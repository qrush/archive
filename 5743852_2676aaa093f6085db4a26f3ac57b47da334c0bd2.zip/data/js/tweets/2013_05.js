Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/GmaWPxwOIs",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=5802412",
      "display_url" : "news.ycombinator.com\/item?id=5802412"
    } ]
  },
  "geo" : { },
  "id_str" : "340668077844865024",
  "text" : "RT @moonpolysoft: LOLOLOLOLOLOLOLOL https:\/\/t.co\/GmaWPxwOIs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/GmaWPxwOIs",
        "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=5802412",
        "display_url" : "news.ycombinator.com\/item?id=5802412"
      } ]
    },
    "geo" : { },
    "id_str" : "340663845322366976",
    "text" : "LOLOLOLOLOLOLOLOL https:\/\/t.co\/GmaWPxwOIs",
    "id" : 340663845322366976,
    "created_at" : "2013-06-01 02:59:24 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 340668077844865024,
  "created_at" : "2013-06-01 03:16:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 0, 10 ],
      "id_str" : "14253068",
      "id" : 14253068
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 11, 22 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 23, 32 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Jay Fields",
      "screen_name" : "thejayfields",
      "indices" : [ 33, 46 ],
      "id_str" : "128951516",
      "id" : 128951516
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 57, 65 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340658258933063682",
  "geo" : { },
  "id_str" : "340658709820743680",
  "in_reply_to_user_id" : 14253068,
  "text" : "@mfeathers @tenderlove @KentBeck @thejayfields same with @jayunit !",
  "id" : 340658709820743680,
  "in_reply_to_status_id" : 340658258933063682,
  "created_at" : "2013-06-01 02:39:00 +0000",
  "in_reply_to_screen_name" : "mfeathers",
  "in_reply_to_user_id_str" : "14253068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340640473133744128",
  "text" : "OH \u201Cwere there strange satyrs?\u201D \u201CNo, we aren\u2019t Jewish\u201D",
  "id" : 340640473133744128,
  "created_at" : "2013-06-01 01:26:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340537640162050048",
  "geo" : { },
  "id_str" : "340546151365365760",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney Woot!",
  "id" : 340546151365365760,
  "in_reply_to_status_id" : 340537640162050048,
  "created_at" : "2013-05-31 19:11:44 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 3, 17 ],
      "id_str" : "25321479",
      "id" : 25321479
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oThTqj80EP",
      "expanded_url" : "http:\/\/ow.ly\/lyIGU",
      "display_url" : "ow.ly\/lyIGU"
    } ]
  },
  "geo" : { },
  "id_str" : "340477747434504192",
  "text" : "RT @BuffaloDotCom: Celebrate 1 year of @coworkbuffalo's existence with a Friday worth of free access to the cool co-working space http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 20, 34 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/oThTqj80EP",
        "expanded_url" : "http:\/\/ow.ly\/lyIGU",
        "display_url" : "ow.ly\/lyIGU"
      } ]
    },
    "geo" : { },
    "id_str" : "340276484512022528",
    "text" : "Celebrate 1 year of @coworkbuffalo's existence with a Friday worth of free access to the cool co-working space http:\/\/t.co\/oThTqj80EP",
    "id" : 340276484512022528,
    "created_at" : "2013-05-31 01:20:10 +0000",
    "user" : {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "protected" : false,
      "id_str" : "25321479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467067080139759616\/zJQOtsXK_normal.jpeg",
      "id" : 25321479,
      "verified" : false
    }
  },
  "id" : 340477747434504192,
  "created_at" : "2013-05-31 14:39:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340477567901499394",
  "text" : "RT @coworkbuffalo: 3 awesome things happening today: Free coworking, our 1 year anniversary, and the most important: A\/C!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340477529167118337",
    "text" : "3 awesome things happening today: Free coworking, our 1 year anniversary, and the most important: A\/C!",
    "id" : 340477529167118337,
    "created_at" : "2013-05-31 14:39:03 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 340477567901499394,
  "created_at" : "2013-05-31 14:39:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/nZqb0uvQgO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=MsUNE3Vdh_w",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340467527564029953",
  "text" : "Agricola on iPad?! YES http:\/\/t.co\/nZqb0uvQgO",
  "id" : 340467527564029953,
  "created_at" : "2013-05-31 13:59:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340336663135924224",
  "geo" : { },
  "id_str" : "340337387458674688",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog dopapod?! No way, it was a Mario castle\/boss castle theme!",
  "id" : 340337387458674688,
  "in_reply_to_status_id" : 340336663135924224,
  "created_at" : "2013-05-31 05:22:10 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 55, 67 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/340328143648858112\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/SzyaQBxlGz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLkWpL2CIAAmUW0.jpg",
      "id_str" : "340328143653052416",
      "id" : 340328143653052416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLkWpL2CIAAmUW0.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SzyaQBxlGz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340328143648858112",
  "text" : "Super Mario Bros (with Mario\/Wario hats) &gt; Eon Don. @AqueousBand 1UP! http:\/\/t.co\/SzyaQBxlGz",
  "id" : 340328143648858112,
  "created_at" : "2013-05-31 04:45:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340322935422193665",
  "text" : "In a loud bar waiting for a favorite band while in the corner tweeting. Not good at social things.",
  "id" : 340322935422193665,
  "created_at" : "2013-05-31 04:24:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 5, 17 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/340304926783709185\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/BxWioubhn2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLkBhyTCIAEY36S.jpg",
      "id_str" : "340304926792097793",
      "id" : 340304926792097793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLkBhyTCIAEY36S.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 947
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 947
      } ],
      "display_url" : "pic.twitter.com\/BxWioubhn2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340304926783709185",
  "text" : "It\u2019s @AqueousBand time! http:\/\/t.co\/BxWioubhn2",
  "id" : 340304926783709185,
  "created_at" : "2013-05-31 03:13:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 3, 19 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 133, 138 ]
    }, {
      "text" : "rubykaigi",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/vwEKrsPBNc",
      "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org",
      "display_url" : "github.com\/ruby\/www.ruby-\u2026"
    }, {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/975cqOU24x",
      "expanded_url" : "http:\/\/www.ruby-lang.org",
      "display_url" : "ruby-lang.org"
    } ]
  },
  "geo" : { },
  "id_str" : "340216062538813442",
  "text" : "RT @postmodern_mod3: https:\/\/t.co\/vwEKrsPBNc After two years, http:\/\/t.co\/975cqOU24x is now 100% Markdown and Jekyll, and on GitHub. #ruby \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruby",
        "indices" : [ 112, 117 ]
      }, {
        "text" : "rubykaigi",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/vwEKrsPBNc",
        "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org",
        "display_url" : "github.com\/ruby\/www.ruby-\u2026"
      }, {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/975cqOU24x",
        "expanded_url" : "http:\/\/www.ruby-lang.org",
        "display_url" : "ruby-lang.org"
      } ]
    },
    "geo" : { },
    "id_str" : "340215619205099520",
    "text" : "https:\/\/t.co\/vwEKrsPBNc After two years, http:\/\/t.co\/975cqOU24x is now 100% Markdown and Jekyll, and on GitHub. #ruby #rubykaigi",
    "id" : 340215619205099520,
    "created_at" : "2013-05-30 21:18:19 +0000",
    "user" : {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "protected" : false,
      "id_str" : "46852648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/261097869\/postmodern_normal.jpg",
      "id" : 46852648,
      "verified" : false
    }
  },
  "id" : 340216062538813442,
  "created_at" : "2013-05-30 21:20:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 3, 15 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/AJqPa8jvOJ",
      "expanded_url" : "http:\/\/lazowska.cs.washington.edu\/workforce.oped\/National.STEM.gap.pdf",
      "display_url" : "lazowska.cs.washington.edu\/workforce.oped\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340213794779308034",
  "text" : "RT @eliseworthy: A graph of degrees granted versus open positions in the US. No wonder we have hiring problems. http:\/\/t.co\/AJqPa8jvOJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/AJqPa8jvOJ",
        "expanded_url" : "http:\/\/lazowska.cs.washington.edu\/workforce.oped\/National.STEM.gap.pdf",
        "display_url" : "lazowska.cs.washington.edu\/workforce.oped\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340213574691586050",
    "text" : "A graph of degrees granted versus open positions in the US. No wonder we have hiring problems. http:\/\/t.co\/AJqPa8jvOJ",
    "id" : 340213574691586050,
    "created_at" : "2013-05-30 21:10:11 +0000",
    "user" : {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "protected" : false,
      "id_str" : "198661893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502913017634250754\/3Da3F-N8_normal.jpeg",
      "id" : 198661893,
      "verified" : false
    }
  },
  "id" : 340213794779308034,
  "created_at" : "2013-05-30 21:11:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "russolsen",
      "screen_name" : "russolsen",
      "indices" : [ 0, 10 ],
      "id_str" : "15740685",
      "id" : 15740685
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 24, 30 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/KaxBFxb6BO",
      "expanded_url" : "https:\/\/twitter.com\/jamis\/status\/335108402005016577",
      "display_url" : "twitter.com\/jamis\/status\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "340212999233097729",
  "geo" : { },
  "id_str" : "340213508413198336",
  "in_reply_to_user_id" : 15740685,
  "text" : "@russolsen Don't do it! @jamis, you should write more about it: https:\/\/t.co\/KaxBFxb6BO",
  "id" : 340213508413198336,
  "in_reply_to_status_id" : 340212999233097729,
  "created_at" : "2013-05-30 21:09:55 +0000",
  "in_reply_to_screen_name" : "russolsen",
  "in_reply_to_user_id_str" : "15740685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340212136166965248",
  "geo" : { },
  "id_str" : "340212622408417280",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski wtf? Still haven't had anything crazy like this happen in EV\/Allentown\/Downtown :(",
  "id" : 340212622408417280,
  "in_reply_to_status_id" : 340212136166965248,
  "created_at" : "2013-05-30 21:06:24 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Whole Hog Truck",
      "screen_name" : "WholeHogTruck",
      "indices" : [ 36, 50 ],
      "id_str" : "298098634",
      "id" : 298098634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340159782453383168",
  "text" : "$6 for a slider and beet salad from @WholeHogTruck. Unbeatable value.",
  "id" : 340159782453383168,
  "created_at" : "2013-05-30 17:36:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 51, 65 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340134412291289088",
  "text" : "RT @theediguy: I'm coworking tomorrow to celebrate @coworkbuffalo's one year anniversary. Come on down and celebrate with us! Even to just \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 36, 50 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340089489907122177",
    "text" : "I'm coworking tomorrow to celebrate @coworkbuffalo's one year anniversary. Come on down and celebrate with us! Even to just say hi.",
    "id" : 340089489907122177,
    "created_at" : "2013-05-30 12:57:07 +0000",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 340134412291289088,
  "created_at" : "2013-05-30 15:55:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340133256173322240",
  "text" : "Just had to renew my iOS Development Certificate, it's been a year of iOS work so far. That went quick.",
  "id" : 340133256173322240,
  "created_at" : "2013-05-30 15:51:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FiKz0xszsI",
      "expanded_url" : "http:\/\/www.ccsp.sfu.ca\/2013\/05\/software-preservation-and-the-special-problem-of-unix\/",
      "display_url" : "ccsp.sfu.ca\/2013\/05\/softwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339954339508518913",
  "text" : "RT @sstephenson: \u201CUnix is self-archiving \u2026 It preserves itself by being continually re-implemented and re-created.\u201D http:\/\/t.co\/FiKz0xszsI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/FiKz0xszsI",
        "expanded_url" : "http:\/\/www.ccsp.sfu.ca\/2013\/05\/software-preservation-and-the-special-problem-of-unix\/",
        "display_url" : "ccsp.sfu.ca\/2013\/05\/softwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339942536837738496",
    "text" : "\u201CUnix is self-archiving \u2026 It preserves itself by being continually re-implemented and re-created.\u201D http:\/\/t.co\/FiKz0xszsI",
    "id" : 339942536837738496,
    "created_at" : "2013-05-30 03:13:11 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 339954339508518913,
  "created_at" : "2013-05-30 04:00:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/7A6pky3ur3",
      "expanded_url" : "http:\/\/gawker.com\/we-drank-soylent-the-weird-food-of-the-future-510293401",
      "display_url" : "gawker.com\/we-drank-soyle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339921278695784448",
  "text" : "There's something sad about a programming optimizing the joy and taste out of food. http:\/\/t.co\/7A6pky3ur3",
  "id" : 339921278695784448,
  "created_at" : "2013-05-30 01:48:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/dfIeZT9ADh",
      "expanded_url" : "https:\/\/vine.co\/v\/bYvZJIW1Dbb",
      "display_url" : "vine.co\/v\/bYvZJIW1Dbb"
    } ]
  },
  "geo" : { },
  "id_str" : "339911392490561536",
  "text" : "Link needs an invite to the new Hyrule Maps Beta. https:\/\/t.co\/dfIeZT9ADh",
  "id" : 339911392490561536,
  "created_at" : "2013-05-30 01:09:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/H9iXOZPxRO",
      "expanded_url" : "https:\/\/vine.co\/v\/bYvWE3uYVFq",
      "display_url" : "vine.co\/v\/bYvWE3uYVFq"
    } ]
  },
  "geo" : { },
  "id_str" : "339910393222799360",
  "text" : "My Super NES has seen better days. https:\/\/t.co\/H9iXOZPxRO",
  "id" : 339910393222799360,
  "created_at" : "2013-05-30 01:05:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339906786867949568",
  "text" : "Desperation seems to be my biggest motivator for bug squashing. Not sure if this is a bad thing.",
  "id" : 339906786867949568,
  "created_at" : "2013-05-30 00:51:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/ZZ0i3eFMmb",
      "expanded_url" : "http:\/\/forecast.io\/raw\/",
      "display_url" : "forecast.io\/raw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "339898229871222786",
  "text" : "Plug it into my veins: http:\/\/t.co\/ZZ0i3eFMmb",
  "id" : 339898229871222786,
  "created_at" : "2013-05-30 00:17:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339873507112517632",
  "text" : "RT @substack: You can't stop an animated gif. They are unstoppable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339872047784148992",
    "text" : "You can't stop an animated gif. They are unstoppable.",
    "id" : 339872047784148992,
    "created_at" : "2013-05-29 22:33:05 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 339873507112517632,
  "created_at" : "2013-05-29 22:38:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 3, 10 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339861614855585792",
  "text" : "RT @mwhuss: How I find app crashes. \n\n1. Install build \n2. Open app\n3. Give iPad to 2 year old",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339861403781455872",
    "text" : "How I find app crashes. \n\n1. Install build \n2. Open app\n3. Give iPad to 2 year old",
    "id" : 339861403781455872,
    "created_at" : "2013-05-29 21:50:47 +0000",
    "user" : {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "protected" : false,
      "id_str" : "4235881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489787952923295744\/8OxRFdPI_normal.jpeg",
      "id" : 4235881,
      "verified" : false
    }
  },
  "id" : 339861614855585792,
  "created_at" : "2013-05-29 21:51:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4LAD3SZ1K",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Pebble_(watch)",
      "display_url" : "en.wikipedia.org\/wiki\/Pebble_(w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339832835596750848",
  "text" : "lmao @ \"Unusually for a startup at Y Combinator, Migicovsky's business actually generated revenue during the program\" http:\/\/t.co\/b4LAD3SZ1K",
  "id" : 339832835596750848,
  "created_at" : "2013-05-29 19:57:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 56, 63 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ec6k3CxcfT",
      "expanded_url" : "http:\/\/flickr.com\/qrush",
      "display_url" : "flickr.com\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "339826365165600769",
  "text" : "Not sure if this worked before the profile upgrade, but @flickr supports username in URLs now: http:\/\/t.co\/ec6k3CxcfT",
  "id" : 339826365165600769,
  "created_at" : "2013-05-29 19:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/1kGoPdl3nE",
      "expanded_url" : "http:\/\/www.confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
      "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339802353203036161",
  "text" : "RT @r00k: My RailsConf presentation \"How to talk to developers\" is up! I haven't had more fun giving a talk yet. http:\/\/t.co\/1kGoPdl3nE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/1kGoPdl3nE",
        "expanded_url" : "http:\/\/www.confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
        "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339802260617961472",
    "text" : "My RailsConf presentation \"How to talk to developers\" is up! I haven't had more fun giving a talk yet. http:\/\/t.co\/1kGoPdl3nE",
    "id" : 339802260617961472,
    "created_at" : "2013-05-29 17:55:46 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 339802353203036161,
  "created_at" : "2013-05-29 17:56:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 33, 42 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 46, 56 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/p2l5dWiE1J",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2487-railsconf2013-lightning-talks",
      "display_url" : "confreaks.com\/videos\/2487-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339792752646701059",
  "text" : "Once again, my lightning talk on @OpenHack at @railsconf: http:\/\/t.co\/p2l5dWiE1J",
  "id" : 339792752646701059,
  "created_at" : "2013-05-29 17:17:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 3, 13 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 72, 77 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 101, 111 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf2013",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/fmWpijD5fs",
      "expanded_url" : "http:\/\/www.confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
      "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339788375416504320",
  "text" : "RT @confreaks: New Video! #railsconf2013 - How to Talk to Developers by @r00k http:\/\/t.co\/fmWpijD5fs @railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Orenstein",
        "screen_name" : "r00k",
        "indices" : [ 57, 62 ],
        "id_str" : "11280212",
        "id" : 11280212
      }, {
        "name" : "RailsConf 2015",
        "screen_name" : "railsconf",
        "indices" : [ 86, 96 ],
        "id_str" : "5493662",
        "id" : 5493662
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf2013",
        "indices" : [ 11, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/fmWpijD5fs",
        "expanded_url" : "http:\/\/www.confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
        "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339788244185137153",
    "text" : "New Video! #railsconf2013 - How to Talk to Developers by @r00k http:\/\/t.co\/fmWpijD5fs @railsconf",
    "id" : 339788244185137153,
    "created_at" : "2013-05-29 17:00:05 +0000",
    "user" : {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "protected" : false,
      "id_str" : "14182110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508193987417485312\/4FaFrBga_normal.png",
      "id" : 14182110,
      "verified" : false
    }
  },
  "id" : 339788375416504320,
  "created_at" : "2013-05-29 17:00:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Mw3lzaoaE3",
      "expanded_url" : "http:\/\/archive.org\/details\/aq2013-04-06",
      "display_url" : "archive.org\/details\/aq2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339763436328218624",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Awesome, they covered Knights of Cydonia last time I saw them for the first time: http:\/\/t.co\/Mw3lzaoaE3",
  "id" : 339763436328218624,
  "created_at" : "2013-05-29 15:21:30 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/hYDhxVUwsD",
      "expanded_url" : "https:\/\/fbcdn-sphotos-b-a.akamaihd.net\/hphotos-ak-ash4\/217369_10100495764051905_1018906469_n.jpg",
      "display_url" : "fbcdn-sphotos-b-a.akamaihd.net\/hphotos-ak-ash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339755200871022594",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant awesome. Pumped for Thursday - SUPER AQUEOUS BROS https:\/\/t.co\/hYDhxVUwsD",
  "id" : 339755200871022594,
  "created_at" : "2013-05-29 14:48:46 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 0, 11 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339753890293637122",
  "geo" : { },
  "id_str" : "339754575244431361",
  "in_reply_to_user_id" : 14104108,
  "text" : "@itspriddle also knowing many \"real\" engineers what we do is so far removed from engineering it's a joke (I also have a SE degree)",
  "id" : 339754575244431361,
  "in_reply_to_status_id" : 339753890293637122,
  "created_at" : "2013-05-29 14:46:17 +0000",
  "in_reply_to_screen_name" : "itspriddle",
  "in_reply_to_user_id_str" : "14104108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Priddle",
      "screen_name" : "itspriddle",
      "indices" : [ 0, 11 ],
      "id_str" : "14104108",
      "id" : 14104108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339753890293637122",
  "geo" : { },
  "id_str" : "339754316971790336",
  "in_reply_to_user_id" : 14104108,
  "text" : "@itspriddle yes, i prefer \"Programmer\"",
  "id" : 339754316971790336,
  "in_reply_to_status_id" : 339753890293637122,
  "created_at" : "2013-05-29 14:45:16 +0000",
  "in_reply_to_screen_name" : "itspriddle",
  "in_reply_to_user_id_str" : "14104108",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339750264057786369",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant worth downloading?",
  "id" : 339750264057786369,
  "created_at" : "2013-05-29 14:29:09 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Nesselbeck",
      "screen_name" : "Alex_Nesselbeck",
      "indices" : [ 3, 19 ],
      "id_str" : "35598878",
      "id" : 35598878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/jHsXxodNml",
      "expanded_url" : "http:\/\/hofbrauhauscanalside.com\/",
      "display_url" : "hofbrauhauscanalside.com"
    } ]
  },
  "geo" : { },
  "id_str" : "339738655813943296",
  "text" : "RT @Alex_Nesselbeck: Holy crap, #Buffalo, please make this happen! http:\/\/t.co\/jHsXxodNml",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/jHsXxodNml",
        "expanded_url" : "http:\/\/hofbrauhauscanalside.com\/",
        "display_url" : "hofbrauhauscanalside.com"
      } ]
    },
    "geo" : { },
    "id_str" : "339730606952947712",
    "text" : "Holy crap, #Buffalo, please make this happen! http:\/\/t.co\/jHsXxodNml",
    "id" : 339730606952947712,
    "created_at" : "2013-05-29 13:11:03 +0000",
    "user" : {
      "name" : "Alex Nesselbeck",
      "screen_name" : "Alex_Nesselbeck",
      "protected" : false,
      "id_str" : "35598878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3728349513\/e1ee678f8c3b4ec4b16cc669d0f6f82e_normal.jpeg",
      "id" : 35598878,
      "verified" : false
    }
  },
  "id" : 339738655813943296,
  "created_at" : "2013-05-29 13:43:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339617711543971840",
  "geo" : { },
  "id_str" : "339718633003560961",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck curious to see how intros work with that many people. Might need to break into smaller groups.",
  "id" : 339718633003560961,
  "in_reply_to_status_id" : 339617711543971840,
  "created_at" : "2013-05-29 12:23:28 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 3, 11 ],
      "id_str" : "14835545",
      "id" : 14835545
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 20, 29 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339713814683598848",
  "text" : "RT @yann_ck: @qrush @openhack Brussels tonight! With around 40 hackers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 7, 16 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "339605056116629504",
    "geo" : { },
    "id_str" : "339617711543971840",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @openhack Brussels tonight! With around 40 hackers",
    "id" : 339617711543971840,
    "in_reply_to_status_id" : 339605056116629504,
    "created_at" : "2013-05-29 05:42:26 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "protected" : false,
      "id_str" : "14835545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456012586043985921\/VITqbNxD_normal.jpeg",
      "id" : 14835545,
      "verified" : false
    }
  },
  "id" : 339713814683598848,
  "created_at" : "2013-05-29 12:04:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 8, 17 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339605056116629504",
  "text" : "Lots of @OpenHack meetups happening this week - Baltimore, Philly, Toledo, Miami, Valencia (those are just what I can find on twitter)",
  "id" : 339605056116629504,
  "created_at" : "2013-05-29 04:52:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josemar Luedke",
      "screen_name" : "josemarluedke",
      "indices" : [ 3, 17 ],
      "id_str" : "20789347",
      "id" : 20789347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ocMVFdI0tF",
      "expanded_url" : "http:\/\/blog.josemarluedke.com\/posts\/openhack-poa",
      "display_url" : "blog.josemarluedke.com\/posts\/openhack\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339604307840212992",
  "text" : "RT @JosemarLuedke: [Blog post] OpenHack POA http:\/\/t.co\/ocMVFdI0tF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/ocMVFdI0tF",
        "expanded_url" : "http:\/\/blog.josemarluedke.com\/posts\/openhack-poa",
        "display_url" : "blog.josemarluedke.com\/posts\/openhack\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339435312767983618",
    "text" : "[Blog post] OpenHack POA http:\/\/t.co\/ocMVFdI0tF",
    "id" : 339435312767983618,
    "created_at" : "2013-05-28 17:37:39 +0000",
    "user" : {
      "name" : "Josemar Luedke",
      "screen_name" : "josemarluedke",
      "protected" : false,
      "id_str" : "20789347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472455812623765504\/gtYDbp2K_normal.jpeg",
      "id" : 20789347,
      "verified" : false
    }
  },
  "id" : 339604307840212992,
  "created_at" : "2013-05-29 04:49:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sstephenson\/status\/333357815504707585\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/g6ltSJJzDY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKBTKsCCIAA36eR.jpg",
      "id_str" : "333357815508901888",
      "id" : 333357815508901888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKBTKsCCIAA36eR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/g6ltSJJzDY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339519399272775680",
  "text" : "RT @sstephenson: Build Finished! http:\/\/t.co\/g6ltSJJzDY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sstephenson\/status\/333357815504707585\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/g6ltSJJzDY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKBTKsCCIAA36eR.jpg",
        "id_str" : "333357815508901888",
        "id" : 333357815508901888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKBTKsCCIAA36eR.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/g6ltSJJzDY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333357815504707585",
    "text" : "Build Finished! http:\/\/t.co\/g6ltSJJzDY",
    "id" : 333357815504707585,
    "created_at" : "2013-05-11 23:07:51 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 339519399272775680,
  "created_at" : "2013-05-28 23:11:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339404864574595072",
  "geo" : { },
  "id_str" : "339406694876581888",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 Where is this going to be?",
  "id" : 339406694876581888,
  "in_reply_to_status_id" : 339404864574595072,
  "created_at" : "2013-05-28 15:43:56 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/osnxYnioEY",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/57aef9514e4f7da94a7127877032d9d5\/tumblr_mmjtljaL3O1s3v8rqo2_500.gif",
      "display_url" : "24.media.tumblr.com\/57aef9514e4f7d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339402331152076801",
  "text" : "Current status: http:\/\/t.co\/osnxYnioEY",
  "id" : 339402331152076801,
  "created_at" : "2013-05-28 15:26:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XLQW8r96xJ",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2013\/05\/apartment-boom-continues-with-10-symphony-circle.html",
      "display_url" : "buffalorising.com\/2013\/05\/apartm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339367038898274305",
  "text" : "Luckily stories of desolation and depression in WNY are countered nicely by new development and good news: http:\/\/t.co\/XLQW8r96xJ",
  "id" : 339367038898274305,
  "created_at" : "2013-05-28 13:06:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 68, 78 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ubkEb61gnZ",
      "expanded_url" : "http:\/\/buff.ly\/13VM8cp",
      "display_url" : "buff.ly\/13VM8cp"
    } ]
  },
  "geo" : { },
  "id_str" : "339366797897777153",
  "text" : "\u201CThe house I grew up in sold for $4000\u201D http:\/\/t.co\/ubkEb61gnZ (via @acangiano)",
  "id" : 339366797897777153,
  "created_at" : "2013-05-28 13:05:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 3, 10 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339364760174862336",
  "text" : "RT @bryanl: Verizon clerk: how'd you get Google Glass. You know that's only for developers, right?\nMe: not all black guys sling rocks or ha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338728057395372032",
    "text" : "Verizon clerk: how'd you get Google Glass. You know that's only for developers, right?\nMe: not all black guys sling rocks or have jump shots",
    "id" : 338728057395372032,
    "created_at" : "2013-05-26 18:47:16 +0000",
    "user" : {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "protected" : false,
      "id_str" : "659933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573327799135559680\/GiTRW1Hw_normal.jpeg",
      "id" : 659933,
      "verified" : false
    }
  },
  "id" : 339364760174862336,
  "created_at" : "2013-05-28 12:57:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 17, 25 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339270538641948672",
  "geo" : { },
  "id_str" : "339364630688301056",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene @evanphx and I were actually talking about a similar naming scheme to fix the \u201Cclaim\u201D problem. Maybe could sync up in IRC?",
  "id" : 339364630688301056,
  "in_reply_to_status_id" : 339270538641948672,
  "created_at" : "2013-05-28 12:56:47 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "jgehtland",
      "screen_name" : "jgehtland",
      "indices" : [ 12, 22 ],
      "id_str" : "8384012",
      "id" : 8384012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/gFCESQms3c",
      "expanded_url" : "http:\/\/www.catonmat.net\/blog\/wp-content\/uploads\/2008\/12\/john-mccarthy-programming-wrong.jpg",
      "display_url" : "catonmat.net\/blog\/wp-conten\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "339356438721880067",
  "geo" : { },
  "id_str" : "339357215897051136",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler @jgehtland is it time to recreate http:\/\/t.co\/gFCESQms3c ?",
  "id" : 339357215897051136,
  "in_reply_to_status_id" : 339356438721880067,
  "created_at" : "2013-05-28 12:27:19 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/kRFcyeVHMq",
      "expanded_url" : "http:\/\/flic.kr\/p\/ev1u1a",
      "display_url" : "flic.kr\/p\/ev1u1a"
    } ]
  },
  "geo" : { },
  "id_str" : "339187332961935360",
  "text" : "Possibly the only time this husky stood still today. http:\/\/t.co\/kRFcyeVHMq",
  "id" : 339187332961935360,
  "created_at" : "2013-05-28 01:12:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 77, 86 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/S2N2nG23XC",
      "expanded_url" : "https:\/\/soundcloud.com\/arkham_p77\/walt_disnizzle",
      "display_url" : "soundcloud.com\/arkham_p77\/wal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339065686531919872",
  "text" : "Disney + Hiphop \u00F7 Mashup = Walt Disnizzle https:\/\/t.co\/S2N2nG23XC (thanks to @shildner for this find)",
  "id" : 339065686531919872,
  "created_at" : "2013-05-27 17:08:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339049523827585025",
  "geo" : { },
  "id_str" : "339059003202101248",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove or Patchy Beard",
  "id" : 339059003202101248,
  "in_reply_to_status_id" : 339049523827585025,
  "created_at" : "2013-05-27 16:42:20 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/4kvhUu013u",
      "expanded_url" : "http:\/\/flic.kr\/p\/euAZEC",
      "display_url" : "flic.kr\/p\/euAZEC"
    } ]
  },
  "geo" : { },
  "id_str" : "339058045093023745",
  "text" : "Farmops. http:\/\/t.co\/4kvhUu013u",
  "id" : 339058045093023745,
  "created_at" : "2013-05-27 16:38:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339040959004295168",
  "text" : "RT @rubygems_status: The dependency API should be working again. Sorry about that!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339040900925755394",
    "text" : "The dependency API should be working again. Sorry about that!",
    "id" : 339040900925755394,
    "created_at" : "2013-05-27 15:30:24 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 339040959004295168,
  "created_at" : "2013-05-27 15:30:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 27, 35 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "Silo City Rocks!",
      "screen_name" : "SiloCityRocks",
      "indices" : [ 38, 52 ],
      "id_str" : "126023850",
      "id" : 126023850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/LKbNsnZMwN",
      "expanded_url" : "http:\/\/www.nytimes.com\/slideshow\/2013\/05\/26\/travel\/20130526-SURFACING.html?_r=0",
      "display_url" : "nytimes.com\/slideshow\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339038706793082881",
  "text" : "Buffalo travel shoutout in @NYTimes: (@SiloCityRocks too!) http:\/\/t.co\/LKbNsnZMwN",
  "id" : 339038706793082881,
  "created_at" : "2013-05-27 15:21:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/bYngd2rqaB",
      "expanded_url" : "http:\/\/www.clevelandfed.org\/research\/commentary\/2013\/2013-06.cfm",
      "display_url" : "clevelandfed.org\/research\/comme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339038374239289345",
  "text" : "Interesting comparison and lots of data from urban decline 1970-2000's in Cleveland, Detroit, Buffalo, Pittsburgh: http:\/\/t.co\/bYngd2rqaB",
  "id" : 339038374239289345,
  "created_at" : "2013-05-27 15:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 17, 26 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339019403465195521",
  "geo" : { },
  "id_str" : "339019631979286529",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 @evanphx @indirect what i found is in IRC. seeing upstream timeouts but not sure if I should restart nginx.",
  "id" : 339019631979286529,
  "in_reply_to_status_id" : 339019403465195521,
  "created_at" : "2013-05-27 14:05:53 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338826869417857024",
  "geo" : { },
  "id_str" : "339017115325587457",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy In all seriousness it might be. Worth it?",
  "id" : 339017115325587457,
  "in_reply_to_status_id" : 338826869417857024,
  "created_at" : "2013-05-27 13:55:53 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Carlsen",
      "screen_name" : "sjelfull",
      "indices" : [ 0, 9 ],
      "id_str" : "44462601",
      "id" : 44462601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339000768860409859",
  "geo" : { },
  "id_str" : "339016147955507200",
  "in_reply_to_user_id" : 44462601,
  "text" : "@sjelfull Why do you need sub sub commands? Curious about the use case...seems overly complex.",
  "id" : 339016147955507200,
  "in_reply_to_status_id" : 339000768860409859,
  "created_at" : "2013-05-27 13:52:02 +0000",
  "in_reply_to_screen_name" : "sjelfull",
  "in_reply_to_user_id_str" : "44462601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 39, 48 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339008564100206592",
  "geo" : { },
  "id_str" : "339015308436193281",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr have you talked to Sunlight (or @konklone) yet?",
  "id" : 339015308436193281,
  "in_reply_to_status_id" : 339008564100206592,
  "created_at" : "2013-05-27 13:48:42 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Menno van der Sman",
      "screen_name" : "mennos",
      "indices" : [ 0, 7 ],
      "id_str" : "10599012",
      "id" : 10599012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339001350526480385",
  "geo" : { },
  "id_str" : "339002038362976257",
  "in_reply_to_user_id" : 10599012,
  "text" : "@mennos yep, seems like it. Not sure where that lives or how to fix it though. Trying to ping some of the others.",
  "id" : 339002038362976257,
  "in_reply_to_status_id" : 339001350526480385,
  "created_at" : "2013-05-27 12:55:58 +0000",
  "in_reply_to_screen_name" : "mennos",
  "in_reply_to_user_id_str" : "10599012",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Carlsen",
      "screen_name" : "sjelfull",
      "indices" : [ 0, 9 ],
      "id_str" : "44462601",
      "id" : 44462601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338999395561373696",
  "geo" : { },
  "id_str" : "338999973221908480",
  "in_reply_to_user_id" : 44462601,
  "text" : "@sjelfull I also havent had time to look into those issues, and none of them have affected us.",
  "id" : 338999973221908480,
  "in_reply_to_status_id" : 338999395561373696,
  "created_at" : "2013-05-27 12:47:46 +0000",
  "in_reply_to_screen_name" : "sjelfull",
  "in_reply_to_user_id_str" : "44462601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Carlsen",
      "screen_name" : "sjelfull",
      "indices" : [ 0, 9 ],
      "id_str" : "44462601",
      "id" : 44462601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338999395561373696",
  "geo" : { },
  "id_str" : "338999890157920257",
  "in_reply_to_user_id" : 44462601,
  "text" : "@sjelfull we use 37 (and sub) every day, it's just stable. I hate how github issues\/PRs make a project seem abandoned.",
  "id" : 338999890157920257,
  "in_reply_to_status_id" : 338999395561373696,
  "created_at" : "2013-05-27 12:47:26 +0000",
  "in_reply_to_screen_name" : "sjelfull",
  "in_reply_to_user_id_str" : "44462601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel",
      "screen_name" : "marceldegraaf",
      "indices" : [ 0, 14 ],
      "id_str" : "16087412",
      "id" : 16087412
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 81, 89 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 90, 97 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 98, 107 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338989219827552257",
  "geo" : { },
  "id_str" : "338998972712636416",
  "in_reply_to_user_id" : 16087412,
  "text" : "@marceldegraaf not sure, just did a heroku restart. let's see if that helps. \/cc @evanphx @hone02 @indirect",
  "id" : 338998972712636416,
  "in_reply_to_status_id" : 338989219827552257,
  "created_at" : "2013-05-27 12:43:48 +0000",
  "in_reply_to_screen_name" : "marceldegraaf",
  "in_reply_to_user_id_str" : "16087412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Y23fyYTssm",
      "expanded_url" : "http:\/\/screenshotsofdespair.tumblr.com\/",
      "display_url" : "screenshotsofdespair.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "338878481813356544",
  "text" : "RT @codinghorror: Screenshots of despair http:\/\/t.co\/Y23fyYTssm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/Y23fyYTssm",
        "expanded_url" : "http:\/\/screenshotsofdespair.tumblr.com\/",
        "display_url" : "screenshotsofdespair.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "338877208770793472",
    "text" : "Screenshots of despair http:\/\/t.co\/Y23fyYTssm",
    "id" : 338877208770793472,
    "created_at" : "2013-05-27 04:39:57 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2052442590\/coding-horror-official-logo-medium_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 338878481813356544,
  "created_at" : "2013-05-27 04:45:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 3, 10 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/h6ETrpiMjg",
      "expanded_url" : "http:\/\/dukope.com\/usemyname\/",
      "display_url" : "dukope.com\/usemyname\/"
    } ]
  },
  "geo" : { },
  "id_str" : "338867300671307779",
  "text" : "RT @dukope: Gonna close name submissions after May 31st. Submit your name now if you haven't already. http:\/\/t.co\/h6ETrpiMjg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/h6ETrpiMjg",
        "expanded_url" : "http:\/\/dukope.com\/usemyname\/",
        "display_url" : "dukope.com\/usemyname\/"
      } ]
    },
    "geo" : { },
    "id_str" : "338863175342637057",
    "text" : "Gonna close name submissions after May 31st. Submit your name now if you haven't already. http:\/\/t.co\/h6ETrpiMjg",
    "id" : 338863175342637057,
    "created_at" : "2013-05-27 03:44:11 +0000",
    "user" : {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "protected" : false,
      "id_str" : "520685404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889196876\/image_normal.jpg",
      "id" : 520685404,
      "verified" : false
    }
  },
  "id" : 338867300671307779,
  "created_at" : "2013-05-27 04:00:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    }, {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 75, 81 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338852659111026688",
  "geo" : { },
  "id_str" : "338853063169306625",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave yes!! Just got to play the 3rd expansion. So good! You me and @jamis need to play sometime ;)",
  "id" : 338853063169306625,
  "in_reply_to_status_id" : 338852659111026688,
  "created_at" : "2013-05-27 03:04:00 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "The Sweethome",
      "screen_name" : "homesweethome",
      "indices" : [ 46, 60 ],
      "id_str" : "1099960304",
      "id" : 1099960304
    }, {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 79, 90 ],
      "id_str" : "12304192",
      "id" : 12304192
    }, {
      "name" : "Ed Grabianowski",
      "screen_name" : "therobotviking",
      "indices" : [ 92, 107 ],
      "id_str" : "38103823",
      "id" : 38103823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338852821212479491",
  "text" : "RT @kevinpurdy: 3 writers for nearly-launched @homesweethome based in Buffalo: @thenickguy, @therobotviking, myself. Buffalo: We Have Consu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sweethome",
        "screen_name" : "homesweethome",
        "indices" : [ 30, 44 ],
        "id_str" : "1099960304",
        "id" : 1099960304
      }, {
        "name" : "Nick Guy",
        "screen_name" : "thenickguy",
        "indices" : [ 63, 74 ],
        "id_str" : "12304192",
        "id" : 12304192
      }, {
        "name" : "Ed Grabianowski",
        "screen_name" : "therobotviking",
        "indices" : [ 76, 91 ],
        "id_str" : "38103823",
        "id" : 38103823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338849081768161281",
    "text" : "3 writers for nearly-launched @homesweethome based in Buffalo: @thenickguy, @therobotviking, myself. Buffalo: We Have Consumer Opinions.",
    "id" : 338849081768161281,
    "created_at" : "2013-05-27 02:48:11 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 338852821212479491,
  "created_at" : "2013-05-27 03:03:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Delcambre",
      "screen_name" : "adelcambre",
      "indices" : [ 0, 11 ],
      "id_str" : "5424182",
      "id" : 5424182
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 12, 16 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338814247289114624",
  "geo" : { },
  "id_str" : "338819007090159616",
  "in_reply_to_user_id" : 5424182,
  "text" : "@adelcambre @lrz I still haven\u2019t made it through K&amp;R after several tries :(",
  "id" : 338819007090159616,
  "in_reply_to_status_id" : 338814247289114624,
  "created_at" : "2013-05-27 00:48:40 +0000",
  "in_reply_to_screen_name" : "adelcambre",
  "in_reply_to_user_id_str" : "5424182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Robinson",
      "screen_name" : "codeofinterest",
      "indices" : [ 0, 15 ],
      "id_str" : "19880887",
      "id" : 19880887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338802159116226560",
  "geo" : { },
  "id_str" : "338811896859860992",
  "in_reply_to_user_id" : 19880887,
  "text" : "@codeofinterest for someone who hasn\u2019t programmed before? Way too much.",
  "id" : 338811896859860992,
  "in_reply_to_status_id" : 338802159116226560,
  "created_at" : "2013-05-27 00:20:25 +0000",
  "in_reply_to_screen_name" : "codeofinterest",
  "in_reply_to_user_id_str" : "19880887",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338799271623143424",
  "geo" : { },
  "id_str" : "338800282928562176",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz I was thinking SICP too, but I find lisp\/scheme to be very...out there for beginners. maybe it's just me.",
  "id" : 338800282928562176,
  "in_reply_to_status_id" : 338799271623143424,
  "created_at" : "2013-05-26 23:34:16 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338799507301101568",
  "geo" : { },
  "id_str" : "338800206458019840",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc i browsed this a bit a few years back and liked it. Strong contender.",
  "id" : 338800206458019840,
  "in_reply_to_status_id" : 338799507301101568,
  "created_at" : "2013-05-26 23:33:58 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338798720785195008",
  "text" : "Found out my cousin-in-law wants to go into Computer Science. Going to pick him up Learn to Program, any suggestions for a second book?",
  "id" : 338798720785195008,
  "created_at" : "2013-05-26 23:28:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338467741642133504",
  "geo" : { },
  "id_str" : "338495103666647040",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw to my 25 year old current self: take allergy medicine today.",
  "id" : 338495103666647040,
  "in_reply_to_status_id" : 338467741642133504,
  "created_at" : "2013-05-26 03:21:36 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/338416789035823104\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/D8RPOJUeFn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLJMRtECMAAGV29.jpg",
      "id_str" : "338416789044211712",
      "id" : 338416789044211712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLJMRtECMAAGV29.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/D8RPOJUeFn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338416789035823104",
  "text" : "What is going on in this pinball machine? http:\/\/t.co\/D8RPOJUeFn",
  "id" : 338416789035823104,
  "created_at" : "2013-05-25 22:10:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/dLIhXyhzC2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9jK-NcRmVcw",
      "display_url" : "youtube.com\/watch?v=9jK-Nc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338362341118836736",
  "text" : "It's the FINAL COUNTDOWN! http:\/\/t.co\/dLIhXyhzC2",
  "id" : 338362341118836736,
  "created_at" : "2013-05-25 18:34:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338361166202019840",
  "text" : "Free name for a vegan metal band: Murdersalad.",
  "id" : 338361166202019840,
  "created_at" : "2013-05-25 18:29:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Hubert",
      "screen_name" : "zhubert",
      "indices" : [ 0, 8 ],
      "id_str" : "9229622",
      "id" : 9229622
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 9, 20 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338099370404741121",
  "geo" : { },
  "id_str" : "338109445995384832",
  "in_reply_to_user_id" : 9229622,
  "text" : "@zhubert @dangigante $75 each",
  "id" : 338109445995384832,
  "in_reply_to_status_id" : 338099370404741121,
  "created_at" : "2013-05-25 01:49:08 +0000",
  "in_reply_to_screen_name" : "zhubert",
  "in_reply_to_user_id_str" : "9229622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/338096912924286977\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/vnT1jFzKtS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLEpWdrCIAATnad.jpg",
      "id_str" : "338096912928481280",
      "id" : 338096912928481280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLEpWdrCIAATnad.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vnT1jFzKtS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338096912924286977",
  "text" : "Seriously vintage D&amp;D. http:\/\/t.co\/vnT1jFzKtS",
  "id" : 338096912924286977,
  "created_at" : "2013-05-25 00:59:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338043634500902913",
  "geo" : { },
  "id_str" : "338046595776000000",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman family is nearby.",
  "id" : 338046595776000000,
  "in_reply_to_status_id" : 338043634500902913,
  "created_at" : "2013-05-24 21:39:23 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338043003212017664",
  "text" : "@melissadclayton yep!",
  "id" : 338043003212017664,
  "created_at" : "2013-05-24 21:25:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338041464309301249",
  "text" : "Youngstown, OH hipsters: ear gauges + camo print baseball cap.",
  "id" : 338041464309301249,
  "created_at" : "2013-05-24 21:19:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Rasmusson",
      "screen_name" : "jrasmusson",
      "indices" : [ 3, 14 ],
      "id_str" : "143659171",
      "id" : 143659171
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 54, 60 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "OpenHack Calgary",
      "screen_name" : "OpenHackYYC",
      "indices" : [ 93, 105 ],
      "id_str" : "1332518635",
      "id" : 1332518635
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funny",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/L1FxeN6JQZ",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
      "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337943391742590976",
  "text" : "RT @jrasmusson: Really like this video on OpenHack by @qrush : http:\/\/t.co\/L1FxeN6JQZ #funny @OpenHackYYC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 38, 44 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "OpenHack Calgary",
        "screen_name" : "OpenHackYYC",
        "indices" : [ 77, 89 ],
        "id_str" : "1332518635",
        "id" : 1332518635
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/L1FxeN6JQZ",
        "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
        "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337937794209046528",
    "text" : "Really like this video on OpenHack by @qrush : http:\/\/t.co\/L1FxeN6JQZ #funny @OpenHackYYC",
    "id" : 337937794209046528,
    "created_at" : "2013-05-24 14:27:03 +0000",
    "user" : {
      "name" : "Jonathan Rasmusson",
      "screen_name" : "jrasmusson",
      "protected" : false,
      "id_str" : "143659171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/898620028\/photo_normal.jpg",
      "id" : 143659171,
      "verified" : false
    }
  },
  "id" : 337943391742590976,
  "created_at" : "2013-05-24 14:49:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pebble",
      "screen_name" : "Pebble",
      "indices" : [ 0, 7 ],
      "id_str" : "515766653",
      "id" : 515766653
    }, {
      "name" : "Alexander",
      "screen_name" : "chebatron",
      "indices" : [ 8, 18 ],
      "id_str" : "14336828",
      "id" : 14336828
    }, {
      "name" : "CAPSULE",
      "screen_name" : "capsulewallets",
      "indices" : [ 19, 34 ],
      "id_str" : "1002358831",
      "id" : 1002358831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337851867965059072",
  "geo" : { },
  "id_str" : "337943346033065984",
  "in_reply_to_user_id" : 515766653,
  "text" : "@Pebble @chebatron @capsulewallets I wish I was a watch person!",
  "id" : 337943346033065984,
  "in_reply_to_status_id" : 337851867965059072,
  "created_at" : "2013-05-24 14:49:07 +0000",
  "in_reply_to_screen_name" : "Pebble",
  "in_reply_to_user_id_str" : "515766653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337780372039417856",
  "text" : "Stages of husky confinement: Whining, Denial, Regret, Confusion, Escape Plotting, More Whining, Acceptance.",
  "id" : 337780372039417856,
  "created_at" : "2013-05-24 04:01:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 19, 30 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 35, 47 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 91, 105 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/4ix8QvqChv",
      "expanded_url" : "http:\/\/5by5.tv\/inbeta\/50",
      "display_url" : "5by5.tv\/inbeta\/50"
    } ]
  },
  "geo" : { },
  "id_str" : "337671360828542976",
  "text" : "Latest inBeta with @kevinpurdy and @ginatrapani goes over the founding &amp; first year of @coworkbuffalo: http:\/\/t.co\/4ix8QvqChv",
  "id" : 337671360828542976,
  "created_at" : "2013-05-23 20:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Youngman",
      "screen_name" : "nathany",
      "indices" : [ 0, 8 ],
      "id_str" : "7145962",
      "id" : 7145962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337670845587668992",
  "geo" : { },
  "id_str" : "337671182084079616",
  "in_reply_to_user_id" : 7145962,
  "text" : "@nathany I wouldn't want to tie it to GitHub...probably not likely as long as I'm involved :)",
  "id" : 337671182084079616,
  "in_reply_to_status_id" : 337670845587668992,
  "created_at" : "2013-05-23 20:47:38 +0000",
  "in_reply_to_screen_name" : "nathany",
  "in_reply_to_user_id_str" : "7145962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 3, 13 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337614965580115970",
  "text" : "RT @tehviking: @qrush I noted yesterday that I have literally 10 apps open so people can get ahold of me. Something\u2019s broken, technically &amp;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "337591704548950018",
    "geo" : { },
    "id_str" : "337613476837064705",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I noted yesterday that I have literally 10 apps open so people can get ahold of me. Something\u2019s broken, technically &amp; societally.",
    "id" : 337613476837064705,
    "in_reply_to_status_id" : 337591704548950018,
    "created_at" : "2013-05-23 16:58:20 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "protected" : false,
      "id_str" : "59341538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431152612264509440\/r4L_jVW6_normal.jpeg",
      "id" : 59341538,
      "verified" : false
    }
  },
  "id" : 337614965580115970,
  "created_at" : "2013-05-23 17:04:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337592588108431360",
  "text" : "Oh, I forgot 2: Hangouts, Skype, Trillian, Flint, IRCCloud, Facebook Messenger, SMS. FML.",
  "id" : 337592588108431360,
  "created_at" : "2013-05-23 15:35:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337591704548950018",
  "text" : "I am in a complete chat overload: Hangouts, Trillian, IRCCloud, Skype, Flint. Sick of it.",
  "id" : 337591704548950018,
  "created_at" : "2013-05-23 15:31:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337412041079914497",
  "geo" : { },
  "id_str" : "337413785490948096",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines I can confirm this happens frequently",
  "id" : 337413785490948096,
  "in_reply_to_status_id" : 337412041079914497,
  "created_at" : "2013-05-23 03:44:49 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337229969484820481",
  "geo" : { },
  "id_str" : "337231805382000640",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic not sure! Not near a computer right now.",
  "id" : 337231805382000640,
  "in_reply_to_status_id" : 337229969484820481,
  "created_at" : "2013-05-22 15:41:42 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/QR2X1b546K",
      "expanded_url" : "http:\/\/magicalgametime.com",
      "display_url" : "magicalgametime.com"
    } ]
  },
  "geo" : { },
  "id_str" : "337051409751109635",
  "text" : "I think about what http:\/\/t.co\/QR2X1b546K will look like for kids 20 years from now and it makes me sad. Where did the stories go?",
  "id" : 337051409751109635,
  "created_at" : "2013-05-22 03:44:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 116, 125 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337048764021870593",
  "geo" : { },
  "id_str" : "337050778378305538",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm I\u2019m more curious about this from those in the game industry. Just seems like such an opportunity. \/cc @mittense",
  "id" : 337050778378305538,
  "in_reply_to_status_id" : 337048764021870593,
  "created_at" : "2013-05-22 03:42:22 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337048821328646145",
  "geo" : { },
  "id_str" : "337050525797335040",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella not an excuse, IMO.",
  "id" : 337050525797335040,
  "in_reply_to_status_id" : 337048821328646145,
  "created_at" : "2013-05-22 03:41:22 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337044648902152193",
  "geo" : { },
  "id_str" : "337048691858894850",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden WHAT?",
  "id" : 337048691858894850,
  "in_reply_to_status_id" : 337044648902152193,
  "created_at" : "2013-05-22 03:34:04 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337048488057655298",
  "text" : "What\u2019s sad about iPad as the \u201Cgame console of the future\u201D - instead of Mario and Zelda, you get an angry bird and ropes to cut. So sad.",
  "id" : 337048488057655298,
  "created_at" : "2013-05-22 03:33:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337047093883572224",
  "geo" : { },
  "id_str" : "337048131608928258",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan totally died here already :(",
  "id" : 337048131608928258,
  "in_reply_to_status_id" : 337047093883572224,
  "created_at" : "2013-05-22 03:31:51 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336992738748817410",
  "geo" : { },
  "id_str" : "336993093154897922",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden What about yellow?!",
  "id" : 336993093154897922,
  "in_reply_to_status_id" : 336992738748817410,
  "created_at" : "2013-05-21 23:53:09 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 26, 40 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 70, 79 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336987924174344192",
  "text" : "A fitting anniversary for @coworkbuffalo is a nearly-filled space for @OpenHack!",
  "id" : 336987924174344192,
  "created_at" : "2013-05-21 23:32:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 55, 69 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 94, 103 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336846481896140800",
  "text" : "Related note, I brought some 18 year Glenlivet down to @coworkbuffalo. Come down today or for @OpenHack and you're welcome to some.",
  "id" : 336846481896140800,
  "created_at" : "2013-05-21 14:10:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336837591267680256",
  "text" : "RT @coworkbuffalo: It's our one-year anniversary today! So thankful to community that comes, sits, chats, and cranks. Stay tuned for a birt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336836768252977152",
    "text" : "It's our one-year anniversary today! So thankful to community that comes, sits, chats, and cranks. Stay tuned for a birthday party invite.",
    "id" : 336836768252977152,
    "created_at" : "2013-05-21 13:31:58 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 336837591267680256,
  "created_at" : "2013-05-21 13:35:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 11, 25 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336835357335240705",
  "text" : "It\u2019s 5\/21. @coworkbuffalo turns one year old today. Thanks to everyone who\u2019s supported us. We waited for no one, shipped it, made it real.",
  "id" : 336835357335240705,
  "created_at" : "2013-05-21 13:26:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 0, 10 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336823121006968833",
  "geo" : { },
  "id_str" : "336826470712373248",
  "in_reply_to_user_id" : 7826502,
  "text" : "@drbarnard ah, so after using the project menu (that lets you switch sections), it feels like a vertical move, not horizontal. Fair point.",
  "id" : 336826470712373248,
  "in_reply_to_status_id" : 336823121006968833,
  "created_at" : "2013-05-21 12:51:03 +0000",
  "in_reply_to_screen_name" : "drbarnard",
  "in_reply_to_user_id_str" : "7826502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 0, 10 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336823478772695040",
  "geo" : { },
  "id_str" : "336825653926191104",
  "in_reply_to_user_id" : 7826502,
  "text" : "@drbarnard ah, on a discussion? Yeah that is awkward.",
  "id" : 336825653926191104,
  "in_reply_to_status_id" : 336823478772695040,
  "created_at" : "2013-05-21 12:47:48 +0000",
  "in_reply_to_screen_name" : "drbarnard",
  "in_reply_to_user_id_str" : "7826502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 0, 10 ],
      "id_str" : "7826502",
      "id" : 7826502
    }, {
      "name" : "Ryan Cash",
      "screen_name" : "ryanacash",
      "indices" : [ 11, 21 ],
      "id_str" : "27816366",
      "id" : 27816366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336824449829593088",
  "geo" : { },
  "id_str" : "336824818555047936",
  "in_reply_to_user_id" : 7826502,
  "text" : "@drbarnard @ryanacash working on that for this upcoming release.",
  "id" : 336824818555047936,
  "in_reply_to_status_id" : 336824449829593088,
  "created_at" : "2013-05-21 12:44:29 +0000",
  "in_reply_to_screen_name" : "drbarnard",
  "in_reply_to_user_id_str" : "7826502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cash",
      "screen_name" : "ryanacash",
      "indices" : [ 0, 10 ],
      "id_str" : "27816366",
      "id" : 27816366
    }, {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 11, 21 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336707766129401856",
  "geo" : { },
  "id_str" : "336708020367147008",
  "in_reply_to_user_id" : 27816366,
  "text" : "@ryanacash @drbarnard FWIW we hear a lot of \u201Chey this feels all native and super fast!\u201D a lot too. Just curious to see what feels awkward.",
  "id" : 336708020367147008,
  "in_reply_to_status_id" : 336707766129401856,
  "created_at" : "2013-05-21 05:00:22 +0000",
  "in_reply_to_screen_name" : "ryanacash",
  "in_reply_to_user_id_str" : "27816366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cash",
      "screen_name" : "ryanacash",
      "indices" : [ 0, 10 ],
      "id_str" : "27816366",
      "id" : 27816366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336706277222780930",
  "geo" : { },
  "id_str" : "336707444417904640",
  "in_reply_to_user_id" : 27816366,
  "text" : "@ryanacash the docs need a lot of improvement on both sides right now. Right with you that it\u2019s not feature matched though.",
  "id" : 336707444417904640,
  "in_reply_to_status_id" : 336706277222780930,
  "created_at" : "2013-05-21 04:58:05 +0000",
  "in_reply_to_screen_name" : "ryanacash",
  "in_reply_to_user_id_str" : "27816366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cash",
      "screen_name" : "ryanacash",
      "indices" : [ 0, 10 ],
      "id_str" : "27816366",
      "id" : 27816366
    }, {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 11, 21 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336706512410005504",
  "geo" : { },
  "id_str" : "336706849543954433",
  "in_reply_to_user_id" : 27816366,
  "text" : "@ryanacash @drbarnard the navigation is all native\u2026the content is web. Page stacking not feeling right maybe?",
  "id" : 336706849543954433,
  "in_reply_to_status_id" : 336706512410005504,
  "created_at" : "2013-05-21 04:55:43 +0000",
  "in_reply_to_screen_name" : "ryanacash",
  "in_reply_to_user_id_str" : "27816366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cash",
      "screen_name" : "ryanacash",
      "indices" : [ 0, 10 ],
      "id_str" : "27816366",
      "id" : 27816366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335072871816761344",
  "geo" : { },
  "id_str" : "336705701927870464",
  "in_reply_to_user_id" : 27816366,
  "text" : "@ryanacash hey! Just saw this. I\u2019m curious about what you had trouble getting to in the app.",
  "id" : 336705701927870464,
  "in_reply_to_status_id" : 335072871816761344,
  "created_at" : "2013-05-21 04:51:09 +0000",
  "in_reply_to_screen_name" : "ryanacash",
  "in_reply_to_user_id_str" : "27816366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Barnard",
      "screen_name" : "drbarnard",
      "indices" : [ 0, 10 ],
      "id_str" : "7826502",
      "id" : 7826502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335063720814329856",
  "geo" : { },
  "id_str" : "336705515495239680",
  "in_reply_to_user_id" : 7826502,
  "text" : "@drbarnard just saw this. We\u2019re working on the connectivity issues. What\u2019s hard to navigate to?",
  "id" : 336705515495239680,
  "in_reply_to_status_id" : 335063720814329856,
  "created_at" : "2013-05-21 04:50:25 +0000",
  "in_reply_to_screen_name" : "drbarnard",
  "in_reply_to_user_id_str" : "7826502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 0, 11 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336701323854614530",
  "geo" : { },
  "id_str" : "336705083469361153",
  "in_reply_to_user_id" : 5539522,
  "text" : "@AskedRelic I wish it was this easy.",
  "id" : 336705083469361153,
  "in_reply_to_status_id" : 336701323854614530,
  "created_at" : "2013-05-21 04:48:42 +0000",
  "in_reply_to_screen_name" : "AskedRelic",
  "in_reply_to_user_id_str" : "5539522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "indices" : [ 3, 14 ],
      "id_str" : "5539522",
      "id" : 5539522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/yg0OQlno9z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LakMmxg_sQg",
      "display_url" : "youtube.com\/watch?v=LakMmx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336705034781868034",
  "text" : "RT @AskedRelic: Japan is amazing http:\/\/t.co\/yg0OQlno9z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/yg0OQlno9z",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LakMmxg_sQg",
        "display_url" : "youtube.com\/watch?v=LakMmx\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336701323854614530",
    "text" : "Japan is amazing http:\/\/t.co\/yg0OQlno9z",
    "id" : 336701323854614530,
    "created_at" : "2013-05-21 04:33:45 +0000",
    "user" : {
      "name" : "Matt Behrens",
      "screen_name" : "AskedRelic",
      "protected" : false,
      "id_str" : "5539522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1772443295\/photo_normal.jpeg",
      "id" : 5539522,
      "verified" : false
    }
  },
  "id" : 336705034781868034,
  "created_at" : "2013-05-21 04:48:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Baglieri",
      "screen_name" : "chrisbaglieri",
      "indices" : [ 0, 14 ],
      "id_str" : "12462452",
      "id" : 12462452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336691954207293440",
  "geo" : { },
  "id_str" : "336693540455317504",
  "in_reply_to_user_id" : 12462452,
  "text" : "@chrisbaglieri getting downvoted for it too! \/play trombone",
  "id" : 336693540455317504,
  "in_reply_to_status_id" : 336691954207293440,
  "created_at" : "2013-05-21 04:02:50 +0000",
  "in_reply_to_screen_name" : "chrisbaglieri",
  "in_reply_to_user_id_str" : "12462452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336692556920389632",
  "geo" : { },
  "id_str" : "336692864203513857",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal alias is so fucking confusing.",
  "id" : 336692864203513857,
  "in_reply_to_status_id" : 336692556920389632,
  "created_at" : "2013-05-21 04:00:08 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GKm5dGyKSJ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/ruby\/comments\/1eqond\/my_first_ruby_game_what_did_i_do_rightwrong\/ca2tf1a",
      "display_url" : "reddit.com\/r\/ruby\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336691438974812161",
  "text" : "I love giving feedback like this. Also looking at 5 year old code of my own is terrifying. http:\/\/t.co\/GKm5dGyKSJ",
  "id" : 336691438974812161,
  "created_at" : "2013-05-21 03:54:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 30, 37 ],
      "id_str" : "17471979",
      "id" : 17471979
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 67, 79 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/efxu439oUM",
      "expanded_url" : "http:\/\/natgeofound.tumblr.com\/post\/48203648267\/a-replica-of-the-mayflower-sails-into-new-york",
      "display_url" : "natgeofound.tumblr.com\/post\/482036482\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336679698690080768",
  "text" : "Absolutely unreal photos from @NatGeo: http:\/\/t.co\/efxu439oUM (via @fredyatesiv)",
  "id" : 336679698690080768,
  "created_at" : "2013-05-21 03:07:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336654340485947392",
  "text" : "I knew that could be a sound of the future.",
  "id" : 336654340485947392,
  "created_at" : "2013-05-21 01:27:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/opFub1FT1R",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/",
      "display_url" : "flickr.com\/photos\/qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "336594541568200705",
  "text" : "Flickr profile redesign is gorgeous. Still happy I dumped Instagram and CC licensed my photos. http:\/\/t.co\/opFub1FT1R",
  "id" : 336594541568200705,
  "created_at" : "2013-05-20 21:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 11, 21 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336593412516085761",
  "geo" : { },
  "id_str" : "336594361963913216",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel @theediguy Our space is a cool 72\u00BA right now.",
  "id" : 336594361963913216,
  "in_reply_to_status_id" : 336593412516085761,
  "created_at" : "2013-05-20 21:28:44 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Thompson",
      "screen_name" : "kevinthompson",
      "indices" : [ 0, 14 ],
      "id_str" : "14372471",
      "id" : 14372471
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 15, 20 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336584220984102913",
  "geo" : { },
  "id_str" : "336584896724217856",
  "in_reply_to_user_id" : 14372471,
  "text" : "@kevinthompson @avdi This sounds like a cry from people missing Hungarian notation and IDEs. Move on.",
  "id" : 336584896724217856,
  "in_reply_to_status_id" : 336584220984102913,
  "created_at" : "2013-05-20 20:51:07 +0000",
  "in_reply_to_screen_name" : "kevinthompson",
  "in_reply_to_user_id_str" : "14372471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Thompson",
      "screen_name" : "kevinthompson",
      "indices" : [ 0, 14 ],
      "id_str" : "14372471",
      "id" : 14372471
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 15, 20 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336582156325367810",
  "geo" : { },
  "id_str" : "336584102063005696",
  "in_reply_to_user_id" : 14372471,
  "text" : "@kevinthompson @avdi I don't think I have seen any private methods start with a _ in any Ruby code I've read in 5 years.",
  "id" : 336584102063005696,
  "in_reply_to_status_id" : 336582156325367810,
  "created_at" : "2013-05-20 20:47:58 +0000",
  "in_reply_to_screen_name" : "kevinthompson",
  "in_reply_to_user_id_str" : "14372471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 3, 9 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336580576452689920",
  "text" : "RT @dozba: I'm trying Ruby... and I *like* it. This is scary stuff, people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336580319480254465",
    "text" : "I'm trying Ruby... and I *like* it. This is scary stuff, people.",
    "id" : 336580319480254465,
    "created_at" : "2013-05-20 20:32:56 +0000",
    "user" : {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "protected" : false,
      "id_str" : "44282335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537809944037191681\/kPC8Noli_normal.jpeg",
      "id" : 44282335,
      "verified" : false
    }
  },
  "id" : 336580576452689920,
  "created_at" : "2013-05-20 20:33:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndon Buckley",
      "screen_name" : "LyndonBuckley",
      "indices" : [ 0, 14 ],
      "id_str" : "384481702",
      "id" : 384481702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/x10A7Nl8TK",
      "expanded_url" : "https:\/\/github.com\/37signals\/bcx-api#authentication",
      "display_url" : "github.com\/37signals\/bcx-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336301545459167233",
  "geo" : { },
  "id_str" : "336305858789142528",
  "in_reply_to_user_id" : 384481702,
  "text" : "@LyndonBuckley there are no API keys. Check out https:\/\/t.co\/x10A7Nl8TK",
  "id" : 336305858789142528,
  "in_reply_to_status_id" : 336301545459167233,
  "created_at" : "2013-05-20 02:22:19 +0000",
  "in_reply_to_screen_name" : "LyndonBuckley",
  "in_reply_to_user_id_str" : "384481702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Ward",
      "screen_name" : "coreyward",
      "indices" : [ 0, 10 ],
      "id_str" : "9648292",
      "id" : 9648292
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 88, 98 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336185315431690240",
  "geo" : { },
  "id_str" : "336305318462095362",
  "in_reply_to_user_id" : 9648292,
  "text" : "@coreyward it\u2019s just stable. Have you tried it? We use it every day for all of our apps @37signals",
  "id" : 336305318462095362,
  "in_reply_to_status_id" : 336185315431690240,
  "created_at" : "2013-05-20 02:20:10 +0000",
  "in_reply_to_screen_name" : "coreyward",
  "in_reply_to_user_id_str" : "9648292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336162877134213121",
  "text" : "My guess is 2 years for Tumblr to get shuttered. One year to get renamed into Yahoo! Tumbles",
  "id" : 336162877134213121,
  "created_at" : "2013-05-19 16:54:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336151908446244865",
  "geo" : { },
  "id_str" : "336155391253700608",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine nope, not us, we\u2019re ok. Thanks though.",
  "id" : 336155391253700608,
  "in_reply_to_status_id" : 336151908446244865,
  "created_at" : "2013-05-19 16:24:25 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336118217779077120",
  "text" : "Not sure if sad or amazed that hospital wifi is blazing fast.",
  "id" : 336118217779077120,
  "created_at" : "2013-05-19 13:56:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 0, 7 ],
      "id_str" : "15964196",
      "id" : 15964196
    }, {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 8, 23 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335995339624566786",
  "geo" : { },
  "id_str" : "336117908361064450",
  "in_reply_to_user_id" : 15964196,
  "text" : "@ckanal @colindabkowski this is pathetic.",
  "id" : 336117908361064450,
  "in_reply_to_status_id" : 335995339624566786,
  "created_at" : "2013-05-19 13:55:28 +0000",
  "in_reply_to_screen_name" : "ckanal",
  "in_reply_to_user_id_str" : "15964196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason madsen",
      "screen_name" : "jason_madsen",
      "indices" : [ 0, 13 ],
      "id_str" : "20523707",
      "id" : 20523707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335879294045806592",
  "geo" : { },
  "id_str" : "335890687868424192",
  "in_reply_to_user_id" : 20523707,
  "text" : "@jason_madsen we are not down or pingdom would be screaming at me. sounds like a DNS problem on your end",
  "id" : 335890687868424192,
  "in_reply_to_status_id" : 335879294045806592,
  "created_at" : "2013-05-18 22:52:35 +0000",
  "in_reply_to_screen_name" : "jason_madsen",
  "in_reply_to_user_id_str" : "20523707",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/aYOtZpMZNn",
      "expanded_url" : "http:\/\/flic.kr\/p\/ekjVDw",
      "display_url" : "flic.kr\/p\/ekjVDw"
    } ]
  },
  "geo" : { },
  "id_str" : "335812368552558592",
  "text" : "The Cotter http:\/\/t.co\/aYOtZpMZNn",
  "id" : 335812368552558592,
  "created_at" : "2013-05-18 17:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Silber",
      "screen_name" : "wifelette",
      "indices" : [ 0, 10 ],
      "id_str" : "11320942",
      "id" : 11320942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335760697596198912",
  "geo" : { },
  "id_str" : "335772523323092992",
  "in_reply_to_user_id" : 11320942,
  "text" : "@wifelette sadface",
  "id" : 335772523323092992,
  "in_reply_to_status_id" : 335760697596198912,
  "created_at" : "2013-05-18 15:03:02 +0000",
  "in_reply_to_screen_name" : "wifelette",
  "in_reply_to_user_id_str" : "11320942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Silber",
      "screen_name" : "wifelette",
      "indices" : [ 0, 10 ],
      "id_str" : "11320942",
      "id" : 11320942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335760697596198912",
  "geo" : { },
  "id_str" : "335761539367841792",
  "in_reply_to_user_id" : 11320942,
  "text" : "@wifelette \/play trombone",
  "id" : 335761539367841792,
  "in_reply_to_status_id" : 335760697596198912,
  "created_at" : "2013-05-18 14:19:23 +0000",
  "in_reply_to_screen_name" : "wifelette",
  "in_reply_to_user_id_str" : "11320942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Silber",
      "screen_name" : "wifelette",
      "indices" : [ 0, 10 ],
      "id_str" : "11320942",
      "id" : 11320942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335738569605914624",
  "geo" : { },
  "id_str" : "335749783199289344",
  "in_reply_to_user_id" : 11320942,
  "text" : "@wifelette you guys are way too close. How long are you in Toronto for? Should visit the Falls\u2026or here! ;)",
  "id" : 335749783199289344,
  "in_reply_to_status_id" : 335738569605914624,
  "created_at" : "2013-05-18 13:32:40 +0000",
  "in_reply_to_screen_name" : "wifelette",
  "in_reply_to_user_id_str" : "11320942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Godin",
      "screen_name" : "ThisIsSethsBlog",
      "indices" : [ 3, 19 ],
      "id_str" : "17825445",
      "id" : 17825445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aCA8SfFeaI",
      "expanded_url" : "http:\/\/bit.ly\/16oYjlw",
      "display_url" : "bit.ly\/16oYjlw"
    } ]
  },
  "geo" : { },
  "id_str" : "335624347228180480",
  "text" : "RT @ThisIsSethsBlog: Every day is an investment: You're not lucky to have this job, they're lucky to have you. Every day, you inves... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/aCA8SfFeaI",
        "expanded_url" : "http:\/\/bit.ly\/16oYjlw",
        "display_url" : "bit.ly\/16oYjlw"
      } ]
    },
    "geo" : { },
    "id_str" : "335623426003836928",
    "text" : "Every day is an investment: You're not lucky to have this job, they're lucky to have you. Every day, you inves... http:\/\/t.co\/aCA8SfFeaI",
    "id" : 335623426003836928,
    "created_at" : "2013-05-18 05:10:34 +0000",
    "user" : {
      "name" : "Seth Godin",
      "screen_name" : "ThisIsSethsBlog",
      "protected" : false,
      "id_str" : "17825445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67490765\/bloghead_normal.jpg",
      "id" : 17825445,
      "verified" : true
    }
  },
  "id" : 335624347228180480,
  "created_at" : "2013-05-18 05:14:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 33, 42 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spaceweather",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335619164838432768",
  "geo" : { },
  "id_str" : "335619317704032257",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg #spaceweather !! \/cc @bquarant",
  "id" : 335619317704032257,
  "in_reply_to_status_id" : 335619164838432768,
  "created_at" : "2013-05-18 04:54:15 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Tsujimoto",
      "screen_name" : "Tsuj10",
      "indices" : [ 0, 7 ],
      "id_str" : "61690399",
      "id" : 61690399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335618492210495488",
  "geo" : { },
  "id_str" : "335619053907505152",
  "in_reply_to_user_id" : 61690399,
  "text" : "@Tsuj10 sting on what? Bar? DUI?",
  "id" : 335619053907505152,
  "in_reply_to_status_id" : 335618492210495488,
  "created_at" : "2013-05-18 04:53:12 +0000",
  "in_reply_to_screen_name" : "Tsuj10",
  "in_reply_to_user_id_str" : "61690399",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trending Buffalo",
      "screen_name" : "TrendingBuffalo",
      "indices" : [ 3, 19 ],
      "id_str" : "519717958",
      "id" : 519717958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/w0mBJp8Mgf",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "335596026176086016",
  "text" : "RT @TrendingBuffalo: By the way... you might want to bookmark this is a pretty awesome \"Buffalo food truck tracker\" page. http:\/\/t.co\/w0mBJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/w0mBJp8Mgf",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
        "display_url" : "coworkbuffalo.com\/food\/"
      } ]
    },
    "geo" : { },
    "id_str" : "335420651252891648",
    "text" : "By the way... you might want to bookmark this is a pretty awesome \"Buffalo food truck tracker\" page. http:\/\/t.co\/w0mBJp8Mgf",
    "id" : 335420651252891648,
    "created_at" : "2013-05-17 15:44:49 +0000",
    "user" : {
      "name" : "Trending Buffalo",
      "screen_name" : "TrendingBuffalo",
      "protected" : false,
      "id_str" : "519717958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3086392748\/af09c3aec0c906764bed3f02b501dd6c_normal.jpeg",
      "id" : 519717958,
      "verified" : false
    }
  },
  "id" : 335596026176086016,
  "created_at" : "2013-05-18 03:21:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 0, 10 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335486996652888064",
  "geo" : { },
  "id_str" : "335595996132302848",
  "in_reply_to_user_id" : 250785234,
  "text" : "@Mechaphil @ExitMusicCory I'd love to, but just getting the trucks to tweet is hard enough :(",
  "id" : 335595996132302848,
  "in_reply_to_status_id" : 335486996652888064,
  "created_at" : "2013-05-18 03:21:35 +0000",
  "in_reply_to_screen_name" : "Mechaphil",
  "in_reply_to_user_id_str" : "250785234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/7JNwVtSABj",
      "expanded_url" : "http:\/\/magicalgametime.com\/post\/48470399171",
      "display_url" : "magicalgametime.com\/post\/484703991\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335594870137823232",
  "text" : "\"This is no gift\" http:\/\/t.co\/7JNwVtSABj",
  "id" : 335594870137823232,
  "created_at" : "2013-05-18 03:17:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335557921616326656",
  "geo" : { },
  "id_str" : "335558095197573120",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk animated too.",
  "id" : 335558095197573120,
  "in_reply_to_status_id" : 335557921616326656,
  "created_at" : "2013-05-18 00:50:58 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335557118591655936\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/9muETIA2H9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKgja-fCYAAnDtH.png",
      "id_str" : "335557118595850240",
      "id" : 335557118595850240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKgja-fCYAAnDtH.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/9muETIA2H9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335557118591655936",
  "text" : "Pusheen in Facebook chat? Emoji are OVER http:\/\/t.co\/9muETIA2H9",
  "id" : 335557118591655936,
  "created_at" : "2013-05-18 00:47:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pedro Lobo",
      "screen_name" : "pslobo",
      "indices" : [ 0, 7 ],
      "id_str" : "104788039",
      "id" : 104788039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335555455000670209",
  "geo" : { },
  "id_str" : "335556997275590656",
  "in_reply_to_user_id" : 104788039,
  "text" : "@pslobo cool, I\u2019ll have to play with it. Glad that hack works at least :)",
  "id" : 335556997275590656,
  "in_reply_to_status_id" : 335555455000670209,
  "created_at" : "2013-05-18 00:46:37 +0000",
  "in_reply_to_screen_name" : "pslobo",
  "in_reply_to_user_id_str" : "104788039",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pedro Lobo",
      "screen_name" : "pslobo",
      "indices" : [ 0, 7 ],
      "id_str" : "104788039",
      "id" : 104788039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335455816977108992",
  "geo" : { },
  "id_str" : "335544214739898369",
  "in_reply_to_user_id" : 104788039,
  "text" : "@pslobo hey, there isn\u2019t one yet. I\u2019m curious: what were you trying to open\/do?",
  "id" : 335544214739898369,
  "in_reply_to_status_id" : 335455816977108992,
  "created_at" : "2013-05-17 23:55:49 +0000",
  "in_reply_to_screen_name" : "pslobo",
  "in_reply_to_user_id_str" : "104788039",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335498111776608258",
  "text" : "Current status: ((((((((nnnnuuuullllllll))))))))&gt;&gt;&gt;&gt;[[[11111111GGGGrake aborted!",
  "id" : 335498111776608258,
  "created_at" : "2013-05-17 20:52:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335496959521603584",
  "text" : "git checkout -p, or, git checkout --remove-expletives-from-code-before-committing",
  "id" : 335496959521603584,
  "created_at" : "2013-05-17 20:48:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 0, 8 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 40, 51 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335418551722733568",
  "geo" : { },
  "id_str" : "335419437240950784",
  "in_reply_to_user_id" : 16476741,
  "text" : "@merbist our guess is that it's rubber. @kevinpurdy thinks it might be lithograph stamping plates.",
  "id" : 335419437240950784,
  "in_reply_to_status_id" : 335418551722733568,
  "created_at" : "2013-05-17 15:40:00 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335405609040109568\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3x0IJZN5nS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeZn9bCYAQ9IU0.jpg",
      "id_str" : "335405609044303876",
      "id" : 335405609044303876,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeZn9bCYAQ9IU0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/3x0IJZN5nS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335405609040109568",
  "text" : "10\/10\/47: $50K brooch stolen in Chicago. http:\/\/t.co\/3x0IJZN5nS",
  "id" : 335405609040109568,
  "created_at" : "2013-05-17 14:45:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335404502133923840\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/6LqB3XVT4G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeYnh4CYAI3T7-.jpg",
      "id_str" : "335404502138118146",
      "id" : 335404502138118146,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeYnh4CYAI3T7-.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/6LqB3XVT4G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335404502133923840",
  "text" : "12\/13\/47: New Jersey Insists Hotel Put Ropes in Rooms http:\/\/t.co\/6LqB3XVT4G",
  "id" : 335404502133923840,
  "created_at" : "2013-05-17 14:40:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/xBNtShjuj4",
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335404082028232705\/photo\/1",
      "display_url" : "pic.twitter.com\/xBNtShjuj4"
    } ]
  },
  "geo" : { },
  "id_str" : "335404148981915648",
  "text" : "12\/13\/46: Couple Starts Fire In Wild Dash To One http:\/\/t.co\/xBNtShjuj4",
  "id" : 335404148981915648,
  "created_at" : "2013-05-17 14:39:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335402471092535296\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/p7qj1JafAO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeWxTqCQAE8lmk.jpg",
      "id_str" : "335402471096729601",
      "id" : 335402471096729601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeWxTqCQAE8lmk.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/p7qj1JafAO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335402471092535296",
  "text" : "Some ridiculous stories - 9\/30\/47: \u201CUses Gun to Keep Boys Quiet\u201D http:\/\/t.co\/p7qj1JafAO",
  "id" : 335402471092535296,
  "created_at" : "2013-05-17 14:32:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335401355499933697\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/k0vOwwJzjW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeVwXxCEAIvpBW.jpg",
      "id_str" : "335401355508322306",
      "id" : 335401355508322306,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeVwXxCEAIvpBW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/k0vOwwJzjW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335401355499933697",
  "text" : "Hard to make out straight on but the photo impressions are very visible. Snow making headlines in the 40s too! http:\/\/t.co\/k0vOwwJzjW",
  "id" : 335401355499933697,
  "created_at" : "2013-05-17 14:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Campbell",
      "screen_name" : "justincampbell",
      "indices" : [ 0, 15 ],
      "id_str" : "7387992",
      "id" : 7387992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335400414595915776",
  "geo" : { },
  "id_str" : "335401023332032513",
  "in_reply_to_user_id" : 7387992,
  "text" : "@justincampbell it feels like a stamp. Not paper since ink is still on it (from 1946!!)",
  "id" : 335401023332032513,
  "in_reply_to_status_id" : 335400414595915776,
  "created_at" : "2013-05-17 14:26:50 +0000",
  "in_reply_to_screen_name" : "justincampbell",
  "in_reply_to_user_id_str" : "7387992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335400746931597312\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/XIJcGcWPI4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeVM8rCMAItgWU.jpg",
      "id_str" : "335400746939985922",
      "id" : 335400746939985922,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeVM8rCMAItgWU.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/XIJcGcWPI4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335400746931597312",
  "text" : "Up close you can see how the stamps were aligned and even some spacer markings. http:\/\/t.co\/XIJcGcWPI4",
  "id" : 335400746931597312,
  "created_at" : "2013-05-17 14:25:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/335400405397815296\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/tqrXImHvnx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKeU5EWCQAI35Nt.jpg",
      "id_str" : "335400405402009602",
      "id" : 335400405402009602,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKeU5EWCQAI35Nt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tqrXImHvnx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335400405397815296",
  "text" : "Some cool details from these, actual box score from a Yankees\/Dodgers World Series http:\/\/t.co\/tqrXImHvnx",
  "id" : 335400405397815296,
  "created_at" : "2013-05-17 14:24:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 84, 98 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/pqEyrw0MIq",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjF7mQEk",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjF7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335400160974757888",
  "text" : "Found some Buffalo Evening News stamps (?) at a yard sale from 1946-47. Going up at @coworkbuffalo soon! http:\/\/t.co\/pqEyrw0MIq",
  "id" : 335400160974757888,
  "created_at" : "2013-05-17 14:23:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335242508143575040",
  "text" : "Le Havre is only 99\u00A2 on the App Store right now. I wouldn\u2019t try to learn how to play via the app, but worth picking up for so cheap.",
  "id" : 335242508143575040,
  "created_at" : "2013-05-17 03:56:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335219474779238401",
  "geo" : { },
  "id_str" : "335220248728965120",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis I got Gathering Storm for my friend who owns it and it's well worth it. adds lots of good cards, Catan-like Longest Road achievements",
  "id" : 335220248728965120,
  "in_reply_to_status_id" : 335219474779238401,
  "created_at" : "2013-05-17 02:28:30 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indyK1ng",
      "screen_name" : "indyK1ng",
      "indices" : [ 0, 9 ],
      "id_str" : "18765238",
      "id" : 18765238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335219612042010626",
  "geo" : { },
  "id_str" : "335219997968302080",
  "in_reply_to_user_id" : 18765238,
  "text" : "@indyK1ng EVERYTHING",
  "id" : 335219997968302080,
  "in_reply_to_status_id" : 335219612042010626,
  "created_at" : "2013-05-17 02:27:30 +0000",
  "in_reply_to_screen_name" : "indyK1ng",
  "in_reply_to_user_id_str" : "18765238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335218702008078336",
  "geo" : { },
  "id_str" : "335219221288075266",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis gets even worse with the xpacs too :( but the game's strategy depth and balance makes up for it. Took a while to ditch the help card.",
  "id" : 335219221288075266,
  "in_reply_to_status_id" : 335218702008078336,
  "created_at" : "2013-05-17 02:24:25 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/sRGKoHP6UG",
      "expanded_url" : "http:\/\/i.imgur.com\/Bk6OQF3.gif",
      "display_url" : "i.imgur.com\/Bk6OQF3.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "335218747973464065",
  "text" : "Star Trek was http:\/\/t.co\/sRGKoHP6UG I wanted.",
  "id" : 335218747973464065,
  "created_at" : "2013-05-17 02:22:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 84, 98 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335215060609822720",
  "geo" : { },
  "id_str" : "335215319079587842",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis it\u2019s overwhelming at first but so worth it. Have literally spent every lunch @coworkbuffalo this week playing :)",
  "id" : 335215319079587842,
  "in_reply_to_status_id" : 335215060609822720,
  "created_at" : "2013-05-17 02:08:54 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335178217881206785",
  "geo" : { },
  "id_str" : "335211640322666497",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda it has to be.",
  "id" : 335211640322666497,
  "in_reply_to_status_id" : 335178217881206785,
  "created_at" : "2013-05-17 01:54:17 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335178033977765889",
  "text" : "There\u2019s seriously a feature length film about being an intern at Google with Vince Vaughn and Owen Wilson. Wat?",
  "id" : 335178033977765889,
  "created_at" : "2013-05-16 23:40:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "335121514808623104",
  "text" : "RT @nickelcityruby: Tickets are still available for NickelCityRuby! We want to see you in BUF this Sept 20-21st! Register here: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "335075399077871617",
    "text" : "Tickets are still available for NickelCityRuby! We want to see you in BUF this Sept 20-21st! Register here: http:\/\/t.co\/U1fBUeQnGv",
    "id" : 335075399077871617,
    "created_at" : "2013-05-16 16:52:55 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 335121514808623104,
  "created_at" : "2013-05-16 19:56:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 54, 68 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335101010227892224",
  "geo" : { },
  "id_str" : "335105338862882816",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench There is one more Buffalo Kolsch left at @coworkbuffalo if you want it.",
  "id" : 335105338862882816,
  "in_reply_to_status_id" : 335101010227892224,
  "created_at" : "2013-05-16 18:51:53 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/i7VT1rIMYf",
      "expanded_url" : "http:\/\/jezebel.com\/5960255\/how-to-have-the-best-pregnancy-ever",
      "display_url" : "jezebel.com\/5960255\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335097926583975936",
  "text" : "RT @aquaranto: If I haven't said it before, this article is my whole life: http:\/\/t.co\/i7VT1rIMYf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/i7VT1rIMYf",
        "expanded_url" : "http:\/\/jezebel.com\/5960255\/how-to-have-the-best-pregnancy-ever",
        "display_url" : "jezebel.com\/5960255\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335097590045614081",
    "text" : "If I haven't said it before, this article is my whole life: http:\/\/t.co\/i7VT1rIMYf",
    "id" : 335097590045614081,
    "created_at" : "2013-05-16 18:21:05 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 335097926583975936,
  "created_at" : "2013-05-16 18:22:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335089356291334144",
  "geo" : { },
  "id_str" : "335090075941609472",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier It's a truck!",
  "id" : 335090075941609472,
  "in_reply_to_status_id" : 335089356291334144,
  "created_at" : "2013-05-16 17:51:14 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335087250847178752",
  "geo" : { },
  "id_str" : "335088067192975361",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Spaceweather truck.",
  "id" : 335088067192975361,
  "in_reply_to_status_id" : 335087250847178752,
  "created_at" : "2013-05-16 17:43:15 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335085739018711040",
  "text" : "Just hear me out on this one. Ready?\n\nSnuggle truck.",
  "id" : 335085739018711040,
  "created_at" : "2013-05-16 17:34:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 3, 16 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335059907856445441",
  "text" : "RT @TheOtherZach: So, @coworkbuffalo is an amazing space. Stop by sometime if you're ever in town.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 4, 18 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335055357628018688",
    "text" : "So, @coworkbuffalo is an amazing space. Stop by sometime if you're ever in town.",
    "id" : 335055357628018688,
    "created_at" : "2013-05-16 15:33:16 +0000",
    "user" : {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "protected" : false,
      "id_str" : "29200620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427580633745854465\/Oo8wowKC_normal.png",
      "id" : 29200620,
      "verified" : false
    }
  },
  "id" : 335059907856445441,
  "created_at" : "2013-05-16 15:51:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_Zach McArtor",
      "screen_name" : "zmcartor",
      "indices" : [ 0, 9 ],
      "id_str" : "19977631",
      "id" : 19977631
    }, {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 10, 23 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335059025739804673",
  "geo" : { },
  "id_str" : "335059892622737408",
  "in_reply_to_user_id" : 19977631,
  "text" : "@zmcartor @TheOtherZach thanks! :D",
  "id" : 335059892622737408,
  "in_reply_to_status_id" : 335059025739804673,
  "created_at" : "2013-05-16 15:51:18 +0000",
  "in_reply_to_screen_name" : "zmcartor",
  "in_reply_to_user_id_str" : "19977631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/92KbX9sP0c",
      "expanded_url" : "http:\/\/fb.me\/2rlZZhkoT",
      "display_url" : "fb.me\/2rlZZhkoT"
    } ]
  },
  "geo" : { },
  "id_str" : "335035570826915840",
  "text" : "RT @UnclePhilsBlog: AQuaintances! Tonight Aqueous makes their debut at the revered and renowned Middle East Restaurant and Nightclub... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/92KbX9sP0c",
        "expanded_url" : "http:\/\/fb.me\/2rlZZhkoT",
        "display_url" : "fb.me\/2rlZZhkoT"
      } ]
    },
    "geo" : { },
    "id_str" : "335035112393670657",
    "text" : "AQuaintances! Tonight Aqueous makes their debut at the revered and renowned Middle East Restaurant and Nightclub... http:\/\/t.co\/92KbX9sP0c",
    "id" : 335035112393670657,
    "created_at" : "2013-05-16 14:12:50 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 335035570826915840,
  "created_at" : "2013-05-16 14:14:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/SuNfOuBOgN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ch5MEJk5ZCQ",
      "display_url" : "youtube.com\/watch?v=Ch5MEJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334990547234193408",
  "text" : "RT @codinghorror: True Facts about Morgan Freeman http:\/\/t.co\/SuNfOuBOgN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/SuNfOuBOgN",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ch5MEJk5ZCQ",
        "display_url" : "youtube.com\/watch?v=Ch5MEJ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334966173194149888",
    "text" : "True Facts about Morgan Freeman http:\/\/t.co\/SuNfOuBOgN",
    "id" : 334966173194149888,
    "created_at" : "2013-05-16 09:38:53 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2052442590\/coding-horror-official-logo-medium_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 334990547234193408,
  "created_at" : "2013-05-16 11:15:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L u k e O' N e i l",
      "screen_name" : "lukeoneil47",
      "indices" : [ 0, 12 ],
      "id_str" : "108338399",
      "id" : 108338399
    }, {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 13, 19 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334883932782870529",
  "geo" : { },
  "id_str" : "334888469363060736",
  "in_reply_to_user_id" : 108338399,
  "text" : "@lukeoneil47 @vrunt I was almost expecting a Top 5 Lawnmowing Tips segway",
  "id" : 334888469363060736,
  "in_reply_to_status_id" : 334883932782870529,
  "created_at" : "2013-05-16 04:30:07 +0000",
  "in_reply_to_screen_name" : "lukeoneil47",
  "in_reply_to_user_id_str" : "108338399",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 0, 5 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334876728797298690",
  "geo" : { },
  "id_str" : "334877186840465408",
  "in_reply_to_user_id" : 18713,
  "text" : "@al3x what show is this?",
  "id" : 334877186840465408,
  "in_reply_to_status_id" : 334876728797298690,
  "created_at" : "2013-05-16 03:45:17 +0000",
  "in_reply_to_screen_name" : "al3x",
  "in_reply_to_user_id_str" : "18713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugen",
      "screen_name" : "tensil",
      "indices" : [ 0, 7 ],
      "id_str" : "34671289",
      "id" : 34671289
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 26, 34 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334609588747923457",
  "geo" : { },
  "id_str" : "334874228732084226",
  "in_reply_to_user_id" : 34671289,
  "text" : "@tensil what? How so? \/cc @evanphx",
  "id" : 334874228732084226,
  "in_reply_to_status_id" : 334609588747923457,
  "created_at" : "2013-05-16 03:33:32 +0000",
  "in_reply_to_screen_name" : "tensil",
  "in_reply_to_user_id_str" : "34671289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Barone",
      "screen_name" : "buffalofoodie",
      "indices" : [ 0, 14 ],
      "id_str" : "190038945",
      "id" : 190038945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334825607047294976",
  "geo" : { },
  "id_str" : "334825973558173697",
  "in_reply_to_user_id" : 190038945,
  "text" : "@buffalofoodie daaang ! how late are they open?",
  "id" : 334825973558173697,
  "in_reply_to_status_id" : 334825607047294976,
  "created_at" : "2013-05-16 00:21:47 +0000",
  "in_reply_to_screen_name" : "buffalofoodie",
  "in_reply_to_user_id_str" : "190038945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334824993697431552",
  "geo" : { },
  "id_str" : "334825256332165120",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting well Buffalo is just upstate, duh",
  "id" : 334825256332165120,
  "in_reply_to_status_id" : 334824993697431552,
  "created_at" : "2013-05-16 00:18:56 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/I1UCdUDRq5",
      "expanded_url" : "https:\/\/github.com\/aaronsw",
      "display_url" : "github.com\/aaronsw"
    } ]
  },
  "geo" : { },
  "id_str" : "334824115166912514",
  "text" : "I feel that github profiles should have some kind of memorial mode - https:\/\/t.co\/I1UCdUDRq5 just feels sad.",
  "id" : 334824115166912514,
  "created_at" : "2013-05-16 00:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/334823838477062145\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/i5MlIMA42m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKWIgdMCEAEBRET.png",
      "id_str" : "334823838481256449",
      "id" : 334823838481256449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKWIgdMCEAEBRET.png",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i5MlIMA42m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334823838477062145",
  "text" : "Possibly the saddest contributions graph: http:\/\/t.co\/i5MlIMA42m",
  "id" : 334823838477062145,
  "created_at" : "2013-05-16 00:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334816789672370176",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt welcome back",
  "id" : 334816789672370176,
  "created_at" : "2013-05-15 23:45:17 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Calgary",
      "screen_name" : "OpenHackYYC",
      "indices" : [ 3, 15 ],
      "id_str" : "1332518635",
      "id" : 1332518635
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 101, 107 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/a0Tyyoa2s7",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
      "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334783226281332737",
  "text" : "RT @OpenHackYYC: Curious about what OpenHack is all about? Here's a quick 5 minute RailsConf talk by @qrush http:\/\/t.co\/a0Tyyoa2s7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 84, 90 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/a0Tyyoa2s7",
        "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
        "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334776186976755712",
    "text" : "Curious about what OpenHack is all about? Here's a quick 5 minute RailsConf talk by @qrush http:\/\/t.co\/a0Tyyoa2s7",
    "id" : 334776186976755712,
    "created_at" : "2013-05-15 21:03:57 +0000",
    "user" : {
      "name" : "OpenHack Calgary",
      "screen_name" : "OpenHackYYC",
      "protected" : false,
      "id_str" : "1332518635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3486362140\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 1332518635,
      "verified" : false
    }
  },
  "id" : 334783226281332737,
  "created_at" : "2013-05-15 21:31:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334759914503294976",
  "geo" : { },
  "id_str" : "334760651404750849",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa Right, also, you're biased ;)",
  "id" : 334760651404750849,
  "in_reply_to_status_id" : 334759914503294976,
  "created_at" : "2013-05-15 20:02:13 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwistedSifter",
      "screen_name" : "TwistedSifter",
      "indices" : [ 3, 17 ],
      "id_str" : "14464767",
      "id" : 14464767
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TwistedSifter\/status\/334742258463158272\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/jK8T2UCMOe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKU-T39CMAETgrG.jpg",
      "id_str" : "334742258467352577",
      "id" : 334742258467352577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKU-T39CMAETgrG.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jK8T2UCMOe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334747804637462528",
  "text" : "RT @TwistedSifter: Comedian uses Kickstarter to write a joke in the sky. This is the result http:\/\/t.co\/jK8T2UCMOe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TwistedSifter\/status\/334742258463158272\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/jK8T2UCMOe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKU-T39CMAETgrG.jpg",
        "id_str" : "334742258467352577",
        "id" : 334742258467352577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKU-T39CMAETgrG.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jK8T2UCMOe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334742258463158272",
    "text" : "Comedian uses Kickstarter to write a joke in the sky. This is the result http:\/\/t.co\/jK8T2UCMOe",
    "id" : 334742258463158272,
    "created_at" : "2013-05-15 18:49:08 +0000",
    "user" : {
      "name" : "TwistedSifter",
      "screen_name" : "TwistedSifter",
      "protected" : false,
      "id_str" : "14464767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629221898\/twistedsifter_logo_black_normal.jpg",
      "id" : 14464767,
      "verified" : false
    }
  },
  "id" : 334747804637462528,
  "created_at" : "2013-05-15 19:11:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334745401221595136",
  "geo" : { },
  "id_str" : "334745563771838464",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems yeah, I'm aware. Major bummer.",
  "id" : 334745563771838464,
  "in_reply_to_status_id" : 334745401221595136,
  "created_at" : "2013-05-15 19:02:16 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334739643000033280",
  "text" : "I can't be the only one that hasn't given any money to Kickstarter. I just don't get it. I want to buy the thing, not invest\/preorder it.",
  "id" : 334739643000033280,
  "created_at" : "2013-05-15 18:38:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334726637927165952",
  "text" : "I don't always reset my password, but when I do, it's because I pasted a curl statement right into Campfire.",
  "id" : 334726637927165952,
  "created_at" : "2013-05-15 17:47:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334695832454574083",
  "geo" : { },
  "id_str" : "334696137309184000",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder I don't live in Frank",
  "id" : 334696137309184000,
  "in_reply_to_status_id" : 334695832454574083,
  "created_at" : "2013-05-15 15:45:52 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334683970212081665",
  "geo" : { },
  "id_str" : "334685075646062592",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms sadly most of the pop. in the area does not live in Buffalo proper (I do). We have one car for our family and keeping it that way.",
  "id" : 334685075646062592,
  "in_reply_to_status_id" : 334683970212081665,
  "created_at" : "2013-05-15 15:01:54 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334683970212081665",
  "geo" : { },
  "id_str" : "334684642500300800",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms Definitely does retain - many of Buffalo's neighborhoods are very walkable\/bikable - Elmwood Village, Allentown, Downtown too.",
  "id" : 334684642500300800,
  "in_reply_to_status_id" : 334683970212081665,
  "created_at" : "2013-05-15 15:00:11 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334679874608447488",
  "geo" : { },
  "id_str" : "334681046647984128",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I was blown away by the amount I saw biking in PDX, of all ages. Thinking of parents\/grandp\u2019s biking here is just ridiculous.",
  "id" : 334681046647984128,
  "in_reply_to_status_id" : 334679874608447488,
  "created_at" : "2013-05-15 14:45:54 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/u9xkYBh79E",
      "expanded_url" : "http:\/\/grist.org\/news\/youngs-kill-car-culture\/",
      "display_url" : "grist.org\/news\/youngs-ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334679205713432576",
  "text" : "I can't wait to see car culture die: http:\/\/t.co\/u9xkYBh79E",
  "id" : 334679205713432576,
  "created_at" : "2013-05-15 14:38:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334660931231563779",
  "geo" : { },
  "id_str" : "334668969912979457",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach we open at 10 anyway :)",
  "id" : 334668969912979457,
  "in_reply_to_status_id" : 334660931231563779,
  "created_at" : "2013-05-15 13:57:54 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334538156957384704",
  "geo" : { },
  "id_str" : "334538634436947969",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy another round for the guy tweeting from 30K feet",
  "id" : 334538634436947969,
  "in_reply_to_status_id" : 334538156957384704,
  "created_at" : "2013-05-15 05:20:00 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334537497742819331",
  "geo" : { },
  "id_str" : "334537914711158784",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy it\u2019s I Am Legend the MMO.",
  "id" : 334537914711158784,
  "in_reply_to_status_id" : 334537497742819331,
  "created_at" : "2013-05-15 05:17:08 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334536178667765760",
  "text" : "I don\u2019t have insomnia, I\u2019m just really bored right before falling asleep.",
  "id" : 334536178667765760,
  "created_at" : "2013-05-15 05:10:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/ardscwQh99",
      "expanded_url" : "http:\/\/mrgan.tumblr.com\/post\/46608227636\/work-icon",
      "display_url" : "mrgan.tumblr.com\/post\/466082276\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334534791758229505",
  "text" : "RT @ubuwaits: Try to imagine the icon that represents 2060 in this sequence: http:\/\/t.co\/ardscwQh99",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/ardscwQh99",
        "expanded_url" : "http:\/\/mrgan.tumblr.com\/post\/46608227636\/work-icon",
        "display_url" : "mrgan.tumblr.com\/post\/466082276\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329908741078142976",
    "text" : "Try to imagine the icon that represents 2060 in this sequence: http:\/\/t.co\/ardscwQh99",
    "id" : 329908741078142976,
    "created_at" : "2013-05-02 10:42:27 +0000",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 334534791758229505,
  "created_at" : "2013-05-15 05:04:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/lE6PBr0utM",
      "expanded_url" : "http:\/\/nerdyoctopus.com\/a\/0f5943d660033231094a",
      "display_url" : "nerdyoctopus.com\/a\/0f5943d66003\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334524168169222144",
  "text" : "Finally trying out Dots. Such slick animations. http:\/\/t.co\/lE6PBr0utM",
  "id" : 334524168169222144,
  "created_at" : "2013-05-15 04:22:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334494451961577472",
  "text" : "Knob Creek Rye Small Batch is absolutely stellar. Get you some.",
  "id" : 334494451961577472,
  "created_at" : "2013-05-15 02:24:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/VsxzrtV8Hn",
      "expanded_url" : "http:\/\/pitchfork.com\/features\/cover-story\/reader\/daft-punk\/",
      "display_url" : "pitchfork.com\/features\/cover\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334394761354043392",
  "text" : "Absolutely stunning article on the new Daft Punk album: http:\/\/t.co\/VsxzrtV8Hn",
  "id" : 334394761354043392,
  "created_at" : "2013-05-14 19:48:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 5, 13 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/XXhMF81leR",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/115932912\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334320463222280192",
  "text" : "It's @wnyruby time tonight! http:\/\/t.co\/XXhMF81leR",
  "id" : 334320463222280192,
  "created_at" : "2013-05-14 14:53:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 7, 18 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bQiQghxTra",
      "expanded_url" : "http:\/\/www.confreaks.com\/videos\/370-rubyconf2010-history-of-rdoc-and-rubygems",
      "display_url" : "confreaks.com\/videos\/370-rub\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "331866831663026176",
  "geo" : { },
  "id_str" : "334320316178386945",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @chadfowler For some reason my brain just jogged, this is a great recap if you need it: http:\/\/t.co\/bQiQghxTra",
  "id" : 334320316178386945,
  "in_reply_to_status_id" : 331866831663026176,
  "created_at" : "2013-05-14 14:52:29 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/kAPz9eMv95",
      "expanded_url" : "http:\/\/nightmaremode.net\/2013\/03\/dwarf-fortress-as-spectator-sport-24563\/",
      "display_url" : "nightmaremode.net\/2013\/03\/dwarf-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334318819294203904",
  "text" : "\"I do not, however, love actually playing the game.  It makes me want to pull out my teeth.\" http:\/\/t.co\/kAPz9eMv95",
  "id" : 334318819294203904,
  "created_at" : "2013-05-14 14:46:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/334317067819954177\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/FlUnSYVLrq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKO7mhYCMAAel_F.jpg",
      "id_str" : "334317067824148480",
      "id" : 334317067824148480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKO7mhYCMAAel_F.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FlUnSYVLrq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334317573049040897",
  "text" : "RT @coworkbuffalo: It's in there. http:\/\/t.co\/FlUnSYVLrq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/334317067819954177\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/FlUnSYVLrq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKO7mhYCMAAel_F.jpg",
        "id_str" : "334317067824148480",
        "id" : 334317067824148480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKO7mhYCMAAel_F.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FlUnSYVLrq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334317067819954177",
    "text" : "It's in there. http:\/\/t.co\/FlUnSYVLrq",
    "id" : 334317067819954177,
    "created_at" : "2013-05-14 14:39:35 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 334317573049040897,
  "created_at" : "2013-05-14 14:41:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 33, 39 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334316117256437761",
  "text" : "RT @aquaranto: Last night I woke @qrush to tell him I felt the baby move he replied with: \"I don't think so.\" and then \"Has it robbed a ban\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 18, 24 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334314740396482560",
    "text" : "Last night I woke @qrush to tell him I felt the baby move he replied with: \"I don't think so.\" and then \"Has it robbed a bank yet?\"",
    "id" : 334314740396482560,
    "created_at" : "2013-05-14 14:30:20 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 334316117256437761,
  "created_at" : "2013-05-14 14:35:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/5P9ZkSHfni",
      "expanded_url" : "https:\/\/github.com\/mojombo\/jekyll\/pull\/583#issuecomment-17854624",
      "display_url" : "github.com\/mojombo\/jekyll\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334312811163447296",
  "geo" : { },
  "id_str" : "334315972209025027",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle https:\/\/t.co\/5P9ZkSHfni",
  "id" : 334315972209025027,
  "in_reply_to_status_id" : 334312811163447296,
  "created_at" : "2013-05-14 14:35:13 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334306083432697858",
  "text" : "It\u2019s sad when open source discussions devolve into \u201Clet me speak to your manager\u201D",
  "id" : 334306083432697858,
  "created_at" : "2013-05-14 13:55:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334173214446067713",
  "geo" : { },
  "id_str" : "334173423980920832",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove Direcorgis.",
  "id" : 334173423980920832,
  "in_reply_to_status_id" : 334173214446067713,
  "created_at" : "2013-05-14 05:08:47 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334165603587858432",
  "text" : "I want a feed of my followers\u2019 faved tweets. If they\u2019re anywhere close to how crazy mine are, they will be awesome.",
  "id" : 334165603587858432,
  "created_at" : "2013-05-14 04:37:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334087150209478658",
  "geo" : { },
  "id_str" : "334096203669180417",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel something in the water here? ;)",
  "id" : 334096203669180417,
  "in_reply_to_status_id" : 334087150209478658,
  "created_at" : "2013-05-14 00:01:56 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Anguelov",
      "screen_name" : "BobbyAnguelov",
      "indices" : [ 0, 14 ],
      "id_str" : "86052970",
      "id" : 86052970
    }, {
      "name" : "Dave Hoover",
      "screen_name" : "davehoover",
      "indices" : [ 15, 26 ],
      "id_str" : "57853",
      "id" : 57853
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 58, 67 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330460777276403712",
  "geo" : { },
  "id_str" : "334081262711083008",
  "in_reply_to_user_id" : 86052970,
  "text" : "@BobbyAnguelov @davehoover this is a big reason I started @openhack. Good software takes dedication and persistence.",
  "id" : 334081262711083008,
  "in_reply_to_status_id" : 330460777276403712,
  "created_at" : "2013-05-13 23:02:34 +0000",
  "in_reply_to_screen_name" : "BobbyAnguelov",
  "in_reply_to_user_id_str" : "86052970",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Anguelov",
      "screen_name" : "BobbyAnguelov",
      "indices" : [ 3, 17 ],
      "id_str" : "86052970",
      "id" : 86052970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334081119446237184",
  "text" : "RT @BobbyAnguelov: We really need to stop having \"hackathons\", how about we start having \"Code slowly and correctly\"-athons...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330460777276403712",
    "text" : "We really need to stop having \"hackathons\", how about we start having \"Code slowly and correctly\"-athons...",
    "id" : 330460777276403712,
    "created_at" : "2013-05-03 23:16:03 +0000",
    "user" : {
      "name" : "Bobby Anguelov",
      "screen_name" : "BobbyAnguelov",
      "protected" : false,
      "id_str" : "86052970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461854314890162176\/2t8oAW3X_normal.jpeg",
      "id" : 86052970,
      "verified" : false
    }
  },
  "id" : 334081119446237184,
  "created_at" : "2013-05-13 23:02:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gEDYZOo5L2",
      "expanded_url" : "http:\/\/developer.apple.com\/library\/ios\/#documentation\/iphone\/conceptual\/iphoneosprogrammingguide\/StatePreservation\/StatePreservation.html",
      "display_url" : "developer.apple.com\/library\/ios\/#d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334047401428000768",
  "geo" : { },
  "id_str" : "334048383981469697",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt seems like this should mention the state preservation\/restoration guide (and that it uses NSCoder) http:\/\/t.co\/gEDYZOo5L2",
  "id" : 334048383981469697,
  "in_reply_to_status_id" : 334047401428000768,
  "created_at" : "2013-05-13 20:51:55 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/eInfBXP5gz",
      "expanded_url" : "http:\/\/shitroughdrafts.com\/",
      "display_url" : "shitroughdrafts.com"
    } ]
  },
  "geo" : { },
  "id_str" : "334041307725041664",
  "text" : "A\u0336w\u0336e\u0336s\u0336o\u0336m\u0336e\u0336:\u0336 http:\/\/t.co\/eInfBXP5gz",
  "id" : 334041307725041664,
  "created_at" : "2013-05-13 20:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 5, 17 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333724407161843712",
  "geo" : { },
  "id_str" : "333725180197232640",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat @bcardarella we just haven\u2019t needed SSL locally. Not sure why it\u2019s worth the hassle",
  "id" : 333725180197232640,
  "in_reply_to_status_id" : 333724407161843712,
  "created_at" : "2013-05-12 23:27:37 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Winkler",
      "screen_name" : "mcmire",
      "indices" : [ 0, 7 ],
      "id_str" : "14453888",
      "id" : 14453888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333691186210553857",
  "geo" : { },
  "id_str" : "333724837891698688",
  "in_reply_to_user_id" : 14453888,
  "text" : "@mcmire agh I never did reply to that thread. Still not sure how to manage it :(",
  "id" : 333724837891698688,
  "in_reply_to_status_id" : 333691186210553857,
  "created_at" : "2013-05-12 23:26:16 +0000",
  "in_reply_to_screen_name" : "mcmire",
  "in_reply_to_user_id_str" : "14453888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333712218799607808",
  "geo" : { },
  "id_str" : "333721926977601538",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella totally a bummer but why not legit? If you want it, build it.",
  "id" : 333721926977601538,
  "in_reply_to_status_id" : 333712218799607808,
  "created_at" : "2013-05-12 23:14:42 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333636486937329664",
  "geo" : { },
  "id_str" : "333642293225607168",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve just saw this, sorry! If you can make it to Elmwood Village there\u2019s plenty of shops &amp; things to walk to.",
  "id" : 333642293225607168,
  "in_reply_to_status_id" : 333636486937329664,
  "created_at" : "2013-05-12 17:58:16 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333396035500130304",
  "geo" : { },
  "id_str" : "333456004282978305",
  "in_reply_to_user_id" : 1130185466,
  "text" : "@erinbrownUF submit two, well keep the updated one. Just say its the updated one.",
  "id" : 333456004282978305,
  "in_reply_to_status_id" : 333396035500130304,
  "created_at" : "2013-05-12 05:38:01 +0000",
  "in_reply_to_screen_name" : "thegeekprof",
  "in_reply_to_user_id_str" : "1130185466",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333440710831403010",
  "geo" : { },
  "id_str" : "333449591330594820",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl definitely a 1.0. Bummed the performance sucks with a larger ship :(",
  "id" : 333449591330594820,
  "in_reply_to_status_id" : 333440710831403010,
  "created_at" : "2013-05-12 05:12:32 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333400680440156161",
  "geo" : { },
  "id_str" : "333403971072970752",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin woot!!!",
  "id" : 333403971072970752,
  "in_reply_to_status_id" : 333400680440156161,
  "created_at" : "2013-05-12 02:11:15 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333395863923732482",
  "geo" : { },
  "id_str" : "333399956507480065",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin you need to set a homepage URL in the gemspec.",
  "id" : 333399956507480065,
  "in_reply_to_status_id" : 333395863923732482,
  "created_at" : "2013-05-12 01:55:18 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333365083176579072",
  "geo" : { },
  "id_str" : "333365980694720512",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski have you considered windmills?",
  "id" : 333365980694720512,
  "in_reply_to_status_id" : 333365083176579072,
  "created_at" : "2013-05-11 23:40:18 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333357815504707585",
  "geo" : { },
  "id_str" : "333362487753850880",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson oh nooooo",
  "id" : 333362487753850880,
  "in_reply_to_status_id" : 333357815504707585,
  "created_at" : "2013-05-11 23:26:25 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333360361141071872",
  "geo" : { },
  "id_str" : "333361844930633728",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski have you made your own peanut butter yet? (Yes I have done this for my dog)",
  "id" : 333361844930633728,
  "in_reply_to_status_id" : 333360361141071872,
  "created_at" : "2013-05-11 23:23:52 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 59, 63 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 64, 72 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/333337553438650368\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/pMmpXKnXsT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKBAvR9CMAAb1vJ.jpg",
      "id_str" : "333337553442844672",
      "id" : 333337553442844672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKBAvR9CMAAb1vJ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pMmpXKnXsT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333337553438650368",
  "text" : "Found some Brussels in the latest 7 Wonders expansion. \/cc @lrz @yann_ck http:\/\/t.co\/pMmpXKnXsT",
  "id" : 333337553438650368,
  "created_at" : "2013-05-11 21:47:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333321656376389633",
  "geo" : { },
  "id_str" : "333321961474244609",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 frame, just below the seat. Don\u2019t trust him enough to pull fully and braking would be harder",
  "id" : 333321961474244609,
  "in_reply_to_status_id" : 333321656376389633,
  "created_at" : "2013-05-11 20:45:23 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 25, 37 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/333321796768116736\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/YnAi8LWxDL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKAyaHyCMAAFTUM.jpg",
      "id_str" : "333321796772311040",
      "id" : 333321796772311040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKAyaHyCMAAFTUM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/YnAi8LWxDL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333321796768116736",
  "text" : "Without a doubt the best @AqueousBand poster ever. Even nailed the cover. http:\/\/t.co\/YnAi8LWxDL",
  "id" : 333321796768116736,
  "created_at" : "2013-05-11 20:44:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333320641124130817",
  "geo" : { },
  "id_str" : "333321532422111232",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 yep! Leashed to a carabiner\/bungee cord on the bike.",
  "id" : 333321532422111232,
  "in_reply_to_status_id" : 333320641124130817,
  "created_at" : "2013-05-11 20:43:40 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333310429780656129",
  "text" : "8 mile bike ride with the husky, he carried his own water too. Can't imagine having a tiny dog.",
  "id" : 333310429780656129,
  "created_at" : "2013-05-11 19:59:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333257739943936001",
  "text" : "\"Don't break anything\" - verbatim radio message to the 2 humans spacewalking to fix the space station right now.",
  "id" : 333257739943936001,
  "created_at" : "2013-05-11 16:30:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/nBJFrtM9zW",
      "expanded_url" : "http:\/\/www.nasa.gov\/multimedia\/nasatv\/index.html#live",
      "display_url" : "nasa.gov\/multimedia\/nas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "333253983185543170",
  "text" : "Spaceops, live: http:\/\/t.co\/nBJFrtM9zW",
  "id" : 333253983185543170,
  "created_at" : "2013-05-11 16:15:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333201192152887296",
  "geo" : { },
  "id_str" : "333204164664508416",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench Rhombus!!",
  "id" : 333204164664508416,
  "in_reply_to_status_id" : 333201192152887296,
  "created_at" : "2013-05-11 12:57:18 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333087015090409473",
  "geo" : { },
  "id_str" : "333091255401738240",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone whaaaaat is this sorcery!",
  "id" : 333091255401738240,
  "in_reply_to_status_id" : 333087015090409473,
  "created_at" : "2013-05-11 05:28:38 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 0, 14 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333052306591465472",
  "geo" : { },
  "id_str" : "333052678991138816",
  "in_reply_to_user_id" : 679103,
  "text" : "@travisjeffery agreed, which is sad. Nethack has been semi OSS for 20 years, DF goes on donations. More business models are needed.",
  "id" : 333052678991138816,
  "in_reply_to_status_id" : 333052306591465472,
  "created_at" : "2013-05-11 02:55:21 +0000",
  "in_reply_to_screen_name" : "travisjeffery",
  "in_reply_to_user_id_str" : "679103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333051581153034241",
  "geo" : { },
  "id_str" : "333052428247244802",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox WoW consumed me like that. Don\u2019t want a repeat!",
  "id" : 333052428247244802,
  "in_reply_to_status_id" : 333051581153034241,
  "created_at" : "2013-05-11 02:54:21 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hunty",
      "screen_name" : "HunterBridges",
      "indices" : [ 0, 14 ],
      "id_str" : "142796579",
      "id" : 142796579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333051658496000000",
  "geo" : { },
  "id_str" : "333052130078380032",
  "in_reply_to_user_id" : 142796579,
  "text" : "@HunterBridges the two games I listed don\u2019t care about MP. Think of how many good ones don't.",
  "id" : 333052130078380032,
  "in_reply_to_status_id" : 333051658496000000,
  "created_at" : "2013-05-11 02:53:10 +0000",
  "in_reply_to_screen_name" : "HunterBridges",
  "in_reply_to_user_id_str" : "142796579",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 3, 9 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333051323362721793",
  "text" : "RT @wfarr: BREAKING NEWS: iOS7 will be one more than iOS6. Discuss.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7787840545, -122.3889885746 ]
    },
    "id_str" : "333051074514673664",
    "text" : "BREAKING NEWS: iOS7 will be one more than iOS6. Discuss.",
    "id" : 333051074514673664,
    "created_at" : "2013-05-11 02:48:58 +0000",
    "user" : {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "protected" : false,
      "id_str" : "10403812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543857966395305984\/IVdcW2qU_normal.png",
      "id" : 10403812,
      "verified" : false
    }
  },
  "id" : 333051323362721793,
  "created_at" : "2013-05-11 02:49:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333050888673456129",
  "geo" : { },
  "id_str" : "333051287769870336",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox none seem to stick for long either. Latest for me has been Kingdom Rush, which has been surprisingly good.",
  "id" : 333051287769870336,
  "in_reply_to_status_id" : 333050888673456129,
  "created_at" : "2013-05-11 02:49:49 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333050134021693440",
  "geo" : { },
  "id_str" : "333050663632248832",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle yeah I forget to RT every few days or so. Want to monitor and RT for me? :)",
  "id" : 333050663632248832,
  "in_reply_to_status_id" : 333050134021693440,
  "created_at" : "2013-05-11 02:47:20 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333050487677018112",
  "text" : "I want for deep, highly replayable games for iOS. I miss Nethack and Dwarf Fortress: behind complexity is depth, mastery, and imagination.",
  "id" : 333050487677018112,
  "created_at" : "2013-05-11 02:46:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333032263598096384",
  "geo" : { },
  "id_str" : "333032463230177280",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald BUT EWWWW IT LOOKS SO GROSS",
  "id" : 333032463230177280,
  "in_reply_to_status_id" : 333032263598096384,
  "created_at" : "2013-05-11 01:35:01 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333014087216791552",
  "geo" : { },
  "id_str" : "333032205494394881",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k clearly you haven\u2019t done any iOS work. Hard to imagine life without the docs. :)",
  "id" : 333032205494394881,
  "in_reply_to_status_id" : 333014087216791552,
  "created_at" : "2013-05-11 01:33:59 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332925594176192512",
  "geo" : { },
  "id_str" : "332925826041528320",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh was expecting LEMONS",
  "id" : 332925826041528320,
  "in_reply_to_status_id" : 332925594176192512,
  "created_at" : "2013-05-10 18:31:17 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/06JYbvNKFY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_-agl0pOQfs",
      "display_url" : "youtube.com\/watch?v=_-agl0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332914109639172098",
  "text" : "Current status: http:\/\/t.co\/06JYbvNKFY",
  "id" : 332914109639172098,
  "created_at" : "2013-05-10 17:44:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brendle what",
      "screen_name" : "brendlewhat",
      "indices" : [ 3, 15 ],
      "id_str" : "38103536",
      "id" : 38103536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332903213562998784",
  "text" : "RT @brendlewhat: Top 0 Buzzfeed Writers Who Will Quit Their Job For Ethical Reasons",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332903061209088000",
    "text" : "Top 0 Buzzfeed Writers Who Will Quit Their Job For Ethical Reasons",
    "id" : 332903061209088000,
    "created_at" : "2013-05-10 17:00:49 +0000",
    "user" : {
      "name" : "brendle what",
      "screen_name" : "brendlewhat",
      "protected" : false,
      "id_str" : "38103536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458718748015202304\/pZ4ZTsOU_normal.png",
      "id" : 38103536,
      "verified" : false
    }
  },
  "id" : 332903213562998784,
  "created_at" : "2013-05-10 17:01:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332900499860893696",
  "geo" : { },
  "id_str" : "332901030008344576",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt not enough high pitched yelling or drum solos.",
  "id" : 332901030008344576,
  "in_reply_to_status_id" : 332900499860893696,
  "created_at" : "2013-05-10 16:52:45 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BFLO Harbor Kayak",
      "screen_name" : "BFLOHarborKayak",
      "indices" : [ 22, 38 ],
      "id_str" : "14463605",
      "id" : 14463605
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/nYtttggu6m",
      "expanded_url" : "http:\/\/bfloharborkayak.com\/",
      "display_url" : "bfloharborkayak.com"
    } ]
  },
  "geo" : { },
  "id_str" : "332900520723378176",
  "text" : "Sounds like a trip to @BFLOHarborKayak after one of the @nickelcityruby days is a good idea. Anyone else up for it? http:\/\/t.co\/nYtttggu6m",
  "id" : 332900520723378176,
  "created_at" : "2013-05-10 16:50:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 12, 19 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/xlYyzFi1qI",
      "expanded_url" : "http:\/\/indiegogo.com\/projects\/grain-elevator-rock-climbing-center",
      "display_url" : "indiegogo.com\/projects\/grain\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "332892859990700032",
  "geo" : { },
  "id_str" : "332892989745684480",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler @holman fuck yeah, world's largest outdoor rock climbing gym! http:\/\/t.co\/xlYyzFi1qI",
  "id" : 332892989745684480,
  "in_reply_to_status_id" : 332892859990700032,
  "created_at" : "2013-05-10 16:20:48 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Z9W7cQvygb",
      "expanded_url" : "https:\/\/www.facebook.com\/SiloCityRocks",
      "display_url" : "facebook.com\/SiloCityRocks"
    } ]
  },
  "in_reply_to_status_id_str" : "332891991924944896",
  "geo" : { },
  "id_str" : "332892464933392384",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman yeah could do after. Not sure if it will be done, but climbing a grain silo might be an option too: https:\/\/t.co\/Z9W7cQvygb",
  "id" : 332892464933392384,
  "in_reply_to_status_id" : 332891991924944896,
  "created_at" : "2013-05-10 16:18:43 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "BFLO Harbor Kayak",
      "screen_name" : "BFLOHarborKayak",
      "indices" : [ 90, 106 ],
      "id_str" : "14463605",
      "id" : 14463605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332890509230084096",
  "geo" : { },
  "id_str" : "332891375366467584",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman We can make that happen! 5 min train ride or 15 minute walk from the library. \/cc @BFLOHarborKayak",
  "id" : 332891375366467584,
  "in_reply_to_status_id" : 332890509230084096,
  "created_at" : "2013-05-10 16:14:23 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    }, {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 54, 65 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/Ehxf35m8w1",
      "expanded_url" : "https:\/\/twitter.com\/rubygems\/status\/332703347440242688",
      "display_url" : "twitter.com\/rubygems\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "332851683786883075",
  "geo" : { },
  "id_str" : "332853384115802113",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie ha! That's fun. https:\/\/t.co\/Ehxf35m8w1 \/cc @laserlemon",
  "id" : 332853384115802113,
  "in_reply_to_status_id" : 332851683786883075,
  "created_at" : "2013-05-10 13:43:25 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/rPajFGbg8i",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Northern_Inuit_Dog",
      "display_url" : "en.wikipedia.org\/wiki\/Northern_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332852188789493760",
  "text" : "Correction on last night's GoT snark: Game of Thrones is a medieval\/fantasy soap opera. With Northern Inuits. http:\/\/t.co\/rPajFGbg8i",
  "id" : 332852188789493760,
  "created_at" : "2013-05-10 13:38:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "332848139214151680",
  "geo" : { },
  "id_str" : "332848973532524544",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis yes, investigate why! I'm short on time for http:\/\/t.co\/33aYAp8SaM. this is the first i've heard. sounds like cookies are jacked",
  "id" : 332848973532524544,
  "in_reply_to_status_id" : 332848139214151680,
  "created_at" : "2013-05-10 13:25:53 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332705850202406913",
  "geo" : { },
  "id_str" : "332847995215282176",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie sorry, what?",
  "id" : 332847995215282176,
  "in_reply_to_status_id" : 332705850202406913,
  "created_at" : "2013-05-10 13:22:00 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332787813458247680",
  "geo" : { },
  "id_str" : "332847963758018561",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis doesn't seem like it :[ not sure what's up.",
  "id" : 332847963758018561,
  "in_reply_to_status_id" : 332787813458247680,
  "created_at" : "2013-05-10 13:21:53 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square",
      "screen_name" : "Square",
      "indices" : [ 3, 10 ],
      "id_str" : "93017945",
      "id" : 93017945
    }, {
      "name" : "BFLO Harbor Kayak",
      "screen_name" : "BFLOHarborKayak",
      "indices" : [ 66, 82 ],
      "id_str" : "14463605",
      "id" : 14463605
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Square\/status\/332665305639841792\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ukOgCwq0Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ3dVTxCcAANfmz.jpg",
      "id_str" : "332665305648230400",
      "id" : 332665305648230400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ3dVTxCcAANfmz.jpg",
      "sizes" : [ {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 1680
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ukOgCwq0Y4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332847093976801281",
  "text" : "RT @Square: Photo of the Day: Kayaking on Buffalo\u2019s waterfront at @BFLOHarborKayak. http:\/\/t.co\/ukOgCwq0Y4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BFLO Harbor Kayak",
        "screen_name" : "BFLOHarborKayak",
        "indices" : [ 54, 70 ],
        "id_str" : "14463605",
        "id" : 14463605
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Square\/status\/332665305639841792\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ukOgCwq0Y4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ3dVTxCcAANfmz.jpg",
        "id_str" : "332665305648230400",
        "id" : 332665305648230400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ3dVTxCcAANfmz.jpg",
        "sizes" : [ {
          "h" : 162,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 805,
          "resize" : "fit",
          "w" : 1680
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ukOgCwq0Y4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332665305639841792",
    "text" : "Photo of the Day: Kayaking on Buffalo\u2019s waterfront at @BFLOHarborKayak. http:\/\/t.co\/ukOgCwq0Y4",
    "id" : 332665305639841792,
    "created_at" : "2013-05-10 01:16:04 +0000",
    "user" : {
      "name" : "Square",
      "screen_name" : "Square",
      "protected" : false,
      "id_str" : "93017945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539826988488224768\/6FgH3zpA_normal.png",
      "id" : 93017945,
      "verified" : true
    }
  },
  "id" : 332847093976801281,
  "created_at" : "2013-05-10 13:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332688555426054144",
  "geo" : { },
  "id_str" : "332691337688260609",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws I actually hyperventilated.",
  "id" : 332691337688260609,
  "in_reply_to_status_id" : 332688555426054144,
  "created_at" : "2013-05-10 02:59:30 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332671741572837376",
  "text" : "Game of Thrones is just a medieval\/fantasy soap opera. With huskies.",
  "id" : 332671741572837376,
  "created_at" : "2013-05-10 01:41:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shyhoof",
      "screen_name" : "shyhoof",
      "indices" : [ 3, 11 ],
      "id_str" : "465759363",
      "id" : 465759363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/471HHWXOa4",
      "expanded_url" : "http:\/\/i.imgur.com\/4J7Il0m.jpg",
      "display_url" : "i.imgur.com\/4J7Il0m.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "332629116811620352",
  "text" : "RT @shyhoof: An ode to the journey of \u00F3 on a shipping label http:\/\/t.co\/471HHWXOa4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/471HHWXOa4",
        "expanded_url" : "http:\/\/i.imgur.com\/4J7Il0m.jpg",
        "display_url" : "i.imgur.com\/4J7Il0m.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "332621356338405376",
    "text" : "An ode to the journey of \u00F3 on a shipping label http:\/\/t.co\/471HHWXOa4",
    "id" : 332621356338405376,
    "created_at" : "2013-05-09 22:21:25 +0000",
    "user" : {
      "name" : "shyhoof",
      "screen_name" : "shyhoof",
      "protected" : false,
      "id_str" : "465759363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555198100952711169\/CY6cahZu_normal.jpeg",
      "id" : 465759363,
      "verified" : false
    }
  },
  "id" : 332629116811620352,
  "created_at" : "2013-05-09 22:52:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/7PHsLmjvzE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t-3qncy5Qfk",
      "display_url" : "youtube.com\/watch?v=t-3qnc\u2026"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EsBgHi0lAz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=jAMIneGqmCY",
      "display_url" : "youtube.com\/watch?v=jAMIne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332624235056996352",
  "text" : "Just realized that Powerthirst did UNACCEPTABLE 6 years before Lemongrab. http:\/\/t.co\/7PHsLmjvzE http:\/\/t.co\/EsBgHi0lAz",
  "id" : 332624235056996352,
  "created_at" : "2013-05-09 22:32:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/txjfQ8m0Pj",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qRuNxHqwazs",
      "display_url" : "youtube.com\/watch?v=qRuNxH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "332622534333849600",
  "geo" : { },
  "id_str" : "332623187324059648",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @steveklabnik or to exercise an UNCOMFORTABLY ENERGETIC husky. http:\/\/t.co\/txjfQ8m0Pj",
  "id" : 332623187324059648,
  "in_reply_to_status_id" : 332622534333849600,
  "created_at" : "2013-05-09 22:28:42 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Jeffrey Hardy",
      "screen_name" : "packagethief",
      "indices" : [ 24, 37 ],
      "id_str" : "12089482",
      "id" : 12089482
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 38, 47 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 59, 70 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/javan\/status\/332616239967002627\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/TMmSQjy0oC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ2wtT5CYAIz4w4.jpg",
      "id_str" : "332616239975391234",
      "id" : 332616239975391234,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ2wtT5CYAIz4w4.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 944
      } ],
      "display_url" : "pic.twitter.com\/TMmSQjy0oC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332620412204752898",
  "text" : "RT @javan: Hangin' with @packagethief @bitsweat @qrush and @trevorturk http:\/\/t.co\/TMmSQjy0oC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeffrey Hardy",
        "screen_name" : "packagethief",
        "indices" : [ 13, 26 ],
        "id_str" : "12089482",
        "id" : 12089482
      }, {
        "name" : "Jeremy Kemper",
        "screen_name" : "bitsweat",
        "indices" : [ 27, 36 ],
        "id_str" : "9462972",
        "id" : 9462972
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 37, 43 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Trevor Turk",
        "screen_name" : "trevorturk",
        "indices" : [ 48, 59 ],
        "id_str" : "1742",
        "id" : 1742
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/javan\/status\/332616239967002627\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/TMmSQjy0oC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ2wtT5CYAIz4w4.jpg",
        "id_str" : "332616239975391234",
        "id" : 332616239975391234,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ2wtT5CYAIz4w4.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 944
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 944
        } ],
        "display_url" : "pic.twitter.com\/TMmSQjy0oC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332616239967002627",
    "text" : "Hangin' with @packagethief @bitsweat @qrush and @trevorturk http:\/\/t.co\/TMmSQjy0oC",
    "id" : 332616239967002627,
    "created_at" : "2013-05-09 22:01:06 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 332620412204752898,
  "created_at" : "2013-05-09 22:17:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/0E6XL9asjP",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
      "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "332614815363248129",
  "geo" : { },
  "id_str" : "332620393204547584",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn http:\/\/t.co\/0E6XL9asjP",
  "id" : 332620393204547584,
  "in_reply_to_status_id" : 332614815363248129,
  "created_at" : "2013-05-09 22:17:36 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 4, 10 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 11, 15 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/7wIUELpjM0",
      "expanded_url" : "https:\/\/github.com\/HipByte\/motion-cocoapods\/issues\/56",
      "display_url" : "github.com\/HipByte\/motion\u2026"
    }, {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/3E9lvJJTYi",
      "expanded_url" : "https:\/\/github.com\/HipByte\/motion-cocoapods\/issues\/57",
      "display_url" : "github.com\/HipByte\/motion\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332566749390192642",
  "text" : "Hey @alloy @lrz have a moment to look at https:\/\/t.co\/7wIUELpjM0 https:\/\/t.co\/3E9lvJJTYi ?",
  "id" : 332566749390192642,
  "created_at" : "2013-05-09 18:44:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Hubert",
      "screen_name" : "zhubert",
      "indices" : [ 0, 8 ],
      "id_str" : "9229622",
      "id" : 9229622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332536972331601920",
  "geo" : { },
  "id_str" : "332559003970322433",
  "in_reply_to_user_id" : 9229622,
  "text" : "@zhubert Saw them last year (same tour), so good! I wish they did more improv\/jamming.",
  "id" : 332559003970322433,
  "in_reply_to_status_id" : 332536972331601920,
  "created_at" : "2013-05-09 18:13:39 +0000",
  "in_reply_to_screen_name" : "zhubert",
  "in_reply_to_user_id_str" : "9229622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 0, 13 ],
      "id_str" : "29200620",
      "id" : 29200620
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332536464346857473",
  "geo" : { },
  "id_str" : "332557701131423744",
  "in_reply_to_user_id" : 29200620,
  "text" : "@TheOtherZach @coworkbuffalo there will be plenty!",
  "id" : 332557701131423744,
  "in_reply_to_status_id" : 332536464346857473,
  "created_at" : "2013-05-09 18:08:29 +0000",
  "in_reply_to_screen_name" : "TheOtherZach",
  "in_reply_to_user_id_str" : "29200620",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamon Holmgren",
      "screen_name" : "jamonholmgren",
      "indices" : [ 0, 14 ],
      "id_str" : "30273948",
      "id" : 30273948
    }, {
      "name" : "Richard Venneman",
      "screen_name" : "richardvenneman",
      "indices" : [ 15, 31 ],
      "id_str" : "13342402",
      "id" : 13342402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332527025522880512",
  "geo" : { },
  "id_str" : "332527708707905538",
  "in_reply_to_user_id" : 30273948,
  "text" : "@jamonholmgren @richardvenneman if you have dealt with manually laying things out in iOS, anything is better.",
  "id" : 332527708707905538,
  "in_reply_to_status_id" : 332527025522880512,
  "created_at" : "2013-05-09 16:09:18 +0000",
  "in_reply_to_screen_name" : "jamonholmgren",
  "in_reply_to_user_id_str" : "30273948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Whitman",
      "screen_name" : "bwhitman",
      "indices" : [ 0, 9 ],
      "id_str" : "14148390",
      "id" : 14148390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332525938388656128",
  "geo" : { },
  "id_str" : "332526455147864065",
  "in_reply_to_user_id" : 14148390,
  "text" : "@bwhitman also given git.io is a thing, feels like a lot. :)",
  "id" : 332526455147864065,
  "in_reply_to_status_id" : 332525938388656128,
  "created_at" : "2013-05-09 16:04:19 +0000",
  "in_reply_to_screen_name" : "bwhitman",
  "in_reply_to_user_id_str" : "14148390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Whitman",
      "screen_name" : "bwhitman",
      "indices" : [ 0, 9 ],
      "id_str" : "14148390",
      "id" : 14148390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332525938388656128",
  "geo" : { },
  "id_str" : "332526401200734208",
  "in_reply_to_user_id" : 14148390,
  "text" : "@bwhitman sure, I get it, but could be used for so much more: a guide on markdown, a blog on the latest markdown news, etc",
  "id" : 332526401200734208,
  "in_reply_to_status_id" : 332525938388656128,
  "created_at" : "2013-05-09 16:04:06 +0000",
  "in_reply_to_screen_name" : "bwhitman",
  "in_reply_to_user_id_str" : "14148390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ycLCltYoeU",
      "expanded_url" : "http:\/\/3.bp.blogspot.com\/-Fc3rmTqj0IU\/UVjokR4t1LI\/AAAAAAAAIWc\/nUlrrKM1tv8\/s640\/DEPRESSIONTWO8.2.png",
      "display_url" : "3.bp.blogspot.com\/-Fc3rmTqj0IU\/U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332524447317778433",
  "text" : "Very glad Hyperbole and a Half is back. http:\/\/t.co\/ycLCltYoeU",
  "id" : 332524447317778433,
  "created_at" : "2013-05-09 15:56:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332514893326598145",
  "text" : "Be still my heart, Neil Peart's drumset is at the top of Reddit.",
  "id" : 332514893326598145,
  "created_at" : "2013-05-09 15:18:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 24, 38 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332514589524774912",
  "text" : "Almost full house today @coworkbuffalo, almost a year in. Days like this are awesome.",
  "id" : 332514589524774912,
  "created_at" : "2013-05-09 15:17:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CIkrPTmaNZ",
      "expanded_url" : "https:\/\/pbs.twimg.com\/media\/BJ1Pkc_CAAE6i0G.jpg",
      "display_url" : "pbs.twimg.com\/media\/BJ1Pkc_C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332513492118675456",
  "text" : "\"Millenials are lazy, entitled narcissists who still live with their parents\" https:\/\/t.co\/CIkrPTmaNZ",
  "id" : 332513492118675456,
  "created_at" : "2013-05-09 15:12:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332509601247408128",
  "geo" : { },
  "id_str" : "332510605984559104",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo one of many reasons I enjoy go's for loop - one way to loop them all!",
  "id" : 332510605984559104,
  "in_reply_to_status_id" : 332509601247408128,
  "created_at" : "2013-05-09 15:01:20 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/U1hsrGrcFn",
      "expanded_url" : "http:\/\/readme.md",
      "display_url" : "readme.md"
    } ]
  },
  "geo" : { },
  "id_str" : "332505920225570816",
  "text" : "It's kind of sad that a domain like http:\/\/t.co\/U1hsrGrcFn is wasted on just a redirect.",
  "id" : 332505920225570816,
  "created_at" : "2013-05-09 14:42:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332504466865655810",
  "geo" : { },
  "id_str" : "332505373682589696",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale At least it's not in CoffeeScript! EW SO GROSS would need a rewrite!",
  "id" : 332505373682589696,
  "in_reply_to_status_id" : 332504466865655810,
  "created_at" : "2013-05-09 14:40:33 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/PTwKeAyw2t",
      "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/49943751398\/rubymotion-goes-2-0-and-gets-osx-support-templates-and",
      "display_url" : "blog.rubymotion.com\/post\/499437513\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332504215308087297",
  "text" : "RT @RubyMotion: RubyMotion Goes 2.0 And Gets OSX Support, Templates and Plugins http:\/\/t.co\/PTwKeAyw2t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/PTwKeAyw2t",
        "expanded_url" : "http:\/\/blog.rubymotion.com\/post\/49943751398\/rubymotion-goes-2-0-and-gets-osx-support-templates-and",
        "display_url" : "blog.rubymotion.com\/post\/499437513\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "332499901265092608",
    "text" : "RubyMotion Goes 2.0 And Gets OSX Support, Templates and Plugins http:\/\/t.co\/PTwKeAyw2t",
    "id" : 332499901265092608,
    "created_at" : "2013-05-09 14:18:48 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 332504215308087297,
  "created_at" : "2013-05-09 14:35:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Venneman",
      "screen_name" : "richardvenneman",
      "indices" : [ 3, 19 ],
      "id_str" : "13342402",
      "id" : 13342402
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 45, 51 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332496486644457472",
  "text" : "RT @richardvenneman: Having lots of fun with @qrush his motion-layout gem. So much better for laying out views than dumb absolute positioni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 24, 30 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332474384709214208",
    "text" : "Having lots of fun with @qrush his motion-layout gem. So much better for laying out views than dumb absolute positioning.",
    "id" : 332474384709214208,
    "created_at" : "2013-05-09 12:37:25 +0000",
    "user" : {
      "name" : "Richard Venneman",
      "screen_name" : "richardvenneman",
      "protected" : false,
      "id_str" : "13342402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492594678576197632\/KmY9JsmS_normal.jpeg",
      "id" : 13342402,
      "verified" : false
    }
  },
  "id" : 332496486644457472,
  "created_at" : "2013-05-09 14:05:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332310789262295040",
  "text" : "Star Command is definitely a 1.0. Despite the haters I\u2019m really liking it. I hope they continue to work on it.",
  "id" : 332310789262295040,
  "created_at" : "2013-05-09 01:47:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whit morriss",
      "screen_name" : "whitmo",
      "indices" : [ 3, 10 ],
      "id_str" : "1592024322",
      "id" : 1592024322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332233925944553472",
  "text" : "RT @whitmo: Some days you crush the code, some days the code crushes you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332233561535041537",
    "text" : "Some days you crush the code, some days the code crushes you.",
    "id" : 332233561535041537,
    "created_at" : "2013-05-08 20:40:28 +0000",
    "user" : {
      "name" : "\/var\/log\/whit.log",
      "screen_name" : "whit",
      "protected" : false,
      "id_str" : "17974018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531850665606127616\/KFQIgv5h_normal.jpeg",
      "id" : 17974018,
      "verified" : false
    }
  },
  "id" : 332233925944553472,
  "created_at" : "2013-05-08 20:41:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcoin.txt",
      "screen_name" : "bitcoin_txt",
      "indices" : [ 3, 15 ],
      "id_str" : "1327139984",
      "id" : 1327139984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332228015931142146",
  "text" : "RT @bitcoin_txt: I quit my job to follow my crazy dream of being an Etch a Sketch artist, I'm one of the world's best. I'm taking a risk an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328225688446439425",
    "text" : "I quit my job to follow my crazy dream of being an Etch a Sketch artist, I'm one of the world's best. I'm taking a risk and I accept bitcoin",
    "id" : 328225688446439425,
    "created_at" : "2013-04-27 19:14:36 +0000",
    "user" : {
      "name" : "bitcoin.txt",
      "screen_name" : "bitcoin_txt",
      "protected" : false,
      "id_str" : "1327139984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000733109800\/bf0d2dd7fd0de2130350482bc6318055_normal.png",
      "id" : 1327139984,
      "verified" : false
    }
  },
  "id" : 332228015931142146,
  "created_at" : "2013-05-08 20:18:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 3, 15 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332218798310559747",
  "text" : "RT @clayallsopp: GIF Driven Development",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332218690177224704",
    "text" : "GIF Driven Development",
    "id" : 332218690177224704,
    "created_at" : "2013-05-08 19:41:22 +0000",
    "user" : {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "protected" : false,
      "id_str" : "48464282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000117720193\/f274bdf193101039d3b8c71308a4b25d_normal.jpeg",
      "id" : 48464282,
      "verified" : false
    }
  },
  "id" : 332218798310559747,
  "created_at" : "2013-05-08 19:41:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/a5FlqVuRIX",
      "expanded_url" : "http:\/\/i.imgur.com\/aKnV3cL.jpg",
      "display_url" : "i.imgur.com\/aKnV3cL.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "332201871127244800",
  "text" : "Current status: http:\/\/t.co\/a5FlqVuRIX",
  "id" : 332201871127244800,
  "created_at" : "2013-05-08 18:34:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Moyer",
      "screen_name" : "willmoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "19036986",
      "id" : 19036986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/Av36oiqYee",
      "expanded_url" : "http:\/\/cl.ly\/2Z0A3N2w463t",
      "display_url" : "cl.ly\/2Z0A3N2w463t"
    } ]
  },
  "geo" : { },
  "id_str" : "332182807155703810",
  "text" : "RT @willmoyer: \u201CMy Administration is committed to creating an unprecedented level of openness in Government.\u201D \u2014Barack Obama\n\nhttp:\/\/t.co\/Av\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Av36oiqYee",
        "expanded_url" : "http:\/\/cl.ly\/2Z0A3N2w463t",
        "display_url" : "cl.ly\/2Z0A3N2w463t"
      } ]
    },
    "geo" : { },
    "id_str" : "332179342463475713",
    "text" : "\u201CMy Administration is committed to creating an unprecedented level of openness in Government.\u201D \u2014Barack Obama\n\nhttp:\/\/t.co\/Av36oiqYee\n\nHaha.",
    "id" : 332179342463475713,
    "created_at" : "2013-05-08 17:05:01 +0000",
    "user" : {
      "name" : "Will Moyer",
      "screen_name" : "willmoyer",
      "protected" : false,
      "id_str" : "19036986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564846343756054529\/rmoYO0gK_normal.jpeg",
      "id" : 19036986,
      "verified" : false
    }
  },
  "id" : 332182807155703810,
  "created_at" : "2013-05-08 17:18:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 17, 20 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 21, 33 ],
      "id_str" : "15524875",
      "id" : 15524875
    }, {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 34, 41 ],
      "id_str" : "11322372",
      "id" : 11322372
    }, {
      "name" : "Neal Sales-Griffin",
      "screen_name" : "nealsales",
      "indices" : [ 42, 52 ],
      "id_str" : "13275012",
      "id" : 13275012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BIsVS2IXtQ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
      "display_url" : "nickelcityruby.com\/cfp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "332181598831251458",
  "text" : "Excited to bring @j3 @SaraJChipps @holman @nealsales to Buffalo this fall. You should give a talk too! http:\/\/t.co\/BIsVS2IXtQ",
  "id" : 332181598831251458,
  "created_at" : "2013-05-08 17:13:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332154487479357440",
  "geo" : { },
  "id_str" : "332156524803788801",
  "in_reply_to_user_id" : 11789152,
  "text" : "@gkarekinian +1",
  "id" : 332156524803788801,
  "in_reply_to_status_id" : 332154487479357440,
  "created_at" : "2013-05-08 15:34:21 +0000",
  "in_reply_to_screen_name" : "gregkare",
  "in_reply_to_user_id_str" : "11789152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332149886038450179",
  "geo" : { },
  "id_str" : "332153577604792320",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald BUG REPORT: Not a monad.",
  "id" : 332153577604792320,
  "in_reply_to_status_id" : 332149886038450179,
  "created_at" : "2013-05-08 15:22:38 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 13, 19 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332149021009387523",
  "geo" : { },
  "id_str" : "332153470436122625",
  "in_reply_to_user_id" : 11789152,
  "text" : "@gkarekinian @parkr the pervasive niceness of folks have kept me around. What's breaking for you? Would email be easier?",
  "id" : 332153470436122625,
  "in_reply_to_status_id" : 332149021009387523,
  "created_at" : "2013-05-08 15:22:13 +0000",
  "in_reply_to_screen_name" : "gregkare",
  "in_reply_to_user_id_str" : "11789152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332146600342327296",
  "geo" : { },
  "id_str" : "332147372975067136",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Well at this point I'm a prehistoric dev! I'm using a language that 20 years old!",
  "id" : 332147372975067136,
  "in_reply_to_status_id" : 332146600342327296,
  "created_at" : "2013-05-08 14:57:59 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/PH7gmV1V5e",
      "expanded_url" : "https:\/\/github.com\/rethinkdb\/rethinkdb\/issues\/766",
      "display_url" : "github.com\/rethinkdb\/reth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332145467590840320",
  "text" : "\"ew nevermind the entire driver is coffeescript\" it's people like this :( https:\/\/t.co\/PH7gmV1V5e",
  "id" : 332145467590840320,
  "created_at" : "2013-05-08 14:50:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mispy",
      "screen_name" : "m1sp",
      "indices" : [ 0, 5 ],
      "id_str" : "1007638597",
      "id" : 1007638597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332139575814287360",
  "geo" : { },
  "id_str" : "332142801586376704",
  "in_reply_to_user_id" : 1007638597,
  "text" : "@m1sp ha, yes, I've had it for a while. i've been meaning to write about DF.",
  "id" : 332142801586376704,
  "in_reply_to_status_id" : 332139575814287360,
  "created_at" : "2013-05-08 14:39:49 +0000",
  "in_reply_to_screen_name" : "m1sp",
  "in_reply_to_user_id_str" : "1007638597",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331999022611038208",
  "geo" : { },
  "id_str" : "331999752801615872",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded given I just spent all night playing this, I\u2019m satisfied for $3. Controls are finicky but I like it.",
  "id" : 331999752801615872,
  "in_reply_to_status_id" : 331999022611038208,
  "created_at" : "2013-05-08 05:11:23 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 0, 11 ],
      "id_str" : "14693115",
      "id" : 14693115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331911670081396736",
  "geo" : { },
  "id_str" : "331962581877153793",
  "in_reply_to_user_id" : 14693115,
  "text" : "@rayonrails only the best birthday gift!",
  "id" : 331962581877153793,
  "in_reply_to_status_id" : 331911670081396736,
  "created_at" : "2013-05-08 02:43:41 +0000",
  "in_reply_to_screen_name" : "rayonrails",
  "in_reply_to_user_id_str" : "14693115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Riedinger",
      "screen_name" : "chrisriedinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14857000",
      "id" : 14857000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331931313881874432",
  "geo" : { },
  "id_str" : "331931602907176960",
  "in_reply_to_user_id" : 14857000,
  "text" : "@chrisriedinger Yikes. Rough times man :(",
  "id" : 331931602907176960,
  "in_reply_to_status_id" : 331931313881874432,
  "created_at" : "2013-05-08 00:40:35 +0000",
  "in_reply_to_screen_name" : "chrisriedinger",
  "in_reply_to_user_id_str" : "14857000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Riedinger",
      "screen_name" : "chrisriedinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14857000",
      "id" : 14857000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331930425956106241",
  "geo" : { },
  "id_str" : "331930937799606273",
  "in_reply_to_user_id" : 14857000,
  "text" : "@chrisriedinger Holy shit. What happened?",
  "id" : 331930937799606273,
  "in_reply_to_status_id" : 331930425956106241,
  "created_at" : "2013-05-08 00:37:57 +0000",
  "in_reply_to_screen_name" : "chrisriedinger",
  "in_reply_to_user_id_str" : "14857000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331918150683729920",
  "geo" : { },
  "id_str" : "331918612996706305",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis Welcome back!",
  "id" : 331918612996706305,
  "in_reply_to_status_id" : 331918150683729920,
  "created_at" : "2013-05-07 23:48:58 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 7, 18 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331905973348343808",
  "geo" : { },
  "id_str" : "331915855422185473",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @chadfowler seems legit.",
  "id" : 331915855422185473,
  "in_reply_to_status_id" : 331905973348343808,
  "created_at" : "2013-05-07 23:38:01 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331914075560898560",
  "geo" : { },
  "id_str" : "331914280481984514",
  "in_reply_to_user_id" : 14925480,
  "text" : "@nirvdrum we gave away nickels at RailsConf to advertise :)",
  "id" : 331914280481984514,
  "in_reply_to_status_id" : 331914075560898560,
  "created_at" : "2013-05-07 23:31:45 +0000",
  "in_reply_to_screen_name" : "nirvdrum",
  "in_reply_to_user_id_str" : "14925480",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 43, 58 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Levo League",
      "screen_name" : "levoleague",
      "indices" : [ 60, 71 ],
      "id_str" : "326821147",
      "id" : 326821147
    }, {
      "name" : "Girl Develop It",
      "screen_name" : "girldevelopit",
      "indices" : [ 78, 92 ],
      "id_str" : "166315104",
      "id" : 166315104
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 101, 113 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "331913374550077440",
  "text" : "Very happy to announce our 4th speaker for @nickelcityruby: @levoleague CTO \/ @GirlDevelopIT founder @SaraJChipps! http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 331913374550077440,
  "created_at" : "2013-05-07 23:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 11, 19 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/8toFuSO9ah",
      "expanded_url" : "https:\/\/medium.com\/building-gittip\/5886749a4ded",
      "display_url" : "medium.com\/building-gitti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331909563307679744",
  "text" : "Huge +1 to @whit537 for being as open as possible. https:\/\/t.co\/8toFuSO9ah",
  "id" : 331909563307679744,
  "created_at" : "2013-05-07 23:13:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9yerfAfHNK",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=5670607",
      "display_url" : "news.ycombinator.com\/item?id=5670607"
    } ]
  },
  "geo" : { },
  "id_str" : "331873475444764672",
  "text" : "\"You think white blood cells are racist blood cells?\" https:\/\/t.co\/9yerfAfHNK",
  "id" : 331873475444764672,
  "created_at" : "2013-05-07 20:49:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331873203171520512",
  "text" : "Ah, Hacker News \"Finally, I know that you are not a racist, but that thing you said about parasites invading was pretty fucking racist\"",
  "id" : 331873203171520512,
  "created_at" : "2013-05-07 20:48:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 7, 18 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "331866831663026176",
  "geo" : { },
  "id_str" : "331868197856899072",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @chadfowler that page is entirely about http:\/\/t.co\/33aYAp8SaM, not a overall history for rubygems. Perhaps it should contain more.",
  "id" : 331868197856899072,
  "in_reply_to_status_id" : 331866831663026176,
  "created_at" : "2013-05-07 20:28:38 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Jaber",
      "screen_name" : "josephjaber",
      "indices" : [ 3, 15 ],
      "id_str" : "17514861",
      "id" : 17514861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/tVuHgea1fF",
      "expanded_url" : "http:\/\/www.josephjaber.com\/articles\/railsconf-2013-talks",
      "display_url" : "josephjaber.com\/articles\/rails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331847399263830018",
  "text" : "RT @josephjaber: RailsConf 2013: Complete list of available talks and slides http:\/\/t.co\/tVuHgea1fF #railsconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railsconf",
        "indices" : [ 83, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/tVuHgea1fF",
        "expanded_url" : "http:\/\/www.josephjaber.com\/articles\/railsconf-2013-talks",
        "display_url" : "josephjaber.com\/articles\/rails\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331593171022790656",
    "text" : "RailsConf 2013: Complete list of available talks and slides http:\/\/t.co\/tVuHgea1fF #railsconf",
    "id" : 331593171022790656,
    "created_at" : "2013-05-07 02:15:47 +0000",
    "user" : {
      "name" : "Joseph Jaber",
      "screen_name" : "josephjaber",
      "protected" : false,
      "id_str" : "17514861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/193054140\/2af0a942932eaee9e1b0a19080ff6a94_normal.jpg",
      "id" : 17514861,
      "verified" : false
    }
  },
  "id" : 331847399263830018,
  "created_at" : "2013-05-07 19:06:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/gkDjfEGJvv",
      "expanded_url" : "http:\/\/imperavi.com\/blog\/march_news_update\/",
      "display_url" : "imperavi.com\/blog\/march_new\u2026"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/yYjZqeKvM4",
      "expanded_url" : "http:\/\/awesomegifs.com\/wp-content\/uploads\/guy-jumps-out-of-window-suddenly.gif",
      "display_url" : "awesomegifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331816295442026496",
  "text" : "\"we don't use any version-control services or systems\" http:\/\/t.co\/gkDjfEGJvv http:\/\/t.co\/yYjZqeKvM4",
  "id" : 331816295442026496,
  "created_at" : "2013-05-07 17:02:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 3, 14 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/slnhf71Lp7",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Grandfather_clause",
      "display_url" : "en.wikipedia.org\/wiki\/Grandfath\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331787189698572289",
  "text" : "RT @fromonesrc: TIL \"Grandfathered in\" is a throwback to Jim Crow http:\/\/t.co\/slnhf71Lp7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/slnhf71Lp7",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Grandfather_clause",
        "display_url" : "en.wikipedia.org\/wiki\/Grandfath\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331786543343747072",
    "text" : "TIL \"Grandfathered in\" is a throwback to Jim Crow http:\/\/t.co\/slnhf71Lp7",
    "id" : 331786543343747072,
    "created_at" : "2013-05-07 15:04:10 +0000",
    "user" : {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "protected" : false,
      "id_str" : "14420513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514496188117438464\/ZdUrUp0B_normal.jpeg",
      "id" : 14420513,
      "verified" : false
    }
  },
  "id" : 331787189698572289,
  "created_at" : "2013-05-07 15:06:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 32, 42 ],
      "id_str" : "5493662",
      "id" : 5493662
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 49, 58 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0E6XL9asjP",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2250226",
      "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331786319103676416",
  "text" : "I did a quick lightning talk at @railsconf about @OpenHack. Yes, there are GIFs. http:\/\/t.co\/0E6XL9asjP",
  "id" : 331786319103676416,
  "created_at" : "2013-05-07 15:03:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 5, 15 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331448121177559040",
  "geo" : { },
  "id_str" : "331448551240527873",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz @asianmack Sure does!",
  "id" : 331448551240527873,
  "in_reply_to_status_id" : 331448121177559040,
  "created_at" : "2013-05-06 16:41:07 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ZAJz1UGtWT",
      "expanded_url" : "http:\/\/www.marieclaire.com\/blog\/gwyneth-paltrow-goop-guides-iphone-app?src=soc_twtr",
      "display_url" : "marieclaire.com\/blog\/gwyneth-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331445359614234624",
  "text" : "RT @asianmack: Gwyneth Paltrow uses Basecamp. http:\/\/t.co\/ZAJz1UGtWT Pepper Potts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/ZAJz1UGtWT",
        "expanded_url" : "http:\/\/www.marieclaire.com\/blog\/gwyneth-paltrow-goop-guides-iphone-app?src=soc_twtr",
        "display_url" : "marieclaire.com\/blog\/gwyneth-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "331444920063766528",
    "text" : "Gwyneth Paltrow uses Basecamp. http:\/\/t.co\/ZAJz1UGtWT Pepper Potts.",
    "id" : 331444920063766528,
    "created_at" : "2013-05-06 16:26:41 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 331445359614234624,
  "created_at" : "2013-05-06 16:28:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331441388581429249",
  "text" : "TIL that [UIApplication sharedApplication].statusBarFrame.size.height returns 20px on portrait, but 480px on landscape. W.T.F.",
  "id" : 331441388581429249,
  "created_at" : "2013-05-06 16:12:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 3, 16 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 64, 73 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Tyler Hunt",
      "screen_name" : "tylerhunt",
      "indices" : [ 139, 140 ],
      "id_str" : "4384181",
      "id" : 4384181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/2dMid9I01H",
      "expanded_url" : "http:\/\/rubygems.org\/search?utf8=%E2%9C%93&query=formulate",
      "display_url" : "rubygems.org\/search?utf8=%E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331440453545230337",
  "text" : "RT @olivierlacan: No more single search result listing pages on @rubygems, jumps straight to the gem page: http:\/\/t.co\/2dMid9I01H\n\n*pair hu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 46, 55 ],
        "id_str" : "14881835",
        "id" : 14881835
      }, {
        "name" : "Tyler Hunt",
        "screen_name" : "tylerhunt",
        "indices" : [ 124, 134 ],
        "id_str" : "4384181",
        "id" : 4384181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/2dMid9I01H",
        "expanded_url" : "http:\/\/rubygems.org\/search?utf8=%E2%9C%93&query=formulate",
        "display_url" : "rubygems.org\/search?utf8=%E\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.34703027, 1.62735735 ]
    },
    "id_str" : "331440135809941504",
    "text" : "No more single search result listing pages on @rubygems, jumps straight to the gem page: http:\/\/t.co\/2dMid9I01H\n\n*pair hugs @tylerhunt*",
    "id" : 331440135809941504,
    "created_at" : "2013-05-06 16:07:40 +0000",
    "user" : {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "protected" : false,
      "id_str" : "17035875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554033206677483520\/8mqHp9Kd_normal.jpeg",
      "id" : 17035875,
      "verified" : false
    }
  },
  "id" : 331440453545230337,
  "created_at" : "2013-05-06 16:08:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/1Okm8Bg44F",
      "expanded_url" : "http:\/\/jekyllrb.com\/",
      "display_url" : "jekyllrb.com"
    } ]
  },
  "geo" : { },
  "id_str" : "331435412528701441",
  "text" : "Also my old crappy design for http:\/\/t.co\/1Okm8Bg44F has been replaced some new hotness. Very glad to see Jekyll thriving!",
  "id" : 331435412528701441,
  "created_at" : "2013-05-06 15:48:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 37, 43 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/CCU93EkMXr",
      "expanded_url" : "http:\/\/blog.parkermoore.de\/2013\/05\/06\/jekyll-1-dot-0-released\/",
      "display_url" : "blog.parkermoore.de\/2013\/05\/06\/jek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331435265841319936",
  "text" : "Jekyll hit 1.0! Monumental effort by @parkr. Keep on kicking ass! http:\/\/t.co\/CCU93EkMXr",
  "id" : 331435265841319936,
  "created_at" : "2013-05-06 15:48:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 8, 20 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331398797664083968",
  "geo" : { },
  "id_str" : "331415954678489088",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo @AqueousBand yes!! Please tell me you taped the show.",
  "id" : 331415954678489088,
  "in_reply_to_status_id" : 331398797664083968,
  "created_at" : "2013-05-06 14:31:35 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331083346320953346",
  "text" : "RT @coworkbuffalo: One year ago today, a U-Haul van went to the Southern Tier, then Canada. And a heavy phone booth went up many stairs. It\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331082252954001408",
    "text" : "One year ago today, a U-Haul van went to the Southern Tier, then Canada. And a heavy phone booth went up many stairs. It is still heavy!",
    "id" : 331082252954001408,
    "created_at" : "2013-05-05 16:25:34 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 331083346320953346,
  "created_at" : "2013-05-05 16:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Stark",
      "screen_name" : "GavinStark",
      "indices" : [ 0, 11 ],
      "id_str" : "6110222",
      "id" : 6110222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330874751218245632",
  "geo" : { },
  "id_str" : "330875279989932032",
  "in_reply_to_user_id" : 6110222,
  "text" : "@GavinStark and an entire line too! \u201CUpload to the oracle cloud\u201D or whatever. Ugh.",
  "id" : 330875279989932032,
  "in_reply_to_status_id" : 330874751218245632,
  "created_at" : "2013-05-05 02:43:08 +0000",
  "in_reply_to_screen_name" : "GavinStark",
  "in_reply_to_user_id_str" : "6110222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330874349630414850",
  "text" : "Biggest lol out of Iron Man 3: a clearly labeled Sun\/Oracle server rack inside of a TV van.",
  "id" : 330874349630414850,
  "created_at" : "2013-05-05 02:39:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330438054030483457",
  "text" : "F..E.EEEE...E.EE......................................................E.....E..EEEE.............EEEESSE................SSSSSSSSSSSS......FF.",
  "id" : 330438054030483457,
  "created_at" : "2013-05-03 21:45:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330419230564569089",
  "geo" : { },
  "id_str" : "330419838960926720",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded APPROVED",
  "id" : 330419838960926720,
  "in_reply_to_status_id" : 330419230564569089,
  "created_at" : "2013-05-03 20:33:23 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 15, 26 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/sj0tpeqHJq",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks\/c\/2237797",
      "display_url" : "justin.tv\/confreaks\/c\/22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330404160912633856",
  "text" : "I had to watch @tenderlove's SEO Optimization bit again. Fucking hilarious. http:\/\/t.co\/sj0tpeqHJq",
  "id" : 330404160912633856,
  "created_at" : "2013-05-03 19:31:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 7, 17 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/TAEAuxkfQ9",
      "expanded_url" : "http:\/\/confreaks.com\/",
      "display_url" : "confreaks.com"
    } ]
  },
  "geo" : { },
  "id_str" : "330399085393752065",
  "text" : "A wild @aspleenic appears as the featured video on http:\/\/t.co\/TAEAuxkfQ9 !",
  "id" : 330399085393752065,
  "created_at" : "2013-05-03 19:10:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330186899912286208",
  "text" : "Today I have been a twitter user for 6 years, which means I have been tweeting for nearly a quarter of my life. Fascinating and terrifying.",
  "id" : 330186899912286208,
  "created_at" : "2013-05-03 05:07:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330172603509665792",
  "geo" : { },
  "id_str" : "330173363857260544",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik no way I coined that",
  "id" : 330173363857260544,
  "in_reply_to_status_id" : 330172603509665792,
  "created_at" : "2013-05-03 04:13:58 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330172424203157504",
  "geo" : { },
  "id_str" : "330173304453345280",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik everything seemed normal here.",
  "id" : 330173304453345280,
  "in_reply_to_status_id" : 330172424203157504,
  "created_at" : "2013-05-03 04:13:44 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330168855085326337",
  "text" : "Yet another #railsconf of nice people, discussions, friends, drinks, games, adventures, experiences, talks, hugs, and code. So good.",
  "id" : 330168855085326337,
  "created_at" : "2013-05-03 03:56:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330156884357160961",
  "geo" : { },
  "id_str" : "330168546351009792",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield it was awesome. Thanks for everything!",
  "id" : 330168546351009792,
  "in_reply_to_status_id" : 330156884357160961,
  "created_at" : "2013-05-03 03:54:50 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330092829810511874",
  "geo" : { },
  "id_str" : "330168183199764482",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant it\u2019s yours. I actually bought the wii console version",
  "id" : 330168183199764482,
  "in_reply_to_status_id" : 330092829810511874,
  "created_at" : "2013-05-03 03:53:23 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330167534621954048",
  "text" : "Learned that I am a lot less tense about freedom fondles after 2 beers. Thanks for the massage PDX!",
  "id" : 330167534621954048,
  "created_at" : "2013-05-03 03:50:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330090449484263424",
  "geo" : { },
  "id_str" : "330092665876144128",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant UB?",
  "id" : 330092665876144128,
  "in_reply_to_status_id" : 330090449484263424,
  "created_at" : "2013-05-02 22:53:19 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Railsconf",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330086218618527745",
  "text" : "#Railsconf game room appears open still and we should play something.",
  "id" : 330086218618527745,
  "created_at" : "2013-05-02 22:27:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 0, 15 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 16, 27 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330066610696114177",
  "geo" : { },
  "id_str" : "330086094030905345",
  "in_reply_to_user_id" : 290866979,
  "text" : "@thompson_caleb @tenderlove I was expecting a suit!",
  "id" : 330086094030905345,
  "in_reply_to_status_id" : 330066610696114177,
  "created_at" : "2013-05-02 22:27:12 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/F4YOWYjxYK",
      "expanded_url" : "https:\/\/twitter.com\/MichaelSkolnik\/status\/330036456930304000",
      "display_url" : "twitter.com\/MichaelSkolnik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330037263054544897",
  "text" : "Holy shit: https:\/\/t.co\/F4YOWYjxYK",
  "id" : 330037263054544897,
  "created_at" : "2013-05-02 19:13:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cqU2ZojrY1",
      "expanded_url" : "http:\/\/jonas.do\/writing\/what-my-daughter-taught-me-about-worrying",
      "display_url" : "jonas.do\/writing\/what-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330033445277413377",
  "text" : "\u201CAdult worldviews are cynical and full of pointless bullshit.\u201D  http:\/\/t.co\/cqU2ZojrY1",
  "id" : 330033445277413377,
  "created_at" : "2013-05-02 18:57:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 3, 9 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330025276513861632",
  "text" : "RT @rands: Stop bitching and build shit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330025072146403328",
    "text" : "Stop bitching and build shit.",
    "id" : 330025072146403328,
    "created_at" : "2013-05-02 18:24:43 +0000",
    "user" : {
      "name" : "rands",
      "screen_name" : "rands",
      "protected" : false,
      "id_str" : "30923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458982455932760064\/40qsmGPF_normal.png",
      "id" : 30923,
      "verified" : false
    }
  },
  "id" : 330025276513861632,
  "created_at" : "2013-05-02 18:25:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 5, 10 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330023931362807810",
  "text" : "Only @r00k could get an entire chorus of developers to sing, literally. Great talk.",
  "id" : 330023931362807810,
  "created_at" : "2013-05-02 18:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 21, 26 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/330008833378373632\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/oUPqSCbLA2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJRtSRaCUAAC1bJ.jpg",
      "id_str" : "330008833382567936",
      "id" : 330008833382567936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJRtSRaCUAAC1bJ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oUPqSCbLA2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330008833378373632",
  "text" : "Missing the start of @r00k\u2019s talk due to barge related problems. http:\/\/t.co\/oUPqSCbLA2",
  "id" : 330008833378373632,
  "created_at" : "2013-05-02 17:20:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329660292999041025",
  "geo" : { },
  "id_str" : "329998477482405888",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine @aquaranto might be up for suggestion",
  "id" : 329998477482405888,
  "in_reply_to_status_id" : 329660292999041025,
  "created_at" : "2013-05-02 16:39:02 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329991308104060928",
  "text" : "I\u2019m pretty sure the yelling guy from Trailer Park Boys lives in this complex.",
  "id" : 329991308104060928,
  "created_at" : "2013-05-02 16:10:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/cPHRAfRldc",
      "expanded_url" : "https:\/\/37signals.com\/svn\/posts\/3517-wanted-25-special-customers",
      "display_url" : "37signals.com\/svn\/posts\/3517\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329988891702599680",
  "text" : "RT @JZ: We're looking for 25 special customers to help us make our next product outstanding. https:\/\/t.co\/cPHRAfRldc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/cPHRAfRldc",
        "expanded_url" : "https:\/\/37signals.com\/svn\/posts\/3517-wanted-25-special-customers",
        "display_url" : "37signals.com\/svn\/posts\/3517\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329988707895607296",
    "text" : "We're looking for 25 special customers to help us make our next product outstanding. https:\/\/t.co\/cPHRAfRldc",
    "id" : 329988707895607296,
    "created_at" : "2013-05-02 16:00:13 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 329988891702599680,
  "created_at" : "2013-05-02 16:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 8, 16 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329783022138302465",
  "geo" : { },
  "id_str" : "329791311756529664",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @mperham it was closed! We went to Esan Thai.",
  "id" : 329791311756529664,
  "in_reply_to_status_id" : 329783022138302465,
  "created_at" : "2013-05-02 02:55:50 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 0, 10 ],
      "id_str" : "7220202",
      "id" : 7220202
    }, {
      "name" : "\u30E8\u30B7\u30AA\u30EA",
      "screen_name" : "yoshiori",
      "indices" : [ 11, 20 ],
      "id_str" : "3213261",
      "id" : 3213261
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 21, 27 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 28, 41 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329771685907685376",
  "geo" : { },
  "id_str" : "329772322657562624",
  "in_reply_to_user_id" : 7220202,
  "text" : "@a_matsuda @yoshiori @raggi @markimbriaco I was also hoping to provide large tar\/zip archives of all gems per month. And Postgres\/Redis too.",
  "id" : 329772322657562624,
  "in_reply_to_status_id" : 329771685907685376,
  "created_at" : "2013-05-02 01:40:23 +0000",
  "in_reply_to_screen_name" : "a_matsuda",
  "in_reply_to_user_id_str" : "7220202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30AA\u30EA",
      "screen_name" : "yoshiori",
      "indices" : [ 0, 9 ],
      "id_str" : "3213261",
      "id" : 3213261
    }, {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 10, 20 ],
      "id_str" : "7220202",
      "id" : 7220202
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 62, 68 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 73, 86 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329768618021765122",
  "geo" : { },
  "id_str" : "329770309089644544",
  "in_reply_to_user_id" : 3213261,
  "text" : "@yoshiori @a_matsuda hey rubygems-mirror-command looks great. @raggi and @markimbriaco had a way to download the all the gems in a few mins!",
  "id" : 329770309089644544,
  "in_reply_to_status_id" : 329768618021765122,
  "created_at" : "2013-05-02 01:32:23 +0000",
  "in_reply_to_screen_name" : "yoshiori",
  "in_reply_to_user_id_str" : "3213261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toru Maesaka",
      "screen_name" : "tmaesaka",
      "indices" : [ 0, 9 ],
      "id_str" : "10742632",
      "id" : 10742632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329770082467188736",
  "in_reply_to_user_id" : 10742632,
  "text" : "@tmaesaka oops, mistweet!!",
  "id" : 329770082467188736,
  "created_at" : "2013-05-02 01:31:29 +0000",
  "in_reply_to_screen_name" : "tmaesaka",
  "in_reply_to_user_id_str" : "10742632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329760975123279873",
  "text" : "Empty files have no code smell!",
  "id" : 329760975123279873,
  "created_at" : "2013-05-02 00:55:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Tx5Zphep15",
      "expanded_url" : "http:\/\/openhack.github.io",
      "display_url" : "openhack.github.io"
    } ]
  },
  "in_reply_to_status_id_str" : "329737949161869313",
  "geo" : { },
  "id_str" : "329738384119562242",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu sadly gifs won\u2019t show up. All you need to know is on http:\/\/t.co\/Tx5Zphep15 !",
  "id" : 329738384119562242,
  "in_reply_to_status_id" : 329737949161869313,
  "created_at" : "2013-05-01 23:25:31 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329737816311472129",
  "text" : "Railsconf lightning talks just went Rick Warren.",
  "id" : 329737816311472129,
  "created_at" : "2013-05-01 23:23:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 59, 68 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsconf",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329735010422763520",
  "text" : "Glad I could make some folks laugh at #railsconf\u2026check out @openhack and start one in your area!",
  "id" : 329735010422763520,
  "created_at" : "2013-05-01 23:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Strelau",
      "screen_name" : "dstrelau",
      "indices" : [ 0, 9 ],
      "id_str" : "17011212",
      "id" : 17011212
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 64, 73 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 74, 81 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329720397798965249",
  "geo" : { },
  "id_str" : "329721044455804928",
  "in_reply_to_user_id" : 17011212,
  "text" : "@dstrelau might be able to run bundler-api just on its own? \/cc @indirect @hone02",
  "id" : 329721044455804928,
  "in_reply_to_status_id" : 329720397798965249,
  "created_at" : "2013-05-01 22:16:37 +0000",
  "in_reply_to_screen_name" : "dstrelau",
  "in_reply_to_user_id_str" : "17011212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Gillen",
      "screen_name" : "glenngillen",
      "indices" : [ 3, 15 ],
      "id_str" : "6867422",
      "id" : 6867422
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 53, 60 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329717762584875008",
  "text" : "RT @glenngillen: well deserved Ruby Heroes award for @hone02. The quiet name behind things you depend on every day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Terence Lee",
        "screen_name" : "hone02",
        "indices" : [ 36, 43 ],
        "id_str" : "15317640",
        "id" : 15317640
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329659492591611906",
    "text" : "well deserved Ruby Heroes award for @hone02. The quiet name behind things you depend on every day.",
    "id" : 329659492591611906,
    "created_at" : "2013-05-01 18:12:02 +0000",
    "user" : {
      "name" : "Glenn Gillen",
      "screen_name" : "glenngillen",
      "protected" : false,
      "id_str" : "6867422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1415605087\/glenngillen_normal.jpg",
      "id" : 6867422,
      "verified" : false
    }
  },
  "id" : 329717762584875008,
  "created_at" : "2013-05-01 22:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 3, 16 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329704022745432065",
  "text" : "RT @IanCAnderson: Just bought my ticket for @nickelcityruby. You should come too!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329701445983166465",
    "text" : "Just bought my ticket for @nickelcityruby. You should come too!",
    "id" : 329701445983166465,
    "created_at" : "2013-05-01 20:58:44 +0000",
    "user" : {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "protected" : false,
      "id_str" : "23820237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491274238410506241\/KHjRmdIO_normal.jpeg",
      "id" : 23820237,
      "verified" : false
    }
  },
  "id" : 329704022745432065,
  "created_at" : "2013-05-01 21:08:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 3, 7 ],
      "id_str" : "5523",
      "id" : 5523
    }, {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 13, 23 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329686902267588609",
  "text" : "RT @pat: Hey @railsconf \u2013 I'll teach you how to create gems after lunch, and then there's a workshop to put that knowledge into practice. C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RailsConf 2015",
        "screen_name" : "railsconf",
        "indices" : [ 4, 14 ],
        "id_str" : "5493662",
        "id" : 5493662
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329686687062040576",
    "text" : "Hey @railsconf \u2013 I'll teach you how to create gems after lunch, and then there's a workshop to put that knowledge into practice. Come on by!",
    "id" : 329686687062040576,
    "created_at" : "2013-05-01 20:00:06 +0000",
    "user" : {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "protected" : false,
      "id_str" : "5523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475943177833050112\/KVAIzJUb_normal.png",
      "id" : 5523,
      "verified" : false
    }
  },
  "id" : 329686902267588609,
  "created_at" : "2013-05-01 20:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 3, 8 ],
      "id_str" : "15234407",
      "id" : 15234407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0VNFWEF1aY",
      "expanded_url" : "http:\/\/press.web.cern.ch\/press-releases\/2013\/04\/cern-celebrates-20-years-free-open-web",
      "display_url" : "press.web.cern.ch\/press-releases\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329648534582337536",
  "text" : "RT @CERN: CERN celebrates 20 years of a free, open web http:\/\/t.co\/0VNFWEF1aY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/0VNFWEF1aY",
        "expanded_url" : "http:\/\/press.web.cern.ch\/press-releases\/2013\/04\/cern-celebrates-20-years-free-open-web",
        "display_url" : "press.web.cern.ch\/press-releases\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329146430491095040",
    "text" : "CERN celebrates 20 years of a free, open web http:\/\/t.co\/0VNFWEF1aY",
    "id" : 329146430491095040,
    "created_at" : "2013-04-30 08:13:18 +0000",
    "user" : {
      "name" : "CERN",
      "screen_name" : "CERN",
      "protected" : false,
      "id_str" : "15234407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464336727562141696\/RPiEyveo_normal.jpeg",
      "id" : 15234407,
      "verified" : true
    }
  },
  "id" : 329648534582337536,
  "created_at" : "2013-05-01 17:28:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329642514443292673",
  "geo" : { },
  "id_str" : "329644398289752064",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy I think the Holley farms has ice cream\u2026but seriously. CoworkCones.",
  "id" : 329644398289752064,
  "in_reply_to_status_id" : 329642514443292673,
  "created_at" : "2013-05-01 17:12:03 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/dbVAd0lszy",
      "expanded_url" : "http:\/\/tecmogeek.com\/",
      "display_url" : "tecmogeek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "329642049383047168",
  "text" : "RT @ubuwaits: A ridiculous side project I made a few months ago: http:\/\/t.co\/dbVAd0lszy \u2014 a love letter to a game that devoured hours of my\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/dbVAd0lszy",
        "expanded_url" : "http:\/\/tecmogeek.com\/",
        "display_url" : "tecmogeek.com"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 59.3478683899, 18.0490366412 ]
    },
    "id_str" : "329641866305892352",
    "text" : "A ridiculous side project I made a few months ago: http:\/\/t.co\/dbVAd0lszy \u2014 a love letter to a game that devoured hours of my childhood.",
    "id" : 329641866305892352,
    "created_at" : "2013-05-01 17:02:00 +0000",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 329642049383047168,
  "created_at" : "2013-05-01 17:02:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 3, 14 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/2NF9eAMnVJ",
      "expanded_url" : "http:\/\/blog.dispatch.io\/post\/49367704834\/what-your-office-can-learn-from-our-coworking-space",
      "display_url" : "blog.dispatch.io\/post\/493677048\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329641841110695937",
  "text" : "RT @Alex_Godin: Every office should be more like a coworking space http:\/\/t.co\/2NF9eAMnVJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/2NF9eAMnVJ",
        "expanded_url" : "http:\/\/blog.dispatch.io\/post\/49367704834\/what-your-office-can-learn-from-our-coworking-space",
        "display_url" : "blog.dispatch.io\/post\/493677048\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329641557655425024",
    "text" : "Every office should be more like a coworking space http:\/\/t.co\/2NF9eAMnVJ",
    "id" : 329641557655425024,
    "created_at" : "2013-05-01 17:00:46 +0000",
    "user" : {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "protected" : false,
      "id_str" : "11694962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444228256741339136\/Wz2Cm7py_normal.jpeg",
      "id" : 11694962,
      "verified" : false
    }
  },
  "id" : 329641841110695937,
  "created_at" : "2013-05-01 17:01:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cz",
      "screen_name" : "netshade",
      "indices" : [ 0, 9 ],
      "id_str" : "785416",
      "id" : 785416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329495118128238592",
  "geo" : { },
  "id_str" : "329605939378393088",
  "in_reply_to_user_id" : 785416,
  "text" : "@netshade sorry! :( ill be near the helpdesk again today",
  "id" : 329605939378393088,
  "in_reply_to_status_id" : 329495118128238592,
  "created_at" : "2013-05-01 14:39:14 +0000",
  "in_reply_to_screen_name" : "netshade",
  "in_reply_to_user_id_str" : "785416",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 3, 19 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329483981286408192",
  "text" : "RT @patricksroberts: Submitted a talk for @nickelcityruby!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 21, 36 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 45.5283587274, -122.6632983985 ]
    },
    "id_str" : "329398693046403077",
    "text" : "Submitted a talk for @nickelcityruby!",
    "id" : 329398693046403077,
    "created_at" : "2013-05-01 00:55:43 +0000",
    "user" : {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "protected" : false,
      "id_str" : "46661605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248286148\/ea57968324be012f02e540b110ff12bf_normal.png",
      "id" : 46661605,
      "verified" : false
    }
  },
  "id" : 329483981286408192,
  "created_at" : "2013-05-01 06:34:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329404904772866048",
  "geo" : { },
  "id_str" : "329478279151120384",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella agreed.",
  "id" : 329478279151120384,
  "in_reply_to_status_id" : 329404904772866048,
  "created_at" : "2013-05-01 06:11:57 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
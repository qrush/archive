Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274704606859259905",
  "geo" : { },
  "id_str" : "274707727048118272",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried Instagram is much more cost-effective.",
  "id" : 274707727048118272,
  "in_reply_to_status_id" : 274704606859259905,
  "created_at" : "2012-12-01 02:53:20 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/WqGmn96u",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_nVk25ZvTkU",
      "display_url" : "youtube.com\/watch?v=_nVk25\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "274311144334839808",
  "geo" : { },
  "id_str" : "274335419204767745",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer http:\/\/t.co\/WqGmn96u",
  "id" : 274335419204767745,
  "in_reply_to_status_id" : 274311144334839808,
  "created_at" : "2012-11-30 02:13:55 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 0, 8 ],
      "id_str" : "425253989",
      "id" : 425253989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274304215487217665",
  "geo" : { },
  "id_str" : "274335140111581185",
  "in_reply_to_user_id" : 425253989,
  "text" : "@embrown I don't always drink ice cream, but when I do...",
  "id" : 274335140111581185,
  "in_reply_to_status_id" : 274304215487217665,
  "created_at" : "2012-11-30 02:12:48 +0000",
  "in_reply_to_screen_name" : "embrown",
  "in_reply_to_user_id_str" : "425253989",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chan",
      "screen_name" : "jtcchan",
      "indices" : [ 0, 8 ],
      "id_str" : "12653762",
      "id" : 12653762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274303687390793728",
  "geo" : { },
  "id_str" : "274334953699950592",
  "in_reply_to_user_id" : 12653762,
  "text" : "@jtcchan already done, only once though. trying to vary our cuisines to much success.",
  "id" : 274334953699950592,
  "in_reply_to_status_id" : 274303687390793728,
  "created_at" : "2012-11-30 02:12:04 +0000",
  "in_reply_to_screen_name" : "jtcchan",
  "in_reply_to_user_id_str" : "12653762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274329586735669251",
  "geo" : { },
  "id_str" : "274334850390040577",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine yes!",
  "id" : 274334850390040577,
  "in_reply_to_status_id" : 274329586735669251,
  "created_at" : "2012-11-30 02:11:39 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274302880251518976",
  "text" : "750 of La Fin Du Monde for $6. Loving being in Quebec.",
  "id" : 274302880251518976,
  "created_at" : "2012-11-30 00:04:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274206991738613761",
  "text" : "First impression of VIA Rail is that it\u2019s much nicer than Amtrak.",
  "id" : 274206991738613761,
  "created_at" : "2012-11-29 17:43:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 38, 49 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274012261469810689",
  "text" : "I can\u2019t say this enough, big props to @MattBinder for wading through the eternal derpness of those who can\u2019t math tonight.",
  "id" : 274012261469810689,
  "created_at" : "2012-11-29 04:49:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274010566497013761",
  "text" : "LOL\u2019d at open mic night, walked with a comic, got lost trying to find  shawarma, found a museum, nearly froze, ordered pizza. Good night.",
  "id" : 274010566497013761,
  "created_at" : "2012-11-29 04:43:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/HkQ9PjgW",
      "expanded_url" : "http:\/\/kylerush.net\/blog\/meet-the-obama-campaigns-250-million-fundraising-platform\/",
      "display_url" : "kylerush.net\/blog\/meet-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273902329848270848",
  "text" : "The Obama campaign used Jekyll to raise over $250M. Blown away by this. http:\/\/t.co\/HkQ9PjgW",
  "id" : 273902329848270848,
  "created_at" : "2012-11-28 21:32:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 0, 8 ],
      "id_str" : "324160285",
      "id" : 324160285
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 9, 18 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 19, 31 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 32, 41 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273578074761723904",
  "geo" : { },
  "id_str" : "273612672396820481",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DougYun @bquarant @bcardarella @openhack yes, yes\u2026let the hate flow through you!",
  "id" : 273612672396820481,
  "in_reply_to_status_id" : 273578074761723904,
  "created_at" : "2012-11-28 02:21:59 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273506358815506432",
  "geo" : { },
  "id_str" : "273521735733747712",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills rbenv is a good way to start, that's where I mostly extracted sub from.",
  "id" : 273521735733747712,
  "in_reply_to_status_id" : 273506358815506432,
  "created_at" : "2012-11-27 20:20:38 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273521255397859329",
  "text" : "This month is brought to you by the letter F, and \"FUCK\".",
  "id" : 273521255397859329,
  "created_at" : "2012-11-27 20:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brandt",
      "screen_name" : "cbrandtbuffalo",
      "indices" : [ 0, 15 ],
      "id_str" : "44345137",
      "id" : 44345137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273418550092374017",
  "geo" : { },
  "id_str" : "273420927595859968",
  "in_reply_to_user_id" : 44345137,
  "text" : "@cbrandtbuffalo \u2026great.",
  "id" : 273420927595859968,
  "in_reply_to_status_id" : 273418550092374017,
  "created_at" : "2012-11-27 13:40:03 +0000",
  "in_reply_to_screen_name" : "cbrandtbuffalo",
  "in_reply_to_user_id_str" : "44345137",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273121298694148096",
  "text" : "On a bus in Montreal with wifi. Mobile wifi always amazes me.",
  "id" : 273121298694148096,
  "created_at" : "2012-11-26 17:49:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 20, 30 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273037793872207873",
  "text" : "Marking a year with @37signals this week! Still just as excited and grateful for awesome coworkers and challenging work.",
  "id" : 273037793872207873,
  "created_at" : "2012-11-26 12:17:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272908201643610112",
  "geo" : { },
  "id_str" : "272908658923433984",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt amazing: Isn\u2019t that meant to be pronounced \u201Cwhat?\u201D",
  "id" : 272908658923433984,
  "in_reply_to_status_id" : 272908201643610112,
  "created_at" : "2012-11-26 03:44:29 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/dZCRaGgs",
      "expanded_url" : "http:\/\/youtu.be\/UoqlBHSePw0",
      "display_url" : "youtu.be\/UoqlBHSePw0"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/h7OjiISU",
      "expanded_url" : "http:\/\/i.imgur.com\/vcYuy.png",
      "display_url" : "i.imgur.com\/vcYuy.png"
    } ]
  },
  "geo" : { },
  "id_str" : "272884872127868928",
  "text" : "RT @lindseybieda: So there's this movie called Red Dawn http:\/\/t.co\/dZCRaGgs and it inspires racism on twitter http:\/\/t.co\/h7OjiISU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rstat.us\/\" rel=\"nofollow\"\u003ERstat.us App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/dZCRaGgs",
        "expanded_url" : "http:\/\/youtu.be\/UoqlBHSePw0",
        "display_url" : "youtu.be\/UoqlBHSePw0"
      }, {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/h7OjiISU",
        "expanded_url" : "http:\/\/i.imgur.com\/vcYuy.png",
        "display_url" : "i.imgur.com\/vcYuy.png"
      } ]
    },
    "geo" : { },
    "id_str" : "272878477605232641",
    "text" : "So there's this movie called Red Dawn http:\/\/t.co\/dZCRaGgs and it inspires racism on twitter http:\/\/t.co\/h7OjiISU",
    "id" : 272878477605232641,
    "created_at" : "2012-11-26 01:44:33 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 272884872127868928,
  "created_at" : "2012-11-26 02:09:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 8, 16 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272830234284392449",
  "geo" : { },
  "id_str" : "272836752257998848",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @mperham awesome!!",
  "id" : 272836752257998848,
  "in_reply_to_status_id" : 272830234284392449,
  "created_at" : "2012-11-25 22:58:45 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/QIWqD0t2",
      "expanded_url" : "http:\/\/quaran.to\/m",
      "display_url" : "quaran.to\/m"
    } ]
  },
  "in_reply_to_status_id_str" : "272826343887106050",
  "geo" : { },
  "id_str" : "272827322405621762",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham obviously biased but I use m daily. http:\/\/t.co\/QIWqD0t2",
  "id" : 272827322405621762,
  "in_reply_to_status_id" : 272826343887106050,
  "created_at" : "2012-11-25 22:21:17 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272822173360599042",
  "geo" : { },
  "id_str" : "272823258364125184",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy it will get better.",
  "id" : 272823258364125184,
  "in_reply_to_status_id" : 272822173360599042,
  "created_at" : "2012-11-25 22:05:08 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/272773252152164352\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/9jjb0EHn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8kV098CAAEsHSB.png",
      "id_str" : "272773252156358657",
      "id" : 272773252156358657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8kV098CAAEsHSB.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/9jjb0EHn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272773252152164352",
  "text" : "How this Bills fan asks Siri questions: http:\/\/t.co\/9jjb0EHn",
  "id" : 272773252152164352,
  "created_at" : "2012-11-25 18:46:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272723399254609920",
  "text" : "RT @aquaranto: Yes, my husband woke up rapping \"I like it when you call me Big Poppa\" and yes, this is normal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272722712026288128",
    "text" : "Yes, my husband woke up rapping \"I like it when you call me Big Poppa\" and yes, this is normal.",
    "id" : 272722712026288128,
    "created_at" : "2012-11-25 15:25:36 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 272723399254609920,
  "created_at" : "2012-11-25 15:28:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/272584773237612544\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/hqIZRwhc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8hqaDSCIAAVnJT.png",
      "id_str" : "272584773246001152",
      "id" : 272584773246001152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8hqaDSCIAAVnJT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hqIZRwhc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272584773237612544",
  "text" : "Pretty wild stats on Xbox Smartglass available seconds after games have ended. UI not polished but Halo has evolved. http:\/\/t.co\/hqIZRwhc",
  "id" : 272584773237612544,
  "created_at" : "2012-11-25 06:17:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zer0Her0",
      "screen_name" : "Zer0Her0",
      "indices" : [ 0, 9 ],
      "id_str" : "662843",
      "id" : 662843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272573364323885056",
  "geo" : { },
  "id_str" : "272579209245908992",
  "in_reply_to_user_id" : 662843,
  "text" : "@Zer0Her0 woot!",
  "id" : 272579209245908992,
  "in_reply_to_status_id" : 272573364323885056,
  "created_at" : "2012-11-25 05:55:22 +0000",
  "in_reply_to_screen_name" : "Zer0Her0",
  "in_reply_to_user_id_str" : "662843",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272557400383434752",
  "text" : "It\u2019s Halo 4 time. Anyone else playing tonight? Gamertag is \u201CDoctor Q\u201D (man I hate that renaming costs money)",
  "id" : 272557400383434752,
  "created_at" : "2012-11-25 04:28:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272535233692311552",
  "geo" : { },
  "id_str" : "272553370424860673",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 more live tweeting.",
  "id" : 272553370424860673,
  "in_reply_to_status_id" : 272535233692311552,
  "created_at" : "2012-11-25 04:12:41 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 11, 22 ],
      "id_str" : "14931637",
      "id" : 14931637
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 33, 46 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/dlli8tcD",
      "expanded_url" : "http:\/\/publicshaming.tumblr.com",
      "display_url" : "publicshaming.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "272429169332338688",
  "text" : "Looks like @MattBinder has taken @herpderpedia to a whole new level: http:\/\/t.co\/dlli8tcD",
  "id" : 272429169332338688,
  "created_at" : "2012-11-24 19:59:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272140146084814848",
  "geo" : { },
  "id_str" : "272149152589283328",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders pretty sure no, it will try to use the platform of the parent gem",
  "id" : 272149152589283328,
  "in_reply_to_status_id" : 272140146084814848,
  "created_at" : "2012-11-24 01:26:28 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272085956696358913",
  "text" : "Such BULLSHIT. Can't cancel the flight, change it, or ANYTHING without an $150 fee. I'm getting molested BEFORE I get to the airport.",
  "id" : 272085956696358913,
  "created_at" : "2012-11-23 21:15:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272085044917571584",
  "text" : "I really, really, REALLY fucking HATE how you can't get a refund for flights. Such a fucking JOKE.",
  "id" : 272085044917571584,
  "created_at" : "2012-11-23 21:11:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stats Canada",
      "screen_name" : "stats_canada",
      "indices" : [ 3, 16 ],
      "id_str" : "701267743",
      "id" : 701267743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272081339996577793",
  "text" : "RT @stats_canada: 98% of Southern Ontarians are currently in Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272033367380348928",
    "text" : "98% of Southern Ontarians are currently in Buffalo",
    "id" : 272033367380348928,
    "created_at" : "2012-11-23 17:46:23 +0000",
    "user" : {
      "name" : "Stats Canada",
      "screen_name" : "stats_canada",
      "protected" : false,
      "id_str" : "701267743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2752781064\/decdee41e5324dfe1af9a1a1c8c9846b_normal.png",
      "id" : 701267743,
      "verified" : false
    }
  },
  "id" : 272081339996577793,
  "created_at" : "2012-11-23 20:57:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/Su4VGq63",
      "expanded_url" : "http:\/\/package.json.jit.su\/",
      "display_url" : "package.json.jit.su"
    } ]
  },
  "geo" : { },
  "id_str" : "272065905821900800",
  "text" : "Really neat, maybe we should have something like this for gemspecs? http:\/\/t.co\/Su4VGq63",
  "id" : 272065905821900800,
  "created_at" : "2012-11-23 19:55:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272004123522658304",
  "geo" : { },
  "id_str" : "272012157414154240",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones why aren't you DJing!?",
  "id" : 272012157414154240,
  "in_reply_to_status_id" : 272004123522658304,
  "created_at" : "2012-11-23 16:22:06 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272004026395131906",
  "geo" : { },
  "id_str" : "272012116314185729",
  "in_reply_to_user_id" : 176608253,
  "text" : "@dhiggsbuf that seems plausible",
  "id" : 272012116314185729,
  "in_reply_to_status_id" : 272004026395131906,
  "created_at" : "2012-11-23 16:21:56 +0000",
  "in_reply_to_screen_name" : "drunKoreaNerd",
  "in_reply_to_user_id_str" : "176608253",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "272003579437527041",
  "text" : "DJing in the CoworkBuffalo room. Now playing Lily Allen Vs Mumford Sons: Lily Lion Man Mashup Remix \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 272003579437527041,
  "created_at" : "2012-11-23 15:48:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272002042090881024",
  "geo" : { },
  "id_str" : "272002805991108611",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I don't buy\/get the \"extra baggage\" nonsense. (This as someone who loves and uses Sinatra)",
  "id" : 272002805991108611,
  "in_reply_to_status_id" : 272002042090881024,
  "created_at" : "2012-11-23 15:44:57 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272002042090881024",
  "geo" : { },
  "id_str" : "272002711107538944",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I don't understand why you wouldn't just use Rails.",
  "id" : 272002711107538944,
  "in_reply_to_status_id" : 272002042090881024,
  "created_at" : "2012-11-23 15:44:34 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/0k6e6rei",
      "expanded_url" : "http:\/\/blog.steveklabnik.com\/posts\/2012-11-22-introducing-the-rails-api-project",
      "display_url" : "blog.steveklabnik.com\/posts\/2012-11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272001591408730113",
  "text" : "Maybe I'm tired, but I don't get http:\/\/t.co\/0k6e6rei at all.",
  "id" : 272001591408730113,
  "created_at" : "2012-11-23 15:40:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271998717094146048",
  "geo" : { },
  "id_str" : "272001493664661505",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 100 billion should be enough",
  "id" : 272001493664661505,
  "in_reply_to_status_id" : 271998717094146048,
  "created_at" : "2012-11-23 15:39:44 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271998951828361217",
  "geo" : { },
  "id_str" : "272001449410584578",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending You should try to build a quick Twitter client and find this out for yourself :)",
  "id" : 272001449410584578,
  "in_reply_to_status_id" : 271998951828361217,
  "created_at" : "2012-11-23 15:39:33 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271997429082103808",
  "geo" : { },
  "id_str" : "271997727972409345",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending I highly doubt that. That it set by the Oauth gateway and not per request.",
  "id" : 271997727972409345,
  "in_reply_to_status_id" : 271997429082103808,
  "created_at" : "2012-11-23 15:24:46 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271993970106712066",
  "geo" : { },
  "id_str" : "271997299528454144",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella it\u2019s a constant of my life.",
  "id" : 271997299528454144,
  "in_reply_to_status_id" : 271993970106712066,
  "created_at" : "2012-11-23 15:23:04 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271996439020855296",
  "geo" : { },
  "id_str" : "271997241168916480",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 does it have GPS?",
  "id" : 271997241168916480,
  "in_reply_to_status_id" : 271996439020855296,
  "created_at" : "2012-11-23 15:22:50 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271993181166526465",
  "text" : "There is a point in life where one stops losing things? I'm ready for that point.",
  "id" : 271993181166526465,
  "created_at" : "2012-11-23 15:06:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271735902747906048",
  "text" : "Why is a picture password an advertised feature of Windows 8? Do people actually care about that?",
  "id" : 271735902747906048,
  "created_at" : "2012-11-22 22:04:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Murphy",
      "screen_name" : "wfm",
      "indices" : [ 0, 4 ],
      "id_str" : "6655452",
      "id" : 6655452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271654456083492865",
  "geo" : { },
  "id_str" : "271694691798511616",
  "in_reply_to_user_id" : 6655452,
  "text" : "@wfm no worries. This is definitely a long term thing. Just need to keep it running and consistent :)",
  "id" : 271694691798511616,
  "in_reply_to_status_id" : 271654456083492865,
  "created_at" : "2012-11-22 19:20:37 +0000",
  "in_reply_to_screen_name" : "wfm",
  "in_reply_to_user_id_str" : "6655452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Grusden",
      "screen_name" : "cgrusden",
      "indices" : [ 0, 9 ],
      "id_str" : "10187892",
      "id" : 10187892
    }, {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 10, 17 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 18, 29 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271434814576533504",
  "geo" : { },
  "id_str" : "271454971747262464",
  "in_reply_to_user_id" : 10187892,
  "text" : "@cgrusden @tsaleh @timocratic or..don\u2019t ;)",
  "id" : 271454971747262464,
  "in_reply_to_status_id" : 271434814576533504,
  "created_at" : "2012-11-22 03:28:03 +0000",
  "in_reply_to_screen_name" : "cgrusden",
  "in_reply_to_user_id_str" : "10187892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271454396498468864",
  "geo" : { },
  "id_str" : "271454892818825217",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting I am. Love it.",
  "id" : 271454892818825217,
  "in_reply_to_status_id" : 271454396498468864,
  "created_at" : "2012-11-22 03:27:44 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271391753511256064",
  "text" : "It's always pretty humbling to be diving around code that's 7+ years old. Being a software mechanic is still fun.",
  "id" : 271391753511256064,
  "created_at" : "2012-11-21 23:16:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 8, 19 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 20, 32 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271349990448824321",
  "geo" : { },
  "id_str" : "271350231319343107",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 @kevinpurdy @jillterreri SKYJAGERBOMBS.",
  "id" : 271350231319343107,
  "in_reply_to_status_id" : 271349990448824321,
  "created_at" : "2012-11-21 20:31:51 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271349669253218304",
  "text" : "Just set up my first AirPort Express. Holy crap, that was magical. Absolutely no configuration.",
  "id" : 271349669253218304,
  "created_at" : "2012-11-21 20:29:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/271332599702626304\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/n1ghvHxf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8P3j9XCIAA91qV.jpg",
      "id_str" : "271332599711014912",
      "id" : 271332599711014912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8P3j9XCIAA91qV.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n1ghvHxf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271332599702626304",
  "text" : "The cops are onto @coworkbuffalo and need to shut down a street and get an expensive portable elevator to use our wifi. http:\/\/t.co\/n1ghvHxf",
  "id" : 271332599702626304,
  "created_at" : "2012-11-21 19:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271324270376935425",
  "geo" : { },
  "id_str" : "271324566087925760",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato Haha, I know it's old. Just preparing myself for the wrath.",
  "id" : 271324566087925760,
  "in_reply_to_status_id" : 271324270376935425,
  "created_at" : "2012-11-21 18:49:52 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 16, 26 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271324016118218752",
  "text" : "Waiting for the @joedamato hate train. It's pulling into station, I can just feel it! HATE HATE HATE HATE HATE HATE HAAAAAATE! ALLL ABOARD!",
  "id" : 271324016118218752,
  "created_at" : "2012-11-21 18:47:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271320482861707265",
  "geo" : { },
  "id_str" : "271323715546005504",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato \"authors of Ruby gems must understand how GC works in the VM to prevent their gems from causing GC to break the universe.\" ...No?",
  "id" : 271323715546005504,
  "in_reply_to_status_id" : 271320482861707265,
  "created_at" : "2012-11-21 18:46:29 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/3Zz1THCL",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/11\/21\/us\/san-francisco-officials-vote-to-ban-public-nudity.html",
      "display_url" : "nytimes.com\/2012\/11\/21\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271308523411996672",
  "text" : "\u201CThe nudity situation in the Castro has become extreme,\u201D Mr. Wiener told his colleagues. - http:\/\/t.co\/3Zz1THCL",
  "id" : 271308523411996672,
  "created_at" : "2012-11-21 17:46:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 0, 7 ],
      "id_str" : "814306",
      "id" : 814306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271307491650977793",
  "geo" : { },
  "id_str" : "271308110172397569",
  "in_reply_to_user_id" : 814306,
  "text" : "@Shella \"\u201CThe nudity situation in the Castro has become extreme,\u201D Mr. Wiener told his colleagues.\"",
  "id" : 271308110172397569,
  "in_reply_to_status_id" : 271307491650977793,
  "created_at" : "2012-11-21 17:44:28 +0000",
  "in_reply_to_screen_name" : "Shella",
  "in_reply_to_user_id_str" : "814306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 3, 9 ],
      "id_str" : "3116191",
      "id" : 3116191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/XLSqAtqo",
      "expanded_url" : "http:\/\/weblog.rubyonrails.org\/2012\/11\/21\/the-people-behind-rails-4\/",
      "display_url" : "weblog.rubyonrails.org\/2012\/11\/21\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271307981218521088",
  "text" : "RT @rails: The People Behind Rails 4 http:\/\/t.co\/XLSqAtqo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/XLSqAtqo",
        "expanded_url" : "http:\/\/weblog.rubyonrails.org\/2012\/11\/21\/the-people-behind-rails-4\/",
        "display_url" : "weblog.rubyonrails.org\/2012\/11\/21\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "271307555878346752",
    "text" : "The People Behind Rails 4 http:\/\/t.co\/XLSqAtqo",
    "id" : 271307555878346752,
    "created_at" : "2012-11-21 17:42:16 +0000",
    "user" : {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "protected" : false,
      "id_str" : "3116191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000296761640\/2e69482e09113a93ccdd109c36f7fca7_normal.png",
      "id" : 3116191,
      "verified" : false
    }
  },
  "id" : 271307981218521088,
  "created_at" : "2012-11-21 17:43:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/4aw7iAiO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sn78IFGVTyc",
      "display_url" : "youtube.com\/watch?v=sn78IF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271293571771019264",
  "text" : "RIP Mr. Food: http:\/\/t.co\/4aw7iAiO",
  "id" : 271293571771019264,
  "created_at" : "2012-11-21 16:46:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/tXOaEyzB",
      "expanded_url" : "http:\/\/www.socialsynergycloudsolutions.com\/",
      "display_url" : "socialsynergycloudsolutions.com"
    } ]
  },
  "geo" : { },
  "id_str" : "271266559295631361",
  "text" : "RT @chorn: If I had to pick just one fast moving super company for 2013, it would be http:\/\/t.co\/tXOaEyzB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/tXOaEyzB",
        "expanded_url" : "http:\/\/www.socialsynergycloudsolutions.com\/",
        "display_url" : "socialsynergycloudsolutions.com"
      } ]
    },
    "geo" : { },
    "id_str" : "271265876450344962",
    "text" : "If I had to pick just one fast moving super company for 2013, it would be http:\/\/t.co\/tXOaEyzB",
    "id" : 271265876450344962,
    "created_at" : "2012-11-21 14:56:39 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 271266559295631361,
  "created_at" : "2012-11-21 14:59:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/WuHYqBS4",
      "expanded_url" : "http:\/\/bukk.it\/omgyay.gif",
      "display_url" : "bukk.it\/omgyay.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "271265452100026368",
  "geo" : { },
  "id_str" : "271265742371033088",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin http:\/\/t.co\/WuHYqBS4",
  "id" : 271265742371033088,
  "in_reply_to_status_id" : 271265452100026368,
  "created_at" : "2012-11-21 14:56:07 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271104466705592320",
  "geo" : { },
  "id_str" : "271105754264633345",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @aquaranto and I will be at CodeMash!",
  "id" : 271105754264633345,
  "in_reply_to_status_id" : 271104466705592320,
  "created_at" : "2012-11-21 04:20:23 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 12, 26 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 31, 40 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271081168902971392",
  "text" : "13 folks at @coworkbuffalo for @openhack tonight. Still pumped for this community\u2019s momentum.",
  "id" : 271081168902971392,
  "created_at" : "2012-11-21 02:42:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 66, 78 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 61 ],
      "url" : "https:\/\/t.co\/j4pbYmbU",
      "expanded_url" : "https:\/\/github.com\/OpenHack\/openhack.github.com\/issues\/59",
      "display_url" : "github.com\/OpenHack\/openh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "271015005787418625",
  "geo" : { },
  "id_str" : "271069697733185536",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn You should have access. Also: https:\/\/t.co\/j4pbYmbU \/cc @bcardarella",
  "id" : 271069697733185536,
  "in_reply_to_status_id" : 271015005787418625,
  "created_at" : "2012-11-21 01:57:06 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 86, 96 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 102, 113 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 114, 122 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271067786304962560",
  "text" : "Looks like only one of the @coworkbuffalo partners doesn't have a dog. Looking at you @magnachef. \/cc @kevinpurdy @fending",
  "id" : 271067786304962560,
  "created_at" : "2012-11-21 01:49:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271067177078108161",
  "text" : "OH: \"I know how books work!\"",
  "id" : 271067177078108161,
  "created_at" : "2012-11-21 01:47:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 0, 9 ],
      "id_str" : "15338379",
      "id" : 15338379
    }, {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 10, 21 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 22, 34 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271036071054295040",
  "geo" : { },
  "id_str" : "271038883620352000",
  "in_reply_to_user_id" : 15338379,
  "text" : "@merissie @joanofdark @rocketslide yes, this is happening. Details forthcoming. Be prepared for airbnb chilling + puppy.",
  "id" : 271038883620352000,
  "in_reply_to_status_id" : 271036071054295040,
  "created_at" : "2012-11-20 23:54:40 +0000",
  "in_reply_to_screen_name" : "merissie",
  "in_reply_to_user_id_str" : "15338379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 59 ],
      "url" : "https:\/\/t.co\/PJehNsIK",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/ruby-build#20121120",
      "display_url" : "github.com\/sstephenson\/ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271021567671169024",
  "text" : "RT @sstephenson: ruby-build 20121120: https:\/\/t.co\/PJehNsIK \u2014 Now with super fast downloads.\n\nHappy Thanksgiving! Give thanks to a Ruby  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 42 ],
        "url" : "https:\/\/t.co\/PJehNsIK",
        "expanded_url" : "https:\/\/github.com\/sstephenson\/ruby-build#20121120",
        "display_url" : "github.com\/sstephenson\/ru\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "271006435587010560",
    "text" : "ruby-build 20121120: https:\/\/t.co\/PJehNsIK \u2014 Now with super fast downloads.\n\nHappy Thanksgiving! Give thanks to a Ruby maintainer this week.",
    "id" : 271006435587010560,
    "created_at" : "2012-11-20 21:45:43 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 271021567671169024,
  "created_at" : "2012-11-20 22:45:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 122, 134 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271015005787418625",
  "geo" : { },
  "id_str" : "271020299854692352",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn I'll add you tonight. Maybe I'll write up some scripts to automate this process so we dont miss anyone else \/cc @bcardarella",
  "id" : 271020299854692352,
  "in_reply_to_status_id" : 271015005787418625,
  "created_at" : "2012-11-20 22:40:49 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 3, 14 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 47, 53 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 54, 64 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271020004013637633",
  "text" : "RT @joanofdark: Operation: Puppy Drop is a go! @qrush @aquaranto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 31, 37 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 38, 48 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271019877857390593",
    "text" : "Operation: Puppy Drop is a go! @qrush @aquaranto",
    "id" : 271019877857390593,
    "created_at" : "2012-11-20 22:39:08 +0000",
    "user" : {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "protected" : false,
      "id_str" : "12734002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52337868\/76195_normal.jpeg",
      "id" : 12734002,
      "verified" : false
    }
  },
  "id" : 271020004013637633,
  "created_at" : "2012-11-20 22:39:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 49, 56 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/EzraZTle",
      "expanded_url" : "http:\/\/github.com\/37signals\/api",
      "display_url" : "github.com\/37signals\/api"
    }, {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/4bDZWhUt",
      "expanded_url" : "http:\/\/zachholman.com\/talk\/open-source-misfeasance",
      "display_url" : "zachholman.com\/talk\/open-sour\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271014568489283584",
  "text" : "Woot! http:\/\/t.co\/EzraZTle makes an apperance in @holman's talk: http:\/\/t.co\/4bDZWhUt &lt;3 &lt;3",
  "id" : 271014568489283584,
  "created_at" : "2012-11-20 22:18:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271012145142050817",
  "geo" : { },
  "id_str" : "271012961588494336",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn You should have access to the main repo, once you've been added as a city. Are you not on it?",
  "id" : 271012961588494336,
  "in_reply_to_status_id" : 271012145142050817,
  "created_at" : "2012-11-20 22:11:39 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270997913738571776",
  "text" : "I can't even handle focusing when Dragonforce is playing. Too much shredding.",
  "id" : 270997913738571776,
  "created_at" : "2012-11-20 21:11:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270996919747215361",
  "geo" : { },
  "id_str" : "270997408010362881",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg the EST range is huge. Still light on this end of it :)",
  "id" : 270997408010362881,
  "in_reply_to_status_id" : 270996919747215361,
  "created_at" : "2012-11-20 21:09:51 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/08aEXDks",
      "expanded_url" : "http:\/\/robrhinehart.com\/?p=119",
      "display_url" : "robrhinehart.com\/?p=119"
    } ]
  },
  "geo" : { },
  "id_str" : "270987495930462208",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense finally, a musical version to go along with http:\/\/t.co\/08aEXDks",
  "id" : 270987495930462208,
  "created_at" : "2012-11-20 20:30:28 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270980880674205696",
  "geo" : { },
  "id_str" : "270981035007803393",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu Definitely is not. there's a lot of these for many cities.",
  "id" : 270981035007803393,
  "in_reply_to_status_id" : 270980880674205696,
  "created_at" : "2012-11-20 20:04:47 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Beasley",
      "screen_name" : "MikeBeas",
      "indices" : [ 3, 12 ],
      "id_str" : "318393568",
      "id" : 318393568
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 14, 26 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270980022632857600",
  "text" : "RT @MikeBeas: @SteveStreza \u201CPSY, what do we do with our gifts?\u201D\n\n\u201COpen... Gangnam style.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Streza",
        "screen_name" : "SteveStreza",
        "indices" : [ 0, 12 ],
        "id_str" : "658643",
        "id" : 658643
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "270966583290118144",
    "geo" : { },
    "id_str" : "270966736738713600",
    "in_reply_to_user_id" : 658643,
    "text" : "@SteveStreza \u201CPSY, what do we do with our gifts?\u201D\n\n\u201COpen... Gangnam style.\u201D",
    "id" : 270966736738713600,
    "in_reply_to_status_id" : 270966583290118144,
    "created_at" : "2012-11-20 19:07:59 +0000",
    "in_reply_to_screen_name" : "SteveStreza",
    "in_reply_to_user_id_str" : "658643",
    "user" : {
      "name" : "Mike Beasley",
      "screen_name" : "MikeBeas",
      "protected" : false,
      "id_str" : "318393568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564627094609866755\/NE21kBug_normal.jpeg",
      "id" : 318393568,
      "verified" : false
    }
  },
  "id" : 270980022632857600,
  "created_at" : "2012-11-20 20:00:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/4OO1mgSf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v1PBptSDIh8",
      "display_url" : "youtube.com\/watch?v=v1PBpt\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270978878330253312",
  "geo" : { },
  "id_str" : "270979506603438080",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench @aquaranto what a troll http:\/\/t.co\/4OO1mgSf",
  "id" : 270979506603438080,
  "in_reply_to_status_id" : 270978878330253312,
  "created_at" : "2012-11-20 19:58:43 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/3TGlNveU",
      "expanded_url" : "http:\/\/turntable.fm\/ey_remote",
      "display_url" : "turntable.fm\/ey_remote"
    } ]
  },
  "geo" : { },
  "id_str" : "270977948058804224",
  "text" : "DJing in the EY - Remote room. Now playing DJ abSRD #turntablefm http:\/\/t.co\/3TGlNveU",
  "id" : 270977948058804224,
  "created_at" : "2012-11-20 19:52:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270968887036764161",
  "text" : "That was fun: Kids at the programming class flew through my content. Started doing &lt;canvas&gt; stuff, which works in IE9. So awesome.",
  "id" : 270968887036764161,
  "created_at" : "2012-11-20 19:16:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270927675739217921",
  "geo" : { },
  "id_str" : "270930163787771904",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan Thanks dude.",
  "id" : 270930163787771904,
  "in_reply_to_status_id" : 270927675739217921,
  "created_at" : "2012-11-20 16:42:39 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 65 ],
      "url" : "https:\/\/t.co\/Phd5XMwv",
      "expanded_url" : "https:\/\/www.gittip.com\/qrush",
      "display_url" : "gittip.com\/qrush"
    } ]
  },
  "in_reply_to_status_id_str" : "270924264826347521",
  "geo" : { },
  "id_str" : "270927260855435265",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan I'm on gittip, does that count? https:\/\/t.co\/Phd5XMwv",
  "id" : 270927260855435265,
  "in_reply_to_status_id" : 270924264826347521,
  "created_at" : "2012-11-20 16:31:07 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270923563521941504",
  "geo" : { },
  "id_str" : "270923906955743233",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan I have a paypal? Haven't signed up for that yet.",
  "id" : 270923906955743233,
  "in_reply_to_status_id" : 270923563521941504,
  "created_at" : "2012-11-20 16:17:47 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 59, 68 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270917957675257857",
  "text" : "I've gotten no responses from local sponsors for tonight's @OpenHack in Buffalo. Anyone out there willing to donate money for pizza\/beer? :)",
  "id" : 270917957675257857,
  "created_at" : "2012-11-20 15:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270904622825213952",
  "text" : "Has anyone bought used Mac stuff off Amazon? The prices are way cheaper...",
  "id" : 270904622825213952,
  "created_at" : "2012-11-20 15:01:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian G\u00F6ttschkes",
      "screen_name" : "Sgoettschkes",
      "indices" : [ 3, 16 ],
      "id_str" : "62806594",
      "id" : 62806594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/IV3LJj9L",
      "expanded_url" : "http:\/\/bit.ly\/Qnt0Aq",
      "display_url" : "bit.ly\/Qnt0Aq"
    } ]
  },
  "geo" : { },
  "id_str" : "270778397817442305",
  "text" : "RT @Sgoettschkes: New blog post: Using 37signals\/sub inside a vagrant virtual machine http:\/\/t.co\/IV3LJj9L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/IV3LJj9L",
        "expanded_url" : "http:\/\/bit.ly\/Qnt0Aq",
        "display_url" : "bit.ly\/Qnt0Aq"
      } ]
    },
    "geo" : { },
    "id_str" : "270238066134900736",
    "text" : "New blog post: Using 37signals\/sub inside a vagrant virtual machine http:\/\/t.co\/IV3LJj9L",
    "id" : 270238066134900736,
    "created_at" : "2012-11-18 18:52:30 +0000",
    "user" : {
      "name" : "Sebastian G\u00F6ttschkes",
      "screen_name" : "Sgoettschkes",
      "protected" : false,
      "id_str" : "62806594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2203745595\/sebi_klein_normal.jpg",
      "id" : 62806594,
      "verified" : false
    }
  },
  "id" : 270778397817442305,
  "created_at" : "2012-11-20 06:39:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270745433284947969",
  "text" : "Alright it\u2019s time to get new routers. Any suggestions for a good one that will cover an entire house?",
  "id" : 270745433284947969,
  "created_at" : "2012-11-20 04:28:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270744767434985473",
  "text" : "Granted, it took longer than the 8 minutes so I tried power cycling it. Now reboots itself every 20 secs. &gt;:(",
  "id" : 270744767434985473,
  "created_at" : "2012-11-20 04:25:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270744237073657856",
  "text" : "Tried to update my old router\u2019s firmware and bricked it. Not happy about this.",
  "id" : 270744237073657856,
  "created_at" : "2012-11-20 04:23:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 7, 15 ],
      "id_str" : "32317282",
      "id" : 32317282
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 16, 28 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270701033225867264",
  "geo" : { },
  "id_str" : "270701163043778561",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @dunalar @ecarlsen912 also my router is stupid, sorry no voice. \/cc @dhiggsbuf",
  "id" : 270701163043778561,
  "in_reply_to_status_id" : 270701033225867264,
  "created_at" : "2012-11-20 01:32:41 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 15, 23 ],
      "id_str" : "32317282",
      "id" : 32317282
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 26, 38 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270701033225867264",
  "text" : "Very glad that @dunalar \/ @ecarlsen912 and myself are the only ones brave enough to wear pink armor in Halo.",
  "id" : 270701033225867264,
  "created_at" : "2012-11-20 01:32:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Loewenherz",
      "screen_name" : "dwlz",
      "indices" : [ 3, 8 ],
      "id_str" : "17824785",
      "id" : 17824785
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 36, 47 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270695002554920960",
  "text" : "RT @dwlz: I highly recommend giving @RubyMotion a shot if you want to start developing for iOS. Unparalleled support (truly!) and fantas ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 26, 37 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270688142019936257",
    "text" : "I highly recommend giving @RubyMotion a shot if you want to start developing for iOS. Unparalleled support (truly!) and fantastic toolchain.",
    "id" : 270688142019936257,
    "created_at" : "2012-11-20 00:40:56 +0000",
    "user" : {
      "name" : "Dan Loewenherz",
      "screen_name" : "dwlz",
      "protected" : false,
      "id_str" : "17824785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476895691521142785\/ZZUZJ866_normal.jpeg",
      "id" : 17824785,
      "verified" : false
    }
  },
  "id" : 270695002554920960,
  "created_at" : "2012-11-20 01:08:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270659647885684736",
  "text" : "I'm going to power through using the twitter website and not setting a header photo. Closed the dialog 3 times already today.",
  "id" : 270659647885684736,
  "created_at" : "2012-11-19 22:47:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Diaz",
      "screen_name" : "alycit",
      "indices" : [ 0, 7 ],
      "id_str" : "14164414",
      "id" : 14164414
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 8, 20 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270637740750692352",
  "geo" : { },
  "id_str" : "270641674391285760",
  "in_reply_to_user_id" : 14164414,
  "text" : "@alycit @juliepagano maybe this time @aquaranto won't skip it!",
  "id" : 270641674391285760,
  "in_reply_to_status_id" : 270637740750692352,
  "created_at" : "2012-11-19 21:36:18 +0000",
  "in_reply_to_screen_name" : "alycit",
  "in_reply_to_user_id_str" : "14164414",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 3, 12 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/Km4smqt2",
      "expanded_url" : "http:\/\/jezebel.com\/5961702\/revenge-of-the-nerds-white-male-geeks-hack-sexism-racism",
      "display_url" : "jezebel.com\/5961702\/reveng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270641546561474561",
  "text" : "RT @konklone: BritRuby hits Jezebel: http:\/\/t.co\/Km4smqt2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/Km4smqt2",
        "expanded_url" : "http:\/\/jezebel.com\/5961702\/revenge-of-the-nerds-white-male-geeks-hack-sexism-racism",
        "display_url" : "jezebel.com\/5961702\/reveng\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270641000546963456",
    "text" : "BritRuby hits Jezebel: http:\/\/t.co\/Km4smqt2",
    "id" : 270641000546963456,
    "created_at" : "2012-11-19 21:33:37 +0000",
    "user" : {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "protected" : false,
      "id_str" : "5232171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226668113\/blue_normal.png",
      "id" : 5232171,
      "verified" : false
    }
  },
  "id" : 270641546561474561,
  "created_at" : "2012-11-19 21:35:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 3, 12 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gitclone",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "destroyerofinternets",
      "indices" : [ 117, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/4I4To4OB",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "270641530975420416",
  "text" : "RT @schneems: I feel bad for everyone else in this coffee shop\u2026 i\u2019m cloning the http:\/\/t.co\/4I4To4OB repo. #gitclone #destroyerofinternets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gitclone",
        "indices" : [ 93, 102 ]
      }, {
        "text" : "destroyerofinternets",
        "indices" : [ 103, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/4I4To4OB",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "270641342391132161",
    "text" : "I feel bad for everyone else in this coffee shop\u2026 i\u2019m cloning the http:\/\/t.co\/4I4To4OB repo. #gitclone #destroyerofinternets",
    "id" : 270641342391132161,
    "created_at" : "2012-11-19 21:34:58 +0000",
    "user" : {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "protected" : false,
      "id_str" : "23621187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475413152838848512\/fTOESg1A_normal.jpeg",
      "id" : 23621187,
      "verified" : false
    }
  },
  "id" : 270641530975420416,
  "created_at" : "2012-11-19 21:35:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 14, 21 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 22, 38 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270616002734215171",
  "geo" : { },
  "id_str" : "270623580784578560",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @hone02 @rubygems_status Happening again, right now.",
  "id" : 270623580784578560,
  "in_reply_to_status_id" : 270616002734215171,
  "created_at" : "2012-11-19 20:24:24 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    }, {
      "name" : "LabGrrl",
      "screen_name" : "labgrrl",
      "indices" : [ 15, 23 ],
      "id_str" : "14457223",
      "id" : 14457223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270616645733588992",
  "geo" : { },
  "id_str" : "270616907349127169",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky @labgrrl \u0CA0_\u0CA0",
  "id" : 270616907349127169,
  "in_reply_to_status_id" : 270616645733588992,
  "created_at" : "2012-11-19 19:57:53 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LabGrrl",
      "screen_name" : "labgrrl",
      "indices" : [ 0, 8 ],
      "id_str" : "14457223",
      "id" : 14457223
    }, {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 9, 23 ],
      "id_str" : "16930130",
      "id" : 16930130
    }, {
      "name" : "SWBuffalo",
      "screen_name" : "SWBuffalo",
      "indices" : [ 46, 56 ],
      "id_str" : "611972038",
      "id" : 611972038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/rrMUchau",
      "expanded_url" : "http:\/\/buffalo.startupweekend.org\/blog\/",
      "display_url" : "buffalo.startupweekend.org\/blog\/"
    } ]
  },
  "in_reply_to_status_id_str" : "270615787654483968",
  "geo" : { },
  "id_str" : "270616479844691968",
  "in_reply_to_user_id" : 14457223,
  "text" : "@labgrrl @PhilDarnowsky not to be a jerk, but @SWBuffalo was this weekend and it was awesome. http:\/\/t.co\/rrMUchau",
  "id" : 270616479844691968,
  "in_reply_to_status_id" : 270615787654483968,
  "created_at" : "2012-11-19 19:56:11 +0000",
  "in_reply_to_screen_name" : "labgrrl",
  "in_reply_to_user_id_str" : "14457223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 14, 30 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 31, 38 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/LahemjM4",
      "expanded_url" : "http:\/\/status.rubygems.org\/",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "270613081946718208",
  "geo" : { },
  "id_str" : "270614778676928514",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @rubygems_status @hone02 Looks up now? http:\/\/t.co\/LahemjM4",
  "id" : 270614778676928514,
  "in_reply_to_status_id" : 270613081946718208,
  "created_at" : "2012-11-19 19:49:25 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 14, 30 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 31, 38 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/LahemjM4",
      "expanded_url" : "http:\/\/status.rubygems.org\/",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "270613081946718208",
  "geo" : { },
  "id_str" : "270614153603993600",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @rubygems_status @hone02 looks like it :( http:\/\/t.co\/LahemjM4",
  "id" : 270614153603993600,
  "in_reply_to_status_id" : 270613081946718208,
  "created_at" : "2012-11-19 19:46:56 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QvcPEqzr",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2012\/11\/october-temperatures-warm\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270610097774931969",
  "text" : "RT @edyong209: If you're 27 or younger, you\u2019ve never experienced a month when the global temp was colder than the 20thC average http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/QvcPEqzr",
        "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2012\/11\/october-temperatures-warm\/",
        "display_url" : "wired.com\/wiredscience\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270608185528832001",
    "text" : "If you're 27 or younger, you\u2019ve never experienced a month when the global temp was colder than the 20thC average http:\/\/t.co\/QvcPEqzr",
    "id" : 270608185528832001,
    "created_at" : "2012-11-19 19:23:13 +0000",
    "user" : {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551081327240290304\/42JbmjR4_normal.jpeg",
      "id" : 19767193,
      "verified" : false
    }
  },
  "id" : 270610097774931969,
  "created_at" : "2012-11-19 19:30:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 9, 18 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 19, 30 ],
      "id_str" : "403807816",
      "id" : 403807816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270601098098794496",
  "geo" : { },
  "id_str" : "270601140784214016",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright @openhack @seedcowork Woot!!",
  "id" : 270601140784214016,
  "in_reply_to_status_id" : 270601098098794496,
  "created_at" : "2012-11-19 18:55:14 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270600013648896002",
  "geo" : { },
  "id_str" : "270600659764670465",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser \"Why are they only serving white meat at this Thanksgiving dinner!?\"",
  "id" : 270600659764670465,
  "in_reply_to_status_id" : 270600013648896002,
  "created_at" : "2012-11-19 18:53:19 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 3, 14 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270600386551881729",
  "text" : "RT @joshsusser: Going to try tweeting again today. Hoping I don't accidentally destroy Thanksgiving.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270600013648896002",
    "text" : "Going to try tweeting again today. Hoping I don't accidentally destroy Thanksgiving.",
    "id" : 270600013648896002,
    "created_at" : "2012-11-19 18:50:45 +0000",
    "user" : {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "protected" : false,
      "id_str" : "35954885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502547892230316032\/njGJleCw_normal.png",
      "id" : 35954885,
      "verified" : false
    }
  },
  "id" : 270600386551881729,
  "created_at" : "2012-11-19 18:52:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kat",
      "screen_name" : "wirehead2501",
      "indices" : [ 0, 13 ],
      "id_str" : "11797632",
      "id" : 11797632
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 14, 25 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270590142689984513",
  "geo" : { },
  "id_str" : "270591819560132608",
  "in_reply_to_user_id" : 11797632,
  "text" : "@wirehead2501 @ashedryden yay! I bet @aquaranto would have some advice :)",
  "id" : 270591819560132608,
  "in_reply_to_status_id" : 270590142689984513,
  "created_at" : "2012-11-19 18:18:11 +0000",
  "in_reply_to_screen_name" : "wirehead2501",
  "in_reply_to_user_id_str" : "11797632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    }, {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 8, 14 ],
      "id_str" : "8605362",
      "id" : 8605362
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 15, 25 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270560517498736640",
  "geo" : { },
  "id_str" : "270560696050278400",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc @keavy @listrophy this looks dead",
  "id" : 270560696050278400,
  "in_reply_to_status_id" : 270560517498736640,
  "created_at" : "2012-11-19 16:14:31 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 82, 92 ],
      "id_str" : "1942",
      "id" : 1942
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 93, 106 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/d2XUosaQ",
      "expanded_url" : "http:\/\/lanyrd.com\/topics\/ruby\/",
      "display_url" : "lanyrd.com\/topics\/ruby\/"
    } ]
  },
  "geo" : { },
  "id_str" : "270560326813093889",
  "text" : "Is there a better calendar of upcoming Ruby confs than http:\/\/t.co\/d2XUosaQ ? \/cc @jremsikjr @steveklabnik",
  "id" : 270560326813093889,
  "created_at" : "2012-11-19 16:13:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Toledo",
      "screen_name" : "OpenHackToledo",
      "indices" : [ 3, 18 ],
      "id_str" : "933463981",
      "id" : 933463981
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 51, 60 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Seed Coworking",
      "screen_name" : "seedcowork",
      "indices" : [ 77, 88 ],
      "id_str" : "403807816",
      "id" : 403807816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270551726547935232",
  "text" : "RT @OpenHackToledo: Tonight\u2019s the night, the first @openhack in Toledo is at @seedcowork from 6pm - 10pm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 31, 40 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "Seed Coworking",
        "screen_name" : "seedcowork",
        "indices" : [ 57, 68 ],
        "id_str" : "403807816",
        "id" : 403807816
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270530042860294144",
    "text" : "Tonight\u2019s the night, the first @openhack in Toledo is at @seedcowork from 6pm - 10pm.",
    "id" : 270530042860294144,
    "created_at" : "2012-11-19 14:12:43 +0000",
    "user" : {
      "name" : "OpenHack Toledo",
      "screen_name" : "OpenHackToledo",
      "protected" : false,
      "id_str" : "933463981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2828186151\/e5fb61c347cb5887e886b8392207f55e_normal.png",
      "id" : 933463981,
      "verified" : false
    }
  },
  "id" : 270551726547935232,
  "created_at" : "2012-11-19 15:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 17, 26 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/FuKESQLZ",
      "expanded_url" : "http:\/\/openhack.github.com\/buffalo\/",
      "display_url" : "openhack.github.com\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "270546352486875136",
  "text" : "Officially at 30 @OpenHack cities on 4 continents! Which reminds me, Buffalo's meetup is tomorrow: http:\/\/t.co\/FuKESQLZ",
  "id" : 270546352486875136,
  "created_at" : "2012-11-19 15:17:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devdatta Kane",
      "screen_name" : "devdatta",
      "indices" : [ 0, 9 ],
      "id_str" : "14257769",
      "id" : 14257769
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 115, 123 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/3nRhWYRt",
      "expanded_url" : "http:\/\/status.aws.amazon.com\/",
      "display_url" : "status.aws.amazon.com"
    } ]
  },
  "in_reply_to_status_id_str" : "270510180410720258",
  "geo" : { },
  "id_str" : "270545912705732609",
  "in_reply_to_user_id" : 14257769,
  "text" : "@devdatta seeing nothing on NewRelic, and http:\/\/t.co\/3nRhWYRt is reporting no errors. maybe refresh your DNS? \/cc @evanphx",
  "id" : 270545912705732609,
  "in_reply_to_status_id" : 270510180410720258,
  "created_at" : "2012-11-19 15:15:46 +0000",
  "in_reply_to_screen_name" : "devdatta",
  "in_reply_to_user_id_str" : "14257769",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "indices" : [ 3, 13 ],
      "id_str" : "47494539",
      "id" : 47494539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270522516420841472",
  "text" : "RT @kellabyte: We make a lot of money in this industry. How about some conference sponsors sponsor a high school programming class to at ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270488152291045376",
    "text" : "We make a lot of money in this industry. How about some conference sponsors sponsor a high school programming class to attend a conference?",
    "id" : 270488152291045376,
    "created_at" : "2012-11-19 11:26:15 +0000",
    "user" : {
      "name" : "Kelly Sommers",
      "screen_name" : "kellabyte",
      "protected" : false,
      "id_str" : "47494539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2808005971\/b81b99287e78b1cd6cbd0e5cbfb3295c_normal.png",
      "id" : 47494539,
      "verified" : false
    }
  },
  "id" : 270522516420841472,
  "created_at" : "2012-11-19 13:42:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devdatta Kane",
      "screen_name" : "devdatta",
      "indices" : [ 0, 9 ],
      "id_str" : "14257769",
      "id" : 14257769
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 89, 97 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 98, 108 ],
      "id_str" : "15031577",
      "id" : 15031577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270510180410720258",
  "geo" : { },
  "id_str" : "270515685380210688",
  "in_reply_to_user_id" : 14257769,
  "text" : "@devdatta no downtime alerts here. I won\u2019t be able to check anything until 10am EST. \/cc @evanphx @tcopeland",
  "id" : 270515685380210688,
  "in_reply_to_status_id" : 270510180410720258,
  "created_at" : "2012-11-19 13:15:39 +0000",
  "in_reply_to_screen_name" : "devdatta",
  "in_reply_to_user_id_str" : "14257769",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/79bpXVLK",
      "expanded_url" : "http:\/\/ow.ly\/fogiA",
      "display_url" : "ow.ly\/fogiA"
    } ]
  },
  "geo" : { },
  "id_str" : "270364402149122048",
  "text" : "RT @avdi: \/r\/ruby: where a reasoned response from a giant in the community gets downvoted into oblivion. http:\/\/t.co\/79bpXVLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/79bpXVLK",
        "expanded_url" : "http:\/\/ow.ly\/fogiA",
        "display_url" : "ow.ly\/fogiA"
      } ]
    },
    "geo" : { },
    "id_str" : "270362895097925632",
    "text" : "\/r\/ruby: where a reasoned response from a giant in the community gets downvoted into oblivion. http:\/\/t.co\/79bpXVLK",
    "id" : 270362895097925632,
    "created_at" : "2012-11-19 03:08:31 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 270364402149122048,
  "created_at" : "2012-11-19 03:14:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ElisabethHendrickson",
      "screen_name" : "testobsessed",
      "indices" : [ 3, 16 ],
      "id_str" : "12614742",
      "id" : 12614742
    }, {
      "name" : "Britruby",
      "screen_name" : "britruby",
      "indices" : [ 49, 58 ],
      "id_str" : "1117452871",
      "id" : 1117452871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/tpfreE9E",
      "expanded_url" : "http:\/\/testobsessed.com\/2012\/11\/diverse-discussions\/",
      "display_url" : "testobsessed.com\/2012\/11\/divers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270352339276275713",
  "text" : "RT @testobsessed: In which I too weigh in on the @BritRuby thing. But probably not to say what you think I'm gonna say. http:\/\/t.co\/tpfreE9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Britruby",
        "screen_name" : "britruby",
        "indices" : [ 31, 40 ],
        "id_str" : "1117452871",
        "id" : 1117452871
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/tpfreE9E",
        "expanded_url" : "http:\/\/testobsessed.com\/2012\/11\/diverse-discussions\/",
        "display_url" : "testobsessed.com\/2012\/11\/divers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270351144402964480",
    "text" : "In which I too weigh in on the @BritRuby thing. But probably not to say what you think I'm gonna say. http:\/\/t.co\/tpfreE9E",
    "id" : 270351144402964480,
    "created_at" : "2012-11-19 02:21:50 +0000",
    "user" : {
      "name" : "ElisabethHendrickson",
      "screen_name" : "testobsessed",
      "protected" : false,
      "id_str" : "12614742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000537974783\/0aca696fb71add94d8a153da8a37cc34_normal.jpeg",
      "id" : 12614742,
      "verified" : false
    }
  },
  "id" : 270352339276275713,
  "created_at" : "2012-11-19 02:26:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/YSEiM7yj",
      "expanded_url" : "http:\/\/www.useit.com\/alertbox\/windows-8.html",
      "display_url" : "useit.com\/alertbox\/windo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270352033222119424",
  "text" : "\"a tortured soul hoping for redemption\" \" \"a monster that [...] strangles their productivity\" http:\/\/t.co\/YSEiM7yj",
  "id" : 270352033222119424,
  "created_at" : "2012-11-19 02:25:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270241529124253696",
  "geo" : { },
  "id_str" : "270339113360691201",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Hoping to make it happen, capn.",
  "id" : 270339113360691201,
  "in_reply_to_status_id" : 270241529124253696,
  "created_at" : "2012-11-19 01:34:01 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/RD2zIuyd",
      "expanded_url" : "http:\/\/ashedryden.com\/blog\/so-you-want-to-put-on-a-diverse-inclusive-conference",
      "display_url" : "ashedryden.com\/blog\/so-you-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270305283702669313",
  "text" : "RT @ashedryden: So You Want to Put on a Diverse, Inclusive Conference: http:\/\/t.co\/RD2zIuyd (finally back up, sorry about that!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/RD2zIuyd",
        "expanded_url" : "http:\/\/ashedryden.com\/blog\/so-you-want-to-put-on-a-diverse-inclusive-conference",
        "display_url" : "ashedryden.com\/blog\/so-you-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270300516897128449",
    "text" : "So You Want to Put on a Diverse, Inclusive Conference: http:\/\/t.co\/RD2zIuyd (finally back up, sorry about that!)",
    "id" : 270300516897128449,
    "created_at" : "2012-11-18 23:00:39 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 270305283702669313,
  "created_at" : "2012-11-18 23:19:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britruby",
      "screen_name" : "britruby",
      "indices" : [ 4, 13 ],
      "id_str" : "1117452871",
      "id" : 1117452871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270236106937749504",
  "text" : "The @BritRuby scandal has really put a sobering light on this hopeful conference organizer\u2019s line of thinking.",
  "id" : 270236106937749504,
  "created_at" : "2012-11-18 18:44:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270066509278228480",
  "geo" : { },
  "id_str" : "270066887923224576",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg oh, yes it is. See our wonderful footer!",
  "id" : 270066887923224576,
  "in_reply_to_status_id" : 270066509278228480,
  "created_at" : "2012-11-18 07:32:18 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 8, 21 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2amsleeplesstweets",
      "indices" : [ 87, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270065188915515392",
  "geo" : { },
  "id_str" : "270065663958188032",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @steveklabnik what have I stepped into. Yeah, there\u2019s a shitload if JS. Yay!!! #2amsleeplesstweets",
  "id" : 270065663958188032,
  "in_reply_to_status_id" : 270065188915515392,
  "created_at" : "2012-11-18 07:27:26 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270063920809660416",
  "geo" : { },
  "id_str" : "270064547656773632",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik but that all isn\u2019t backbone code either. Man I hate arguments like this.",
  "id" : 270064547656773632,
  "in_reply_to_status_id" : 270063920809660416,
  "created_at" : "2012-11-18 07:23:00 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270063267718766592",
  "geo" : { },
  "id_str" : "270063579359739904",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik how is this even relevant or an apples to apples comparison!?",
  "id" : 270063579359739904,
  "in_reply_to_status_id" : 270063267718766592,
  "created_at" : "2012-11-18 07:19:09 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 76, 86 ],
      "id_str" : "7220202",
      "id" : 7220202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270061992323215360",
  "text" : "Kind of bewildering that RubyGems was down for just Japan for hours. Thanks @a_matsuda for speaking up\u2026we need to add some more alerts.",
  "id" : 270061992323215360,
  "created_at" : "2012-11-18 07:12:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270061736122519552",
  "text" : "RT @rubygems_status: Sorry about the tokyo outage! Linode did a reboot and it didn't come back up properly. Should be fine now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270060471737012224",
    "text" : "Sorry about the tokyo outage! Linode did a reboot and it didn't come back up properly. Should be fine now!",
    "id" : 270060471737012224,
    "created_at" : "2012-11-18 07:06:48 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 270061736122519552,
  "created_at" : "2012-11-18 07:11:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 0, 10 ],
      "id_str" : "7220202",
      "id" : 7220202
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 64, 72 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270046589962293248",
  "geo" : { },
  "id_str" : "270058749069242369",
  "in_reply_to_user_id" : 7220202,
  "text" : "@a_matsuda apparently linode rebooted, something isn\u2019t right :( @evanphx is checking it out.",
  "id" : 270058749069242369,
  "in_reply_to_status_id" : 270046589962293248,
  "created_at" : "2012-11-18 06:59:57 +0000",
  "in_reply_to_screen_name" : "a_matsuda",
  "in_reply_to_user_id_str" : "7220202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270055331445497856",
  "geo" : { },
  "id_str" : "270057397186347010",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant why can\u2019t most Americans choose a which lightbulb to buy?",
  "id" : 270057397186347010,
  "in_reply_to_status_id" : 270055331445497856,
  "created_at" : "2012-11-18 06:54:35 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 0, 10 ],
      "id_str" : "7220202",
      "id" : 7220202
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 58, 66 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270046589962293248",
  "geo" : { },
  "id_str" : "270047976481771520",
  "in_reply_to_user_id" : 7220202,
  "text" : "@a_matsuda not sure\u2026I know little about the mirrors. Ping @evanphx !",
  "id" : 270047976481771520,
  "in_reply_to_status_id" : 270046589962293248,
  "created_at" : "2012-11-18 06:17:09 +0000",
  "in_reply_to_screen_name" : "a_matsuda",
  "in_reply_to_user_id_str" : "7220202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksandr (Sasha) K.",
      "screen_name" : "Arktronic",
      "indices" : [ 3, 13 ],
      "id_str" : "14715126",
      "id" : 14715126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 102 ],
      "url" : "https:\/\/t.co\/3tmi60NT",
      "expanded_url" : "https:\/\/code.google.com\/p\/android\/issues\/detail?id=39692",
      "display_url" : "code.google.com\/p\/android\/issu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270028900799754240",
  "text" : "RT @Arktronic: You're fucking kidding. Android 4.2 calendar app forgot December? https:\/\/t.co\/3tmi60NT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 87 ],
        "url" : "https:\/\/t.co\/3tmi60NT",
        "expanded_url" : "https:\/\/code.google.com\/p\/android\/issues\/detail?id=39692",
        "display_url" : "code.google.com\/p\/android\/issu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269932222545526784",
    "text" : "You're fucking kidding. Android 4.2 calendar app forgot December? https:\/\/t.co\/3tmi60NT",
    "id" : 269932222545526784,
    "created_at" : "2012-11-17 22:37:11 +0000",
    "user" : {
      "name" : "Aleksandr (Sasha) K.",
      "screen_name" : "Arktronic",
      "protected" : false,
      "id_str" : "14715126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617153042\/371908_27300166_509819528_n_normal.jpg",
      "id" : 14715126,
      "verified" : false
    }
  },
  "id" : 270028900799754240,
  "created_at" : "2012-11-18 05:01:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "indices" : [ 0, 10 ],
      "id_str" : "71065878",
      "id" : 71065878
    }, {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 11, 16 ],
      "id_str" : "3374231",
      "id" : 3374231
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 57, 71 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269979631266963456",
  "geo" : { },
  "id_str" : "270028539175264256",
  "in_reply_to_user_id" : 71065878,
  "text" : "@jacknagel @mxcl I believe this was considered back when @joshuaclayton and I were pairing.",
  "id" : 270028539175264256,
  "in_reply_to_status_id" : 269979631266963456,
  "created_at" : "2012-11-18 04:59:55 +0000",
  "in_reply_to_screen_name" : "jacknagel",
  "in_reply_to_user_id_str" : "71065878",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 19, 28 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/270002842834698240\/photo\/1",
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/p9XSgrVy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A78-J6_CAAMCwP0.png",
      "id_str" : "270002842838892547",
      "id" : 270002842838892547,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A78-J6_CAAMCwP0.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/p9XSgrVy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270002842834698240",
  "text" : "Something tells me @migreyes is letterpress trolling. http:\/\/t.co\/p9XSgrVy",
  "id" : 270002842834698240,
  "created_at" : "2012-11-18 03:17:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Watson",
      "screen_name" : "rebeccawatson",
      "indices" : [ 0, 14 ],
      "id_str" : "14188985",
      "id" : 14188985
    }, {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 15, 24 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269926632708517888",
  "geo" : { },
  "id_str" : "269951200512851968",
  "in_reply_to_user_id" : 14188985,
  "text" : "@rebeccawatson @Sigafoos I know you\u2019re just catching up, but the NF Reporter is just one small way NF is really, really, really messed up :(",
  "id" : 269951200512851968,
  "in_reply_to_status_id" : 269926632708517888,
  "created_at" : "2012-11-17 23:52:36 +0000",
  "in_reply_to_screen_name" : "rebeccawatson",
  "in_reply_to_user_id_str" : "14188985",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/269886284581969920\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/fXoQAU5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A77UJVrCIAAaCKm.png",
      "id_str" : "269886284590358528",
      "id" : 269886284590358528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A77UJVrCIAAaCKm.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/fXoQAU5R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269886284581969920",
  "text" : "Letterpress\u2019 update log is amazing. http:\/\/t.co\/fXoQAU5R",
  "id" : 269886284581969920,
  "created_at" : "2012-11-17 19:34:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 7, 16 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269635230992838656",
  "geo" : { },
  "id_str" : "269636627599605760",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @migreyes and a GeelWonder troll! \/play trololo",
  "id" : 269636627599605760,
  "in_reply_to_status_id" : 269635230992838656,
  "created_at" : "2012-11-17 03:02:36 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 23, 32 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/8brjlf5H",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3297-a-case-for-clarity-in-feedback",
      "display_url" : "37signals.com\/svn\/posts\/3297\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269635230992838656",
  "text" : "Clarity in feedback: a @migreyes classic, starring my horrible feedback. http:\/\/t.co\/8brjlf5H",
  "id" : 269635230992838656,
  "created_at" : "2012-11-17 02:57:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269533674222002177",
  "geo" : { },
  "id_str" : "269534001126055936",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette Experience bij.",
  "id" : 269534001126055936,
  "in_reply_to_status_id" : 269533674222002177,
  "created_at" : "2012-11-16 20:14:48 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269530685675556864",
  "geo" : { },
  "id_str" : "269530843981156352",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @kevinpurdy YESSSSSSSSSSSSS",
  "id" : 269530843981156352,
  "in_reply_to_status_id" : 269530685675556864,
  "created_at" : "2012-11-16 20:02:15 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 14, 25 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269522835192557568",
  "text" : "Woot, another @RubyMotion patch accepted. I have to say, the team behind it is great.",
  "id" : 269522835192557568,
  "created_at" : "2012-11-16 19:30:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/8grDpjQN",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2012\/11\/secret-buffalos-farm-table-culture\/3880\/",
      "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269492656827142144",
  "text" : "\"In Buffalo, we say that everyone has two jobs, it\u2019s just that one usually isn\u2019t paid.\" http:\/\/t.co\/8grDpjQN",
  "id" : 269492656827142144,
  "created_at" : "2012-11-16 17:30:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Robinson",
      "screen_name" : "_rbsn",
      "indices" : [ 0, 6 ],
      "id_str" : "2160164963",
      "id" : 2160164963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269183474898972672",
  "text" : "@_rbsn merge early and often.",
  "id" : 269183474898972672,
  "created_at" : "2012-11-15 21:01:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269144574042202113",
  "geo" : { },
  "id_str" : "269146189465808896",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape BOOTS!",
  "id" : 269146189465808896,
  "in_reply_to_status_id" : 269144574042202113,
  "created_at" : "2012-11-15 18:33:46 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Robinson",
      "screen_name" : "_rbsn",
      "indices" : [ 0, 6 ],
      "id_str" : "2160164963",
      "id" : 2160164963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269145690230386690",
  "text" : "@_rbsn There's 22275 on master now, around 39 commits per day average since the repo started.",
  "id" : 269145690230386690,
  "created_at" : "2012-11-15 18:31:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 28, 37 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269143364606255104",
  "geo" : { },
  "id_str" : "269144034168160256",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape Hell yes! When? @openhack is Tuesday night.",
  "id" : 269144034168160256,
  "in_reply_to_status_id" : 269143364606255104,
  "created_at" : "2012-11-15 18:25:12 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "269141986999693312",
  "text" : "DJing in the CoworkBuffalo room. #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 269141986999693312,
  "created_at" : "2012-11-15 18:17:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Robinson",
      "screen_name" : "_rbsn",
      "indices" : [ 0, 6 ],
      "id_str" : "2160164963",
      "id" : 2160164963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269141335355830274",
  "text" : "@_rbsn it's pretty wild :)",
  "id" : 269141335355830274,
  "created_at" : "2012-11-15 18:14:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "269097541549821952",
  "text" : "DJing in the CoworkBuffalo room. Now playing Strong Bad vs Rammstein: The System is Du (DJ Defekt mix) \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 269097541549821952,
  "created_at" : "2012-11-15 15:20:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269071176523984896",
  "geo" : { },
  "id_str" : "269071712467959808",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano won\u2019t be at the game until 5 at least. Crazy that folks will be there all day.",
  "id" : 269071712467959808,
  "in_reply_to_status_id" : 269071176523984896,
  "created_at" : "2012-11-15 13:37:50 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Stack",
      "screen_name" : "richardkstack",
      "indices" : [ 0, 14 ],
      "id_str" : "26840419",
      "id" : 26840419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268960967646400513",
  "geo" : { },
  "id_str" : "268963140669153280",
  "in_reply_to_user_id" : 26840419,
  "text" : "@richardkstack Go OpenGL on iOS or just straight canvas\/HTML5. Choose open, not closed and decaying :)",
  "id" : 268963140669153280,
  "in_reply_to_status_id" : 268960967646400513,
  "created_at" : "2012-11-15 06:26:24 +0000",
  "in_reply_to_screen_name" : "richardkstack",
  "in_reply_to_user_id_str" : "26840419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Stack",
      "screen_name" : "richardkstack",
      "indices" : [ 0, 14 ],
      "id_str" : "26840419",
      "id" : 26840419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268954513279422464",
  "geo" : { },
  "id_str" : "268959392030932992",
  "in_reply_to_user_id" : 26840419,
  "text" : "@richardkstack neither?",
  "id" : 268959392030932992,
  "in_reply_to_status_id" : 268954513279422464,
  "created_at" : "2012-11-15 06:11:30 +0000",
  "in_reply_to_screen_name" : "richardkstack",
  "in_reply_to_user_id_str" : "26840419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 48 ],
      "url" : "https:\/\/t.co\/J9I5GGun",
      "expanded_url" : "https:\/\/github.com\/rails\/rails\/pull\/8222\/files",
      "display_url" : "github.com\/rails\/rails\/pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268851649563463680",
  "text" : "And in today's WTF bucket: https:\/\/t.co\/J9I5GGun",
  "id" : 268851649563463680,
  "created_at" : "2012-11-14 23:03:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wilkening",
      "screen_name" : "bwilken",
      "indices" : [ 0, 8 ],
      "id_str" : "117543486",
      "id" : 117543486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268405824731361280",
  "geo" : { },
  "id_str" : "268820829515702273",
  "in_reply_to_user_id" : 117543486,
  "text" : "@bwilken Lots of people! Damn! I'd love to attend one next time I'm in town :)",
  "id" : 268820829515702273,
  "in_reply_to_status_id" : 268405824731361280,
  "created_at" : "2012-11-14 21:00:54 +0000",
  "in_reply_to_screen_name" : "bwilken",
  "in_reply_to_user_id_str" : "117543486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 3, 14 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268817544939462656",
  "text" : "RT @benjaminws: mkderp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268817062900678656",
    "text" : "mkderp",
    "id" : 268817062900678656,
    "created_at" : "2012-11-14 20:45:56 +0000",
    "user" : {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "protected" : false,
      "id_str" : "14188391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572829103221268480\/Yz-uQhpX_normal.jpeg",
      "id" : 14188391,
      "verified" : false
    }
  },
  "id" : 268817544939462656,
  "created_at" : "2012-11-14 20:47:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268814528396005378",
  "geo" : { },
  "id_str" : "268815112964558849",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods Time to play Dwarf Fortress dwarven babies are born with a booze preference and start drinking immediately after being born.",
  "id" : 268815112964558849,
  "in_reply_to_status_id" : 268814528396005378,
  "created_at" : "2012-11-14 20:38:11 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 3, 11 ],
      "id_str" : "11374142",
      "id" : 11374142
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268796500929282048",
  "text" : "RT @bphogan: @qrush I\u2019m teaching absolute beginners, and I have come to realize that programmers \u201Cblock out\u201D the first two years of prog ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "268796178274082816",
    "geo" : { },
    "id_str" : "268796405622140928",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I\u2019m teaching absolute beginners, and I have come to realize that programmers \u201Cblock out\u201D the first two years of programming. :)",
    "id" : 268796405622140928,
    "in_reply_to_status_id" : 268796178274082816,
    "created_at" : "2012-11-14 19:23:51 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "protected" : false,
      "id_str" : "11374142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477448204909174785\/xcuKMs6E_normal.jpeg",
      "id" : 11374142,
      "verified" : false
    }
  },
  "id" : 268796500929282048,
  "created_at" : "2012-11-14 19:24:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 0, 15 ],
      "id_str" : "17850415",
      "id" : 17850415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268796055561326594",
  "geo" : { },
  "id_str" : "268796325766766592",
  "in_reply_to_user_id" : 17850415,
  "text" : "@caseyrosenthal Helping out with a high school programming class once a week.",
  "id" : 268796325766766592,
  "in_reply_to_status_id" : 268796055561326594,
  "created_at" : "2012-11-14 19:23:32 +0000",
  "in_reply_to_screen_name" : "caseyrosenthal",
  "in_reply_to_user_id_str" : "17850415",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268795950066176001",
  "geo" : { },
  "id_str" : "268796178274082816",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan I think thats my problem right now. My shallow end is too deep...so hard to judge what is going to be achievable, grokable.",
  "id" : 268796178274082816,
  "in_reply_to_status_id" : 268795950066176001,
  "created_at" : "2012-11-14 19:22:57 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268795483013672960",
  "geo" : { },
  "id_str" : "268795763004420096",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan Sounds good. I probably just jumped too far into the deep end.",
  "id" : 268795763004420096,
  "in_reply_to_status_id" : 268795483013672960,
  "created_at" : "2012-11-14 19:21:18 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268793703819268097",
  "text" : "Full house at @coworkbuffalo today. Very happy about this.",
  "id" : 268793703819268097,
  "created_at" : "2012-11-14 19:13:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268793513284628480",
  "text" : "So hard to find balance between \"way too easy\" and \"WTF WTF WTF\" for in-class exercises. Mind of the beginner...still searching for it.",
  "id" : 268793513284628480,
  "created_at" : "2012-11-14 19:12:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268756202287161344",
  "geo" : { },
  "id_str" : "268756662238732290",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez @coworkbuffalo there are several bike racks on the street, or you can haul it upstairs if you want!",
  "id" : 268756662238732290,
  "in_reply_to_status_id" : 268756202287161344,
  "created_at" : "2012-11-14 16:45:56 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268742972873510912",
  "text" : "Remember Guitar Hero? Good times.",
  "id" : 268742972873510912,
  "created_at" : "2012-11-14 15:51:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 15, 20 ],
      "id_str" : "14184324",
      "id" : 14184324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268739670093996036",
  "text" : "RT @aquaranto: @mwrc \"Thank you for submitting a proposal to MWRC.\" Hooray!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MtnWest RubyConf",
        "screen_name" : "mwrc",
        "indices" : [ 0, 5 ],
        "id_str" : "14184324",
        "id" : 14184324
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268727919097049088",
    "in_reply_to_user_id" : 14184324,
    "text" : "@mwrc \"Thank you for submitting a proposal to MWRC.\" Hooray!!!!",
    "id" : 268727919097049088,
    "created_at" : "2012-11-14 14:51:43 +0000",
    "in_reply_to_screen_name" : "mwrc",
    "in_reply_to_user_id_str" : "14184324",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 268739670093996036,
  "created_at" : "2012-11-14 15:38:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268548079194632192",
  "geo" : { },
  "id_str" : "268585500279988224",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic thanks man.",
  "id" : 268585500279988224,
  "in_reply_to_status_id" : 268548079194632192,
  "created_at" : "2012-11-14 05:25:48 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed",
      "screen_name" : "mneorr",
      "indices" : [ 0, 7 ],
      "id_str" : "2358949105",
      "id" : 2358949105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268485733629718528",
  "geo" : { },
  "id_str" : "268493038643453952",
  "in_reply_to_user_id" : 259575244,
  "text" : "@mneorr we haven't hired anyone yet.",
  "id" : 268493038643453952,
  "in_reply_to_status_id" : 268485733629718528,
  "created_at" : "2012-11-13 23:18:23 +0000",
  "in_reply_to_screen_name" : "_supermarin",
  "in_reply_to_user_id_str" : "259575244",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 22, 33 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268472463233515520",
  "geo" : { },
  "id_str" : "268472893317451779",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant I think @kevinpurdy is about to blow a blood vessel with excitement about this",
  "id" : 268472893317451779,
  "in_reply_to_status_id" : 268472463233515520,
  "created_at" : "2012-11-13 21:58:20 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268472312414736385",
  "text" : "\"Am I worth more hourly than two girls snuggling?\" OH: \"Probably not\"",
  "id" : 268472312414736385,
  "created_at" : "2012-11-13 21:56:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/DRAU29eT",
      "expanded_url" : "http:\/\/www.thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268471434442059778",
  "text" : "Weekly reminder to my freelancer friends that the Double Cuddle is $120\/hr: http:\/\/t.co\/DRAU29eT",
  "id" : 268471434442059778,
  "created_at" : "2012-11-13 21:52:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 3, 13 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268470728658124800",
  "text" : "RT @patmaddox: drinkup is a githubber! githubber is a drinkup! drinkup, githubbers!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268470485623394304",
    "text" : "drinkup is a githubber! githubber is a drinkup! drinkup, githubbers!",
    "id" : 268470485623394304,
    "created_at" : "2012-11-13 21:48:46 +0000",
    "user" : {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "protected" : false,
      "id_str" : "14955528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3310115264\/0eabb481dbeed11a52f54d2976323385_normal.png",
      "id" : 14955528,
      "verified" : false
    }
  },
  "id" : 268470728658124800,
  "created_at" : "2012-11-13 21:49:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/DRAU29eT",
      "expanded_url" : "http:\/\/www.thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "268470436906561536",
  "geo" : { },
  "id_str" : "268470590988492800",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Reminder that the Double Cuddle is $120\/hour: http:\/\/t.co\/DRAU29eT",
  "id" : 268470590988492800,
  "in_reply_to_status_id" : 268470436906561536,
  "created_at" : "2012-11-13 21:49:11 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268469085048799233",
  "geo" : { },
  "id_str" : "268469786097373184",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Initial release October 18, 2006; 6 years ago",
  "id" : 268469786097373184,
  "in_reply_to_status_id" : 268469085048799233,
  "created_at" : "2012-11-13 21:45:59 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268469085048799233",
  "geo" : { },
  "id_str" : "268469666970742784",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten IE7!?!?!",
  "id" : 268469666970742784,
  "in_reply_to_status_id" : 268469085048799233,
  "created_at" : "2012-11-13 21:45:31 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 0, 8 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268423168190996480",
  "geo" : { },
  "id_str" : "268427333885640705",
  "in_reply_to_user_id" : 223422672,
  "text" : "@jo_liss I have zero time :( All of the data is there. I'm nervous about putting load back on the servers until we get on new infrastructure",
  "id" : 268427333885640705,
  "in_reply_to_status_id" : 268423168190996480,
  "created_at" : "2012-11-13 18:57:18 +0000",
  "in_reply_to_screen_name" : "jo_liss",
  "in_reply_to_user_id_str" : "223422672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    }, {
      "name" : "Matt Clement",
      "screen_name" : "darkmoves",
      "indices" : [ 11, 21 ],
      "id_str" : "77850407",
      "id" : 77850407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268417805622312960",
  "geo" : { },
  "id_str" : "268418125790318592",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano @darkmoves Woo! Suggestions: Canalside Park, Hoyt Lake, Bidwell Parkway, 3 Sisters Island (Niagara Falls)",
  "id" : 268418125790318592,
  "in_reply_to_status_id" : 268417805622312960,
  "created_at" : "2012-11-13 18:20:42 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268416984176287745",
  "geo" : { },
  "id_str" : "268417584922251265",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano You better get downtown, harbor, or to Delaware Park\/Elmwood Village for some footage. There's more to Buffalo than OP :)",
  "id" : 268417584922251265,
  "in_reply_to_status_id" : 268416984176287745,
  "created_at" : "2012-11-13 18:18:33 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 11, 21 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/0xPPZoPI",
      "expanded_url" : "http:\/\/tailgate32.com\/",
      "display_url" : "tailgate32.com"
    } ]
  },
  "in_reply_to_status_id_str" : "268416533611565056",
  "geo" : { },
  "id_str" : "268416957815091201",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @jtrupiano yes, the advantages of being a diehard football vagrant\/hobo are plenty: http:\/\/t.co\/0xPPZoPI",
  "id" : 268416957815091201,
  "in_reply_to_status_id" : 268416533611565056,
  "created_at" : "2012-11-13 18:16:04 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cVHR2i8P",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VAC-5BQnuXI",
      "display_url" : "youtube.com\/watch?v=VAC-5B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268410173943595010",
  "text" : "Current status: http:\/\/t.co\/cVHR2i8P",
  "id" : 268410173943595010,
  "created_at" : "2012-11-13 17:49:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268401131317760000",
  "geo" : { },
  "id_str" : "268401773977423872",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic Holy crap dude, what happened?",
  "id" : 268401773977423872,
  "in_reply_to_status_id" : 268401131317760000,
  "created_at" : "2012-11-13 17:15:44 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268399255541145600",
  "geo" : { },
  "id_str" : "268400774923575296",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano Can do ! If you're up for a drink let me know.",
  "id" : 268400774923575296,
  "in_reply_to_status_id" : 268399255541145600,
  "created_at" : "2012-11-13 17:11:46 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268395912693432320",
  "geo" : { },
  "id_str" : "268396306253361152",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano hey, heard you're going to be at the Bills game this Thursday! (I will be too!) If you're going to be in Buffalo please say hi.",
  "id" : 268396306253361152,
  "in_reply_to_status_id" : 268395912693432320,
  "created_at" : "2012-11-13 16:54:00 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268395404457029632",
  "geo" : { },
  "id_str" : "268395651556048897",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo @37signals \/play deeper",
  "id" : 268395651556048897,
  "in_reply_to_status_id" : 268395404457029632,
  "created_at" : "2012-11-13 16:51:24 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/6xWnr8ZX",
      "expanded_url" : "http:\/\/www.wired.com\/business\/2012\/11\/best-non-california-tech-companies\/",
      "display_url" : "wired.com\/business\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268391500507922433",
  "text" : "Proud to be working in Non-California. http:\/\/t.co\/6xWnr8ZX",
  "id" : 268391500507922433,
  "created_at" : "2012-11-13 16:34:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Rg5q0eu0",
      "expanded_url" : "http:\/\/is.gd\/dfXwF9",
      "display_url" : "is.gd\/dfXwF9"
    } ]
  },
  "geo" : { },
  "id_str" : "268387453537226752",
  "text" : "RT @theediguy: RIP LooseCubes. A valiant effort in co-working space. Where'd that $7m go? http:\/\/t.co\/Rg5q0eu0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/Rg5q0eu0",
        "expanded_url" : "http:\/\/is.gd\/dfXwF9",
        "display_url" : "is.gd\/dfXwF9"
      } ]
    },
    "geo" : { },
    "id_str" : "268386833010946048",
    "text" : "RIP LooseCubes. A valiant effort in co-working space. Where'd that $7m go? http:\/\/t.co\/Rg5q0eu0",
    "id" : 268386833010946048,
    "created_at" : "2012-11-13 16:16:22 +0000",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 268387453537226752,
  "created_at" : "2012-11-13 16:18:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/itxBSFM2",
      "expanded_url" : "http:\/\/bravemule.com",
      "display_url" : "bravemule.com"
    }, {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/pqhTOnGA",
      "expanded_url" : "http:\/\/exittt.tumblr.com\/post\/35471429712\/preview-for-the-bravemule-finale",
      "display_url" : "exittt.tumblr.com\/post\/354714297\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268380657833611266",
  "text" : "Looks like http:\/\/t.co\/itxBSFM2 is coming to a close...and it will be !!FUN!! http:\/\/t.co\/pqhTOnGA",
  "id" : 268380657833611266,
  "created_at" : "2012-11-13 15:51:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268369262891130881",
  "geo" : { },
  "id_str" : "268369703385325568",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez the mailing list is a decent alternative :)",
  "id" : 268369703385325568,
  "in_reply_to_status_id" : 268369262891130881,
  "created_at" : "2012-11-13 15:08:18 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268368149789937664",
  "geo" : { },
  "id_str" : "268369075539939328",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez you need to be on Buffalo Open Coffee Club!",
  "id" : 268369075539939328,
  "in_reply_to_status_id" : 268368149789937664,
  "created_at" : "2012-11-13 15:05:48 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268368609863147520",
  "text" : "Watching kegs get delivered to Blue Monk from the bus. Do want!",
  "id" : 268368609863147520,
  "created_at" : "2012-11-13 15:03:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Asaff",
      "screen_name" : "iasaff",
      "indices" : [ 0, 7 ],
      "id_str" : "282063742",
      "id" : 282063742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268366074246987776",
  "geo" : { },
  "id_str" : "268368384436088832",
  "in_reply_to_user_id" : 282063742,
  "text" : "@iasaff thanks!!",
  "id" : 268368384436088832,
  "in_reply_to_status_id" : 268366074246987776,
  "created_at" : "2012-11-13 15:03:03 +0000",
  "in_reply_to_screen_name" : "iasaff",
  "in_reply_to_user_id_str" : "282063742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268357767633453056",
  "text" : "\u201CSome people die at 25 and aren't buried until 75.\u201D - Ben Franklin. Thinking about this a lot today.",
  "id" : 268357767633453056,
  "created_at" : "2012-11-13 14:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268246619038830593",
  "geo" : { },
  "id_str" : "268256170005893120",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant thanks!",
  "id" : 268256170005893120,
  "in_reply_to_status_id" : 268246619038830593,
  "created_at" : "2012-11-13 07:37:09 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268256137328078848",
  "text" : "Literally a life changing day. Not in a good way. Hoping tomorrow will be brighter.",
  "id" : 268256137328078848,
  "created_at" : "2012-11-13 07:37:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268121529630474241",
  "geo" : { },
  "id_str" : "268197811949027329",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Augh, censored! Fail.",
  "id" : 268197811949027329,
  "in_reply_to_status_id" : 268121529630474241,
  "created_at" : "2012-11-13 03:45:15 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cF0XR8k5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JU9TouRnO84",
      "display_url" : "youtube.com\/watch?v=JU9Tou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "268121529630474241",
  "geo" : { },
  "id_str" : "268197590607208448",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten http:\/\/t.co\/cF0XR8k5",
  "id" : 268197590607208448,
  "in_reply_to_status_id" : 268121529630474241,
  "created_at" : "2012-11-13 03:44:23 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https:\/\/t.co\/EqFBL6Zn",
      "expanded_url" : "https:\/\/37signals.com\/svn\/posts\/1061-why-we-skip-photoshop",
      "display_url" : "37signals.com\/svn\/posts\/1061\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "268113405230071808",
  "geo" : { },
  "id_str" : "268118949630181376",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten https:\/\/t.co\/EqFBL6Zn ;)",
  "id" : 268118949630181376,
  "in_reply_to_status_id" : 268113405230071808,
  "created_at" : "2012-11-12 22:31:53 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268116927208112128",
  "geo" : { },
  "id_str" : "268118153773592576",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy \u201Chow does one kill that which has no life?\u201D",
  "id" : 268118153773592576,
  "in_reply_to_status_id" : 268116927208112128,
  "created_at" : "2012-11-12 22:28:43 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 8, 18 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268070041940021249",
  "geo" : { },
  "id_str" : "268070188077957121",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel @aquaranto haha yep :)",
  "id" : 268070188077957121,
  "in_reply_to_status_id" : 268070041940021249,
  "created_at" : "2012-11-12 19:18:08 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 1, 11 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268069816500383746",
  "text" : ".@aquaranto on Sinatra: \"yeah... that was way easier than rails\"",
  "id" : 268069816500383746,
  "created_at" : "2012-11-12 19:16:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 10, 20 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268037922358435840",
  "text" : "All Nerds @37signals is on a roll today.",
  "id" : 268037922358435840,
  "created_at" : "2012-11-12 17:09:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/7etgGaqZ",
      "expanded_url" : "https:\/\/github.com\/albertz\/music-player\/blob\/master\/WhatIsAMusicPlayer.md",
      "display_url" : "github.com\/albertz\/music-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268012465961459713",
  "text" : "Great writeup of the hidden complexity behind music players: https:\/\/t.co\/7etgGaqZ",
  "id" : 268012465961459713,
  "created_at" : "2012-11-12 15:28:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 13, 22 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "268011813390655488",
  "text" : "27 cities on @OpenHack now. 3 continents. Let's get some more! http:\/\/t.co\/Dih7bxvF",
  "id" : 268011813390655488,
  "created_at" : "2012-11-12 15:26:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267996565422084096",
  "text" : "iPhone powered off at 15% battery life. Ever since iOS6 this has been happening :(",
  "id" : 267996565422084096,
  "created_at" : "2012-11-12 14:25:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267866203274477569",
  "geo" : { },
  "id_str" : "267866815923900416",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting trolololo",
  "id" : 267866815923900416,
  "in_reply_to_status_id" : 267866203274477569,
  "created_at" : "2012-11-12 05:50:00 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 3, 17 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 40, 46 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Boxcar Press",
      "screen_name" : "letterpress",
      "indices" : [ 51, 63 ],
      "id_str" : "17379504",
      "id" : 17379504
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 103, 109 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267866764241670145",
  "text" : "RT @gnuconsulting: Everyone please tell @qrush and @letterpress that \u201Cflava\u201D is not a real word. Also, @qrush is a poopy head.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 21, 27 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Boxcar Press",
        "screen_name" : "letterpress",
        "indices" : [ 32, 44 ],
        "id_str" : "17379504",
        "id" : 17379504
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 84, 90 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267866203274477569",
    "text" : "Everyone please tell @qrush and @letterpress that \u201Cflava\u201D is not a real word. Also, @qrush is a poopy head.",
    "id" : 267866203274477569,
    "created_at" : "2012-11-12 05:47:34 +0000",
    "user" : {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "protected" : false,
      "id_str" : "15060778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474011977006579712\/EWheVLDk_normal.jpeg",
      "id" : 15060778,
      "verified" : false
    }
  },
  "id" : 267866764241670145,
  "created_at" : "2012-11-12 05:49:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267682596446666753",
  "text" : "Jetskis on Lake Erie in November? Is this Buffalo!?",
  "id" : 267682596446666753,
  "created_at" : "2012-11-11 17:37:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/8awttAN9",
      "expanded_url" : "http:\/\/turntable.fm\/jam_bands_no_lames_1up1down",
      "display_url" : "turntable.fm\/jam_bands_no_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "267367422040883200",
  "text" : "DJing in the Jam Bands | No Lames | 1Up1Down room. Now playing Perpetual Groove #turntablefm http:\/\/t.co\/8awttAN9",
  "id" : 267367422040883200,
  "created_at" : "2012-11-10 20:45:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 78, 89 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/267071113740296192\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/v3v66aVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7TTw1ECIAAH-y2.jpg",
      "id_str" : "267071113752879104",
      "id" : 267071113752879104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7TTw1ECIAAH-y2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/v3v66aVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267071113740296192",
  "text" : "Just jerryrigged an Xbox controller back using some electrical tape and a tag @kevinpurdy gave me. Ship it! http:\/\/t.co\/v3v66aVZ",
  "id" : 267071113740296192,
  "created_at" : "2012-11-10 01:08:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267013537740771328",
  "geo" : { },
  "id_str" : "267013673103532032",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k WHO FAVORITES THE FAVORITES?",
  "id" : 267013673103532032,
  "in_reply_to_status_id" : 267013537740771328,
  "created_at" : "2012-11-09 21:19:55 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 6, 15 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 51, 58 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/PosY0ARd",
      "expanded_url" : "http:\/\/statuscode.org\/archive\/18.html",
      "display_url" : "statuscode.org\/archive\/18.html"
    } ]
  },
  "geo" : { },
  "id_str" : "266959638241615872",
  "text" : "Woot! @OpenHack is in StatusCode this week. Thanks @peterc ! http:\/\/t.co\/PosY0ARd",
  "id" : 266959638241615872,
  "created_at" : "2012-11-09 17:45:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Wilk",
      "screen_name" : "josephwilk",
      "indices" : [ 3, 14 ],
      "id_str" : "14321259",
      "id" : 14321259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266933174813220865",
  "text" : "RT @josephwilk: You don't fix culture with code.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266931310663172096",
    "text" : "You don't fix culture with code.",
    "id" : 266931310663172096,
    "created_at" : "2012-11-09 15:52:38 +0000",
    "user" : {
      "name" : "Joseph Wilk",
      "screen_name" : "josephwilk",
      "protected" : false,
      "id_str" : "14321259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518760213755994112\/kTFeRKT9_normal.jpeg",
      "id" : 14321259,
      "verified" : false
    }
  },
  "id" : 266933174813220865,
  "created_at" : "2012-11-09 16:00:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 3, 14 ],
      "id_str" : "11857402",
      "id" : 11857402
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 32, 41 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266933038913572865",
  "text" : "RT @bryanwoods: I don't get why @rubygems is bragging about a billion downloads. That's just what happens when I do a bundle install.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 16, 25 ],
        "id_str" : "14881835",
        "id" : 14881835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266932113499111426",
    "text" : "I don't get why @rubygems is bragging about a billion downloads. That's just what happens when I do a bundle install.",
    "id" : 266932113499111426,
    "created_at" : "2012-11-09 15:55:49 +0000",
    "user" : {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "protected" : false,
      "id_str" : "11857402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522216405698347009\/YTLEJ2_0_normal.jpeg",
      "id" : 11857402,
      "verified" : false
    }
  },
  "id" : 266933038913572865,
  "created_at" : "2012-11-09 15:59:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "266927543628742657",
  "text" : "DJing in the CoworkBuffalo room! #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 266927543628742657,
  "created_at" : "2012-11-09 15:37:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Dever",
      "screen_name" : "clarkdever",
      "indices" : [ 0, 11 ],
      "id_str" : "11081432",
      "id" : 11081432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266765065527644160",
  "geo" : { },
  "id_str" : "266913857535090688",
  "in_reply_to_user_id" : 11081432,
  "text" : "@clarkdever no problem. love teaching new games!",
  "id" : 266913857535090688,
  "in_reply_to_status_id" : 266765065527644160,
  "created_at" : "2012-11-09 14:43:17 +0000",
  "in_reply_to_screen_name" : "clarkdever",
  "in_reply_to_user_id_str" : "11081432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkb",
      "screen_name" : "mojinations",
      "indices" : [ 3, 15 ],
      "id_str" : "259616245",
      "id" : 259616245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266898644672860160",
  "text" : "RT @mojinations: If you know your way around the RubyGems server-side code, please drop me a line.  I might have some contract work for you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266691221563531265",
    "text" : "If you know your way around the RubyGems server-side code, please drop me a line.  I might have some contract work for you.",
    "id" : 266691221563531265,
    "created_at" : "2012-11-08 23:58:36 +0000",
    "user" : {
      "name" : "mkb",
      "screen_name" : "mojinations",
      "protected" : false,
      "id_str" : "259616245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2427743703\/4v8u7icartfvdaj85sip_normal.jpeg",
      "id" : 259616245,
      "verified" : false
    }
  },
  "id" : 266898644672860160,
  "created_at" : "2012-11-09 13:42:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Dorrans",
      "screen_name" : "blowdart",
      "indices" : [ 0, 9 ],
      "id_str" : "1847381",
      "id" : 1847381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266779939322347520",
  "geo" : { },
  "id_str" : "266780787263815680",
  "in_reply_to_user_id" : 1847381,
  "text" : "@blowdart doing campaign on Heroic\u2026have died many times. Switched so melee is B immediately.",
  "id" : 266780787263815680,
  "in_reply_to_status_id" : 266779939322347520,
  "created_at" : "2012-11-09 05:54:30 +0000",
  "in_reply_to_screen_name" : "blowdart",
  "in_reply_to_user_id_str" : "1847381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 30, 39 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/08JxR40R",
      "expanded_url" : "http:\/\/sflo.me\/Txal1F",
      "display_url" : "sflo.me\/Txal1F"
    } ]
  },
  "geo" : { },
  "id_str" : "266780548968611841",
  "text" : "Pretty sure this is the first @OpenHack related blog post! We should keep a list on the site. http:\/\/t.co\/08JxR40R",
  "id" : 266780548968611841,
  "created_at" : "2012-11-09 05:53:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bright",
      "screen_name" : "btbright",
      "indices" : [ 3, 12 ],
      "id_str" : "38057253",
      "id" : 38057253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/WVeEByG8",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ryt3jntwvY\/",
      "display_url" : "instagr.am\/p\/Ryt3jntwvY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "266779795529023488",
  "text" : "RT @btbright: OpenHack Birmingham http:\/\/t.co\/WVeEByG8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/WVeEByG8",
        "expanded_url" : "http:\/\/instagr.am\/p\/Ryt3jntwvY\/",
        "display_url" : "instagr.am\/p\/Ryt3jntwvY\/"
      } ]
    },
    "geo" : { },
    "id_str" : "266732839909855232",
    "text" : "OpenHack Birmingham http:\/\/t.co\/WVeEByG8",
    "id" : 266732839909855232,
    "created_at" : "2012-11-09 02:43:59 +0000",
    "user" : {
      "name" : "Ben Bright",
      "screen_name" : "btbright",
      "protected" : false,
      "id_str" : "38057253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477331745964961792\/FjMxATLj_normal.jpeg",
      "id" : 38057253,
      "verified" : false
    }
  },
  "id" : 266779795529023488,
  "created_at" : "2012-11-09 05:50:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266779228119367680",
  "text" : "Halo 4 feedback so far: the pistol doesn\u2019t suck.",
  "id" : 266779228119367680,
  "created_at" : "2012-11-09 05:48:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/266740493474467840\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/773oFAxh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7OnEMlCEAEQfKB.jpg",
      "id_str" : "266740493482856449",
      "id" : 266740493482856449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7OnEMlCEAEQfKB.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/773oFAxh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266740493474467840",
  "text" : "Maximum trolling Halo 4 armor acquired. Gamertag is Doctor Q for anyone else playing! http:\/\/t.co\/773oFAxh",
  "id" : 266740493474467840,
  "created_at" : "2012-11-09 03:14:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266707701218816000",
  "text" : "Having a lot of fun at Buffalo Open Tabletop. Really loving the tech\/geek community here.",
  "id" : 266707701218816000,
  "created_at" : "2012-11-09 01:04:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Dever",
      "screen_name" : "clarkdever",
      "indices" : [ 0, 11 ],
      "id_str" : "11081432",
      "id" : 11081432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266672757947899905",
  "in_reply_to_user_id" : 11081432,
  "text" : "@clarkdever do you guys actually have any games tonight? mailing list post doesnt sound optimistic",
  "id" : 266672757947899905,
  "created_at" : "2012-11-08 22:45:14 +0000",
  "in_reply_to_screen_name" : "clarkdever",
  "in_reply_to_user_id_str" : "11081432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 7, 14 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266663687849385984",
  "geo" : { },
  "id_str" : "266667116030197760",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @Adkron Added. There's some fresh feedback on 484 for ya!",
  "id" : 266667116030197760,
  "in_reply_to_status_id" : 266663687849385984,
  "created_at" : "2012-11-08 22:22:49 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266661276380454912",
  "geo" : { },
  "id_str" : "266662668457361408",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik Which? in the past we've done if they've asked for it. I originally added everyone but someone bitched about it :\/",
  "id" : 266662668457361408,
  "in_reply_to_status_id" : 266661276380454912,
  "created_at" : "2012-11-08 22:05:09 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266649536896843777",
  "geo" : { },
  "id_str" : "266650200750292992",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier \"* Vaguely disturbing\"",
  "id" : 266650200750292992,
  "in_reply_to_status_id" : 266649536896843777,
  "created_at" : "2012-11-08 21:15:36 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266648455374573568",
  "geo" : { },
  "id_str" : "266648635276656640",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer Bring it! quaranto on Game Center.",
  "id" : 266648635276656640,
  "in_reply_to_status_id" : 266648455374573568,
  "created_at" : "2012-11-08 21:09:23 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eliza Brock Marcum",
      "screen_name" : "elizabrock",
      "indices" : [ 0, 11 ],
      "id_str" : "10358392",
      "id" : 10358392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266647844205776896",
  "geo" : { },
  "id_str" : "266648280564371456",
  "in_reply_to_user_id" : 10358392,
  "text" : "@elizabrock It's like Disney World!",
  "id" : 266648280564371456,
  "in_reply_to_status_id" : 266647844205776896,
  "created_at" : "2012-11-08 21:07:58 +0000",
  "in_reply_to_screen_name" : "elizabrock",
  "in_reply_to_user_id_str" : "10358392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266646254862348288",
  "geo" : { },
  "id_str" : "266647076102873088",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y WTFFFF",
  "id" : 266647076102873088,
  "in_reply_to_status_id" : 266646254862348288,
  "created_at" : "2012-11-08 21:03:11 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "266619612152594432",
  "text" : "Need to say this more: huge thanks to RubyCentral, our sponsors, and all committers. Here\u2019s to the next 1 billion on http:\/\/t.co\/t7WATcFT! \uD83C\uDF7B",
  "id" : 266619612152594432,
  "created_at" : "2012-11-08 19:14:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266618113657827328",
  "text" : "Probably just completely botched a first introduction to HTML. Feeling more stupid than when you were going into a class is normal, right?",
  "id" : 266618113657827328,
  "created_at" : "2012-11-08 19:08:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Cohen",
      "screen_name" : "jeffcohen",
      "indices" : [ 3, 13 ],
      "id_str" : "14635093",
      "id" : 14635093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266597303903739904",
  "text" : "RT @jeffcohen: Most programmers aren't good at helping non-programmers get started.  We rapidly lose touch with the beginner's mind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266588065684934656",
    "text" : "Most programmers aren't good at helping non-programmers get started.  We rapidly lose touch with the beginner's mind.",
    "id" : 266588065684934656,
    "created_at" : "2012-11-08 17:08:42 +0000",
    "user" : {
      "name" : "Jeff Cohen",
      "screen_name" : "jeffcohen",
      "protected" : false,
      "id_str" : "14635093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480434062155186176\/2EZhB_ul_normal.jpeg",
      "id" : 14635093,
      "verified" : false
    }
  },
  "id" : 266597303903739904,
  "created_at" : "2012-11-08 17:45:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    }, {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 44, 55 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266583680246509568",
  "geo" : { },
  "id_str" : "266589364958658560",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair opposite end of the country, but @themcgruff might know!",
  "id" : 266589364958658560,
  "in_reply_to_status_id" : 266583680246509568,
  "created_at" : "2012-11-08 17:13:52 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266574021800366080",
  "geo" : { },
  "id_str" : "266575131952959488",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl I usually say \"q rush\", but I don't mind either.",
  "id" : 266575131952959488,
  "in_reply_to_status_id" : 266574021800366080,
  "created_at" : "2012-11-08 16:17:18 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/LHaiK2Rv",
      "expanded_url" : "http:\/\/rubygems.org\/",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "266573020083146752",
  "text" : "1 Billion! http:\/\/t.co\/LHaiK2Rv",
  "id" : 266573020083146752,
  "created_at" : "2012-11-08 16:08:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266385830476668929",
  "text" : "And apparently you need to pay Microsoft monthly to use IE on Xbox. LOLZ",
  "id" : 266385830476668929,
  "created_at" : "2012-11-08 03:45:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266384402114813952",
  "text" : "Xbox Smartglass is blowing my mind right now. I\u2019m \u201CDoctor Q\u201D on Live if you want to add me.",
  "id" : 266384402114813952,
  "created_at" : "2012-11-08 03:39:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266372910296489984",
  "geo" : { },
  "id_str" : "266373448052404224",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 I think the comments helped out. Jumped up to #8? It was over 30 last time. The ranking algorithm makes zero sense.",
  "id" : 266373448052404224,
  "in_reply_to_status_id" : 266372910296489984,
  "created_at" : "2012-11-08 02:55:53 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266365312830668802",
  "geo" : { },
  "id_str" : "266365778830450689",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 haha I'm not looking for HN's \"acceptance\", just trying to get the word out.",
  "id" : 266365778830450689,
  "in_reply_to_status_id" : 266365312830668802,
  "created_at" : "2012-11-08 02:25:25 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266363232694980609",
  "geo" : { },
  "id_str" : "266363756697751552",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 Doing so, but that's not going to get it back on the homepage. :(",
  "id" : 266363756697751552,
  "in_reply_to_status_id" : 266363232694980609,
  "created_at" : "2012-11-08 02:17:23 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266362510674915328",
  "text" : "And in under an hour, the OpenHack discussion on HN is off the homepage. It's not just the community that is poisonous\/stupid. &gt;:[",
  "id" : 266362510674915328,
  "created_at" : "2012-11-08 02:12:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Diago",
      "screen_name" : "josefdiago",
      "indices" : [ 0, 11 ],
      "id_str" : "251839105",
      "id" : 251839105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266356315792736256",
  "geo" : { },
  "id_str" : "266358468674457600",
  "in_reply_to_user_id" : 251839105,
  "text" : "@josefdiago in buffalo, every other week.",
  "id" : 266358468674457600,
  "in_reply_to_status_id" : 266356315792736256,
  "created_at" : "2012-11-08 01:56:22 +0000",
  "in_reply_to_screen_name" : "josefdiago",
  "in_reply_to_user_id_str" : "251839105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 54, 63 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/BH2WEale",
      "expanded_url" : "http:\/\/news.ycombinator.com\/newest",
      "display_url" : "news.ycombinator.com\/newest"
    } ]
  },
  "geo" : { },
  "id_str" : "266352567880122368",
  "text" : "Apparently, go to http:\/\/t.co\/BH2WEale and upvote the @OpenHack story. Because upvotes aren't simple enough.",
  "id" : 266352567880122368,
  "created_at" : "2012-11-08 01:32:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266351321949560832",
  "geo" : { },
  "id_str" : "266351899324841984",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik So stupid.",
  "id" : 266351899324841984,
  "in_reply_to_status_id" : 266351321949560832,
  "created_at" : "2012-11-08 01:30:16 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 57, 66 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "266343849645965312",
  "text" : "17 cities strong, and now a new redesign. So excited for @OpenHack! http:\/\/t.co\/Dih7bxvF",
  "id" : 266343849645965312,
  "created_at" : "2012-11-08 00:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/31bfogiz",
      "expanded_url" : "http:\/\/nooooooooooooooo.com\/",
      "display_url" : "nooooooooooooooo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "266279943648997376",
  "geo" : { },
  "id_str" : "266280092949430272",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting http:\/\/t.co\/31bfogiz",
  "id" : 266280092949430272,
  "in_reply_to_status_id" : 266279943648997376,
  "created_at" : "2012-11-07 20:44:56 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266243723803889664",
  "text" : "THE COFFEE MUST FLOW!",
  "id" : 266243723803889664,
  "created_at" : "2012-11-07 18:20:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266243027381673984",
  "text" : "Bless the Maker and all His Coffee. Bless the coming and going of Him, May His passing cleanse the world.",
  "id" : 266243027381673984,
  "created_at" : "2012-11-07 18:17:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/I1qjm8AC",
      "expanded_url" : "http:\/\/en.wikiquote.org\/wiki\/Dune",
      "display_url" : "en.wikiquote.org\/wiki\/Dune"
    } ]
  },
  "geo" : { },
  "id_str" : "266237301829558272",
  "text" : "Whoever picks stock art for Wikiquote...Dune has an amazing selection. http:\/\/t.co\/I1qjm8AC",
  "id" : 266237301829558272,
  "created_at" : "2012-11-07 17:54:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/2t2nhDHd",
      "expanded_url" : "http:\/\/startheory.files.wordpress.com\/2010\/01\/muaddib84.jpg",
      "display_url" : "startheory.files.wordpress.com\/2010\/01\/muaddi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266236154620305408",
  "text" : "Upcoming coffee status: http:\/\/t.co\/2t2nhDHd",
  "id" : 266236154620305408,
  "created_at" : "2012-11-07 17:50:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GratisBuzz",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266235877964013569",
  "text" : "RT @coworkbuffalo: Coffee maestro Phil Roberts is stopping by soon to sample and taste really, really good coffees. Stop by for a free c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GratisBuzz",
        "indices" : [ 121, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266235757117718529",
    "text" : "Coffee maestro Phil Roberts is stopping by soon to sample and taste really, really good coffees. Stop by for a free cup. #GratisBuzz",
    "id" : 266235757117718529,
    "created_at" : "2012-11-07 17:48:45 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 266235877964013569,
  "created_at" : "2012-11-07 17:49:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey S",
      "screen_name" : "caseyinBuffalo",
      "indices" : [ 0, 15 ],
      "id_str" : "191558578",
      "id" : 191558578
    }, {
      "name" : "Canuck | Kate",
      "screen_name" : "PeopleOfCanada",
      "indices" : [ 16, 31 ],
      "id_str" : "774139460",
      "id" : 774139460
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "in_reply_to_status_id_str" : "266198034436722688",
  "geo" : { },
  "id_str" : "266198293573410817",
  "in_reply_to_user_id" : 191558578,
  "text" : "@caseyinBuffalo @PeopleOfCanada @coworkbuffalo http:\/\/t.co\/EYaWwERQ",
  "id" : 266198293573410817,
  "in_reply_to_status_id" : 266198034436722688,
  "created_at" : "2012-11-07 15:19:53 +0000",
  "in_reply_to_screen_name" : "caseyinBuffalo",
  "in_reply_to_user_id_str" : "191558578",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blake hall",
      "screen_name" : "blakehall",
      "indices" : [ 0, 10 ],
      "id_str" : "804668",
      "id" : 804668
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 11, 22 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266068790452842496",
  "geo" : { },
  "id_str" : "266069156221296640",
  "in_reply_to_user_id" : 804668,
  "text" : "@blakehall @ashedryden that's so many timbits!",
  "id" : 266069156221296640,
  "in_reply_to_status_id" : 266068790452842496,
  "created_at" : "2012-11-07 06:46:44 +0000",
  "in_reply_to_screen_name" : "blakehall",
  "in_reply_to_user_id_str" : "804668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 13, 22 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 23, 31 ],
      "id_str" : "14408469",
      "id" : 14408469
    }, {
      "name" : "Michael Berger",
      "screen_name" : "bergatron",
      "indices" : [ 32, 42 ],
      "id_str" : "15517749",
      "id" : 15517749
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 43, 51 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266056546520268800",
  "geo" : { },
  "id_str" : "266056877782204417",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide @bitsweat @uptonic @bergatron @noahhlo Emergency meetup planning!",
  "id" : 266056877782204417,
  "in_reply_to_status_id" : 266056546520268800,
  "created_at" : "2012-11-07 05:57:57 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266055301206245377",
  "text" : "I hope the concession speech is delayed because they're still saying goodbye on the phone. \"You first!\" \"No you!\" \"Oh hang up!\" \"No, you!\"",
  "id" : 266055301206245377,
  "created_at" : "2012-11-07 05:51:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 25, 32 ],
      "id_str" : "814306",
      "id" : 814306
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 37, 49 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266052162512093186",
  "geo" : { },
  "id_str" : "266053935876411393",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule I'm pretty sure @Shella and @SteveStreza are responsible.",
  "id" : 266053935876411393,
  "in_reply_to_status_id" : 266052162512093186,
  "created_at" : "2012-11-07 05:46:16 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266047904597291008",
  "text" : "RT @theediguy: MD &amp; ME pass marriage equality, CO legalizes weed, first openly gay Senator, and we re-elected a black guy to POTUS.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266047822376349696",
    "text" : "MD &amp; ME pass marriage equality, CO legalizes weed, first openly gay Senator, and we re-elected a black guy to POTUS. Hell yeah.",
    "id" : 266047822376349696,
    "created_at" : "2012-11-07 05:21:58 +0000",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 266047904597291008,
  "created_at" : "2012-11-07 05:22:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 9, 18 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Josh Lowensohn",
      "screen_name" : "Josh",
      "indices" : [ 19, 24 ],
      "id_str" : "626433",
      "id" : 626433
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 25, 37 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265950235610730497",
  "geo" : { },
  "id_str" : "266040391252443136",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @rtomayko @Josh @sstephenson awesome to hear. let me know how it goes :)",
  "id" : 266040391252443136,
  "in_reply_to_status_id" : 265950235610730497,
  "created_at" : "2012-11-07 04:52:26 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/Age95qH4",
      "expanded_url" : "http:\/\/www.comedycentral.com\/live-election-night\/",
      "display_url" : "comedycentral.com\/live-election-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266028887430029313",
  "text" : "This is already better than watching local news describing the color of boxes on the screen. http:\/\/t.co\/Age95qH4",
  "id" : 266028887430029313,
  "created_at" : "2012-11-07 04:06:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 39, 52 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266010312745037824",
  "text" : "RT @kevinpurdy: In case you missed it: @herpderpedia rose from its underwater city today, RT'd arrogant non-participants. Read and remem ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "herpderpedia",
        "screen_name" : "herpderpedia",
        "indices" : [ 23, 36 ],
        "id_str" : "467162656",
        "id" : 467162656
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265994728036765697",
    "text" : "In case you missed it: @herpderpedia rose from its underwater city today, RT'd arrogant non-participants. Read and remember why you voted.",
    "id" : 265994728036765697,
    "created_at" : "2012-11-07 01:50:59 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 266010312745037824,
  "created_at" : "2012-11-07 02:52:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265994232521703424",
  "geo" : { },
  "id_str" : "265994740514840576",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg ...what?",
  "id" : 265994740514840576,
  "in_reply_to_status_id" : 265994232521703424,
  "created_at" : "2012-11-07 01:51:02 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 10, 19 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265971507237371905",
  "text" : "Woot it's @openhack Buffalo time! Absolutely love getting techies in town together.",
  "id" : 265971507237371905,
  "created_at" : "2012-11-07 00:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indyK1ng",
      "screen_name" : "indyK1ng",
      "indices" : [ 0, 9 ],
      "id_str" : "18765238",
      "id" : 18765238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265932575099461632",
  "geo" : { },
  "id_str" : "265941362615140352",
  "in_reply_to_user_id" : 18765238,
  "text" : "@indyK1ng That's literally the point.",
  "id" : 265941362615140352,
  "in_reply_to_status_id" : 265932575099461632,
  "created_at" : "2012-11-06 22:18:56 +0000",
  "in_reply_to_screen_name" : "indyK1ng",
  "in_reply_to_user_id_str" : "18765238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 12, 22 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265931623588044800",
  "geo" : { },
  "id_str" : "265931835530420224",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws @aspleenic Gold!",
  "id" : 265931835530420224,
  "in_reply_to_status_id" : 265931623588044800,
  "created_at" : "2012-11-06 21:41:05 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265930552195039232",
  "geo" : { },
  "id_str" : "265931108447821825",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic Pretty sure you were egging me on.",
  "id" : 265931108447821825,
  "in_reply_to_status_id" : 265930552195039232,
  "created_at" : "2012-11-06 21:38:11 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265916271483310080",
  "geo" : { },
  "id_str" : "265917074633789441",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza The derpness, it weighs heavy on my soul.",
  "id" : 265917074633789441,
  "in_reply_to_status_id" : 265916271483310080,
  "created_at" : "2012-11-06 20:42:25 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265915997062582273",
  "text" : "The derp is strong in this one, but I've lost 200 followers so far today. Apparently trolling democracy isn't fun.",
  "id" : 265915997062582273,
  "created_at" : "2012-11-06 20:38:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265897400202321920",
  "geo" : { },
  "id_str" : "265898777158770689",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson gold.",
  "id" : 265898777158770689,
  "in_reply_to_status_id" : 265897400202321920,
  "created_at" : "2012-11-06 19:29:43 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    }, {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 11, 22 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265895739153059840",
  "geo" : { },
  "id_str" : "265896081412464640",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave @timocratic this sounds to me like the rates in the bay area are astronomical.",
  "id" : 265896081412464640,
  "in_reply_to_status_id" : 265895739153059840,
  "created_at" : "2012-11-06 19:19:00 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 50, 63 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265894605059399680",
  "text" : "Taking suggestions for good realtime searches for @herpderpedia today related to voting, the election, etc. Happy derping!",
  "id" : 265894605059399680,
  "created_at" : "2012-11-06 19:13:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/KblTNq0L",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3307-im-hiring-a-personal-ios-prototyper",
      "display_url" : "37signals.com\/svn\/posts\/3307\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265894056268271617",
  "text" : "Hey iOS folks in Chicagoland: http:\/\/t.co\/KblTNq0L",
  "id" : 265894056268271617,
  "created_at" : "2012-11-06 19:10:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 36, 49 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 73 ],
      "url" : "https:\/\/t.co\/NZ9tstrV",
      "expanded_url" : "https:\/\/twitter.com\/search\/realtime?q=%22voting+is+gay%22&src=typd",
      "display_url" : "twitter.com\/search\/realtim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265888896645230592",
  "text" : "Yep, I think it's time to break out @herpderpedia : https:\/\/t.co\/NZ9tstrV",
  "id" : 265888896645230592,
  "created_at" : "2012-11-06 18:50:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 46, 59 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/ZfoglYwa",
      "expanded_url" : "https:\/\/twitter.com\/search\/realtime?q=%22fuck+voting%22&src=typd",
      "display_url" : "twitter.com\/search\/realtim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265887551414484992",
  "text" : "General tweets about voting might be good for @herpderpedia: https:\/\/t.co\/ZfoglYwa",
  "id" : 265887551414484992,
  "created_at" : "2012-11-06 18:45:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265886875598856192",
  "geo" : { },
  "id_str" : "265886922117873666",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting omg",
  "id" : 265886922117873666,
  "in_reply_to_status_id" : 265886875598856192,
  "created_at" : "2012-11-06 18:42:36 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265878989955018752",
  "geo" : { },
  "id_str" : "265886257882750976",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed That would be fun. We need to have another Artemis night. \/cc @dhiggsbuf",
  "id" : 265886257882750976,
  "in_reply_to_status_id" : 265878989955018752,
  "created_at" : "2012-11-06 18:39:58 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265885834648100865",
  "text" : "\"Rommney\" \"Ubama\"",
  "id" : 265885834648100865,
  "created_at" : "2012-11-06 18:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 25, 38 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 73 ],
      "url" : "https:\/\/t.co\/dMdN7zds",
      "expanded_url" : "https:\/\/twitter.com\/search\/realtime?q=rommey&src=typd",
      "display_url" : "twitter.com\/search\/realtim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265885456049242112",
  "text" : "Considering breaking out @herpderpedia for \"Rommey\" https:\/\/t.co\/dMdN7zds",
  "id" : 265885456049242112,
  "created_at" : "2012-11-06 18:36:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/DRAU29eT",
      "expanded_url" : "http:\/\/www.thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265852321727127552",
  "text" : "A tip for consultants\/contractors: When deciding hourly rates think, \"Am I worth more than 2 girls snuggling?\" http:\/\/t.co\/DRAU29eT",
  "id" : 265852321727127552,
  "created_at" : "2012-11-06 16:25:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/bL0ksJXx",
      "expanded_url" : "http:\/\/rubbercat.net\/text\/horse_ebooks-speech.html",
      "display_url" : "rubbercat.net\/text\/horse_ebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265843829377208320",
  "text" : "Everything happens, so much. http:\/\/t.co\/bL0ksJXx",
  "id" : 265843829377208320,
  "created_at" : "2012-11-06 15:51:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265843064319397888",
  "geo" : { },
  "id_str" : "265843599583870977",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws It's terrifying that this is in Rochester.",
  "id" : 265843599583870977,
  "in_reply_to_status_id" : 265843064319397888,
  "created_at" : "2012-11-06 15:50:27 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265834273532157953",
  "text" : "Voted! I was the only Q in the district, had an entire page to myself!",
  "id" : 265834273532157953,
  "created_at" : "2012-11-06 15:13:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265666360535834625",
  "geo" : { },
  "id_str" : "265666628635746304",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv WTF? maybe try reinstalling? On a newish Macbook Pro here and works fine.",
  "id" : 265666628635746304,
  "in_reply_to_status_id" : 265666360535834625,
  "created_at" : "2012-11-06 04:07:14 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 7, 15 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/nJaZ97Ph",
      "expanded_url" : "http:\/\/rubygems.org\/fluid-icon.png",
      "display_url" : "rubygems.org\/fluid-icon.png"
    } ]
  },
  "in_reply_to_status_id_str" : "265662061672017920",
  "geo" : { },
  "id_str" : "265665093872791552",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @evanphx Will http:\/\/t.co\/nJaZ97Ph do? We have  PSD somewhere I can try to find...",
  "id" : 265665093872791552,
  "in_reply_to_status_id" : 265662061672017920,
  "created_at" : "2012-11-06 04:01:08 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 3, 15 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265653143705112576",
  "text" : "Yo @fredyatesiv: \"Patch 11\/3 - Fixed some problems with starting Cargo Commander on Mac\"",
  "id" : 265653143705112576,
  "created_at" : "2012-11-06 03:13:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 3, 12 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1sZKrz0Z",
      "expanded_url" : "http:\/\/openhack.github.com",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "265644231559884801",
  "text" : "RT @openhack: Big welcomes to new OpenHack cities: Columbus, Columbia, and Iowa City! That\u2019s 17 cities so far. Where\u2019s yours? http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/1sZKrz0Z",
        "expanded_url" : "http:\/\/openhack.github.com",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "265644178078306305",
    "text" : "Big welcomes to new OpenHack cities: Columbus, Columbia, and Iowa City! That\u2019s 17 cities so far. Where\u2019s yours? http:\/\/t.co\/1sZKrz0Z",
    "id" : 265644178078306305,
    "created_at" : "2012-11-06 02:38:02 +0000",
    "user" : {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "protected" : false,
      "id_str" : "715440464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2820837518\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 715440464,
      "verified" : false
    }
  },
  "id" : 265644231559884801,
  "created_at" : "2012-11-06 02:38:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/n3xFr0zF",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2012\/11\/05\/the-rubygems-hackfest-at-rubyconf.html",
      "display_url" : "blog.rubygems.org\/2012\/11\/05\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265642587757613057",
  "text" : "Really flattered by the http:\/\/t.co\/bdjsRgTW hackfest at #rubyconf. Sad I wasn't there, but happy it rocked! http:\/\/t.co\/n3xFr0zF",
  "id" : 265642587757613057,
  "created_at" : "2012-11-06 02:31:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 3, 12 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/yarGWXHh",
      "expanded_url" : "http:\/\/openhack.github.com\/buffalo",
      "display_url" : "openhack.github.com\/buffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "265637474200592384",
  "text" : "RT @openhack: OpenHack Buffalo is tomorrow @coworkbuffalo ! http:\/\/t.co\/yarGWXHh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 29, 43 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/yarGWXHh",
        "expanded_url" : "http:\/\/openhack.github.com\/buffalo",
        "display_url" : "openhack.github.com\/buffalo"
      } ]
    },
    "geo" : { },
    "id_str" : "265637307556691970",
    "text" : "OpenHack Buffalo is tomorrow @coworkbuffalo ! http:\/\/t.co\/yarGWXHh",
    "id" : 265637307556691970,
    "created_at" : "2012-11-06 02:10:44 +0000",
    "user" : {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "protected" : false,
      "id_str" : "715440464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2820837518\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 715440464,
      "verified" : false
    }
  },
  "id" : 265637474200592384,
  "created_at" : "2012-11-06 02:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/bkTt28he",
      "expanded_url" : "http:\/\/romneymegaprayer.com\/",
      "display_url" : "romneymegaprayer.com"
    } ]
  },
  "geo" : { },
  "id_str" : "265588034571997184",
  "text" : "Whelp: http:\/\/t.co\/bkTt28he",
  "id" : 265588034571997184,
  "created_at" : "2012-11-05 22:54:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265572028986318848",
  "text" : "\"Seriously what else would you suggest?\" Anything but a bro chugging beer on our city's subreddit's front page?",
  "id" : 265572028986318848,
  "created_at" : "2012-11-05 21:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/VASE5VOh",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Buffalo\/comments\/12nhqw\/does_anyone_not_enjoy_a_member_of_the_bills_army\/",
      "display_url" : "reddit.com\/r\/Buffalo\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265571669505110018",
  "text" : "And with this stupid thread, I've resigned from being anywhere responsible for the content of \/r\/buffalo. http:\/\/t.co\/VASE5VOh",
  "id" : 265571669505110018,
  "created_at" : "2012-11-05 21:49:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 0, 12 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265539634635882496",
  "geo" : { },
  "id_str" : "265541386403725312",
  "in_reply_to_user_id" : 248477732,
  "text" : "@ecarlsen912 lol tiny dogs.",
  "id" : 265541386403725312,
  "in_reply_to_status_id" : 265539634635882496,
  "created_at" : "2012-11-05 19:49:34 +0000",
  "in_reply_to_screen_name" : "ecarlsen912",
  "in_reply_to_user_id_str" : "248477732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Esteves",
      "screen_name" : "gesteves",
      "indices" : [ 3, 12 ],
      "id_str" : "48243",
      "id" : 48243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TVrFDd1u",
      "expanded_url" : "http:\/\/i.imgur.com\/fUh35.gif",
      "display_url" : "i.imgur.com\/fUh35.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "265539505598115840",
  "text" : "RT @gesteves: Just deployed code to production: http:\/\/t.co\/TVrFDd1u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/TVrFDd1u",
        "expanded_url" : "http:\/\/i.imgur.com\/fUh35.gif",
        "display_url" : "i.imgur.com\/fUh35.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "265473862551089153",
    "text" : "Just deployed code to production: http:\/\/t.co\/TVrFDd1u",
    "id" : 265473862551089153,
    "created_at" : "2012-11-05 15:21:15 +0000",
    "user" : {
      "name" : "Guillermo Esteves",
      "screen_name" : "gesteves",
      "protected" : false,
      "id_str" : "48243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477591500000223232\/CquAhQAQ_normal.jpeg",
      "id" : 48243,
      "verified" : false
    }
  },
  "id" : 265539505598115840,
  "created_at" : "2012-11-05 19:42:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265480032829460480",
  "text" : "New favorite emoji face: \u0CA0\u256D\u256E\u0CA0",
  "id" : 265480032829460480,
  "created_at" : "2012-11-05 15:45:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/iOvxnexo",
      "expanded_url" : "http:\/\/www.buffalo.com\/sports\/video\/would-be-nyc-marathon-races-for-a-cause-in-buffalo\/",
      "display_url" : "buffalo.com\/sports\/video\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265472498848657409",
  "text" : "Holy crap, @NYWineWench kicked ass yesterday. http:\/\/t.co\/iOvxnexo",
  "id" : 265472498848657409,
  "created_at" : "2012-11-05 15:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bennett",
      "screen_name" : "MarkBennett",
      "indices" : [ 0, 12 ],
      "id_str" : "11347752",
      "id" : 11347752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264788122188017664",
  "geo" : { },
  "id_str" : "265333905744343040",
  "in_reply_to_user_id" : 11347752,
  "text" : "@MarkBennett not sure if you got the rationale behind this: gems are bundled since if the site went down, how would we get gems? ;)",
  "id" : 265333905744343040,
  "in_reply_to_status_id" : 264788122188017664,
  "created_at" : "2012-11-05 06:05:07 +0000",
  "in_reply_to_screen_name" : "MarkBennett",
  "in_reply_to_user_id_str" : "11347752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Koschei",
      "screen_name" : "jordankoschei",
      "indices" : [ 3, 17 ],
      "id_str" : "249887765",
      "id" : 249887765
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 19, 25 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265326919938084864",
  "text" : "RT @jordankoschei: @qrush For the record, beating the Water Temple is still kind of an achievement.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "265323401965617152",
    "geo" : { },
    "id_str" : "265326511022809089",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush For the record, beating the Water Temple is still kind of an achievement.",
    "id" : 265326511022809089,
    "in_reply_to_status_id" : 265323401965617152,
    "created_at" : "2012-11-05 05:35:44 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Jordan Koschei",
      "screen_name" : "jordankoschei",
      "protected" : false,
      "id_str" : "249887765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496663123126796290\/CfUBvZvh_normal.jpeg",
      "id" : 249887765,
      "verified" : false
    }
  },
  "id" : 265326919938084864,
  "created_at" : "2012-11-05 05:37:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265315647389589504",
  "geo" : { },
  "id_str" : "265323712138604545",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik Added. Man it needs some style help.",
  "id" : 265323712138604545,
  "in_reply_to_status_id" : 265315647389589504,
  "created_at" : "2012-11-05 05:24:37 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/2k2wvjV1",
      "expanded_url" : "http:\/\/summly.com\/",
      "display_url" : "summly.com"
    } ]
  },
  "geo" : { },
  "id_str" : "265323401965617152",
  "text" : "This kid is 15, YC backed, and got Stephen Fry. Beating the Water Temple in Zelda was my crowning achievement at 15. http:\/\/t.co\/2k2wvjV1",
  "id" : 265323401965617152,
  "created_at" : "2012-11-05 05:23:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265314073158250496",
  "text" : "Seriously enjoying Cargo Commander. Lots of roguelike\/NetHack influences...replayability + bones\/corpses of high scores!",
  "id" : 265314073158250496,
  "created_at" : "2012-11-05 04:46:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/265200497839984640\/photo\/1",
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Xz02RH1p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A64ucpxCUAA9_Iy.jpg",
      "id_str" : "265200497844178944",
      "id" : 265200497844178944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A64ucpxCUAA9_Iy.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Xz02RH1p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265200497839984640",
  "text" : "Experience bij. http:\/\/t.co\/Xz02RH1p",
  "id" : 265200497839984640,
  "created_at" : "2012-11-04 21:15:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265194371337564161",
  "geo" : { },
  "id_str" : "265200056439820288",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr Artemis !",
  "id" : 265200056439820288,
  "in_reply_to_status_id" : 265194371337564161,
  "created_at" : "2012-11-04 21:13:15 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265185783755988992",
  "text" : "Captain, detecting octave change in theme music upon entering nebula!",
  "id" : 265185783755988992,
  "created_at" : "2012-11-04 20:16:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265114032300765185",
  "geo" : { },
  "id_str" : "265122154163609600",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting I check letterpress maybe once or twice daily.",
  "id" : 265122154163609600,
  "in_reply_to_status_id" : 265114032300765185,
  "created_at" : "2012-11-04 16:03:41 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/3ZoLrdUc",
      "expanded_url" : "https:\/\/www.gittip.com\/qrush\/",
      "display_url" : "gittip.com\/qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "265110451027845121",
  "text" : "Someone extremely nice maxed out my gittip this week. Already merged some PRs for gitready today. https:\/\/t.co\/3ZoLrdUc &lt;3",
  "id" : 265110451027845121,
  "created_at" : "2012-11-04 15:17:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 0, 11 ],
      "id_str" : "56423575",
      "id" : 56423575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265096183247167491",
  "geo" : { },
  "id_str" : "265108322271772672",
  "in_reply_to_user_id" : 56423575,
  "text" : "@luisjoseve Yep! Nothing is sticking yet.",
  "id" : 265108322271772672,
  "in_reply_to_status_id" : 265096183247167491,
  "created_at" : "2012-11-04 15:08:44 +0000",
  "in_reply_to_screen_name" : "luisjoseve",
  "in_reply_to_user_id_str" : "56423575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265095518911356928",
  "text" : "Snowing in Buffalo!",
  "id" : 265095518911356928,
  "created_at" : "2012-11-04 14:17:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 3, 9 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cmeik\/status\/264902355194109953\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6haaIeDT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A60fSd4CYAAdcC9.jpg",
      "id_str" : "264902355202498560",
      "id" : 264902355202498560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A60fSd4CYAAdcC9.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/6haaIeDT"
    } ],
    "hashtags" : [ {
      "text" : "RubyConf",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/tKY5ePRQ",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "264931532291063808",
  "text" : "RT @cmeik: Already a bunch of pull requests on http:\/\/t.co\/tKY5ePRQ! #RubyConf http:\/\/t.co\/6haaIeDT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cmeik\/status\/264902355194109953\/photo\/1",
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/6haaIeDT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A60fSd4CYAAdcC9.jpg",
        "id_str" : "264902355202498560",
        "id" : 264902355202498560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A60fSd4CYAAdcC9.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/6haaIeDT"
      } ],
      "hashtags" : [ {
        "text" : "RubyConf",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/tKY5ePRQ",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "264902355194109953",
    "text" : "Already a bunch of pull requests on http:\/\/t.co\/tKY5ePRQ! #RubyConf http:\/\/t.co\/6haaIeDT",
    "id" : 264902355194109953,
    "created_at" : "2012-11-04 01:30:18 +0000",
    "user" : {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "protected" : false,
      "id_str" : "6815762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563790577485889540\/RAksq4d3_normal.jpeg",
      "id" : 6815762,
      "verified" : false
    }
  },
  "id" : 264931532291063808,
  "created_at" : "2012-11-04 03:26:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bennett",
      "screen_name" : "MarkBennett",
      "indices" : [ 3, 15 ],
      "id_str" : "11347752",
      "id" : 11347752
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 104, 110 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/kGRPlmA7",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 72, 93 ],
      "url" : "https:\/\/t.co\/RrDR5r6s",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/pull\/478",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264931468940288000",
  "text" : "RT @MarkBennett: My pull requests was merged into http:\/\/t.co\/kGRPlmA7. https:\/\/t.co\/RrDR5r6s Thanks to @cmeik for organising this RubyC ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C. Scott Meiklejohn",
        "screen_name" : "cmeik",
        "indices" : [ 87, 93 ],
        "id_str" : "6815762",
        "id" : 6815762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/kGRPlmA7",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 55, 76 ],
        "url" : "https:\/\/t.co\/RrDR5r6s",
        "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/pull\/478",
        "display_url" : "github.com\/rubygems\/rubyg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264919811291766785",
    "text" : "My pull requests was merged into http:\/\/t.co\/kGRPlmA7. https:\/\/t.co\/RrDR5r6s Thanks to @cmeik for organising this RubyConf hackfest!",
    "id" : 264919811291766785,
    "created_at" : "2012-11-04 02:39:39 +0000",
    "user" : {
      "name" : "Mark Bennett",
      "screen_name" : "MarkBennett",
      "protected" : false,
      "id_str" : "11347752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000657296957\/7eeccc1928a214f1a13215c54d2be734_normal.jpeg",
      "id" : 11347752,
      "verified" : false
    }
  },
  "id" : 264931468940288000,
  "created_at" : "2012-11-04 03:25:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264887457001136128",
  "geo" : { },
  "id_str" : "264887677994807298",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik holy crap, this is awesome. Please remind that anyone with a patch gets a commit bit :)",
  "id" : 264887677994807298,
  "in_reply_to_status_id" : 264887457001136128,
  "created_at" : "2012-11-04 00:31:58 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 3, 9 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cmeik\/status\/264887457001136128\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/tVImmuTR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A60RvRxCYAEhg0Z.jpg",
      "id_str" : "264887457005330433",
      "id" : 264887457005330433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A60RvRxCYAEhg0Z.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/tVImmuTR"
    } ],
    "hashtags" : [ {
      "text" : "RubyConf",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/5pvkqQ9z",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "264887524109975553",
  "text" : "RT @cmeik: http:\/\/t.co\/5pvkqQ9z hacking in session.  Come join us.  #RubyConf http:\/\/t.co\/tVImmuTR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cmeik\/status\/264887457001136128\/photo\/1",
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/tVImmuTR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A60RvRxCYAEhg0Z.jpg",
        "id_str" : "264887457005330433",
        "id" : 264887457005330433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A60RvRxCYAEhg0Z.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/tVImmuTR"
      } ],
      "hashtags" : [ {
        "text" : "RubyConf",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/5pvkqQ9z",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "264887457001136128",
    "text" : "http:\/\/t.co\/5pvkqQ9z hacking in session.  Come join us.  #RubyConf http:\/\/t.co\/tVImmuTR",
    "id" : 264887457001136128,
    "created_at" : "2012-11-04 00:31:07 +0000",
    "user" : {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "protected" : false,
      "id_str" : "6815762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563790577485889540\/RAksq4d3_normal.jpeg",
      "id" : 6815762,
      "verified" : false
    }
  },
  "id" : 264887524109975553,
  "created_at" : "2012-11-04 00:31:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264812112210165761",
  "geo" : { },
  "id_str" : "264832194189619200",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv yep...strange :(",
  "id" : 264832194189619200,
  "in_reply_to_status_id" : 264812112210165761,
  "created_at" : "2012-11-03 20:51:30 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264806555738832896",
  "text" : "Trying out Cargo Commander. Seriously fun.",
  "id" : 264806555738832896,
  "created_at" : "2012-11-03 19:09:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264738844530839552",
  "text" : "Scumbag dog: doesn\u2019t eat breakfast kibble, will gladly shred and chew any tissue paper found instead.",
  "id" : 264738844530839552,
  "created_at" : "2012-11-03 14:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 3, 12 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/HsOwm0no",
      "expanded_url" : "http:\/\/is.gd\/ibpBsE",
      "display_url" : "is.gd\/ibpBsE"
    } ]
  },
  "geo" : { },
  "id_str" : "264600884141518849",
  "text" : "RT @rubygems: sandy (0.0.2): http:\/\/t.co\/HsOwm0no Presents a simple API to consume power outage data for the Greater New York area.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rubygems.org\" rel=\"nofollow\"\u003ERubyGems.org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/HsOwm0no",
        "expanded_url" : "http:\/\/is.gd\/ibpBsE",
        "display_url" : "is.gd\/ibpBsE"
      } ]
    },
    "geo" : { },
    "id_str" : "264473788291362816",
    "text" : "sandy (0.0.2): http:\/\/t.co\/HsOwm0no Presents a simple API to consume power outage data for the Greater New York area.",
    "id" : 264473788291362816,
    "created_at" : "2012-11-02 21:07:19 +0000",
    "user" : {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "protected" : false,
      "id_str" : "14881835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651086638\/rubygems-125x125t_normal.png",
      "id" : 14881835,
      "verified" : false
    }
  },
  "id" : 264600884141518849,
  "created_at" : "2012-11-03 05:32:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264526859600019456",
  "geo" : { },
  "id_str" : "264534182582157312",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw Not really. The course work they have comes first...lots of compiler and syntax errors. Trying to introduce HTML.",
  "id" : 264534182582157312,
  "in_reply_to_status_id" : 264526859600019456,
  "created_at" : "2012-11-03 01:07:18 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "redinger",
      "screen_name" : "redinger",
      "indices" : [ 0, 9 ],
      "id_str" : "8140482",
      "id" : 8140482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264485842041597953",
  "geo" : { },
  "id_str" : "264487110503956480",
  "in_reply_to_user_id" : 8140482,
  "text" : "@redinger Please stand clear of the doors. Por favor mant\u00E9ngase alejado de las puertas.",
  "id" : 264487110503956480,
  "in_reply_to_status_id" : 264485842041597953,
  "created_at" : "2012-11-02 22:00:15 +0000",
  "in_reply_to_screen_name" : "redinger",
  "in_reply_to_user_id_str" : "8140482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug March",
      "screen_name" : "Marchdoe",
      "indices" : [ 3, 12 ],
      "id_str" : "12506",
      "id" : 12506
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 115, 121 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264463647626125312",
  "text" : "RT @Marchdoe: \"It's rarely the person that complains the loudest that is most helpful when actually shipping.\" via @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 101, 107 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264452544066113536",
    "text" : "\"It's rarely the person that complains the loudest that is most helpful when actually shipping.\" via @qrush",
    "id" : 264452544066113536,
    "created_at" : "2012-11-02 19:42:54 +0000",
    "user" : {
      "name" : "Doug March",
      "screen_name" : "Marchdoe",
      "protected" : false,
      "id_str" : "12506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/14716872\/dm_normal.jpg",
      "id" : 12506,
      "verified" : false
    }
  },
  "id" : 264463647626125312,
  "created_at" : "2012-11-02 20:27:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 57, 63 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 91, 105 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264463333871210497",
  "text" : "RT @kevinpurdy: Just made my first git commit, thanks to @qrush, candy, Southern Tier, and @coworkbuffalo. Noting this for the record.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 41, 47 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 75, 89 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264463057986654208",
    "text" : "Just made my first git commit, thanks to @qrush, candy, Southern Tier, and @coworkbuffalo. Noting this for the record.",
    "id" : 264463057986654208,
    "created_at" : "2012-11-02 20:24:41 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 264463333871210497,
  "created_at" : "2012-11-02 20:25:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264437365840424960",
  "geo" : { },
  "id_str" : "264437632954662913",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 it's pretty funny how not much has changed.",
  "id" : 264437632954662913,
  "in_reply_to_status_id" : 264437365840424960,
  "created_at" : "2012-11-02 18:43:39 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264433839567425538",
  "text" : "Going on a month now of weekly visits to my old high school's programming class, helping w\/ Java\/C++ and introducing them to JS. Loving it.",
  "id" : 264433839567425538,
  "created_at" : "2012-11-02 18:28:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264389137996587008",
  "text" : "Happy Friday! \/play trololo",
  "id" : 264389137996587008,
  "created_at" : "2012-11-02 15:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/18mtR1Hq",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=4732382",
      "display_url" : "news.ycombinator.com\/item?id=4732382"
    } ]
  },
  "geo" : { },
  "id_str" : "264370692601032704",
  "text" : "Hacker News: Go for the links, stay for the great advice. http:\/\/t.co\/18mtR1Hq",
  "id" : 264370692601032704,
  "created_at" : "2012-11-02 14:17:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 3, 19 ],
      "id_str" : "10373972",
      "id" : 10373972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264352066573590528",
  "text" : "RT @chrisguillebeau: \"Many people die at 25 and aren't buried until they are 75.\" -Benjamin Franklin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264294542323363842",
    "text" : "\"Many people die at 25 and aren't buried until they are 75.\" -Benjamin Franklin",
    "id" : 264294542323363842,
    "created_at" : "2012-11-02 09:15:03 +0000",
    "user" : {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "protected" : false,
      "id_str" : "10373972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509882788825149440\/B-q3gGrR_normal.jpeg",
      "id" : 10373972,
      "verified" : true
    }
  },
  "id" : 264352066573590528,
  "created_at" : "2012-11-02 13:03:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264193560373501953",
  "geo" : { },
  "id_str" : "264195068536188928",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I want to believe :(",
  "id" : 264195068536188928,
  "in_reply_to_status_id" : 264193560373501953,
  "created_at" : "2012-11-02 02:39:47 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264079704959623168",
  "geo" : { },
  "id_str" : "264080179180208128",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly Any methods on Symbol always end up bothering me right to my core. No idea why, it just feels gross.",
  "id" : 264080179180208128,
  "in_reply_to_status_id" : 264079704959623168,
  "created_at" : "2012-11-01 19:03:15 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 9, 18 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 19, 29 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264029288171466752",
  "geo" : { },
  "id_str" : "264029504220045312",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @rubyconf @confreaks sweet!",
  "id" : 264029504220045312,
  "in_reply_to_status_id" : 264029288171466752,
  "created_at" : "2012-11-01 15:41:53 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 10, 20 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264028853847080960",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf @confreaks hey no sound yet? also what room\/track is being streamed?",
  "id" : 264028853847080960,
  "created_at" : "2012-11-01 15:39:18 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 5, 14 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/pxZOuf3e",
      "expanded_url" : "http:\/\/www.justin.tv\/confreaks#\/w\/4092769792",
      "display_url" : "justin.tv\/confreaks#\/w\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264028097676992512",
  "text" : "Yay, @rubyconf stream is up! http:\/\/t.co\/pxZOuf3e",
  "id" : 264028097676992512,
  "created_at" : "2012-11-01 15:36:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    }, {
      "name" : "Ben Burton",
      "screen_name" : "bjburton",
      "indices" : [ 14, 23 ],
      "id_str" : "14858358",
      "id" : 14858358
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 24, 34 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/M0cYQoLy",
      "expanded_url" : "http:\/\/rubyconf.org",
      "display_url" : "rubyconf.org"
    } ]
  },
  "in_reply_to_status_id_str" : "263993359805341696",
  "geo" : { },
  "id_str" : "264006545363324928",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft @bjburton @aquaranto it will be on http:\/\/t.co\/M0cYQoLy once available AFAIK",
  "id" : 264006545363324928,
  "in_reply_to_status_id" : 263993359805341696,
  "created_at" : "2012-11-01 14:10:40 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Frost",
      "screen_name" : "jephjacques",
      "indices" : [ 12, 24 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264001562685341696",
  "text" : "Feeling for @jephjacques today. Get better, please!",
  "id" : 264001562685341696,
  "created_at" : "2012-11-01 13:50:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 20, 29 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 35, 49 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263992141230010368",
  "text" : "Going to livestream @rubyconf from @coworkbuffalo on our projector today if any Ruby kin want to watch!",
  "id" : 263992141230010368,
  "created_at" : "2012-11-01 13:13:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
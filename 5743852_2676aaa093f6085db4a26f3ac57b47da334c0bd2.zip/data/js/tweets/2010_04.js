Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13157966900",
  "text" : "Now that's a wish. http:\/\/seattletimes.nwsource.com\/html\/localnews\/2011740342_electronboy30m.html",
  "id" : 13157966900,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Apolzon",
      "screen_name" : "apolzon",
      "indices" : [ 0, 8 ],
      "id_str" : "39290355",
      "id" : 39290355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13134521424",
  "geo" : { },
  "id_str" : "13164309537",
  "in_reply_to_user_id" : 39290355,
  "text" : "@apolzon same, maybe I'm biased",
  "id" : 13164309537,
  "in_reply_to_status_id" : 13134521424,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "apolzon",
  "in_reply_to_user_id_str" : "39290355",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13187928671",
  "text" : "Holy shit, it's May.",
  "id" : 13187928671,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imaginerit",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13195194459",
  "text" : "Hot dog robot is a hit, again! Yay @ablissfulgal! #imaginerit http:\/\/twitpic.com\/1jzr9h",
  "id" : 13195194459,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imaginerit",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13196021275",
  "text" : "Seriously impressed by the amount of people that showed up for #imaginerit. Campus is packed.",
  "id" : 13196021275,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imaginerit",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13201514583",
  "text" : "Pep band starting up at #imaginerit http:\/\/twitpic.com\/1k0xb7",
  "id" : 13201514583,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13206288784",
  "text" : "OBAMANOS! http:\/\/twitpic.com\/1k1xn8",
  "id" : 13206288784,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nethack.alt.org bot",
      "screen_name" : "nethackaltorg",
      "indices" : [ 3, 17 ],
      "id_str" : "88474436",
      "id" : 88474436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13209191619",
  "text" : "RT @nethackaltorg: DoctorNick ascended: http:\/\/alt.org\/nethack\/userdata\/DoctorNick\/dumplog\/1272343729.nh343.txt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13209182365",
    "text" : "DoctorNick ascended: http:\/\/alt.org\/nethack\/userdata\/DoctorNick\/dumplog\/1272343729.nh343.txt",
    "id" : 13209182365,
    "created_at" : "2010-05-01 21:25:31 +0000",
    "user" : {
      "name" : "nethack.alt.org bot",
      "screen_name" : "nethackaltorg",
      "protected" : false,
      "id_str" : "88474436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516351938\/alt_favicon_normal.png",
      "id" : 88474436,
      "verified" : false
    }
  },
  "id" : 13209191619,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13212246032",
  "text" : "I just unlocked the \"Explorer\" badge on @foursquare! http:\/\/4sq.com\/c5Eeur",
  "id" : 13212246032,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13212246111",
  "text" : "I'm at Michelina's Italian Eatery (2700 W Henrietta Rd, Pittsford). http:\/\/4sq.com\/aF78kB",
  "id" : 13212246111,
  "created_at" : "2010-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13106015329",
  "text" : "I'm at MacGregors' Grill & Tap Room (300 Jefferson Rd, Rochester). http:\/\/4sq.com\/6hNKyN",
  "id" : 13106015329,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13113330362",
  "text" : "Watching Cannibal: The Musical. So many South Park echoes.",
  "id" : 13113330362,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13134732761",
  "text" : "Poster came out way darker than expected. Boo.",
  "id" : 13134732761,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13134869061",
  "text" : "Ok, maybe it came out alright: http:\/\/twitpic.com\/1jnzoj",
  "id" : 13134869061,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13142388268",
  "text" : "git config --global alias.up '!git fetch origin && git rebase origin\/master'",
  "id" : 13142388268,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Celis",
      "screen_name" : "stephencelis",
      "indices" : [ 0, 13 ],
      "id_str" : "6523632",
      "id" : 6523632
    }, {
      "name" : "Thomas Ritz",
      "screen_name" : "rittsu",
      "indices" : [ 14, 21 ],
      "id_str" : "25809963",
      "id" : 25809963
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 22, 29 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13142596270",
  "geo" : { },
  "id_str" : "13143213767",
  "in_reply_to_user_id" : 6523632,
  "text" : "@stephencelis @rittsu @mislav git fetch gets all the latest refs, pull --rebase will only get the one you asked for",
  "id" : 13143213767,
  "in_reply_to_status_id" : 13142596270,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "stephencelis",
  "in_reply_to_user_id_str" : "6523632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13146258355",
  "text" : "Tons of job listings, wake up #RIT folks: http:\/\/news.ycombinator.com\/item?id=1308582",
  "id" : 13146258355,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13152108571",
  "text" : "Animations in the Android twitter app are really cool. This blows Twidroid and TweetCaster out of the water.",
  "id" : 13152108571,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13152142360",
  "text" : "Easily the best UI out of any Droid app I've used.",
  "id" : 13152142360,
  "created_at" : "2010-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13035347742",
  "geo" : { },
  "id_str" : "13036422344",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton definitely check out Go, you'll love it.",
  "id" : 13036422344,
  "in_reply_to_status_id" : 13035347742,
  "created_at" : "2010-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Green",
      "screen_name" : "hotgazpacho",
      "indices" : [ 0, 12 ],
      "id_str" : "10687942",
      "id" : 10687942
    }, {
      "name" : "Eric Hexter",
      "screen_name" : "ehexter",
      "indices" : [ 13, 21 ],
      "id_str" : "14184054",
      "id" : 14184054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13077186364",
  "geo" : { },
  "id_str" : "13080309399",
  "in_reply_to_user_id" : 10687942,
  "text" : "@hotgazpacho @ehexter Please do. Make some noise!! http:\/\/litanyagainstfear.com\/blog\/2010\/04\/18\/ironruby-drops-make-some-noise\/",
  "id" : 13080309399,
  "in_reply_to_status_id" : 13077186364,
  "created_at" : "2010-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotgazpacho",
  "in_reply_to_user_id_str" : "10687942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13014514948",
  "text" : "Super Mario Crossover. Play the original as other characters. http:\/\/www.playedonline.com\/game\/598161\/super-mario-crossover.html",
  "id" : 13014514948,
  "created_at" : "2010-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 11, 18 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13032863453",
  "text" : "node.js on @heroku, this is huge. http:\/\/blog.heroku.com\/archives\/2010\/4\/28\/node_js_support_experimental\/",
  "id" : 13032863453,
  "created_at" : "2010-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12915746687",
  "text" : "I'm at TC Riley's (200 Park Point Dr, Rochester). http:\/\/4sq.com\/6QibLZ",
  "id" : 12915746687,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12919037928",
  "geo" : { },
  "id_str" : "12919266174",
  "in_reply_to_user_id" : 16892522,
  "text" : "@wolfz0rz never too late, welcome to the party",
  "id" : 12919266174,
  "in_reply_to_status_id" : 12919037928,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "cregatron",
  "in_reply_to_user_id_str" : "16892522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12926076744",
  "text" : "Hard to tell but I'm in a steel box used for venting the lights ~3 stories up with only an inch of plaster below us. http:\/\/is.gd\/bJjdz",
  "id" : 12926076744,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Madsen",
      "screen_name" : "blatyo",
      "indices" : [ 0, 7 ],
      "id_str" : "14188909",
      "id" : 14188909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12942825735",
  "geo" : { },
  "id_str" : "12943512475",
  "in_reply_to_user_id" : 14188909,
  "text" : "@blatyo that guy is such a hipster. We should talk some ruby sometime :)",
  "id" : 12943512475,
  "in_reply_to_status_id" : 12942825735,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "blatyo",
  "in_reply_to_user_id_str" : "14188909",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bleigh",
      "screen_name" : "mbleigh",
      "indices" : [ 0, 8 ],
      "id_str" : "12025282",
      "id" : 12025282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12949935233",
  "geo" : { },
  "id_str" : "12949978292",
  "in_reply_to_user_id" : 12025282,
  "text" : "@mbleigh everyone else in the world who doesn't use cap.",
  "id" : 12949978292,
  "in_reply_to_status_id" : 12949935233,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mbleigh",
  "in_reply_to_user_id_str" : "12025282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12957157610",
  "text" : "Lost my 10th RIT ID. Zero recollection of where I last had it. This happens constantly to me.",
  "id" : 12957157610,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12964936172",
  "text" : "\"Greenfield development of Revenue Generating Product\" RECRUITER FAIL",
  "id" : 12964936172,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    }, {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 27, 37 ],
      "id_str" : "10453902",
      "id" : 10453902
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 81, 89 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12851843637",
  "geo" : { },
  "id_str" : "12853352300",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek make sure to bug @jbarnette or pull request him, he can handle it. \/cc @drbrain",
  "id" : 12853352300,
  "in_reply_to_status_id" : 12851843637,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12847165126",
  "geo" : { },
  "id_str" : "12853381967",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital Amazing.",
  "id" : 12853381967,
  "in_reply_to_status_id" : 12847165126,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12880252838",
  "text" : "Video: \u201CHe\u2019s my brother\u201D http:\/\/tumblr.com\/x1793uhgu",
  "id" : 12880252838,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12883404153",
  "geo" : { },
  "id_str" : "12884042182",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens http:\/\/github.com\/jferris\/config_files",
  "id" : 12884042182,
  "in_reply_to_status_id" : 12883404153,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12890364138",
  "text" : "The case for git rebase: http:\/\/darwinweb.net\/articles\/86",
  "id" : 12890364138,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12897871680",
  "text" : "Great little Redis tutorial, covers basics and a good dive into how to use it. http:\/\/simonwillison.net\/static\/2010\/redis-tutorial\/",
  "id" : 12897871680,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12796265322",
  "text" : "Played Jarts for the first time tonight...way too hard. Brought in beer bottles to hit for more points, renamed to Barts.",
  "id" : 12796265322,
  "created_at" : "2010-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12835543605",
  "text" : "Prepping for RIT's public speaking contest. Managed to toss in a reference to drunken photos on Facebook in my talk about network neutrality",
  "id" : 12835543605,
  "created_at" : "2010-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12847049327",
  "text" : "I'm at Five Guys Burgers & Fries (1100 Jefferson Rd, Rochester). http:\/\/4sq.com\/cgW4od",
  "id" : 12847049327,
  "created_at" : "2010-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12736930925",
  "text" : "Loved the signs Sabres fans were holding: \"2010 Boston Massacre\"",
  "id" : 12736930925,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12782117739",
  "text" : "Absolutely exhausted after several hours of laundry. I need to invent self-cleaning clothes.",
  "id" : 12782117739,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12788417939",
  "text" : "I'm at Wok With You (300 Park Point Drive Suite 110, Rochester). http:\/\/4sq.com\/4Hn3Y1",
  "id" : 12788417939,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian H",
      "screen_name" : "furan",
      "indices" : [ 93, 99 ],
      "id_str" : "10329292",
      "id" : 10329292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12673824117",
  "text" : "http:\/\/www.playedonline.com\/game\/598079\/sydney-shark.html is really the best game ever. (via @furan)",
  "id" : 12673824117,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12699837097",
  "text" : "http:\/\/howtousetwitterformarketingandpr.com\/",
  "id" : 12699837097,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12711437116",
  "text" : "Sitting in on Brian Kernighan's talk here at RIT. The CS professors are as giddy as little girls.",
  "id" : 12711437116,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12713734627",
  "text" : "Next books to read for me are going to The Practice of Programming and finally shoving through K&R. Need to get inside of this guy's head.",
  "id" : 12713734627,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12718819211",
  "text" : "Overall gist of Kernighan's talk: Programming is cool and all, but teaching computing in general to everyone is important too.",
  "id" : 12718819211,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12729641040",
  "text" : "Cmon Sabres!",
  "id" : 12729641040,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12731565026",
  "text" : "2-0 sabres after the first period...feeling too familiar...",
  "id" : 12731565026,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12672740761",
  "text" : "Wow. Pathetic. http:\/\/www.southparkstudios.com\/news\/3878",
  "id" : 12672740761,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12618361211",
  "geo" : { },
  "id_str" : "12618479636",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith couldn't come sooner. i've had enough of time wasting projects and incompetent group members.",
  "id" : 12618479636,
  "in_reply_to_status_id" : 12618361211,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12624675893",
  "text" : "The history of 4.2.2.2: http:\/\/www.tummy.com\/Community\/Articles\/famous-dns-server\/",
  "id" : 12624675893,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12653316796",
  "text" : "RubyGems 1.3.7.pre.1 is out. Help test it! (download it, gem install it, run update_rubygems) http:\/\/is.gd\/bDPi9",
  "id" : 12653316796,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12655441861",
  "text" : "For some people, email just a way to share word documents as images. I don't want to get emails from those people.",
  "id" : 12655441861,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Petschnig",
      "screen_name" : "cpetschnig",
      "indices" : [ 0, 11 ],
      "id_str" : "48014477",
      "id" : 48014477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12654488936",
  "geo" : { },
  "id_str" : "12655499324",
  "in_reply_to_user_id" : 48014477,
  "text" : "@cpetschnig agreed, the prerelease install mechanism could be way easier...let's make it happen!",
  "id" : 12655499324,
  "in_reply_to_status_id" : 12654488936,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "cpetschnig",
  "in_reply_to_user_id_str" : "48014477",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 29, 37 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12656138670",
  "text" : "Photo: Just use jQuery! (via @capotej) http:\/\/tumblr.com\/x178y7q4y",
  "id" : 12656138670,
  "created_at" : "2010-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 0, 8 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12551315182",
  "geo" : { },
  "id_str" : "12551619166",
  "in_reply_to_user_id" : 839931,
  "text" : "@ddollar i've heard good things about http:\/\/github.com\/pokeb\/asi-http-request",
  "id" : 12551619166,
  "in_reply_to_status_id" : 12551315182,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ddollar",
  "in_reply_to_user_id_str" : "839931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12551760626",
  "text" : "I feel like I've been in crunch time this whole last quarter of school, no time at all for OSS or pet projects. Frustrating. 3 more weeks.",
  "id" : 12551760626,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12559105990",
  "geo" : { },
  "id_str" : "12560108597",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek yeah definitely would love to make that easier...now sure of the best way with the gems in S3",
  "id" : 12560108597,
  "in_reply_to_status_id" : 12559105990,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 0, 11 ],
      "id_str" : "19661139",
      "id" : 19661139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12599314322",
  "geo" : { },
  "id_str" : "12600216793",
  "in_reply_to_user_id" : 19661139,
  "text" : "@spastorino sweet, make it happen!",
  "id" : 12600216793,
  "in_reply_to_status_id" : 12599314322,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "spastorino",
  "in_reply_to_user_id_str" : "19661139",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santiago Pastorino",
      "screen_name" : "spastorino",
      "indices" : [ 0, 11 ],
      "id_str" : "19661139",
      "id" : 19661139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12599399727",
  "geo" : { },
  "id_str" : "12601791430",
  "in_reply_to_user_id" : 19661139,
  "text" : "@spastorino would love to see it. waiting on lots of plugins to get up to speed. haven't had a lot of time to spend on it lately",
  "id" : 12601791430,
  "in_reply_to_status_id" : 12599399727,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "spastorino",
  "in_reply_to_user_id_str" : "19661139",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nethack.alt.org bot",
      "screen_name" : "nethackaltorg",
      "indices" : [ 3, 17 ],
      "id_str" : "88474436",
      "id" : 88474436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12602103021",
  "text" : "RT @nethackaltorg: DoctorNick (Cav Hum Mal Neu), 114516 points, killed by the invisible Chromatic Dragon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "12602068791",
    "text" : "DoctorNick (Cav Hum Mal Neu), 114516 points, killed by the invisible Chromatic Dragon",
    "id" : 12602068791,
    "created_at" : "2010-04-21 22:36:52 +0000",
    "user" : {
      "name" : "nethack.alt.org bot",
      "screen_name" : "nethackaltorg",
      "protected" : false,
      "id_str" : "88474436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516351938\/alt_favicon_normal.png",
      "id" : 88474436,
      "verified" : false
    }
  },
  "id" : 12602103021,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12602116516",
  "text" : "I am always woefully unprepared for the quest nemesis.",
  "id" : 12602116516,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12605114627",
  "text" : "The law of CS students: There's always a way to make a simple assignment complicated and 10x longer code wise.",
  "id" : 12605114627,
  "created_at" : "2010-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12492940339",
  "text" : "Really sad to see this happening. http:\/\/devver.net\/blog\/2010\/04\/closing-up-shop\/",
  "id" : 12492940339,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12516032303",
  "text" : "Rules I wish every developer would learn: http:\/\/pragprog.com\/the-pragmatic-programmer\/extracts\/tips",
  "id" : 12516032303,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12519787569",
  "geo" : { },
  "id_str" : "12519979538",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek we don't really track what's inside of gems yet...you'd need to `gem mirror` and see",
  "id" : 12519979538,
  "in_reply_to_status_id" : 12519787569,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12541460356",
  "text" : "THANKS RIT GMAIL, FORGETTING MY EMAIL FORWARDING SETTINGS FOR THE THIRD TIME",
  "id" : 12541460356,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12544937465",
  "text" : "Anyone looking for entry level developers? I happen to know a lot of smart RIT kids who are graduating.",
  "id" : 12544937465,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12431319538",
  "text" : "The \"Hoarding: Buried Alive\" show makes me really anxious.",
  "id" : 12431319538,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12457542283",
  "text" : "\"I\u2019m not a real programmer. I throw together things until it works then I move on. The real programmers...\" http:\/\/tumblr.com\/x178timd0",
  "id" : 12457542283,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12470685582",
  "text" : "OH BOY UML EXACTLY WHAT I LOVE LEARNING ABOUT",
  "id" : 12470685582,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12473801022",
  "text" : "Humans vs. Zombies has started again on campus. I've always wanted to go rogue and just start nailing everyone with nerf darts.",
  "id" : 12473801022,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12475519518",
  "text" : "Well, I found my source to read for this week. http:\/\/github.com\/rtomayko\/rpg",
  "id" : 12475519518,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "towski",
      "screen_name" : "towski",
      "indices" : [ 40, 47 ],
      "id_str" : "10188202",
      "id" : 10188202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12482930226",
  "text" : "Photo: I need this Magic card, now. via @towski http:\/\/tumblr.com\/x178u59h2",
  "id" : 12482930226,
  "created_at" : "2010-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 0, 7 ],
      "id_str" : "369604063",
      "id" : 369604063
    }, {
      "name" : "Chris Bilson",
      "screen_name" : "cbilson",
      "indices" : [ 8, 16 ],
      "id_str" : "721053",
      "id" : 721053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12368035037",
  "text" : "@armmer @cbilson definitely considering writing a Rubyist response to that, as someone who's deep into Rails and now has used MVC 2",
  "id" : 12368035037,
  "created_at" : "2010-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s bellware",
      "screen_name" : "bellware",
      "indices" : [ 67, 76 ],
      "id_str" : "1183038558",
      "id" : 1183038558
    }, {
      "name" : "Chris Bilson",
      "screen_name" : "cbilson",
      "indices" : [ 92, 100 ],
      "id_str" : "721053",
      "id" : 721053
    }, {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 101, 108 ],
      "id_str" : "369604063",
      "id" : 369604063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12382628017",
  "text" : "IronRuby drops, make some noise! http:\/\/is.gd\/bxK1a My reaction to @bellware's article. \/cc @cbilson @armmer",
  "id" : 12382628017,
  "created_at" : "2010-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12407386430",
  "text" : "I wish someone would do this in the US. I'd vote for them! http:\/\/www.madcapntom.co.uk\/",
  "id" : 12407386430,
  "created_at" : "2010-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12400780154",
  "geo" : { },
  "id_str" : "12410558235",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape it's Rails compatible and passing most of RubySpec. JRuby isn't fully there yet either but it's gained a lot of traction",
  "id" : 12410558235,
  "in_reply_to_status_id" : 12400780154,
  "created_at" : "2010-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Jimmy Schementi",
      "screen_name" : "jschementi",
      "indices" : [ 75, 86 ],
      "id_str" : "8007442",
      "id" : 8007442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12400780154",
  "geo" : { },
  "id_str" : "12410624380",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape More info on compatibility is at http:\/\/ironruby.info. Perhaps @jschementi could answer more specific questions :)",
  "id" : 12410624380,
  "in_reply_to_status_id" : 12400780154,
  "created_at" : "2010-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12317746344",
  "text" : "I'm at The Distillery (3010 Winton Road South, Rochester). http:\/\/4sq.com\/5z6Ase",
  "id" : 12317746344,
  "created_at" : "2010-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12351838099",
  "text" : "Shopping for apartments ~400 miles away from the city is impossible. Realtors don't respond, need to actually look at places.",
  "id" : 12351838099,
  "created_at" : "2010-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcbos",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "glrb",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "barcampnyc5",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "jsconf",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12359436753",
  "text" : "So many cool tech events going on today... #bcbos, #glrb, #barcampnyc5, #jsconf ...5 weeks until graduation!",
  "id" : 12359436753,
  "created_at" : "2010-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12365696120",
  "text" : "\"Stop waiting for the next immature .NET pseudo-port of a Ruby project. Just use the Ruby version. You...\" http:\/\/tumblr.com\/x178r1zdh",
  "id" : 12365696120,
  "created_at" : "2010-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12257479233",
  "text" : "Made a complete fool of myself in public speaking, but the Sabres won! All is right with the world...right?",
  "id" : 12257479233,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12257964151",
  "geo" : { },
  "id_str" : "12257996365",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs been watching the new episodes and they're kind of meh so far...they don't add up to the ridiculousness of the trailer",
  "id" : 12257996365,
  "in_reply_to_status_id" : 12257964151,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12286344554",
  "text" : "This has gone too far. \"Innovation Management\" is not a degree. http:\/\/www.rit.edu\/emcs\/ptgrad\/grad\/1435.php3",
  "id" : 12286344554,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 54, 66 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12286506146",
  "text" : "Audio: Remix of the Inspector Gadget theme song. (via @SteveStreza) http:\/\/tumblr.com\/x178p3w66",
  "id" : 12286506146,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12287957560",
  "text" : "One thing I've learned: realtors do not respond to email.",
  "id" : 12287957560,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12288356735",
  "geo" : { },
  "id_str" : "12288561230",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith now accepting donations to actually \"buy\" something in boston, feel free to help!",
  "id" : 12288561230,
  "in_reply_to_status_id" : 12288356735,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    }, {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 11, 20 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12288135457",
  "geo" : { },
  "id_str" : "12288814204",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair @adambair yeah, but just looking for apartments. main issue is that we're 400 miles away",
  "id" : 12288814204,
  "in_reply_to_status_id" : 12288135457,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12273881301",
  "geo" : { },
  "id_str" : "12289419166",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase agreed. i need to finish up the redis downloads move and then we can start getting some cool graphs going.",
  "id" : 12289419166,
  "in_reply_to_status_id" : 12273881301,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12292467086",
  "geo" : { },
  "id_str" : "12293491383",
  "in_reply_to_user_id" : 734903,
  "text" : "@mjijackson how so? Seems fine here!",
  "id" : 12293491383,
  "in_reply_to_status_id" : 12292467086,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mjackson",
  "in_reply_to_user_id_str" : "734903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grooveshark",
      "screen_name" : "Grooveshark",
      "indices" : [ 52, 64 ],
      "id_str" : "3806441",
      "id" : 3806441
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 92, 104 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12296163701",
  "text" : "listening to Red Barchetta by The String Quartet on @Grooveshark: http:\/\/tinysong.com\/sDZb (@fredyatesiv was right, slick ui!)",
  "id" : 12296163701,
  "created_at" : "2010-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12230412675",
  "geo" : { },
  "id_str" : "12230706141",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith yep! let's go see a Royals game!",
  "id" : 12230706141,
  "in_reply_to_status_id" : 12230412675,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12230822342",
  "geo" : { },
  "id_str" : "12230896147",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith woot. starting to think a Royals night for the conference would be fun to organize :)",
  "id" : 12230896147,
  "in_reply_to_status_id" : 12230822342,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12231251586",
  "text" : "Speaker lineup for http:\/\/www.rubymidwest.com\/speakers.html is up! I'll be talking about Redis, of course!",
  "id" : 12231251586,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12233311188",
  "text" : "Completely batshit insane. http:\/\/www.youtube.com\/watch?v=9ezZgAl6aN8",
  "id" : 12233311188,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Mizerany",
      "screen_name" : "bmizerany",
      "indices" : [ 0, 10 ],
      "id_str" : "2379441",
      "id" : 2379441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12250533307",
  "geo" : { },
  "id_str" : "12251313097",
  "in_reply_to_user_id" : 2379441,
  "text" : "@bmizerany hey I finally got the lib\/ dir cleaned up! Not too tough :)",
  "id" : 12251313097,
  "in_reply_to_status_id" : 12250533307,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "bmizerany",
  "in_reply_to_user_id_str" : "2379441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12196705334",
  "text" : "Photo: The Aurora Australis, viewed by astronauts aboard the ISS, 356 km above the Indian Ocean on March... http:\/\/tumblr.com\/x178mv1a7",
  "id" : 12196705334,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12196860987",
  "geo" : { },
  "id_str" : "12197353190",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh time for NEW FRIENDS. Just kidding, git-svn is fine, but hope to $deity you don't have any merge problems!",
  "id" : 12197353190,
  "in_reply_to_status_id" : 12196860987,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12197400537",
  "geo" : { },
  "id_str" : "12197440592",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton HOLY SHIT GET ME TICKETS",
  "id" : 12197440592,
  "in_reply_to_status_id" : 12197400537,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12197494590",
  "text" : "HOW DID I MISS THIS http:\/\/is.gd\/btaOY",
  "id" : 12197494590,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 47, 53 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12199466414",
  "geo" : { },
  "id_str" : "12200809502",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel well yeah, I used to be DoctorNick but @drnic being all famous like put that idea down once I got into Ruby\/Rails",
  "id" : 12200809502,
  "in_reply_to_status_id" : 12199466414,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12200925094",
  "text" : "Tonight @ablissfulgal made a worry list. My first reaction: let's make that into a web app.",
  "id" : 12200925094,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 14, 22 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12223493674",
  "geo" : { },
  "id_str" : "12223645232",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin @drbrain whoa, whoa, i thought that was not allowed for built gems. obviously a gemspec can contain anything, it's just ruby",
  "id" : 12223645232,
  "in_reply_to_status_id" : 12223493674,
  "created_at" : "2010-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12132310119",
  "text" : "Video: tinydesigners: Who says reading is dead? http:\/\/tumblr.com\/x178l8mlp",
  "id" : 12132310119,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chirp",
      "screen_name" : "Chirp",
      "indices" : [ 36, 42 ],
      "id_str" : "93950835",
      "id" : 93950835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12170832913",
  "text" : "Seriously impressive live stream of @Chirp: http:\/\/chirp.twitter.com\/live.html",
  "id" : 12170832913,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12178812839",
  "text" : "Just refactored a ton of Go code using closures. Current status: http:\/\/is.gd\/bsKcc",
  "id" : 12178812839,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 11, 21 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12179550065",
  "text" : "Holy crap, @gemcutter hit 20 million downloads! http:\/\/rubygems.org\/stats",
  "id" : 12179550065,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12187376441",
  "text" : "Nothing like 2 CS majors, possibly graduate students, not using version control. What the fuck did you learn in 5 years?",
  "id" : 12187376441,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12187756892",
  "text" : "For those coming to their defense: There's really no excuse. They've had coop experience. They're just fucking lazy.",
  "id" : 12187756892,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12083401597",
  "text" : "Finished moving sale mega man poster: http:\/\/img.skitch.com\/20100413-jrgfpq6km8anfnf35sxmb9sdrf.png",
  "id" : 12083401597,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12085839450",
  "text" : "I really prefer Textile over Markdown. Any day, every day.",
  "id" : 12085839450,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12086221799",
  "text" : "What I hate the most is the link structure. \"blah\":http:\/\/ is so much easier than [blah](http:\/\/). I always forget the order of []()",
  "id" : 12086221799,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12086333012",
  "geo" : { },
  "id_str" : "12086368727",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub And centering\/creating an image is so much more difficult. Textile just speaks to me naturally. Ugh.",
  "id" : 12086368727,
  "in_reply_to_status_id" : 12086333012,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Richards",
      "screen_name" : "noahsmark",
      "indices" : [ 0, 10 ],
      "id_str" : "14198565",
      "id" : 14198565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12086602073",
  "geo" : { },
  "id_str" : "12086696413",
  "in_reply_to_user_id" : 14198565,
  "text" : "@noahsmark yeah, i guess everyone uses it differently. for all the vim\/git\/jekyll lovin' you have i'm still surprised you work at MS :)",
  "id" : 12086696413,
  "in_reply_to_status_id" : 12086602073,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "noahsmark",
  "in_reply_to_user_id_str" : "14198565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jqueryui",
      "screen_name" : "jqueryui",
      "indices" : [ 88, 97 ],
      "id_str" : "14538636",
      "id" : 14538636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12087095518",
  "text" : "A long awaited GitHub Rebase #41! http:\/\/github.com\/blog\/638-github-rebase-41 Featuring @jqueryui!",
  "id" : 12087095518,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12118104487",
  "geo" : { },
  "id_str" : "12118537306",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom it...should! is it not?",
  "id" : 12118537306,
  "in_reply_to_status_id" : 12118104487,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12122947439",
  "text" : "\"How did you test all of this code?\" \"I haven't yet.\"",
  "id" : 12122947439,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12129777289",
  "text" : "Literally had to jump through 20 hoops to get SQL server authentication working. Who the fuck uses this crap?",
  "id" : 12129777289,
  "created_at" : "2010-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12018311175",
  "text" : "Just realized we left a huge bag of toiletries in our hotel room back in Detroit. Fuck.",
  "id" : 12018311175,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12019823392",
  "geo" : { },
  "id_str" : "12020108569",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit oh snap! I finally called a realtor, really hard since we're so far away.",
  "id" : 12020108569,
  "in_reply_to_status_id" : 12019823392,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12022395914",
  "geo" : { },
  "id_str" : "12022936668",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg what project is this? i was about to remove mine",
  "id" : 12022936668,
  "in_reply_to_status_id" : 12022395914,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12052703495",
  "geo" : { },
  "id_str" : "12052891650",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey did they break out any new drag and drop controls? DESIGN PANEL SO EASY! NO CODING!",
  "id" : 12052891650,
  "in_reply_to_status_id" : 12052703495,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12057559987",
  "text" : "Gimp skills. I HAZ THEM. http:\/\/img.skitch.com\/20100412-xfrbty5tkqr171tfyudybcrpmc.png",
  "id" : 12057559987,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12060187171",
  "text" : "I really wish I would have STUDIED FOR MY TEST TODAY I DIDNT KNOW ABOUT instead of creating sweet mega man graphics all morning.",
  "id" : 12060187171,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazytweet",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12064559241",
  "text" : "Any suggestions for cheap color prints near RIT? Would love to hang some of my mega man posters tonight. #lazytweet",
  "id" : 12064559241,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12066348953",
  "geo" : { },
  "id_str" : "12067573550",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett dude just make sure you call Object#freeze on that baby name at some point.",
  "id" : 12067573550,
  "in_reply_to_status_id" : 12066348953,
  "created_at" : "2010-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11970222827",
  "text" : "I'm at box bar & grill (777 W Ann Arbor Trl, btw Main & Deer, Plymouth). http:\/\/4sq.com\/839aDi",
  "id" : 11970222827,
  "created_at" : "2010-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Willis Webber",
      "screen_name" : "Mephux",
      "indices" : [ 0, 7 ],
      "id_str" : "7810112",
      "id" : 7810112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11946144546",
  "geo" : { },
  "id_str" : "11970681052",
  "in_reply_to_user_id" : 7810112,
  "text" : "@Mephux that's up next. This bar has a great selection.",
  "id" : 11970681052,
  "in_reply_to_status_id" : 11946144546,
  "created_at" : "2010-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mephux",
  "in_reply_to_user_id_str" : "7810112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11909543255",
  "text" : "OH: \"Besides the fact that you can't leave, jail is pretty cool\"",
  "id" : 11909543255,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 45, 55 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11915957791",
  "text" : "Kind of wish I had the motivation to hack on @gemcutter. Week 6\/10 of spring quarter, the final weeks are approaching!",
  "id" : 11915957791,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11916779051",
  "text" : "I hate EULAs so much. \"MICROSOFT SOFTWARE LICENSE TERMS\nMICROSOFT ASP.NET MODEL VIEW CONTROLLER 2\"...oh shut up",
  "id" : 11916779051,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11941584801",
  "text" : "Trying to find something to do in Detroit\/Ann Arbor before the hockey championship. Preferably free\/cheap. And not outside, it's freezing.",
  "id" : 11941584801,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11948406705",
  "text" : "I'm at Detroit Science Center (5020 John R. Road, Woodward Ave., Detroit). http:\/\/4sq.com\/8hwqmw",
  "id" : 11948406705,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael evans",
      "screen_name" : "magic6435",
      "indices" : [ 0, 10 ],
      "id_str" : "6154832",
      "id" : 6154832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11948667031",
  "geo" : { },
  "id_str" : "11953579159",
  "in_reply_to_user_id" : 6154832,
  "text" : "@magic6435 in town for the NCAA championship! Couldn't miss my only chance to be an RIT sports fan at a big game.",
  "id" : 11953579159,
  "in_reply_to_status_id" : 11948667031,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "magic6435",
  "in_reply_to_user_id_str" : "6154832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11959010738",
  "text" : "I'm at Ford Field (2000 Brush St, Detroit) w\/ 8 others. http:\/\/4sq.com\/5TDFy4",
  "id" : 11959010738,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11960735122",
  "text" : "Corner crew is booing both teams.",
  "id" : 11960735122,
  "created_at" : "2010-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11853517413",
  "text" : "Awesome: Miami fans told by cops to sit down, the Corner Crew stands up and cheers them on. Miami fans counter by cheering for RIT!",
  "id" : 11853517413,
  "created_at" : "2010-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11862327069",
  "text" : "Free wifi at hotel FTW.",
  "id" : 11862327069,
  "created_at" : "2010-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uRaNGaTaNG",
      "screen_name" : "rngtng",
      "indices" : [ 0, 7 ],
      "id_str" : "89221709",
      "id" : 89221709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11828843010",
  "geo" : { },
  "id_str" : "11863878245",
  "in_reply_to_user_id" : 89221709,
  "text" : "@rngtng Open up a request at http:\/\/help.rubygems.org and we'll get it sorted out.",
  "id" : 11863878245,
  "in_reply_to_status_id" : 11828843010,
  "created_at" : "2010-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "rngtng",
  "in_reply_to_user_id_str" : "89221709",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11894415611",
  "geo" : { },
  "id_str" : "11895746702",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez why does it matter? ActiveRecord abstracts all of that away for me. Outside of AR I guess so.",
  "id" : 11895746702,
  "in_reply_to_status_id" : 11894415611,
  "created_at" : "2010-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11819252221",
  "text" : "On our way to Detroit!",
  "id" : 11819252221,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 62, 72 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11828881134",
  "text" : "Spent the first half of the ride trying to benchmark sticking @gemcutter indexes into Redis (vs currently in Postgres). Oh, hai Cleveland!",
  "id" : 11828881134,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11834561937",
  "text" : "It's been a while, Michigan!",
  "id" : 11834561937,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11836596728",
  "text" : "Detroit: just as frightening as I remember.",
  "id" : 11836596728,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11839620348",
  "text" : "Current status: http:\/\/twitpic.com\/1e43b8",
  "id" : 11839620348,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11850694001",
  "text" : "Thanks for a great season, RIT Tigers!",
  "id" : 11850694001,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11794042869",
  "text" : "http:\/\/twitpic.com\/1dxr2c huge bonfire outside crossroads!",
  "id" : 11794042869,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11797427596",
  "text" : "Nothing like a good thunderstorm.",
  "id" : 11797427596,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 6, 16 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11800248785",
  "geo" : { },
  "id_str" : "11800479864",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo @joedamato I'll be honest that kind of shit scares me. I like Ruby for how it hides all of that from me and just lets me get shit done",
  "id" : 11800479864,
  "in_reply_to_status_id" : 11800248785,
  "created_at" : "2010-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11734614683",
  "text" : "Been coding for 12 hours straight pretty much.",
  "id" : 11734614683,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11736463013",
  "text" : "I really don't enjoy Go's type system or type embedding. It's a sad excuse for  actual inheritance or mixins.",
  "id" : 11736463013,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eust\u00E1quio Rangel",
      "screen_name" : "taq",
      "indices" : [ 0, 4 ],
      "id_str" : "8524192",
      "id" : 8524192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11728942577",
  "geo" : { },
  "id_str" : "11739672999",
  "in_reply_to_user_id" : 8524192,
  "text" : "@taq I'm still waiting for someone to build a tarball service using gem webhooks. http:\/\/rubygems.org\/pages\/api_docs#webhook",
  "id" : 11739672999,
  "in_reply_to_status_id" : 11728942577,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "taq",
  "in_reply_to_user_id_str" : "8524192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Mathieu",
      "screen_name" : "dmathieu",
      "indices" : [ 0, 9 ],
      "id_str" : "7134522",
      "id" : 7134522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11743366150",
  "geo" : { },
  "id_str" : "11755538791",
  "in_reply_to_user_id" : 7134522,
  "text" : "@dmathieu I haven't had time to work on it in a while, health of the service in general has been more important. and graduating.",
  "id" : 11755538791,
  "in_reply_to_status_id" : 11743366150,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmathieu",
  "in_reply_to_user_id_str" : "7134522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Mathieu",
      "screen_name" : "dmathieu",
      "indices" : [ 0, 9 ],
      "id_str" : "7134522",
      "id" : 7134522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11755843342",
  "geo" : { },
  "id_str" : "11756597484",
  "in_reply_to_user_id" : 7134522,
  "text" : "@dmathieu definitely am looking for someone to pick it up especially if they want to see it sooner :) otherwise I can't see it before may",
  "id" : 11756597484,
  "in_reply_to_status_id" : 11755843342,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmathieu",
  "in_reply_to_user_id_str" : "7134522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Mathieu",
      "screen_name" : "dmathieu",
      "indices" : [ 0, 9 ],
      "id_str" : "7134522",
      "id" : 7134522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11756770033",
  "geo" : { },
  "id_str" : "11757155876",
  "in_reply_to_user_id" : 7134522,
  "text" : "@dmathieu I don't think private subdomains are a good idea for gemcutter. have you tried cwninja\/geminabox?",
  "id" : 11757155876,
  "in_reply_to_status_id" : 11756770033,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmathieu",
  "in_reply_to_user_id_str" : "7134522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11766577027",
  "text" : "\"eats spice and trips balls\" http:\/\/i.imgur.com\/FTczx.jpg",
  "id" : 11766577027,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11766705715",
  "text" : "\"ASP.NET is simply not a quality-producing technology\" http:\/\/www.codingthewheel.com\/archives\/asp-net-web-development-horror",
  "id" : 11766705715,
  "created_at" : "2010-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 3, 10 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rithockey",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11708569674",
  "text" : "RT @elvo86: Ford Field is ready to welcome RIT. http:\/\/twitpic.com\/1dnqs7 #rithockey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rithockey",
        "indices" : [ 62, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11708507489",
    "text" : "Ford Field is ready to welcome RIT. http:\/\/twitpic.com\/1dnqs7 #rithockey",
    "id" : 11708507489,
    "created_at" : "2010-04-06 17:12:07 +0000",
    "user" : {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "protected" : false,
      "id_str" : "14183391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614236218\/af7d126fcb057a5052d21e42d0c0faee_normal.jpeg",
      "id" : 14183391,
      "verified" : false
    }
  },
  "id" : 11708569674,
  "created_at" : "2010-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11715190917",
  "text" : "Loving the animation backgrounds from http:\/\/adventuretime.tumblr.com\/ as desktop backgrounds. More shows need to do this.",
  "id" : 11715190917,
  "created_at" : "2010-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 9, 21 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11621273677",
  "geo" : { },
  "id_str" : "11621919717",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @tristandunn can i has canvas wars? http:\/\/image.com.com\/gamespot\/images\/2001\/ects\/advancewars\/advancewars_790screen004.jpg",
  "id" : 11621919717,
  "in_reply_to_status_id" : 11621273677,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11624501390",
  "text" : "\"Programming\" XAML makes me glad I don't do .NET full time anymore. The \"bleak future\" seems to be the present. http:\/\/is.gd\/beX4v",
  "id" : 11624501390,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11642043078",
  "text" : "I love days when I set 3 alarms and somehow manage to turn them all off unconsciously.",
  "id" : 11642043078,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11647069877",
  "text" : "Yes, it blends! http:\/\/www.youtube.com\/watch?v=lAl28d6tbko",
  "id" : 11647069877,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Richard Ford",
      "screen_name" : "ceosion",
      "indices" : [ 0, 8 ],
      "id_str" : "19460716",
      "id" : 19460716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11655099006",
  "geo" : { },
  "id_str" : "11655144733",
  "in_reply_to_user_id" : 19460716,
  "text" : "@ceosion nope but I should drag you out to some of the Boston.rb meetups. I have some suggestions for realtors if you need them.",
  "id" : 11655144733,
  "in_reply_to_status_id" : 11655099006,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ceosion",
  "in_reply_to_user_id_str" : "19460716",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11660283823",
  "text" : "Engadget breaks out the Litany Against Fear: http:\/\/is.gd\/bg1sS",
  "id" : 11660283823,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11662412523",
  "text" : "OH: \"He's stupid bro. I mean, like, whatever.\"",
  "id" : 11662412523,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11664234860",
  "text" : "man telnet | tail -4 | head -2",
  "id" : 11664234860,
  "created_at" : "2010-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidbrenner",
      "screen_name" : "davidbrenner",
      "indices" : [ 58, 71 ],
      "id_str" : "14312099",
      "id" : 14312099
    }, {
      "name" : "Sela Davis",
      "screen_name" : "sela_davis",
      "indices" : [ 72, 83 ],
      "id_str" : "7488582",
      "id" : 7488582
    }, {
      "name" : "Michael Dumont",
      "screen_name" : "mdumont",
      "indices" : [ 84, 92 ],
      "id_str" : "16463562",
      "id" : 16463562
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 93, 100 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarCampRoc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11561050333",
  "text" : "#BarCampRoc was great. Thanks for putting on a great day, @davidbrenner @sela_davis @mdumont @hiteak and plenty of others I'm missing!",
  "id" : 11561050333,
  "created_at" : "2010-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Rae",
      "screen_name" : "stickylipgloss",
      "indices" : [ 14, 29 ],
      "id_str" : "36714090",
      "id" : 36714090
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 60, 71 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11563831911",
  "text" : "I just ousted @stickylipgloss as the mayor of TC Riley's on @foursquare! http:\/\/4sq.com\/6QibLZ",
  "id" : 11563831911,
  "created_at" : "2010-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11563832340",
  "text" : "I'm at TC Riley's (200 Park Point Dr, Rochester). http:\/\/4sq.com\/6QibLZ",
  "id" : 11563832340,
  "created_at" : "2010-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 0, 8 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11563912475",
  "geo" : { },
  "id_str" : "11564208783",
  "in_reply_to_user_id" : 22682102,
  "text" : "@dmansen we tend to come here way too often. The food is actually pretty decent.",
  "id" : 11564208783,
  "in_reply_to_status_id" : 11563912475,
  "created_at" : "2010-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "dmansen",
  "in_reply_to_user_id_str" : "22682102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11597002570",
  "geo" : { },
  "id_str" : "11600031609",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek my timbuk2 bag is one of few possessions that has survived 5 years of college and is still in great shape. +1",
  "id" : 11600031609,
  "in_reply_to_status_id" : 11597002570,
  "created_at" : "2010-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11535248579",
  "text" : "BarCampRoc time! Woot.",
  "id" : 11535248579,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11537228916",
  "text" : "BarCamp Tip #1: Make your code font size HUGE and not white on black.",
  "id" : 11537228916,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 33, 43 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11538977100",
  "text" : "Looking into the DNS issues with @gemcutter, thanks for the heads up folks.",
  "id" : 11538977100,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 21, 27 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11539646026",
  "text" : "Extremely jealous of @chorn's iPad. I kind of want one.",
  "id" : 11539646026,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 58, 66 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11539933187",
  "text" : "Getting schooled on the DOM and how it can be improved by @jeresig!",
  "id" : 11539933187,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "\u2131[\u03B4(x)]",
      "screen_name" : "judofyr",
      "indices" : [ 89, 97 ],
      "id_str" : "13009542",
      "id" : 13009542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11540038083",
  "text" : "RT @gemcutter: Temporary fix: add \"72.4.120.124 rubygems.org\" to your \/etc\/hosts. Thanks @judofyr.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2131[\u03B4(x)]",
        "screen_name" : "judofyr",
        "indices" : [ 74, 82 ],
        "id_str" : "13009542",
        "id" : 13009542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11540024249",
    "text" : "Temporary fix: add \"72.4.120.124 rubygems.org\" to your \/etc\/hosts. Thanks @judofyr.",
    "id" : 11540024249,
    "created_at" : "2010-04-03 15:42:55 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 11540038083,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 8, 18 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 56, 64 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11540416581",
  "text" : "DNS for @gemcutter should be coming back online, thanks @drbrain! If you couldn't get to it please try again and let us know.",
  "id" : 11540416581,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 68, 76 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11551079143",
  "text" : "Thanks for putting up with my Redis talk, folks. Looking forward to @dmansen explaining WTF a monad is.",
  "id" : 11551079143,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 35, 41 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11555359098",
  "text" : "Learning how to end the world with @chorn. More #barcamproc talks need to be like this.",
  "id" : 11555359098,
  "created_at" : "2010-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11450971471",
  "geo" : { },
  "id_str" : "11455037921",
  "in_reply_to_user_id" : 734903,
  "text" : "@mjijackson thanks! plenty of cool features still to come :)",
  "id" : 11455037921,
  "in_reply_to_status_id" : 11450971471,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mjackson",
  "in_reply_to_user_id_str" : "734903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 35, 46 ],
      "id_str" : "20751318",
      "id" : 20751318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11457679711",
  "text" : "Trying out @schacon\/showoff for my @BarCampRoc talk, very impressed. It's the next evolution of @nakajima\/slidedown.",
  "id" : 11457679711,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara T. Howard",
      "screen_name" : "drawohara",
      "indices" : [ 0, 10 ],
      "id_str" : "17058191",
      "id" : 17058191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11459654621",
  "geo" : { },
  "id_str" : "11460094854",
  "in_reply_to_user_id" : 17058191,
  "text" : "@drawohara syncing from rubyforge should work. let us know the problems you're having please: http:\/\/help.rubygems.org",
  "id" : 11460094854,
  "in_reply_to_status_id" : 11459654621,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "drawohara",
  "in_reply_to_user_id_str" : "17058191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11461773475",
  "text" : "If all commercials were like this, I'd watch TV all day. http:\/\/is.gd\/baG6I",
  "id" : 11461773475,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11462740836",
  "text" : "@IselaMariaPhoto exactly. I hope TV evolves TV from Idiocracy someday. It's halfway there.",
  "id" : 11462740836,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara T. Howard",
      "screen_name" : "drawohara",
      "indices" : [ 0, 10 ],
      "id_str" : "17058191",
      "id" : 17058191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11462168169",
  "geo" : { },
  "id_str" : "11462773832",
  "in_reply_to_user_id" : 17058191,
  "text" : "@drawohara thanks, we did move fast on it, but I tried to be open as possible. Definitely open to suggestions for improvement.",
  "id" : 11462773832,
  "in_reply_to_status_id" : 11462168169,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "drawohara",
  "in_reply_to_user_id_str" : "17058191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11466259200",
  "text" : "Definitely my favorite slide of this presentation: http:\/\/img.skitch.com\/20100402-1mbdfd65w5smmjft7x7c39er1.png",
  "id" : 11466259200,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11481029014",
  "geo" : { },
  "id_str" : "11481987385",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey i'm seeing a similar pattern, from 2008 I was going through same stuff with windows http:\/\/is.gd\/bbgTT then http:\/\/is.gd\/bbhGv",
  "id" : 11481987385,
  "in_reply_to_status_id" : 11481029014,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 3, 17 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11486516577",
  "text" : "RT @jkreeftmeijer: .gitignore your *.gemspec http:\/\/jeffkreeftmeijer.com\/2010\/gitignore-your-gemspec\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11485724362",
    "text" : ".gitignore your *.gemspec http:\/\/jeffkreeftmeijer.com\/2010\/gitignore-your-gemspec\/",
    "id" : 11485724362,
    "created_at" : "2010-04-02 15:27:36 +0000",
    "user" : {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "protected" : false,
      "id_str" : "8284992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548110778113753088\/FzD5r_Am_normal.jpeg",
      "id" : 8284992,
      "verified" : false
    }
  },
  "id" : 11486516577,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11487541301",
  "geo" : { },
  "id_str" : "11487709675",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates oh that's silly if so. not sure why you would do such a thing.",
  "id" : 11487709675,
  "in_reply_to_status_id" : 11487541301,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 8, 15 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11488277729",
  "geo" : { },
  "id_str" : "11488897546",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates @mislav I guess it's just a matter of preference, i'd rather use a simple rake task or Jeweler to generate it.",
  "id" : 11488897546,
  "in_reply_to_status_id" : 11488277729,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11488957174",
  "text" : "Holy crap, RIT is going to feel like a real school with sports for a week. http:\/\/www.rit.edu\/news\/?v=47464",
  "id" : 11488957174,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11489343368",
  "geo" : { },
  "id_str" : "11489498993",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates yeah, but i appreciate the added benefits and helpers that jeweler brings. jeweler and gemcutter kind of grew up together :)",
  "id" : 11489498993,
  "in_reply_to_status_id" : 11489343368,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11490942863",
  "text" : "So many jobs and internships in Boston, cmon RIT folks! http:\/\/wiki.barcampboston.org\/index.php?title=Sponsor_Job_Opportunities",
  "id" : 11490942863,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11491288660",
  "geo" : { },
  "id_str" : "11491553729",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates I still don't understand why you need a gemspec to use a git package with Bundler. Why wouldn't you just use a gem?",
  "id" : 11491553729,
  "in_reply_to_status_id" : 11491288660,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Moreland",
      "screen_name" : "Derander",
      "indices" : [ 0, 9 ],
      "id_str" : "17055071",
      "id" : 17055071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11446932411",
  "geo" : { },
  "id_str" : "11452784564",
  "in_reply_to_user_id" : 17055071,
  "text" : "@Derander was the best choice 5 years ago and still is. Feel free to have your friend email me.",
  "id" : 11452784564,
  "in_reply_to_status_id" : 11446932411,
  "created_at" : "2010-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Derander",
  "in_reply_to_user_id_str" : "17055071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
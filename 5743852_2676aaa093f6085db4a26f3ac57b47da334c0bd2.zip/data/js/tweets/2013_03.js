Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/FKvikyJkU3",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qmb9FisSd-c",
      "display_url" : "youtube.com\/watch?v=qmb9Fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318557709819580417",
  "text" : "Current status: http:\/\/t.co\/FKvikyJkU3",
  "id" : 318557709819580417,
  "created_at" : "2013-04-01 02:57:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318545434597552128",
  "text" : "@stevenhaddox what the fuck? just stalkers?",
  "id" : 318545434597552128,
  "created_at" : "2013-04-01 02:08:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318541929015042048",
  "text" : "@stevenhaddox wtf? \u201CPopular forums\u201D ??",
  "id" : 318541929015042048,
  "created_at" : "2013-04-01 01:54:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318509625622274048",
  "geo" : { },
  "id_str" : "318509822448398336",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox yeah there\u2019s been some bad hockey ones with blood\u2026but damn.",
  "id" : 318509822448398336,
  "in_reply_to_status_id" : 318509625622274048,
  "created_at" : "2013-03-31 23:47:13 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318478236948516864",
  "text" : "Watched March Madness for 5 minutes and see literally the most brutal injury I\u2019ve seen in basketball. Nope. Nope nope.",
  "id" : 318478236948516864,
  "created_at" : "2013-03-31 21:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/jHWdtTBxRe",
      "expanded_url" : "https:\/\/irccloud.com\/",
      "display_url" : "irccloud.com"
    } ]
  },
  "geo" : { },
  "id_str" : "318417148986937346",
  "text" : "Bummer that https:\/\/t.co\/jHWdtTBxRe is getting DDoS'd :(",
  "id" : 318417148986937346,
  "created_at" : "2013-03-31 17:38:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 0, 5 ],
      "id_str" : "819606",
      "id" : 819606
    }, {
      "name" : "Luis Abreu",
      "screen_name" : "lmjabreu",
      "indices" : [ 6, 15 ],
      "id_str" : "7857522",
      "id" : 7857522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318307693964193793",
  "geo" : { },
  "id_str" : "318349871662907392",
  "in_reply_to_user_id" : 819606,
  "text" : "@janl @lmjabreu yep, UIWebView exposes it\u2019s UIScrollView, so you can add it just like any other.",
  "id" : 318349871662907392,
  "in_reply_to_status_id" : 318307693964193793,
  "created_at" : "2013-03-31 13:11:38 +0000",
  "in_reply_to_screen_name" : "janl",
  "in_reply_to_user_id_str" : "819606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 3, 16 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "The Beauty Shoppe",
      "screen_name" : "BeautyShoppePgh",
      "indices" : [ 25, 41 ],
      "id_str" : "376332532",
      "id" : 376332532
    }, {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 60, 72 ],
      "id_str" : "906546798",
      "id" : 906546798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/hoDHOmm4px",
      "expanded_url" : "http:\/\/thebeautyshoppe.org\/journal\/happenings-openhack",
      "display_url" : "thebeautyshoppe.org\/journal\/happen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318349390865657859",
  "text" : "RT @justinxreese: Thanks @BeautyShoppePgh for writing about @OpenHackPGH - http:\/\/t.co\/hoDHOmm4px",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Beauty Shoppe",
        "screen_name" : "BeautyShoppePgh",
        "indices" : [ 7, 23 ],
        "id_str" : "376332532",
        "id" : 376332532
      }, {
        "name" : "OpenHack Pittsburgh",
        "screen_name" : "OpenHackPGH",
        "indices" : [ 42, 54 ],
        "id_str" : "906546798",
        "id" : 906546798
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/hoDHOmm4px",
        "expanded_url" : "http:\/\/thebeautyshoppe.org\/journal\/happenings-openhack",
        "display_url" : "thebeautyshoppe.org\/journal\/happen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "317674805115629568",
    "text" : "Thanks @BeautyShoppePgh for writing about @OpenHackPGH - http:\/\/t.co\/hoDHOmm4px",
    "id" : 317674805115629568,
    "created_at" : "2013-03-29 16:29:10 +0000",
    "user" : {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "protected" : false,
      "id_str" : "14255877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000717365875\/a5fc587859d80f9415092095a619b378_normal.jpeg",
      "id" : 14255877,
      "verified" : false
    }
  },
  "id" : 318349390865657859,
  "created_at" : "2013-03-31 13:09:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 19, 31 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318200287728914432",
  "text" : "Adventure Time and @whereslloyd. Shmowzow!",
  "id" : 318200287728914432,
  "created_at" : "2013-03-31 03:17:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecy Correa",
      "screen_name" : "cecycorrea",
      "indices" : [ 0, 11 ],
      "id_str" : "18825668",
      "id" : 18825668
    }, {
      "name" : "Jerry Chen",
      "screen_name" : "jcsalterego",
      "indices" : [ 12, 24 ],
      "id_str" : "14343561",
      "id" : 14343561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318094326452338688",
  "geo" : { },
  "id_str" : "318161022248697856",
  "in_reply_to_user_id" : 18825668,
  "text" : "@cecycorrea @jcsalterego Algebraic!!",
  "id" : 318161022248697856,
  "in_reply_to_status_id" : 318094326452338688,
  "created_at" : "2013-03-31 00:41:13 +0000",
  "in_reply_to_screen_name" : "cecycorrea",
  "in_reply_to_user_id_str" : "18825668",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/piGFEjG9gI",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/5256546",
      "display_url" : "gist.github.com\/qrush\/5256546"
    } ]
  },
  "in_reply_to_status_id_str" : "318114494540824577",
  "geo" : { },
  "id_str" : "318122146771656704",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan https:\/\/t.co\/piGFEjG9gI",
  "id" : 318122146771656704,
  "in_reply_to_status_id" : 318114494540824577,
  "created_at" : "2013-03-30 22:06:44 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318121933113810945",
  "geo" : { },
  "id_str" : "318121996527489025",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt whomp",
  "id" : 318121996527489025,
  "in_reply_to_status_id" : 318121933113810945,
  "created_at" : "2013-03-30 22:06:09 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318121441029677056",
  "geo" : { },
  "id_str" : "318121862775316481",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt does that LOC count include comments? It\u2019s pretty well documented. Not an excuse just offering an idea :)",
  "id" : 318121862775316481,
  "in_reply_to_status_id" : 318121441029677056,
  "created_at" : "2013-03-30 22:05:37 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318116115765157889",
  "geo" : { },
  "id_str" : "318121209885782017",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt even with docs?",
  "id" : 318121209885782017,
  "in_reply_to_status_id" : 318116115765157889,
  "created_at" : "2013-03-30 22:03:01 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318088935563739136",
  "geo" : { },
  "id_str" : "318089271800107008",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck it's best with 2-4, but can play up to 6 with expansions",
  "id" : 318089271800107008,
  "in_reply_to_status_id" : 318088935563739136,
  "created_at" : "2013-03-30 19:56:06 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318082783182471168",
  "geo" : { },
  "id_str" : "318088893822021634",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded Looks nice, but wtf platform choices :\/",
  "id" : 318088893822021634,
  "in_reply_to_status_id" : 318082783182471168,
  "created_at" : "2013-03-30 19:54:36 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318001540965232640",
  "geo" : { },
  "id_str" : "318088699634139136",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck Yes!",
  "id" : 318088699634139136,
  "in_reply_to_status_id" : 318001540965232640,
  "created_at" : "2013-03-30 19:53:50 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317662096571654144",
  "geo" : { },
  "id_str" : "317785652542468097",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie well that\u2019s not cool. I\u2019ll ban this account when I get a chance :(",
  "id" : 317785652542468097,
  "in_reply_to_status_id" : 317662096571654144,
  "created_at" : "2013-03-29 23:49:38 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317691755984199681",
  "geo" : { },
  "id_str" : "317785406177439744",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems yes! Soon\u2026we have a lot to do.",
  "id" : 317785406177439744,
  "in_reply_to_status_id" : 317691755984199681,
  "created_at" : "2013-03-29 23:48:39 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 0, 9 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317618301914185730",
  "geo" : { },
  "id_str" : "317618827598888960",
  "in_reply_to_user_id" : 876930312,
  "text" : "@BfloFRED I'd still be up for that.",
  "id" : 317618827598888960,
  "in_reply_to_status_id" : 317618301914185730,
  "created_at" : "2013-03-29 12:46:44 +0000",
  "in_reply_to_screen_name" : "BfloFRED",
  "in_reply_to_user_id_str" : "876930312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317617767320784898",
  "text" : "Just picked up mini Carcassonne expansions The Messages and Mage &amp; Witch. Both sound awesome.",
  "id" : 317617767320784898,
  "created_at" : "2013-03-29 12:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Disqus",
      "screen_name" : "disqus",
      "indices" : [ 10, 17 ],
      "id_str" : "14130628",
      "id" : 14130628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317602698344136704",
  "geo" : { },
  "id_str" : "317615316035313665",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @disqus ugh. i should just take the comments off.",
  "id" : 317615316035313665,
  "in_reply_to_status_id" : 317602698344136704,
  "created_at" : "2013-03-29 12:32:47 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin T.A. Gray",
      "screen_name" : "colinta",
      "indices" : [ 24, 32 ],
      "id_str" : "270963272",
      "id" : 270963272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317594128059875329",
  "text" : "Blown away by Kiln from @colinta at #inspect. He built Firebug or Web Inspector for iOS. Shit just got real.",
  "id" : 317594128059875329,
  "created_at" : "2013-03-29 11:08:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 48, 57 ],
      "id_str" : "876930312",
      "id" : 876930312
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 77, 87 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317454526674268161",
  "geo" : { },
  "id_str" : "317539364580241408",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Sounds good! I'm sure we'd get some @BFLOFred spillover too. \/cc @aspleenic",
  "id" : 317539364580241408,
  "in_reply_to_status_id" : 317454526674268161,
  "created_at" : "2013-03-29 07:30:58 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lu\u00EDs Ferreira",
      "screen_name" : "zamith",
      "indices" : [ 0, 7 ],
      "id_str" : "24297915",
      "id" : 24297915
    }, {
      "name" : "Stephen Ball  ",
      "screen_name" : "StephenBallNC",
      "indices" : [ 8, 22 ],
      "id_str" : "12402702",
      "id" : 12402702
    }, {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 23, 31 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317434114594705409",
  "geo" : { },
  "id_str" : "317434468916944896",
  "in_reply_to_user_id" : 24297915,
  "text" : "@Zamith @StephenBallNC @bphogan please reply on the list! I won\u2019t get started on this for a few days.",
  "id" : 317434468916944896,
  "in_reply_to_status_id" : 317434114594705409,
  "created_at" : "2013-03-29 00:34:09 +0000",
  "in_reply_to_screen_name" : "zamith",
  "in_reply_to_user_id_str" : "24297915",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "10x charm gender",
      "screen_name" : "aurynn",
      "indices" : [ 0, 7 ],
      "id_str" : "10015412",
      "id" : 10015412
    }, {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 8, 21 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317427505843822593",
  "geo" : { },
  "id_str" : "317427884606251008",
  "in_reply_to_user_id" : 10015412,
  "text" : "@aurynn @derickbailey rubygems has very, very minimal dependency resolution, it just sucks compared to bundler's :) World of difference.",
  "id" : 317427884606251008,
  "in_reply_to_status_id" : 317427505843822593,
  "created_at" : "2013-03-29 00:07:59 +0000",
  "in_reply_to_screen_name" : "aurynn",
  "in_reply_to_user_id_str" : "10015412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317426821853491202",
  "geo" : { },
  "id_str" : "317427410163339264",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle woot. i probably wont be able to start until the weekend or next due to traveling &amp; wifi. please respond to the thread though!",
  "id" : 317427410163339264,
  "in_reply_to_status_id" : 317426821853491202,
  "created_at" : "2013-03-29 00:06:06 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/8NdNMExNMF",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubygems-org\/browse_thread\/thread\/a81e0ee264db06d3?hl=en_US",
      "display_url" : "groups.google.com\/group\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317425657929936896",
  "text" : "I need some help with help: https:\/\/t.co\/8NdNMExNMF",
  "id" : 317425657929936896,
  "created_at" : "2013-03-28 23:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 74, 89 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317417670054117376",
  "geo" : { },
  "id_str" : "317418032815300608",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @ashedryden let\u2019s ask someone who this actually affects: hey @AustinSeraphin, have you used python?",
  "id" : 317418032815300608,
  "in_reply_to_status_id" : 317417670054117376,
  "created_at" : "2013-03-28 23:28:51 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stardock",
      "screen_name" : "Stardock",
      "indices" : [ 19, 28 ],
      "id_str" : "14462781",
      "id" : 14462781
    }, {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 35, 44 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8IKgl7qZUu",
      "expanded_url" : "http:\/\/www.facebook.com\/draginol\/posts\/10151501877948984",
      "display_url" : "facebook.com\/draginol\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317417762202984449",
  "text" : "Still impressed by @stardock &amp; @draginol \u2018s their forward thinking, especially on hiring &amp; diversity: http:\/\/t.co\/8IKgl7qZUu",
  "id" : 317417762202984449,
  "created_at" : "2013-03-28 23:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317416499457433601",
  "text" : "RT @ashedryden: Learned that Python is inaccessible to blind programmers due to indentation requirements. Need to think about this when  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316983219390148608",
    "text" : "Learned that Python is inaccessible to blind programmers due to indentation requirements. Need to think about this when we design languages.",
    "id" : 316983219390148608,
    "created_at" : "2013-03-27 18:41:03 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 317416499457433601,
  "created_at" : "2013-03-28 23:22:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 11, 22 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 97, 105 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317415524856377345",
  "geo" : { },
  "id_str" : "317415973038743553",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @benjaminws I have a guest bed and no less than 3 tacos for anyone who comes to speak @wnyruby !",
  "id" : 317415973038743553,
  "in_reply_to_status_id" : 317415524856377345,
  "created_at" : "2013-03-28 23:20:39 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect2013",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317415381859979264",
  "text" : "Lots of diverse accents at #inspect2013, and loving it. Someday we\u2019ll have a real Babelfish.",
  "id" : 317415381859979264,
  "created_at" : "2013-03-28 23:18:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 51, 63 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317413257612754949",
  "geo" : { },
  "id_str" : "317415101122637824",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws you need to visit Buffalo and get some @whereslloyd.",
  "id" : 317415101122637824,
  "in_reply_to_status_id" : 317413257612754949,
  "created_at" : "2013-03-28 23:17:12 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Holland",
      "screen_name" : "hollandjsauce",
      "indices" : [ 0, 14 ],
      "id_str" : "342958857",
      "id" : 342958857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317407209736785920",
  "geo" : { },
  "id_str" : "317414962115010560",
  "in_reply_to_user_id" : 342958857,
  "text" : "@hollandjsauce sure, sounds good!",
  "id" : 317414962115010560,
  "in_reply_to_status_id" : 317407209736785920,
  "created_at" : "2013-03-28 23:16:38 +0000",
  "in_reply_to_screen_name" : "hollandjsauce",
  "in_reply_to_user_id_str" : "342958857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mateus",
      "screen_name" : "seanlilmateus",
      "indices" : [ 0, 14 ],
      "id_str" : "16103797",
      "id" : 16103797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317383200731193344",
  "geo" : { },
  "id_str" : "317414884008660993",
  "in_reply_to_user_id" : 16103797,
  "text" : "@seanlilmateus np! Say hi tomorrow :)",
  "id" : 317414884008660993,
  "in_reply_to_status_id" : 317383200731193344,
  "created_at" : "2013-03-28 23:16:20 +0000",
  "in_reply_to_screen_name" : "seanlilmateus",
  "in_reply_to_user_id_str" : "16103797",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jordangrant",
      "screen_name" : "jordangrant",
      "indices" : [ 0, 12 ],
      "id_str" : "8567442",
      "id" : 8567442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317320842533011456",
  "geo" : { },
  "id_str" : "317414768346533891",
  "in_reply_to_user_id" : 8567442,
  "text" : "@jordangrant not yet! Sorry.",
  "id" : 317414768346533891,
  "in_reply_to_status_id" : 317320842533011456,
  "created_at" : "2013-03-28 23:15:52 +0000",
  "in_reply_to_screen_name" : "jordangrant",
  "in_reply_to_user_id_str" : "8567442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317377566992392192",
  "geo" : { },
  "id_str" : "317379965555466240",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy got a gmaps link? Can't find this easily...",
  "id" : 317379965555466240,
  "in_reply_to_status_id" : 317377566992392192,
  "created_at" : "2013-03-28 20:57:35 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Joshua Ballanco",
      "screen_name" : "manhattanmetric",
      "indices" : [ 7, 23 ],
      "id_str" : "261529768",
      "id" : 261529768
    }, {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 24, 36 ],
      "id_str" : "48464282",
      "id" : 48464282
    }, {
      "name" : "Mateus",
      "screen_name" : "seanlilmateus",
      "indices" : [ 37, 51 ],
      "id_str" : "16103797",
      "id" : 16103797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317377353867198464",
  "geo" : { },
  "id_str" : "317379414117736448",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy @manhattanmetric @clayallsopp @seanlilmateus i was wondering where people were! I'll try to find it.",
  "id" : 317379414117736448,
  "in_reply_to_status_id" : 317377353867198464,
  "created_at" : "2013-03-28 20:55:23 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/seo9SHKSU0",
      "expanded_url" : "http:\/\/37svn.com\/3432",
      "display_url" : "37svn.com\/3432"
    } ]
  },
  "in_reply_to_status_id_str" : "317345984529178624",
  "geo" : { },
  "id_str" : "317369763603021824",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan Did you see http:\/\/t.co\/seo9SHKSU0 ? if you have questions I'd be happy to help.",
  "id" : 317369763603021824,
  "in_reply_to_status_id" : 317345984529178624,
  "created_at" : "2013-03-28 20:17:02 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317355219690332161",
  "geo" : { },
  "id_str" : "317361307445776386",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi ugh :( We should yank those.",
  "id" : 317361307445776386,
  "in_reply_to_status_id" : 317355219690332161,
  "created_at" : "2013-03-28 19:43:26 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317284632011878401",
  "text" : "Jet lagging. Hard.",
  "id" : 317284632011878401,
  "created_at" : "2013-03-28 14:38:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 0, 11 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317284242524618752",
  "geo" : { },
  "id_str" : "317284532137127937",
  "in_reply_to_user_id" : 15020118,
  "text" : "@jaytennier shut the fuck up Donnie.",
  "id" : 317284532137127937,
  "in_reply_to_status_id" : 317284242524618752,
  "created_at" : "2013-03-28 14:38:21 +0000",
  "in_reply_to_screen_name" : "jaytennier",
  "in_reply_to_user_id_str" : "15020118",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 61, 72 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect2013",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ILfjZqLA2i",
      "expanded_url" : "http:\/\/github.com\/qrush\/motion-layout",
      "display_url" : "github.com\/qrush\/motion-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317266514027880448",
  "text" : "Having a blast at #inspect2013, and here\u2019s a new gem for the @RubyMotion community: motion-layout! http:\/\/t.co\/ILfjZqLA2i",
  "id" : 317266514027880448,
  "created_at" : "2013-03-28 13:26:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316981170766233600",
  "geo" : { },
  "id_str" : "316981679124271104",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef Is someone going to ask about a certain $35M acquisition?",
  "id" : 316981679124271104,
  "in_reply_to_status_id" : 316981170766233600,
  "created_at" : "2013-03-27 18:34:56 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316972672384905217",
  "geo" : { },
  "id_str" : "316972996688490496",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej furiously trying to figure out what ringtone this belongs with",
  "id" : 316972996688490496,
  "in_reply_to_status_id" : 316972672384905217,
  "created_at" : "2013-03-27 18:00:26 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316972672384905217",
  "geo" : { },
  "id_str" : "316972843340533760",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej I'm special teams",
  "id" : 316972843340533760,
  "in_reply_to_status_id" : 316972672384905217,
  "created_at" : "2013-03-27 17:59:49 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/piGFEjG9gI",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/5256546",
      "display_url" : "gist.github.com\/qrush\/5256546"
    } ]
  },
  "geo" : { },
  "id_str" : "316972074331668480",
  "text" : "Here's a real \"MY PHONE\" interview. With myself. https:\/\/t.co\/piGFEjG9gI",
  "id" : 316972074331668480,
  "created_at" : "2013-03-27 17:56:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316957986188820482",
  "geo" : { },
  "id_str" : "316958201708957698",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda I don't know what is better: 2 iphones, or a custom-built app for a personal assistant only",
  "id" : 316958201708957698,
  "in_reply_to_status_id" : 316957986188820482,
  "created_at" : "2013-03-27 17:01:38 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/LEMu5jM2AZ",
      "expanded_url" : "http:\/\/js1k.com\/2013-spring\/demo\/1459",
      "display_url" : "js1k.com\/2013-spring\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316947243506757634",
  "text" : "As usual blown away by JS1k. Even got the lights to flicker on this minecraft ride: http:\/\/t.co\/LEMu5jM2AZ",
  "id" : 316947243506757634,
  "created_at" : "2013-03-27 16:18:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    }, {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 13, 24 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316936884167274496",
  "geo" : { },
  "id_str" : "316937199176278016",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens @cadeparade R-E-A-D-A-BO-OOOOOOOOOK!!",
  "id" : 316937199176278016,
  "in_reply_to_status_id" : 316936884167274496,
  "created_at" : "2013-03-27 15:38:11 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316927528805736448",
  "geo" : { },
  "id_str" : "316936790542016515",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade write an app write an app write a motherfuckin app",
  "id" : 316936790542016515,
  "in_reply_to_status_id" : 316927528805736448,
  "created_at" : "2013-03-27 15:36:33 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316933123948552192",
  "geo" : { },
  "id_str" : "316936685508235265",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak I don't think I ever got it working. Looks like I did have a blurb in the readme but no code backed it up.",
  "id" : 316936685508235265,
  "in_reply_to_status_id" : 316933123948552192,
  "created_at" : "2013-03-27 15:36:08 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lee",
      "screen_name" : "kastiglione",
      "indices" : [ 0, 12 ],
      "id_str" : "337785394",
      "id" : 337785394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316909095229743104",
  "geo" : { },
  "id_str" : "316925357569753088",
  "in_reply_to_user_id" : 337785394,
  "text" : "@kastiglione Pixel.",
  "id" : 316925357569753088,
  "in_reply_to_status_id" : 316909095229743104,
  "created_at" : "2013-03-27 14:51:08 +0000",
  "in_reply_to_screen_name" : "kastiglione",
  "in_reply_to_user_id_str" : "337785394",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 0, 9 ],
      "id_str" : "876930312",
      "id" : 876930312
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316734571787980803",
  "geo" : { },
  "id_str" : "316923352453373952",
  "in_reply_to_user_id" : 876930312,
  "text" : "@BfloFRED @coworkbuffalo Yay!",
  "id" : 316923352453373952,
  "in_reply_to_status_id" : 316734571787980803,
  "created_at" : "2013-03-27 14:43:10 +0000",
  "in_reply_to_screen_name" : "BfloFRED",
  "in_reply_to_user_id_str" : "876930312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/316908376145670144\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/glb3YKRr7l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGXifTLCMAAvVvE.jpg",
      "id_str" : "316908376149864448",
      "id" : 316908376149864448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGXifTLCMAAvVvE.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/glb3YKRr7l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316908376145670144",
  "text" : "I was just left in charge of this cafe. Hard to complain. http:\/\/t.co\/glb3YKRr7l",
  "id" : 316908376145670144,
  "created_at" : "2013-03-27 13:43:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Rudick",
      "screen_name" : "tmrudick",
      "indices" : [ 0, 9 ],
      "id_str" : "15198826",
      "id" : 15198826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316906429539835905",
  "geo" : { },
  "id_str" : "316906617893421056",
  "in_reply_to_user_id" : 15198826,
  "text" : "@tmrudick because it\u2019s really difficult.",
  "id" : 316906617893421056,
  "in_reply_to_status_id" : 316906429539835905,
  "created_at" : "2013-03-27 13:36:40 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316893123072643072",
  "geo" : { },
  "id_str" : "316906313638612992",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy not a vacation!",
  "id" : 316906313638612992,
  "in_reply_to_status_id" : 316893123072643072,
  "created_at" : "2013-03-27 13:35:27 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316857811562803200",
  "geo" : { },
  "id_str" : "316865307568402432",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack I used to do lights\/set construction in high school. I once got yelled at for wearing a Macbeth shirt on opening day.",
  "id" : 316865307568402432,
  "in_reply_to_status_id" : 316857811562803200,
  "created_at" : "2013-03-27 10:52:31 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316855979511799809",
  "geo" : { },
  "id_str" : "316856682397442048",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack I bet they involve waste product and hitched trailers",
  "id" : 316856682397442048,
  "in_reply_to_status_id" : 316855979511799809,
  "created_at" : "2013-03-27 10:18:14 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 3, 15 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/2kFnyM2fGf",
      "expanded_url" : "http:\/\/blog.michellebu.com\/2013\/03\/21-nested-callbacks\/",
      "display_url" : "blog.michellebu.com\/2013\/03\/21-nes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316848765417947136",
  "text" : "RT @jamesarosen: Programming is hard: http:\/\/t.co\/2kFnyM2fGf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/2kFnyM2fGf",
        "expanded_url" : "http:\/\/blog.michellebu.com\/2013\/03\/21-nested-callbacks\/",
        "display_url" : "blog.michellebu.com\/2013\/03\/21-nes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316844345129050112",
    "text" : "Programming is hard: http:\/\/t.co\/2kFnyM2fGf",
    "id" : 316844345129050112,
    "created_at" : "2013-03-27 09:29:13 +0000",
    "user" : {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "protected" : false,
      "id_str" : "7114202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448559866206908416\/Q0FAFt_n_normal.jpeg",
      "id" : 7114202,
      "verified" : false
    }
  },
  "id" : 316848765417947136,
  "created_at" : "2013-03-27 09:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316825878011183104",
  "geo" : { },
  "id_str" : "316826133767278592",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza well at least I got Phish tickets this year.",
  "id" : 316826133767278592,
  "in_reply_to_status_id" : 316825878011183104,
  "created_at" : "2013-03-27 08:16:51 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316825339449982976",
  "geo" : { },
  "id_str" : "316825704727711744",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza are tickets supposed to be up soon? I\u2019d really like to go.",
  "id" : 316825704727711744,
  "in_reply_to_status_id" : 316825339449982976,
  "created_at" : "2013-03-27 08:15:09 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316814232102531072",
  "geo" : { },
  "id_str" : "316815411536601088",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz that would be awesome, thank you!! Is the training in the same location as the conf? I could drop by.",
  "id" : 316815411536601088,
  "in_reply_to_status_id" : 316814232102531072,
  "created_at" : "2013-03-27 07:34:14 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316812450416717825",
  "text" : "And I forgot a power adapter for EU. *facepalm*",
  "id" : 316812450416717825,
  "created_at" : "2013-03-27 07:22:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316799225348362240",
  "text" : "Also starting to realize my bad luck with traveling tends to correlate with my terrible travel preparation skills.",
  "id" : 316799225348362240,
  "created_at" : "2013-03-27 06:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316799104166547456",
  "text" : "Hi Europe! (And Brussels!) It\u2019s been a while.",
  "id" : 316799104166547456,
  "created_at" : "2013-03-27 06:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316664058826870785",
  "text" : "Best flight experience so far: random African dude asks me to take his picture in a first class seat (definitely was not his seat!)",
  "id" : 316664058826870785,
  "created_at" : "2013-03-26 21:32:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby5",
      "screen_name" : "rubyfive",
      "indices" : [ 3, 12 ],
      "id_str" : "56158733",
      "id" : 56158733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bkF5AIC3Ha",
      "expanded_url" : "http:\/\/ruby5.envylabs.com\/episodes\/360-episode-356-march-26th-2013",
      "display_url" : "ruby5.envylabs.com\/episodes\/360-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316649861309153281",
  "text" : "RT @rubyfive: Security news, custom IRB, local pull requests, tuning Ruby, pry-doc 0.4.5, git bisect, Nickel City Ruby &amp; SpreeConf.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/bkF5AIC3Ha",
        "expanded_url" : "http:\/\/ruby5.envylabs.com\/episodes\/360-episode-356-march-26th-2013",
        "display_url" : "ruby5.envylabs.com\/episodes\/360-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316645976406368256",
    "text" : "Security news, custom IRB, local pull requests, tuning Ruby, pry-doc 0.4.5, git bisect, Nickel City Ruby &amp; SpreeConf. http:\/\/t.co\/bkF5AIC3Ha",
    "id" : 316645976406368256,
    "created_at" : "2013-03-26 20:20:58 +0000",
    "user" : {
      "name" : "Ruby5",
      "screen_name" : "rubyfive",
      "protected" : false,
      "id_str" : "56158733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556473444897144833\/Uo1I1n0V_normal.jpeg",
      "id" : 56158733,
      "verified" : false
    }
  },
  "id" : 316649861309153281,
  "created_at" : "2013-03-26 20:36:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316596679333785600",
  "text" : "Technology just made something absolutely amazing happen. Holy wow.",
  "id" : 316596679333785600,
  "created_at" : "2013-03-26 17:05:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/0rr4Lr63fW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=X4N-ZBbPmQs",
      "display_url" : "youtube.com\/watch?v=X4N-ZB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316568486975504384",
  "text" : "Current status: http:\/\/t.co\/0rr4Lr63fW",
  "id" : 316568486975504384,
  "created_at" : "2013-03-26 15:13:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316563820187381761",
  "text" : "Things are looking super bright today for @nickelcityruby. Breakthrough after a few months of blah.",
  "id" : 316563820187381761,
  "created_at" : "2013-03-26 14:54:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 97, 111 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bufftrucks",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316552751934996481",
  "text" : "Pulling for the #bufftrucks today. Glad we didn\u2019t have to pay an upfront fee to the city to open @coworkbuffalo.",
  "id" : 316552751934996481,
  "created_at" : "2013-03-26 14:10:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ninefold",
      "screen_name" : "ninefold",
      "indices" : [ 3, 12 ],
      "id_str" : "237541322",
      "id" : 237541322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/BOo3sAIg90",
      "expanded_url" : "http:\/\/ninefold.com\/blog\/ruby\/australian-rubygems-mirror\/",
      "display_url" : "ninefold.com\/blog\/ruby\/aust\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316540005982027776",
  "text" : "RT @ninefold: We're excited to announce that Ninefold is hosting an Australian RubyGems mirror. http:\/\/t.co\/BOo3sAIg90",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/BOo3sAIg90",
        "expanded_url" : "http:\/\/ninefold.com\/blog\/ruby\/australian-rubygems-mirror\/",
        "display_url" : "ninefold.com\/blog\/ruby\/aust\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316427755355009024",
    "text" : "We're excited to announce that Ninefold is hosting an Australian RubyGems mirror. http:\/\/t.co\/BOo3sAIg90",
    "id" : 316427755355009024,
    "created_at" : "2013-03-26 05:53:50 +0000",
    "user" : {
      "name" : "Ninefold",
      "screen_name" : "ninefold",
      "protected" : false,
      "id_str" : "237541322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000855954663\/9f2d5f7bc82e45cc36feead4f625bb16_normal.jpeg",
      "id" : 237541322,
      "verified" : false
    }
  },
  "id" : 316540005982027776,
  "created_at" : "2013-03-26 13:19:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kurt braget",
      "screen_name" : "kurtybot",
      "indices" : [ 0, 9 ],
      "id_str" : "221278284",
      "id" : 221278284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316346432435142659",
  "geo" : { },
  "id_str" : "316531626102374401",
  "in_reply_to_user_id" : 221278284,
  "text" : "@kurtybot we have a fix coming for this soon!",
  "id" : 316531626102374401,
  "in_reply_to_status_id" : 316346432435142659,
  "created_at" : "2013-03-26 12:46:35 +0000",
  "in_reply_to_screen_name" : "kurtybot",
  "in_reply_to_user_id_str" : "221278284",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 0, 6 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316389108735950848",
  "geo" : { },
  "id_str" : "316389278382948353",
  "in_reply_to_user_id" : 30923,
  "text" : "@rands I really hope they don't.",
  "id" : 316389278382948353,
  "in_reply_to_status_id" : 316389108735950848,
  "created_at" : "2013-03-26 03:20:56 +0000",
  "in_reply_to_screen_name" : "rands",
  "in_reply_to_user_id_str" : "30923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316388330969374720",
  "geo" : { },
  "id_str" : "316388914510303232",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz that's super shitty...yikes",
  "id" : 316388914510303232,
  "in_reply_to_status_id" : 316388330969374720,
  "created_at" : "2013-03-26 03:19:30 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316359643515465728",
  "geo" : { },
  "id_str" : "316359810524254208",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending Bike. Bike bike bike. Just biked today with Ged.",
  "id" : 316359810524254208,
  "in_reply_to_status_id" : 316359643515465728,
  "created_at" : "2013-03-26 01:23:51 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316347782002790400",
  "geo" : { },
  "id_str" : "316359076227448832",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 Sure am! What's up?",
  "id" : 316359076227448832,
  "in_reply_to_status_id" : 316347782002790400,
  "created_at" : "2013-03-26 01:20:56 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316352387126280193",
  "geo" : { },
  "id_str" : "316358734479761408",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw but will she light it on fire!?",
  "id" : 316358734479761408,
  "in_reply_to_status_id" : 316352387126280193,
  "created_at" : "2013-03-26 01:19:34 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 3, 11 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/pvQAu0Xajy",
      "expanded_url" : "http:\/\/rubysec.github.com",
      "display_url" : "rubysec.github.com"
    }, {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/NddMMjaf0X",
      "expanded_url" : "http:\/\/rubysec.github.com\/advisories\/CVE-2013-1857",
      "display_url" : "rubysec.github.com\/advisories\/CVE\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jfEYg3Awma",
      "expanded_url" : "http:\/\/rubysec.github.com\/advisories\/categories\/rails\/",
      "display_url" : "rubysec.github.com\/advisories\/cat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316308673322418176",
  "text" : "RT @bascule: The new http:\/\/t.co\/pvQAu0Xajy is up. View an individual advisory: http:\/\/t.co\/NddMMjaf0X or all Rails advisories: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/pvQAu0Xajy",
        "expanded_url" : "http:\/\/rubysec.github.com",
        "display_url" : "rubysec.github.com"
      }, {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/NddMMjaf0X",
        "expanded_url" : "http:\/\/rubysec.github.com\/advisories\/CVE-2013-1857",
        "display_url" : "rubysec.github.com\/advisories\/CVE\u2026"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/jfEYg3Awma",
        "expanded_url" : "http:\/\/rubysec.github.com\/advisories\/categories\/rails\/",
        "display_url" : "rubysec.github.com\/advisories\/cat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316305124190474240",
    "text" : "The new http:\/\/t.co\/pvQAu0Xajy is up. View an individual advisory: http:\/\/t.co\/NddMMjaf0X or all Rails advisories: http:\/\/t.co\/jfEYg3Awma",
    "id" : 316305124190474240,
    "created_at" : "2013-03-25 21:46:32 +0000",
    "user" : {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "protected" : false,
      "id_str" : "6083342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450061818606522368\/pjDTHFB9_normal.jpeg",
      "id" : 6083342,
      "verified" : false
    }
  },
  "id" : 316308673322418176,
  "created_at" : "2013-03-25 22:00:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "wolax",
      "indices" : [ 0, 6 ],
      "id_str" : "8029562",
      "id" : 8029562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316302667230097410",
  "geo" : { },
  "id_str" : "316303789940412416",
  "in_reply_to_user_id" : 8029562,
  "text" : "@wolax Brussels !",
  "id" : 316303789940412416,
  "in_reply_to_status_id" : 316302667230097410,
  "created_at" : "2013-03-25 21:41:14 +0000",
  "in_reply_to_screen_name" : "wolax",
  "in_reply_to_user_id_str" : "8029562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/vLoGGhKSeD",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Drake_equation",
      "display_url" : "en.wikipedia.org\/wiki\/Drake_equ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "316284654611210240",
  "geo" : { },
  "id_str" : "316285391588175873",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen Not to bum you out, but: http:\/\/t.co\/vLoGGhKSeD",
  "id" : 316285391588175873,
  "in_reply_to_status_id" : 316284654611210240,
  "created_at" : "2013-03-25 20:28:08 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316273596102234112",
  "text" : "Beyond the \"short and sturdy creature fond of drink and industry\" that is literally on every. single. dorf.",
  "id" : 316273596102234112,
  "created_at" : "2013-03-25 19:41:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316273498110717953",
  "text" : "Best line of description from a dwarf's bio in Dwarf Fortress: \"Needs alcohol to get through the working day\"",
  "id" : 316273498110717953,
  "created_at" : "2013-03-25 19:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz DiFiore",
      "screen_name" : "LizDiFiore",
      "indices" : [ 0, 11 ],
      "id_str" : "1205171251",
      "id" : 1205171251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316264836373807105",
  "geo" : { },
  "id_str" : "316265361660063744",
  "in_reply_to_user_id" : 1205171251,
  "text" : "@LizDiFiore Solution: don't watch local TV (or read dead trees). I'm convinced this is a generational thing.",
  "id" : 316265361660063744,
  "in_reply_to_status_id" : 316264836373807105,
  "created_at" : "2013-03-25 19:08:32 +0000",
  "in_reply_to_screen_name" : "LizDiFiore",
  "in_reply_to_user_id_str" : "1205171251",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316260099922460673",
  "geo" : { },
  "id_str" : "316264071676694528",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox We have to have a letterpress match or something in the air.",
  "id" : 316264071676694528,
  "in_reply_to_status_id" : 316260099922460673,
  "created_at" : "2013-03-25 19:03:25 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/OdcxLkNRbc",
      "expanded_url" : "http:\/\/37svn.com\/3485",
      "display_url" : "37svn.com\/3485"
    } ]
  },
  "geo" : { },
  "id_str" : "316263921856151552",
  "text" : "Happy to hear http:\/\/t.co\/OdcxLkNRbc has inspired talks of first jobs today at some offices. More!",
  "id" : 316263921856151552,
  "created_at" : "2013-03-25 19:02:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/trZPwRzKFC",
      "expanded_url" : "http:\/\/vimeo.com\/24715531",
      "display_url" : "vimeo.com\/24715531"
    } ]
  },
  "geo" : { },
  "id_str" : "316263401057828864",
  "text" : "\"It's only through a volume of work that you're actually going to catch up and close that gap\" http:\/\/t.co\/trZPwRzKFC",
  "id" : 316263401057828864,
  "created_at" : "2013-03-25 19:00:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316259621947965440",
  "geo" : { },
  "id_str" : "316260761582313472",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto If you don't like 'murica you can GET OUT",
  "id" : 316260761582313472,
  "in_reply_to_status_id" : 316259621947965440,
  "created_at" : "2013-03-25 18:50:16 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2PMIvJrJFP",
      "expanded_url" : "http:\/\/images.t-shirts.com\/combat-stryker-tshirt-front-hr.jpg",
      "display_url" : "images.t-shirts.com\/combat-stryker\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316259367701852160",
  "text" : "Going to Europe for the first time in over 10 years tomorrow. Is this appropriate attire? http:\/\/t.co\/2PMIvJrJFP",
  "id" : 316259367701852160,
  "created_at" : "2013-03-25 18:44:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316245179826860032",
  "geo" : { },
  "id_str" : "316246147108855808",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan cfp\/registration opening soon, sign up and we\u2019ll let you know!",
  "id" : 316246147108855808,
  "in_reply_to_status_id" : 316245179826860032,
  "created_at" : "2013-03-25 17:52:11 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Ruby5",
      "screen_name" : "rubyfive",
      "indices" : [ 14, 23 ],
      "id_str" : "56158733",
      "id" : 56158733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "316241766804242432",
  "geo" : { },
  "id_str" : "316242085592305664",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @rubyfive A shoutout about http:\/\/t.co\/3UAdoKZw7Q would be cool. I will shout again when CFP\/registration opens!",
  "id" : 316242085592305664,
  "in_reply_to_status_id" : 316241766804242432,
  "created_at" : "2013-03-25 17:36:03 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316241207166660608",
  "geo" : { },
  "id_str" : "316241284882919424",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa Yes. that's awesome.",
  "id" : 316241284882919424,
  "in_reply_to_status_id" : 316241207166660608,
  "created_at" : "2013-03-25 17:32:52 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OdcxLkNRbc",
      "expanded_url" : "http:\/\/37svn.com\/3485",
      "display_url" : "37svn.com\/3485"
    } ]
  },
  "geo" : { },
  "id_str" : "316232118625783808",
  "text" : "What was your first job? Do you know your coworkers' first jobs? I asked, learned much and had a lot of fun: http:\/\/t.co\/OdcxLkNRbc",
  "id" : 316232118625783808,
  "created_at" : "2013-03-25 16:56:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316230775349583872",
  "geo" : { },
  "id_str" : "316231599169617921",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine new gig? congrats! moving too?",
  "id" : 316231599169617921,
  "in_reply_to_status_id" : 316230775349583872,
  "created_at" : "2013-03-25 16:54:23 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316229652622479361",
  "geo" : { },
  "id_str" : "316229948367069184",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr my email is my gtalk.",
  "id" : 316229948367069184,
  "in_reply_to_status_id" : 316229652622479361,
  "created_at" : "2013-03-25 16:47:49 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniele Di Bernardo",
      "screen_name" : "marzapower",
      "indices" : [ 0, 11 ],
      "id_str" : "14918197",
      "id" : 14918197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316224225784520704",
  "geo" : { },
  "id_str" : "316229055143874560",
  "in_reply_to_user_id" : 14918197,
  "text" : "@marzapower yeah. you probably already have one :)",
  "id" : 316229055143874560,
  "in_reply_to_status_id" : 316224225784520704,
  "created_at" : "2013-03-25 16:44:16 +0000",
  "in_reply_to_screen_name" : "marzapower",
  "in_reply_to_user_id_str" : "14918197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316228619104030721",
  "geo" : { },
  "id_str" : "316228999858774019",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Get ready!!!",
  "id" : 316228999858774019,
  "in_reply_to_status_id" : 316228619104030721,
  "created_at" : "2013-03-25 16:44:03 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316222723888132097",
  "geo" : { },
  "id_str" : "316223182325567488",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella \"May of 2013\" FUTURE PRODUCT!",
  "id" : 316223182325567488,
  "in_reply_to_status_id" : 316222723888132097,
  "created_at" : "2013-03-25 16:20:56 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 0, 6 ],
      "id_str" : "8605362",
      "id" : 8605362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316176281295265792",
  "geo" : { },
  "id_str" : "316194102884564992",
  "in_reply_to_user_id" : 8605362,
  "text" : "@keavy Getting 500 errors on submission :\/",
  "id" : 316194102884564992,
  "in_reply_to_status_id" : 316176281295265792,
  "created_at" : "2013-03-25 14:25:23 +0000",
  "in_reply_to_screen_name" : "keavy",
  "in_reply_to_user_id_str" : "8605362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This American Life",
      "screen_name" : "ThisAmerLife",
      "indices" : [ 90, 103 ],
      "id_str" : "149180925",
      "id" : 149180925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316185309928910848",
  "text" : "Harper High &amp; Trends with Benefits have been eye-opening and mind-blowing episodes of @ThisAmerLife. Please go listen if you haven't.",
  "id" : 316185309928910848,
  "created_at" : "2013-03-25 13:50:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316003585806704640",
  "text" : "Just used sox for the first time to convert ogg =&gt; mp3, via homebrew. `sox Encounter.ogg Encounter.mp3`. Done!",
  "id" : 316003585806704640,
  "created_at" : "2013-03-25 01:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316003407804657665",
  "text" : "Easily the most nerve-wracking email: \"The status for the following app has changed to In Review.\"",
  "id" : 316003407804657665,
  "created_at" : "2013-03-25 01:47:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315916968840536064",
  "geo" : { },
  "id_str" : "315918184437927937",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza This is one of many reasons why UIWebView is a huge part of Basecamp.app.",
  "id" : 315918184437927937,
  "in_reply_to_status_id" : 315916968840536064,
  "created_at" : "2013-03-24 20:08:59 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 12, 18 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315894730007379968",
  "geo" : { },
  "id_str" : "315894951730892800",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger @raggi wat!?",
  "id" : 315894951730892800,
  "in_reply_to_status_id" : 315894730007379968,
  "created_at" : "2013-03-24 18:36:40 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    }, {
      "name" : "Thomas S.",
      "screen_name" : "schn1ttchen",
      "indices" : [ 12, 24 ],
      "id_str" : "415799500",
      "id" : 415799500
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 25, 32 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 33, 42 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315884504084520960",
  "geo" : { },
  "id_str" : "315894500910313473",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger @schn1ttchen @hone02 @indirect messing with the indexes as is wont happen. would have to be a new index, which has more problems",
  "id" : 315894500910313473,
  "in_reply_to_status_id" : 315884504084520960,
  "created_at" : "2013-03-24 18:34:52 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas S.",
      "screen_name" : "schn1ttchen",
      "indices" : [ 0, 12 ],
      "id_str" : "415799500",
      "id" : 415799500
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 89, 96 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 97, 106 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 107, 118 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315883408326799361",
  "geo" : { },
  "id_str" : "315883662103150592",
  "in_reply_to_user_id" : 415799500,
  "text" : "@schn1ttchen bundler\u2019s API could certainly be trained to have \u201Cflagged\u201D gems. Neat idea. @hone02 @indirect @lmarburger",
  "id" : 315883662103150592,
  "in_reply_to_status_id" : 315883408326799361,
  "created_at" : "2013-03-24 17:51:48 +0000",
  "in_reply_to_screen_name" : "schn1ttchen",
  "in_reply_to_user_id_str" : "415799500",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurish Sharma",
      "screen_name" : "gaurish",
      "indices" : [ 0, 8 ],
      "id_str" : "14684796",
      "id" : 14684796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315782204867375104",
  "geo" : { },
  "id_str" : "315883437150060544",
  "in_reply_to_user_id" : 14684796,
  "text" : "@gaurish cool!",
  "id" : 315883437150060544,
  "in_reply_to_status_id" : 315782204867375104,
  "created_at" : "2013-03-24 17:50:54 +0000",
  "in_reply_to_screen_name" : "gaurish",
  "in_reply_to_user_id_str" : "14684796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniele Di Bernardo",
      "screen_name" : "marzapower",
      "indices" : [ 0, 11 ],
      "id_str" : "14918197",
      "id" : 14918197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/SjbKuNKOnK",
      "expanded_url" : "https:\/\/github.com\/qrush\/dotfiles",
      "display_url" : "github.com\/qrush\/dotfiles"
    } ]
  },
  "in_reply_to_status_id_str" : "314688462559260672",
  "geo" : { },
  "id_str" : "315883371735703552",
  "in_reply_to_user_id" : 14918197,
  "text" : "@marzapower you can do this in your .gemrc. Check mine here: https:\/\/t.co\/SjbKuNKOnK",
  "id" : 315883371735703552,
  "in_reply_to_status_id" : 314688462559260672,
  "created_at" : "2013-03-24 17:50:39 +0000",
  "in_reply_to_screen_name" : "marzapower",
  "in_reply_to_user_id_str" : "14918197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Scott",
      "screen_name" : "jasonpscottcom",
      "indices" : [ 0, 15 ],
      "id_str" : "494529660",
      "id" : 494529660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/wCsxAY8phr",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "315290476884402176",
  "geo" : { },
  "id_str" : "315883172166516737",
  "in_reply_to_user_id" : 494529660,
  "text" : "@jasonpscottcom what antivirus? Also I don\u2019t blame Vagrant\u2026http:\/\/t.co\/wCsxAY8phr is a great way to get started and that\u2019s ok",
  "id" : 315883172166516737,
  "in_reply_to_status_id" : 315290476884402176,
  "created_at" : "2013-03-24 17:49:51 +0000",
  "in_reply_to_screen_name" : "jasonpscottcom",
  "in_reply_to_user_id_str" : "494529660",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas S.",
      "screen_name" : "schn1ttchen",
      "indices" : [ 0, 12 ],
      "id_str" : "415799500",
      "id" : 415799500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315232990538133504",
  "geo" : { },
  "id_str" : "315882985293496321",
  "in_reply_to_user_id" : 415799500,
  "text" : "@schn1ttchen this is rough to do automatically\u2026",
  "id" : 315882985293496321,
  "in_reply_to_status_id" : 315232990538133504,
  "created_at" : "2013-03-24 17:49:07 +0000",
  "in_reply_to_screen_name" : "schn1ttchen",
  "in_reply_to_user_id_str" : "415799500",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00E1bio Rehm",
      "screen_name" : "fgrehm",
      "indices" : [ 0, 7 ],
      "id_str" : "37705939",
      "id" : 37705939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315169856762834945",
  "geo" : { },
  "id_str" : "315882862320709633",
  "in_reply_to_user_id" : 37705939,
  "text" : "@fgrehm mirrors are most likely doing this",
  "id" : 315882862320709633,
  "in_reply_to_status_id" : 315169856762834945,
  "created_at" : "2013-03-24 17:48:37 +0000",
  "in_reply_to_screen_name" : "fgrehm",
  "in_reply_to_user_id_str" : "37705939",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darrin Holst",
      "screen_name" : "darrinholst",
      "indices" : [ 0, 12 ],
      "id_str" : "14219899",
      "id" : 14219899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315822416108613632",
  "geo" : { },
  "id_str" : "315844617604042753",
  "in_reply_to_user_id" : 14219899,
  "text" : "@darrinholst I sense a trap!",
  "id" : 315844617604042753,
  "in_reply_to_status_id" : 315822416108613632,
  "created_at" : "2013-03-24 15:16:39 +0000",
  "in_reply_to_screen_name" : "darrinholst",
  "in_reply_to_user_id_str" : "14219899",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keavy",
      "screen_name" : "keavy",
      "indices" : [ 0, 6 ],
      "id_str" : "8605362",
      "id" : 8605362
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315598315632873473",
  "geo" : { },
  "id_str" : "315648334373199874",
  "in_reply_to_user_id" : 8605362,
  "text" : "@keavy awesome. I\u2019d love to get @nickelcityruby on the list",
  "id" : 315648334373199874,
  "in_reply_to_status_id" : 315598315632873473,
  "created_at" : "2013-03-24 02:16:42 +0000",
  "in_reply_to_screen_name" : "keavy",
  "in_reply_to_user_id_str" : "8605362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315575573328044033",
  "geo" : { },
  "id_str" : "315575821156884480",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude AirBNB?",
  "id" : 315575821156884480,
  "in_reply_to_status_id" : 315575573328044033,
  "created_at" : "2013-03-23 21:28:33 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 7, 22 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Lanyrd",
      "screen_name" : "lanyrd",
      "indices" : [ 26, 33 ],
      "id_str" : "169942861",
      "id" : 169942861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/FMh3QztoGT",
      "expanded_url" : "http:\/\/lanyrd.com\/2013\/ncrc13\/",
      "display_url" : "lanyrd.com\/2013\/ncrc13\/"
    } ]
  },
  "geo" : { },
  "id_str" : "315575762889617408",
  "text" : "Set up @nickelcityruby on @lanyrd...feeling more and more real! http:\/\/t.co\/FMh3QztoGT",
  "id" : 315575762889617408,
  "created_at" : "2013-03-23 21:28:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/AeaY8M2BSr",
      "expanded_url" : "http:\/\/rubythere.com",
      "display_url" : "rubythere.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315575090815328256",
  "text" : "What happened to http:\/\/t.co\/AeaY8M2BSr ?",
  "id" : 315575090815328256,
  "created_at" : "2013-03-23 21:25:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315560610295332865",
  "geo" : { },
  "id_str" : "315571488998715393",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella awesome man. lots of good info on \/r\/dogs! good luck. puppies are hard.",
  "id" : 315571488998715393,
  "in_reply_to_status_id" : 315560610295332865,
  "created_at" : "2013-03-23 21:11:20 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315301529064189952",
  "text" : "My main problem with Dwarf Fortress: I get more immersed in the landscape and planning than actually playing.",
  "id" : 315301529064189952,
  "created_at" : "2013-03-23 03:18:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 0, 10 ],
      "id_str" : "14437070",
      "id" : 14437070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315295726290759680",
  "geo" : { },
  "id_str" : "315296082940801024",
  "in_reply_to_user_id" : 14437070,
  "text" : "@marksands SPOILERS! No seriously. I have a certain set of skills. I will find them, and I will kill them.",
  "id" : 315296082940801024,
  "in_reply_to_status_id" : 315295726290759680,
  "created_at" : "2013-03-23 02:56:58 +0000",
  "in_reply_to_screen_name" : "marksands",
  "in_reply_to_user_id_str" : "14437070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315293796038488064",
  "geo" : { },
  "id_str" : "315294053283549184",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded Starting a succession fort soon! Trying to get everything set up. You're more than welcome to join or watch on G+ :)",
  "id" : 315294053283549184,
  "in_reply_to_status_id" : 315293796038488064,
  "created_at" : "2013-03-23 02:48:54 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315293047879507971",
  "geo" : { },
  "id_str" : "315293698697076736",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff I love old manuals like this. the drawings are the best.",
  "id" : 315293698697076736,
  "in_reply_to_status_id" : 315293047879507971,
  "created_at" : "2013-03-23 02:47:30 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/uQpyKMAtLp",
      "expanded_url" : "https:\/\/soundcloud.com\/simonswerwer\/sets",
      "display_url" : "soundcloud.com\/simonswerwer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315292835895209989",
  "text" : "It's that time again. https:\/\/t.co\/uQpyKMAtLp",
  "id" : 315292835895209989,
  "created_at" : "2013-03-23 02:44:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/O9Cs4uzz9B",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315288356944769025",
  "text" : "55 OpenHack cities, all in various states of running (most just starting meetups, some active). It's working! http:\/\/t.co\/O9Cs4uzz9B",
  "id" : 315288356944769025,
  "created_at" : "2013-03-23 02:26:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Zhxt0syvKA",
      "expanded_url" : "http:\/\/i.qkme.me\/3qpw0u.jpg",
      "display_url" : "i.qkme.me\/3qpw0u.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "315281694137671680",
  "text" : "To the last 5 fish in Ridiculous Fishing that are deeper than 1000m on Maelstrom: http:\/\/t.co\/Zhxt0syvKA",
  "id" : 315281694137671680,
  "created_at" : "2013-03-23 01:59:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315278385561616384",
  "geo" : { },
  "id_str" : "315278912773050370",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded obviously the stealers are at fault primarily. Blow the whistle on that bullshit",
  "id" : 315278912773050370,
  "in_reply_to_status_id" : 315278385561616384,
  "created_at" : "2013-03-23 01:48:45 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315278385561616384",
  "geo" : { },
  "id_str" : "315278772427444224",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded the use cases are different\u2026can you imagine a game company allowing another to borrow art assets?",
  "id" : 315278772427444224,
  "in_reply_to_status_id" : 315278385561616384,
  "created_at" : "2013-03-23 01:48:11 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315277080503922689",
  "geo" : { },
  "id_str" : "315277315879882752",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded if they were serious they could have CC licensed the sprites. Not much you can do on hearsay.",
  "id" : 315277315879882752,
  "in_reply_to_status_id" : 315277080503922689,
  "created_at" : "2013-03-23 01:42:24 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315272606766989313",
  "geo" : { },
  "id_str" : "315276631675662336",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded sigh. I\u2019ve seen this cycle repeated over and over.",
  "id" : 315276631675662336,
  "in_reply_to_status_id" : 315272606766989313,
  "created_at" : "2013-03-23 01:39:41 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315274913290276864",
  "geo" : { },
  "id_str" : "315275959009943553",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw :(@)",
  "id" : 315275959009943553,
  "in_reply_to_status_id" : 315274913290276864,
  "created_at" : "2013-03-23 01:37:00 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Z1koesAeCk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sdSJ1--kBZ4",
      "display_url" : "youtube.com\/watch?v=sdSJ1-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315275906233008128",
  "text" : "RT @gabebw: LEMONS?! http:\/\/t.co\/Z1koesAeCk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/Z1koesAeCk",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sdSJ1--kBZ4",
        "display_url" : "youtube.com\/watch?v=sdSJ1-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "315274913290276864",
    "text" : "LEMONS?! http:\/\/t.co\/Z1koesAeCk",
    "id" : 315274913290276864,
    "created_at" : "2013-03-23 01:32:51 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 315275906233008128,
  "created_at" : "2013-03-23 01:36:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315241414105645056",
  "geo" : { },
  "id_str" : "315267433655054336",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon we just submitted a release to  fix this today. Hopefully will be approved soon :\/",
  "id" : 315267433655054336,
  "in_reply_to_status_id" : 315241414105645056,
  "created_at" : "2013-03-23 01:03:08 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315215792562114562",
  "geo" : { },
  "id_str" : "315266810524094465",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon hey! It\u2019s been a while. Yes, one step at a time. Literally was our first internally run iOS project.",
  "id" : 315266810524094465,
  "in_reply_to_status_id" : 315215792562114562,
  "created_at" : "2013-03-23 01:00:39 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 3, 16 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/codemastermm\/status\/315203176263462912\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/DMCTrVbCTv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF_TnmpCAAAqd8d.jpg",
      "id_str" : "315203176280227840",
      "id" : 315203176280227840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF_TnmpCAAAqd8d.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com\/DMCTrVbCTv"
    } ],
    "hashtags" : [ {
      "text" : "PAX",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315203461132193792",
  "text" : "RT @codemastermm: So I heard you like tabletop games #PAX http:\/\/t.co\/DMCTrVbCTv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/codemastermm\/status\/315203176263462912\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/DMCTrVbCTv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF_TnmpCAAAqd8d.jpg",
        "id_str" : "315203176280227840",
        "id" : 315203176280227840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF_TnmpCAAAqd8d.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1944,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com\/DMCTrVbCTv"
      } ],
      "hashtags" : [ {
        "text" : "PAX",
        "indices" : [ 35, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315203176263462912",
    "text" : "So I heard you like tabletop games #PAX http:\/\/t.co\/DMCTrVbCTv",
    "id" : 315203176263462912,
    "created_at" : "2013-03-22 20:47:48 +0000",
    "user" : {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "protected" : false,
      "id_str" : "15375238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2362207395\/57dmpi6unqtrh9le126t_normal.jpeg",
      "id" : 15375238,
      "verified" : false
    }
  },
  "id" : 315203461132193792,
  "created_at" : "2013-03-22 20:48:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315176857609842688",
  "geo" : { },
  "id_str" : "315178287934615552",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda Frequently. I am the worst.",
  "id" : 315178287934615552,
  "in_reply_to_status_id" : 315176857609842688,
  "created_at" : "2013-03-22 19:08:54 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315176857609842688",
  "geo" : { },
  "id_str" : "315178262273859584",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda yeah, just been getting several frequency. I didn't ask for them :\/",
  "id" : 315178262273859584,
  "in_reply_to_status_id" : 315176857609842688,
  "created_at" : "2013-03-22 19:08:48 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Tyler Hunt",
      "screen_name" : "tylerhunt",
      "indices" : [ 14, 24 ],
      "id_str" : "4384181",
      "id" : 4384181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315174476293750787",
  "geo" : { },
  "id_str" : "315177865543032832",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @tylerhunt but...link?",
  "id" : 315177865543032832,
  "in_reply_to_status_id" : 315174476293750787,
  "created_at" : "2013-03-22 19:07:13 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Tyler Hunt",
      "screen_name" : "tylerhunt",
      "indices" : [ 14, 24 ],
      "id_str" : "4384181",
      "id" : 4384181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315174476293750787",
  "geo" : { },
  "id_str" : "315177800611012609",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @tylerhunt any spare time i get for rubygems is usually spent on attacking the support queue",
  "id" : 315177800611012609,
  "in_reply_to_status_id" : 315174476293750787,
  "created_at" : "2013-03-22 19:06:58 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Tyler Hunt",
      "screen_name" : "tylerhunt",
      "indices" : [ 14, 24 ],
      "id_str" : "4384181",
      "id" : 4384181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hAaxyFryyu",
      "expanded_url" : "https:\/\/trello.com\/board\/rubygems-org\/513f9634a7ed906115000755",
      "display_url" : "trello.com\/board\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "315174476293750787",
  "geo" : { },
  "id_str" : "315177594066710528",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @tylerhunt my plate is overflowing, it's one reason i made https:\/\/t.co\/hAaxyFryyu",
  "id" : 315177594066710528,
  "in_reply_to_status_id" : 315174476293750787,
  "created_at" : "2013-03-22 19:06:08 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315176544068829184",
  "text" : "Considering responding to recruiters with just \"UNSUBSCRIBE\". Anyone else do this?",
  "id" : 315176544068829184,
  "created_at" : "2013-03-22 19:01:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Chiera",
      "screen_name" : "remarkUP",
      "indices" : [ 0, 9 ],
      "id_str" : "1631175859",
      "id" : 1631175859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/PNr2sqf4lP",
      "expanded_url" : "http:\/\/37svn.com\/3438",
      "display_url" : "37svn.com\/3438"
    } ]
  },
  "in_reply_to_status_id_str" : "313683868442062849",
  "geo" : { },
  "id_str" : "315154965159096320",
  "in_reply_to_user_id" : 482409717,
  "text" : "@remarkUP actually most of the Basecamp app is HTML5. http:\/\/t.co\/PNr2sqf4lP",
  "id" : 315154965159096320,
  "in_reply_to_status_id" : 313683868442062849,
  "created_at" : "2013-03-22 17:36:13 +0000",
  "in_reply_to_screen_name" : "ChrisChiera",
  "in_reply_to_user_id_str" : "482409717",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 111, 126 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 127, 130 ]
    }, {
      "text" : "ncrc2013",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/LeZPa2o1sc",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315152723626569729",
  "text" : "RT @aspleenic: For those of you that have asked it's official, we are doing this: http:\/\/t.co\/LeZPa2o1sc &amp; @nickelcityruby #fb #ncrc2013",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 96, 111 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 112, 115 ]
      }, {
        "text" : "ncrc2013",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/LeZPa2o1sc",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "315136061657477122",
    "text" : "For those of you that have asked it's official, we are doing this: http:\/\/t.co\/LeZPa2o1sc &amp; @nickelcityruby #fb #ncrc2013",
    "id" : 315136061657477122,
    "created_at" : "2013-03-22 16:21:06 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 315152723626569729,
  "created_at" : "2013-03-22 17:27:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wnyruby",
      "indices" : [ 124, 132 ]
    }, {
      "text" : "nickelcityruby",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/qcBrUbFC6O",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315152711391776768",
  "text" : "RT @jhsu: [ANN] Nickel City Ruby Conference http:\/\/t.co\/qcBrUbFC6O Buffalo's first ruby conference and It's Gonna Be Great. #wnyruby #ni ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wnyruby",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "nickelcityruby",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/qcBrUbFC6O",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "315140970209480704",
    "text" : "[ANN] Nickel City Ruby Conference http:\/\/t.co\/qcBrUbFC6O Buffalo's first ruby conference and It's Gonna Be Great. #wnyruby #nickelcityruby",
    "id" : 315140970209480704,
    "created_at" : "2013-03-22 16:40:36 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 315152711391776768,
  "created_at" : "2013-03-22 17:27:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/POp9LkFOCi",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-us-canada-21896141",
      "display_url" : "bbc.co.uk\/news\/world-us-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315130848292765697",
  "text" : "Your weekly reminder that the Double Cuddle is $120\/hr and now is on the BBC: http:\/\/t.co\/POp9LkFOCi",
  "id" : 315130848292765697,
  "created_at" : "2013-03-22 16:00:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 8, 14 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315113963224449025",
  "geo" : { },
  "id_str" : "315122251123027968",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos @chorn that is nice!",
  "id" : 315122251123027968,
  "in_reply_to_status_id" : 315113963224449025,
  "created_at" : "2013-03-22 15:26:14 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Orbital",
      "screen_name" : "GetOrbital",
      "indices" : [ 0, 11 ],
      "id_str" : "400292635",
      "id" : 400292635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314777698054582273",
  "geo" : { },
  "id_str" : "315098593805602818",
  "in_reply_to_user_id" : 400292635,
  "text" : "@GetOrbital fixed this for the next release. Thanks for reporting it!",
  "id" : 315098593805602818,
  "in_reply_to_status_id" : 314777698054582273,
  "created_at" : "2013-03-22 13:52:13 +0000",
  "in_reply_to_screen_name" : "GetOrbital",
  "in_reply_to_user_id_str" : "400292635",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic Jacobs",
      "screen_name" : "FredericJacobs",
      "indices" : [ 0, 15 ],
      "id_str" : "18018877",
      "id" : 18018877
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 16, 20 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 30, 44 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/q5o9ZG2GvU",
      "expanded_url" : "http:\/\/www.communitybeerworks.com\/2013\/03\/the-ipa-now-with-more-silver\/",
      "display_url" : "communitybeerworks.com\/2013\/03\/the-ip\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "315095100818612224",
  "geo" : { },
  "id_str" : "315098070171918337",
  "in_reply_to_user_id" : 18018877,
  "text" : "@FredericJacobs @lrz actually @communitybeer\u2019s IPA just got 2nd\/128 beers! http:\/\/t.co\/q5o9ZG2GvU",
  "id" : 315098070171918337,
  "in_reply_to_status_id" : 315095100818612224,
  "created_at" : "2013-03-22 13:50:08 +0000",
  "in_reply_to_screen_name" : "FredericJacobs",
  "in_reply_to_user_id_str" : "18018877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Marburger",
      "screen_name" : "lmarburger",
      "indices" : [ 0, 11 ],
      "id_str" : "2355631",
      "id" : 2355631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315093186445987840",
  "geo" : { },
  "id_str" : "315093396890992640",
  "in_reply_to_user_id" : 2355631,
  "text" : "@lmarburger soon. Working on it one step at a time.",
  "id" : 315093396890992640,
  "in_reply_to_status_id" : 315093186445987840,
  "created_at" : "2013-03-22 13:31:34 +0000",
  "in_reply_to_screen_name" : "lmarburger",
  "in_reply_to_user_id_str" : "2355631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315093039674695681",
  "geo" : { },
  "id_str" : "315093235422871552",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes no. NF (and Buffalo) politics is a mess.",
  "id" : 315093235422871552,
  "in_reply_to_status_id" : 315093039674695681,
  "created_at" : "2013-03-22 13:30:56 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315091300150046720",
  "geo" : { },
  "id_str" : "315092370578350080",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I was thinking about putting heads together to get you guys on a fork of the barcampbuf rails app\u2026if not interested it\u2019s np",
  "id" : 315092370578350080,
  "in_reply_to_status_id" : 315091300150046720,
  "created_at" : "2013-03-22 13:27:29 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/315092092416319488\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UDVWIn1PK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF9ulrBCYAAEps3.jpg",
      "id_str" : "315092092420513792",
      "id" : 315092092420513792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF9ulrBCYAAEps3.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UDVWIn1PK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315088226215944193",
  "geo" : { },
  "id_str" : "315092092416319488",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried my grandfather ran for mayor twice in Niagara Falls. I have a magnet he used to drive with to advertise. http:\/\/t.co\/UDVWIn1PK1",
  "id" : 315092092416319488,
  "in_reply_to_status_id" : 315088226215944193,
  "created_at" : "2013-03-22 13:26:23 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/TNPxEgSC55",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315086354528739328",
  "text" : "Excited to announce Buffalo\u2019s first Ruby conference! http:\/\/t.co\/TNPxEgSC55 I hope you\u2019ll want to visit us and learn.",
  "id" : 315086354528739328,
  "created_at" : "2013-03-22 13:03:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 105, 113 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eXldmt1AF0",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "315086147044921346",
  "text" : "RT @nickelcityruby: NickelCityRuby.new: Join us in Buffalo this fall for a new Ruby conference hosted by @WNYRuby! http:\/\/t.co\/eXldmt1AF0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 85, 93 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/eXldmt1AF0",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "315086090606346240",
    "text" : "NickelCityRuby.new: Join us in Buffalo this fall for a new Ruby conference hosted by @WNYRuby! http:\/\/t.co\/eXldmt1AF0",
    "id" : 315086090606346240,
    "created_at" : "2013-03-22 13:02:32 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 315086147044921346,
  "created_at" : "2013-03-22 13:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315022042216939520",
  "geo" : { },
  "id_str" : "315074838547013634",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror welcome, and stay a while :)",
  "id" : 315074838547013634,
  "in_reply_to_status_id" : 315022042216939520,
  "created_at" : "2013-03-22 12:17:49 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/NZTOMZuBHO",
      "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2013\/03\/why-ruby.html",
      "display_url" : "codinghorror.com\/blog\/2013\/03\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315074792938147841",
  "text" : "RT @codinghorror: Why Ruby? http:\/\/t.co\/NZTOMZuBHO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/NZTOMZuBHO",
        "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2013\/03\/why-ruby.html",
        "display_url" : "codinghorror.com\/blog\/2013\/03\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "315022042216939520",
    "text" : "Why Ruby? http:\/\/t.co\/NZTOMZuBHO",
    "id" : 315022042216939520,
    "created_at" : "2013-03-22 08:48:02 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2052442590\/coding-horror-official-logo-medium_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 315074792938147841,
  "created_at" : "2013-03-22 12:17:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/tf58CB7Qr0",
      "expanded_url" : "http:\/\/i.conio.net\/stallman.gif",
      "display_url" : "i.conio.net\/stallman.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "314931640147259392",
  "geo" : { },
  "id_str" : "314932075713163264",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren http:\/\/t.co\/tf58CB7Qr0",
  "id" : 314932075713163264,
  "in_reply_to_status_id" : 314931640147259392,
  "created_at" : "2013-03-22 02:50:32 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/w3Y8adzDfb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=sN8hobKMjR8#",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314930982241312768",
  "text" : "Very...very glad my husky doesn't sing like this. http:\/\/t.co\/w3Y8adzDfb!",
  "id" : 314930982241312768,
  "created_at" : "2013-03-22 02:46:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314929514373332993",
  "geo" : { },
  "id_str" : "314930115970752512",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash yep! cauliflower or almonds make for an awesome crust",
  "id" : 314930115970752512,
  "in_reply_to_status_id" : 314929514373332993,
  "created_at" : "2013-03-22 02:42:45 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/cl6JkUk8X6",
      "expanded_url" : "http:\/\/somesummersunday.files.wordpress.com\/2012\/05\/feels_goodman.jpg",
      "display_url" : "somesummersunday.files.wordpress.com\/2012\/05\/feels_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314926191087853568",
  "text" : "Current status: http:\/\/t.co\/cl6JkUk8X6",
  "id" : 314926191087853568,
  "created_at" : "2013-03-22 02:27:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314924445443706881",
  "geo" : { },
  "id_str" : "314924685995438080",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden fall has been pretty brutally warm the past 2 years. Hoping the trend continues.",
  "id" : 314924685995438080,
  "in_reply_to_status_id" : 314924445443706881,
  "created_at" : "2013-03-22 02:21:10 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314924221845340160",
  "text" : "I cannot express how excited I am to bring people to Buffalo.",
  "id" : 314924221845340160,
  "created_at" : "2013-03-22 02:19:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314921668608946177",
  "text" : "RT @nickelcityruby: puts \"Hello World!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314920550407491584",
    "text" : "puts \"Hello World!\"",
    "id" : 314920550407491584,
    "created_at" : "2013-03-22 02:04:44 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 314921668608946177,
  "created_at" : "2013-03-22 02:09:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 7, 14 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314897543391760384",
  "geo" : { },
  "id_str" : "314898080715636736",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH @zapnap you will love this then. Read the nutshell post on the subreddit sidebar. All the bacon.",
  "id" : 314898080715636736,
  "in_reply_to_status_id" : 314897543391760384,
  "created_at" : "2013-03-22 00:35:27 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314886264937668608",
  "geo" : { },
  "id_str" : "314895008518004737",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH lots of info on \/r\/keto. Down over 10 lbs. AMA ;)",
  "id" : 314895008518004737,
  "in_reply_to_status_id" : 314886264937668608,
  "created_at" : "2013-03-22 00:23:15 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314884799636594688",
  "text" : "I love keto. Tonight\u2019s dinner: hot wings, bacon blue cheese, cauliflower faux taters, Hungarian hot peppers in everything.",
  "id" : 314884799636594688,
  "created_at" : "2013-03-21 23:42:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 81, 91 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314879814848892928",
  "text" : "Mulan is currently being viewed at the Quaranto household. Appropriate choice by @aquaranto for netflixing tonight.",
  "id" : 314879814848892928,
  "created_at" : "2013-03-21 23:22:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia West",
      "screen_name" : "juliamae",
      "indices" : [ 0, 9 ],
      "id_str" : "6354852",
      "id" : 6354852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314871452614676480",
  "geo" : { },
  "id_str" : "314872976090750976",
  "in_reply_to_user_id" : 6354852,
  "text" : "@juliamae they are the worst",
  "id" : 314872976090750976,
  "in_reply_to_status_id" : 314871452614676480,
  "created_at" : "2013-03-21 22:55:42 +0000",
  "in_reply_to_screen_name" : "juliamae",
  "in_reply_to_user_id_str" : "6354852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/314864327939223552\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/GQ9MqTvTaw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF6fcCOCcAE1K-M.png",
      "id_str" : "314864327943417857",
      "id" : 314864327943417857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF6fcCOCcAE1K-M.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/GQ9MqTvTaw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314864327939223552",
  "text" : "Bro do you even fish? http:\/\/t.co\/GQ9MqTvTaw",
  "id" : 314864327939223552,
  "created_at" : "2013-03-21 22:21:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314857977335136256",
  "geo" : { },
  "id_str" : "314861606599262208",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren worth it.",
  "id" : 314861606599262208,
  "in_reply_to_status_id" : 314857977335136256,
  "created_at" : "2013-03-21 22:10:31 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314857204392026112",
  "geo" : { },
  "id_str" : "314857766541987840",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren holy crap you\u2019re on twitter",
  "id" : 314857766541987840,
  "in_reply_to_status_id" : 314857204392026112,
  "created_at" : "2013-03-21 21:55:15 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314850161505497088",
  "text" : "Anyone else remember \"Hardcore forking action\" ?",
  "id" : 314850161505497088,
  "created_at" : "2013-03-21 21:25:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 3, 10 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Wyq3CBVFLj",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/2f6ae3a4412564bcfbc904b911ba3c20\/tumblr_mk0pxwjhth1r3kmkso3_r1_1280.gif",
      "display_url" : "25.media.tumblr.com\/2f6ae3a4412564\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314826514917097473",
  "text" : "RT @nb3004: Flat UI design. http:\/\/t.co\/Wyq3CBVFLj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/Wyq3CBVFLj",
        "expanded_url" : "http:\/\/25.media.tumblr.com\/2f6ae3a4412564bcfbc904b911ba3c20\/tumblr_mk0pxwjhth1r3kmkso3_r1_1280.gif",
        "display_url" : "25.media.tumblr.com\/2f6ae3a4412564\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314823598139400192",
    "text" : "Flat UI design. http:\/\/t.co\/Wyq3CBVFLj",
    "id" : 314823598139400192,
    "created_at" : "2013-03-21 19:39:29 +0000",
    "user" : {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "protected" : false,
      "id_str" : "5452072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477084296000585728\/PVswHXyq_normal.jpeg",
      "id" : 5452072,
      "verified" : false
    }
  },
  "id" : 314826514917097473,
  "created_at" : "2013-03-21 19:51:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 3, 16 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314811500151861249",
  "text" : "RT @Horse_ebooks: Everything happens so much",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218439593240956928",
    "text" : "Everything happens so much",
    "id" : 218439593240956928,
    "created_at" : "2012-06-28 20:23:52 +0000",
    "user" : {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "protected" : false,
      "id_str" : "174958347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096005346\/1_normal.jpg",
      "id" : 174958347,
      "verified" : false
    }
  },
  "id" : 314811500151861249,
  "created_at" : "2013-03-21 18:51:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Q5gTRpPqbB",
      "expanded_url" : "http:\/\/www.itworld.com\/mobile-wireless\/349221\/do-headlines-pose-questions-usually-negate-themselves",
      "display_url" : "itworld.com\/mobile-wireles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314798246956523520",
  "text" : "Big ups to @kevinpurdy for calling out terrible tech headlines that are questions: http:\/\/t.co\/Q5gTRpPqbB",
  "id" : 314798246956523520,
  "created_at" : "2013-03-21 17:58:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/bQmTTZiWeP",
      "expanded_url" : "http:\/\/www.itworld.com\/mobile-wireless\/349221\/do-headlines-pose-questions-usually-negate-themselves",
      "display_url" : "itworld.com\/mobile-wireles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314798090219573248",
  "text" : "RT @kevinpurdy: Do tech headlines that post questions usually negate themselves? http:\/\/t.co\/bQmTTZiWeP Oh, yes, they do. Yes they certa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/bQmTTZiWeP",
        "expanded_url" : "http:\/\/www.itworld.com\/mobile-wireless\/349221\/do-headlines-pose-questions-usually-negate-themselves",
        "display_url" : "itworld.com\/mobile-wireles\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314797939006521344",
    "text" : "Do tech headlines that post questions usually negate themselves? http:\/\/t.co\/bQmTTZiWeP Oh, yes, they do. Yes they certainly do.",
    "id" : 314797939006521344,
    "created_at" : "2013-03-21 17:57:31 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 314798090219573248,
  "created_at" : "2013-03-21 17:58:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314791442499391488",
  "text" : "RT @coworkbuffalo: OH (earlier this week): \"Quiche is just an egg pizza.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314789889969381376",
    "text" : "OH (earlier this week): \"Quiche is just an egg pizza.\"",
    "id" : 314789889969381376,
    "created_at" : "2013-03-21 17:25:32 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 314791442499391488,
  "created_at" : "2013-03-21 17:31:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314782666106994690",
  "geo" : { },
  "id_str" : "314782894889517057",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox gabriel iglesias?",
  "id" : 314782894889517057,
  "in_reply_to_status_id" : 314782666106994690,
  "created_at" : "2013-03-21 16:57:45 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314761526093414400",
  "geo" : { },
  "id_str" : "314762917285339137",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden You need a link to the site on there!",
  "id" : 314762917285339137,
  "in_reply_to_status_id" : 314761526093414400,
  "created_at" : "2013-03-21 15:38:22 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/dRKEfcK7oP",
      "expanded_url" : "http:\/\/isitdnsimple.com\/rubygems.org",
      "display_url" : "isitdnsimple.com\/rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "314762809143599104",
  "text" : "Is http:\/\/t.co\/33aYAp8SaM resolved by DNSimple? http:\/\/t.co\/dRKEfcK7oP",
  "id" : 314762809143599104,
  "created_at" : "2013-03-21 15:37:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314754984443006976",
  "text" : "Looks like the account is already suspended though. What a terrible thing to go through :(",
  "id" : 314754984443006976,
  "created_at" : "2013-03-21 15:06:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Safety",
      "screen_name" : "safety",
      "indices" : [ 34, 41 ],
      "id_str" : "95731075",
      "id" : 95731075
    }, {
      "name" : "Adria Richards",
      "screen_name" : "adriarichards",
      "indices" : [ 88, 102 ],
      "id_str" : "14268164",
      "id" : 14268164
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 107, 120 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314754819380359168",
  "text" : "Just got a bullshit response from @safety about reporting one of the accounts harassing @adriarichards via @steveklabnik. What garbage.",
  "id" : 314754819380359168,
  "created_at" : "2013-03-21 15:06:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314753819726708736",
  "geo" : { },
  "id_str" : "314754202125615104",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Did you apply yet!?",
  "id" : 314754202125615104,
  "in_reply_to_status_id" : 314753819726708736,
  "created_at" : "2013-03-21 15:03:44 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314748902169522179",
  "geo" : { },
  "id_str" : "314750443181965312",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango Twitter is bad for this. Email? nick at 37signals.",
  "id" : 314750443181965312,
  "in_reply_to_status_id" : 314748902169522179,
  "created_at" : "2013-03-21 14:48:48 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314748370503729153",
  "geo" : { },
  "id_str" : "314748735076839425",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad strange...doesn't sound normal. definitely shouldnt be getting signed out :\/",
  "id" : 314748735076839425,
  "in_reply_to_status_id" : 314748370503729153,
  "created_at" : "2013-03-21 14:42:00 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314496302115328000",
  "geo" : { },
  "id_str" : "314748434034868224",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango there's a lot of differing opinions and solutions for this...short answer is probably :)",
  "id" : 314748434034868224,
  "in_reply_to_status_id" : 314496302115328000,
  "created_at" : "2013-03-21 14:40:49 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314543688812474369",
  "geo" : { },
  "id_str" : "314748316120395778",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad are you signing out of the web side?",
  "id" : 314748316120395778,
  "in_reply_to_status_id" : 314543688812474369,
  "created_at" : "2013-03-21 14:40:20 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/314742568657227776\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/jpXXlyyR72",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF4wstjCEAI7ILF.jpg",
      "id_str" : "314742568661422082",
      "id" : 314742568661422082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF4wstjCEAI7ILF.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/jpXXlyyR72"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314742568657227776",
  "text" : "Sunny but terribly windy day to Cowork! http:\/\/t.co\/jpXXlyyR72",
  "id" : 314742568657227776,
  "created_at" : "2013-03-21 14:17:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314721142550179842",
  "geo" : { },
  "id_str" : "314723285298458624",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss definitely!",
  "id" : 314723285298458624,
  "in_reply_to_status_id" : 314721142550179842,
  "created_at" : "2013-03-21 13:00:53 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Meeker",
      "screen_name" : "CuriousCurmudge",
      "indices" : [ 0, 16 ],
      "id_str" : "87356793",
      "id" : 87356793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314582085279051776",
  "geo" : { },
  "id_str" : "314582751292575745",
  "in_reply_to_user_id" : 87356793,
  "text" : "@CuriousCurmudge geez. well i hope it keeps helping :)",
  "id" : 314582751292575745,
  "in_reply_to_status_id" : 314582085279051776,
  "created_at" : "2013-03-21 03:42:27 +0000",
  "in_reply_to_screen_name" : "CuriousCurmudge",
  "in_reply_to_user_id_str" : "87356793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Meeker",
      "screen_name" : "CuriousCurmudge",
      "indices" : [ 0, 16 ],
      "id_str" : "87356793",
      "id" : 87356793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314577383560732672",
  "geo" : { },
  "id_str" : "314579724154327040",
  "in_reply_to_user_id" : 87356793,
  "text" : "@CuriousCurmudge curious to hear how it helps with RSI...or why!",
  "id" : 314579724154327040,
  "in_reply_to_status_id" : 314577383560732672,
  "created_at" : "2013-03-21 03:30:25 +0000",
  "in_reply_to_screen_name" : "CuriousCurmudge",
  "in_reply_to_user_id_str" : "87356793",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314579458218684416",
  "geo" : { },
  "id_str" : "314579635037941763",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich after walking out of his railsconf session I don't think I can take anything he says seriously",
  "id" : 314579635037941763,
  "in_reply_to_status_id" : 314579458218684416,
  "created_at" : "2013-03-21 03:30:04 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 7, 19 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314579295941046272",
  "geo" : { },
  "id_str" : "314579512111271938",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @jamesgolick Totally. Down over 10 lbs already, but I've read this is typical of males starting on keto.",
  "id" : 314579512111271938,
  "in_reply_to_status_id" : 314579295941046272,
  "created_at" : "2013-03-21 03:29:34 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brad huber",
      "screen_name" : "daybreaker",
      "indices" : [ 0, 11 ],
      "id_str" : "1956161",
      "id" : 1956161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314575436329938944",
  "geo" : { },
  "id_str" : "314579208930209792",
  "in_reply_to_user_id" : 1956161,
  "text" : "@daybreaker agreed! All the scotch\/bacon\/meat!",
  "id" : 314579208930209792,
  "in_reply_to_status_id" : 314575436329938944,
  "created_at" : "2013-03-21 03:28:22 +0000",
  "in_reply_to_screen_name" : "daybreaker",
  "in_reply_to_user_id_str" : "1956161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314577335573680128",
  "geo" : { },
  "id_str" : "314579079141662720",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick losing weight is the only goal. needed a reset. never really been on a strict diet or had a fitness routine.",
  "id" : 314579079141662720,
  "in_reply_to_status_id" : 314577335573680128,
  "created_at" : "2013-03-21 03:27:51 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314574039563771904",
  "geo" : { },
  "id_str" : "314574424772845568",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx I used to be very spiky\u2026when it would get close to meals I would just go berserk. Just doesn\u2019t happen now.",
  "id" : 314574424772845568,
  "in_reply_to_status_id" : 314574039563771904,
  "created_at" : "2013-03-21 03:09:22 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314574039563771904",
  "geo" : { },
  "id_str" : "314574218736041984",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx yes. Been on keto for the past month. What\u2019s it\u2019s done for my energy level is amazing.",
  "id" : 314574218736041984,
  "in_reply_to_status_id" : 314574039563771904,
  "created_at" : "2013-03-21 03:08:32 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314573911490695171",
  "text" : "Over one month without a beer. Don\u2019t remember this happening since I turned 21. Haven\u2019t given up scotch or whiskey though!",
  "id" : 314573911490695171,
  "created_at" : "2013-03-21 03:07:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314551181194182656",
  "text" : "Today is one day I'm exceptionally glad that I'm not reading Hacker News.",
  "id" : 314551181194182656,
  "created_at" : "2013-03-21 01:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314491763169579009",
  "geo" : { },
  "id_str" : "314495166901792769",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango I think only admins can. You can turn off email for a project.",
  "id" : 314495166901792769,
  "in_reply_to_status_id" : 314491763169579009,
  "created_at" : "2013-03-20 21:54:25 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314482049622892544",
  "text" : "OH \"Google Keep: Cause the glasses and cars aint working yet\"",
  "id" : 314482049622892544,
  "created_at" : "2013-03-20 21:02:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/HlJGqnfeMx",
      "expanded_url" : "http:\/\/imgur.com\/jBt5MzD",
      "display_url" : "imgur.com\/jBt5MzD"
    } ]
  },
  "geo" : { },
  "id_str" : "314476168223014912",
  "text" : "The only obvious choice to replace Alex Trebek: http:\/\/t.co\/HlJGqnfeMx YES! YES YES!",
  "id" : 314476168223014912,
  "created_at" : "2013-03-20 20:38:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Evans",
      "screen_name" : "deadprogram",
      "indices" : [ 3, 15 ],
      "id_str" : "9885222",
      "id" : 9885222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RfSmJRXbiS",
      "expanded_url" : "http:\/\/bit.ly\/ZdoCkC",
      "display_url" : "bit.ly\/ZdoCkC"
    } ]
  },
  "geo" : { },
  "id_str" : "314459121053212672",
  "text" : "RT @deadprogram: Today is a huge milestone for humanity: Voyager 1 has left the solar system http:\/\/t.co\/RfSmJRXbiS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/RfSmJRXbiS",
        "expanded_url" : "http:\/\/bit.ly\/ZdoCkC",
        "display_url" : "bit.ly\/ZdoCkC"
      } ]
    },
    "geo" : { },
    "id_str" : "314457113529307136",
    "text" : "Today is a huge milestone for humanity: Voyager 1 has left the solar system http:\/\/t.co\/RfSmJRXbiS",
    "id" : 314457113529307136,
    "created_at" : "2013-03-20 19:23:12 +0000",
    "user" : {
      "name" : "Ron Evans",
      "screen_name" : "deadprogram",
      "protected" : false,
      "id_str" : "9885222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502653952\/roneye_normal.jpg",
      "id" : 9885222,
      "verified" : false
    }
  },
  "id" : 314459121053212672,
  "created_at" : "2013-03-20 19:31:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 11, 21 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "CCNY, Inc.",
      "screen_name" : "ComConnectNY",
      "indices" : [ 61, 74 ],
      "id_str" : "41811164",
      "id" : 41811164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/b6COGmOhxL",
      "expanded_url" : "http:\/\/www.comconnectionsny.org\/blog\/2013\/03\/20\/ccny-and-37signals-collaborate-to-save-kittens\/",
      "display_url" : "comconnectionsny.org\/blog\/2013\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314457853693935616",
  "text" : "Some local @37signals Buffalove: http:\/\/t.co\/b6COGmOhxL (via @ComConnectNY)",
  "id" : 314457853693935616,
  "created_at" : "2013-03-20 19:26:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CCNY, Inc.",
      "screen_name" : "ComConnectNY",
      "indices" : [ 3, 16 ],
      "id_str" : "41811164",
      "id" : 41811164
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 42, 52 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/H3M2lZdSPN",
      "expanded_url" : "http:\/\/ow.ly\/jg7W9",
      "display_url" : "ow.ly\/jg7W9"
    } ]
  },
  "geo" : { },
  "id_str" : "314457666619572226",
  "text" : "RT @ComConnectNY: CCNY wants to shout out @37signals for their awesome customer service!!! http:\/\/t.co\/H3M2lZdSPN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 24, 34 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/H3M2lZdSPN",
        "expanded_url" : "http:\/\/ow.ly\/jg7W9",
        "display_url" : "ow.ly\/jg7W9"
      } ]
    },
    "geo" : { },
    "id_str" : "314455004352241664",
    "text" : "CCNY wants to shout out @37signals for their awesome customer service!!! http:\/\/t.co\/H3M2lZdSPN",
    "id" : 314455004352241664,
    "created_at" : "2013-03-20 19:14:49 +0000",
    "user" : {
      "name" : "CCNY, Inc.",
      "screen_name" : "ComConnectNY",
      "protected" : false,
      "id_str" : "41811164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527431666545860609\/Lr3nPunn_normal.jpeg",
      "id" : 41811164,
      "verified" : false
    }
  },
  "id" : 314457666619572226,
  "created_at" : "2013-03-20 19:25:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erie.rb",
      "screen_name" : "erierb",
      "indices" : [ 0, 7 ],
      "id_str" : "776151728",
      "id" : 776151728
    }, {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 8, 19 ],
      "id_str" : "14693115",
      "id" : 14693115
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 120, 130 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314435309800681472",
  "geo" : { },
  "id_str" : "314435717189206016",
  "in_reply_to_user_id" : 776151728,
  "text" : "@erierb @rayonrails No reason not to be...as the spouse of an Erie native and a resident Buffalonian you should be! \/cc @aquaranto",
  "id" : 314435717189206016,
  "in_reply_to_status_id" : 314435309800681472,
  "created_at" : "2013-03-20 17:58:11 +0000",
  "in_reply_to_screen_name" : "erierb",
  "in_reply_to_user_id_str" : "776151728",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 0, 11 ],
      "id_str" : "14693115",
      "id" : 14693115
    }, {
      "name" : "Erie.rb",
      "screen_name" : "erierb",
      "indices" : [ 12, 19 ],
      "id_str" : "776151728",
      "id" : 776151728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/O9Cs4uzz9B",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "314426768645824514",
  "geo" : { },
  "id_str" : "314435007508783105",
  "in_reply_to_user_id" : 14693115,
  "text" : "@rayonrails @erierb Awesome! Why aren't you guys on http:\/\/t.co\/O9Cs4uzz9B ?",
  "id" : 314435007508783105,
  "in_reply_to_status_id" : 314426768645824514,
  "created_at" : "2013-03-20 17:55:22 +0000",
  "in_reply_to_screen_name" : "rayonrails",
  "in_reply_to_user_id_str" : "14693115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Andreas",
      "screen_name" : "cscotta",
      "indices" : [ 3, 11 ],
      "id_str" : "815031",
      "id" : 815031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/BR2O7CU336",
      "expanded_url" : "http:\/\/www.thebolditalic.com\/michelletea\/stories\/2931-i-was-paid-to-eat-snacks",
      "display_url" : "thebolditalic.com\/michelletea\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314432785903398912",
  "text" : "RT @cscotta: \u201CIt included a real live goat observing the tech workers with its spooky goat eyes.\u201D http:\/\/t.co\/BR2O7CU336",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/BR2O7CU336",
        "expanded_url" : "http:\/\/www.thebolditalic.com\/michelletea\/stories\/2931-i-was-paid-to-eat-snacks",
        "display_url" : "thebolditalic.com\/michelletea\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314425655393669120",
    "text" : "\u201CIt included a real live goat observing the tech workers with its spooky goat eyes.\u201D http:\/\/t.co\/BR2O7CU336",
    "id" : 314425655393669120,
    "created_at" : "2013-03-20 17:18:12 +0000",
    "user" : {
      "name" : "C. Scott Andreas",
      "screen_name" : "cscotta",
      "protected" : false,
      "id_str" : "815031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541828000640024576\/3VjOyfIc_normal.jpeg",
      "id" : 815031,
      "verified" : false
    }
  },
  "id" : 314432785903398912,
  "created_at" : "2013-03-20 17:46:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314410520927141888",
  "geo" : { },
  "id_str" : "314411974324801537",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV this music. holy shit.",
  "id" : 314411974324801537,
  "in_reply_to_status_id" : 314410520927141888,
  "created_at" : "2013-03-20 16:23:50 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 3, 16 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nQ8gwwcM9l",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=n5Gn8jt55LQ",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314411138626490368",
  "text" : "RT @ChrisSmithAV: Slow-Mo Infomercial is Fucking Terrifying and Hilarious http:\/\/t.co\/nQ8gwwcM9l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/nQ8gwwcM9l",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=n5Gn8jt55LQ",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314410520927141888",
    "text" : "Slow-Mo Infomercial is Fucking Terrifying and Hilarious http:\/\/t.co\/nQ8gwwcM9l",
    "id" : 314410520927141888,
    "created_at" : "2013-03-20 16:18:04 +0000",
    "user" : {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "protected" : true,
      "id_str" : "5911122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563454542260359168\/QWS_s6Pd_normal.png",
      "id" : 5911122,
      "verified" : false
    }
  },
  "id" : 314411138626490368,
  "created_at" : "2013-03-20 16:20:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP LeBreton",
      "screen_name" : "vectorpoem",
      "indices" : [ 3, 14 ],
      "id_str" : "393460809",
      "id" : 393460809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314387335053721600",
  "text" : "RT @vectorpoem: Actual ninja misreads job posting, infiltrates SF web startup, slaughters 27 brogrammers, leaves after failing to locate ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313418943870169088",
    "text" : "Actual ninja misreads job posting, infiltrates SF web startup, slaughters 27 brogrammers, leaves after failing to locate World Class Ruby.",
    "id" : 313418943870169088,
    "created_at" : "2013-03-17 22:37:53 +0000",
    "user" : {
      "name" : "JP LeBreton",
      "screen_name" : "vectorpoem",
      "protected" : false,
      "id_str" : "393460809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528202461568200705\/r3PTbS9R_normal.jpeg",
      "id" : 393460809,
      "verified" : false
    }
  },
  "id" : 314387335053721600,
  "created_at" : "2013-03-20 14:45:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "indices" : [ 3, 10 ],
      "id_str" : "6328872",
      "id" : 6328872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/eF7f9FZaov",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/03\/18\/student-suspended-for-pop-tart-gun_n_2903500.html?ncid=edlinkusaolp00000003",
      "display_url" : "huffingtonpost.com\/2013\/03\/18\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314378608770691072",
  "text" : "RT @Hates_: \"Student Suspended For Pop-Tart Gun\" http:\/\/t.co\/eF7f9FZaov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/eF7f9FZaov",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/03\/18\/student-suspended-for-pop-tart-gun_n_2903500.html?ncid=edlinkusaolp00000003",
        "display_url" : "huffingtonpost.com\/2013\/03\/18\/stu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314378067835502594",
    "text" : "\"Student Suspended For Pop-Tart Gun\" http:\/\/t.co\/eF7f9FZaov",
    "id" : 314378067835502594,
    "created_at" : "2013-03-20 14:09:06 +0000",
    "user" : {
      "name" : "Richard Hart",
      "screen_name" : "Hates_",
      "protected" : false,
      "id_str" : "6328872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556786979686215681\/hZq54rPB_normal.jpeg",
      "id" : 6328872,
      "verified" : false
    }
  },
  "id" : 314378608770691072,
  "created_at" : "2013-03-20 14:11:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 71, 79 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/GVAqFSm5DP",
      "expanded_url" : "https:\/\/github.com\/search?l=&q=jekyll+--server&ref=advsearch&type=Code",
      "display_url" : "github.com\/search?l=&q=je\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314184302386638848",
  "geo" : { },
  "id_str" : "314194642948210690",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr \"We've found 11,289 code results\" - https:\/\/t.co\/GVAqFSm5DP \/cc @mojombo",
  "id" : 314194642948210690,
  "in_reply_to_status_id" : 314184302386638848,
  "created_at" : "2013-03-20 02:00:14 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314184302386638848",
  "geo" : { },
  "id_str" : "314189732210950145",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr do a quick github search and I\u2019m sure there will be many examples of the old workflows",
  "id" : 314189732210950145,
  "in_reply_to_status_id" : 314184302386638848,
  "created_at" : "2013-03-20 01:40:44 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314184302386638848",
  "geo" : { },
  "id_str" : "314189479642542080",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr hm, ok. Maybe it should print out what to use if someone runs with the legacy arguments",
  "id" : 314189479642542080,
  "in_reply_to_status_id" : 314184302386638848,
  "created_at" : "2013-03-20 01:39:43 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 3, 12 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 55, 61 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314189275811962881",
  "text" : "RT @sabiddle: Nice turnout at openhack. I think I blew @qrush 's mind with !$:t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 41, 47 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314183999880826881",
    "text" : "Nice turnout at openhack. I think I blew @qrush 's mind with !$:t",
    "id" : 314183999880826881,
    "created_at" : "2013-03-20 01:17:57 +0000",
    "user" : {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "protected" : false,
      "id_str" : "20531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2696016475\/32aa0b0b3249511f0e106601d87bab01_normal.png",
      "id" : 20531902,
      "verified" : false
    }
  },
  "id" : 314189275811962881,
  "created_at" : "2013-03-20 01:38:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314154944183816192",
  "geo" : { },
  "id_str" : "314184096031047680",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr just tried --server and it didn't work. not sure how to proceed. sucks that the old commands aren't supported",
  "id" : 314184096031047680,
  "in_reply_to_status_id" : 314154944183816192,
  "created_at" : "2013-03-20 01:18:20 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 13, 20 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314142310969520129",
  "geo" : { },
  "id_str" : "314142827611299840",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @jayroh Woot!",
  "id" : 314142827611299840,
  "in_reply_to_status_id" : 314142310969520129,
  "created_at" : "2013-03-19 22:34:21 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alberto grespan",
      "screen_name" : "albertogg",
      "indices" : [ 0, 10 ],
      "id_str" : "57244212",
      "id" : 57244212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314118813824208897",
  "geo" : { },
  "id_str" : "314120902201712640",
  "in_reply_to_user_id" : 57244212,
  "text" : "@albertogg I don't have a preference, I've just used it in a few other jekyll sites and it works fine.",
  "id" : 314120902201712640,
  "in_reply_to_status_id" : 314118813824208897,
  "created_at" : "2013-03-19 21:07:13 +0000",
  "in_reply_to_screen_name" : "albertogg",
  "in_reply_to_user_id_str" : "57244212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314108935869186048",
  "geo" : { },
  "id_str" : "314109583419379712",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle hm, doesn't seem to work in zsh :(",
  "id" : 314109583419379712,
  "in_reply_to_status_id" : 314108935869186048,
  "created_at" : "2013-03-19 20:22:15 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 49, 63 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 91, 100 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314108649452756992",
  "text" : "Visibility is under a block right now outside of @coworkbuffalo. If you're driving down to @OpenHack tonight please be careful!",
  "id" : 314108649452756992,
  "created_at" : "2013-03-19 20:18:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 10, 22 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314072093278994432",
  "geo" : { },
  "id_str" : "314072838422269953",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett @bcardarella \u0CA0_\u0CA0",
  "id" : 314072838422269953,
  "in_reply_to_status_id" : 314072093278994432,
  "created_at" : "2013-03-19 17:56:14 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 3, 15 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314063078771785730",
  "text" : "RT @alanstevens: Vim is more like a martial art than an editor. You practice, learn from masters and eventually level up. For the rest o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314061693615472640",
    "text" : "Vim is more like a martial art than an editor. You practice, learn from masters and eventually level up. For the rest of your life.",
    "id" : 314061693615472640,
    "created_at" : "2013-03-19 17:11:57 +0000",
    "user" : {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "protected" : false,
      "id_str" : "9700652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571783104387530753\/1gEyur2X_normal.jpeg",
      "id" : 9700652,
      "verified" : false
    }
  },
  "id" : 314063078771785730,
  "created_at" : "2013-03-19 17:17:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Alex Howells",
      "screen_name" : "nixgeek",
      "indices" : [ 13, 21 ],
      "id_str" : "37211927",
      "id" : 37211927
    }, {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 22, 30 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 31, 38 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 62, 69 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314059831302582273",
  "geo" : { },
  "id_str" : "314060294668316673",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @nixgeek @kdaigle @soffes awesome. it does - now @soffes can push a gem with any number that isnt taken.",
  "id" : 314060294668316673,
  "in_reply_to_status_id" : 314059831302582273,
  "created_at" : "2013-03-19 17:06:23 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 13, 20 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314057867927896064",
  "geo" : { },
  "id_str" : "314057997523492864",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @soffes that's usually what we do anyway. we rarely (as in, has only ever happened once) will forcibly give away a gem",
  "id" : 314057997523492864,
  "in_reply_to_status_id" : 314057867927896064,
  "created_at" : "2013-03-19 16:57:16 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314038645424283648",
  "geo" : { },
  "id_str" : "314048947817680896",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes don\u2019t mean to be a bummer with this but help on the support side is rare. Also it feels like more of a job than a volunteer project",
  "id" : 314048947817680896,
  "in_reply_to_status_id" : 314038645424283648,
  "created_at" : "2013-03-19 16:21:18 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314038645424283648",
  "geo" : { },
  "id_str" : "314048598163742720",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes open a help ticket and wait until I get free time to look at it (weeks usually) or choose a different name",
  "id" : 314048598163742720,
  "in_reply_to_status_id" : 314038645424283648,
  "created_at" : "2013-03-19 16:19:55 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martyn Loughran",
      "screen_name" : "mloughran",
      "indices" : [ 0, 10 ],
      "id_str" : "6869822",
      "id" : 6869822
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 11, 17 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 107, 115 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314010222685462528",
  "geo" : { },
  "id_str" : "314026593431461888",
  "in_reply_to_user_id" : 6869822,
  "text" : "@mloughran @raggi I think metadata is in RG 2.0 now...it's time to settle on a spec for links finally! \/cc @drbrain",
  "id" : 314026593431461888,
  "in_reply_to_status_id" : 314010222685462528,
  "created_at" : "2013-03-19 14:52:28 +0000",
  "in_reply_to_screen_name" : "mloughran",
  "in_reply_to_user_id_str" : "6869822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 53, 64 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Edwin",
      "screen_name" : "ehmorris",
      "indices" : [ 71, 80 ],
      "id_str" : "109443936",
      "id" : 109443936
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 93, 102 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2OfhRRBpwJ",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/03\/18\/new-blog-design.html",
      "display_url" : "blog.rubygems.org\/2013\/03\/18\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314005970638475264",
  "text" : "Ought to be repeated for the morning: Huge thanks to @thoughtbot &amp; @ehmorris for the new @RubyGems blog design! http:\/\/t.co\/2OfhRRBpwJ",
  "id" : 314005970638475264,
  "created_at" : "2013-03-19 13:30:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Gbx6rtDd00",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "314005696880463873",
  "text" : "Why does http:\/\/t.co\/Gbx6rtDd00 blink on every keyboard shortcut? :(",
  "id" : 314005696880463873,
  "created_at" : "2013-03-19 13:29:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313940561038020609",
  "geo" : { },
  "id_str" : "313991270907383808",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister ok. I am pretty slammed, one reason I made the trello board was to get everything out of my head. Maybe can look tomorrow.",
  "id" : 313991270907383808,
  "in_reply_to_status_id" : 313940561038020609,
  "created_at" : "2013-03-19 12:32:07 +0000",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313868853295845377",
  "geo" : { },
  "id_str" : "313869202182258688",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded even the clock hand is a face. this is terrifying",
  "id" : 313869202182258688,
  "in_reply_to_status_id" : 313868853295845377,
  "created_at" : "2013-03-19 04:27:03 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurish Sharma",
      "screen_name" : "gaurish",
      "indices" : [ 0, 8 ],
      "id_str" : "14684796",
      "id" : 14684796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313867930007908352",
  "geo" : { },
  "id_str" : "313868728469159936",
  "in_reply_to_user_id" : 14684796,
  "text" : "@gaurish there's issues lists for both projects. if you haven't made a gem, do that first.",
  "id" : 313868728469159936,
  "in_reply_to_status_id" : 313867930007908352,
  "created_at" : "2013-03-19 04:25:10 +0000",
  "in_reply_to_screen_name" : "gaurish",
  "in_reply_to_user_id_str" : "14684796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/313867989546049537\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/q3QB6tCWjB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFsVRgfCIAABAIb.png",
      "id_str" : "313867989554438144",
      "id" : 313867989554438144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFsVRgfCIAABAIb.png",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 979
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 979
      } ],
      "display_url" : "pic.twitter.com\/q3QB6tCWjB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313866910167080961",
  "geo" : { },
  "id_str" : "313867989546049537",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded what did I do to deserve this http:\/\/t.co\/q3QB6tCWjB",
  "id" : 313867989546049537,
  "in_reply_to_status_id" : 313866910167080961,
  "created_at" : "2013-03-19 04:22:14 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Moran",
      "screen_name" : "ChadMoran",
      "indices" : [ 0, 10 ],
      "id_str" : "16367850",
      "id" : 16367850
    }, {
      "name" : "Edwin",
      "screen_name" : "ehmorris",
      "indices" : [ 37, 46 ],
      "id_str" : "109443936",
      "id" : 109443936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313857867289595904",
  "geo" : { },
  "id_str" : "313858183854710786",
  "in_reply_to_user_id" : 16367850,
  "text" : "@ChadMoran huh, didnt know that. \/cc @ehmorris",
  "id" : 313858183854710786,
  "in_reply_to_status_id" : 313857867289595904,
  "created_at" : "2013-03-19 03:43:16 +0000",
  "in_reply_to_screen_name" : "ChadMoran",
  "in_reply_to_user_id_str" : "16367850",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 19, 30 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Edwin",
      "screen_name" : "ehmorris",
      "indices" : [ 35, 44 ],
      "id_str" : "109443936",
      "id" : 109443936
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 46, 55 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/2OfhRRBpwJ",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2013\/03\/18\/new-blog-design.html",
      "display_url" : "blog.rubygems.org\/2013\/03\/18\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313853602319966208",
  "text" : "Shipped! Thanks to @thoughtbot and @ehmorris, @rubygems has a new blog design! http:\/\/t.co\/2OfhRRBpwJ",
  "id" : 313853602319966208,
  "created_at" : "2013-03-19 03:25:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313833929683656704",
  "geo" : { },
  "id_str" : "313834089562124288",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I constantly forget about hub, but I have it installed :\/",
  "id" : 313834089562124288,
  "in_reply_to_status_id" : 313833929683656704,
  "created_at" : "2013-03-19 02:07:32 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 7, 14 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313833566532427777",
  "text" : "I wish @github had \"git remote add [user] [url]\" as a copy-able thingy on each repo.",
  "id" : 313833566532427777,
  "created_at" : "2013-03-19 02:05:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 10, 20 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313833086620147715",
  "geo" : { },
  "id_str" : "313833237225041920",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen @ngauthier I'm biased, but Stardock has a history of being non-scumbags ;)",
  "id" : 313833237225041920,
  "in_reply_to_status_id" : 313833086620147715,
  "created_at" : "2013-03-19 02:04:09 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/iJ34cHJGnt",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/rbenv\/",
      "display_url" : "github.com\/sstephenson\/rb\u2026"
    }, {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/fcP8gfFVg0",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/ruby-build",
      "display_url" : "github.com\/sstephenson\/ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "313832018557403137",
  "geo" : { },
  "id_str" : "313832993997352960",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango https:\/\/t.co\/iJ34cHJGnt https:\/\/t.co\/fcP8gfFVg0",
  "id" : 313832993997352960,
  "in_reply_to_status_id" : 313832018557403137,
  "created_at" : "2013-03-19 02:03:11 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313819353504169985",
  "geo" : { },
  "id_str" : "313830942617763840",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango no idea. I\u2019ve used rbenv and ruby-install to much success lately",
  "id" : 313830942617763840,
  "in_reply_to_status_id" : 313819353504169985,
  "created_at" : "2013-03-19 01:55:02 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 9, 20 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313809790000316416",
  "geo" : { },
  "id_str" : "313810315705995264",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain @joshsusser ah yes. Derp!",
  "id" : 313810315705995264,
  "in_reply_to_status_id" : 313809790000316416,
  "created_at" : "2013-03-19 00:33:04 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313806872325009410",
  "geo" : { },
  "id_str" : "313807088000323584",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser how would it detect that? a .gemspec?",
  "id" : 313807088000323584,
  "in_reply_to_status_id" : 313806872325009410,
  "created_at" : "2013-03-19 00:20:14 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313784522258935809",
  "geo" : { },
  "id_str" : "313806830969176064",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald I don't see why not. Apply!",
  "id" : 313806830969176064,
  "in_reply_to_status_id" : 313784522258935809,
  "created_at" : "2013-03-19 00:19:13 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/UBFF4BMWE2",
      "expanded_url" : "http:\/\/flic.kr\/p\/e4g8gz",
      "display_url" : "flic.kr\/p\/e4g8gz"
    } ]
  },
  "geo" : { },
  "id_str" : "313804810619088896",
  "text" : "Snowy night at the Barkyard. http:\/\/t.co\/UBFF4BMWE2",
  "id" : 313804810619088896,
  "created_at" : "2013-03-19 00:11:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 30, 41 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/p1Kotgxp6K",
      "expanded_url" : "http:\/\/jobs.37signals.com\/jobs\/12628",
      "display_url" : "jobs.37signals.com\/jobs\/12628"
    } ]
  },
  "geo" : { },
  "id_str" : "313801959733882882",
  "text" : "Spent today working on OSS, a @RubyMotion app, and upgrading our 19 apps and the world's oldest Rails app. Want in? http:\/\/t.co\/p1Kotgxp6K",
  "id" : 313801959733882882,
  "created_at" : "2013-03-18 23:59:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313799880562860032",
  "geo" : { },
  "id_str" : "313800753846300672",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting it's one thing to say this, it's another to actually do it and ship things others use.",
  "id" : 313800753846300672,
  "in_reply_to_status_id" : 313799880562860032,
  "created_at" : "2013-03-18 23:55:04 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 9, 15 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313796919786893313",
  "geo" : { },
  "id_str" : "313798468273573888",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo @parkr seriously. A+++++ WOULD MERGE AGAIN",
  "id" : 313798468273573888,
  "in_reply_to_status_id" : 313796919786893313,
  "created_at" : "2013-03-18 23:45:59 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 3, 11 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 27, 33 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313798388124643329",
  "text" : "RT @mojombo: Huge props to @parkr for pushing all the recent Jekyll changes forward. We're working closely together to keep Jekyll cutti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parker",
        "screen_name" : "parkr",
        "indices" : [ 14, 20 ],
        "id_str" : "1928021",
        "id" : 1928021
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313796919786893313",
    "text" : "Huge props to @parkr for pushing all the recent Jekyll changes forward. We're working closely together to keep Jekyll cutting edge.",
    "id" : 313796919786893313,
    "created_at" : "2013-03-18 23:39:50 +0000",
    "user" : {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "protected" : false,
      "id_str" : "5502392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276311659\/9a5ac16a84dc44337c3e09186273ada9_normal.png",
      "id" : 5502392,
      "verified" : false
    }
  },
  "id" : 313798388124643329,
  "created_at" : "2013-03-18 23:45:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 3, 11 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "jekyll",
      "screen_name" : "jekyllrb",
      "indices" : [ 60, 69 ],
      "id_str" : "1143789606",
      "id" : 1143789606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313798198466580480",
  "text" : "RT @mojombo: For future Jekyll updates, make sure to follow @jekyllrb. All new releases will be tweeted from there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jekyll",
        "screen_name" : "jekyllrb",
        "indices" : [ 47, 56 ],
        "id_str" : "1143789606",
        "id" : 1143789606
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313797110443175936",
    "text" : "For future Jekyll updates, make sure to follow @jekyllrb. All new releases will be tweeted from there.",
    "id" : 313797110443175936,
    "created_at" : "2013-03-18 23:40:35 +0000",
    "user" : {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "protected" : false,
      "id_str" : "5502392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276311659\/9a5ac16a84dc44337c3e09186273ada9_normal.png",
      "id" : 5502392,
      "verified" : false
    }
  },
  "id" : 313798198466580480,
  "created_at" : "2013-03-18 23:44:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 34, 44 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/eYCiYXr3VH",
      "expanded_url" : "http:\/\/quaran.to\/signal",
      "display_url" : "quaran.to\/signal"
    } ]
  },
  "geo" : { },
  "id_str" : "313795294921887744",
  "text" : "If you\u2019re looking to apply to the @37signals programmer spot, here\u2019s the site I made to introduce myself: http:\/\/t.co\/eYCiYXr3VH",
  "id" : 313795294921887744,
  "created_at" : "2013-03-18 23:33:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 47, 57 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 62, 68 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 139, 140 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Bk5nJaTU5i",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3049-we-welcome-nick-quaranto-to-37signals",
      "display_url" : "37signals.com\/svn\/posts\/3049\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313787349110771713",
  "text" : "RT @dhh: Last time we hired a Rails programmer @37signals was @qrush 16 months ago: http:\/\/t.co\/Bk5nJaTU5i. At this pace, watch out @git ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 38, 48 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 53, 59 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 123, 130 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Bk5nJaTU5i",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3049-we-welcome-nick-quaranto-to-37signals",
        "display_url" : "37signals.com\/svn\/posts\/3049\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "313784974618808321",
    "text" : "Last time we hired a Rails programmer @37signals was @qrush 16 months ago: http:\/\/t.co\/Bk5nJaTU5i. At this pace, watch out @github! ;)",
    "id" : 313784974618808321,
    "created_at" : "2013-03-18 22:52:22 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 313787349110771713,
  "created_at" : "2013-03-18 23:01:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VgRC5c8Lte",
      "expanded_url" : "http:\/\/jobs.37signals.com\/jobs\/12628",
      "display_url" : "jobs.37signals.com\/jobs\/12628"
    } ]
  },
  "geo" : { },
  "id_str" : "313787330827784193",
  "text" : "RT @dhh: Want to be the tenth programmer at 37signals? We have a rare opening on the team: http:\/\/t.co\/VgRC5c8Lte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/VgRC5c8Lte",
        "expanded_url" : "http:\/\/jobs.37signals.com\/jobs\/12628",
        "display_url" : "jobs.37signals.com\/jobs\/12628"
      } ]
    },
    "geo" : { },
    "id_str" : "313784012344795138",
    "text" : "Want to be the tenth programmer at 37signals? We have a rare opening on the team: http:\/\/t.co\/VgRC5c8Lte",
    "id" : 313784012344795138,
    "created_at" : "2013-03-18 22:48:33 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 313787330827784193,
  "created_at" : "2013-03-18 23:01:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313768114481410049",
  "geo" : { },
  "id_str" : "313768772215390208",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls Seriously. Going to see how it works out this week. I want a better way of keeping logs and IMs across devices, I think this is it.",
  "id" : 313768772215390208,
  "in_reply_to_status_id" : 313768114481410049,
  "created_at" : "2013-03-18 21:47:59 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/fQ5wCNhuii",
      "expanded_url" : "http:\/\/trillian.im",
      "display_url" : "trillian.im"
    } ]
  },
  "geo" : { },
  "id_str" : "313763014706884609",
  "text" : "Trying out http:\/\/t.co\/fQ5wCNhuii again after *years* of not using it. OSX and iOS clients are both solid. Really impressed.",
  "id" : 313763014706884609,
  "created_at" : "2013-03-18 21:25:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313717036364754944",
  "text" : "UPGRADDDYYEE",
  "id" : 313717036364754944,
  "created_at" : "2013-03-18 18:22:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Clay Shafer",
      "screen_name" : "littleidea",
      "indices" : [ 0, 11 ],
      "id_str" : "14079705",
      "id" : 14079705
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 12, 23 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313706914808750080",
  "geo" : { },
  "id_str" : "313707326777466880",
  "in_reply_to_user_id" : 14079705,
  "text" : "@littleidea @benjaminws wtf?",
  "id" : 313707326777466880,
  "in_reply_to_status_id" : 313706914808750080,
  "created_at" : "2013-03-18 17:43:49 +0000",
  "in_reply_to_screen_name" : "littleidea",
  "in_reply_to_user_id_str" : "14079705",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313680210992185345",
  "text" : "OH \"It was a hard-knocked life on a Linux desktop\"",
  "id" : 313680210992185345,
  "created_at" : "2013-03-18 15:56:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313475568693805056",
  "geo" : { },
  "id_str" : "313478982152638464",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene the trello board is mostly to map out where things stand internally\u2026ML still for ideas, etc",
  "id" : 313478982152638464,
  "in_reply_to_status_id" : 313475568693805056,
  "created_at" : "2013-03-18 02:36:28 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313464258719514625",
  "text" : "Delaware Ave is a shitshow thanks to St. Paddy's Day. Heaps of garbage in every parking lot. Just terrible.",
  "id" : 313464258719514625,
  "created_at" : "2013-03-18 01:37:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 3, 10 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313332045663330305",
  "text" : "RT @ziromr: project idea: rubymotion themes. provide images + UIApperance combinations as gems, ready to be dropped into an existing project",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313204754471862272",
    "text" : "project idea: rubymotion themes. provide images + UIApperance combinations as gems, ready to be dropped into an existing project",
    "id" : 313204754471862272,
    "created_at" : "2013-03-17 08:26:47 +0000",
    "user" : {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "protected" : false,
      "id_str" : "9689352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536898874883833857\/05bedTnJ_normal.png",
      "id" : 9689352,
      "verified" : false
    }
  },
  "id" : 313332045663330305,
  "created_at" : "2013-03-17 16:52:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Petrie",
      "screen_name" : "geopet",
      "indices" : [ 0, 7 ],
      "id_str" : "14604055",
      "id" : 14604055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313284078541606912",
  "geo" : { },
  "id_str" : "313320239771303936",
  "in_reply_to_user_id" : 14604055,
  "text" : "@geopet thanks! Glad it\u2019s catching on, especially for small towns.",
  "id" : 313320239771303936,
  "in_reply_to_status_id" : 313284078541606912,
  "created_at" : "2013-03-17 16:05:41 +0000",
  "in_reply_to_screen_name" : "geopet",
  "in_reply_to_user_id_str" : "14604055",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313168638226075648",
  "geo" : { },
  "id_str" : "313168969475448833",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod it\u2019s a lot of fun but pretty damn hard. Definitely have failed at most chapters, even the first.",
  "id" : 313168969475448833,
  "in_reply_to_status_id" : 313168638226075648,
  "created_at" : "2013-03-17 06:04:35 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Petrie",
      "screen_name" : "geopet",
      "indices" : [ 0, 7 ],
      "id_str" : "14604055",
      "id" : 14604055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312963860229419009",
  "geo" : { },
  "id_str" : "313166908151189504",
  "in_reply_to_user_id" : 14604055,
  "text" : "@geopet +1, it\u2019s not really meant for a bar or as a drinkup\u2026but beer is totally acceptable :)",
  "id" : 313166908151189504,
  "in_reply_to_status_id" : 312963860229419009,
  "created_at" : "2013-03-17 05:56:23 +0000",
  "in_reply_to_screen_name" : "geopet",
  "in_reply_to_user_id_str" : "14604055",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313166356159815680",
  "text" : "Mice &amp; Mystics, Carcassone, Race for the Galaxy, Smallworld, King of Tokyo, Castle Panic all saw action at the Q house tonight. Good night!",
  "id" : 313166356159815680,
  "created_at" : "2013-03-17 05:54:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313127481978781699",
  "text" : "OH \u201CI wasn\u2019t that drunk\u201D \u201CYou sang karaoke by yourself for an hour\u201D",
  "id" : 313127481978781699,
  "created_at" : "2013-03-17 03:19:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/esp7s3D3nc",
      "expanded_url" : "http:\/\/mobile.peacebridge.com",
      "display_url" : "mobile.peacebridge.com"
    } ]
  },
  "in_reply_to_status_id_str" : "313027481336700928",
  "geo" : { },
  "id_str" : "313032188234956801",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael dude, http:\/\/t.co\/esp7s3D3nc",
  "id" : 313032188234956801,
  "in_reply_to_status_id" : 313027481336700928,
  "created_at" : "2013-03-16 21:01:04 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 3, 15 ],
      "id_str" : "6927562",
      "id" : 6927562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313031900853858304",
  "text" : "RT @thomasfuchs: Contributed to an open source project this month yet?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313029922182533121",
    "text" : "Contributed to an open source project this month yet?",
    "id" : 313029922182533121,
    "created_at" : "2013-03-16 20:52:03 +0000",
    "user" : {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "protected" : false,
      "id_str" : "6927562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528509543119343616\/bDhQei1L_normal.jpeg",
      "id" : 6927562,
      "verified" : false
    }
  },
  "id" : 313031900853858304,
  "created_at" : "2013-03-16 20:59:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313030474979229696",
  "text" : "Shout out to the dude in an Isuzu Trooper who put eagle stickers with a an American flag over the eye and FREEDOM ISN\u2019T FREE on the side",
  "id" : 313030474979229696,
  "created_at" : "2013-03-16 20:54:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313017951718629376",
  "geo" : { },
  "id_str" : "313021749564420097",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr welcome to old code. Most code is :)",
  "id" : 313021749564420097,
  "in_reply_to_status_id" : 313017951718629376,
  "created_at" : "2013-03-16 20:19:35 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 0, 11 ],
      "id_str" : "17386551",
      "id" : 17386551
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 18, 29 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312993211796824064",
  "geo" : { },
  "id_str" : "313000321880317952",
  "in_reply_to_user_id" : 17386551,
  "text" : "@natekontny I bet @kevinpurdy would love to!",
  "id" : 313000321880317952,
  "in_reply_to_status_id" : 312993211796824064,
  "created_at" : "2013-03-16 18:54:26 +0000",
  "in_reply_to_screen_name" : "natekontny",
  "in_reply_to_user_id_str" : "17386551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/DXRETnlFwA",
      "expanded_url" : "http:\/\/railsinstaller.org",
      "display_url" : "railsinstaller.org"
    } ]
  },
  "in_reply_to_status_id_str" : "312697309332905984",
  "geo" : { },
  "id_str" : "312704328823627777",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape Try out http:\/\/t.co\/DXRETnlFwA",
  "id" : 312704328823627777,
  "in_reply_to_status_id" : 312697309332905984,
  "created_at" : "2013-03-15 23:18:16 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312697309332905984",
  "geo" : { },
  "id_str" : "312704240478982147",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape 1.9.3",
  "id" : 312704240478982147,
  "in_reply_to_status_id" : 312697309332905984,
  "created_at" : "2013-03-15 23:17:55 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PUiLRUDCRN",
      "expanded_url" : "http:\/\/overapi.com\/",
      "display_url" : "overapi.com"
    } ]
  },
  "geo" : { },
  "id_str" : "312658560058269696",
  "text" : "OVER API HERE. HAVE I GOT A CHEAT SHEET FOR YOU! http:\/\/t.co\/PUiLRUDCRN",
  "id" : 312658560058269696,
  "created_at" : "2013-03-15 20:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BusA92GGjN",
      "expanded_url" : "http:\/\/www.census.gov\/population\/cencounts\/ny190090.txt",
      "display_url" : "census.gov\/population\/cen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312656522587041793",
  "text" : "I need to play around with census data at some point. Lots of fun stuff to slam into graphs: http:\/\/t.co\/BusA92GGjN",
  "id" : 312656522587041793,
  "created_at" : "2013-03-15 20:08:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 0, 14 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 65, 75 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312655572187103232",
  "geo" : { },
  "id_str" : "312656135637327873",
  "in_reply_to_user_id" : 45490102,
  "text" : "@markpoloncarz I'm going to take that as a sign of good luck for @aquaranto and myself! Proud to live in Buffalo.",
  "id" : 312656135637327873,
  "in_reply_to_status_id" : 312655572187103232,
  "created_at" : "2013-03-15 20:06:46 +0000",
  "in_reply_to_screen_name" : "markpoloncarz",
  "in_reply_to_user_id_str" : "45490102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 3, 17 ],
      "id_str" : "186154646",
      "id" : 186154646
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Cmdr_Hadfield\/status\/312627390268469248\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3pmsXgnu1u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFas9IBCcAAg_Xx.jpg",
      "id_str" : "312627390272663552",
      "id" : 312627390272663552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFas9IBCcAAg_Xx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3pmsXgnu1u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312628326751682560",
  "text" : "RT @Cmdr_Hadfield: Erie on the left, Ontario on the right, Niagara Falls in the middle. I love this perspective shot. http:\/\/t.co\/3pmsXgnu1u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cmdr_Hadfield\/status\/312627390268469248\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/3pmsXgnu1u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFas9IBCcAAg_Xx.jpg",
        "id_str" : "312627390272663552",
        "id" : 312627390272663552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFas9IBCcAAg_Xx.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3pmsXgnu1u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312627390268469248",
    "text" : "Erie on the left, Ontario on the right, Niagara Falls in the middle. I love this perspective shot. http:\/\/t.co\/3pmsXgnu1u",
    "id" : 312627390268469248,
    "created_at" : "2013-03-15 18:12:33 +0000",
    "user" : {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "protected" : false,
      "id_str" : "186154646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541256255679909889\/cmEdkkD4_normal.jpeg",
      "id" : 186154646,
      "verified" : true
    }
  },
  "id" : 312628326751682560,
  "created_at" : "2013-03-15 18:16:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 54, 68 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312618164229902336",
  "text" : "Shout out to the guy blasting Phish in the club below @coworkbuffalo. Much improved over recent audio choices.",
  "id" : 312618164229902336,
  "created_at" : "2013-03-15 17:35:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312588861819719680",
  "geo" : { },
  "id_str" : "312601941706424320",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape woot.",
  "id" : 312601941706424320,
  "in_reply_to_status_id" : 312588861819719680,
  "created_at" : "2013-03-15 16:31:25 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/y6fp7nkTzV",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/tumblr_lqzfey9tut1qexpu1o1_500.gif",
      "display_url" : "24.media.tumblr.com\/tumblr_lqzfey9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312579072591015936",
  "text" : "ActiveRecord::Base.no_touching http:\/\/t.co\/y6fp7nkTzV",
  "id" : 312579072591015936,
  "created_at" : "2013-03-15 15:00:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312577723983859713",
  "text" : "It's Ctrl-T! Duh. Thanks everyone.",
  "id" : 312577723983859713,
  "created_at" : "2013-03-15 14:55:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/QtbNsAmoZL",
      "expanded_url" : "https:\/\/github.com\/kien\/ctrlp.vim",
      "display_url" : "github.com\/kien\/ctrlp.vim"
    } ]
  },
  "geo" : { },
  "id_str" : "312576350777139200",
  "text" : "I want to open up a new tab from Ctrl-P. Anyone know how? https:\/\/t.co\/QtbNsAmoZL",
  "id" : 312576350777139200,
  "created_at" : "2013-03-15 14:49:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 3, 11 ],
      "id_str" : "19041990",
      "id" : 19041990
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312305686367305729",
  "text" : "RT @kkuchta: @qrush I didn't really mind the cube.  I minded the sort of company of which cubes are a byproduct.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "312303472903081984",
    "geo" : { },
    "id_str" : "312305328156991488",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I didn't really mind the cube.  I minded the sort of company of which cubes are a byproduct.",
    "id" : 312305328156991488,
    "in_reply_to_status_id" : 312303472903081984,
    "created_at" : "2013-03-14 20:52:47 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "protected" : false,
      "id_str" : "19041990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1638281947\/KevSuit_normal.jpeg",
      "id" : 19041990,
      "verified" : false
    }
  },
  "id" : 312305686367305729,
  "created_at" : "2013-03-14 20:54:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 3, 10 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312305668394737665",
  "text" : "RT @jmazzi: @qrush happened at my old job. After about a month we took them down without asking. Nobody felt like putting them back up s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "312304196194009089",
    "geo" : { },
    "id_str" : "312304699942531072",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush happened at my old job. After about a month we took them down without asking. Nobody felt like putting them back up so we won.",
    "id" : 312304699942531072,
    "in_reply_to_status_id" : 312304196194009089,
    "created_at" : "2013-03-14 20:50:17 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "protected" : false,
      "id_str" : "15395778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413712456620322816\/Ki1bebJu_normal.jpeg",
      "id" : 15395778,
      "verified" : false
    }
  },
  "id" : 312305668394737665,
  "created_at" : "2013-03-14 20:54:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312303960885186560",
  "geo" : { },
  "id_str" : "312304196194009089",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic Yes, actually.",
  "id" : 312304196194009089,
  "in_reply_to_status_id" : 312303960885186560,
  "created_at" : "2013-03-14 20:48:17 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312303472903081984",
  "text" : "Has anyone else quit a job because they've been forced to work in a cube?",
  "id" : 312303472903081984,
  "created_at" : "2013-03-14 20:45:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312302198879031298",
  "geo" : { },
  "id_str" : "312302888225484801",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney i produce only local, organic, artisanal pixels",
  "id" : 312302888225484801,
  "in_reply_to_status_id" : 312302198879031298,
  "created_at" : "2013-03-14 20:43:05 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312234210435932160",
  "text" : "RT @nexxylove: \u201CDO YOU EVEN REALIZE HOW MANY IMPORTANT BLOGS I KEEP UP WITH?!?\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312125004861038592",
    "text" : "\u201CDO YOU EVEN REALIZE HOW MANY IMPORTANT BLOGS I KEEP UP WITH?!?\u201D",
    "id" : 312125004861038592,
    "created_at" : "2013-03-14 08:56:14 +0000",
    "user" : {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571613144133296128\/-EmxBenM_normal.jpeg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 312234210435932160,
  "created_at" : "2013-03-14 16:10:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312234184909398017",
  "text" : "RT @nexxylove: \u201CThey can have a robot kill me without a trial? That\u2019s kinda shitty, I guess\u2026\u201D\n\n\u201CThey want to shut down Google Reader? I\u2019 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312124778586710017",
    "text" : "\u201CThey can have a robot kill me without a trial? That\u2019s kinda shitty, I guess\u2026\u201D\n\n\u201CThey want to shut down Google Reader? I\u2019M FUCKING PISSED!!\u201D",
    "id" : 312124778586710017,
    "created_at" : "2013-03-14 08:55:20 +0000",
    "user" : {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571613144133296128\/-EmxBenM_normal.jpeg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 312234184909398017,
  "created_at" : "2013-03-14 16:10:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/KMv0pbUfVD",
      "expanded_url" : "http:\/\/www.examiner.com\/images\/blog\/wysiwyg\/image\/pzone.jpg",
      "display_url" : "examiner.com\/images\/blog\/wy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312231631412924416",
  "text" : "Current status: p zone http:\/\/t.co\/KMv0pbUfVD",
  "id" : 312231631412924416,
  "created_at" : "2013-03-14 15:59:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Perel",
      "screen_name" : "obox",
      "indices" : [ 0, 5 ],
      "id_str" : "14770247",
      "id" : 14770247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312099166081933312",
  "geo" : { },
  "id_str" : "312206808968208384",
  "in_reply_to_user_id" : 14770247,
  "text" : "@obox sorry. we have some bugs squashed and almost ready to submit to apple. could try reinstalling for now :\/",
  "id" : 312206808968208384,
  "in_reply_to_status_id" : 312099166081933312,
  "created_at" : "2013-03-14 14:21:18 +0000",
  "in_reply_to_screen_name" : "obox",
  "in_reply_to_user_id_str" : "14770247",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/jMTzRXPDwB",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Jorge_Bergoglio#Views",
      "display_url" : "en.wikipedia.org\/wiki\/Jorge_Ber\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311919804418256896",
  "text" : "Glad the new Pope is a Jesuit, but not happy about: http:\/\/t.co\/jMTzRXPDwB",
  "id" : 311919804418256896,
  "created_at" : "2013-03-13 19:20:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311896977627549696",
  "geo" : { },
  "id_str" : "311897222503596033",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff s\/working from home\/living in a warm climate\/",
  "id" : 311897222503596033,
  "in_reply_to_status_id" : 311896977627549696,
  "created_at" : "2013-03-13 17:51:07 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 7, 15 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/LUDgBzlq29",
      "expanded_url" : "https:\/\/buy.louisck.net\/tour-dates",
      "display_url" : "buy.louisck.net\/tour-dates"
    } ]
  },
  "geo" : { },
  "id_str" : "311878498019065856",
  "text" : "Yes!!! @louisck is coming to Buffalo. Get some: https:\/\/t.co\/LUDgBzlq29",
  "id" : 311878498019065856,
  "created_at" : "2013-03-13 16:36:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311853469092962307",
  "text" : "When do WWDC tickets usually go on sale? Really want to go this year.",
  "id" : 311853469092962307,
  "created_at" : "2013-03-13 14:57:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Stallone \uE10D",
      "screen_name" : "frankstallone",
      "indices" : [ 0, 14 ],
      "id_str" : "14955456",
      "id" : 14955456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311828401721864192",
  "geo" : { },
  "id_str" : "311836241857507328",
  "in_reply_to_user_id" : 14955456,
  "text" : "@frankstallone we\u2019re open to submit a build to fix this in the next few days. Sorry :( reinstalling might help.",
  "id" : 311836241857507328,
  "in_reply_to_status_id" : 311828401721864192,
  "created_at" : "2013-03-13 13:48:48 +0000",
  "in_reply_to_screen_name" : "frankstallone",
  "in_reply_to_user_id_str" : "14955456",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Buda",
      "screen_name" : "bradleybuda",
      "indices" : [ 0, 12 ],
      "id_str" : "3466521",
      "id" : 3466521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311708774186487808",
  "geo" : { },
  "id_str" : "311813762741063680",
  "in_reply_to_user_id" : 3466521,
  "text" : "@bradleybuda you mean signed gems?",
  "id" : 311813762741063680,
  "in_reply_to_status_id" : 311708774186487808,
  "created_at" : "2013-03-13 12:19:28 +0000",
  "in_reply_to_screen_name" : "bradleybuda",
  "in_reply_to_user_id_str" : "3466521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311691092833751040",
  "geo" : { },
  "id_str" : "311693050298638337",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas I liked the side by side aspect of it before. feels more like a blog post in the new style.",
  "id" : 311693050298638337,
  "in_reply_to_status_id" : 311691092833751040,
  "created_at" : "2013-03-13 04:19:48 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311691092833751040",
  "geo" : { },
  "id_str" : "311692912821948416",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas ah ha. i'm fine with classic. :)",
  "id" : 311692912821948416,
  "in_reply_to_status_id" : 311691092833751040,
  "created_at" : "2013-03-13 04:19:16 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 0, 10 ],
      "id_str" : "123323498",
      "id" : 123323498
    }, {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 11, 20 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/9Cgp282WOM",
      "expanded_url" : "http:\/\/quaran.to\/m\/",
      "display_url" : "quaran.to\/m\/"
    } ]
  },
  "in_reply_to_status_id_str" : "311688536841670657",
  "geo" : { },
  "id_str" : "311690014276849664",
  "in_reply_to_user_id" : 123323498,
  "text" : "@jashkenas @rtomayko I think the html changed a bit too. just flipped the CSS and no bueno http:\/\/t.co\/9Cgp282WOM",
  "id" : 311690014276849664,
  "in_reply_to_status_id" : 311688536841670657,
  "created_at" : "2013-03-13 04:07:44 +0000",
  "in_reply_to_screen_name" : "jashkenas",
  "in_reply_to_user_id_str" : "123323498",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 3, 12 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "Jeremy Ashkenas",
      "screen_name" : "jashkenas",
      "indices" : [ 65, 75 ],
      "id_str" : "123323498",
      "id" : 123323498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311687619622866945",
  "text" : "Yo @rtomayko rocco's docco css is le broke. Tried to update from @jashkenas' latest styles and it's not the same :(",
  "id" : 311687619622866945,
  "created_at" : "2013-03-13 03:58:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/XCOjV1vhvC",
      "expanded_url" : "https:\/\/trello.com\/card\/mirroring\/513f9634a7ed906115000755\/19",
      "display_url" : "trello.com\/card\/mirroring\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311646286048813057",
  "geo" : { },
  "id_str" : "311647759209992192",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr https:\/\/t.co\/XCOjV1vhvC",
  "id" : 311647759209992192,
  "in_reply_to_status_id" : 311646286048813057,
  "created_at" : "2013-03-13 01:19:50 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311646286048813057",
  "geo" : { },
  "id_str" : "311647250600304641",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr Let's kick it off.",
  "id" : 311647250600304641,
  "in_reply_to_status_id" : 311646286048813057,
  "created_at" : "2013-03-13 01:17:49 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack SF",
      "screen_name" : "OpenHackSF",
      "indices" : [ 17, 28 ],
      "id_str" : "1263158528",
      "id" : 1263158528
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 39, 48 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ddfmf06xMt",
      "expanded_url" : "http:\/\/openhack.github.com\/san_francisco\/",
      "display_url" : "openhack.github.com\/san_francisco\/"
    } ]
  },
  "geo" : { },
  "id_str" : "311646336514670593",
  "text" : "A big welcome to @OpenHackSF, the 50th @OpenHack city! http:\/\/t.co\/ddfmf06xMt",
  "id" : 311646336514670593,
  "created_at" : "2013-03-13 01:14:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/hAaxyFryyu",
      "expanded_url" : "https:\/\/trello.com\/board\/rubygems-org\/513f9634a7ed906115000755",
      "display_url" : "trello.com\/board\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311645730081218561",
  "text" : "Writing down everything going on with http:\/\/t.co\/33aYAp8SaM that's in my head is overwhelming. Lots going on: https:\/\/t.co\/hAaxyFryyu",
  "id" : 311645730081218561,
  "created_at" : "2013-03-13 01:11:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Meridth",
      "screen_name" : "jmeridth",
      "indices" : [ 0, 9 ],
      "id_str" : "107301595",
      "id" : 107301595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311644717894995968",
  "geo" : { },
  "id_str" : "311645539529797632",
  "in_reply_to_user_id" : 107301595,
  "text" : "@jmeridth Woot!",
  "id" : 311645539529797632,
  "in_reply_to_status_id" : 311644717894995968,
  "created_at" : "2013-03-13 01:11:01 +0000",
  "in_reply_to_screen_name" : "jmeridth",
  "in_reply_to_user_id_str" : "107301595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trello",
      "screen_name" : "trello",
      "indices" : [ 14, 21 ],
      "id_str" : "360831528",
      "id" : 360831528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311638781969186817",
  "text" : "It sucks that @trello doesn't let public members add cards. :(",
  "id" : 311638781969186817,
  "created_at" : "2013-03-13 00:44:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Trello",
      "screen_name" : "trello",
      "indices" : [ 17, 24 ],
      "id_str" : "360831528",
      "id" : 360831528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311609141120606208",
  "geo" : { },
  "id_str" : "311619009323876353",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 @trello I think I added you.",
  "id" : 311619009323876353,
  "in_reply_to_status_id" : 311609141120606208,
  "created_at" : "2013-03-12 23:25:36 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 9, 19 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311594873973243907",
  "geo" : { },
  "id_str" : "311614689153019905",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @aquaranto just admitted she got this same push notification for this drivel",
  "id" : 311614689153019905,
  "in_reply_to_status_id" : 311594873973243907,
  "created_at" : "2013-03-12 23:08:26 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311609141120606208",
  "geo" : { },
  "id_str" : "311614237141237760",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 good idea. Maybe I have to add you for that.",
  "id" : 311614237141237760,
  "in_reply_to_status_id" : 311609141120606208,
  "created_at" : "2013-03-12 23:06:38 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rigel St. Pierre",
      "screen_name" : "rigelstpierre",
      "indices" : [ 0, 14 ],
      "id_str" : "14143955",
      "id" : 14143955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/8oi1ZdcmvG",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311586440276480000",
  "geo" : { },
  "id_str" : "311589145619349504",
  "in_reply_to_user_id" : 14143955,
  "text" : "@rigelstpierre I asked this 4+ years ago: http:\/\/t.co\/8oi1ZdcmvG",
  "id" : 311589145619349504,
  "in_reply_to_status_id" : 311586440276480000,
  "created_at" : "2013-03-12 21:26:56 +0000",
  "in_reply_to_screen_name" : "rigelstpierre",
  "in_reply_to_user_id_str" : "14143955",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trello",
      "screen_name" : "trello",
      "indices" : [ 10, 17 ],
      "id_str" : "360831528",
      "id" : 360831528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/33aYAp8SaM",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/hAaxyFryyu",
      "expanded_url" : "https:\/\/trello.com\/board\/rubygems-org\/513f9634a7ed906115000755",
      "display_url" : "trello.com\/board\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311585633019756544",
  "text" : "Started a @trello for http:\/\/t.co\/33aYAp8SaM: https:\/\/t.co\/hAaxyFryyu Trying to be open\/transparent\/public.",
  "id" : 311585633019756544,
  "created_at" : "2013-03-12 21:12:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311577056427257856",
  "geo" : { },
  "id_str" : "311577694494146560",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn you've been dead to me for years",
  "id" : 311577694494146560,
  "in_reply_to_status_id" : 311577056427257856,
  "created_at" : "2013-03-12 20:41:25 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 38, 44 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/C1e4ik9qN2",
      "expanded_url" : "http:\/\/phish.portals.musictoday.com\/",
      "display_url" : "phish.portals.musictoday.com"
    } ]
  },
  "geo" : { },
  "id_str" : "311574366104190976",
  "text" : "Hopefully heading to Toronto for some @phish this summer!! http:\/\/t.co\/C1e4ik9qN2",
  "id" : 311574366104190976,
  "created_at" : "2013-03-12 20:28:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311476371140517888",
  "text" : "RT @rubygems_status: New gems are back! Sorry about that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311476218597892097",
    "text" : "New gems are back! Sorry about that.",
    "id" : 311476218597892097,
    "created_at" : "2013-03-12 13:58:12 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 311476371140517888,
  "created_at" : "2013-03-12 13:58:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311474053225533440",
  "text" : "RT @rubygems_status: Gems being pushes currently and from the past few hours aren\u2019t appearing in the index. Investigating why.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311473984749322241",
    "text" : "Gems being pushes currently and from the past few hours aren\u2019t appearing in the index. Investigating why.",
    "id" : 311473984749322241,
    "created_at" : "2013-03-12 13:49:19 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 311474053225533440,
  "created_at" : "2013-03-12 13:49:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 9, 20 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/zFQx0gy1TP",
      "expanded_url" : "https:\/\/github.com\/shellscape\/Brew",
      "display_url" : "github.com\/shellscape\/Brew"
    } ]
  },
  "geo" : { },
  "id_str" : "311309405402570752",
  "text" : "My buddy @shellscape continues to ship code like a boss: https:\/\/t.co\/zFQx0gy1TP",
  "id" : 311309405402570752,
  "created_at" : "2013-03-12 02:55:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/qSQ3fGHgXO",
      "expanded_url" : "http:\/\/i.imgur.com\/odPF16e.jpg",
      "display_url" : "i.imgur.com\/odPF16e.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "311308871832592384",
  "text" : "Current status: http:\/\/t.co\/qSQ3fGHgXO",
  "id" : 311308871832592384,
  "created_at" : "2013-03-12 02:53:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 3, 11 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 139, 140 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/irXDvPwUkS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-W1WSOthhrg",
      "display_url" : "youtube.com\/watch?v=-W1WSO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311307452173922304",
  "text" : "RT @whit537: Are you saying \"Git Tip\"? Consider http:\/\/t.co\/irXDvPwUkS instead. It's what non-geeks say, and can help geeks differentiat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 129, 135 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/irXDvPwUkS",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-W1WSOthhrg",
        "display_url" : "youtube.com\/watch?v=-W1WSO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "311306349680140288",
    "text" : "Are you saying \"Git Tip\"? Consider http:\/\/t.co\/irXDvPwUkS instead. It's what non-geeks say, and can help geeks differentiate. ht @qrush",
    "id" : 311306349680140288,
    "created_at" : "2013-03-12 02:43:12 +0000",
    "user" : {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "protected" : false,
      "id_str" : "34175404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560974605255319554\/CbOeWpFu_normal.jpeg",
      "id" : 34175404,
      "verified" : false
    }
  },
  "id" : 311307452173922304,
  "created_at" : "2013-03-12 02:47:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 12, 20 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311303802458365952",
  "geo" : { },
  "id_str" : "311304049175695360",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @whit537 That's why I think this should be promoted more. I definitely prefer the \"git IPP\" style.",
  "id" : 311304049175695360,
  "in_reply_to_status_id" : 311303802458365952,
  "created_at" : "2013-03-12 02:34:03 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/zifNkmQMrM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3ADu3tHanP8",
      "display_url" : "youtube.com\/watch?v=3ADu3t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311299770125799425",
  "geo" : { },
  "id_str" : "311300165023719424",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 Like this, but for gittip. http:\/\/t.co\/zifNkmQMrM",
  "id" : 311300165023719424,
  "in_reply_to_status_id" : 311299770125799425,
  "created_at" : "2013-03-12 02:18:37 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311299770125799425",
  "geo" : { },
  "id_str" : "311300111865114625",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 FWIW I have been saying \"git IPP\" not \"git tip\" ever since you said it to me. I think you should do a video\/sound byte thing",
  "id" : 311300111865114625,
  "in_reply_to_status_id" : 311299770125799425,
  "created_at" : "2013-03-12 02:18:25 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Murphey",
      "screen_name" : "rmurphey",
      "indices" : [ 0, 9 ],
      "id_str" : "6490602",
      "id" : 6490602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311292491783610368",
  "geo" : { },
  "id_str" : "311296678697267200",
  "in_reply_to_user_id" : 6490602,
  "text" : "@rmurphey wow, blown away. good luck!",
  "id" : 311296678697267200,
  "in_reply_to_status_id" : 311292491783610368,
  "created_at" : "2013-03-12 02:04:46 +0000",
  "in_reply_to_screen_name" : "rmurphey",
  "in_reply_to_user_id_str" : "6490602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 91, 97 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/GOqDoSeLN7",
      "expanded_url" : "http:\/\/jekyllrb.com",
      "display_url" : "jekyllrb.com"
    } ]
  },
  "in_reply_to_status_id_str" : "311287352104468480",
  "geo" : { },
  "id_str" : "311287730619445249",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 so good. time to get the http:\/\/t.co\/GOqDoSeLN7 new design out too... \/cc @parkr",
  "id" : 311287730619445249,
  "in_reply_to_status_id" : 311287352104468480,
  "created_at" : "2013-03-12 01:29:13 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 120, 136 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/xbSRaY3RnX",
      "expanded_url" : "http:\/\/ruby-lang.org",
      "display_url" : "ruby-lang.org"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/rup5qil7uk",
      "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org",
      "display_url" : "github.com\/ruby\/www.ruby-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311286812645666816",
  "text" : "Didn't even know this was a thing, http:\/\/t.co\/xbSRaY3RnX is going to powered by Jekyll! https:\/\/t.co\/rup5qil7uk Thanks @postmodern_mod3 !",
  "id" : 311286812645666816,
  "created_at" : "2013-03-12 01:25:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 3, 19 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Wn7xGNPl5b",
      "expanded_url" : "http:\/\/www.ruby-lang.org\/",
      "display_url" : "ruby-lang.org"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/HUu7TjaovK",
      "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org",
      "display_url" : "github.com\/ruby\/www.ruby-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311286492146319360",
  "text" : "RT @postmodern_mod3: My Jekyll port of http:\/\/t.co\/Wn7xGNPl5b has finally been accepted by Ruby VIT! https:\/\/t.co\/HUu7TjaovK Big thanks  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/Wn7xGNPl5b",
        "expanded_url" : "http:\/\/www.ruby-lang.org\/",
        "display_url" : "ruby-lang.org"
      }, {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/HUu7TjaovK",
        "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org",
        "display_url" : "github.com\/ruby\/www.ruby-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "311281687856312323",
    "text" : "My Jekyll port of http:\/\/t.co\/Wn7xGNPl5b has finally been accepted by Ruby VIT! https:\/\/t.co\/HUu7TjaovK Big thanks to Marcus Stollsteimer.",
    "id" : 311281687856312323,
    "created_at" : "2013-03-12 01:05:12 +0000",
    "user" : {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "protected" : false,
      "id_str" : "46852648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/261097869\/postmodern_normal.jpg",
      "id" : 46852648,
      "verified" : false
    }
  },
  "id" : 311286492146319360,
  "created_at" : "2013-03-12 01:24:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 28, 36 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311281687856312323",
  "geo" : { },
  "id_str" : "311286479081070592",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 Wow!!! \/cc @mojombo",
  "id" : 311286479081070592,
  "in_reply_to_status_id" : 311281687856312323,
  "created_at" : "2013-03-12 01:24:14 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/NSL33WsdmL",
      "expanded_url" : "https:\/\/github.com\/github\/github-services\/pull\/544",
      "display_url" : "github.com\/github\/github-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311179552200196096",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie hey, any chance you could merge\/ship https:\/\/t.co\/NSL33WsdmL ?",
  "id" : 311179552200196096,
  "created_at" : "2013-03-11 18:19:21 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/scdUcyj2s9",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "311123031571447809",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing lady danville: Kids - (MGMT Cover) \u266B\u266A #turntablefm http:\/\/t.co\/scdUcyj2s9",
  "id" : 311123031571447809,
  "created_at" : "2013-03-11 14:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin John Gomez",
      "screen_name" : "kevinjohngomez",
      "indices" : [ 0, 15 ],
      "id_str" : "26253666",
      "id" : 26253666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310878141352660992",
  "geo" : { },
  "id_str" : "310883081131266048",
  "in_reply_to_user_id" : 26253666,
  "text" : "@kevinjohngomez I did the latter. Learned ruby as I went along.",
  "id" : 310883081131266048,
  "in_reply_to_status_id" : 310878141352660992,
  "created_at" : "2013-03-10 22:41:17 +0000",
  "in_reply_to_screen_name" : "kevinjohngomez",
  "in_reply_to_user_id_str" : "26253666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310746051525099521",
  "geo" : { },
  "id_str" : "310750881836589056",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench brunch!!!",
  "id" : 310750881836589056,
  "in_reply_to_status_id" : 310746051525099521,
  "created_at" : "2013-03-10 13:55:58 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310574484795056128",
  "geo" : { },
  "id_str" : "310577347558518785",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 this is not my fault",
  "id" : 310577347558518785,
  "in_reply_to_status_id" : 310574484795056128,
  "created_at" : "2013-03-10 02:26:24 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310573105607233536",
  "text" : "OH \u201Ccome over here and feel this and be confused\u201D",
  "id" : 310573105607233536,
  "created_at" : "2013-03-10 02:09:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310572769760931840",
  "text" : "OH \u201Cshe got paid to laser a butthole\u201D",
  "id" : 310572769760931840,
  "created_at" : "2013-03-10 02:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310572099137859584",
  "text" : "OH \u201COur boobs are cool\u201D",
  "id" : 310572099137859584,
  "created_at" : "2013-03-10 02:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310567946227429377",
  "geo" : { },
  "id_str" : "310572044746117120",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx BAAAAAAAAAAAAAAW",
  "id" : 310572044746117120,
  "in_reply_to_status_id" : 310567946227429377,
  "created_at" : "2013-03-10 02:05:20 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310566325917474818",
  "text" : "OH \u201CI feel like I\u2019m damaging the feminist movement at this point\u201D",
  "id" : 310566325917474818,
  "created_at" : "2013-03-10 01:42:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 45, 55 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 56, 61 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310485637126037505",
  "geo" : { },
  "id_str" : "310487601108893697",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy that thread should be banned. \/cc @magnachef @popo",
  "id" : 310487601108893697,
  "in_reply_to_status_id" : 310485637126037505,
  "created_at" : "2013-03-09 20:29:47 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/29Ia1dXeei",
      "expanded_url" : "https:\/\/medium.com\/the-ingredients-2\/221d449929ef",
      "display_url" : "medium.com\/the-ingredient\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310454434696146944",
  "text" : "\"The number of individuals who know how to make a can of Coke is zero.\" https:\/\/t.co\/29Ia1dXeei",
  "id" : 310454434696146944,
  "created_at" : "2013-03-09 18:17:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310253177385648128",
  "text" : "RT @hotdogsladies: Sometimes I doubt your commitment to House Atreides.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310249517196922880",
    "text" : "Sometimes I doubt your commitment to House Atreides.",
    "id" : 310249517196922880,
    "created_at" : "2013-03-09 04:43:43 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615975268921345\/15phrwGy_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 310253177385648128,
  "created_at" : "2013-03-09 04:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310205100687753217",
  "geo" : { },
  "id_str" : "310238324587634688",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending you need to watch Fifth Element (again)",
  "id" : 310238324587634688,
  "in_reply_to_status_id" : 310205100687753217,
  "created_at" : "2013-03-09 03:59:15 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310197463220891650",
  "geo" : { },
  "id_str" : "310203477483720704",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending you are a meat popsicle",
  "id" : 310203477483720704,
  "in_reply_to_status_id" : 310197463220891650,
  "created_at" : "2013-03-09 01:40:46 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/odpDJvovWH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qIdq-Bn6trM",
      "display_url" : "youtube.com\/watch?v=qIdq-B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310141487809695744",
  "text" : "Current status: http:\/\/t.co\/odpDJvovWH",
  "id" : 310141487809695744,
  "created_at" : "2013-03-08 21:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309934285375299584",
  "geo" : { },
  "id_str" : "310054380982374400",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Ged is equally terrifying upside down.",
  "id" : 310054380982374400,
  "in_reply_to_status_id" : 309934285375299584,
  "created_at" : "2013-03-08 15:48:19 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/FbuYVATpA3",
      "expanded_url" : "http:\/\/cdn.memegenerator.net\/instances\/250x250\/30441558.jpg",
      "display_url" : "cdn.memegenerator.net\/instances\/250x\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "310045547694284804",
  "geo" : { },
  "id_str" : "310047656699367424",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh http:\/\/t.co\/FbuYVATpA3",
  "id" : 310047656699367424,
  "in_reply_to_status_id" : 310045547694284804,
  "created_at" : "2013-03-08 15:21:36 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310032231894753280",
  "geo" : { },
  "id_str" : "310032362866085889",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi not between accounts, no. Could export and then copy pasta it over. :\/",
  "id" : 310032362866085889,
  "in_reply_to_status_id" : 310032231894753280,
  "created_at" : "2013-03-08 14:20:50 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309996399125209088",
  "geo" : { },
  "id_str" : "310019844336664576",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy gonna stay at home due to meds",
  "id" : 310019844336664576,
  "in_reply_to_status_id" : 309996399125209088,
  "created_at" : "2013-03-08 13:31:05 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Roes",
      "screen_name" : "jroes",
      "indices" : [ 0, 6 ],
      "id_str" : "1431461",
      "id" : 1431461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309791453532536833",
  "geo" : { },
  "id_str" : "309792083659587585",
  "in_reply_to_user_id" : 1431461,
  "text" : "@jroes he already made my day, can\u2019t get better",
  "id" : 309792083659587585,
  "in_reply_to_status_id" : 309791453532536833,
  "created_at" : "2013-03-07 22:26:03 +0000",
  "in_reply_to_screen_name" : "jroes",
  "in_reply_to_user_id_str" : "1431461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309788223670984704",
  "text" : "Shout out to the delivery guy blasting Mike\u2019s Song out of an ancient Camry.",
  "id" : 309788223670984704,
  "created_at" : "2013-03-07 22:10:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/KmaeqvnFUr",
      "expanded_url" : "http:\/\/flic.kr\/p\/e1mgdn",
      "display_url" : "flic.kr\/p\/e1mgdn"
    } ]
  },
  "geo" : { },
  "id_str" : "309741709762379776",
  "text" : "Delaware and Bryant on a snowy March morning. http:\/\/t.co\/KmaeqvnFUr",
  "id" : 309741709762379776,
  "created_at" : "2013-03-07 19:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/YXofQcZer8",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush",
      "display_url" : "flickr.com\/photos\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "309740641137598464",
  "text" : "I miss the photos I was taking with Instagram. Haven't been taking nearly as many since. http:\/\/t.co\/YXofQcZer8",
  "id" : 309740641137598464,
  "created_at" : "2013-03-07 19:01:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "AlleyCat",
      "screen_name" : "alleycatcomics",
      "indices" : [ 10, 25 ],
      "id_str" : "195130492",
      "id" : 195130492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309724815168778240",
  "geo" : { },
  "id_str" : "309740284890202112",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner @alleycatcomics YES!",
  "id" : 309740284890202112,
  "in_reply_to_status_id" : 309724815168778240,
  "created_at" : "2013-03-07 19:00:13 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/tggKRWhbBa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=I_keWS1i3RA",
      "display_url" : "youtube.com\/watch?v=I_keWS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309736033778556928",
  "text" : "Current status: http:\/\/t.co\/tggKRWhbBa",
  "id" : 309736033778556928,
  "created_at" : "2013-03-07 18:43:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/scdUcyj2s9",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "309729864955613185",
  "text" : "Back on the train: http:\/\/t.co\/scdUcyj2s9",
  "id" : 309729864955613185,
  "created_at" : "2013-03-07 18:18:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309724943510286337",
  "geo" : { },
  "id_str" : "309725133998804993",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak Yeah, it does. A lot of stuff that just wasn't important got pushed off to make v1 ship.",
  "id" : 309725133998804993,
  "in_reply_to_status_id" : 309724943510286337,
  "created_at" : "2013-03-07 18:00:01 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309721409796571137",
  "geo" : { },
  "id_str" : "309724643105832960",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak hopefully going to release it for #inspect. I need to work on it! D:",
  "id" : 309724643105832960,
  "in_reply_to_status_id" : 309721409796571137,
  "created_at" : "2013-03-07 17:58:03 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309691875135205376",
  "geo" : { },
  "id_str" : "309692470822842368",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Added to the gem too.",
  "id" : 309692470822842368,
  "in_reply_to_status_id" : 309691875135205376,
  "created_at" : "2013-03-07 15:50:13 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309691875135205376",
  "geo" : { },
  "id_str" : "309692311179235328",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Done.",
  "id" : 309692311179235328,
  "in_reply_to_status_id" : 309691875135205376,
  "created_at" : "2013-03-07 15:49:35 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/BzIR07Z0c6",
      "expanded_url" : "http:\/\/ballmer.tumblr.com\/",
      "display_url" : "ballmer.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "309691002304724992",
  "text" : "Current status: http:\/\/t.co\/BzIR07Z0c6",
  "id" : 309691002304724992,
  "created_at" : "2013-03-07 15:44:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309685463583703042",
  "geo" : { },
  "id_str" : "309689939640082432",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes I wouldn't mind adding you as a contrib if you want to merge, etc",
  "id" : 309689939640082432,
  "in_reply_to_status_id" : 309685463583703042,
  "created_at" : "2013-03-07 15:40:10 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309685463583703042",
  "geo" : { },
  "id_str" : "309689879867060224",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes on call this week and it's been brutal...i have a RM talk to prep too :(",
  "id" : 309689879867060224,
  "in_reply_to_status_id" : 309685463583703042,
  "created_at" : "2013-03-07 15:39:55 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/scdUcyj2s9",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "309688878514708480",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Lettuce: Blast Off \u266B\u266A #turntablefm http:\/\/t.co\/scdUcyj2s9",
  "id" : 309688878514708480,
  "created_at" : "2013-03-07 15:35:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309678484538658816",
  "text" : "RT @coworkbuffalo: Quick poll: would you be interested in a class on making better coffee at home, hosted here, with guest barista\/roaster?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309667458199982081",
    "text" : "Quick poll: would you be interested in a class on making better coffee at home, hosted here, with guest barista\/roaster?",
    "id" : 309667458199982081,
    "created_at" : "2013-03-07 14:10:50 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 309678484538658816,
  "created_at" : "2013-03-07 14:54:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ayUHOgGc9k",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins",
      "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309428334801059840",
  "geo" : { },
  "id_str" : "309431874114158593",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten did you see http:\/\/t.co\/ayUHOgGc9k ?",
  "id" : 309431874114158593,
  "in_reply_to_status_id" : 309428334801059840,
  "created_at" : "2013-03-06 22:34:42 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Rosen",
      "screen_name" : "rosenboy",
      "indices" : [ 0, 9 ],
      "id_str" : "11215972",
      "id" : 11215972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309404351909216256",
  "geo" : { },
  "id_str" : "309404948611862528",
  "in_reply_to_user_id" : 11215972,
  "text" : "@rosenboy had no idea about GCUC. how did you find out?",
  "id" : 309404948611862528,
  "in_reply_to_status_id" : 309404351909216256,
  "created_at" : "2013-03-06 20:47:42 +0000",
  "in_reply_to_screen_name" : "rosenboy",
  "in_reply_to_user_id_str" : "11215972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wardell",
      "screen_name" : "draginol",
      "indices" : [ 0, 9 ],
      "id_str" : "13972382",
      "id" : 13972382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309364625751830529",
  "geo" : { },
  "id_str" : "309371942757072896",
  "in_reply_to_user_id" : 13972382,
  "text" : "@draginol still surprised that tools to support older Windows workflows is profitable. not sure if sign of the times or the platform :(",
  "id" : 309371942757072896,
  "in_reply_to_status_id" : 309364625751830529,
  "created_at" : "2013-03-06 18:36:33 +0000",
  "in_reply_to_screen_name" : "draginol",
  "in_reply_to_user_id_str" : "13972382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Azizi Khalid",
      "screen_name" : "azizikhalid",
      "indices" : [ 0, 12 ],
      "id_str" : "12148212",
      "id" : 12148212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309348751556882432",
  "geo" : { },
  "id_str" : "309349237454417922",
  "in_reply_to_user_id" : 12148212,
  "text" : "@azizikhalid Yeah, we've had a few reports of this! :( Not sure what's up yet, hoping to fix it soon.",
  "id" : 309349237454417922,
  "in_reply_to_status_id" : 309348751556882432,
  "created_at" : "2013-03-06 17:06:20 +0000",
  "in_reply_to_screen_name" : "azizikhalid",
  "in_reply_to_user_id_str" : "12148212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/a0DQOGfRpB",
      "expanded_url" : "http:\/\/www.thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309349107108040704",
  "text" : "Your weekly reminder that the Double Cuddle is $120\/hr. What's your hourly rate like? http:\/\/t.co\/a0DQOGfRpB",
  "id" : 309349107108040704,
  "created_at" : "2013-03-06 17:05:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 44, 55 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/gvqQsK7LKv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ejr9KBQzQPM",
      "display_url" : "youtube.com\/watch?v=Ejr9KB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309153861640265728",
  "text" : "Current status: http:\/\/t.co\/gvqQsK7LKv (via @samkottler)",
  "id" : 309153861640265728,
  "created_at" : "2013-03-06 04:09:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309097727864745985",
  "geo" : { },
  "id_str" : "309098075216035840",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried Yeah, this is definitely a small town movement. I need to write up something about it. Just still surprised.",
  "id" : 309098075216035840,
  "in_reply_to_status_id" : 309097727864745985,
  "created_at" : "2013-03-06 00:28:18 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 15, 24 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/JK3TqzENNm",
      "expanded_url" : "https:\/\/github.com\/OpenHack\/openhack.github.com\/issues\/104",
      "display_url" : "github.com\/OpenHack\/openh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309096489521668096",
  "text" : "Very surprised @OpenHack in SF has had no momentum. What gives? https:\/\/t.co\/JK3TqzENNm",
  "id" : 309096489521668096,
  "created_at" : "2013-03-06 00:22:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Dobson",
      "screen_name" : "EricDobson",
      "indices" : [ 0, 11 ],
      "id_str" : "77030702",
      "id" : 77030702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309013984521113601",
  "geo" : { },
  "id_str" : "309018060445077504",
  "in_reply_to_user_id" : 77030702,
  "text" : "@EricDobson Would you? :) I'm at least in a 50% white or less area.",
  "id" : 309018060445077504,
  "in_reply_to_status_id" : 309013984521113601,
  "created_at" : "2013-03-05 19:10:21 +0000",
  "in_reply_to_screen_name" : "EricDobson",
  "in_reply_to_user_id_str" : "77030702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ZPAP8bYbBO",
      "expanded_url" : "http:\/\/tweetdeck.posterous.com\/an-update-on-tweetdeck",
      "display_url" : "tweetdeck.posterous.com\/an-update-on-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309007379645726720",
  "geo" : { },
  "id_str" : "309007540379844608",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik http:\/\/t.co\/ZPAP8bYbBO",
  "id" : 309007540379844608,
  "in_reply_to_status_id" : 309007379645726720,
  "created_at" : "2013-03-05 18:28:33 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Hakes",
      "screen_name" : "ea_andrewh",
      "indices" : [ 0, 11 ],
      "id_str" : "1120897015",
      "id" : 1120897015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309005125266055168",
  "geo" : { },
  "id_str" : "309006433129746433",
  "in_reply_to_user_id" : 1120897015,
  "text" : "@ea_andrewh I'm a hopeless optimist, but I'm convinced the city is turning itself around. I don't want to live anywhere else.",
  "id" : 309006433129746433,
  "in_reply_to_status_id" : 309005125266055168,
  "created_at" : "2013-03-05 18:24:09 +0000",
  "in_reply_to_screen_name" : "ea_andrewh",
  "in_reply_to_user_id_str" : "1120897015",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 102, 112 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/dFDj5BP2yA",
      "expanded_url" : "http:\/\/basecamp.com\/extras",
      "display_url" : "basecamp.com\/extras"
    } ]
  },
  "geo" : { },
  "id_str" : "309005427302092800",
  "text" : "I'm glad @37signals treats 3rd party apps as friends, not enemies: http:\/\/t.co\/dFDj5BP2yA Sad day for @TweetDeck today.",
  "id" : 309005427302092800,
  "created_at" : "2013-03-05 18:20:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/OFzGa6O0Gf",
      "expanded_url" : "http:\/\/www.salon.com\/2011\/03\/29\/most_segregated_cities\/slide_show\/5",
      "display_url" : "salon.com\/2011\/03\/29\/mos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309001051573473280",
  "text" : "Embarrassed by this. The number 6 most segregated city, Buffalo: http:\/\/t.co\/OFzGa6O0Gf",
  "id" : 309001051573473280,
  "created_at" : "2013-03-05 18:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Jjc6DuMwU4",
      "expanded_url" : "http:\/\/www.coffitivity.com\/",
      "display_url" : "coffitivity.com"
    }, {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5hDav4GgjE",
      "expanded_url" : "http:\/\/www.rainymood.com\/",
      "display_url" : "rainymood.com"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/6lRMmzXvTC",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZPoqNeR3_UA",
      "display_url" : "youtube.com\/watch?v=ZPoqNe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308976693299785728",
  "text" : "RT @bitsweat: Coworking from a rainy cafe on the holodeck: http:\/\/t.co\/Jjc6DuMwU4 + http:\/\/t.co\/5hDav4GgjE + http:\/\/t.co\/6lRMmzXvTC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/Jjc6DuMwU4",
        "expanded_url" : "http:\/\/www.coffitivity.com\/",
        "display_url" : "coffitivity.com"
      }, {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/5hDav4GgjE",
        "expanded_url" : "http:\/\/www.rainymood.com\/",
        "display_url" : "rainymood.com"
      }, {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6lRMmzXvTC",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZPoqNeR3_UA",
        "display_url" : "youtube.com\/watch?v=ZPoqNe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308976421307576321",
    "text" : "Coworking from a rainy cafe on the holodeck: http:\/\/t.co\/Jjc6DuMwU4 + http:\/\/t.co\/5hDav4GgjE + http:\/\/t.co\/6lRMmzXvTC",
    "id" : 308976421307576321,
    "created_at" : "2013-03-05 16:24:54 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 308976693299785728,
  "created_at" : "2013-03-05 16:25:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Little",
      "screen_name" : "aalittle",
      "indices" : [ 0, 9 ],
      "id_str" : "26332027",
      "id" : 26332027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/dv3VKTepI4",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/phosphor\/id589654268",
      "display_url" : "itunes.apple.com\/us\/app\/phospho\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "308956746972528640",
  "geo" : { },
  "id_str" : "308957858588925952",
  "in_reply_to_user_id" : 26332027,
  "text" : "@aalittle https:\/\/t.co\/dv3VKTepI4",
  "id" : 308957858588925952,
  "in_reply_to_status_id" : 308956746972528640,
  "created_at" : "2013-03-05 15:11:08 +0000",
  "in_reply_to_screen_name" : "aalittle",
  "in_reply_to_user_id_str" : "26332027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/wmzadhDBDg",
      "expanded_url" : "http:\/\/37svn.com\/3457",
      "display_url" : "37svn.com\/3457"
    } ]
  },
  "geo" : { },
  "id_str" : "308949859564675072",
  "text" : "It's not a meetup: http:\/\/t.co\/wmzadhDBDg",
  "id" : 308949859564675072,
  "created_at" : "2013-03-05 14:39:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308820442729312257",
  "geo" : { },
  "id_str" : "308820610639876096",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw next time I\u2019ll buy the coffee!",
  "id" : 308820610639876096,
  "in_reply_to_status_id" : 308820442729312257,
  "created_at" : "2013-03-05 06:05:45 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gisi",
      "screen_name" : "gisikw",
      "indices" : [ 0, 7 ],
      "id_str" : "14308739",
      "id" : 14308739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308503650077130752",
  "geo" : { },
  "id_str" : "308818860658814976",
  "in_reply_to_user_id" : 14308739,
  "text" : "@gisikw blown away that rubyconf 09 turned things around\u2026I remember! Cheers man, keep rocking.",
  "id" : 308818860658814976,
  "in_reply_to_status_id" : 308503650077130752,
  "created_at" : "2013-03-05 05:58:48 +0000",
  "in_reply_to_screen_name" : "gisikw",
  "in_reply_to_user_id_str" : "14308739",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308796622375100417",
  "geo" : { },
  "id_str" : "308797002609741824",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek coaster crazy. It\u2019s Roller Coaster Tycoon, but only coasters, in a Psychonauts art style.",
  "id" : 308797002609741824,
  "in_reply_to_status_id" : 308796622375100417,
  "created_at" : "2013-03-05 04:31:57 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Little",
      "screen_name" : "aalittle",
      "indices" : [ 0, 9 ],
      "id_str" : "26332027",
      "id" : 26332027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/mLgzCQyU3J",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3438",
      "display_url" : "37signals.com\/svn\/posts\/3438"
    } ]
  },
  "in_reply_to_status_id_str" : "308682782366916608",
  "geo" : { },
  "id_str" : "308796730646863873",
  "in_reply_to_user_id" : 26332027,
  "text" : "@aalittle nice. Fair points. Did you read http:\/\/t.co\/mLgzCQyU3J ? Explains more about the split.",
  "id" : 308796730646863873,
  "in_reply_to_status_id" : 308682782366916608,
  "created_at" : "2013-03-05 04:30:52 +0000",
  "in_reply_to_screen_name" : "aalittle",
  "in_reply_to_user_id_str" : "26332027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/308796307630350336\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GyoOsyqIJi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEkQmxDCYAAFs7L.png",
      "id_str" : "308796307638738944",
      "id" : 308796307638738944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEkQmxDCYAAFs7L.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GyoOsyqIJi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308796307630350336",
  "text" : "This is the most bullshit game mechanic. Just let me fucking play your game. (I could pay to play now!) http:\/\/t.co\/GyoOsyqIJi",
  "id" : 308796307630350336,
  "created_at" : "2013-03-05 04:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick DiRienzo",
      "screen_name" : "nickdirienzo",
      "indices" : [ 0, 13 ],
      "id_str" : "101859945",
      "id" : 101859945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308771857539149824",
  "geo" : { },
  "id_str" : "308795952834162688",
  "in_reply_to_user_id" : 101859945,
  "text" : "@nickdirienzo sure. Mind emailing me?",
  "id" : 308795952834162688,
  "in_reply_to_status_id" : 308771857539149824,
  "created_at" : "2013-03-05 04:27:46 +0000",
  "in_reply_to_screen_name" : "nickdirienzo",
  "in_reply_to_user_id_str" : "101859945",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Cashin",
      "screen_name" : "scashin133",
      "indices" : [ 0, 11 ],
      "id_str" : "19324579",
      "id" : 19324579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308728260110475264",
  "geo" : { },
  "id_str" : "308739692067704834",
  "in_reply_to_user_id" : 19324579,
  "text" : "@scashin133 i don\u2019t see that. Maybe a strange extension?",
  "id" : 308739692067704834,
  "in_reply_to_status_id" : 308728260110475264,
  "created_at" : "2013-03-05 00:44:13 +0000",
  "in_reply_to_screen_name" : "scashin133",
  "in_reply_to_user_id_str" : "19324579",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 94, 103 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308721340490321921",
  "text" : "Is there a way to get multi-line markdown code blocks from GFM to show in ronn or pandoc? \/cc @rtomayko",
  "id" : 308721340490321921,
  "created_at" : "2013-03-04 23:31:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Perel",
      "screen_name" : "obox",
      "indices" : [ 0, 5 ],
      "id_str" : "14770247",
      "id" : 14770247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308665512995475457",
  "geo" : { },
  "id_str" : "308718400849453056",
  "in_reply_to_user_id" : 14770247,
  "text" : "@obox hey, this is on the latest version? I'd love to hear more about what's not working",
  "id" : 308718400849453056,
  "in_reply_to_status_id" : 308665512995475457,
  "created_at" : "2013-03-04 23:19:37 +0000",
  "in_reply_to_screen_name" : "obox",
  "in_reply_to_user_id_str" : "14770247",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/XVkKS1Beoi",
      "expanded_url" : "http:\/\/s3-ec.buzzfed.com\/static\/enhanced\/webdr02\/2013\/3\/1\/15\/enhanced-buzz-29327-1362170571-15.jpg",
      "display_url" : "s3-ec.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308713916580634624",
  "text" : "Current status: http:\/\/t.co\/XVkKS1Beoi",
  "id" : 308713916580634624,
  "created_at" : "2013-03-04 23:01:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Maciej Pasternacki",
      "screen_name" : "mpasternacki",
      "indices" : [ 9, 22 ],
      "id_str" : "18005558",
      "id" : 18005558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308614338267205632",
  "geo" : { },
  "id_str" : "308615571359019009",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @mpasternacki Thanks!",
  "id" : 308615571359019009,
  "in_reply_to_status_id" : 308614338267205632,
  "created_at" : "2013-03-04 16:31:00 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maciej Pasternacki",
      "screen_name" : "mpasternacki",
      "indices" : [ 0, 13 ],
      "id_str" : "18005558",
      "id" : 18005558
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 60, 68 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308371238726803456",
  "geo" : { },
  "id_str" : "308614188555706368",
  "in_reply_to_user_id" : 18005558,
  "text" : "@mpasternacki yikes. I\u2019m not sure who runs that mirror. \/cc @evanphx",
  "id" : 308614188555706368,
  "in_reply_to_status_id" : 308371238726803456,
  "created_at" : "2013-03-04 16:25:30 +0000",
  "in_reply_to_screen_name" : "mpasternacki",
  "in_reply_to_user_id_str" : "18005558",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Osman",
      "screen_name" : "surkatty",
      "indices" : [ 0, 9 ],
      "id_str" : "93748947",
      "id" : 93748947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308439605038956545",
  "geo" : { },
  "id_str" : "308578858578350081",
  "in_reply_to_user_id" : 93748947,
  "text" : "@surkatty thanks for the reminder. Been slow getting a Google Apps account setup.",
  "id" : 308578858578350081,
  "in_reply_to_status_id" : 308439605038956545,
  "created_at" : "2013-03-04 14:05:07 +0000",
  "in_reply_to_screen_name" : "surkatty",
  "in_reply_to_user_id_str" : "93748947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/308091927402782720\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/eDYckJ6CkF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEaP-cNCIAARYTw.jpg",
      "id_str" : "308091927406977024",
      "id" : 308091927406977024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEaP-cNCIAARYTw.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/eDYckJ6CkF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308091927402782720",
  "text" : "_______, high five bro! http:\/\/t.co\/eDYckJ6CkF",
  "id" : 308091927402782720,
  "created_at" : "2013-03-03 05:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/308025381087223808\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/3O2kjSAntb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEZTc73CIAAF-jl.jpg",
      "id_str" : "308025381091418112",
      "id" : 308025381091418112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEZTc73CIAAF-jl.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/3O2kjSAntb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308025381087223808",
  "text" : "The ultimate answer\u2026puck. http:\/\/t.co\/3O2kjSAntb",
  "id" : 308025381087223808,
  "created_at" : "2013-03-03 01:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308018306311409665",
  "geo" : { },
  "id_str" : "308018740837097472",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting yep. Not a bad drive.",
  "id" : 308018740837097472,
  "in_reply_to_status_id" : 308018306311409665,
  "created_at" : "2013-03-03 00:59:25 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/308013555976896512\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ilpuDibgKT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEZIsn5CAAAi-7A.jpg",
      "id_str" : "308013555981090816",
      "id" : 308013555981090816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEZIsn5CAAAi-7A.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ilpuDibgKT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308013555976896512",
  "text" : "CAUTION! BE AWARE OF http:\/\/t.co\/ilpuDibgKT",
  "id" : 308013555976896512,
  "created_at" : "2013-03-03 00:38:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307993286621155328",
  "geo" : { },
  "id_str" : "307999457532841984",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting do you mean Swedish meatballs?",
  "id" : 307999457532841984,
  "in_reply_to_status_id" : 307993286621155328,
  "created_at" : "2013-03-02 23:42:47 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Lewinski",
      "screen_name" : "JordanLewinski",
      "indices" : [ 0, 15 ],
      "id_str" : "34574378",
      "id" : 34574378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/swlW80669R",
      "expanded_url" : "http:\/\/basecamp.com\/help",
      "display_url" : "basecamp.com\/help"
    } ]
  },
  "in_reply_to_status_id_str" : "307962564468416512",
  "geo" : { },
  "id_str" : "307962836078960640",
  "in_reply_to_user_id" : 34574378,
  "text" : "@JordanLewinski strange. If you could open up a ticket at http:\/\/t.co\/swlW80669R we can take a deeper look!",
  "id" : 307962836078960640,
  "in_reply_to_status_id" : 307962564468416512,
  "created_at" : "2013-03-02 21:17:16 +0000",
  "in_reply_to_screen_name" : "JordanLewinski",
  "in_reply_to_user_id_str" : "34574378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307954589624315904",
  "geo" : { },
  "id_str" : "307962595174912001",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting go to IKEA.",
  "id" : 307962595174912001,
  "in_reply_to_status_id" : 307954589624315904,
  "created_at" : "2013-03-02 21:16:19 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/6HD8qh0WXm",
      "expanded_url" : "http:\/\/youtu.be\/OGR3mc3DdLE",
      "display_url" : "youtu.be\/OGR3mc3DdLE"
    } ]
  },
  "geo" : { },
  "id_str" : "307961130821775360",
  "text" : "I\u2019m glad this wasn\u2019t a thing when I was responsible for mopping up at a grocery store. http:\/\/t.co\/6HD8qh0WXm",
  "id" : 307961130821775360,
  "created_at" : "2013-03-02 21:10:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lail Brown",
      "screen_name" : "lailbrown",
      "indices" : [ 3, 13 ],
      "id_str" : "17907299",
      "id" : 17907299
    }, {
      "name" : "NextPlex",
      "screen_name" : "nplex",
      "indices" : [ 82, 88 ],
      "id_str" : "534757903",
      "id" : 534757903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/QfpzxXDlbJ",
      "expanded_url" : "http:\/\/nextplex.com\/rochester-ny\/calendar\/events\/3432-openhack-rochester",
      "display_url" : "nextplex.com\/rochester-ny\/c\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zsgsxRDS5r",
      "expanded_url" : "http:\/\/img.ly\/t0iw",
      "display_url" : "img.ly\/t0iw"
    } ]
  },
  "geo" : { },
  "id_str" : "307951378679083008",
  "text" : "RT @lailbrown: Tonight tonight - feel the raw power. \n http:\/\/t.co\/QfpzxXDlbJ via @nplex http:\/\/t.co\/zsgsxRDS5r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NextPlex",
        "screen_name" : "nplex",
        "indices" : [ 67, 73 ],
        "id_str" : "534757903",
        "id" : 534757903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/QfpzxXDlbJ",
        "expanded_url" : "http:\/\/nextplex.com\/rochester-ny\/calendar\/events\/3432-openhack-rochester",
        "display_url" : "nextplex.com\/rochester-ny\/c\u2026"
      }, {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/zsgsxRDS5r",
        "expanded_url" : "http:\/\/img.ly\/t0iw",
        "display_url" : "img.ly\/t0iw"
      } ]
    },
    "geo" : { },
    "id_str" : "306782650037841921",
    "text" : "Tonight tonight - feel the raw power. \n http:\/\/t.co\/QfpzxXDlbJ via @nplex http:\/\/t.co\/zsgsxRDS5r",
    "id" : 306782650037841921,
    "created_at" : "2013-02-27 15:07:38 +0000",
    "user" : {
      "name" : "Lail Brown",
      "screen_name" : "lailbrown",
      "protected" : false,
      "id_str" : "17907299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506926031706415104\/fE40dRhN_normal.jpeg",
      "id" : 17907299,
      "verified" : false
    }
  },
  "id" : 307951378679083008,
  "created_at" : "2013-03-02 20:31:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Lewinski",
      "screen_name" : "JordanLewinski",
      "indices" : [ 0, 15 ],
      "id_str" : "34574378",
      "id" : 34574378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307942432954257408",
  "geo" : { },
  "id_str" : "307949280646287360",
  "in_reply_to_user_id" : 34574378,
  "text" : "@JordanLewinski hey there! Is this on happening on version 1.0.2 of the app? You can check in Settings.",
  "id" : 307949280646287360,
  "in_reply_to_status_id" : 307942432954257408,
  "created_at" : "2013-03-02 20:23:24 +0000",
  "in_reply_to_screen_name" : "JordanLewinski",
  "in_reply_to_user_id_str" : "34574378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307946870901182465",
  "geo" : { },
  "id_str" : "307948485662097409",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath nope. Just burned us too.",
  "id" : 307948485662097409,
  "in_reply_to_status_id" : 307946870901182465,
  "created_at" : "2013-03-02 20:20:15 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307914454492930049",
  "geo" : { },
  "id_str" : "307918394693390338",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking basically can\u2019t hear from one ear. Plane ride was brutal.",
  "id" : 307918394693390338,
  "in_reply_to_status_id" : 307914454492930049,
  "created_at" : "2013-03-02 18:20:40 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307904801243537408",
  "text" : "Achievement unlocked: Acquire \u201Craging\u201D ear infection according to MD. \uD83D\uDE37",
  "id" : 307904801243537408,
  "created_at" : "2013-03-02 17:26:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/307717939384160256\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/GLJGafVo9D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEU71eRCEAAwtQ7.png",
      "id_str" : "307717939388354560",
      "id" : 307717939388354560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEU71eRCEAAwtQ7.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GLJGafVo9D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307717939384160256",
  "text" : "My $EDITOR is now a helmet. http:\/\/t.co\/GLJGafVo9D",
  "id" : 307717939384160256,
  "created_at" : "2013-03-02 05:04:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307697261499011072",
  "text" : "First flight I\u2019ve been on tonight where someone got on the wrong flight, didn\u2019t realize until after closing the door. At least he got out.",
  "id" : 307697261499011072,
  "created_at" : "2013-03-02 03:41:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307655413803925506",
  "geo" : { },
  "id_str" : "307664110991069184",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety we were just about to push off and someone realized they were going to the wrong destination. Now waiting to open the gate.",
  "id" : 307664110991069184,
  "in_reply_to_status_id" : 307655413803925506,
  "created_at" : "2013-03-02 01:30:14 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307655413803925506",
  "geo" : { },
  "id_str" : "307655827941105666",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety doubtful",
  "id" : 307655827941105666,
  "in_reply_to_status_id" : 307655413803925506,
  "created_at" : "2013-03-02 00:57:20 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307609599081598976",
  "geo" : { },
  "id_str" : "307648548000915456",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety delayed and 2 gate changes so far.",
  "id" : 307648548000915456,
  "in_reply_to_status_id" : 307609599081598976,
  "created_at" : "2013-03-02 00:28:24 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307609599081598976",
  "geo" : { },
  "id_str" : "307610359383080961",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety broke a 4 airport no molesting streak on Sunday. Not optimistic about today.",
  "id" : 307610359383080961,
  "in_reply_to_status_id" : 307609599081598976,
  "created_at" : "2013-03-01 21:56:39 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sudara",
      "screen_name" : "sudara",
      "indices" : [ 0, 7 ],
      "id_str" : "5907052",
      "id" : 5907052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/A2brWiVNJP",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/4676363",
      "display_url" : "gist.github.com\/qrush\/4676363"
    } ]
  },
  "in_reply_to_status_id_str" : "307509148940111873",
  "geo" : { },
  "id_str" : "307607935838728192",
  "in_reply_to_user_id" : 5907052,
  "text" : "@sudara This is from a month ago. I\u2019d love help with improving stats. https:\/\/t.co\/A2brWiVNJP",
  "id" : 307607935838728192,
  "in_reply_to_status_id" : 307509148940111873,
  "created_at" : "2013-03-01 21:47:01 +0000",
  "in_reply_to_screen_name" : "sudara",
  "in_reply_to_user_id_str" : "5907052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 69, 79 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307606681502773248",
  "text" : "ORD is a madhouse. Glad I got here early. Thanks for an awesome week @37signals !",
  "id" : 307606681502773248,
  "created_at" : "2013-03-01 21:42:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307585654026539010",
  "text" : "Finally have locked down a venue for NickelCityRubyConf. Time to make it happen!",
  "id" : 307585654026539010,
  "created_at" : "2013-03-01 20:18:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307570847290359808",
  "geo" : { },
  "id_str" : "307571316125478913",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods I'm just trying to install pandoc :(",
  "id" : 307571316125478913,
  "in_reply_to_status_id" : 307570847290359808,
  "created_at" : "2013-03-01 19:21:30 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307570305306611712",
  "text" : "Oh god, just typed in \"brew install haskell-platform\"",
  "id" : 307570305306611712,
  "created_at" : "2013-03-01 19:17:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    }, {
      "name" : "Jonathan Owens",
      "screen_name" : "intjonathan",
      "indices" : [ 12, 24 ],
      "id_str" : "62634651",
      "id" : 62634651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307539155351633921",
  "geo" : { },
  "id_str" : "307551113111015425",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic @intjonathan yes, I get that, but I don't want to click it. i use Sparrow for the GMail shortcuts :\/",
  "id" : 307551113111015425,
  "in_reply_to_status_id" : 307539155351633921,
  "created_at" : "2013-03-01 18:01:14 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307537010640424961",
  "geo" : { },
  "id_str" : "307537472861134848",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik begin; Timeout::timeout(TIMEOUT) \u007B raise TimeoutError \u007D; rescue TimeoutError =&gt; timeout; end",
  "id" : 307537472861134848,
  "in_reply_to_status_id" : 307537010640424961,
  "created_at" : "2013-03-01 17:07:01 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/bF9MetLWm4",
      "expanded_url" : "https:\/\/dnsimple.com\/r\/35d1afbfe92d46",
      "display_url" : "dnsimple.com\/r\/35d1afbfe92d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307535897207906304",
  "geo" : { },
  "id_str" : "307537056786157570",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg DNSimple! https:\/\/t.co\/bF9MetLWm4",
  "id" : 307537056786157570,
  "in_reply_to_status_id" : 307535897207906304,
  "created_at" : "2013-03-01 17:05:22 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307536685149847552",
  "geo" : { },
  "id_str" : "307536933419094017",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench FRIDAYS!",
  "id" : 307536933419094017,
  "in_reply_to_status_id" : 307536685149847552,
  "created_at" : "2013-03-01 17:04:53 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307535786583130112",
  "text" : "Is there *any* way to get Sparrow on OSX to refresh the current thread without jumping on, off the existing message?",
  "id" : 307535786583130112,
  "created_at" : "2013-03-01 17:00:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/sM9YmokPWr",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/jobs-and-economy\/2013\/02\/urban-suburban-compromise-revitalize-buffalo-neighborhood\/4809\/#",
      "display_url" : "theatlanticcities.com\/jobs-and-econo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307370869699796992",
  "text" : "\"Negative perceptions of the [Buffalo] city limits are increasingly fading away\" http:\/\/t.co\/sM9YmokPWr",
  "id" : 307370869699796992,
  "created_at" : "2013-03-01 06:05:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
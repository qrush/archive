Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/373950391949737984\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/pkD4aXuZWl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTCJ5m5IgAAlWKr.png",
      "id_str" : "373950391857479680",
      "id" : 373950391857479680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTCJ5m5IgAAlWKr.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pkD4aXuZWl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373950391949737984",
  "text" : "Siri is just trolling me now. http:\/\/t.co\/pkD4aXuZWl",
  "id" : 373950391949737984,
  "created_at" : "2013-08-31 23:28:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonnifer lopez ",
      "screen_name" : "senderblock23",
      "indices" : [ 3, 17 ],
      "id_str" : "149027072",
      "id" : 149027072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373944740569677824",
  "text" : "RT @senderblock23: My questionnaire for dogs:\n1. Do you like to get pet\n2. Who is a good boy\n3. Is it you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363391140633903104",
    "text" : "My questionnaire for dogs:\n1. Do you like to get pet\n2. Who is a good boy\n3. Is it you",
    "id" : 363391140633903104,
    "created_at" : "2013-08-02 20:09:34 +0000",
    "user" : {
      "name" : "jonnifer lopez ",
      "screen_name" : "senderblock23",
      "protected" : false,
      "id_str" : "149027072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528420483117887488\/AwXLuJNa_normal.jpeg",
      "id" : 149027072,
      "verified" : false
    }
  },
  "id" : 373944740569677824,
  "created_at" : "2013-08-31 23:05:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/QqsoLjQfna",
      "expanded_url" : "http:\/\/vimeo.com\/7577554",
      "display_url" : "vimeo.com\/7577554"
    } ]
  },
  "geo" : { },
  "id_str" : "373905840157114368",
  "text" : "Current status: http:\/\/t.co\/QqsoLjQfna",
  "id" : 373905840157114368,
  "created_at" : "2013-08-31 20:31:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373632126169530368",
  "geo" : { },
  "id_str" : "373632561622548480",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo dude!! Hope you\u2019re having fun.",
  "id" : 373632561622548480,
  "in_reply_to_status_id" : 373632126169530368,
  "created_at" : "2013-08-31 02:25:19 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373572349175422977",
  "geo" : { },
  "id_str" : "373572881235460098",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Blown away with it that week. Excited to play with it more. It's pretty small, too. Couldn't imagine lugging a full size DSLR.",
  "id" : 373572881235460098,
  "in_reply_to_status_id" : 373572349175422977,
  "created_at" : "2013-08-30 22:28:10 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/zx4JpVjcQU",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/qrush\/sets\/72157635300487787\/",
      "display_url" : "flickr.com\/photos\/qrush\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373564480463962112",
  "geo" : { },
  "id_str" : "373570228648542209",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh X100S. A week with it in SF off LensRentals convinced me. http:\/\/t.co\/zx4JpVjcQU",
  "id" : 373570228648542209,
  "in_reply_to_status_id" : 373564480463962112,
  "created_at" : "2013-08-30 22:17:37 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Soroka",
      "screen_name" : "ssoroka",
      "indices" : [ 0, 8 ],
      "id_str" : "6377052",
      "id" : 6377052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373563117189349376",
  "geo" : { },
  "id_str" : "373569338860527616",
  "in_reply_to_user_id" : 6377052,
  "text" : "@ssoroka No worries. Please pass it on...I expect a serious Canadian delegation!",
  "id" : 373569338860527616,
  "in_reply_to_status_id" : 373563117189349376,
  "created_at" : "2013-08-30 22:14:05 +0000",
  "in_reply_to_screen_name" : "ssoroka",
  "in_reply_to_user_id_str" : "6377052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 12, 27 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373557247432851456",
  "geo" : { },
  "id_str" : "373557643438067713",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan @ChrisVanPatten i can't wait until you have to use Windows or Java for some reason.",
  "id" : 373557643438067713,
  "in_reply_to_status_id" : 373557247432851456,
  "created_at" : "2013-08-30 21:27:37 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 12, 27 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373556696561360896",
  "geo" : { },
  "id_str" : "373557007740977152",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan @ChrisVanPatten pretty sure this only has to happen once...also is this some kind of CPU-strapped box?",
  "id" : 373557007740977152,
  "in_reply_to_status_id" : 373556696561360896,
  "created_at" : "2013-08-30 21:25:05 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 16, 27 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373556211599572992",
  "geo" : { },
  "id_str" : "373556459323158528",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @paddyforan :( it shouldn't take 15 minutes for jekyll to run. wtf are you using?",
  "id" : 373556459323158528,
  "in_reply_to_status_id" : 373556211599572992,
  "created_at" : "2013-08-30 21:22:54 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373554331259109376",
  "geo" : { },
  "id_str" : "373555665966350336",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr literally the 6th shot off the camera.",
  "id" : 373555665966350336,
  "in_reply_to_status_id" : 373554331259109376,
  "created_at" : "2013-08-30 21:19:45 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "indices" : [ 0, 13 ],
      "id_str" : "72991857",
      "id" : 72991857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/1wSCf7AbOI",
      "expanded_url" : "http:\/\/www.kenrockwell.com\/fuji\/x100s.htm",
      "display_url" : "kenrockwell.com\/fuji\/x100s.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "373554326880268288",
  "geo" : { },
  "id_str" : "373555547250757632",
  "in_reply_to_user_id" : 72991857,
  "text" : "@juliabwrites thanks! it's the X100S. http:\/\/t.co\/1wSCf7AbOI",
  "id" : 373555547250757632,
  "in_reply_to_status_id" : 373554326880268288,
  "created_at" : "2013-08-30 21:19:17 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Soroka",
      "screen_name" : "ssoroka",
      "indices" : [ 0, 8 ],
      "id_str" : "6377052",
      "id" : 6377052
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "373555359002005504",
  "in_reply_to_user_id" : 6377052,
  "text" : "@ssoroka hey, have you seen @nickelcityruby \/ http:\/\/t.co\/yhjteaaViy ? Would love to some Scalability folks come out.",
  "id" : 373555359002005504,
  "created_at" : "2013-08-30 21:18:32 +0000",
  "in_reply_to_screen_name" : "ssoroka",
  "in_reply_to_user_id_str" : "6377052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373552556280414209",
  "geo" : { },
  "id_str" : "373553064243769345",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu All in auto mode...nothing fancy yet. Wish I knew how to control it, soon!",
  "id" : 373553064243769345,
  "in_reply_to_status_id" : 373552556280414209,
  "created_at" : "2013-08-30 21:09:25 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/CRbwsXvyiY",
      "expanded_url" : "http:\/\/flic.kr\/p\/fFdMS7",
      "display_url" : "flic.kr\/p\/fFdMS7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.891749, -78.894517 ]
  },
  "id_str" : "373552478794424320",
  "text" : "New camera is in, and it's awesome. Ged at the park: http:\/\/t.co\/CRbwsXvyiY",
  "id" : 373552478794424320,
  "created_at" : "2013-08-30 21:07:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "indices" : [ 0, 11 ],
      "id_str" : "272230417",
      "id" : 272230417
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373527927859601408",
  "geo" : { },
  "id_str" : "373528356362272769",
  "in_reply_to_user_id" : 272230417,
  "text" : "@phildzikiy @kevinpurdy Purdster.",
  "id" : 373528356362272769,
  "in_reply_to_status_id" : 373527927859601408,
  "created_at" : "2013-08-30 19:31:14 +0000",
  "in_reply_to_screen_name" : "phildzikiy",
  "in_reply_to_user_id_str" : "272230417",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/373514556011577344\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TywdpB9fjr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS79gn3CAAEDjWe.png",
      "id_str" : "373514556015771649",
      "id" : 373514556015771649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS79gn3CAAEDjWe.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/TywdpB9fjr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "373514942869024769",
  "text" : "RT @nickelcityruby: Here's a sneak peek of the NickelCityRuby tshirt design!!! Register here to get your own! http:\/\/t.co\/U1fBUeQnGv http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/373514556011577344\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/TywdpB9fjr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BS79gn3CAAEDjWe.png",
        "id_str" : "373514556015771649",
        "id" : 373514556015771649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS79gn3CAAEDjWe.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 660
        } ],
        "display_url" : "pic.twitter.com\/TywdpB9fjr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "373514556011577344",
    "text" : "Here's a sneak peek of the NickelCityRuby tshirt design!!! Register here to get your own! http:\/\/t.co\/U1fBUeQnGv http:\/\/t.co\/TywdpB9fjr",
    "id" : 373514556011577344,
    "created_at" : "2013-08-30 18:36:24 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 373514942869024769,
  "created_at" : "2013-08-30 18:37:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/373513491899887616\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/eFOeBXofuK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS78irwCMAAJlN5.png",
      "id_str" : "373513491908276224",
      "id" : 373513491908276224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS78irwCMAAJlN5.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/eFOeBXofuK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373513491899887616",
  "text" : "Design for the @nickelcityruby shirt is coming together... I hope you'll be wearing one soon! http:\/\/t.co\/eFOeBXofuK",
  "id" : 373513491899887616,
  "created_at" : "2013-08-30 18:32:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Phoenix",
      "screen_name" : "aphoenix",
      "indices" : [ 0, 9 ],
      "id_str" : "7469952",
      "id" : 7469952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373494046791962624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9124282675, -78.8800949635 ]
  },
  "id_str" : "373495574869590016",
  "in_reply_to_user_id" : 7469952,
  "text" : "@aphoenix Can do. Sorry about this.",
  "id" : 373495574869590016,
  "in_reply_to_status_id" : 373494046791962624,
  "created_at" : "2013-08-30 17:20:58 +0000",
  "in_reply_to_screen_name" : "aphoenix",
  "in_reply_to_user_id_str" : "7469952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Jill Terreri Ramos",
      "screen_name" : "jillterreri",
      "indices" : [ 12, 24 ],
      "id_str" : "46209505",
      "id" : 46209505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373475821932920832",
  "geo" : { },
  "id_str" : "373478303602311168",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @jillterreri Litany Against Fear of Missing Out",
  "id" : 373478303602311168,
  "in_reply_to_status_id" : 373475821932920832,
  "created_at" : "2013-08-30 16:12:21 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/3bPKHQtc96",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus",
      "display_url" : "nickelcityruby.com\/bus"
    } ]
  },
  "geo" : { },
  "id_str" : "373461257011355649",
  "text" : "3 weeks (21 days!) until @nickelcityruby.  20 until the bus leaves! http:\/\/t.co\/3bPKHQtc96",
  "id" : 373461257011355649,
  "created_at" : "2013-08-30 15:04:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Newland",
      "screen_name" : "onewland",
      "indices" : [ 0, 9 ],
      "id_str" : "22040390",
      "id" : 22040390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373459949638000640",
  "geo" : { },
  "id_str" : "373460756127571969",
  "in_reply_to_user_id" : 22040390,
  "text" : "@onewland yeah I don\u2019t have the tools. I\u2019ve done it before when friends lend them. Not a huge deal.",
  "id" : 373460756127571969,
  "in_reply_to_status_id" : 373459949638000640,
  "created_at" : "2013-08-30 15:02:37 +0000",
  "in_reply_to_screen_name" : "onewland",
  "in_reply_to_user_id_str" : "22040390",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373453830438256640",
  "geo" : { },
  "id_str" : "373456067495473152",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV are you at Violas?",
  "id" : 373456067495473152,
  "in_reply_to_status_id" : 373453830438256640,
  "created_at" : "2013-08-30 14:43:59 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373455876201660416",
  "text" : "Bike troubles once again keeping me from @coworkbuffalo. One day out of the shop and an asphalt shard popped the back tube.",
  "id" : 373455876201660416,
  "created_at" : "2013-08-30 14:43:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 13, 28 ],
      "id_str" : "870817116",
      "id" : 870817116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373428306978541568",
  "geo" : { },
  "id_str" : "373429868660154368",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @WickedGoodRuby this is another big reason why I liked the blind selection.",
  "id" : 373429868660154368,
  "in_reply_to_status_id" : 373428306978541568,
  "created_at" : "2013-08-30 12:59:53 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/AIR27yP7cY",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Miasma_theory_of_disease",
      "display_url" : "en.wikipedia.org\/wiki\/Miasma_th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373306985770258432",
  "text" : "Just a reminder that this wasn\u2019t too far in the past: http:\/\/t.co\/AIR27yP7cY",
  "id" : 373306985770258432,
  "created_at" : "2013-08-30 04:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373295282017939456",
  "geo" : { },
  "id_str" : "373295484460212224",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh no worries.",
  "id" : 373295484460212224,
  "in_reply_to_status_id" : 373295282017939456,
  "created_at" : "2013-08-30 04:05:53 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373293573367558146",
  "geo" : { },
  "id_str" : "373294564267655168",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh ah dang. Still up here, I can open.",
  "id" : 373294564267655168,
  "in_reply_to_status_id" : 373293573367558146,
  "created_at" : "2013-08-30 04:02:14 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 15, 24 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373292777494179840",
  "geo" : { },
  "id_str" : "373292958247686144",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @bquarant 80+ hours a week is not worth it for anything, but that\u2019s just me. (As a side owner of 2 businesses as well)",
  "id" : 373292958247686144,
  "in_reply_to_status_id" : 373292777494179840,
  "created_at" : "2013-08-30 03:55:51 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 15, 24 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373291216181280769",
  "geo" : { },
  "id_str" : "373291571828891650",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @bquarant not doubting that, but there has been some absolutely ridiculous pg quotes lately. See article and follow up.",
  "id" : 373291571828891650,
  "in_reply_to_status_id" : 373291216181280769,
  "created_at" : "2013-08-30 03:50:20 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373290494370914306",
  "geo" : { },
  "id_str" : "373290616987193344",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr just wait until the type system melts your mind",
  "id" : 373290616987193344,
  "in_reply_to_status_id" : 373290494370914306,
  "created_at" : "2013-08-30 03:46:33 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0h202midBj",
      "expanded_url" : "http:\/\/valleywag.gawker.com\/anti-foreigner-vc-also-supports-hiring-discrimination-1215372055",
      "display_url" : "valleywag.gawker.com\/anti-foreigner\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373288732322848768",
  "geo" : { },
  "id_str" : "373289355990671360",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant \u201CI would be reluctant to start a startup with a woman who had small children, or was likely to have them\u201D http:\/\/t.co\/0h202midBj",
  "id" : 373289355990671360,
  "in_reply_to_status_id" : 373288732322848768,
  "created_at" : "2013-08-30 03:41:32 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 3, 10 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/HTCYdlbNLX",
      "expanded_url" : "http:\/\/blog.testdouble.com\/posts\/2013-08-29-great-technical-talks.html",
      "display_url" : "blog.testdouble.com\/posts\/2013-08-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373288551988727808",
  "text" : "RT @searls: Great Technical Talks. http:\/\/t.co\/HTCYdlbNLX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/HTCYdlbNLX",
        "expanded_url" : "http:\/\/blog.testdouble.com\/posts\/2013-08-29-great-technical-talks.html",
        "display_url" : "blog.testdouble.com\/posts\/2013-08-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373264825889357824",
    "text" : "Great Technical Talks. http:\/\/t.co\/HTCYdlbNLX",
    "id" : 373264825889357824,
    "created_at" : "2013-08-30 02:04:04 +0000",
    "user" : {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "protected" : false,
      "id_str" : "9038902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2360535353\/20120630-face_normal.jpg",
      "id" : 9038902,
      "verified" : false
    }
  },
  "id" : 373288551988727808,
  "created_at" : "2013-08-30 03:38:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hush Puppy",
      "screen_name" : "uhduh",
      "indices" : [ 0, 6 ],
      "id_str" : "2765967748",
      "id" : 2765967748
    }, {
      "name" : "Tavis Rudd",
      "screen_name" : "tavisrudd",
      "indices" : [ 7, 17 ],
      "id_str" : "187354174",
      "id" : 187354174
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 70, 85 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373276978767335425",
  "geo" : { },
  "id_str" : "373288345368932352",
  "in_reply_to_user_id" : 6998462,
  "text" : "@uhduh @tavisrudd I\u2019d love to see this in action at lightning talk at @nickelcityruby or IgniteBuffalo. Blown away by the Pycon video.",
  "id" : 373288345368932352,
  "in_reply_to_status_id" : 373276978767335425,
  "created_at" : "2013-08-30 03:37:31 +0000",
  "in_reply_to_screen_name" : "simianhacker",
  "in_reply_to_user_id_str" : "6998462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373286878000058368",
  "geo" : { },
  "id_str" : "373287585654652928",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded ah cool. They have so far to go in promoting community in-game.",
  "id" : 373287585654652928,
  "in_reply_to_status_id" : 373286878000058368,
  "created_at" : "2013-08-30 03:34:30 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    }, {
      "name" : "Bill Trinen",
      "screen_name" : "trintran",
      "indices" : [ 13, 22 ],
      "id_str" : "23489657",
      "id" : 23489657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373274169082798080",
  "geo" : { },
  "id_str" : "373275307970547712",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded @trintran how...is that possible if he's in seattle?",
  "id" : 373275307970547712,
  "in_reply_to_status_id" : 373274169082798080,
  "created_at" : "2013-08-30 02:45:43 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373274397077147648",
  "geo" : { },
  "id_str" : "373275224369684480",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams :(",
  "id" : 373275224369684480,
  "in_reply_to_status_id" : 373274397077147648,
  "created_at" : "2013-08-30 02:45:23 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/MrMeryZe9o",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus",
      "display_url" : "nickelcityruby.com\/bus"
    } ]
  },
  "geo" : { },
  "id_str" : "373273673521569792",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams have you seen http:\/\/t.co\/MrMeryZe9o ? curious if you\/folks in your area would be interested",
  "id" : 373273673521569792,
  "created_at" : "2013-08-30 02:39:13 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 82, 94 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    }, {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 95, 102 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/373272418401259520\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/AnNQu1V3nS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS4hSW-CEAAGIUo.jpg",
      "id_str" : "373272418405453824",
      "id" : 373272418405453824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS4hSW-CEAAGIUo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/AnNQu1V3nS"
    } ],
    "hashtags" : [ {
      "text" : "ACNL",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373272418401259520",
  "text" : "Still blown away by this Zelda inspired basement in my town's #ACNL showcase. \/cc @starguarded @cubosh http:\/\/t.co\/AnNQu1V3nS",
  "id" : 373272418401259520,
  "created_at" : "2013-08-30 02:34:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373266379954073600",
  "geo" : { },
  "id_str" : "373266475684868096",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded no, i can't figure out how to make them leave. could use the axe!",
  "id" : 373266475684868096,
  "in_reply_to_status_id" : 373266379954073600,
  "created_at" : "2013-08-30 02:10:37 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    }, {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 13, 20 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373263998935777280",
  "geo" : { },
  "id_str" : "373265330153353216",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded @cubosh gates open here if you want some TVs (or other random stuff)",
  "id" : 373265330153353216,
  "in_reply_to_status_id" : 373263998935777280,
  "created_at" : "2013-08-30 02:06:04 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/8JgDITxC5W",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v1p9jlQUW0k",
      "display_url" : "youtube.com\/watch?v=v1p9jl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373263276810854400",
  "text" : "The world's tallest slum in Caracas: http:\/\/t.co\/8JgDITxC5W",
  "id" : 373263276810854400,
  "created_at" : "2013-08-30 01:57:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/uXfToH4qhh",
      "expanded_url" : "http:\/\/gettingreal.37signals.com\/ch02_Have_an_Enemy.php",
      "display_url" : "gettingreal.37signals.com\/ch02_Have_an_E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373261566444986368",
  "text" : "Why haven't VC firms outside of SV picked an enemy with these bullshit views? Fear? Ignorance? Compliance? http:\/\/t.co\/uXfToH4qhh",
  "id" : 373261566444986368,
  "created_at" : "2013-08-30 01:51:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Fleming",
      "screen_name" : "w33ble",
      "indices" : [ 0, 7 ],
      "id_str" : "41162521",
      "id" : 41162521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373208501536829440",
  "geo" : { },
  "id_str" : "373220532051013632",
  "in_reply_to_user_id" : 41162521,
  "text" : "@w33ble yeah there should be an svg in the repo",
  "id" : 373220532051013632,
  "in_reply_to_status_id" : 373208501536829440,
  "created_at" : "2013-08-29 23:08:03 +0000",
  "in_reply_to_screen_name" : "w33ble",
  "in_reply_to_user_id_str" : "41162521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 5, 17 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/373196921281990656\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/gFPgMBFhNu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS3cn1zIAAAG-Yz.jpg",
      "id_str" : "373196921156141056",
      "id" : 373196921156141056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS3cn1zIAAAG-Yz.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gFPgMBFhNu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373196921281990656",
  "text" : "It\u2019s @AqueousBand time once again! http:\/\/t.co\/gFPgMBFhNu",
  "id" : 373196921281990656,
  "created_at" : "2013-08-29 21:34:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 7, 14 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373175116085354497",
  "geo" : { },
  "id_str" : "373175180706988032",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @gedeon still. Ugh!",
  "id" : 373175180706988032,
  "in_reply_to_status_id" : 373175116085354497,
  "created_at" : "2013-08-29 20:07:51 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 0, 7 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373174732759113728",
  "geo" : { },
  "id_str" : "373175116085354497",
  "in_reply_to_user_id" : 38003,
  "text" : "@gedeon I don\u2019t see them being close to done anytime soon. Feels like so much is unpolished\/broken soon.",
  "id" : 373175116085354497,
  "in_reply_to_status_id" : 373174732759113728,
  "created_at" : "2013-08-29 20:07:35 +0000",
  "in_reply_to_screen_name" : "gedeon",
  "in_reply_to_user_id_str" : "38003",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "in_reply_to_status_id_str" : "373167113868820480",
  "geo" : { },
  "id_str" : "373167577049989120",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Why not? Also, did you see http:\/\/t.co\/YJWat2Hg3F ?",
  "id" : 373167577049989120,
  "in_reply_to_status_id" : 373167113868820480,
  "created_at" : "2013-08-29 19:37:38 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 20, 30 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373163899597492224",
  "geo" : { },
  "id_str" : "373164091226869760",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh Yes, that's @aquaranto. She's mayor. I'm just a wage (bell) slave.",
  "id" : 373164091226869760,
  "in_reply_to_status_id" : 373163899597492224,
  "created_at" : "2013-08-29 19:23:47 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Code Climate",
      "screen_name" : "codeclimate",
      "indices" : [ 3, 15 ],
      "id_str" : "299277049",
      "id" : 299277049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jwf7rXCjmU",
      "expanded_url" : "http:\/\/bit.ly\/1eGVLOg",
      "display_url" : "bit.ly\/1eGVLOg"
    } ]
  },
  "geo" : { },
  "id_str" : "373162247897378816",
  "text" : "RT @codeclimate: Intention revealing methods by Nick of 37signals http:\/\/t.co\/jwf7rXCjmU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/jwf7rXCjmU",
        "expanded_url" : "http:\/\/bit.ly\/1eGVLOg",
        "display_url" : "bit.ly\/1eGVLOg"
      } ]
    },
    "geo" : { },
    "id_str" : "372764021537386498",
    "text" : "Intention revealing methods by Nick of 37signals http:\/\/t.co\/jwf7rXCjmU",
    "id" : 372764021537386498,
    "created_at" : "2013-08-28 16:54:03 +0000",
    "user" : {
      "name" : "Code Climate",
      "screen_name" : "codeclimate",
      "protected" : false,
      "id_str" : "299277049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479006939620184064\/KFgYaUkK_normal.png",
      "id" : 299277049,
      "verified" : false
    }
  },
  "id" : 373162247897378816,
  "created_at" : "2013-08-29 19:16:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 0, 7 ],
      "id_str" : "14466962",
      "id" : 14466962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373159285141696512",
  "geo" : { },
  "id_str" : "373159874412032000",
  "in_reply_to_user_id" : 14466962,
  "text" : "@Lenary well duh, football jerseys and hoodies are profitable all year and contribute highly to your education!",
  "id" : 373159874412032000,
  "in_reply_to_status_id" : 373159285141696512,
  "created_at" : "2013-08-29 19:07:01 +0000",
  "in_reply_to_screen_name" : "Lenary",
  "in_reply_to_user_id_str" : "14466962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 13, 23 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373153499930165249",
  "geo" : { },
  "id_str" : "373153693639520256",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss yes, @confreaks will be there!",
  "id" : 373153693639520256,
  "in_reply_to_status_id" : 373153499930165249,
  "created_at" : "2013-08-29 18:42:28 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 71, 86 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/YJWat2Hg3F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "373138576533225472",
  "text" : "START THE BUS! http:\/\/t.co\/YJWat2Hg3F Anyone in NYC who isn't going to @nickelcityruby should get on this.",
  "id" : 373138576533225472,
  "created_at" : "2013-08-29 17:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 3, 14 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CutXf2L2Vm",
      "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/nickelcityruby-2013",
      "display_url" : "tito.io\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373132911400062976",
  "text" : "RT @rachelober: Join me and a bunch of rubyists ride to @nickelcityruby in style. $125 gets you on the bus and in the conference! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 40, 55 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CutXf2L2Vm",
        "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/nickelcityruby-2013",
        "display_url" : "tito.io\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373131967383887872",
    "text" : "Join me and a bunch of rubyists ride to @nickelcityruby in style. $125 gets you on the bus and in the conference! https:\/\/t.co\/CutXf2L2Vm",
    "id" : 373131967383887872,
    "created_at" : "2013-08-29 17:16:08 +0000",
    "user" : {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "protected" : false,
      "id_str" : "14390268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321996605296640\/ekU7oNFN_normal.jpeg",
      "id" : 14390268,
      "verified" : false
    }
  },
  "id" : 373132911400062976,
  "created_at" : "2013-08-29 17:19:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 16, 28 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373128861321416704",
  "geo" : { },
  "id_str" : "373128910067605504",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @AqueousBand Super helpful, thanks!",
  "id" : 373128910067605504,
  "in_reply_to_status_id" : 373128861321416704,
  "created_at" : "2013-08-29 17:03:59 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 16, 28 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373107479707521024",
  "geo" : { },
  "id_str" : "373127279800369152",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @AqueousBand any ideas about start time? 5PM is early!",
  "id" : 373127279800369152,
  "in_reply_to_status_id" : 373107479707521024,
  "created_at" : "2013-08-29 16:57:30 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 61, 76 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/4RpmJXkTmC",
      "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/nickelcityruby-2013",
      "display_url" : "tito.io\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373125444985294848",
  "text" : "NYC Rubyists! RubyCentral is sponsoring a bus to Buffalo for @nickelcityruby. $125 for conference + roundtrip! https:\/\/t.co\/4RpmJXkTmC",
  "id" : 373125444985294848,
  "created_at" : "2013-08-29 16:50:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Sj\u00F6berg",
      "screen_name" : "KevinSjoberg",
      "indices" : [ 0, 13 ],
      "id_str" : "222442958",
      "id" : 222442958
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 38, 48 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373115237915840512",
  "geo" : { },
  "id_str" : "373116588909535232",
  "in_reply_to_user_id" : 222442958,
  "text" : "@KevinSjoberg Dang! :( Well, at least @confreaks will be here.",
  "id" : 373116588909535232,
  "in_reply_to_status_id" : 373115237915840512,
  "created_at" : "2013-08-29 16:15:01 +0000",
  "in_reply_to_screen_name" : "KevinSjoberg",
  "in_reply_to_user_id_str" : "222442958",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Ketan Deshmukh",
      "screen_name" : "ketandeshmukh",
      "indices" : [ 32, 46 ],
      "id_str" : "59896282",
      "id" : 59896282
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 116, 125 ],
      "id_str" : "51077652",
      "id" : 51077652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373114845123448832",
  "text" : "RT @nickelcityruby: Congrats to @ketandeshmukh the Univ. of Bflo student who received a donated ticket from sponsor @Chargify - contact us \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ketan Deshmukh",
        "screen_name" : "ketandeshmukh",
        "indices" : [ 12, 26 ],
        "id_str" : "59896282",
        "id" : 59896282
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 96, 105 ],
        "id_str" : "51077652",
        "id" : 51077652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373111710292275200",
    "text" : "Congrats to @ketandeshmukh the Univ. of Bflo student who received a donated ticket from sponsor @Chargify - contact us to donate to students",
    "id" : 373111710292275200,
    "created_at" : "2013-08-29 15:55:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 373114845123448832,
  "created_at" : "2013-08-29 16:08:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372751736936472576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.920992088, -78.8805351053 ]
  },
  "id_str" : "372941002237284352",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh adding now. Mine is 2363 6310 1548",
  "id" : 372941002237284352,
  "in_reply_to_status_id" : 372751736936472576,
  "created_at" : "2013-08-29 04:37:18 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/FTg4zjTrMD",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372937667534532609",
  "text" : "9\/13 roles completed...Caveman, Healer, Monk, Priest still elude me. http:\/\/t.co\/FTg4zjTrMD",
  "id" : 372937667534532609,
  "created_at" : "2013-08-29 04:24:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/964x5repIm",
      "expanded_url" : "http:\/\/alt.org\/nethack\/userdata\/D\/DoctorNick\/dumplog\/1376360062.nh343.txt",
      "display_url" : "alt.org\/nethack\/userda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372937390995689472",
  "text" : "First ascension with all 7 Nazgul rings too. http:\/\/t.co\/964x5repIm",
  "id" : 372937390995689472,
  "created_at" : "2013-08-29 04:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372937031975845888",
  "text" : "Ascension 9 complete: Ranger! Picked the right branch of Astral by a huge stroke of luck.",
  "id" : 372937031975845888,
  "created_at" : "2013-08-29 04:21:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sharp",
      "screen_name" : "ajsharp",
      "indices" : [ 0, 8 ],
      "id_str" : "18071073",
      "id" : 18071073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372927245330808832",
  "geo" : { },
  "id_str" : "372932972313186304",
  "in_reply_to_user_id" : 18071073,
  "text" : "@ajsharp i'm sure, but not crating a breed known to cause massive property damage when bored\/inactive is just insanity imo",
  "id" : 372932972313186304,
  "in_reply_to_status_id" : 372927245330808832,
  "created_at" : "2013-08-29 04:05:24 +0000",
  "in_reply_to_screen_name" : "ajsharp",
  "in_reply_to_user_id_str" : "18071073",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YDIgxSQCpD",
      "expanded_url" : "http:\/\/i.imgur.com\/DIMkXvd.jpg",
      "display_url" : "i.imgur.com\/DIMkXvd.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "372925995654737921",
  "text" : "\"I don't like to leave them caged.\" says husky owner after posting this photo. I don't understand other husky owners. http:\/\/t.co\/YDIgxSQCpD",
  "id" : 372925995654737921,
  "created_at" : "2013-08-29 03:37:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 0, 7 ],
      "id_str" : "45489027",
      "id" : 45489027
    }, {
      "name" : "WW2 Tweets from 1943",
      "screen_name" : "RealTimeWWII",
      "indices" : [ 22, 35 ],
      "id_str" : "364488011",
      "id" : 364488011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372852621927014402",
  "geo" : { },
  "id_str" : "372875419176820736",
  "in_reply_to_user_id" : 45489027,
  "text" : "@pummer have you seen @RealTimeWWII ?",
  "id" : 372875419176820736,
  "in_reply_to_status_id" : 372852621927014402,
  "created_at" : "2013-08-29 00:16:42 +0000",
  "in_reply_to_screen_name" : "pummer",
  "in_reply_to_user_id_str" : "45489027",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Merissa",
      "screen_name" : "merissie",
      "indices" : [ 82, 91 ],
      "id_str" : "15338379",
      "id" : 15338379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/aWLUvgPPwv",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3611-letting-employees-make-the-most-out-of-their-own-fitness",
      "display_url" : "37signals.com\/svn\/posts\/3611\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372875347450003457",
  "text" : "RT @37signals: SvN: Letting employees make the most out of their own fitness (or, @merissie is a badass) http:\/\/t.co\/aWLUvgPPwv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Merissa",
        "screen_name" : "merissie",
        "indices" : [ 67, 76 ],
        "id_str" : "15338379",
        "id" : 15338379
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/aWLUvgPPwv",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3611-letting-employees-make-the-most-out-of-their-own-fitness",
        "display_url" : "37signals.com\/svn\/posts\/3611\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372852477416062976",
    "text" : "SvN: Letting employees make the most out of their own fitness (or, @merissie is a badass) http:\/\/t.co\/aWLUvgPPwv",
    "id" : 372852477416062976,
    "created_at" : "2013-08-28 22:45:32 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 372875347450003457,
  "created_at" : "2013-08-29 00:16:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 46, 61 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372872552068038656",
  "text" : "Plans to get a bus from NYC =&gt; Buffalo for @nickelcityruby are becoming real. Details forthcoming. (If you're interested yell!)",
  "id" : 372872552068038656,
  "created_at" : "2013-08-29 00:05:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/hcQjaOPfc5",
      "expanded_url" : "http:\/\/i.imgur.com\/cmwCeb4.gif",
      "display_url" : "i.imgur.com\/cmwCeb4.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "372863331834421249",
  "text" : "RT @theediguy: Current status: http:\/\/t.co\/hcQjaOPfc5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/hcQjaOPfc5",
        "expanded_url" : "http:\/\/i.imgur.com\/cmwCeb4.gif",
        "display_url" : "i.imgur.com\/cmwCeb4.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "372862566323589120",
    "text" : "Current status: http:\/\/t.co\/hcQjaOPfc5",
    "id" : 372862566323589120,
    "created_at" : "2013-08-28 23:25:37 +0000",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 372863331834421249,
  "created_at" : "2013-08-28 23:28:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372840885169299456",
  "text" : "\"Harry Potter 15th Anniversary Box Set\" ...15 years!!!?",
  "id" : 372840885169299456,
  "created_at" : "2013-08-28 21:59:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372806480887427072",
  "geo" : { },
  "id_str" : "372806945473716225",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski Glass looks cool. Also they've been putting shoring in for the past ~2 weeks, making a ton of noise.",
  "id" : 372806945473716225,
  "in_reply_to_status_id" : 372806480887427072,
  "created_at" : "2013-08-28 19:44:36 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372778605161766912",
  "geo" : { },
  "id_str" : "372779489857519616",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain the trick is to surrender to the flow :)",
  "id" : 372779489857519616,
  "in_reply_to_status_id" : 372778605161766912,
  "created_at" : "2013-08-28 17:55:30 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HiAQDaTtR2",
      "expanded_url" : "http:\/\/37svn.com\/3603",
      "display_url" : "37svn.com\/3603"
    } ]
  },
  "in_reply_to_status_id_str" : "372775472637427712",
  "geo" : { },
  "id_str" : "372775728460218368",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa been doing iOS stuff for over a year! http:\/\/t.co\/HiAQDaTtR2",
  "id" : 372775728460218368,
  "in_reply_to_status_id" : 372775472637427712,
  "created_at" : "2013-08-28 17:40:34 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/rSccPvb0ri",
      "expanded_url" : "http:\/\/www.marco.org\/2011\/05\/26\/geek-intro-to-phish",
      "display_url" : "marco.org\/2011\/05\/26\/gee\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372773712875229184",
  "geo" : { },
  "id_str" : "372774021760172032",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain I recommend starting here: http:\/\/t.co\/rSccPvb0ri I have plenty of shows to share too (and a ticket to October's show in Roc!)",
  "id" : 372774021760172032,
  "in_reply_to_status_id" : 372773712875229184,
  "created_at" : "2013-08-28 17:33:47 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 25, 31 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "TONX",
      "screen_name" : "tonxcoffee",
      "indices" : [ 42, 53 ],
      "id_str" : "288854366",
      "id" : 288854366
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 77, 88 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372773005715185664",
  "text" : "Preferred state of mind: @phish blasting, @tonxcoffee pumping through veins, @RubyMotion building.",
  "id" : 372773005715185664,
  "created_at" : "2013-08-28 17:29:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 0, 10 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372765835346968576",
  "geo" : { },
  "id_str" : "372765914447347713",
  "in_reply_to_user_id" : 21003240,
  "text" : "@BlockClub congrats! sounds awesome",
  "id" : 372765914447347713,
  "in_reply_to_status_id" : 372765835346968576,
  "created_at" : "2013-08-28 17:01:34 +0000",
  "in_reply_to_screen_name" : "BlockClub",
  "in_reply_to_user_id_str" : "21003240",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 30, 39 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 71, 86 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "372758819186544640",
  "text" : "Dropped some small banners on @gitready and http:\/\/t.co\/2bA9BVLhWr for @nickelcityruby... the best ads are free, right?",
  "id" : 372758819186544640,
  "created_at" : "2013-08-28 16:33:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Cahill",
      "screen_name" : "ElectronicMike",
      "indices" : [ 0, 15 ],
      "id_str" : "18829543",
      "id" : 18829543
    }, {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 16, 28 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 29, 40 ],
      "id_str" : "14390268",
      "id" : 14390268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372755096418779136",
  "geo" : { },
  "id_str" : "372757782144901120",
  "in_reply_to_user_id" : 18829543,
  "text" : "@ElectronicMike @joshknowles @rachelober I'm going to call and get a quote today. My question\/challenge: Can you fill it?",
  "id" : 372757782144901120,
  "in_reply_to_status_id" : 372755096418779136,
  "created_at" : "2013-08-28 16:29:15 +0000",
  "in_reply_to_screen_name" : "ElectronicMike",
  "in_reply_to_user_id_str" : "18829543",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372748108939403264",
  "geo" : { },
  "id_str" : "372755757084590080",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack Same, the 3D hurts my head, it's the form factor that sucks. And yes, hit me with a friend code!",
  "id" : 372755757084590080,
  "in_reply_to_status_id" : 372748108939403264,
  "created_at" : "2013-08-28 16:21:12 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372750315306909697",
  "geo" : { },
  "id_str" : "372755636024406017",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy it's larger than an original 4 AA battery Gameboy!",
  "id" : 372755636024406017,
  "in_reply_to_status_id" : 372750315306909697,
  "created_at" : "2013-08-28 16:20:43 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 4, 16 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 17, 28 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 73, 88 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nyruby",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372753488041627649",
  "text" : "Hey @joshknowles @rachelober #nyruby is there still interest in a bus to @nickelcityruby ?",
  "id" : 372753488041627649,
  "created_at" : "2013-08-28 16:12:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/jGnUAZP49u",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=sAExBTWIp3M",
      "display_url" : "youtube.com\/watch?v=sAExBT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372746755948830722",
  "text" : "What is wrong with Nintendo? This is everything that is wrong: https:\/\/t.co\/jGnUAZP49u",
  "id" : 372746755948830722,
  "created_at" : "2013-08-28 15:45:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 51, 59 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 60, 70 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 71, 82 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 83, 92 ],
      "id_str" : "51077652",
      "id" : 51077652
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 93, 100 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Harvest",
      "screen_name" : "harvest",
      "indices" : [ 101, 109 ],
      "id_str" : "7541902",
      "id" : 7541902
    }, {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "indices" : [ 110, 122 ],
      "id_str" : "22043483",
      "id" : 22043483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372739075343544320",
  "text" : "RT @nickelcityruby: Special thanks to our sponsors @Synacor @37signals @engineyard @Chargify @github @harvest @littlelines &amp; Division by Ze\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Synacor",
        "screen_name" : "Synacor",
        "indices" : [ 31, 39 ],
        "id_str" : "19976046",
        "id" : 19976046
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 40, 50 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 51, 62 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 63, 72 ],
        "id_str" : "51077652",
        "id" : 51077652
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 73, 80 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Harvest",
        "screen_name" : "harvest",
        "indices" : [ 81, 89 ],
        "id_str" : "7541902",
        "id" : 7541902
      }, {
        "name" : "Littlelines on Rails",
        "screen_name" : "littlelines",
        "indices" : [ 90, 102 ],
        "id_str" : "22043483",
        "id" : 22043483
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372734120712888320",
    "text" : "Special thanks to our sponsors @Synacor @37signals @engineyard @Chargify @github @harvest @littlelines &amp; Division by Zero - come see us 9\/20",
    "id" : 372734120712888320,
    "created_at" : "2013-08-28 14:55:14 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 372739075343544320,
  "created_at" : "2013-08-28 15:14:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/QtbNsAmoZL",
      "expanded_url" : "https:\/\/github.com\/kien\/ctrlp.vim",
      "display_url" : "github.com\/kien\/ctrlp.vim"
    } ]
  },
  "in_reply_to_status_id_str" : "372734845841342464",
  "geo" : { },
  "id_str" : "372736102777376768",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah https:\/\/t.co\/QtbNsAmoZL",
  "id" : 372736102777376768,
  "in_reply_to_status_id" : 372734845841342464,
  "created_at" : "2013-08-28 15:03:06 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madison+ Ruby",
      "screen_name" : "MadisonRuby",
      "indices" : [ 3, 15 ],
      "id_str" : "121324195",
      "id" : 121324195
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 89, 104 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madruby13",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372729739770740736",
  "text" : "RT @MadisonRuby: Friends! You owe it to yourself to take a look at the fantastic program @nickelcityruby has put together. #madruby13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 72, 87 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "madruby13",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372729273150238722",
    "text" : "Friends! You owe it to yourself to take a look at the fantastic program @nickelcityruby has put together. #madruby13",
    "id" : 372729273150238722,
    "created_at" : "2013-08-28 14:35:58 +0000",
    "user" : {
      "name" : "Madison+ Ruby",
      "screen_name" : "MadisonRuby",
      "protected" : false,
      "id_str" : "121324195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1219972840\/MadisonRuby-Logo-NoText_normal.png",
      "id" : 121324195,
      "verified" : false
    }
  },
  "id" : 372729739770740736,
  "created_at" : "2013-08-28 14:37:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/8COVYrFcwl",
      "expanded_url" : "http:\/\/j.mp\/19Z5wKW",
      "display_url" : "j.mp\/19Z5wKW"
    } ]
  },
  "geo" : { },
  "id_str" : "372727061854420993",
  "text" : "RT @nickelcityruby: Also - Code retreat registration is filling up for the sunday after #ncrc13: http:\/\/t.co\/8COVYrFcwl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/8COVYrFcwl",
        "expanded_url" : "http:\/\/j.mp\/19Z5wKW",
        "display_url" : "j.mp\/19Z5wKW"
      } ]
    },
    "geo" : { },
    "id_str" : "372726822527455232",
    "text" : "Also - Code retreat registration is filling up for the sunday after #ncrc13: http:\/\/t.co\/8COVYrFcwl",
    "id" : 372726822527455232,
    "created_at" : "2013-08-28 14:26:14 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 372727061854420993,
  "created_at" : "2013-08-28 14:27:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dQYYx3UISO",
      "expanded_url" : "http:\/\/j.mp\/16QHIo4",
      "display_url" : "j.mp\/16QHIo4"
    } ]
  },
  "geo" : { },
  "id_str" : "372727054736703489",
  "text" : "RT @nickelcityruby: With less than a month to go, get your tickets while they are still available: http:\/\/t.co\/dQYYx3UISO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/dQYYx3UISO",
        "expanded_url" : "http:\/\/j.mp\/16QHIo4",
        "display_url" : "j.mp\/16QHIo4"
      } ]
    },
    "geo" : { },
    "id_str" : "372726745792643072",
    "text" : "With less than a month to go, get your tickets while they are still available: http:\/\/t.co\/dQYYx3UISO",
    "id" : 372726745792643072,
    "created_at" : "2013-08-28 14:25:55 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 372727054736703489,
  "created_at" : "2013-08-28 14:27:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/VGrBWVID04",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/59584648154\/parallel-gem-installing-using-bundler",
      "display_url" : "robots.thoughtbot.com\/post\/595846481\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372719334319083520",
  "text" : "RT @thoughtbot: Spend less time sword fighting and more time writing actual code by installing gems in parallel using Bundler! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/VGrBWVID04",
        "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/59584648154\/parallel-gem-installing-using-bundler",
        "display_url" : "robots.thoughtbot.com\/post\/595846481\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372719198176542721",
    "text" : "Spend less time sword fighting and more time writing actual code by installing gems in parallel using Bundler! http:\/\/t.co\/VGrBWVID04",
    "id" : 372719198176542721,
    "created_at" : "2013-08-28 13:55:56 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 372719334319083520,
  "created_at" : "2013-08-28 13:56:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372711682835243009",
  "text" : "A murder of crows greeted me as I left my house this morning. Bad omen? (No lightning though)",
  "id" : 372711682835243009,
  "created_at" : "2013-08-28 13:26:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prakash Murthy",
      "screen_name" : "_prakash",
      "indices" : [ 0, 9 ],
      "id_str" : "14540563",
      "id" : 14540563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372586661483270144",
  "geo" : { },
  "id_str" : "372586937648824320",
  "in_reply_to_user_id" : 14540563,
  "text" : "@_prakash hell no. The purpose is just to spread news about this, not to make any money off it.",
  "id" : 372586937648824320,
  "in_reply_to_status_id" : 372586661483270144,
  "created_at" : "2013-08-28 05:10:22 +0000",
  "in_reply_to_screen_name" : "_prakash",
  "in_reply_to_user_id_str" : "14540563",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372582587434156032",
  "geo" : { },
  "id_str" : "372583229791809536",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky just the term \u201Cviral loop\u201D causes some kind of gag reflex for me. Feels misguided.",
  "id" : 372583229791809536,
  "in_reply_to_status_id" : 372582587434156032,
  "created_at" : "2013-08-28 04:55:38 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372582656833118208",
  "text" : "Have never had an \u201Cad\u201D of any kind before of self-made content on self-made content. Internal struggle deepening.",
  "id" : 372582656833118208,
  "created_at" : "2013-08-28 04:53:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 44, 53 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 55, 64 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "372582161200586752",
  "text" : "Considering a banner for @nickelcityruby on @gitready, @openhack, http:\/\/t.co\/2bA9BVLhWr. All are community focused, does this seem wrong?",
  "id" : 372582161200586752,
  "created_at" : "2013-08-28 04:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372579873065144320",
  "geo" : { },
  "id_str" : "372581477227057152",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky what a terrible, soulless way to think about building a product.",
  "id" : 372581477227057152,
  "in_reply_to_status_id" : 372579873065144320,
  "created_at" : "2013-08-28 04:48:41 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372577088600936448",
  "geo" : { },
  "id_str" : "372580162702811136",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k seeing this from the organizer perspective is different. I\u2019m sure post-September I\u2019ll have more input for you.",
  "id" : 372580162702811136,
  "in_reply_to_status_id" : 372577088600936448,
  "created_at" : "2013-08-28 04:43:27 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 3, 12 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/4ABEHzgOzz",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/PHP\/comments\/1l7baq\/creating_a_user_from_the_web_problem\/",
      "display_url" : "reddit.com\/r\/PHP\/comments\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372552001541787650",
  "text" : "RT @sabiddle: Have to echo the one commenter's sentiment: \"Holy shit\" http:\/\/t.co\/4ABEHzgOzz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/4ABEHzgOzz",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/PHP\/comments\/1l7baq\/creating_a_user_from_the_web_problem\/",
        "display_url" : "reddit.com\/r\/PHP\/comments\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372532408274268160",
    "text" : "Have to echo the one commenter's sentiment: \"Holy shit\" http:\/\/t.co\/4ABEHzgOzz",
    "id" : 372532408274268160,
    "created_at" : "2013-08-28 01:33:42 +0000",
    "user" : {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "protected" : false,
      "id_str" : "20531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2696016475\/32aa0b0b3249511f0e106601d87bab01_normal.png",
      "id" : 20531902,
      "verified" : false
    }
  },
  "id" : 372552001541787650,
  "created_at" : "2013-08-28 02:51:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/yNPCdhRb5g",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "372549528328499200",
  "text" : "RT @samkottler: There's going to be a slight blip for http:\/\/t.co\/yNPCdhRb5g at 11pm eastern so we can move the primary IP over to a new lo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/yNPCdhRb5g",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "372549370501431296",
    "text" : "There's going to be a slight blip for http:\/\/t.co\/yNPCdhRb5g at 11pm eastern so we can move the primary IP over to a new load balancer.",
    "id" : 372549370501431296,
    "created_at" : "2013-08-28 02:41:06 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 372549528328499200,
  "created_at" : "2013-08-28 02:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372545010245185536",
  "geo" : { },
  "id_str" : "372545266613645312",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh I need your friend code. Would gladly donate a modern wood TV to this insanity",
  "id" : 372545266613645312,
  "in_reply_to_status_id" : 372545010245185536,
  "created_at" : "2013-08-28 02:24:47 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Frost",
      "screen_name" : "jephjacques",
      "indices" : [ 0, 12 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372544943128334336",
  "geo" : { },
  "id_str" : "372545110883307520",
  "in_reply_to_user_id" : 7670202,
  "text" : "@jephjacques Everything happens so much",
  "id" : 372545110883307520,
  "in_reply_to_status_id" : 372544943128334336,
  "created_at" : "2013-08-28 02:24:10 +0000",
  "in_reply_to_screen_name" : "jephjacques",
  "in_reply_to_user_id_str" : "7670202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/TUqZIAIlNb",
      "expanded_url" : "http:\/\/zenpencils.com\/comic\/128-bill-watterson-a-cartoonists-advice\/#.Uh1ae40H6yY.facebook",
      "display_url" : "zenpencils.com\/comic\/128-bill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372544246743457792",
  "text" : "Deep thinking about careers and goals from Bill Watterson: http:\/\/t.co\/TUqZIAIlNb",
  "id" : 372544246743457792,
  "created_at" : "2013-08-28 02:20:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/VNS60vhtri",
      "expanded_url" : "http:\/\/codekeyboards.com\/",
      "display_url" : "codekeyboards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "372527221107200000",
  "text" : "CODE looks nice, and is a good reminder desktop computers (that programmers use) still exist. http:\/\/t.co\/VNS60vhtri",
  "id" : 372527221107200000,
  "created_at" : "2013-08-28 01:13:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 15, 25 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372504294903148544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9724284435, -78.8349314112 ]
  },
  "id_str" : "372505381945499648",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael @theediguy wasn\u2019t it already in a suburb?",
  "id" : 372505381945499648,
  "in_reply_to_status_id" : 372504294903148544,
  "created_at" : "2013-08-27 23:46:18 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372486655938007040",
  "geo" : { },
  "id_str" : "372504400901992448",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 what\u2019s the meaning of the binary\/character?",
  "id" : 372504400901992448,
  "in_reply_to_status_id" : 372486655938007040,
  "created_at" : "2013-08-27 23:42:24 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372491982288871424",
  "text" : "Pixelmator is absolutely terrible on 10.9.",
  "id" : 372491982288871424,
  "created_at" : "2013-08-27 22:53:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372476653944832000",
  "geo" : { },
  "id_str" : "372476960720429056",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit What does Mrs. Haskell look like?",
  "id" : 372476960720429056,
  "in_reply_to_status_id" : 372476653944832000,
  "created_at" : "2013-08-27 21:53:22 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "372409626341298176",
  "text" : "It's Tuesday! If you run a prog\/dev related group, and there's a meeting tonight, I'd appreciate a shoutout for http:\/\/t.co\/yhjteaaViy !",
  "id" : 372409626341298176,
  "created_at" : "2013-08-27 17:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372409071174823936",
  "text" : "Current status: __CFRUNLOOP_IS_CALLING_OUT_TO_A_SOURCE1_PERFORM_FUNCTION__",
  "id" : 372409071174823936,
  "created_at" : "2013-08-27 17:23:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372399736268939265",
  "geo" : { },
  "id_str" : "372403649181278209",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant \"Cool\" \"Med school\" \"Education value\" \"Slide design\"",
  "id" : 372403649181278209,
  "in_reply_to_status_id" : 372399736268939265,
  "created_at" : "2013-08-27 17:02:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "Ryan Castillo",
      "screen_name" : "rmcastil",
      "indices" : [ 9, 18 ],
      "id_str" : "10245302",
      "id" : 10245302
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 73, 83 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 97, 106 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372382351185035264",
  "geo" : { },
  "id_str" : "372383876326244353",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright @rmcastil same here, due 11\/8. It's go time! Trying to convince @aquaranto to submit to @codemash too.",
  "id" : 372383876326244353,
  "in_reply_to_status_id" : 372382351185035264,
  "created_at" : "2013-08-27 15:43:29 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo PASS",
      "screen_name" : "BuffaloPASS",
      "indices" : [ 3, 15 ],
      "id_str" : "1468216825",
      "id" : 1468216825
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "Ruby",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/i4JZZqk6rN",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "372380777935159296",
  "text" : "RT @BuffaloPASS: Hey #Buffalo tech: @nickelcityruby is not just for #Ruby devs - focus on craftsmanship,mentorship,architecture,etc. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "Ruby",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/i4JZZqk6rN",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "372379533195751425",
    "text" : "Hey #Buffalo tech: @nickelcityruby is not just for #Ruby devs - focus on craftsmanship,mentorship,architecture,etc. http:\/\/t.co\/i4JZZqk6rN",
    "id" : 372379533195751425,
    "created_at" : "2013-08-27 15:26:13 +0000",
    "user" : {
      "name" : "Buffalo PASS",
      "screen_name" : "BuffaloPASS",
      "protected" : false,
      "id_str" : "1468216825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3733271708\/4abfbb2dbcdac11b0a2008a377eea9d4_normal.png",
      "id" : 1468216825,
      "verified" : false
    }
  },
  "id" : 372380777935159296,
  "created_at" : "2013-08-27 15:31:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Bke1k5K4jX",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "372379192496627712",
  "text" : "RT @nickelcityruby: The schedule has been released! http:\/\/t.co\/Bke1k5K4jX Are you registered for NickelCityRuby yet?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/Bke1k5K4jX",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
        "display_url" : "nickelcityruby.com\/#schedule"
      } ]
    },
    "geo" : { },
    "id_str" : "372378396665188352",
    "text" : "The schedule has been released! http:\/\/t.co\/Bke1k5K4jX Are you registered for NickelCityRuby yet?",
    "id" : 372378396665188352,
    "created_at" : "2013-08-27 15:21:42 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 372379192496627712,
  "created_at" : "2013-08-27 15:24:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian",
      "screen_name" : "id",
      "indices" : [ 0, 3 ],
      "id_str" : "13790742",
      "id" : 13790742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372344478532923392",
  "geo" : { },
  "id_str" : "372347462549524480",
  "in_reply_to_user_id" : 13790742,
  "text" : "@id just funny to me that &lt; 100 lines can be \u201Cover-abstracting\u201D ;)",
  "id" : 372347462549524480,
  "in_reply_to_status_id" : 372344478532923392,
  "created_at" : "2013-08-27 13:18:47 +0000",
  "in_reply_to_screen_name" : "id",
  "in_reply_to_user_id_str" : "13790742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian",
      "screen_name" : "id",
      "indices" : [ 0, 3 ],
      "id_str" : "13790742",
      "id" : 13790742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372344478532923392",
  "geo" : { },
  "id_str" : "372347362448273408",
  "in_reply_to_user_id" : 13790742,
  "text" : "@id take a look at the PRs and tell me which makes most sense. Heck, you can be a contributor if you want.",
  "id" : 372347362448273408,
  "in_reply_to_status_id" : 372344478532923392,
  "created_at" : "2013-08-27 13:18:23 +0000",
  "in_reply_to_screen_name" : "id",
  "in_reply_to_user_id_str" : "13790742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian",
      "screen_name" : "id",
      "indices" : [ 0, 3 ],
      "id_str" : "13790742",
      "id" : 13790742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372206928727777280",
  "geo" : { },
  "id_str" : "372338085175894016",
  "in_reply_to_user_id" : 13790742,
  "text" : "@id there are a few PRs to fix this but I haven\u2019t needed it yet. \u201CBeware\u201D feels a little linkbait-y.",
  "id" : 372338085175894016,
  "in_reply_to_status_id" : 372206928727777280,
  "created_at" : "2013-08-27 12:41:31 +0000",
  "in_reply_to_screen_name" : "id",
  "in_reply_to_user_id_str" : "13790742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Bell",
      "screen_name" : "BobBell",
      "indices" : [ 0, 8 ],
      "id_str" : "19549007",
      "id" : 19549007
    }, {
      "name" : "MarcLyon",
      "screen_name" : "MarcLyon",
      "indices" : [ 9, 18 ],
      "id_str" : "16843390",
      "id" : 16843390
    }, {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 19, 27 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372178524859154432",
  "geo" : { },
  "id_str" : "372189017460060161",
  "in_reply_to_user_id" : 19549007,
  "text" : "@BobBell @MarcLyon @jwright I\u2019d love to get the word out to more .NET folks about this, as a ruby refugee from vb\/c#\/asp",
  "id" : 372189017460060161,
  "in_reply_to_status_id" : 372178524859154432,
  "created_at" : "2013-08-27 02:49:11 +0000",
  "in_reply_to_screen_name" : "BobBell",
  "in_reply_to_user_id_str" : "19549007",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 9, 21 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372120297303851008",
  "geo" : { },
  "id_str" : "372164437765259264",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright @alanstevens agreed, wings are on me! :)",
  "id" : 372164437765259264,
  "in_reply_to_status_id" : 372120297303851008,
  "created_at" : "2013-08-27 01:11:31 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 50, 61 ],
      "id_str" : "381521407",
      "id" : 381521407
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 84, 99 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "accessibility",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372164321939574784",
  "text" : "RT @AustinSeraphin: All right! I will speak about @RubyMotion and #accessibility at @nickelcityruby on Friday September 20 at 01:30 pm!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 30, 41 ],
        "id_str" : "381521407",
        "id" : 381521407
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 64, 79 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "accessibility",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372138031891116032",
    "text" : "All right! I will speak about @RubyMotion and #accessibility at @nickelcityruby on Friday September 20 at 01:30 pm!",
    "id" : 372138031891116032,
    "created_at" : "2013-08-26 23:26:35 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 372164321939574784,
  "created_at" : "2013-08-27 01:11:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/gmeMlOQvCU",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "372164281871388672",
  "text" : "RT @jwright: You guys. Look at this schedule.\n http:\/\/t.co\/gmeMlOQvCU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/gmeMlOQvCU",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
        "display_url" : "nickelcityruby.com\/#schedule"
      } ]
    },
    "geo" : { },
    "id_str" : "372163809244639232",
    "text" : "You guys. Look at this schedule.\n http:\/\/t.co\/gmeMlOQvCU",
    "id" : 372163809244639232,
    "created_at" : "2013-08-27 01:09:01 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 372164281871388672,
  "created_at" : "2013-08-27 01:10:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372086300649611264",
  "geo" : { },
  "id_str" : "372107309230465024",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Metrics was a terrible, terrible class in the SE program. Lots of Word docs to fill out about bullshit, made up things",
  "id" : 372107309230465024,
  "in_reply_to_status_id" : 372086300649611264,
  "created_at" : "2013-08-26 21:24:30 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5bCmLMGE26",
      "expanded_url" : "http:\/\/quaran.to\/archive\/",
      "display_url" : "quaran.to\/archive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "372081643449626624",
  "text" : "Your semi-annual reminder to download (and maybe publish?) your Twitter archive for posterity\/etc: http:\/\/t.co\/5bCmLMGE26",
  "id" : 372081643449626624,
  "created_at" : "2013-08-26 19:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 12, 18 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372077117233586176",
  "geo" : { },
  "id_str" : "372077419894546432",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @tpope I've never had to wait more than a minute or two for an \"assist\". What a terrible name for the procedure.",
  "id" : 372077419894546432,
  "in_reply_to_status_id" : 372077117233586176,
  "created_at" : "2013-08-26 19:25:44 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372059882523869184",
  "text" : "BUFFALO, NY: SEVERE TWEETSTORM WARNING",
  "id" : 372059882523869184,
  "created_at" : "2013-08-26 18:16:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 3, 14 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/ytHbyXUBl5",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "372059828572545024",
  "text" : "RT @rachelober: Schedule is up for @nickelcityruby. Come see me and a whole bunch of awesome people in Buffalo in September! http:\/\/t.co\/yt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/ytHbyXUBl5",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
        "display_url" : "nickelcityruby.com\/#schedule"
      } ]
    },
    "geo" : { },
    "id_str" : "372051672169975809",
    "text" : "Schedule is up for @nickelcityruby. Come see me and a whole bunch of awesome people in Buffalo in September! http:\/\/t.co\/ytHbyXUBl5",
    "id" : 372051672169975809,
    "created_at" : "2013-08-26 17:43:25 +0000",
    "user" : {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "protected" : false,
      "id_str" : "14390268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321996605296640\/ekU7oNFN_normal.jpeg",
      "id" : 14390268,
      "verified" : false
    }
  },
  "id" : 372059828572545024,
  "created_at" : "2013-08-26 18:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 3, 14 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/7IYo5sFpAV",
      "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/coderetreat",
      "display_url" : "tito.io\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372059812898426880",
  "text" : "RT @Jonplussed: Fuck yeah Code Retreat https:\/\/t.co\/7IYo5sFpAV GET UP INS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/7IYo5sFpAV",
        "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/coderetreat",
        "display_url" : "tito.io\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372057032658255872",
    "text" : "Fuck yeah Code Retreat https:\/\/t.co\/7IYo5sFpAV GET UP INS",
    "id" : 372057032658255872,
    "created_at" : "2013-08-26 18:04:43 +0000",
    "user" : {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "protected" : false,
      "id_str" : "38408851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471328341526462464\/hNg5dFGn_normal.jpeg",
      "id" : 38408851,
      "verified" : false
    }
  },
  "id" : 372059812898426880,
  "created_at" : "2013-08-26 18:15:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 3, 8 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372050670074884098",
  "text" : "RT @rufo: I am totally signed up for everything at @nickelcityruby. If you\u2019re a Ruby dev remotely close to Buffalo and not, what\u2019s wrong wi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 41, 56 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372050410220953600",
    "text" : "I am totally signed up for everything at @nickelcityruby. If you\u2019re a Ruby dev remotely close to Buffalo and not, what\u2019s wrong with you?",
    "id" : 372050410220953600,
    "created_at" : "2013-08-26 17:38:24 +0000",
    "user" : {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "protected" : false,
      "id_str" : "710683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3506278060\/f3ad2d84b7ae3cb7fe43a016e6084e2b_normal.jpeg",
      "id" : 710683,
      "verified" : false
    }
  },
  "id" : 372050670074884098,
  "created_at" : "2013-08-26 17:39:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/irvUAjrp19",
      "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/coderetreat",
      "display_url" : "tito.io\/nickelcityruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372049130094223361",
  "text" : "RT @jhsu: Going to attend @nickelcityruby this september? Definitely sign up for CodeRetreat https:\/\/t.co\/irvUAjrp19 (really awesome)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 16, 31 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/irvUAjrp19",
        "expanded_url" : "https:\/\/tito.io\/nickelcityruby\/coderetreat",
        "display_url" : "tito.io\/nickelcityruby\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372046948120801280",
    "text" : "Going to attend @nickelcityruby this september? Definitely sign up for CodeRetreat https:\/\/t.co\/irvUAjrp19 (really awesome)",
    "id" : 372046948120801280,
    "created_at" : "2013-08-26 17:24:39 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 372049130094223361,
  "created_at" : "2013-08-26 17:33:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 3, 10 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 60, 75 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smashthemonolith",
      "indices" : [ 34, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372049108539674624",
  "text" : "RT @bantik: I\u2019ll be delivering my #smashthemonolith talk at @nickelcityruby on Saturday the 21st.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smashthemonolith",
        "indices" : [ 22, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372047777611542528",
    "text" : "I\u2019ll be delivering my #smashthemonolith talk at @nickelcityruby on Saturday the 21st.",
    "id" : 372047777611542528,
    "created_at" : "2013-08-26 17:27:57 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 372049108539674624,
  "created_at" : "2013-08-26 17:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/CPHL5nPJrn",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "372048472918093824",
  "text" : "Our schedule for @nickelcityruby is up! http:\/\/t.co\/CPHL5nPJrn (Have your ticket yet?)",
  "id" : 372048472918093824,
  "created_at" : "2013-08-26 17:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372021091499118592",
  "geo" : { },
  "id_str" : "372025865585958912",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw can't I be sarcastic too? :)",
  "id" : 372025865585958912,
  "in_reply_to_status_id" : 372021091499118592,
  "created_at" : "2013-08-26 16:00:52 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Stephen T Watson",
      "screen_name" : "buffaloscribe",
      "indices" : [ 32, 46 ],
      "id_str" : "14904704",
      "id" : 14904704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371720751608377344",
  "geo" : { },
  "id_str" : "372013974755098626",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski @nickelcityruby @buffaloscribe Done! Thanks for the loop in.",
  "id" : 372013974755098626,
  "in_reply_to_status_id" : 371720751608377344,
  "created_at" : "2013-08-26 15:13:37 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372013876067303427",
  "text" : "Hacker News on Linus' announcement of Linux on comp.os.minix: \"I have a hard time believing the authenticity of this\"",
  "id" : 372013876067303427,
  "created_at" : "2013-08-26 15:13:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "371995522267377664",
  "geo" : { },
  "id_str" : "371995735538929664",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens Will do (I can't even fathom that right now), but also of note: Many talks aren't Ruby-specific http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 371995735538929664,
  "in_reply_to_status_id" : 371995522267377664,
  "created_at" : "2013-08-26 14:01:09 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "371995095383687168",
  "geo" : { },
  "id_str" : "371995333875601408",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens definitely. Kind of sad you're on hiatus, as http:\/\/t.co\/3UAdoKZw7Q 's event and retreat will miss you.",
  "id" : 371995333875601408,
  "in_reply_to_status_id" : 371995095383687168,
  "created_at" : "2013-08-26 13:59:33 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "________________ ",
      "screen_name" : "phillmv",
      "indices" : [ 0, 8 ],
      "id_str" : "7518362",
      "id" : 7518362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371994696174039040",
  "geo" : { },
  "id_str" : "371994942555451393",
  "in_reply_to_user_id" : 7518362,
  "text" : "@phillmv First time i've heard of \"heatscore\"",
  "id" : 371994942555451393,
  "in_reply_to_status_id" : 371994696174039040,
  "created_at" : "2013-08-26 13:58:00 +0000",
  "in_reply_to_screen_name" : "phillmv",
  "in_reply_to_user_id_str" : "7518362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 24, 33 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KScfgi7G1q",
      "expanded_url" : "http:\/\/www.tomordonez.com\/blog\/2013\/08\/25\/the-hackathon-experience-is-a-hack\/",
      "display_url" : "tomordonez.com\/blog\/2013\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371994640896909312",
  "text" : "A huge reason I started @OpenHack: Hackathons are bullshit. http:\/\/t.co\/KScfgi7G1q",
  "id" : 371994640896909312,
  "created_at" : "2013-08-26 13:56:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Fqndgah62x",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/255010953677123584",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/SiiwZjPGIc",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/statuses\/193374401666879491",
      "display_url" : "twitter.com\/qrush\/statuses\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371992035705630720",
  "text" : "Going back to some TSA passive-aggressive behavior for opting out: https:\/\/t.co\/Fqndgah62x https:\/\/t.co\/SiiwZjPGIc",
  "id" : 371992035705630720,
  "created_at" : "2013-08-26 13:46:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371991652316872704",
  "text" : "I've gotten \u201CDon't you know that it's safe? That it's not an X-ray?\u201D nearly every time I've opted out. Don't listen to it.",
  "id" : 371991652316872704,
  "created_at" : "2013-08-26 13:44:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/MPtK8a8Okt",
      "expanded_url" : "http:\/\/orenhazi.com\/defeated.html",
      "display_url" : "orenhazi.com\/defeated.html"
    } ]
  },
  "geo" : { },
  "id_str" : "371988253290688512",
  "text" : "I'm still not defeated. I haven't been through the millimeter machines. Not even once. Feel bad for this: http:\/\/t.co\/MPtK8a8Okt",
  "id" : 371988253290688512,
  "created_at" : "2013-08-26 13:31:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/n9pEpcpPBh",
      "expanded_url" : "http:\/\/m.eastbayexpress.com\/oakland\/waste-the-dark-side-of-the-new-coffee-craze\/Content?oid=3687220",
      "display_url" : "m.eastbayexpress.com\/oakland\/waste-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371982238826508289",
  "text" : "RT @Croaky: Single-cup coffee pods taste worse and cost more than craft coffee. They're also bad for the environment. http:\/\/t.co\/n9pEpcpPBh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/n9pEpcpPBh",
        "expanded_url" : "http:\/\/m.eastbayexpress.com\/oakland\/waste-the-dark-side-of-the-new-coffee-craze\/Content?oid=3687220",
        "display_url" : "m.eastbayexpress.com\/oakland\/waste-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371334837321216001",
    "text" : "Single-cup coffee pods taste worse and cost more than craft coffee. They're also bad for the environment. http:\/\/t.co\/n9pEpcpPBh",
    "id" : 371334837321216001,
    "created_at" : "2013-08-24 18:14:58 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 371982238826508289,
  "created_at" : "2013-08-26 13:07:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aki the Conqueror",
      "screen_name" : "gesa",
      "indices" : [ 0, 5 ],
      "id_str" : "9321562",
      "id" : 9321562
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 6, 18 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 19, 34 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Dan Burkhart",
      "screen_name" : "deekomalley",
      "indices" : [ 35, 47 ],
      "id_str" : "5569332",
      "id" : 5569332
    }, {
      "name" : "Isaac Hall",
      "screen_name" : "isaachall",
      "indices" : [ 48, 58 ],
      "id_str" : "14958257",
      "id" : 14958257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371701384925556736",
  "geo" : { },
  "id_str" : "371753106029043712",
  "in_reply_to_user_id" : 9321562,
  "text" : "@gesa @juliepagano @nickelcityruby @deekomalley @isaachall I\u2019m Nick Quaranto and I approve this message. \uD83D\uDC4D\u2708\uFE0F\uD83D\uDE01",
  "id" : 371753106029043712,
  "in_reply_to_status_id" : 371701384925556736,
  "created_at" : "2013-08-25 21:57:01 +0000",
  "in_reply_to_screen_name" : "gesa",
  "in_reply_to_user_id_str" : "9321562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Stephen T Watson",
      "screen_name" : "buffaloscribe",
      "indices" : [ 32, 46 ],
      "id_str" : "14904704",
      "id" : 14904704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371720751608377344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9209744139, -78.8805143958 ]
  },
  "id_str" : "371752399993450497",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski @nickelcityruby @buffaloscribe will do, thanks!",
  "id" : 371752399993450497,
  "in_reply_to_status_id" : 371720751608377344,
  "created_at" : "2013-08-25 21:54:13 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/EWYn0k7FKY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OINa46HeWg8",
      "display_url" : "youtube.com\/watch?v=OINa46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371706266105561088",
  "text" : "RT @waxpancake: I Forgot My Phone, a short film about life in 2013. http:\/\/t.co\/EWYn0k7FKY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/EWYn0k7FKY",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OINa46HeWg8",
        "display_url" : "youtube.com\/watch?v=OINa46\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371502307097071616",
    "text" : "I Forgot My Phone, a short film about life in 2013. http:\/\/t.co\/EWYn0k7FKY",
    "id" : 371502307097071616,
    "created_at" : "2013-08-25 05:20:26 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539845905889775616\/_tilXA5z_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 371706266105561088,
  "created_at" : "2013-08-25 18:50:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371665957254483968",
  "geo" : { },
  "id_str" : "371666330971160577",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski @nickelcityruby figured :) if you know who to talk to at the News about it, that would be awesome!",
  "id" : 371666330971160577,
  "in_reply_to_status_id" : 371665957254483968,
  "created_at" : "2013-08-25 16:12:13 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 41, 56 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371664868685774848",
  "geo" : { },
  "id_str" : "371665701745864704",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski hoping to avoid this for @nickelcityruby\u2026just send a PR on Friday but could use some more love",
  "id" : 371665701745864704,
  "in_reply_to_status_id" : 371664868685774848,
  "created_at" : "2013-08-25 16:09:43 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 37, 48 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/W9ZtIXIR4x",
      "expanded_url" : "http:\/\/bethesignal.org\/wp-content\/uploads\/2009\/06\/css-is-awesome-700x375.jpg",
      "display_url" : "bethesignal.org\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370996520826716160",
  "geo" : { },
  "id_str" : "370996649604038657",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle http:\/\/t.co\/W9ZtIXIR4x \/cc @kevinpurdy",
  "id" : 370996649604038657,
  "in_reply_to_status_id" : 370996520826716160,
  "created_at" : "2013-08-23 19:51:08 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370996383219597312",
  "text" : "CSS padding\/margin order is top\/right\/bottom\/left, which is clockwise. How have I not figured this out until now?",
  "id" : 370996383219597312,
  "created_at" : "2013-08-23 19:50:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 17, 23 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370978960080764929",
  "geo" : { },
  "id_str" : "370979234707017728",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej if only @vrunt had a StarterKick. Or NewsHacker.",
  "id" : 370979234707017728,
  "in_reply_to_status_id" : 370978960080764929,
  "created_at" : "2013-08-23 18:41:56 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370978697911603201",
  "text" : "22 Things I Don't Give A Fuck About That BuzzFeed Has A Terribly Formatted List Strewn With Ads For",
  "id" : 370978697911603201,
  "created_at" : "2013-08-23 18:39:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 10, 18 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370974657932828672",
  "geo" : { },
  "id_str" : "370974757715341312",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges @capotej Rhombus!",
  "id" : 370974757715341312,
  "in_reply_to_status_id" : 370974657932828672,
  "created_at" : "2013-08-23 18:24:09 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370974282290978816",
  "text" : "\"Some people are working very hard to make Buffalo a place to be and they will succeed, but you should come here before that.\"",
  "id" : 370974282290978816,
  "created_at" : "2013-08-23 18:22:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TVPeHOWovC",
      "expanded_url" : "http:\/\/americanshortfiction.org\/2013\/08\/06\/things-american-buffalo\/",
      "display_url" : "americanshortfiction.org\/2013\/08\/06\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370973710707998720",
  "text" : "\"They might engrave your name on something. [...] They might shake your hand and ask you what you think of Buffalo.\" http:\/\/t.co\/TVPeHOWovC",
  "id" : 370973710707998720,
  "created_at" : "2013-08-23 18:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexander rakoczy",
      "screen_name" : "toothrot",
      "indices" : [ 0, 9 ],
      "id_str" : "14238988",
      "id" : 14238988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370972023112998912",
  "geo" : { },
  "id_str" : "370972208333479936",
  "in_reply_to_user_id" : 14238988,
  "text" : "@toothrot No.",
  "id" : 370972208333479936,
  "in_reply_to_status_id" : 370972023112998912,
  "created_at" : "2013-08-23 18:14:01 +0000",
  "in_reply_to_screen_name" : "toothrot",
  "in_reply_to_user_id_str" : "14238988",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/4AqPjlhvx7",
      "expanded_url" : "http:\/\/varnull.adityamukerjee.net\/post\/59021412512\/dont-fly-during-ramadan",
      "display_url" : "varnull.adityamukerjee.net\/post\/590214125\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370958663260708864",
  "text" : "This is just an absolutely frightening read. Imagine if you were in his shoes: http:\/\/t.co\/4AqPjlhvx7",
  "id" : 370958663260708864,
  "created_at" : "2013-08-23 17:20:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coderetreat",
      "screen_name" : "coderetreat",
      "indices" : [ 16, 28 ],
      "id_str" : "95819229",
      "id" : 95819229
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 46, 61 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/CPHL5nPJrn",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#schedule",
      "display_url" : "nickelcityruby.com\/#schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "370941925508927488",
  "text" : "Buffalo's first @coderetreat is the day after @nickelcityruby, and signup is now open! http:\/\/t.co\/CPHL5nPJrn",
  "id" : 370941925508927488,
  "created_at" : "2013-08-23 16:13:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370762439765139456",
  "text" : "Remember when Batman had nipples? That happened too.",
  "id" : 370762439765139456,
  "created_at" : "2013-08-23 04:20:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370742652255236096",
  "geo" : { },
  "id_str" : "370748950401150976",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant i saw you!",
  "id" : 370748950401150976,
  "in_reply_to_status_id" : 370742652255236096,
  "created_at" : "2013-08-23 03:26:52 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Doug Yun",
      "screen_name" : "dougyun",
      "indices" : [ 10, 18 ],
      "id_str" : "324160285",
      "id" : 324160285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370739480426057728",
  "geo" : { },
  "id_str" : "370739774039937024",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant @DougYun \/r\/battlestations worthy, just needs a toilet paper roll",
  "id" : 370739774039937024,
  "in_reply_to_status_id" : 370739480426057728,
  "created_at" : "2013-08-23 02:50:24 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 74, 89 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YXULdhQv24",
      "expanded_url" : "http:\/\/j.mp\/19Ms8OU",
      "display_url" : "j.mp\/19Ms8OU"
    } ]
  },
  "geo" : { },
  "id_str" : "370711372700454913",
  "text" : "RT @aspleenic: This is the best #Buffalo article I've ever read.  Come to @nickelcityruby to experience a piece of this - then stay http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 59, 74 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 17, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/YXULdhQv24",
        "expanded_url" : "http:\/\/j.mp\/19Ms8OU",
        "display_url" : "j.mp\/19Ms8OU"
      } ]
    },
    "geo" : { },
    "id_str" : "370616313611165696",
    "text" : "This is the best #Buffalo article I've ever read.  Come to @nickelcityruby to experience a piece of this - then stay http:\/\/t.co\/YXULdhQv24",
    "id" : 370616313611165696,
    "created_at" : "2013-08-22 18:39:49 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 370711372700454913,
  "created_at" : "2013-08-23 00:57:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Gould \u2622",
      "screen_name" : "u2622",
      "indices" : [ 3, 9 ],
      "id_str" : "19476127",
      "id" : 19476127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/FCQbW3WSpe",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "370711228953284608",
  "text" : "RT @u2622: Toronto devs, Nickel City Ruby will definitely be worth the trip down to Buffalo: http:\/\/t.co\/FCQbW3WSpe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/FCQbW3WSpe",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "370699546851962880",
    "text" : "Toronto devs, Nickel City Ruby will definitely be worth the trip down to Buffalo: http:\/\/t.co\/FCQbW3WSpe",
    "id" : 370699546851962880,
    "created_at" : "2013-08-23 00:10:33 +0000",
    "user" : {
      "name" : "Richard Gould \u2622",
      "screen_name" : "u2622",
      "protected" : false,
      "id_str" : "19476127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000581978514\/ab808be4b8c17cf0fa679e4f823e6b7e_normal.png",
      "id" : 19476127,
      "verified" : false
    }
  },
  "id" : 370711228953284608,
  "created_at" : "2013-08-23 00:56:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/CWbt4nrcy4",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "370698030258728960",
  "text" : "RT @thoughtbot: NickelCityRuby should be an excellent conference. We'll be there, will you? http:\/\/t.co\/CWbt4nrcy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/CWbt4nrcy4",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "370697579925086208",
    "text" : "NickelCityRuby should be an excellent conference. We'll be there, will you? http:\/\/t.co\/CWbt4nrcy4",
    "id" : 370697579925086208,
    "created_at" : "2013-08-23 00:02:44 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 370698030258728960,
  "created_at" : "2013-08-23 00:04:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#MagmaConf ",
      "screen_name" : "MagmaConf",
      "indices" : [ 0, 10 ],
      "id_str" : "137740103",
      "id" : 137740103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370670654904758272",
  "geo" : { },
  "id_str" : "370695053380833280",
  "in_reply_to_user_id" : 137740103,
  "text" : "@MagmaConf thanks so much for the &lt;3 !",
  "id" : 370695053380833280,
  "in_reply_to_status_id" : 370670654904758272,
  "created_at" : "2013-08-22 23:52:42 +0000",
  "in_reply_to_screen_name" : "MagmaConf",
  "in_reply_to_user_id_str" : "137740103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#MagmaConf ",
      "screen_name" : "MagmaConf",
      "indices" : [ 3, 13 ],
      "id_str" : "137740103",
      "id" : 137740103
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 65, 80 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/hUQFkLSioC",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "370695016475136000",
  "text" : "RT @MagmaConf: Hey Luchadores! We'd like to invite you to attend @NickelCityRuby at Buffalo, NY! \n\nMore info here: http:\/\/t.co\/hUQFkLSioC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 50, 65 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/hUQFkLSioC",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "370670654904758272",
    "text" : "Hey Luchadores! We'd like to invite you to attend @NickelCityRuby at Buffalo, NY! \n\nMore info here: http:\/\/t.co\/hUQFkLSioC",
    "id" : 370670654904758272,
    "created_at" : "2013-08-22 22:15:45 +0000",
    "user" : {
      "name" : "#MagmaConf ",
      "screen_name" : "MagmaConf",
      "protected" : false,
      "id_str" : "137740103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568811196464107520\/M68op8cK_normal.jpeg",
      "id" : 137740103,
      "verified" : false
    }
  },
  "id" : 370695016475136000,
  "created_at" : "2013-08-22 23:52:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Neukirchen",
      "screen_name" : "chneukirchen",
      "indices" : [ 0, 13 ],
      "id_str" : "1879351",
      "id" : 1879351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370656776532013056",
  "geo" : { },
  "id_str" : "370659666306416641",
  "in_reply_to_user_id" : 1879351,
  "text" : "@chneukirchen nope just some junk output",
  "id" : 370659666306416641,
  "in_reply_to_status_id" : 370656776532013056,
  "created_at" : "2013-08-22 21:32:05 +0000",
  "in_reply_to_screen_name" : "chneukirchen",
  "in_reply_to_user_id_str" : "1879351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370655773983907840",
  "text" : "Current status: nl([(l((((nl[l()u()((l(n))(l&gt;n()(n(u)n1()n[l(nnul1 )(&gt;ln)(nl(u))()()nu(l)u1n)u1lnuul)1 )nu&gt;nu)nl&gt;&gt;n)[ln&gt;ulnl&gt;lGu&gt;l1)ulll)G",
  "id" : 370655773983907840,
  "created_at" : "2013-08-22 21:16:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chrissalzman",
      "screen_name" : "chrissalzman",
      "indices" : [ 3, 16 ],
      "id_str" : "12597852",
      "id" : 12597852
    }, {
      "name" : "Workantile",
      "screen_name" : "workantile",
      "indices" : [ 64, 75 ],
      "id_str" : "23528527",
      "id" : 23528527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/L7F4dE8UwA",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/capitalonespark\/2013\/08\/21\/co-working-a-middle-ground-for-remote-workers\/",
      "display_url" : "forbes.com\/sites\/capitalo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370636257367302144",
  "text" : "RT @chrissalzman: Nice article on coworking full of quotes from @workantile folks: http:\/\/t.co\/L7F4dE8UwA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Workantile",
        "screen_name" : "workantile",
        "indices" : [ 46, 57 ],
        "id_str" : "23528527",
        "id" : 23528527
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/L7F4dE8UwA",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/capitalonespark\/2013\/08\/21\/co-working-a-middle-ground-for-remote-workers\/",
        "display_url" : "forbes.com\/sites\/capitalo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370593484882726912",
    "text" : "Nice article on coworking full of quotes from @workantile folks: http:\/\/t.co\/L7F4dE8UwA",
    "id" : 370593484882726912,
    "created_at" : "2013-08-22 17:09:06 +0000",
    "user" : {
      "name" : "chrissalzman",
      "screen_name" : "chrissalzman",
      "protected" : false,
      "id_str" : "12597852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471100884550557696\/V3dyzWCI_normal.jpeg",
      "id" : 12597852,
      "verified" : false
    }
  },
  "id" : 370636257367302144,
  "created_at" : "2013-08-22 19:59:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370635112200683521",
  "text" : "RT @zobar2: Chances are, if you have a class named Overlord, you might be violating the single responsibility principle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370634943396712448",
    "text" : "Chances are, if you have a class named Overlord, you might be violating the single responsibility principle.",
    "id" : 370634943396712448,
    "created_at" : "2013-08-22 19:53:51 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 370635112200683521,
  "created_at" : "2013-08-22 19:54:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 9, 18 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 19, 29 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370631292271865856",
  "geo" : { },
  "id_str" : "370631369564504064",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright @bquarant @aquaranto CCCCCOMBOOOO",
  "id" : 370631369564504064,
  "in_reply_to_status_id" : 370631292271865856,
  "created_at" : "2013-08-22 19:39:39 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergio t. ruiz",
      "screen_name" : "sergio_101",
      "indices" : [ 0, 11 ],
      "id_str" : "2676",
      "id" : 2676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370599389560991745",
  "geo" : { },
  "id_str" : "370606008827387904",
  "in_reply_to_user_id" : 2676,
  "text" : "@sergio_101 yes! You should! If you know of others locally interested please pass it on",
  "id" : 370606008827387904,
  "in_reply_to_status_id" : 370599389560991745,
  "created_at" : "2013-08-22 17:58:52 +0000",
  "in_reply_to_screen_name" : "sergio_101",
  "in_reply_to_user_id_str" : "2676",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Hayes",
      "screen_name" : "michaelhayes",
      "indices" : [ 3, 16 ],
      "id_str" : "7764332",
      "id" : 7764332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/XUpA23sq96",
      "expanded_url" : "http:\/\/twitpic.com\/d9q8t3",
      "display_url" : "twitpic.com\/d9q8t3"
    } ]
  },
  "geo" : { },
  "id_str" : "370580839416881152",
  "text" : "RT @michaelhayes: That time Obama was corrected by the crowd for forgetting the Mayor of Buffalo's name http:\/\/t.co\/XUpA23sq96",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/XUpA23sq96",
        "expanded_url" : "http:\/\/twitpic.com\/d9q8t3",
        "display_url" : "twitpic.com\/d9q8t3"
      } ]
    },
    "geo" : { },
    "id_str" : "370578500526170113",
    "text" : "That time Obama was corrected by the crowd for forgetting the Mayor of Buffalo's name http:\/\/t.co\/XUpA23sq96",
    "id" : 370578500526170113,
    "created_at" : "2013-08-22 16:09:34 +0000",
    "user" : {
      "name" : "Mike Hayes",
      "screen_name" : "michaelhayes",
      "protected" : false,
      "id_str" : "7764332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514783246261837824\/siTbQww__normal.jpeg",
      "id" : 7764332,
      "verified" : true
    }
  },
  "id" : 370580839416881152,
  "created_at" : "2013-08-22 16:18:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/UmM59Ep9UE",
      "expanded_url" : "http:\/\/store.makerbot.com\/digitizer.html?utm_source=mbs_email&utm_medium=email&utm_campaign=digitizersale_08222013&mkt_tok=3RkMMJWWfF9wsRonu6jMZKXonjHpfsX94uolUaCg38431UFwdcjKPmjr1YIBSMJ0aPyQAgobGp5I5FEMS7jYX7Jwt60IWw%253D%253D",
      "display_url" : "store.makerbot.com\/digitizer.html\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370579920721694720",
  "text" : "The future is awesome: http:\/\/t.co\/UmM59Ep9UE",
  "id" : 370579920721694720,
  "created_at" : "2013-08-22 16:15:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergio t. ruiz",
      "screen_name" : "sergio_101",
      "indices" : [ 0, 11 ],
      "id_str" : "2676",
      "id" : 2676
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 12, 21 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 22, 27 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/WpZx7XO16E",
      "expanded_url" : "http:\/\/news.wbfo.org\/post\/wny-conference-provides-support-computer-programmers",
      "display_url" : "news.wbfo.org\/post\/wny-confe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370573338336583680",
  "geo" : { },
  "id_str" : "370573499720425472",
  "in_reply_to_user_id" : 2676,
  "text" : "@sergio_101 @sabiddle @r00k http:\/\/t.co\/WpZx7XO16E",
  "id" : 370573499720425472,
  "in_reply_to_status_id" : 370573338336583680,
  "created_at" : "2013-08-22 15:49:41 +0000",
  "in_reply_to_screen_name" : "sergio_101",
  "in_reply_to_user_id_str" : "2676",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370570435131219968",
  "text" : "RT @aspleenic: I'm going to create a new talk: \"Test Driven Development: Let's Stop Talking About It\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370570342760079361",
    "text" : "I'm going to create a new talk: \"Test Driven Development: Let's Stop Talking About It\"",
    "id" : 370570342760079361,
    "created_at" : "2013-08-22 15:37:09 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 370570435131219968,
  "created_at" : "2013-08-22 15:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370566440467722241",
  "text" : "Hey, is the President in town?",
  "id" : 370566440467722241,
  "created_at" : "2013-08-22 15:21:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 42, 47 ],
      "id_str" : "20612109",
      "id" : 20612109
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 91, 97 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 102, 112 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7cbPStFg3t",
      "expanded_url" : "http:\/\/news.wbfo.org\/post\/wny-conference-provides-support-computer-programmers",
      "display_url" : "news.wbfo.org\/post\/wny-confe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370546921707802624",
  "text" : "RT @nickelcityruby: NickelCityRuby was on @WBFO this morning! Check out the interview with @qrush and @aquaranto  http:\/\/t.co\/7cbPStFg3t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WBFO",
        "screen_name" : "WBFO",
        "indices" : [ 22, 27 ],
        "id_str" : "20612109",
        "id" : 20612109
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 71, 77 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 82, 92 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/7cbPStFg3t",
        "expanded_url" : "http:\/\/news.wbfo.org\/post\/wny-conference-provides-support-computer-programmers",
        "display_url" : "news.wbfo.org\/post\/wny-confe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370546867689357313",
    "text" : "NickelCityRuby was on @WBFO this morning! Check out the interview with @qrush and @aquaranto  http:\/\/t.co\/7cbPStFg3t",
    "id" : 370546867689357313,
    "created_at" : "2013-08-22 14:03:52 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 370546921707802624,
  "created_at" : "2013-08-22 14:04:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 27, 33 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 38, 48 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/9QUMVAJ66B",
      "expanded_url" : "http:\/\/news.wbfo.org\/post\/wny-conference-provides-support-computer-programmers",
      "display_url" : "news.wbfo.org\/post\/wny-confe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370543682526920704",
  "text" : "RT @bquarant: Power couple @qrush and @aquaranto are in the news again, making Buffalo better http:\/\/t.co\/9QUMVAJ66B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 13, 19 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 24, 34 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/9QUMVAJ66B",
        "expanded_url" : "http:\/\/news.wbfo.org\/post\/wny-conference-provides-support-computer-programmers",
        "display_url" : "news.wbfo.org\/post\/wny-confe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370526294674386945",
    "text" : "Power couple @qrush and @aquaranto are in the news again, making Buffalo better http:\/\/t.co\/9QUMVAJ66B",
    "id" : 370526294674386945,
    "created_at" : "2013-08-22 12:42:07 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 370543682526920704,
  "created_at" : "2013-08-22 13:51:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 82, 91 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 92, 97 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "370517609529094144",
  "text" : "Related note: I got a photo of vim (and http:\/\/t.co\/2bA9BVLhWr) on NPR! Beat that @sabiddle @r00k.",
  "id" : 370517609529094144,
  "created_at" : "2013-08-22 12:07:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 51, 56 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Oval8y9alC",
      "expanded_url" : "http:\/\/ow.ly\/2zicrA",
      "display_url" : "ow.ly\/2zicrA"
    } ]
  },
  "geo" : { },
  "id_str" : "370517207928696832",
  "text" : "Just before Obama gets here, @nickelcityruby is on @WBFO and Innovation Trail today! http:\/\/t.co\/Oval8y9alC",
  "id" : 370517207928696832,
  "created_at" : "2013-08-22 12:06:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 3, 8 ],
      "id_str" : "20612109",
      "id" : 20612109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/B2D4tp5noh",
      "expanded_url" : "http:\/\/ow.ly\/2zicrA",
      "display_url" : "ow.ly\/2zicrA"
    } ]
  },
  "geo" : { },
  "id_str" : "370516952365535232",
  "text" : "RT @WBFO: WBFO News update WNY Conference provides support to computer programmers http:\/\/t.co\/B2D4tp5noh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/B2D4tp5noh",
        "expanded_url" : "http:\/\/ow.ly\/2zicrA",
        "display_url" : "ow.ly\/2zicrA"
      } ]
    },
    "geo" : { },
    "id_str" : "370479838219743232",
    "text" : "WBFO News update WNY Conference provides support to computer programmers http:\/\/t.co\/B2D4tp5noh",
    "id" : 370479838219743232,
    "created_at" : "2013-08-22 09:37:31 +0000",
    "user" : {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "protected" : false,
      "id_str" : "20612109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458688569347801088\/UcIrcXjC_normal.jpeg",
      "id" : 20612109,
      "verified" : false
    }
  },
  "id" : 370516952365535232,
  "created_at" : "2013-08-22 12:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 0, 3 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370391522325577728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9209323903, -78.8804865379 ]
  },
  "id_str" : "370395836347191296",
  "in_reply_to_user_id" : 1178441,
  "text" : "@aq \u201Cnot all who drink PBR are lost\u201D",
  "id" : 370395836347191296,
  "in_reply_to_status_id" : 370391522325577728,
  "created_at" : "2013-08-22 04:03:43 +0000",
  "in_reply_to_screen_name" : "aq",
  "in_reply_to_user_id_str" : "1178441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 3, 6 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370395700833435648",
  "text" : "RT @aq: Sometimes I wish I could be all brooklyn Gandalf and like *whistle* white bike named shadow fix appears. Rides into the park slope \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370391522325577728",
    "text" : "Sometimes I wish I could be all brooklyn Gandalf and like *whistle* white bike named shadow fix appears. Rides into the park slope night",
    "id" : 370391522325577728,
    "created_at" : "2013-08-22 03:46:35 +0000",
    "user" : {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "protected" : false,
      "id_str" : "1178441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480436105192677376\/-LIxJ6Db_normal.jpeg",
      "id" : 1178441,
      "verified" : false
    }
  },
  "id" : 370395700833435648,
  "created_at" : "2013-08-22 04:03:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Czuba",
      "screen_name" : "OneLessRegret",
      "indices" : [ 3, 17 ],
      "id_str" : "461774707",
      "id" : 461774707
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OneLessRegret\/status\/370366790766837760\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/GHD5iAd234",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSPOokDCAAEI3kL.jpg",
      "id_str" : "370366790640992257",
      "id" : 370366790640992257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSPOokDCAAEI3kL.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 679
      } ],
      "display_url" : "pic.twitter.com\/GHD5iAd234"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370395054319218690",
  "text" : "RT @OneLessRegret: Starting tomorrow. Go to Allen and Elmwood and get yourself some vegan (or non vegan) pizza. Support! http:\/\/t.co\/GHD5iA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OneLessRegret\/status\/370366790766837760\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/GHD5iAd234",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSPOokDCAAEI3kL.jpg",
        "id_str" : "370366790640992257",
        "id" : 370366790640992257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSPOokDCAAEI3kL.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 679
        } ],
        "display_url" : "pic.twitter.com\/GHD5iAd234"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370366790766837760",
    "text" : "Starting tomorrow. Go to Allen and Elmwood and get yourself some vegan (or non vegan) pizza. Support! http:\/\/t.co\/GHD5iAd234",
    "id" : 370366790766837760,
    "created_at" : "2013-08-22 02:08:18 +0000",
    "user" : {
      "name" : "Andy Czuba",
      "screen_name" : "OneLessRegret",
      "protected" : false,
      "id_str" : "461774707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1804855161\/GEnKo60h_normal",
      "id" : 461774707,
      "verified" : false
    }
  },
  "id" : 370395054319218690,
  "created_at" : "2013-08-22 04:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370385906638680065",
  "geo" : { },
  "id_str" : "370390204177059840",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo yes! After seeing it in Mule I agree. I\u2019ll catch this show tomorrow.",
  "id" : 370390204177059840,
  "in_reply_to_status_id" : 370385906638680065,
  "created_at" : "2013-08-22 03:41:20 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/DM0nLd6JqW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Area_code_707",
      "display_url" : "en.wikipedia.org\/wiki\/Area_code\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370377233040695296",
  "geo" : { },
  "id_str" : "370377695827222531",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen those canoes traveled far, 707 area code on them: http:\/\/t.co\/DM0nLd6JqW",
  "id" : 370377695827222531,
  "in_reply_to_status_id" : 370377233040695296,
  "created_at" : "2013-08-22 02:51:38 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370333086359490560",
  "geo" : { },
  "id_str" : "370333623297536000",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz 435 Canoe Not Found",
  "id" : 370333623297536000,
  "in_reply_to_status_id" : 370333086359490560,
  "created_at" : "2013-08-21 23:56:30 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/NlMawZ6czB",
      "expanded_url" : "http:\/\/flic.kr\/p\/fzbS1Z",
      "display_url" : "flic.kr\/p\/fzbS1Z"
    } ]
  },
  "geo" : { },
  "id_str" : "370332661882970112",
  "text" : "Canoe'd http:\/\/t.co\/NlMawZ6czB",
  "id" : 370332661882970112,
  "created_at" : "2013-08-21 23:52:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/370326579723116544\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/8hoi3JoY1n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSOqD-TIcAATB6Y.jpg",
      "id_str" : "370326579614085120",
      "id" : 370326579614085120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSOqD-TIcAATB6Y.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8hoi3JoY1n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370326579723116544",
  "text" : "Huge truck turnout for the Rodeo. 2 trucks from Rochester! http:\/\/t.co\/8hoi3JoY1n",
  "id" : 370326579723116544,
  "created_at" : "2013-08-21 23:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner  O'Malley",
      "screen_name" : "conner_omalley",
      "indices" : [ 3, 18 ],
      "id_str" : "980990414",
      "id" : 980990414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370317367084986369",
  "text" : "RT @conner_omalley: In 50 years, when fresh water is super expensive, we will have to explain it was partly because of super soakers &amp; foun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368942066568425472",
    "text" : "In 50 years, when fresh water is super expensive, we will have to explain it was partly because of super soakers &amp; fountains to our children",
    "id" : 368942066568425472,
    "created_at" : "2013-08-18 03:46:57 +0000",
    "user" : {
      "name" : "Conner  O'Malley",
      "screen_name" : "conner_omalley",
      "protected" : false,
      "id_str" : "980990414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2915663545\/4bce5b79e1a8b21dacd1a6da46b2426b_normal.jpeg",
      "id" : 980990414,
      "verified" : false
    }
  },
  "id" : 370317367084986369,
  "created_at" : "2013-08-21 22:51:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 112, 127 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/370306362913206272\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kDVtlC0s1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSOXrNPCMAA6yXH.jpg",
      "id_str" : "370306362917400576",
      "id" : 370306362917400576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSOXrNPCMAA6yXH.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kDVtlC0s1d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370306816317476866",
  "text" : "RT @zobar2: They plan to convert part of the H.H. Richardson Complex into a conference center. Future venue for @nickelcityruby? http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 100, 115 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zobar2\/status\/370306362913206272\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kDVtlC0s1d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSOXrNPCMAA6yXH.jpg",
        "id_str" : "370306362917400576",
        "id" : 370306362917400576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSOXrNPCMAA6yXH.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kDVtlC0s1d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370306362913206272",
    "text" : "They plan to convert part of the H.H. Richardson Complex into a conference center. Future venue for @nickelcityruby? http:\/\/t.co\/kDVtlC0s1d",
    "id" : 370306362913206272,
    "created_at" : "2013-08-21 22:08:11 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 370306816317476866,
  "created_at" : "2013-08-21 22:09:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 95, 110 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370296014990622720",
  "text" : "RT @rubiety: @qrush no doubt surveying the area in preparation for Obama's surprise keynote at @nickelcityruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 82, 97 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370224999543898112",
    "geo" : { },
    "id_str" : "370294134851895297",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush no doubt surveying the area in preparation for Obama's surprise keynote at @nickelcityruby",
    "id" : 370294134851895297,
    "in_reply_to_status_id" : 370224999543898112,
    "created_at" : "2013-08-21 21:19:36 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 370296014990622720,
  "created_at" : "2013-08-21 21:27:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370224999543898112",
  "text" : "US Secret Service badge spotted on an agent during lunch. \uD83D\uDE0E\uD83D\uDE31",
  "id" : 370224999543898112,
  "created_at" : "2013-08-21 16:44:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "zfesolcapee198",
      "screen_name" : "Wendy_RM",
      "indices" : [ 8, 17 ],
      "id_str" : "2982348851",
      "id" : 2982348851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369592529827946496",
  "geo" : { },
  "id_str" : "370206437344960512",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd @Wendy_RM Let's get year one done first! How about next month? :)",
  "id" : 370206437344960512,
  "in_reply_to_status_id" : 369592529827946496,
  "created_at" : "2013-08-21 15:31:07 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 3, 6 ],
      "id_str" : "937561",
      "id" : 937561
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370198321169588224",
  "text" : "RT @jm: Going to @nickelcityruby would almost be worth it just to get a proper beef on weck. If you\u2019ve never had one, then you have to go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 9, 24 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370195040993550336",
    "text" : "Going to @nickelcityruby would almost be worth it just to get a proper beef on weck. If you\u2019ve never had one, then you have to go.",
    "id" : 370195040993550336,
    "created_at" : "2013-08-21 14:45:50 +0000",
    "user" : {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "protected" : false,
      "id_str" : "937561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485973888715599872\/2FQpRyqG_normal.jpeg",
      "id" : 937561,
      "verified" : false
    }
  },
  "id" : 370198321169588224,
  "created_at" : "2013-08-21 14:58:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 4, 19 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370195040993550336",
  "geo" : { },
  "id_str" : "370198308167225344",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm @nickelcityruby Yes!!!!",
  "id" : 370198308167225344,
  "in_reply_to_status_id" : 370195040993550336,
  "created_at" : "2013-08-21 14:58:49 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/g6697deVzJ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
      "display_url" : "nickelcityruby.com\/#travel"
    } ]
  },
  "geo" : { },
  "id_str" : "370195291648966656",
  "text" : "RT @nickelcityruby: Never been to Buffalo? Register today for NickelCityRuby and come see all the amazing sights we have to offer! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/g6697deVzJ",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#travel",
        "display_url" : "nickelcityruby.com\/#travel"
      } ]
    },
    "geo" : { },
    "id_str" : "370194425424535552",
    "text" : "Never been to Buffalo? Register today for NickelCityRuby and come see all the amazing sights we have to offer! http:\/\/t.co\/g6697deVzJ",
    "id" : 370194425424535552,
    "created_at" : "2013-08-21 14:43:23 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 370195291648966656,
  "created_at" : "2013-08-21 14:46:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/w64jep8Ffh",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjHCX6KH",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjHC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370014989647495168",
  "text" : "View my 3 latest photos on Flickr: http:\/\/t.co\/w64jep8Ffh",
  "id" : 370014989647495168,
  "created_at" : "2013-08-21 02:50:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 61, 76 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Toledo",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370012291741130752",
  "text" : "RT @jwright: Thinking about organizing a group road trip for @nickelcityruby from #Toledo. \n\nIf you are interested let me know.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Toledo",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369967761147301888",
    "text" : "Thinking about organizing a group road trip for @nickelcityruby from #Toledo. \n\nIf you are interested let me know.",
    "id" : 369967761147301888,
    "created_at" : "2013-08-20 23:42:42 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 370012291741130752,
  "created_at" : "2013-08-21 02:39:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Draplin Design Co.",
      "screen_name" : "Draplin",
      "indices" : [ 3, 11 ],
      "id_str" : "14229273",
      "id" : 14229273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanks",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "oldsigns",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 129, 137 ]
    }, {
      "text" : "ny",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "rudyslayzk",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/n70tKpWaRp",
      "expanded_url" : "http:\/\/santorosigns.com\/signsofbuffalo.htm",
      "display_url" : "santorosigns.com\/signsofbuffalo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369913847034810368",
  "text" : "RT @Draplin: DDC6190: DAYWRECEKER WARNING: Buffalo, we love ya: http:\/\/t.co\/n70tKpWaRp Sent in by Justin Lowe! #thanks #oldsigns #buffalo #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thanks",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "oldsigns",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "ny",
        "indices" : [ 125, 128 ]
      }, {
        "text" : "rudyslayzk",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/n70tKpWaRp",
        "expanded_url" : "http:\/\/santorosigns.com\/signsofbuffalo.htm",
        "display_url" : "santorosigns.com\/signsofbuffalo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369911862554398720",
    "text" : "DDC6190: DAYWRECEKER WARNING: Buffalo, we love ya: http:\/\/t.co\/n70tKpWaRp Sent in by Justin Lowe! #thanks #oldsigns #buffalo #ny #rudyslayzk",
    "id" : 369911862554398720,
    "created_at" : "2013-08-20 20:00:35 +0000",
    "user" : {
      "name" : "Draplin Design Co.",
      "screen_name" : "Draplin",
      "protected" : false,
      "id_str" : "14229273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430582388\/Untitled-1_normal.jpg",
      "id" : 14229273,
      "verified" : false
    }
  },
  "id" : 369913847034810368,
  "created_at" : "2013-08-20 20:08:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369887000842600448",
  "text" : "Every time I make a commit: git commit -am \"DO THIS UP^W^W^WFixed actual bug due to reasons\"",
  "id" : 369887000842600448,
  "created_at" : "2013-08-20 18:21:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "indices" : [ 0, 10 ],
      "id_str" : "14846554",
      "id" : 14846554
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369878449445285888",
  "geo" : { },
  "id_str" : "369881713360379904",
  "in_reply_to_user_id" : 14846554,
  "text" : "@kfaustino @nickelcityruby That's where the power plugs are...so those seats will be quite valuable!",
  "id" : 369881713360379904,
  "in_reply_to_status_id" : 369878449445285888,
  "created_at" : "2013-08-20 18:00:47 +0000",
  "in_reply_to_screen_name" : "kfaustino",
  "in_reply_to_user_id_str" : "14846554",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/369877901610450944\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/4DECM3eMFv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSIR_ehCAAAP6yU.jpg",
      "id_str" : "369877901618839552",
      "id" : 369877901618839552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSIR_ehCAAAP6yU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4DECM3eMFv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "369878954028441600",
  "text" : "RT @nickelcityruby: Where will you sit for NickelCityRuby? http:\/\/t.co\/U1fBUeQnGv http:\/\/t.co\/4DECM3eMFv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/369877901610450944\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/4DECM3eMFv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSIR_ehCAAAP6yU.jpg",
        "id_str" : "369877901618839552",
        "id" : 369877901618839552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSIR_ehCAAAP6yU.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4DECM3eMFv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "369877901610450944",
    "text" : "Where will you sit for NickelCityRuby? http:\/\/t.co\/U1fBUeQnGv http:\/\/t.co\/4DECM3eMFv",
    "id" : 369877901610450944,
    "created_at" : "2013-08-20 17:45:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 369878954028441600,
  "created_at" : "2013-08-20 17:49:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Spector",
      "screen_name" : "GannettAlbany",
      "indices" : [ 0, 14 ],
      "id_str" : "159147860",
      "id" : 159147860
    }, {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 15, 24 ],
      "id_str" : "717973",
      "id" : 717973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369849523646234624",
  "geo" : { },
  "id_str" : "369860241862950912",
  "in_reply_to_user_id" : 159147860,
  "text" : "@GannettAlbany @ceejayoz RIT Building $$$",
  "id" : 369860241862950912,
  "in_reply_to_status_id" : 369849523646234624,
  "created_at" : "2013-08-20 16:35:27 +0000",
  "in_reply_to_screen_name" : "GannettAlbany",
  "in_reply_to_user_id_str" : "159147860",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369842198881136641",
  "geo" : { },
  "id_str" : "369842241432330242",
  "in_reply_to_user_id" : 5743852,
  "text" : "@popo Free shipping too!",
  "id" : 369842241432330242,
  "in_reply_to_status_id" : 369842198881136641,
  "created_at" : "2013-08-20 15:23:56 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369585034795036672",
  "geo" : { },
  "id_str" : "369842198881136641",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo Amazon. Seriously. Cheap.",
  "id" : 369842198881136641,
  "in_reply_to_status_id" : 369585034795036672,
  "created_at" : "2013-08-20 15:23:46 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 40, 49 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369833026592579584",
  "text" : "Going to wait until September to resume @openhack Buffalo. Craziness continues...",
  "id" : 369833026592579584,
  "created_at" : "2013-08-20 14:47:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 65, 80 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/cT47cbAPlo",
      "expanded_url" : "http:\/\/www2.jetblue.com\/deals\/the-leave-with-the-changing-leaves-sale",
      "display_url" : "www2.jetblue.com\/deals\/the-leav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369830549751201792",
  "text" : "Once again, insanely cheap flights to BUF ($69-BOS, $84-JFK) for @nickelcityruby: http:\/\/t.co\/cT47cbAPlo",
  "id" : 369830549751201792,
  "created_at" : "2013-08-20 14:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Hirtzel",
      "screen_name" : "AshleyHirtz",
      "indices" : [ 14, 26 ],
      "id_str" : "196353523",
      "id" : 196353523
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 43, 57 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 67, 82 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369829033074114560",
  "text" : "Big thanks to @AshleyHirtz for swinging by @coworkbuffalo to cover @nickelcityruby. Interview should air soon...THANKS OBAMA",
  "id" : 369829033074114560,
  "created_at" : "2013-08-20 14:31:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/U1fBUeQnGv",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "369818503550738433",
  "text" : "RT @nickelcityruby: NickelCityRuby is 31 days away!! 15 speakers over 2 awesome days in Buffalo. Do you have your ticket yet? http:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/U1fBUeQnGv",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "369818450350206977",
    "text" : "NickelCityRuby is 31 days away!! 15 speakers over 2 awesome days in Buffalo. Do you have your ticket yet? http:\/\/t.co\/U1fBUeQnGv",
    "id" : 369818450350206977,
    "created_at" : "2013-08-20 13:49:24 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 369818503550738433,
  "created_at" : "2013-08-20 13:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/9eqXVmhOjP",
      "expanded_url" : "http:\/\/www.teslamotors.com\/modelx\/",
      "display_url" : "teslamotors.com\/modelx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "369816353747660802",
  "text" : "\"Falcon Wings. Calling them doors would be an understatement.\" Drooling. http:\/\/t.co\/9eqXVmhOjP",
  "id" : 369816353747660802,
  "created_at" : "2013-08-20 13:41:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 3, 17 ],
      "id_str" : "15913837",
      "id" : 15913837
    }, {
      "name" : "Bitmaker Labs",
      "screen_name" : "bitmakerlabs",
      "indices" : [ 29, 42 ],
      "id_str" : "853592048",
      "id" : 853592048
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 72, 87 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369812983741833216",
  "text" : "RT @MutualArising: Anyone at @bitmakerlabs interested in a road trip to @nickelcityruby?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bitmaker Labs",
        "screen_name" : "bitmakerlabs",
        "indices" : [ 10, 23 ],
        "id_str" : "853592048",
        "id" : 853592048
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 53, 68 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369808808488742912",
    "text" : "Anyone at @bitmakerlabs interested in a road trip to @nickelcityruby?",
    "id" : 369808808488742912,
    "created_at" : "2013-08-20 13:11:05 +0000",
    "user" : {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "protected" : false,
      "id_str" : "15913837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000473983129\/c7b155bfe4b6374c5d3c517105d61a14_normal.jpeg",
      "id" : 15913837,
      "verified" : false
    }
  },
  "id" : 369812983741833216,
  "created_at" : "2013-08-20 13:27:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369637913471897601",
  "geo" : { },
  "id_str" : "369663599217610752",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west been playing since 2007 and still learning new things.",
  "id" : 369663599217610752,
  "in_reply_to_status_id" : 369637913471897601,
  "created_at" : "2013-08-20 03:34:04 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan R. Wallace",
      "screen_name" : "jonathanwallace",
      "indices" : [ 0, 16 ],
      "id_str" : "14162962",
      "id" : 14162962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369638467107815424",
  "geo" : { },
  "id_str" : "369663472784506880",
  "in_reply_to_user_id" : 14162962,
  "text" : "@jonathanwallace forgot the candelabrum up at the Valley. Starting the ascent with the Amulet in tow now, paused for tonight.",
  "id" : 369663472784506880,
  "in_reply_to_status_id" : 369638467107815424,
  "created_at" : "2013-08-20 03:33:34 +0000",
  "in_reply_to_screen_name" : "jonathanwallace",
  "in_reply_to_user_id_str" : "14162962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369637030768025600",
  "geo" : { },
  "id_str" : "369637498093187073",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west Nethack.",
  "id" : 369637498093187073,
  "in_reply_to_status_id" : 369637030768025600,
  "created_at" : "2013-08-20 01:50:21 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/369635615865700352\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/PGEX3IQt2X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSE1olxCAAE7sxv.png",
      "id_str" : "369635615869894657",
      "id" : 369635615869894657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSE1olxCAAE7sxv.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PGEX3IQt2X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369635615865700352",
  "text" : "Current status (Glad I'm chaotic...) http:\/\/t.co\/PGEX3IQt2X",
  "id" : 369635615865700352,
  "created_at" : "2013-08-20 01:42:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc13",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uzoAUg8Wt5",
      "expanded_url" : "http:\/\/j.mp\/16XpgsI",
      "display_url" : "j.mp\/16XpgsI"
    } ]
  },
  "geo" : { },
  "id_str" : "369630513444556800",
  "text" : "RT @nickelcityruby: In case you need more reasons than our speaker lineup to come to #ncrc13 - our grocery stores will blow your mind: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc13",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/uzoAUg8Wt5",
        "expanded_url" : "http:\/\/j.mp\/16XpgsI",
        "display_url" : "j.mp\/16XpgsI"
      } ]
    },
    "geo" : { },
    "id_str" : "369544829757173760",
    "text" : "In case you need more reasons than our speaker lineup to come to #ncrc13 - our grocery stores will blow your mind: http:\/\/t.co\/uzoAUg8Wt5",
    "id" : 369544829757173760,
    "created_at" : "2013-08-19 19:42:07 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 369630513444556800,
  "created_at" : "2013-08-20 01:22:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 89, 96 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/w7xUJ5Bh8h",
      "expanded_url" : "http:\/\/heartmindcode.com\/2013\/08\/16\/loyalty-and-layoffs\/",
      "display_url" : "heartmindcode.com\/2013\/08\/16\/loy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369630489813856257",
  "text" : "\"Being loyal to that is mere insanity\" http:\/\/t.co\/w7xUJ5Bh8h Great career insights from @dbrady",
  "id" : 369630489813856257,
  "created_at" : "2013-08-20 01:22:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369588875586310144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9266055767, -78.8766115811 ]
  },
  "id_str" : "369598732255629312",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder woot!",
  "id" : 369598732255629312,
  "in_reply_to_status_id" : 369588875586310144,
  "created_at" : "2013-08-19 23:16:19 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u0445\u043E\u0440\u0435\u0432a \u041F\u0435\u043B\u0430\u0433\u0435\u044F",
      "screen_name" : "Cooltendo",
      "indices" : [ 3, 13 ],
      "id_str" : "2833504365",
      "id" : 2833504365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/0dr0S4x1zN",
      "expanded_url" : "http:\/\/news.discovery.com\/history\/archaeology\/oldest-gaming-tokens-found-130814.htm",
      "display_url" : "news.discovery.com\/history\/archae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369587156961857538",
  "text" : "RT @Cooltendo: 5000 year old game pieces.\n\nhttp:\/\/t.co\/0dr0S4x1zN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/0dr0S4x1zN",
        "expanded_url" : "http:\/\/news.discovery.com\/history\/archaeology\/oldest-gaming-tokens-found-130814.htm",
        "display_url" : "news.discovery.com\/history\/archae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369586298731778048",
    "text" : "5000 year old game pieces.\n\nhttp:\/\/t.co\/0dr0S4x1zN",
    "id" : 369586298731778048,
    "created_at" : "2013-08-19 22:26:54 +0000",
    "user" : {
      "name" : "Philip Armstrong",
      "screen_name" : "SuperCooltendo",
      "protected" : false,
      "id_str" : "36224668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564017970003734528\/5_ZiKOzF_normal.png",
      "id" : 36224668,
      "verified" : false
    }
  },
  "id" : 369587156961857538,
  "created_at" : "2013-08-19 22:30:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/XP7Ke4svap",
      "expanded_url" : "http:\/\/www.catfactstexts.com\/",
      "display_url" : "catfactstexts.com"
    } ]
  },
  "geo" : { },
  "id_str" : "369575026455883776",
  "text" : "Considering signing up pesky car salesmen who keep calling us for http:\/\/t.co\/XP7Ke4svap. Revenge?",
  "id" : 369575026455883776,
  "created_at" : "2013-08-19 21:42:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "369569372529901568",
  "text" : "We have plenty of tickets left for http:\/\/t.co\/3UAdoKZw7Q 1 month away, you know what to do!",
  "id" : 369569372529901568,
  "created_at" : "2013-08-19 21:19:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mahmoud abdelkader",
      "screen_name" : "mahmoudimus",
      "indices" : [ 0, 12 ],
      "id_str" : "49254438",
      "id" : 49254438
    }, {
      "name" : "Matin Tamizi",
      "screen_name" : "matin",
      "indices" : [ 13, 19 ],
      "id_str" : "16166587",
      "id" : 16166587
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 20, 28 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "Balanced",
      "screen_name" : "balanced",
      "indices" : [ 29, 38 ],
      "id_str" : "551520084",
      "id" : 551520084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369551285596323841",
  "geo" : { },
  "id_str" : "369553759698825216",
  "in_reply_to_user_id" : 49254438,
  "text" : "@mahmoudimus @matin @whit537 @balanced I love baseball, dont pay much attention to it though. +1",
  "id" : 369553759698825216,
  "in_reply_to_status_id" : 369551285596323841,
  "created_at" : "2013-08-19 20:17:36 +0000",
  "in_reply_to_screen_name" : "mahmoudimus",
  "in_reply_to_user_id_str" : "49254438",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matin Tamizi",
      "screen_name" : "matin",
      "indices" : [ 0, 6 ],
      "id_str" : "16166587",
      "id" : 16166587
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 7, 15 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "Balanced",
      "screen_name" : "balanced",
      "indices" : [ 16, 25 ],
      "id_str" : "551520084",
      "id" : 551520084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369531571583205376",
  "geo" : { },
  "id_str" : "369549941045096448",
  "in_reply_to_user_id" : 16166587,
  "text" : "@matin @whit537 @balanced Is this actual customer data?!",
  "id" : 369549941045096448,
  "in_reply_to_status_id" : 369531571583205376,
  "created_at" : "2013-08-19 20:02:26 +0000",
  "in_reply_to_screen_name" : "matin",
  "in_reply_to_user_id_str" : "16166587",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369533584597471232",
  "text" : "\"This is written from my mind and not tested.\" StackOverLOL",
  "id" : 369533584597471232,
  "created_at" : "2013-08-19 18:57:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 12, 26 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369510752102518784",
  "geo" : { },
  "id_str" : "369511179002974209",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @buffalopundit Agreed. After living in an old textile mill in the Boston area I'd love to see more spaces like that here.",
  "id" : 369511179002974209,
  "in_reply_to_status_id" : 369510752102518784,
  "created_at" : "2013-08-19 17:28:24 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 3, 11 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 43, 50 ],
      "id_str" : "17416571",
      "id" : 17416571
    }, {
      "name" : "Flatiron School",
      "screen_name" : "FlatironSchool",
      "indices" : [ 77, 92 ],
      "id_str" : "702354494",
      "id" : 702354494
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 103, 118 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369501983549296640",
  "text" : "RT @ag_dubs: contemplating getting an epic @Airbnb in buffalo and throwing a @FlatironSchool party for @nickelcityruby -- any interest?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Airbnb",
        "screen_name" : "Airbnb",
        "indices" : [ 30, 37 ],
        "id_str" : "17416571",
        "id" : 17416571
      }, {
        "name" : "Flatiron School",
        "screen_name" : "FlatironSchool",
        "indices" : [ 64, 79 ],
        "id_str" : "702354494",
        "id" : 702354494
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 90, 105 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369490256036237312",
    "text" : "contemplating getting an epic @Airbnb in buffalo and throwing a @FlatironSchool party for @nickelcityruby -- any interest?",
    "id" : 369490256036237312,
    "created_at" : "2013-08-19 16:05:16 +0000",
    "user" : {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "protected" : false,
      "id_str" : "304067888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545742985921826816\/26ordwAe_normal.jpeg",
      "id" : 304067888,
      "verified" : false
    }
  },
  "id" : 369501983549296640,
  "created_at" : "2013-08-19 16:51:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 3, 11 ],
      "id_str" : "304067888",
      "id" : 304067888
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "blake johnson",
      "screen_name" : "blake41",
      "indices" : [ 54, 62 ],
      "id_str" : "7605412",
      "id" : 7605412
    }, {
      "name" : "Joe Burgess",
      "screen_name" : "jmburges",
      "indices" : [ 67, 76 ],
      "id_str" : "47312435",
      "id" : 47312435
    }, {
      "name" : "Flatiron School",
      "screen_name" : "FlatironSchool",
      "indices" : [ 86, 101 ],
      "id_str" : "702354494",
      "id" : 702354494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369487215987924993",
  "text" : "RT @ag_dubs: just registered for @nickelcityruby with @blake41 and @jmburges . woohoo @FlatironSchool party!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 20, 35 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "blake johnson",
        "screen_name" : "blake41",
        "indices" : [ 41, 49 ],
        "id_str" : "7605412",
        "id" : 7605412
      }, {
        "name" : "Joe Burgess",
        "screen_name" : "jmburges",
        "indices" : [ 54, 63 ],
        "id_str" : "47312435",
        "id" : 47312435
      }, {
        "name" : "Flatiron School",
        "screen_name" : "FlatironSchool",
        "indices" : [ 73, 88 ],
        "id_str" : "702354494",
        "id" : 702354494
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369480053286920192",
    "text" : "just registered for @nickelcityruby with @blake41 and @jmburges . woohoo @FlatironSchool party!",
    "id" : 369480053286920192,
    "created_at" : "2013-08-19 15:24:43 +0000",
    "user" : {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "protected" : false,
      "id_str" : "304067888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545742985921826816\/26ordwAe_normal.jpeg",
      "id" : 304067888,
      "verified" : false
    }
  },
  "id" : 369487215987924993,
  "created_at" : "2013-08-19 15:53:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Forde",
      "screen_name" : "peteforde",
      "indices" : [ 0, 10 ],
      "id_str" : "18212523",
      "id" : 18212523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369475584033710080",
  "geo" : { },
  "id_str" : "369478200104984576",
  "in_reply_to_user_id" : 18212523,
  "text" : "@peteforde done!",
  "id" : 369478200104984576,
  "in_reply_to_status_id" : 369475584033710080,
  "created_at" : "2013-08-19 15:17:22 +0000",
  "in_reply_to_screen_name" : "peteforde",
  "in_reply_to_user_id_str" : "18212523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 54, 61 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369469685772730370",
  "geo" : { },
  "id_str" : "369469940484411392",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante yes, expect an email soonly! working with @nb3004 on design.",
  "id" : 369469940484411392,
  "in_reply_to_status_id" : 369469685772730370,
  "created_at" : "2013-08-19 14:44:32 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Pete Forde",
      "screen_name" : "peteforde",
      "indices" : [ 11, 21 ],
      "id_str" : "18212523",
      "id" : 18212523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368855227471904768",
  "geo" : { },
  "id_str" : "369468728628350976",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @peteforde Signed up via the unspace site too...is it tonight? I don't know I can make it if so...",
  "id" : 369468728628350976,
  "in_reply_to_status_id" : 368855227471904768,
  "created_at" : "2013-08-19 14:39:43 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369467998706229248",
  "text" : "Officially 1 month away from @nickelcityruby festivities! Enter panic^H^H^H^H^H AWESOME mode!!",
  "id" : 369467998706229248,
  "created_at" : "2013-08-19 14:36:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 21, 35 ],
      "id_str" : "25321479",
      "id" : 25321479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/0UkRb03ArR",
      "expanded_url" : "http:\/\/www.buffalo.com\/sports\/blog\/heres-why-i-avoid-the-color-run-opinion\/51062",
      "display_url" : "buffalo.com\/sports\/blog\/he\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369441455426650112",
  "text" : "RT @kevinpurdy: Good @BuffaloDotCom post on chin-scratching revenues behind \"fun run\" trend: http:\/\/t.co\/0UkRb03ArR Seem like charity, but \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Dot Com",
        "screen_name" : "BuffaloDotCom",
        "indices" : [ 5, 19 ],
        "id_str" : "25321479",
        "id" : 25321479
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/0UkRb03ArR",
        "expanded_url" : "http:\/\/www.buffalo.com\/sports\/blog\/heres-why-i-avoid-the-color-run-opinion\/51062",
        "display_url" : "buffalo.com\/sports\/blog\/he\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369440179045408768",
    "text" : "Good @BuffaloDotCom post on chin-scratching revenues behind \"fun run\" trend: http:\/\/t.co\/0UkRb03ArR Seem like charity, but mostly not.",
    "id" : 369440179045408768,
    "created_at" : "2013-08-19 12:46:17 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 369441455426650112,
  "created_at" : "2013-08-19 12:51:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369223870705721344",
  "geo" : { },
  "id_str" : "369285192906579970",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky Congrats!!!",
  "id" : 369285192906579970,
  "in_reply_to_status_id" : 369223870705721344,
  "created_at" : "2013-08-19 02:30:25 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369261678128410624",
  "geo" : { },
  "id_str" : "369262333123502080",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx Quite possibly the best video\/avatar combo ever?",
  "id" : 369262333123502080,
  "in_reply_to_status_id" : 369261678128410624,
  "created_at" : "2013-08-19 00:59:35 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 73, 84 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 85, 96 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/wxru2tdQGN",
      "expanded_url" : "http:\/\/www.youandwho.com\/sale?p=102",
      "display_url" : "youandwho.com\/sale?p=102"
    } ]
  },
  "geo" : { },
  "id_str" : "369261729080823808",
  "text" : "Cleveland people, this is an awesome t-shirt: http:\/\/t.co\/wxru2tdQGN \/cc @joefiorini @benjaminws etc!",
  "id" : 369261729080823808,
  "created_at" : "2013-08-19 00:57:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 6, 20 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369095915262341120",
  "geo" : { },
  "id_str" : "369100233185034240",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @Carols10cents Starting to prefer the latter.",
  "id" : 369100233185034240,
  "in_reply_to_status_id" : 369095915262341120,
  "created_at" : "2013-08-18 14:15:27 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 15, 20 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369092366876962817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.1120772164, -79.9562749979 ]
  },
  "id_str" : "369095520821592064",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @avdi also curious :)",
  "id" : 369095520821592064,
  "in_reply_to_status_id" : 369092366876962817,
  "created_at" : "2013-08-18 13:56:44 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boxxa",
      "screen_name" : "boxxa",
      "indices" : [ 0, 6 ],
      "id_str" : "14103421",
      "id" : 14103421
    }, {
      "name" : "John K.",
      "screen_name" : "theprogrocker",
      "indices" : [ 7, 21 ],
      "id_str" : "16937302",
      "id" : 16937302
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 22, 36 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/mdxVPx70sc",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "368872562383536128",
  "geo" : { },
  "id_str" : "368953497879711744",
  "in_reply_to_user_id" : 14103421,
  "text" : "@boxxa @theprogrocker @coworkbuffalo I\u2019d be more than happy to answer anything :) nick [at] http:\/\/t.co\/mdxVPx70sc if that\u2019s easier",
  "id" : 368953497879711744,
  "in_reply_to_status_id" : 368872562383536128,
  "created_at" : "2013-08-18 04:32:23 +0000",
  "in_reply_to_screen_name" : "boxxa",
  "in_reply_to_user_id_str" : "14103421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSW is now WCC",
      "screen_name" : "webstartwomen",
      "indices" : [ 0, 14 ],
      "id_str" : "2183597364",
      "id" : 2183597364
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Ladies Learning Code",
      "screen_name" : "llcodedotcom",
      "indices" : [ 31, 44 ],
      "id_str" : "2844567866",
      "id" : 2844567866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368951460609798146",
  "geo" : { },
  "id_str" : "368952534091575296",
  "in_reply_to_user_id" : 283710953,
  "text" : "@webstartwomen @nickelcityruby @llcodedotcom nope! Thanks for spreading the news. Would love to get more down from Toronto :)",
  "id" : 368952534091575296,
  "in_reply_to_status_id" : 368951460609798146,
  "created_at" : "2013-08-18 04:28:33 +0000",
  "in_reply_to_screen_name" : "WeAreWCC",
  "in_reply_to_user_id_str" : "283710953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 11, 16 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368952266239143936",
  "geo" : { },
  "id_str" : "368952354134966272",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh @r00k huge +1",
  "id" : 368952354134966272,
  "in_reply_to_status_id" : 368952266239143936,
  "created_at" : "2013-08-18 04:27:50 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Forde",
      "screen_name" : "peteforde",
      "indices" : [ 0, 10 ],
      "id_str" : "18212523",
      "id" : 18212523
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 11, 26 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 115, 130 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368855020608819201",
  "geo" : { },
  "id_str" : "368952186731905024",
  "in_reply_to_user_id" : 18212523,
  "text" : "@peteforde @nickelcityruby nick [at] quaran.to here. Not sure what this is but I\u2019ll take any excuse to shout about @nickelcityruby",
  "id" : 368952186731905024,
  "in_reply_to_status_id" : 368855020608819201,
  "created_at" : "2013-08-18 04:27:10 +0000",
  "in_reply_to_screen_name" : "peteforde",
  "in_reply_to_user_id_str" : "18212523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368951338991759360",
  "geo" : { },
  "id_str" : "368951926274007040",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k I think so. Also tired, need to think about this more. I guess just saying there\u2019s many more ways to improve, not all are skill based",
  "id" : 368951926274007040,
  "in_reply_to_status_id" : 368951338991759360,
  "created_at" : "2013-08-18 04:26:08 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368946362961764353",
  "geo" : { },
  "id_str" : "368951042001494016",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k lots of ego based assumptions here. Nothing about humility. I feel there\u2019s more than just \u201Cbe the worst\u201D",
  "id" : 368951042001494016,
  "in_reply_to_status_id" : 368946362961764353,
  "created_at" : "2013-08-18 04:22:37 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "indices" : [ 3, 8 ],
      "id_str" : "1385921",
      "id" : 1385921
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 48, 54 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 55, 65 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/d00n\/status\/368762355305299969\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/M4o6vh5M28",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BR4baIsCQAAXWP2.jpg",
      "id_str" : "368762355313688576",
      "id" : 368762355313688576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR4baIsCQAAXWP2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/M4o6vh5M28"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368769539619975168",
  "text" : "RT @d00n: Getting ready for @nickelcityruby \/cc @qrush @aquaranto http:\/\/t.co\/M4o6vh5M28",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 18, 33 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 38, 44 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 45, 55 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/d00n\/status\/368762355305299969\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/M4o6vh5M28",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BR4baIsCQAAXWP2.jpg",
        "id_str" : "368762355313688576",
        "id" : 368762355313688576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR4baIsCQAAXWP2.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/M4o6vh5M28"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368762355305299969",
    "text" : "Getting ready for @nickelcityruby \/cc @qrush @aquaranto http:\/\/t.co\/M4o6vh5M28",
    "id" : 368762355305299969,
    "created_at" : "2013-08-17 15:52:51 +0000",
    "user" : {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "protected" : false,
      "id_str" : "1385921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430783022372118528\/K9pIL3o8_normal.jpeg",
      "id" : 1385921,
      "verified" : false
    }
  },
  "id" : 368769539619975168,
  "created_at" : "2013-08-17 16:21:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Nale",
      "screen_name" : "jonnale",
      "indices" : [ 0, 8 ],
      "id_str" : "29127311",
      "id" : 29127311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/26zr2H4k8E",
      "expanded_url" : "http:\/\/www.lensrentals.com\/blog\/2013\/05\/how-to-ruin-your-gear-in-5-minutes-without-water",
      "display_url" : "lensrentals.com\/blog\/2013\/05\/h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368755964125519872",
  "geo" : { },
  "id_str" : "368756536945811456",
  "in_reply_to_user_id" : 29127311,
  "text" : "@jonnale have you seen http:\/\/t.co\/26zr2H4k8E ?",
  "id" : 368756536945811456,
  "in_reply_to_status_id" : 368755964125519872,
  "created_at" : "2013-08-17 15:29:44 +0000",
  "in_reply_to_screen_name" : "jonnale",
  "in_reply_to_user_id_str" : "29127311",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathieu Allaire",
      "screen_name" : "allaire",
      "indices" : [ 3, 11 ],
      "id_str" : "16617671",
      "id" : 16617671
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368455270877233152",
  "text" : "RT @allaire: @qrush MURICA!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "368452024133619712",
    "geo" : { },
    "id_str" : "368455133149290496",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush MURICA!",
    "id" : 368455133149290496,
    "in_reply_to_status_id" : 368452024133619712,
    "created_at" : "2013-08-16 19:32:03 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Mathieu Allaire",
      "screen_name" : "allaire",
      "protected" : false,
      "id_str" : "16617671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572592195979329536\/xXRP2Iog_normal.png",
      "id" : 16617671,
      "verified" : false
    }
  },
  "id" : 368455270877233152,
  "created_at" : "2013-08-16 19:32:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/pYoPpZGTRu",
      "expanded_url" : "http:\/\/reportermag.com\/",
      "display_url" : "reportermag.com"
    } ]
  },
  "geo" : { },
  "id_str" : "368454459141005312",
  "text" : "What happened to http:\/\/t.co\/pYoPpZGTRu, RIT grads?!",
  "id" : 368454459141005312,
  "created_at" : "2013-08-16 19:29:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368452191561854976",
  "geo" : { },
  "id_str" : "368452227825811456",
  "in_reply_to_user_id" : 5743852,
  "text" : "@TommyCreenan oops, SNES. Not N64.",
  "id" : 368452227825811456,
  "in_reply_to_status_id" : 368452191561854976,
  "created_at" : "2013-08-16 19:20:31 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368452009126801409",
  "geo" : { },
  "id_str" : "368452191561854976",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan buying one? I found an N64 at a yard sale for $25 with 12+ games",
  "id" : 368452191561854976,
  "in_reply_to_status_id" : 368452009126801409,
  "created_at" : "2013-08-16 19:20:22 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368452024133619712",
  "text" : "Just realized I have a lawyer but not a doctor.",
  "id" : 368452024133619712,
  "created_at" : "2013-08-16 19:19:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem van Bergen",
      "screen_name" : "wvanbergen",
      "indices" : [ 0, 11 ],
      "id_str" : "116877599",
      "id" : 116877599
    }, {
      "name" : "James Chevalier",
      "screen_name" : "JamesChevalier",
      "indices" : [ 12, 27 ],
      "id_str" : "19874511",
      "id" : 19874511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368442433920450560",
  "geo" : { },
  "id_str" : "368443143219183616",
  "in_reply_to_user_id" : 116877599,
  "text" : "@wvanbergen @JamesChevalier awesome!",
  "id" : 368443143219183616,
  "in_reply_to_status_id" : 368442433920450560,
  "created_at" : "2013-08-16 18:44:25 +0000",
  "in_reply_to_screen_name" : "wvanbergen",
  "in_reply_to_user_id_str" : "116877599",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/ad4WkpWkkv",
      "expanded_url" : "https:\/\/github.com\/123123123123123123123123",
      "display_url" : "github.com\/12312312312312\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368442589671743488",
  "text" : "Yep: https:\/\/t.co\/ad4WkpWkkv",
  "id" : 368442589671743488,
  "created_at" : "2013-08-16 18:42:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "12 Grain",
      "screen_name" : "12grainstudio",
      "indices" : [ 0, 14 ],
      "id_str" : "15650314",
      "id" : 15650314
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 75, 89 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368438420663570432",
  "geo" : { },
  "id_str" : "368438705096114176",
  "in_reply_to_user_id" : 15650314,
  "text" : "@12grainstudio This is why we have trail mix, coffee, and a fridge of beer @coworkbuffalo :) Hope your friday improves!",
  "id" : 368438705096114176,
  "in_reply_to_status_id" : 368438420663570432,
  "created_at" : "2013-08-16 18:26:47 +0000",
  "in_reply_to_screen_name" : "12grainstudio",
  "in_reply_to_user_id_str" : "15650314",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Working Group",
      "screen_name" : "TWG",
      "indices" : [ 0, 4 ],
      "id_str" : "123278675",
      "id" : 123278675
    }, {
      "name" : "Paul  Kalupnieks ",
      "screen_name" : "kalupa",
      "indices" : [ 5, 12 ],
      "id_str" : "2355",
      "id" : 2355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368433249535938560",
  "geo" : { },
  "id_str" : "368435420830240768",
  "in_reply_to_user_id" : 123278675,
  "text" : "@TWG @kalupa can do, thanks!!",
  "id" : 368435420830240768,
  "in_reply_to_status_id" : 368433249535938560,
  "created_at" : "2013-08-16 18:13:44 +0000",
  "in_reply_to_screen_name" : "TWG",
  "in_reply_to_user_id_str" : "123278675",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368435345513127936",
  "text" : "P\u0308\u0369\u0368\u0309\u0301\u034A\u0357\u0336\u0345\u033A\u033C\u0333L\u0306\u0351\u036E\u030B\u036E\u030E\u030C\u0355\u0356\u0332\u0355\u0329E\u0313\u0301\u0323\u032AA\u034B\u036D\u030C\u030D\u0314\u0308\u0329\u0325\u0317\u0347S\u036F\u0309\u0369\u0320\u0329E\u0312\u031A\u0312\u0309\u0346\u030E\u034E\u031D\u032E\u032E\u0348 \u0344\u0321\u032E\u0319\u0331\u0323\u0324\u0359A\u030C\u0305\u0309D\u0328\u0331V\u0338\u034D\u0355\u032BI\u0312\u0311\u0343\u0369\u0349\u0347\u032E\u0318\u0325\u032AS\u0366\u034A\u0346\u0314\u0344\u0345\u0325\u031D\u033AE\u0311\u034A\u034A\u032E\u033B\u033A",
  "id" : 368435345513127936,
  "created_at" : "2013-08-16 18:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368423056345014272",
  "geo" : { },
  "id_str" : "368423670042992640",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren The Day I Stopped Worrying And Learned to Love the Ramblings",
  "id" : 368423670042992640,
  "in_reply_to_status_id" : 368423056345014272,
  "created_at" : "2013-08-16 17:27:02 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Faustino",
      "screen_name" : "kfaustino",
      "indices" : [ 0, 10 ],
      "id_str" : "14846554",
      "id" : 14846554
    }, {
      "name" : "Toronto Ruby Brigade",
      "screen_name" : "torontorb",
      "indices" : [ 11, 21 ],
      "id_str" : "154543290",
      "id" : 154543290
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 56, 66 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368422337609486336",
  "geo" : { },
  "id_str" : "368423367738548225",
  "in_reply_to_user_id" : 14846554,
  "text" : "@kfaustino @torontorb Yes! I was going to email you via @aspleenic :) I'd love to come up and visit, give a talk before the conf hits.",
  "id" : 368423367738548225,
  "in_reply_to_status_id" : 368422337609486336,
  "created_at" : "2013-08-16 17:25:50 +0000",
  "in_reply_to_screen_name" : "kfaustino",
  "in_reply_to_user_id_str" : "14846554",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chevalier",
      "screen_name" : "JamesChevalier",
      "indices" : [ 0, 15 ],
      "id_str" : "19874511",
      "id" : 19874511
    }, {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 107, 112 ],
      "id_str" : "676573",
      "id" : 676573
    }, {
      "name" : "Cody Fauser",
      "screen_name" : "codyfauser",
      "indices" : [ 113, 124 ],
      "id_str" : "14996079",
      "id" : 14996079
    }, {
      "name" : "Jesse Storimer",
      "screen_name" : "jstorimer",
      "indices" : [ 125, 135 ],
      "id_str" : "22868382",
      "id" : 22868382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368414288517816320",
  "geo" : { },
  "id_str" : "368415212610658306",
  "in_reply_to_user_id" : 19874511,
  "text" : "@JamesChevalier I've love to see some Shopify folks make it. &lt; 2 hours depending on bridge traffic. \/cc @tobi @codyfauser @jstorimer",
  "id" : 368415212610658306,
  "in_reply_to_status_id" : 368414288517816320,
  "created_at" : "2013-08-16 16:53:26 +0000",
  "in_reply_to_screen_name" : "JamesChevalier",
  "in_reply_to_user_id_str" : "19874511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 103, 118 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368406402571587584",
  "text" : "Hey, who knows Ruby, Rails, JS, web, dev people\/companies in Toronto? I want to get the word out about @nickelcityruby to them.",
  "id" : 368406402571587584,
  "created_at" : "2013-08-16 16:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 13, 26 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368390174670995456",
  "geo" : { },
  "id_str" : "368390284712755201",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @stevenharman Visual format syntax is surprisingly awesome.",
  "id" : 368390284712755201,
  "in_reply_to_status_id" : 368390174670995456,
  "created_at" : "2013-08-16 15:14:22 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368371736049221633",
  "geo" : { },
  "id_str" : "368379362057682945",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby and awesome AMMO crates",
  "id" : 368379362057682945,
  "in_reply_to_status_id" : 368371736049221633,
  "created_at" : "2013-08-16 14:30:58 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 17, 31 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 98, 113 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368378837677006848",
  "text" : "To my friends at @SteelCityRuby: Have an awesome time, close your laptop, and start planning your @nickelcityruby trip!",
  "id" : 368378837677006848,
  "created_at" : "2013-08-16 14:28:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368253326405550080",
  "geo" : { },
  "id_str" : "368253484891533312",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren oh geez, maybe another night ;)",
  "id" : 368253484891533312,
  "in_reply_to_status_id" : 368253326405550080,
  "created_at" : "2013-08-16 06:10:47 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368252658701709312",
  "geo" : { },
  "id_str" : "368253132737744897",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren we need to get you ascended. Valkyrie time!",
  "id" : 368253132737744897,
  "in_reply_to_status_id" : 368252658701709312,
  "created_at" : "2013-08-16 06:09:23 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368247990521044992",
  "geo" : { },
  "id_str" : "368251020037472257",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat 8 times. Trying to get all the classes. Ranger right now might have a chance.",
  "id" : 368251020037472257,
  "in_reply_to_status_id" : 368247990521044992,
  "created_at" : "2013-08-16 06:00:59 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/J0CW1dE8RW",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-all.php?player=DoctorNick&sort=1",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368246089062690816",
  "text" : "Correction, it's been 6+ years playing NetHack. I love that these stats are available: http:\/\/t.co\/J0CW1dE8RW",
  "id" : 368246089062690816,
  "created_at" : "2013-08-16 05:41:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel",
      "screen_name" : "JoelMcCracken",
      "indices" : [ 0, 14 ],
      "id_str" : "13053562",
      "id" : 13053562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368205588406472704",
  "geo" : { },
  "id_str" : "368208918461165569",
  "in_reply_to_user_id" : 13053562,
  "text" : "@JoelMcCracken yes, love it. Hoping for a meaningful update to Fortress mode this...year? :(",
  "id" : 368208918461165569,
  "in_reply_to_status_id" : 368205588406472704,
  "created_at" : "2013-08-16 03:13:41 +0000",
  "in_reply_to_screen_name" : "JoelMcCracken",
  "in_reply_to_user_id_str" : "13053562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/FTg4zjTrMD",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368203722804850689",
  "text" : "Over 5 years of playing NetHack and still discovering new things. I should write more about this game. http:\/\/t.co\/FTg4zjTrMD",
  "id" : 368203722804850689,
  "created_at" : "2013-08-16 02:53:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368149034965270528",
  "text" : "There's some getting around it with certain protocols, but there doesn't seem to be an end to its expansion.",
  "id" : 368149034965270528,
  "created_at" : "2013-08-15 23:15:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368148953302183936",
  "text" : "Does UIViewController feel bloated to anyone else? It's just an seemingly infinite dumping ground for new functionality.",
  "id" : 368148953302183936,
  "created_at" : "2013-08-15 23:15:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368145619623227392",
  "text" : "\"You\u2019re right. A DBA costs $50 at the Erie County Hall. Go do it.\"",
  "id" : 368145619623227392,
  "created_at" : "2013-08-15 23:02:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 1, 12 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/U12y4Q1Mgk",
      "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/cue-the-resurgence-meet-kevin-purdy-problem-solver-interview\/51005",
      "display_url" : "buffalo.com\/news\/blog\/cue-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368145447409287168",
  "text" : "\"@kevinpurdy is a problem solver\" \u0192 yeah he is! http:\/\/t.co\/U12y4Q1Mgk",
  "id" : 368145447409287168,
  "created_at" : "2013-08-15 23:01:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 8, 21 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368140021943271425",
  "geo" : { },
  "id_str" : "368143559796334592",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls @TheOtherZach Not at #scrc this year, sorry. Baby stuff this weekend.",
  "id" : 368143559796334592,
  "in_reply_to_status_id" : 368140021943271425,
  "created_at" : "2013-08-15 22:53:59 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 3, 12 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/TQQJwcuyy6",
      "expanded_url" : "http:\/\/konklone.com\/post\/blackout",
      "display_url" : "konklone.com\/post\/blackout"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/4Hd9G8MqKK",
      "expanded_url" : "http:\/\/konklone.com\/blackout\/2-sky",
      "display_url" : "konklone.com\/blackout\/2-sky"
    } ]
  },
  "geo" : { },
  "id_str" : "368120425126961152",
  "text" : "RT @konklone: Beginning a series of animated\/interactive things: http:\/\/t.co\/TQQJwcuyy6 Starting out simple: http:\/\/t.co\/4Hd9G8MqKK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/TQQJwcuyy6",
        "expanded_url" : "http:\/\/konklone.com\/post\/blackout",
        "display_url" : "konklone.com\/post\/blackout"
      }, {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/4Hd9G8MqKK",
        "expanded_url" : "http:\/\/konklone.com\/blackout\/2-sky",
        "display_url" : "konklone.com\/blackout\/2-sky"
      } ]
    },
    "geo" : { },
    "id_str" : "368119488337547265",
    "text" : "Beginning a series of animated\/interactive things: http:\/\/t.co\/TQQJwcuyy6 Starting out simple: http:\/\/t.co\/4Hd9G8MqKK",
    "id" : 368119488337547265,
    "created_at" : "2013-08-15 21:18:20 +0000",
    "user" : {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "protected" : false,
      "id_str" : "5232171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226668113\/blue_normal.png",
      "id" : 5232171,
      "verified" : false
    }
  },
  "id" : 368120425126961152,
  "created_at" : "2013-08-15 21:22:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/rVUrq6Zwec",
      "expanded_url" : "https:\/\/tonx.org\/3c31ff59",
      "display_url" : "tonx.org\/3c31ff59"
    } ]
  },
  "geo" : { },
  "id_str" : "368113931794931712",
  "text" : "Latest Tonx bag is in, and it's delicious. If you like coffee, you owe it to yourself: https:\/\/t.co\/rVUrq6Zwec",
  "id" : 368113931794931712,
  "created_at" : "2013-08-15 20:56:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368097488407781376",
  "text" : "Remember that time everyone complained about Daft Punk?",
  "id" : 368097488407781376,
  "created_at" : "2013-08-15 19:50:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368079893851934721",
  "text" : "RT @rjs: The more accustomed you are to working around a problem, the less you see the problem.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368077664856580096",
    "text" : "The more accustomed you are to working around a problem, the less you see the problem.",
    "id" : 368077664856580096,
    "created_at" : "2013-08-15 18:32:08 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 368079893851934721,
  "created_at" : "2013-08-15 18:41:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368079841922256896",
  "text" : "RT @sstephenson: @qrush My heuristic: does the commit message apply to every line of the diff?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "368049013964021760",
    "geo" : { },
    "id_str" : "368049369439670272",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush My heuristic: does the commit message apply to every line of the diff?",
    "id" : 368049369439670272,
    "in_reply_to_status_id" : 368049013964021760,
    "created_at" : "2013-08-15 16:39:42 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 368079841922256896,
  "created_at" : "2013-08-15 18:40:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368049013964021760",
  "text" : "If there's a comma in your commit, you probably need 2 commits.",
  "id" : 368049013964021760,
  "created_at" : "2013-08-15 16:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leandro Marcucci",
      "screen_name" : "leanucci",
      "indices" : [ 0, 9 ],
      "id_str" : "14994975",
      "id" : 14994975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368046253017665536",
  "geo" : { },
  "id_str" : "368046851317956608",
  "in_reply_to_user_id" : 14994975,
  "text" : "@leanucci ANYTIME",
  "id" : 368046851317956608,
  "in_reply_to_status_id" : 368046253017665536,
  "created_at" : "2013-08-15 16:29:41 +0000",
  "in_reply_to_screen_name" : "leanucci",
  "in_reply_to_user_id_str" : "14994975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368046126194102272",
  "text" : "UNINFORMED COMPLAINT ABOUT UNAVAILABILITY OF IMPORTANT PUBLIC AND PRIVATE SERVICE. WITTY QUIP ABOUT SUPERIORITY AND IGNORANCE.",
  "id" : 368046126194102272,
  "created_at" : "2013-08-15 16:26:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 59, 74 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/GOC3jkA4iK",
      "expanded_url" : "http:\/\/www.changesinlongitude.com\/things-to-do-in-buffalo-ny\/",
      "display_url" : "changesinlongitude.com\/things-to-do-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368036610333372416",
  "text" : "11 things you can do here in Buffalo if you're in town for @nickelcityruby: http:\/\/t.co\/GOC3jkA4iK",
  "id" : 368036610333372416,
  "created_at" : "2013-08-15 15:49:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 74, 84 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/HiAQDaTtR2",
      "expanded_url" : "http:\/\/37svn.com\/3603",
      "display_url" : "37svn.com\/3603"
    } ]
  },
  "geo" : { },
  "id_str" : "368033140335312896",
  "text" : "Keeping it in-house: some interviews about our mobile development process @37signals: http:\/\/t.co\/HiAQDaTtR2",
  "id" : 368033140335312896,
  "created_at" : "2013-08-15 15:35:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hipmob",
      "screen_name" : "hipmob",
      "indices" : [ 3, 10 ],
      "id_str" : "608864115",
      "id" : 608864115
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 42, 52 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 116, 120 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/JuRaIcClsg",
      "expanded_url" : "http:\/\/bit.ly\/14y0LPu",
      "display_url" : "bit.ly\/14y0LPu"
    } ]
  },
  "geo" : { },
  "id_str" : "367878893807497218",
  "text" : "RT @hipmob: We talked w\/ Ryan Singer from @37Signals about basecamp for iphone &amp; his approach to mobile. Thx to @rjs for sharing http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 30, 40 ],
        "id_str" : "11132462",
        "id" : 11132462
      }, {
        "name" : "Ryan Singer",
        "screen_name" : "rjs",
        "indices" : [ 104, 108 ],
        "id_str" : "10079052",
        "id" : 10079052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/JuRaIcClsg",
        "expanded_url" : "http:\/\/bit.ly\/14y0LPu",
        "display_url" : "bit.ly\/14y0LPu"
      } ]
    },
    "geo" : { },
    "id_str" : "367658621238124544",
    "text" : "We talked w\/ Ryan Singer from @37Signals about basecamp for iphone &amp; his approach to mobile. Thx to @rjs for sharing http:\/\/t.co\/JuRaIcClsg",
    "id" : 367658621238124544,
    "created_at" : "2013-08-14 14:47:00 +0000",
    "user" : {
      "name" : "Hipmob",
      "screen_name" : "hipmob",
      "protected" : false,
      "id_str" : "608864115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116118870\/c52f762820aa2abb04258fe8ab017971_normal.png",
      "id" : 608864115,
      "verified" : false
    }
  },
  "id" : 367878893807497218,
  "created_at" : "2013-08-15 05:22:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367761320990347264",
  "geo" : { },
  "id_str" : "367762260074455040",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude @aquaranto \uD83C\uDF7B",
  "id" : 367762260074455040,
  "in_reply_to_status_id" : 367761320990347264,
  "created_at" : "2013-08-14 21:38:50 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/R85bOMdRSA",
      "expanded_url" : "http:\/\/the-magazine.org\/23\/the-everending-story",
      "display_url" : "the-magazine.org\/23\/the-everend\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367750477238116352",
  "text" : "RT @kevinpurdy: My story on Chrono Trigger and its obsessive afterlife, \"The Everending Story,\" is up\/out on The Magazine: http:\/\/t.co\/R85b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/R85bOMdRSA",
        "expanded_url" : "http:\/\/the-magazine.org\/23\/the-everending-story",
        "display_url" : "the-magazine.org\/23\/the-everend\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367750436561768448",
    "text" : "My story on Chrono Trigger and its obsessive afterlife, \"The Everending Story,\" is up\/out on The Magazine: http:\/\/t.co\/R85bOMdRSA",
    "id" : 367750436561768448,
    "created_at" : "2013-08-14 20:51:51 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 367750477238116352,
  "created_at" : "2013-08-14 20:52:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/fF6KJmb8sS",
      "expanded_url" : "http:\/\/playloggins.com",
      "display_url" : "playloggins.com"
    } ]
  },
  "in_reply_to_status_id_str" : "367740109694988288",
  "geo" : { },
  "id_str" : "367742378196492289",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik http:\/\/t.co\/fF6KJmb8sS",
  "id" : 367742378196492289,
  "in_reply_to_status_id" : 367740109694988288,
  "created_at" : "2013-08-14 20:19:49 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 9, 15 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/5kxZoRP0bz",
      "expanded_url" : "https:\/\/identicons.github.com\/qrush.png",
      "display_url" : "identicons.github.com\/qrush.png"
    } ]
  },
  "in_reply_to_status_id_str" : "367741256794775555",
  "geo" : { },
  "id_str" : "367742184667099136",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @cmeik I LIKE TURTLES https:\/\/t.co\/5kxZoRP0bz",
  "id" : 367742184667099136,
  "in_reply_to_status_id" : 367741256794775555,
  "created_at" : "2013-08-14 20:19:03 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlanta Ruby",
      "screen_name" : "atlrug",
      "indices" : [ 0, 7 ],
      "id_str" : "46263652",
      "id" : 46263652
    }, {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 8, 18 ],
      "id_str" : "13235612",
      "id" : 13235612
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 65, 80 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367738715621556224",
  "geo" : { },
  "id_str" : "367741000527011840",
  "in_reply_to_user_id" : 46263652,
  "text" : "@atlrug @alindeman I'd appreciate if you could do a shoutout for @nickelcityruby. Great lineup and plenty of tickets left!",
  "id" : 367741000527011840,
  "in_reply_to_status_id" : 367738715621556224,
  "created_at" : "2013-08-14 20:14:21 +0000",
  "in_reply_to_screen_name" : "atlrug",
  "in_reply_to_user_id_str" : "46263652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/f46OFTDFWj",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=M0KbXH_u_bc",
      "display_url" : "youtube.com\/watch?v=M0KbXH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367698077626277888",
  "text" : "Basically how I feel about Kickstarter: http:\/\/t.co\/f46OFTDFWj",
  "id" : 367698077626277888,
  "created_at" : "2013-08-14 17:23:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 3, 11 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367673768363061248",
  "text" : "RT @zakkain: \uD835\uDD17\uD835\uDD25\uD835\uDD26\uD835\uDD30 \uD835\uDD26\uD835\uDD30 \uD835\uDD31\uD835\uDD25\uD835\uDD22 \uD835\uDD23\uD835\uDD32\uD835\uDD31\uD835\uDD32\uD835\uDD2F\uD835\uDD22 \uD835\uDD2C\uD835\uDD23 \uD835\uDD17\uD835\uDD34\uD835\uDD26\uD835\uDD31\uD835\uDD31\uD835\uDD22\uD835\uDD2F.\n\n\uD835\uDD17\uD835\uDD25\uD835\uDD22\uD835\uDD2F\uD835\uDD22 \uD835\uDD26\uD835\uDD30 \uD835\uDD2B\uD835\uDD2C \uD835\uDD31\uD835\uDD32\uD835\uDD2F\uD835\uDD2B\uD835\uDD26\uD835\uDD2B\uD835\uDD24 \uD835\uDD1F\uD835\uDD1E\uD835\uDD20\uD835\uDD0E.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367672111378468864",
    "text" : "\uD835\uDD17\uD835\uDD25\uD835\uDD26\uD835\uDD30 \uD835\uDD26\uD835\uDD30 \uD835\uDD31\uD835\uDD25\uD835\uDD22 \uD835\uDD23\uD835\uDD32\uD835\uDD31\uD835\uDD32\uD835\uDD2F\uD835\uDD22 \uD835\uDD2C\uD835\uDD23 \uD835\uDD17\uD835\uDD34\uD835\uDD26\uD835\uDD31\uD835\uDD31\uD835\uDD22\uD835\uDD2F.\n\n\uD835\uDD17\uD835\uDD25\uD835\uDD22\uD835\uDD2F\uD835\uDD22 \uD835\uDD26\uD835\uDD30 \uD835\uDD2B\uD835\uDD2C \uD835\uDD31\uD835\uDD32\uD835\uDD2F\uD835\uDD2B\uD835\uDD26\uD835\uDD2B\uD835\uDD24 \uD835\uDD1F\uD835\uDD1E\uD835\uDD20\uD835\uDD0E.",
    "id" : 367672111378468864,
    "created_at" : "2013-08-14 15:40:37 +0000",
    "user" : {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "protected" : false,
      "id_str" : "15069435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562658644798365696\/hBo4HXWG_normal.png",
      "id" : 15069435,
      "verified" : false
    }
  },
  "id" : 367673768363061248,
  "created_at" : "2013-08-14 15:47:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAHRINAH",
      "screen_name" : "MLvS",
      "indices" : [ 0, 5 ],
      "id_str" : "16536395",
      "id" : 16536395
    }, {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 6, 13 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367660799709286400",
  "geo" : { },
  "id_str" : "367671573173391361",
  "in_reply_to_user_id" : 16536395,
  "text" : "@MLvS @dankim yeah not sure how this works in huge\/saturated markets. Sounds more difficult :)",
  "id" : 367671573173391361,
  "in_reply_to_status_id" : 367660799709286400,
  "created_at" : "2013-08-14 15:38:28 +0000",
  "in_reply_to_screen_name" : "MLvS",
  "in_reply_to_user_id_str" : "16536395",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367658101622992896",
  "geo" : { },
  "id_str" : "367663739644170240",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel not the worst tattoo I guess",
  "id" : 367663739644170240,
  "in_reply_to_status_id" : 367658101622992896,
  "created_at" : "2013-08-14 15:07:21 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367629384162627584",
  "geo" : { },
  "id_str" : "367655229980155905",
  "in_reply_to_user_id" : 212418463,
  "text" : "@knouroozi shouldn\u2019t. I\u2019d check out their help sites",
  "id" : 367655229980155905,
  "in_reply_to_status_id" : 367629384162627584,
  "created_at" : "2013-08-14 14:33:32 +0000",
  "in_reply_to_screen_name" : "knrz_",
  "in_reply_to_user_id_str" : "212418463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367650489313157120",
  "geo" : { },
  "id_str" : "367655149604716544",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim community first. Maybe do some jelly style meetups",
  "id" : 367655149604716544,
  "in_reply_to_status_id" : 367650489313157120,
  "created_at" : "2013-08-14 14:33:13 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cross-Conference",
      "screen_name" : "crossconference",
      "indices" : [ 3, 19 ],
      "id_str" : "150644817",
      "id" : 150644817
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 93, 108 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367628006128250880",
  "text" : "RT @crossconference: If we have any developers in our audience who be in the NE Sept. 20-21, @nickelcityruby has an amazing conference line\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 72, 87 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367519806221586432",
    "text" : "If we have any developers in our audience who be in the NE Sept. 20-21, @nickelcityruby has an amazing conference lineup.",
    "id" : 367519806221586432,
    "created_at" : "2013-08-14 05:35:24 +0000",
    "user" : {
      "name" : "Cross-Conference",
      "screen_name" : "crossconference",
      "protected" : false,
      "id_str" : "150644817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3290059967\/6a436fd18c5fb955f502b41ac9eb4858_normal.jpeg",
      "id" : 150644817,
      "verified" : false
    }
  },
  "id" : 367628006128250880,
  "created_at" : "2013-08-14 12:45:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 3, 15 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 66, 81 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367517241861885952",
  "text" : "RT @joshknowles: New Yorkers have you seen conference lineup that @nickelcityruby has pulled together? Who is interested in getting a bus f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 49, 64 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367472100199907328",
    "text" : "New Yorkers have you seen conference lineup that @nickelcityruby has pulled together? Who is interested in getting a bus from NYC to attend?",
    "id" : 367472100199907328,
    "created_at" : "2013-08-14 02:25:50 +0000",
    "user" : {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "protected" : false,
      "id_str" : "1274141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3496301020\/b2d6e408cd995060f700b1f00b3b582d_normal.jpeg",
      "id" : 1274141,
      "verified" : false
    }
  },
  "id" : 367517241861885952,
  "created_at" : "2013-08-14 05:25:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Denkinger",
      "screen_name" : "tdenkinger",
      "indices" : [ 0, 11 ],
      "id_str" : "18776291",
      "id" : 18776291
    }, {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 12, 24 ],
      "id_str" : "1274141",
      "id" : 1274141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367490359565512704",
  "geo" : { },
  "id_str" : "367490469896261632",
  "in_reply_to_user_id" : 18776291,
  "text" : "@tdenkinger @joshknowles Or at the least an awesome RV.",
  "id" : 367490469896261632,
  "in_reply_to_status_id" : 367490359565512704,
  "created_at" : "2013-08-14 03:38:50 +0000",
  "in_reply_to_screen_name" : "tdenkinger",
  "in_reply_to_user_id_str" : "18776291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 3, 12 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 67, 82 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "louisville",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367423106660311040",
  "text" : "RT @mr_ndrsn: Hey all #louisville rubyists, you should all head to @nickelcityruby next month! I'll see you there!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 53, 68 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "louisville",
        "indices" : [ 8, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367411731477561345",
    "text" : "Hey all #louisville rubyists, you should all head to @nickelcityruby next month! I'll see you there!",
    "id" : 367411731477561345,
    "created_at" : "2013-08-13 22:25:57 +0000",
    "user" : {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "protected" : false,
      "id_str" : "774032401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460857040542261248\/228nQ2PI_normal.jpeg",
      "id" : 774032401,
      "verified" : false
    }
  },
  "id" : 367423106660311040,
  "created_at" : "2013-08-13 23:11:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/PSDyilgkNa",
      "expanded_url" : "http:\/\/i.imgur.com\/55bK1Rz.jpg?1",
      "display_url" : "i.imgur.com\/55bK1Rz.jpg?1"
    } ]
  },
  "geo" : { },
  "id_str" : "367407496949796865",
  "text" : "Way to go, MSNBC: http:\/\/t.co\/PSDyilgkNa",
  "id" : 367407496949796865,
  "created_at" : "2013-08-13 22:09:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 10, 25 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 54, 62 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/44Tb1bkJff",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/129234472\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "367406880819527680",
  "geo" : { },
  "id_str" : "367407377466671105",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 @Chris_Langford Late. You could stop by the @wnyruby \/PHP group lightning talks at EY! (free food\/beer!) http:\/\/t.co\/44Tb1bkJff",
  "id" : 367407377466671105,
  "in_reply_to_status_id" : 367406880819527680,
  "created_at" : "2013-08-13 22:08:39 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 10, 25 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 88, 96 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367396422611927040",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 @Chris_Langford anyone at the space tonight? I can drop off the posters after @wnyruby",
  "id" : 367396422611927040,
  "created_at" : "2013-08-13 21:25:07 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rene Ritchie",
      "screen_name" : "reneritchie",
      "indices" : [ 3, 15 ],
      "id_str" : "10194392",
      "id" : 10194392
    }, {
      "name" : "Guy English",
      "screen_name" : "gte",
      "indices" : [ 33, 37 ],
      "id_str" : "7125712",
      "id" : 7125712
    }, {
      "name" : "Don Melton",
      "screen_name" : "donmelton",
      "indices" : [ 38, 48 ],
      "id_str" : "11201752",
      "id" : 11201752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jzYgtt8jKN",
      "expanded_url" : "http:\/\/www.imore.com\/ad-hoc-5-dune",
      "display_url" : "imore.com\/ad-hoc-5-dune"
    } ]
  },
  "geo" : { },
  "id_str" : "367361660282892288",
  "text" : "RT @reneritchie: In @AdHocCast 5 @gte @donmelton and I go on a Spice-induced bender through Dune. This show is a killing word!  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guy English",
        "screen_name" : "gte",
        "indices" : [ 16, 20 ],
        "id_str" : "7125712",
        "id" : 7125712
      }, {
        "name" : "Don Melton",
        "screen_name" : "donmelton",
        "indices" : [ 21, 31 ],
        "id_str" : "11201752",
        "id" : 11201752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/jzYgtt8jKN",
        "expanded_url" : "http:\/\/www.imore.com\/ad-hoc-5-dune",
        "display_url" : "imore.com\/ad-hoc-5-dune"
      } ]
    },
    "geo" : { },
    "id_str" : "367345981970722816",
    "text" : "In @AdHocCast 5 @gte @donmelton and I go on a Spice-induced bender through Dune. This show is a killing word!  http:\/\/t.co\/jzYgtt8jKN",
    "id" : 367345981970722816,
    "created_at" : "2013-08-13 18:04:41 +0000",
    "user" : {
      "name" : "Rene Ritchie",
      "screen_name" : "reneritchie",
      "protected" : false,
      "id_str" : "10194392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415725984328192000\/OlL4Pnx5_normal.jpeg",
      "id" : 10194392,
      "verified" : false
    }
  },
  "id" : 367361660282892288,
  "created_at" : "2013-08-13 19:06:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philly.rb",
      "screen_name" : "phillyrb",
      "indices" : [ 0, 9 ],
      "id_str" : "17964172",
      "id" : 17964172
    }, {
      "name" : "Brian E. McElaney",
      "screen_name" : "McElaney",
      "indices" : [ 10, 19 ],
      "id_str" : "249150277",
      "id" : 249150277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367352368545161216",
  "geo" : { },
  "id_str" : "367353607080779777",
  "in_reply_to_user_id" : 17964172,
  "text" : "@phillyrb @McElaney thanks!!",
  "id" : 367353607080779777,
  "in_reply_to_status_id" : 367352368545161216,
  "created_at" : "2013-08-13 18:34:59 +0000",
  "in_reply_to_screen_name" : "phillyrb",
  "in_reply_to_user_id_str" : "17964172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 33, 47 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 82, 97 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367351860790693888",
  "text" : "RT @jwright: If you are going to @SteelCityRuby this week, you should also attend @nickelcityruby in Sept.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 20, 34 ],
        "id_str" : "404851600",
        "id" : 404851600
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 69, 84 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367350508102496257",
    "text" : "If you are going to @SteelCityRuby this week, you should also attend @nickelcityruby in Sept.",
    "id" : 367350508102496257,
    "created_at" : "2013-08-13 18:22:40 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 367351860790693888,
  "created_at" : "2013-08-13 18:28:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367344283566616576",
  "text" : "Bee kill count: 2",
  "id" : 367344283566616576,
  "created_at" : "2013-08-13 17:57:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367338572782632960",
  "geo" : { },
  "id_str" : "367341660025262080",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Masterful trolling: one of the photos on the page is of RMS + Matz",
  "id" : 367341660025262080,
  "in_reply_to_status_id" : 367338572782632960,
  "created_at" : "2013-08-13 17:47:31 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 26, 40 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367332172014686210",
  "text" : "One advantage to being at @coworkbuffalo: There's bees outside. BEES.",
  "id" : 367332172014686210,
  "created_at" : "2013-08-13 17:09:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367327613485727745",
  "geo" : { },
  "id_str" : "367328883650990080",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej hahaproxy",
  "id" : 367328883650990080,
  "in_reply_to_status_id" : 367327613485727745,
  "created_at" : "2013-08-13 16:56:45 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 33, 43 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 44, 56 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367323002100129792",
  "geo" : { },
  "id_str" : "367323213497245699",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents awesome idea! \/cc @aquaranto @rocketslide",
  "id" : 367323213497245699,
  "in_reply_to_status_id" : 367323002100129792,
  "created_at" : "2013-08-13 16:34:13 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian E. McElaney",
      "screen_name" : "McElaney",
      "indices" : [ 3, 12 ],
      "id_str" : "249150277",
      "id" : 249150277
    }, {
      "name" : "philly.rb",
      "screen_name" : "phillyrb",
      "indices" : [ 18, 27 ],
      "id_str" : "17964172",
      "id" : 17964172
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 29, 35 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 59, 74 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367322365459312641",
  "text" : "RT @McElaney: Hey @phillyrb, @qrush wants us to know about @nickelcityruby. They have plenty of seats left and an awesome lineup!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "philly.rb",
        "screen_name" : "phillyrb",
        "indices" : [ 4, 13 ],
        "id_str" : "17964172",
        "id" : 17964172
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 15, 21 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 45, 60 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "367313321076068352",
    "geo" : { },
    "id_str" : "367322103411777537",
    "in_reply_to_user_id" : 5743852,
    "text" : "Hey @phillyrb, @qrush wants us to know about @nickelcityruby. They have plenty of seats left and an awesome lineup!",
    "id" : 367322103411777537,
    "in_reply_to_status_id" : 367313321076068352,
    "created_at" : "2013-08-13 16:29:48 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brian E. McElaney",
      "screen_name" : "McElaney",
      "protected" : false,
      "id_str" : "249150277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560880069166387200\/Z2hBpM7K_normal.png",
      "id" : 249150277,
      "verified" : false
    }
  },
  "id" : 367322365459312641,
  "created_at" : "2013-08-13 16:30:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367303226070024192",
  "geo" : { },
  "id_str" : "367321558445854720",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending Need to watch the video, but initial impression is one of pretty severe vendor lock-in for background\/async tasks.",
  "id" : 367321558445854720,
  "in_reply_to_status_id" : 367303226070024192,
  "created_at" : "2013-08-13 16:27:38 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 8, 16 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367320159779688449",
  "geo" : { },
  "id_str" : "367320440353468417",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @fending make it look like a normal gem would be a good first step.",
  "id" : 367320440353468417,
  "in_reply_to_status_id" : 367320159779688449,
  "created_at" : "2013-08-13 16:23:12 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 0, 11 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "Patrick Crowley",
      "screen_name" : "mokolabs",
      "indices" : [ 12, 21 ],
      "id_str" : "630103",
      "id" : 630103
    }, {
      "name" : "Troy Denkinger",
      "screen_name" : "tdenkinger",
      "indices" : [ 22, 33 ],
      "id_str" : "18776291",
      "id" : 18776291
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 34, 42 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 43, 55 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367309041132769281",
  "geo" : { },
  "id_str" : "367319089716281344",
  "in_reply_to_user_id" : 14390268,
  "text" : "@rachelober @mokolabs @tdenkinger @evanphx @joshknowles @nickelcityruby I could whip up a quick Wufoo\/Google form. Or would just paper help?",
  "id" : 367319089716281344,
  "in_reply_to_status_id" : 367309041132769281,
  "created_at" : "2013-08-13 16:17:50 +0000",
  "in_reply_to_screen_name" : "rachelober",
  "in_reply_to_user_id_str" : "14390268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Rosen",
      "screen_name" : "rosenboy",
      "indices" : [ 0, 9 ],
      "id_str" : "11215972",
      "id" : 11215972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367317380700966913",
  "geo" : { },
  "id_str" : "367317896642306049",
  "in_reply_to_user_id" : 11215972,
  "text" : "@rosenboy Congrats! Glad to hear Desktime's going to get more attention :)",
  "id" : 367317896642306049,
  "in_reply_to_status_id" : 367317380700966913,
  "created_at" : "2013-08-13 16:13:05 +0000",
  "in_reply_to_screen_name" : "rosenboy",
  "in_reply_to_user_id_str" : "11215972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/qsNyI9L0ho",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bkh0gPf4Noc",
      "display_url" : "youtube.com\/watch?v=bkh0gP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367315685384257536",
  "text" : "One thing's for sure: If I invent a language, I'm buying every single book written about it. http:\/\/t.co\/qsNyI9L0ho",
  "id" : 367315685384257536,
  "created_at" : "2013-08-13 16:04:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 72, 87 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367313321076068352",
  "text" : "If you're running a Ruby users group tonight, I'd appreciate mentioning @nickelcityruby. We have plenty of seats left and an awesome lineup!",
  "id" : 367313321076068352,
  "created_at" : "2013-08-13 15:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 73, 80 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367303226070024192",
  "geo" : { },
  "id_str" : "367312447578714113",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending This README is super confusing (and non-standard gem setup) \/cc @lsegal",
  "id" : 367312447578714113,
  "in_reply_to_status_id" : 367303226070024192,
  "created_at" : "2013-08-13 15:51:26 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367146566626578432",
  "text" : "Bell ringing, church 2 doors down at 12:50? Wtf?",
  "id" : 367146566626578432,
  "created_at" : "2013-08-13 04:52:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 3, 14 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 70, 85 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367142330983133185",
  "text" : "RT @rachelober: How can I make a party bus from NYC -&gt; Buffalo for @nickelcityruby happen? Now accepting ideas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 54, 69 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367022246495125504",
    "text" : "How can I make a party bus from NYC -&gt; Buffalo for @nickelcityruby happen? Now accepting ideas.",
    "id" : 367022246495125504,
    "created_at" : "2013-08-12 20:38:17 +0000",
    "user" : {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "protected" : false,
      "id_str" : "14390268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321996605296640\/ekU7oNFN_normal.jpeg",
      "id" : 14390268,
      "verified" : false
    }
  },
  "id" : 367142330983133185,
  "created_at" : "2013-08-13 04:35:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Neomind Labs",
      "screen_name" : "NeomindLabs",
      "indices" : [ 52, 64 ],
      "id_str" : "605670059",
      "id" : 605670059
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 103, 118 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367142321990533121",
  "text" : "RT @AustinSeraphin: I feel pleased to announce that @NeomindLabs and I have begun our preparations for @nickelcityruby!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neomind Labs",
        "screen_name" : "NeomindLabs",
        "indices" : [ 32, 44 ],
        "id_str" : "605670059",
        "id" : 605670059
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 83, 98 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367004107363467264",
    "text" : "I feel pleased to announce that @NeomindLabs and I have begun our preparations for @nickelcityruby!",
    "id" : 367004107363467264,
    "created_at" : "2013-08-12 19:26:12 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 367142321990533121,
  "created_at" : "2013-08-13 04:35:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 40, 45 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/X8XzqGFRBZ",
      "expanded_url" : "http:\/\/ergoemacs.org\/emacs\/using_voice_to_code.html",
      "display_url" : "ergoemacs.org\/emacs\/using_vo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367134685320577024",
  "text" : "This is insane: http:\/\/t.co\/X8XzqGFRBZ (@r00k you should watch this)",
  "id" : 367134685320577024,
  "created_at" : "2013-08-13 04:05:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 37, 43 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/WGagMChkki",
      "expanded_url" : "http:\/\/mad.ly\/52f7f3",
      "display_url" : "mad.ly\/52f7f3"
    } ]
  },
  "geo" : { },
  "id_str" : "367082823976361985",
  "text" : "RT @RubyMotion: MotionMeetup #4 with @qrush this Wednesday (August 14th)! http:\/\/t.co\/WGagMChkki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 21, 27 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/WGagMChkki",
        "expanded_url" : "http:\/\/mad.ly\/52f7f3",
        "display_url" : "mad.ly\/52f7f3"
      } ]
    },
    "geo" : { },
    "id_str" : "367061621547753472",
    "text" : "MotionMeetup #4 with @qrush this Wednesday (August 14th)! http:\/\/t.co\/WGagMChkki",
    "id" : 367061621547753472,
    "created_at" : "2013-08-12 23:14:44 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 367082823976361985,
  "created_at" : "2013-08-13 00:38:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 3, 14 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367056551346843649",
  "text" : "RT @dangigante: Hyperloop from Buffalo to NYC? please?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367056067551068160",
    "text" : "Hyperloop from Buffalo to NYC? please?",
    "id" : 367056067551068160,
    "created_at" : "2013-08-12 22:52:40 +0000",
    "user" : {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "protected" : false,
      "id_str" : "43151378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482218130996232192\/bISq7rRg_normal.jpeg",
      "id" : 43151378,
      "verified" : false
    }
  },
  "id" : 367056551346843649,
  "created_at" : "2013-08-12 22:54:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Amazing Maps ",
      "screen_name" : "Amazing_Maps",
      "indices" : [ 3, 16 ],
      "id_str" : "1571270053",
      "id" : 1571270053
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/367043207177052160\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Fl7rZNS2ri",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
      "id_str" : "367043207202213888",
      "id" : 367043207202213888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Fl7rZNS2ri"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367049262942945280",
  "text" : "RT @Amazing_Maps: Is your state's highest paid public employee a football coach? Probably. http:\/\/t.co\/Fl7rZNS2ri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/367043207177052160\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/Fl7rZNS2ri",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
        "id_str" : "367043207202213888",
        "id" : 367043207202213888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
        "sizes" : [ {
          "h" : 546,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Fl7rZNS2ri"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367043207177052160",
    "text" : "Is your state's highest paid public employee a football coach? Probably. http:\/\/t.co\/Fl7rZNS2ri",
    "id" : 367043207177052160,
    "created_at" : "2013-08-12 22:01:34 +0000",
    "user" : {
      "name" : " Amazing Maps ",
      "screen_name" : "Amazing_Maps",
      "protected" : false,
      "id_str" : "1571270053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514370076816850944\/gvXYbbZO_normal.jpeg",
      "id" : 1571270053,
      "verified" : false
    }
  },
  "id" : 367049262942945280,
  "created_at" : "2013-08-12 22:25:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Mackenzie",
      "screen_name" : "mackesque",
      "indices" : [ 0, 10 ],
      "id_str" : "21399337",
      "id" : 21399337
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 11, 20 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367042006326841345",
  "geo" : { },
  "id_str" : "367043250239967233",
  "in_reply_to_user_id" : 21399337,
  "text" : "@mackesque @bitsweat loop without rhythm to avoid the worm",
  "id" : 367043250239967233,
  "in_reply_to_status_id" : 367042006326841345,
  "created_at" : "2013-08-12 22:01:44 +0000",
  "in_reply_to_screen_name" : "mackesque",
  "in_reply_to_user_id_str" : "21399337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367039443946835968",
  "geo" : { },
  "id_str" : "367039743344640000",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat in the future no one will need them",
  "id" : 367039743344640000,
  "in_reply_to_status_id" : 367039443946835968,
  "created_at" : "2013-08-12 21:47:48 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Boxer",
      "screen_name" : "jakeboxer",
      "indices" : [ 0, 10 ],
      "id_str" : "14500363",
      "id" : 14500363
    }, {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 11, 19 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HB42hT5AgE",
      "expanded_url" : "http:\/\/ostatic.com\/files\/images\/2_0_2.png",
      "display_url" : "ostatic.com\/files\/images\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366997986011656194",
  "geo" : { },
  "id_str" : "367035310745464833",
  "in_reply_to_user_id" : 14500363,
  "text" : "@jakeboxer @haacked This is better: AVOID http:\/\/t.co\/HB42hT5AgE",
  "id" : 367035310745464833,
  "in_reply_to_status_id" : 366997986011656194,
  "created_at" : "2013-08-12 21:30:11 +0000",
  "in_reply_to_screen_name" : "jakeboxer",
  "in_reply_to_user_id_str" : "14500363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Boxer",
      "screen_name" : "jakeboxer",
      "indices" : [ 0, 10 ],
      "id_str" : "14500363",
      "id" : 14500363
    }, {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 11, 19 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/F1owx9O6Ev",
      "expanded_url" : "http:\/\/www.download.ba\/program-image\/bugzilla.jpg",
      "display_url" : "download.ba\/program-image\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366997986011656194",
  "geo" : { },
  "id_str" : "367035241170337792",
  "in_reply_to_user_id" : 14500363,
  "text" : "@jakeboxer @haacked Whatever you're doing, please avoid this: http:\/\/t.co\/F1owx9O6Ev",
  "id" : 367035241170337792,
  "in_reply_to_status_id" : 366997986011656194,
  "created_at" : "2013-08-12 21:29:55 +0000",
  "in_reply_to_screen_name" : "jakeboxer",
  "in_reply_to_user_id_str" : "14500363",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/8L0vlyXkp6",
      "expanded_url" : "http:\/\/www.teslamotors.com\/sites\/default\/files\/blog_images\/hyperloop-alpha.pdf",
      "display_url" : "teslamotors.com\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367027762575323137",
  "text" : "Can the future be here yet? Please? http:\/\/t.co\/8L0vlyXkp6",
  "id" : 367027762575323137,
  "created_at" : "2013-08-12 21:00:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 13, 24 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367005534114680833",
  "geo" : { },
  "id_str" : "367016794139017219",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer @jamesuriah Woot!",
  "id" : 367016794139017219,
  "in_reply_to_status_id" : 367005534114680833,
  "created_at" : "2013-08-12 20:16:37 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367001761057214466",
  "geo" : { },
  "id_str" : "367002162577948673",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr $99\/night. If you're bringing a crew, maybe split an AirBNB?",
  "id" : 367002162577948673,
  "in_reply_to_status_id" : 367001761057214466,
  "created_at" : "2013-08-12 19:18:28 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366983457479458816",
  "geo" : { },
  "id_str" : "367001595608702976",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr we haven't talked about discounts yet for students. there are plenty of tickets left.",
  "id" : 367001595608702976,
  "in_reply_to_status_id" : 366983457479458816,
  "created_at" : "2013-08-12 19:16:13 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367001338225229824",
  "geo" : { },
  "id_str" : "367001448862588928",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah woot!!!",
  "id" : 367001448862588928,
  "in_reply_to_status_id" : 367001338225229824,
  "created_at" : "2013-08-12 19:15:38 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snipe",
      "screen_name" : "snipeyhead",
      "indices" : [ 3, 14 ],
      "id_str" : "14246782",
      "id" : 14246782
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/snipeyhead\/status\/366976287547457536\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/kNQ6NjaCHR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfC_TyCAAEHwYb.png",
      "id_str" : "366976287551651841",
      "id" : 366976287551651841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfC_TyCAAEHwYb.png",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 894
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 894
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kNQ6NjaCHR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/9v6xCpWTrX",
      "expanded_url" : "http:\/\/microsoft.com",
      "display_url" : "microsoft.com"
    } ]
  },
  "geo" : { },
  "id_str" : "366995057036902400",
  "text" : "RT @snipeyhead: Hmm\u2026 Do a whois for http:\/\/t.co\/9v6xCpWTrX\u2026 http:\/\/t.co\/kNQ6NjaCHR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/snipeyhead\/status\/366976287547457536\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/kNQ6NjaCHR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfC_TyCAAEHwYb.png",
        "id_str" : "366976287551651841",
        "id" : 366976287551651841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfC_TyCAAEHwYb.png",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 894
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 894
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kNQ6NjaCHR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/9v6xCpWTrX",
        "expanded_url" : "http:\/\/microsoft.com",
        "display_url" : "microsoft.com"
      } ]
    },
    "geo" : { },
    "id_str" : "366976287547457536",
    "text" : "Hmm\u2026 Do a whois for http:\/\/t.co\/9v6xCpWTrX\u2026 http:\/\/t.co\/kNQ6NjaCHR",
    "id" : 366976287547457536,
    "created_at" : "2013-08-12 17:35:39 +0000",
    "user" : {
      "name" : "snipe",
      "screen_name" : "snipeyhead",
      "protected" : false,
      "id_str" : "14246782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545415835675033600\/gDuSi44o_normal.jpeg",
      "id" : 14246782,
      "verified" : false
    }
  },
  "id" : 366995057036902400,
  "created_at" : "2013-08-12 18:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 0, 12 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 58, 67 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 85, 101 ],
      "id_str" : "46661605",
      "id" : 46661605
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 102, 114 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366989620531044352",
  "geo" : { },
  "id_str" : "366991867671363585",
  "in_reply_to_user_id" : 1274141,
  "text" : "@joshknowles @evanphx I bet this idea would interest many @bostonrb folks too... \/cc @patricksroberts @bcardarella",
  "id" : 366991867671363585,
  "in_reply_to_status_id" : 366989620531044352,
  "created_at" : "2013-08-12 18:37:34 +0000",
  "in_reply_to_screen_name" : "joshknowles",
  "in_reply_to_user_id_str" : "1274141",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 9, 21 ],
      "id_str" : "1274141",
      "id" : 1274141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366989679310012416",
  "geo" : { },
  "id_str" : "366991492293734400",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @joshknowles noncharter on Megabus is $39-59...would have to call a company to see about getting a whole bus",
  "id" : 366991492293734400,
  "in_reply_to_status_id" : 366989679310012416,
  "created_at" : "2013-08-12 18:36:04 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 0, 12 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 22, 33 ],
      "id_str" : "14390268",
      "id" : 14390268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366989620531044352",
  "geo" : { },
  "id_str" : "366989873678270464",
  "in_reply_to_user_id" : 1274141,
  "text" : "@joshknowles @evanphx @rachelober i don't think the conf could pay for it right now, but I can make a quick signup page for those interested",
  "id" : 366989873678270464,
  "in_reply_to_status_id" : 366989620531044352,
  "created_at" : "2013-08-12 18:29:38 +0000",
  "in_reply_to_screen_name" : "joshknowles",
  "in_reply_to_user_id_str" : "1274141",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 0, 12 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 13, 24 ],
      "id_str" : "14390268",
      "id" : 14390268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366988458050338816",
  "geo" : { },
  "id_str" : "366988831293046784",
  "in_reply_to_user_id" : 1274141,
  "text" : "@joshknowles @rachelober Really good idea, I'm happy to help with anything that gets people to attend.",
  "id" : 366988831293046784,
  "in_reply_to_status_id" : 366988458050338816,
  "created_at" : "2013-08-12 18:25:30 +0000",
  "in_reply_to_screen_name" : "joshknowles",
  "in_reply_to_user_id_str" : "1274141",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366967314194759681",
  "geo" : { },
  "id_str" : "366985168877125632",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy does Twitter have an entire team *just* on notifications?",
  "id" : 366985168877125632,
  "in_reply_to_status_id" : 366967314194759681,
  "created_at" : "2013-08-12 18:10:57 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 90, 105 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Josh Knowles",
      "screen_name" : "joshknowles",
      "indices" : [ 111, 123 ],
      "id_str" : "1274141",
      "id" : 1274141
    }, {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 124, 135 ],
      "id_str" : "14390268",
      "id" : 14390268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nycrb",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366977841386110976",
  "text" : "\"Join 152 Rubyists\" at #nycrb...Dang. Anyone attending this and mind doing a shoutout for @nickelcityruby? \/cc @joshknowles @rachelober",
  "id" : 366977841386110976,
  "created_at" : "2013-08-12 17:41:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 9, 18 ],
      "id_str" : "10545",
      "id" : 10545
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 27, 36 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/UmqvD4iHvE",
      "expanded_url" : "https:\/\/speakerdeck.com\/qrush\/git-started-with-git",
      "display_url" : "speakerdeck.com\/qrush\/git-star\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366975423520841728",
  "geo" : { },
  "id_str" : "366976775147892736",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej @flyosity thanks! @gitready is more for tips...I wrote it to learn git though. Old talk too on basics: https:\/\/t.co\/UmqvD4iHvE",
  "id" : 366976775147892736,
  "in_reply_to_status_id" : 366975423520841728,
  "created_at" : "2013-08-12 17:37:35 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366956352716816384",
  "geo" : { },
  "id_str" : "366956734960500736",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej WORK VISA REQUIRED TODAY. ENTRANCE DENIED. \"But I have a ticket!\" *closes window* *pushes detain button slowly*",
  "id" : 366956734960500736,
  "in_reply_to_status_id" : 366956352716816384,
  "created_at" : "2013-08-12 16:17:58 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/tM0t5YN1Yj",
      "expanded_url" : "http:\/\/danshipper.com\/public-speaking-for-introverts",
      "display_url" : "danshipper.com\/public-speakin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366955696698306562",
  "text" : "So true: \"the only cure for insecurity [as a speaker] is experience\" http:\/\/t.co\/tM0t5YN1Yj",
  "id" : 366955696698306562,
  "created_at" : "2013-08-12 16:13:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366932114911928321",
  "geo" : { },
  "id_str" : "366934007281233921",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle pretty sure car seats don\u2019t fit in those.",
  "id" : 366934007281233921,
  "in_reply_to_status_id" : 366932114911928321,
  "created_at" : "2013-08-12 14:47:39 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366931779682185216",
  "text" : "Irony: getting a new car the day Hyperloop plans are being published.",
  "id" : 366931779682185216,
  "created_at" : "2013-08-12 14:38:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366903235509886976",
  "geo" : { },
  "id_str" : "366906530714497026",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant good luck dude!",
  "id" : 366906530714497026,
  "in_reply_to_status_id" : 366903235509886976,
  "created_at" : "2013-08-12 12:58:28 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366768319040208896",
  "geo" : { },
  "id_str" : "366906451467317249",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant cause no trouble.",
  "id" : 366906451467317249,
  "in_reply_to_status_id" : 366768319040208896,
  "created_at" : "2013-08-12 12:58:09 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "366598996837404672",
  "text" : "It's Sunday! That means it's a perfect time to plan your trip to Buffalo for http:\/\/t.co\/3UAdoKZw7Q !",
  "id" : 366598996837404672,
  "created_at" : "2013-08-11 16:36:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 0, 14 ],
      "id_str" : "14247442",
      "id" : 14247442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366286945590059008",
  "geo" : { },
  "id_str" : "366292455076798464",
  "in_reply_to_user_id" : 14247442,
  "text" : "@baroquebobcat minmus next?!",
  "id" : 366292455076798464,
  "in_reply_to_status_id" : 366286945590059008,
  "created_at" : "2013-08-10 20:18:21 +0000",
  "in_reply_to_screen_name" : "baroquebobcat",
  "in_reply_to_user_id_str" : "14247442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366262221711482880",
  "text" : "Car buying negotiation is such a joke. I can\u2019t wait for Musk and other entrepreneurs to remove this bullshit.",
  "id" : 366262221711482880,
  "created_at" : "2013-08-10 18:18:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366076319492087811",
  "text" : "Tonight\u2019s lack of sleep brought to you by the letter K: ketosis and Kerbal. (Warped past a Duna encounter!)",
  "id" : 366076319492087811,
  "created_at" : "2013-08-10 05:59:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366072817365680129",
  "geo" : { },
  "id_str" : "366075862522675200",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws\nR\nE\nA\nD A\nB O\nOKKKKKKK",
  "id" : 366075862522675200,
  "in_reply_to_status_id" : 366072817365680129,
  "created_at" : "2013-08-10 05:57:41 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366073254668013568",
  "geo" : { },
  "id_str" : "366075676933095424",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws ain\u2019t expensive",
  "id" : 366075676933095424,
  "in_reply_to_status_id" : 366073254668013568,
  "created_at" : "2013-08-10 05:56:57 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366016978701393921",
  "text" : "Watching that Liam Neesons movie with the wolves and shit.",
  "id" : 366016978701393921,
  "created_at" : "2013-08-10 02:03:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/COnTFgYy8Y",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=BzEHItrTMHM",
      "display_url" : "m.youtube.com\/watch?v=BzEHIt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365981809307168768",
  "text" : "RT @bquarant: 167 cool dudes playing theremins and wearing stethoscopes? Check. http:\/\/t.co\/COnTFgYy8Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/COnTFgYy8Y",
        "expanded_url" : "http:\/\/m.youtube.com\/watch?v=BzEHItrTMHM",
        "display_url" : "m.youtube.com\/watch?v=BzEHIt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365977968092250112",
    "text" : "167 cool dudes playing theremins and wearing stethoscopes? Check. http:\/\/t.co\/COnTFgYy8Y",
    "id" : 365977968092250112,
    "created_at" : "2013-08-09 23:28:41 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 365981809307168768,
  "created_at" : "2013-08-09 23:43:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 3, 14 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 33, 39 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/sCBzk0XMzu",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "365959776447889408",
  "text" : "RT @joanofdark: Conferences like @qrush's Nickel City Ruby make me wish I were a programmer http:\/\/t.co\/sCBzk0XMzu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 17, 23 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/sCBzk0XMzu",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "365954223625601024",
    "text" : "Conferences like @qrush's Nickel City Ruby make me wish I were a programmer http:\/\/t.co\/sCBzk0XMzu",
    "id" : 365954223625601024,
    "created_at" : "2013-08-09 21:54:20 +0000",
    "user" : {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "protected" : false,
      "id_str" : "12734002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52337868\/76195_normal.jpeg",
      "id" : 12734002,
      "verified" : false
    }
  },
  "id" : 365959776447889408,
  "created_at" : "2013-08-09 22:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365860187669671936",
  "text" : "RT @Pinboard: Angry young people are starting to call the USA a police state, but I think we are more of a fire department state. With sexy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365858786298183680",
    "text" : "Angry young people are starting to call the USA a police state, but I think we are more of a fire department state. With sexy calendars!",
    "id" : 365858786298183680,
    "created_at" : "2013-08-09 15:35:06 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 365860187669671936,
  "created_at" : "2013-08-09 15:40:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365847178167582721",
  "geo" : { },
  "id_str" : "365848530541232128",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan remote work is great, but needs to be self-motivated. Stir-craziness\/hobo syndrome can be avoided at your local coworker spot!",
  "id" : 365848530541232128,
  "in_reply_to_status_id" : 365847178167582721,
  "created_at" : "2013-08-09 14:54:21 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/365837074244456448\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/dciaFemcGZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRO24XiCUAArGTx.png",
      "id_str" : "365837074252845056",
      "id" : 365837074252845056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRO24XiCUAArGTx.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/dciaFemcGZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365837074244456448",
  "text" : "It seems that @coworkbuffalo has arrived in the future. http:\/\/t.co\/dciaFemcGZ",
  "id" : 365837074244456448,
  "created_at" : "2013-08-09 14:08:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 10, 17 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 18, 27 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "365584169415360513",
  "geo" : { },
  "id_str" : "365599240216526848",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti @wycats @indirect we do this for http:\/\/t.co\/2bA9BVLhWr, but i wouldn't recommend it otherwise.",
  "id" : 365599240216526848,
  "in_reply_to_status_id" : 365584169415360513,
  "created_at" : "2013-08-08 22:23:46 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Butt Toucher IRL",
      "screen_name" : "street_doggee",
      "indices" : [ 0, 14 ],
      "id_str" : "502016386",
      "id" : 502016386
    }, {
      "name" : "Matt Gemmell",
      "screen_name" : "mattgemmell",
      "indices" : [ 15, 27 ],
      "id_str" : "755859",
      "id" : 755859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365580661731504128",
  "geo" : { },
  "id_str" : "365582241826480128",
  "in_reply_to_user_id" : 502016386,
  "text" : "@street_doggee @mattgemmell it's still \"web-developer-male\" in the HTML source :|",
  "id" : 365582241826480128,
  "in_reply_to_status_id" : 365580661731504128,
  "created_at" : "2013-08-08 21:16:13 +0000",
  "in_reply_to_screen_name" : "street_doggee",
  "in_reply_to_user_id_str" : "502016386",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 4, 12 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 13, 20 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365580723706544130",
  "geo" : { },
  "id_str" : "365581430639706112",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm @capotej @dukope CAUSE NO BUGS.",
  "id" : 365581430639706112,
  "in_reply_to_status_id" : 365580723706544130,
  "created_at" : "2013-08-08 21:12:59 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 79, 83 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/mtBmyMpyxk",
      "expanded_url" : "http:\/\/feltpresence.com\/articles\/20-vital-elements-of-the-product-design-process",
      "display_url" : "feltpresence.com\/articles\/20-vi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365579642905698305",
  "text" : "\"Good product development is a sequence of bets.\" - tons of great insight from @rjs in this: http:\/\/t.co\/mtBmyMpyxk",
  "id" : 365579642905698305,
  "created_at" : "2013-08-08 21:05:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 62, 70 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 71, 77 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/tCmuglz1RL",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/08\/the-software-that-builds-software.html",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365576311466508291",
  "text" : "Jekyll shoutout in the New Yorker! http:\/\/t.co\/tCmuglz1RL \/cc @mojombo @parkr",
  "id" : 365576311466508291,
  "created_at" : "2013-08-08 20:52:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 3, 11 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365534311832760320",
  "text" : "RT @gknauss: WE ARE ALL DOOMED, a Play in One Act\n\nFather: \"You should read 'Animal Farm.'\"\n\nSon: \"Isn't that a Facebook game?\"\n\nEXEUNT.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364903432965984256",
    "text" : "WE ARE ALL DOOMED, a Play in One Act\n\nFather: \"You should read 'Animal Farm.'\"\n\nSon: \"Isn't that a Facebook game?\"\n\nEXEUNT.",
    "id" : 364903432965984256,
    "created_at" : "2013-08-07 00:18:52 +0000",
    "user" : {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "protected" : false,
      "id_str" : "3163591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/38137892\/greg-icon-128_normal.gif",
      "id" : 3163591,
      "verified" : false
    }
  },
  "id" : 365534311832760320,
  "created_at" : "2013-08-08 18:05:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Schwartz",
      "screen_name" : "eeeschwartz",
      "indices" : [ 0, 12 ],
      "id_str" : "131531865",
      "id" : 131531865
    }, {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 13, 21 ],
      "id_str" : "15048829",
      "id" : 15048829
    }, {
      "name" : "developmentseed",
      "screen_name" : "developmentseed",
      "indices" : [ 22, 38 ],
      "id_str" : "14074424",
      "id" : 14074424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365527611411144704",
  "geo" : { },
  "id_str" : "365533944923422720",
  "in_reply_to_user_id" : 131531865,
  "text" : "@eeeschwartz @greggyb @developmentseed We'll see :) Curious to see how this plays out.",
  "id" : 365533944923422720,
  "in_reply_to_status_id" : 365527611411144704,
  "created_at" : "2013-08-08 18:04:18 +0000",
  "in_reply_to_screen_name" : "eeeschwartz",
  "in_reply_to_user_id_str" : "131531865",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Schwartz",
      "screen_name" : "eeeschwartz",
      "indices" : [ 3, 15 ],
      "id_str" : "131531865",
      "id" : 131531865
    }, {
      "name" : "developmentseed",
      "screen_name" : "developmentseed",
      "indices" : [ 139, 140 ],
      "id_str" : "14074424",
      "id" : 14074424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/IT92fmtr06",
      "expanded_url" : "http:\/\/erikschwartz.net\/jekyll-for-the-masses\/",
      "display_url" : "erikschwartz.net\/jekyll-for-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365533895778770945",
  "text" : "RT @eeeschwartz: prose.io brings jekyll to the masses, and boy are the masses ready http:\/\/t.co\/IT92fmtr06 (thanks to the excellent work of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "developmentseed",
        "screen_name" : "developmentseed",
        "indices" : [ 123, 139 ],
        "id_str" : "14074424",
        "id" : 14074424
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/IT92fmtr06",
        "expanded_url" : "http:\/\/erikschwartz.net\/jekyll-for-the-masses\/",
        "display_url" : "erikschwartz.net\/jekyll-for-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365527611411144704",
    "text" : "prose.io brings jekyll to the masses, and boy are the masses ready http:\/\/t.co\/IT92fmtr06 (thanks to the excellent work of @developmentseed)",
    "id" : 365527611411144704,
    "created_at" : "2013-08-08 17:39:08 +0000",
    "user" : {
      "name" : "Erik Schwartz",
      "screen_name" : "eeeschwartz",
      "protected" : false,
      "id_str" : "131531865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821409818\/erik_02_square_normal.jpg",
      "id" : 131531865,
      "verified" : false
    }
  },
  "id" : 365533895778770945,
  "created_at" : "2013-08-08 18:04:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 21, 35 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/365531068423602177\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/VPOnu7t9GP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRKgkfBCAAA4LDd.png",
      "id_str" : "365531068431990784",
      "id" : 365531068431990784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRKgkfBCAAA4LDd.png",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VPOnu7t9GP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/9GAQ7gTQPB",
      "expanded_url" : "http:\/\/demographics.coopercenter.org\/DotMap\/index.html",
      "display_url" : "demographics.coopercenter.org\/DotMap\/index.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365531068423602177",
  "text" : "Segregated much? \/cc @BuffaloRising (via http:\/\/t.co\/9GAQ7gTQPB) http:\/\/t.co\/VPOnu7t9GP",
  "id" : 365531068423602177,
  "created_at" : "2013-08-08 17:52:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365528386350743552",
  "geo" : { },
  "id_str" : "365529392316817408",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej DETAIN",
  "id" : 365529392316817408,
  "in_reply_to_status_id" : 365528386350743552,
  "created_at" : "2013-08-08 17:46:13 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/wNh2ZGMMLF",
      "expanded_url" : "http:\/\/archpaper.com\/news\/articles.asp?id=6787",
      "display_url" : "archpaper.com\/news\/articles.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365508318933958657",
  "text" : "\"After decades of stagnation and decline, this Rust Belt city is finally on the upswing.\" http:\/\/t.co\/wNh2ZGMMLF",
  "id" : 365508318933958657,
  "created_at" : "2013-08-08 16:22:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike denby",
      "screen_name" : "mikerdenby",
      "indices" : [ 3, 14 ],
      "id_str" : "303475177",
      "id" : 303475177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Inv6n5yMLG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bxDl_ER5VC0&sns=tw",
      "display_url" : "youtube.com\/watch?v=bxDl_E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365504544655933441",
  "text" : "RT @mikerdenby: Well this is incredible. http:\/\/t.co\/Inv6n5yMLG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/Inv6n5yMLG",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bxDl_ER5VC0&sns=tw",
        "display_url" : "youtube.com\/watch?v=bxDl_E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365501023722283009",
    "text" : "Well this is incredible. http:\/\/t.co\/Inv6n5yMLG",
    "id" : 365501023722283009,
    "created_at" : "2013-08-08 15:53:29 +0000",
    "user" : {
      "name" : "mike denby",
      "screen_name" : "mikerdenby",
      "protected" : false,
      "id_str" : "303475177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2272595681\/awaeyew0ql4dre3gff8z_normal.jpeg",
      "id" : 303475177,
      "verified" : false
    }
  },
  "id" : 365504544655933441,
  "created_at" : "2013-08-08 16:07:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 0, 7 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365495118649753600",
  "geo" : { },
  "id_str" : "365496435141120000",
  "in_reply_to_user_id" : 17055675,
  "text" : "@Adkron totally is.",
  "id" : 365496435141120000,
  "in_reply_to_status_id" : 365495118649753600,
  "created_at" : "2013-08-08 15:35:15 +0000",
  "in_reply_to_screen_name" : "Adkron",
  "in_reply_to_user_id_str" : "17055675",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Pope",
      "screen_name" : "dukope",
      "indices" : [ 85, 92 ],
      "id_str" : "520685404",
      "id" : 520685404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/7yQRWkmSTi",
      "expanded_url" : "http:\/\/papersplea.se\/",
      "display_url" : "papersplea.se"
    } ]
  },
  "geo" : { },
  "id_str" : "365492047165128704",
  "text" : "Papers, Please is out today. You need to play this. http:\/\/t.co\/7yQRWkmSTi (Congrats @dukope!)",
  "id" : 365492047165128704,
  "created_at" : "2013-08-08 15:17:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365475393156816899",
  "geo" : { },
  "id_str" : "365475587038515200",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby \"You've been coding like a beast\" AHHHHHHHHHHH",
  "id" : 365475587038515200,
  "in_reply_to_status_id" : 365475393156816899,
  "created_at" : "2013-08-08 14:12:24 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365472196069564418",
  "text" : "Today\u2019s free bus ride brought you by guy with pants falling down, belly button showing, shouting gibberish! (Money acceptor is broke)",
  "id" : 365472196069564418,
  "created_at" : "2013-08-08 13:58:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/UEUZ625Zli",
      "expanded_url" : "http:\/\/i.imgur.com\/HzXLotC.png",
      "display_url" : "i.imgur.com\/HzXLotC.png"
    } ]
  },
  "geo" : { },
  "id_str" : "365321265105473537",
  "text" : "Made it to Minmus for my first night of KSP. As for getting back though... http:\/\/t.co\/UEUZ625Zli",
  "id" : 365321265105473537,
  "created_at" : "2013-08-08 03:59:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365320016893194240",
  "text" : "30-50% packet loss is not acceptable. :(",
  "id" : 365320016893194240,
  "created_at" : "2013-08-08 03:54:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365319794381176832",
  "text" : "Time Warner is so fucking terrible.",
  "id" : 365319794381176832,
  "created_at" : "2013-08-08 03:53:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365253058793447424",
  "geo" : { },
  "id_str" : "365254549398765568",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren gehennom is worse.",
  "id" : 365254549398765568,
  "in_reply_to_status_id" : 365253058793447424,
  "created_at" : "2013-08-07 23:34:05 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365250205941116928",
  "geo" : { },
  "id_str" : "365250517124915202",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren just follow the guides.",
  "id" : 365250517124915202,
  "in_reply_to_status_id" : 365250205941116928,
  "created_at" : "2013-08-07 23:18:03 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/holman\/status\/365210741541859328\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/1ebyp9Ch8K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRF9PAYCcAAndTG.png",
      "id_str" : "365210741546053632",
      "id" : 365210741546053632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRF9PAYCcAAndTG.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 1320
      } ],
      "display_url" : "pic.twitter.com\/1ebyp9Ch8K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365213165828575233",
  "text" : "RT @holman: Kill me if I ever work for a company that carpet bombs their customers with shit like this. http:\/\/t.co\/1ebyp9Ch8K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/holman\/status\/365210741541859328\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/1ebyp9Ch8K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRF9PAYCcAAndTG.png",
        "id_str" : "365210741546053632",
        "id" : 365210741546053632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRF9PAYCcAAndTG.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 884,
          "resize" : "fit",
          "w" : 1320
        } ],
        "display_url" : "pic.twitter.com\/1ebyp9Ch8K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365210741541859328",
    "text" : "Kill me if I ever work for a company that carpet bombs their customers with shit like this. http:\/\/t.co\/1ebyp9Ch8K",
    "id" : 365210741541859328,
    "created_at" : "2013-08-07 20:40:00 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 365213165828575233,
  "created_at" : "2013-08-07 20:49:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/NGpzGQfcvb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RXJKdh1KZ0w",
      "display_url" : "youtube.com\/watch?v=RXJKdh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365181039326408706",
  "text" : "Current status: http:\/\/t.co\/NGpzGQfcvb",
  "id" : 365181039326408706,
  "created_at" : "2013-08-07 18:41:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 8, 14 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365153006662074370",
  "geo" : { },
  "id_str" : "365179201558548480",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos @chorn @nickelcityruby I can make both of these happen",
  "id" : 365179201558548480,
  "in_reply_to_status_id" : 365153006662074370,
  "created_at" : "2013-08-07 18:34:41 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 3, 13 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/raganwald\/status\/365163496041771008\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Co9ua0lz8y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRFSQ9MCcAA9IGr.jpg",
      "id_str" : "365163496050159616",
      "id" : 365163496050159616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRFSQ9MCcAA9IGr.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Co9ua0lz8y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365163586345123840",
  "text" : "RT @raganwald: Java http:\/\/t.co\/Co9ua0lz8y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/raganwald\/status\/365163496041771008\/photo\/1",
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/Co9ua0lz8y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRFSQ9MCcAA9IGr.jpg",
        "id_str" : "365163496050159616",
        "id" : 365163496050159616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRFSQ9MCcAA9IGr.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Co9ua0lz8y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365163496041771008",
    "text" : "Java http:\/\/t.co\/Co9ua0lz8y",
    "id" : 365163496041771008,
    "created_at" : "2013-08-07 17:32:16 +0000",
    "user" : {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "protected" : false,
      "id_str" : "18137723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525649735856570368\/MvtI3PJj_normal.png",
      "id" : 18137723,
      "verified" : false
    }
  },
  "id" : 365163586345123840,
  "created_at" : "2013-08-07 17:32:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Hass",
      "screen_name" : "AshleyHass",
      "indices" : [ 0, 11 ],
      "id_str" : "2788330762",
      "id" : 2788330762
    }, {
      "name" : "WBFO",
      "screen_name" : "WBFO",
      "indices" : [ 12, 17 ],
      "id_str" : "20612109",
      "id" : 20612109
    }, {
      "name" : "Innovation Trail",
      "screen_name" : "InnovationTrail",
      "indices" : [ 18, 34 ],
      "id_str" : "164762580",
      "id" : 164762580
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 79, 94 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365131247049125889",
  "geo" : { },
  "id_str" : "365137561728987137",
  "in_reply_to_user_id" : 196353523,
  "text" : "@AshleyHass @WBFO @InnovationTrail Congrats! This reminds me...I'd love to see @nickelcityruby covered. I just sent an email about it :)",
  "id" : 365137561728987137,
  "in_reply_to_status_id" : 365131247049125889,
  "created_at" : "2013-08-07 15:49:13 +0000",
  "in_reply_to_screen_name" : "AshleyHirtz",
  "in_reply_to_user_id_str" : "196353523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roche",
      "screen_name" : "tedroche",
      "indices" : [ 0, 9 ],
      "id_str" : "14353681",
      "id" : 14353681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365132279699341312",
  "geo" : { },
  "id_str" : "365132840834310147",
  "in_reply_to_user_id" : 14353681,
  "text" : "@tedroche \"You have your own lane, you fucking asshole!\" seemed appropriately assertive to me.",
  "id" : 365132840834310147,
  "in_reply_to_status_id" : 365132279699341312,
  "created_at" : "2013-08-07 15:30:27 +0000",
  "in_reply_to_screen_name" : "tedroche",
  "in_reply_to_user_id_str" : "14353681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 3, 15 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/78DGpmPci5",
      "expanded_url" : "http:\/\/www.tedxbuffalo.com\/tedxbuffalo-2013\/attend\/",
      "display_url" : "tedxbuffalo.com\/tedxbuffalo-20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365122088127827970",
  "text" : "RT @TEDxBuffalo: Applications to attend TEDxBuffalo 2013 are open! http:\/\/t.co\/78DGpmPci5 Spread the word! Free to attend, but only ~250 se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/78DGpmPci5",
        "expanded_url" : "http:\/\/www.tedxbuffalo.com\/tedxbuffalo-2013\/attend\/",
        "display_url" : "tedxbuffalo.com\/tedxbuffalo-20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365121715375833089",
    "text" : "Applications to attend TEDxBuffalo 2013 are open! http:\/\/t.co\/78DGpmPci5 Spread the word! Free to attend, but only ~250 seats.",
    "id" : 365121715375833089,
    "created_at" : "2013-08-07 14:46:15 +0000",
    "user" : {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "protected" : false,
      "id_str" : "140515765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892872495\/TedxBuffalo_Logo_Square__1__normal.JPG",
      "id" : 140515765,
      "verified" : false
    }
  },
  "id" : 365122088127827970,
  "created_at" : "2013-08-07 14:47:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 104, 114 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "player",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5czEFX9qki",
      "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424127887323420604578652051466314748.html#articleTabs%3Darticle",
      "display_url" : "online.wsj.com\/article\/SB1000\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365111844978954241",
  "text" : "RT @asianmack: My friend @JZ is featured in the Wall Street Journal about his role managing Basecamp at @37signals. http:\/\/t.co\/5czEFX9qki \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 89, 99 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "player",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/5czEFX9qki",
        "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424127887323420604578652051466314748.html#articleTabs%3Darticle",
        "display_url" : "online.wsj.com\/article\/SB1000\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365107598657196032",
    "text" : "My friend @JZ is featured in the Wall Street Journal about his role managing Basecamp at @37signals. http:\/\/t.co\/5czEFX9qki #player",
    "id" : 365107598657196032,
    "created_at" : "2013-08-07 13:50:09 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 365111844978954241,
  "created_at" : "2013-08-07 14:07:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365111734060597248",
  "text" : "Bike achievement unlocked: Get yelled at by a driver for claiming the lane when entering a circle with no bike lane!",
  "id" : 365111734060597248,
  "created_at" : "2013-08-07 14:06:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365084105777487872",
  "geo" : { },
  "id_str" : "365095468495147008",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending just saying.",
  "id" : 365095468495147008,
  "in_reply_to_status_id" : 365084105777487872,
  "created_at" : "2013-08-07 13:01:57 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "indyK1ng",
      "screen_name" : "indyK1ng",
      "indices" : [ 0, 9 ],
      "id_str" : "18765238",
      "id" : 18765238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364951195833466880",
  "geo" : { },
  "id_str" : "364951467829886977",
  "in_reply_to_user_id" : 18765238,
  "text" : "@indyK1ng I played the demo for 20 minutes maybe. Slow down!",
  "id" : 364951467829886977,
  "in_reply_to_status_id" : 364951195833466880,
  "created_at" : "2013-08-07 03:29:45 +0000",
  "in_reply_to_screen_name" : "indyK1ng",
  "in_reply_to_user_id_str" : "18765238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364950954874908674",
  "text" : "Kerbal actually strikes me more like Minecraft...more fun to watch others play via YouTube than burn 100s of hours.",
  "id" : 364950954874908674,
  "created_at" : "2013-08-07 03:27:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fS5qU4ERHw",
      "expanded_url" : "http:\/\/wiki.kerbalspaceprogram.com\/wiki\/Cheat_Sheet",
      "display_url" : "wiki.kerbalspaceprogram.com\/wiki\/Cheat_She\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364948401240018945",
  "text" : "KSP seems fun, launched a ship into space and landed but... as a Dwarf Fortress\/Nethack vet this is way daunting. http:\/\/t.co\/fS5qU4ERHw",
  "id" : 364948401240018945,
  "created_at" : "2013-08-07 03:17:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364941725057294338",
  "geo" : { },
  "id_str" : "364944313853034496",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren I miss dorf fort. I wish Fortress mode would get updated. It's been way too long.",
  "id" : 364944313853034496,
  "in_reply_to_status_id" : 364941725057294338,
  "created_at" : "2013-08-07 03:01:19 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364940934162558976",
  "geo" : { },
  "id_str" : "364943826353262594",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Performance is just terrible. 2011 mbp.",
  "id" : 364943826353262594,
  "in_reply_to_status_id" : 364940934162558976,
  "created_at" : "2013-08-07 02:59:23 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364937736043507712",
  "geo" : { },
  "id_str" : "364940288629800962",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Does it perform terribly and has a fixed square screen rez for you too?",
  "id" : 364940288629800962,
  "in_reply_to_status_id" : 364937736043507712,
  "created_at" : "2013-08-07 02:45:19 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364936595272515585",
  "geo" : { },
  "id_str" : "364936958151114752",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza 8 ascensions on NetHack and several Dwarf Fortresses in...I don't think anything can waste time more.",
  "id" : 364936958151114752,
  "in_reply_to_status_id" : 364936595272515585,
  "created_at" : "2013-08-07 02:32:05 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 62, 70 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364936292766728195",
  "text" : "Kerbal Space Program, been hearing good things. Worth it? \/cc @capotej",
  "id" : 364936292766728195,
  "created_at" : "2013-08-07 02:29:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Berglund",
      "screen_name" : "tlberglund",
      "indices" : [ 0, 11 ],
      "id_str" : "14211984",
      "id" : 14211984
    }, {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 12, 20 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364933360444911616",
  "geo" : { },
  "id_str" : "364936026176761856",
  "in_reply_to_user_id" : 14211984,
  "text" : "@tlberglund @haacked Oh good, I can turn off web notifications! Done. I don't get why reinventing the wheel is necessary here.",
  "id" : 364936026176761856,
  "in_reply_to_status_id" : 364933360444911616,
  "created_at" : "2013-08-07 02:28:23 +0000",
  "in_reply_to_screen_name" : "tlberglund",
  "in_reply_to_user_id_str" : "14211984",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/rPzOlEMSWf",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/6170615",
      "display_url" : "gist.github.com\/qrush\/6170615"
    } ]
  },
  "in_reply_to_status_id_str" : "364930044612722690",
  "geo" : { },
  "id_str" : "364931296402739200",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen ah, here's what confused me, as part of NPM install, a rebuild happened: https:\/\/t.co\/rPzOlEMSWf",
  "id" : 364931296402739200,
  "in_reply_to_status_id" : 364930044612722690,
  "created_at" : "2013-08-07 02:09:35 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364929436946149378",
  "text" : "I think running `npm install` just told node to update itself. Installed 0.8 from brew, now it's 0.10.15. WTF?",
  "id" : 364929436946149378,
  "created_at" : "2013-08-07 02:02:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Berglund",
      "screen_name" : "tlberglund",
      "indices" : [ 0, 11 ],
      "id_str" : "14211984",
      "id" : 14211984
    }, {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 12, 20 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364919704256651264",
  "geo" : { },
  "id_str" : "364928750640574465",
  "in_reply_to_user_id" : 14211984,
  "text" : "@tlberglund @haacked \"Unread: 268\" ...what a mess. I don't need another inbox :(",
  "id" : 364928750640574465,
  "in_reply_to_status_id" : 364919704256651264,
  "created_at" : "2013-08-07 01:59:28 +0000",
  "in_reply_to_screen_name" : "tlberglund",
  "in_reply_to_user_id_str" : "14211984",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364925466676703232",
  "geo" : { },
  "id_str" : "364925734684336128",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo hell yeah!",
  "id" : 364925734684336128,
  "in_reply_to_status_id" : 364925466676703232,
  "created_at" : "2013-08-07 01:47:29 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 16, 25 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364913889353277442",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @LawnMemo did you guys just get GA tickets for Rochester? Sad that there's not any reserved seats.",
  "id" : 364913889353277442,
  "created_at" : "2013-08-07 01:00:25 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/rMiP4xWcaz",
      "expanded_url" : "http:\/\/breachattack.com\/",
      "display_url" : "breachattack.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364911907959881728",
  "text" : "This isn't a joke. If you do work on the web get reading, and start planning to mitigate. http:\/\/t.co\/rMiP4xWcaz",
  "id" : 364911907959881728,
  "created_at" : "2013-08-07 00:52:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/m3fux3f4L0",
      "expanded_url" : "http:\/\/tmblr.co\/ZR9abyrctrnN",
      "display_url" : "tmblr.co\/ZR9abyrctrnN"
    } ]
  },
  "geo" : { },
  "id_str" : "364893152018046977",
  "text" : "RT @ashedryden: I'm gonna hack into, like, 30 databases when I get home. http:\/\/t.co\/m3fux3f4L0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/tumblr\/id305343404?mt=8&uo=4\" rel=\"nofollow\"\u003ETumblr on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/m3fux3f4L0",
        "expanded_url" : "http:\/\/tmblr.co\/ZR9abyrctrnN",
        "display_url" : "tmblr.co\/ZR9abyrctrnN"
      } ]
    },
    "geo" : { },
    "id_str" : "364892971235160065",
    "text" : "I'm gonna hack into, like, 30 databases when I get home. http:\/\/t.co\/m3fux3f4L0",
    "id" : 364892971235160065,
    "created_at" : "2013-08-06 23:37:18 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 364893152018046977,
  "created_at" : "2013-08-06 23:38:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dannytatom",
      "screen_name" : "dannytatom",
      "indices" : [ 0, 11 ],
      "id_str" : "2500287421",
      "id" : 2500287421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364885271499636736",
  "geo" : { },
  "id_str" : "364885458276192258",
  "in_reply_to_user_id" : 17012066,
  "text" : "@dannytatom None of them. Learn something outside the web.",
  "id" : 364885458276192258,
  "in_reply_to_status_id" : 364885271499636736,
  "created_at" : "2013-08-06 23:07:27 +0000",
  "in_reply_to_screen_name" : "rabitrup",
  "in_reply_to_user_id_str" : "17012066",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natasha allegri",
      "screen_name" : "natazilla",
      "indices" : [ 3, 13 ],
      "id_str" : "14860638",
      "id" : 14860638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/p7BhillJen",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UetSeZtrY2s&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=UetSeZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364883753828499457",
  "text" : "RT @natazilla: 2nd part of bee and puppycat is up http:\/\/t.co\/p7BhillJen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/p7BhillJen",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UetSeZtrY2s&feature=player_embedded",
        "display_url" : "youtube.com\/watch?v=UetSeZ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364869992740696064",
    "text" : "2nd part of bee and puppycat is up http:\/\/t.co\/p7BhillJen",
    "id" : 364869992740696064,
    "created_at" : "2013-08-06 22:05:59 +0000",
    "user" : {
      "name" : "natasha allegri",
      "screen_name" : "natazilla",
      "protected" : false,
      "id_str" : "14860638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541179560776065025\/Y32So1Ky_normal.png",
      "id" : 14860638,
      "verified" : false
    }
  },
  "id" : 364883753828499457,
  "created_at" : "2013-08-06 23:00:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364883717707141120",
  "text" : "RT @JZ: My favorite sketching tool: iA Writer. \n\nI'm not joking. UI design starts with words.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364882720914026496",
    "text" : "My favorite sketching tool: iA Writer. \n\nI'm not joking. UI design starts with words.",
    "id" : 364882720914026496,
    "created_at" : "2013-08-06 22:56:34 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 364883717707141120,
  "created_at" : "2013-08-06 23:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364875609047973889",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt The Brave Little Air Bud",
  "id" : 364875609047973889,
  "created_at" : "2013-08-06 22:28:18 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364863688836005888",
  "geo" : { },
  "id_str" : "364864242618347520",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle I don't mind. it's like picking which screwdriver to use instead of having multiple heads. at the end, same job, different tool.",
  "id" : 364864242618347520,
  "in_reply_to_status_id" : 364863688836005888,
  "created_at" : "2013-08-06 21:43:08 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364862442083323904",
  "text" : "Learned about fgrep and zfgrep yesterday. Always Be Learning.",
  "id" : 364862442083323904,
  "created_at" : "2013-08-06 21:35:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Park",
      "screen_name" : "robpark",
      "indices" : [ 3, 11 ],
      "id_str" : "21584532",
      "id" : 21584532
    }, {
      "name" : "leandog",
      "screen_name" : "leandog",
      "indices" : [ 139, 140 ],
      "id_str" : "18708694",
      "id" : 18708694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FeTGWpgkAZ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364858824781348865",
  "text" : "RT @robpark: Kinda cool that Buffalo's growing a Ruby community and a having a conference: http:\/\/t.co\/FeTGWpgkAZ Not too far from Clevelan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "leandog",
        "screen_name" : "leandog",
        "indices" : [ 132, 140 ],
        "id_str" : "18708694",
        "id" : 18708694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/FeTGWpgkAZ",
        "expanded_url" : "http:\/\/nickelcityruby.com\/",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "364807806429298690",
    "text" : "Kinda cool that Buffalo's growing a Ruby community and a having a conference: http:\/\/t.co\/FeTGWpgkAZ Not too far from Cleveland cc\/ @leandog",
    "id" : 364807806429298690,
    "created_at" : "2013-08-06 17:58:53 +0000",
    "user" : {
      "name" : "Rob Park",
      "screen_name" : "robpark",
      "protected" : false,
      "id_str" : "21584532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2717083781\/5cb05f437a3934951a06a68c1311e0df_normal.png",
      "id" : 21584532,
      "verified" : false
    }
  },
  "id" : 364858824781348865,
  "created_at" : "2013-08-06 21:21:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Park",
      "screen_name" : "robpark",
      "indices" : [ 0, 8 ],
      "id_str" : "21584532",
      "id" : 21584532
    }, {
      "name" : "leandog",
      "screen_name" : "leandog",
      "indices" : [ 9, 17 ],
      "id_str" : "18708694",
      "id" : 18708694
    }, {
      "name" : "leandog",
      "screen_name" : "leandog",
      "indices" : [ 68, 76 ],
      "id_str" : "18708694",
      "id" : 18708694
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 99, 108 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364807806429298690",
  "geo" : { },
  "id_str" : "364811586868748288",
  "in_reply_to_user_id" : 21584532,
  "text" : "@robpark @leandog thanks! Would love to see the...white hats? Furry @leandog caps? Whatever was at @codemash, in Buffalo this September :)",
  "id" : 364811586868748288,
  "in_reply_to_status_id" : 364807806429298690,
  "created_at" : "2013-08-06 18:13:54 +0000",
  "in_reply_to_screen_name" : "robpark",
  "in_reply_to_user_id_str" : "21584532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364807552497758208",
  "text" : "RT @ubuwaits: Designers &amp; Code\n\nIf it helps you create a better product, do it.\n\nIf it distracts you from creating a better product, don't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364807296309665792",
    "text" : "Designers &amp; Code\n\nIf it helps you create a better product, do it.\n\nIf it distracts you from creating a better product, don't.",
    "id" : 364807296309665792,
    "created_at" : "2013-08-06 17:56:51 +0000",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 364807552497758208,
  "created_at" : "2013-08-06 17:57:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/miox4MGxHU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xG6K5hbPJKs",
      "display_url" : "youtube.com\/watch?v=xG6K5h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364793609133891584",
  "text" : "Completely Honest OBGYN (lots of language!) http:\/\/t.co\/miox4MGxHU",
  "id" : 364793609133891584,
  "created_at" : "2013-08-06 17:02:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 10, 25 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "Buffalo Game Space",
      "screen_name" : "BuffGameSpace",
      "indices" : [ 26, 40 ],
      "id_str" : "1370047219",
      "id" : 1370047219
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 74, 83 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364778284061429762",
  "geo" : { },
  "id_str" : "364780257309495297",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 @Chris_Langford @BuffGameSpace I'm sad this has to compete with @OpenHack :(",
  "id" : 364780257309495297,
  "in_reply_to_status_id" : 364778284061429762,
  "created_at" : "2013-08-06 16:09:25 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364769921080635392",
  "geo" : { },
  "id_str" : "364770965034504193",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren I thought so, but \"easy\" is relative.",
  "id" : 364770965034504193,
  "in_reply_to_status_id" : 364769921080635392,
  "created_at" : "2013-08-06 15:32:29 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364768783618949120",
  "geo" : { },
  "id_str" : "364768966729670656",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk yeah totally first world problems.",
  "id" : 364768966729670656,
  "in_reply_to_status_id" : 364768783618949120,
  "created_at" : "2013-08-06 15:24:33 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364768214854533120",
  "text" : "Feeling powerless to fix real things lately. Glasses' anti-glare shield flaking off, causing blur. Bike spoke, caliper brakes broken. Ugh.",
  "id" : 364768214854533120,
  "created_at" : "2013-08-06 15:21:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364761749037129728",
  "text" : "RT @ChristineLSloc: There is a cowork space in Buffalo, @coworkbuffalo, and half of their twitter pics are of coffee. Wondering if they are\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 36, 50 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364198436284809216",
    "text" : "There is a cowork space in Buffalo, @coworkbuffalo, and half of their twitter pics are of coffee. Wondering if they are actually in Seattle.",
    "id" : 364198436284809216,
    "created_at" : "2013-08-05 01:37:28 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 364761749037129728,
  "created_at" : "2013-08-06 14:55:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/IZpdfFY84R",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B0087RWXTO\/ref=cm_sw_su_dp",
      "display_url" : "amazon.com\/dp\/B0087RWXTO\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364758455485071360",
  "text" : "And $30 shipping. http:\/\/t.co\/IZpdfFY84R",
  "id" : 364758455485071360,
  "created_at" : "2013-08-06 14:42:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBlue Airways",
      "screen_name" : "JetBlue",
      "indices" : [ 28, 36 ],
      "id_str" : "6449282",
      "id" : 6449282
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 73, 88 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/AA1jxyx7Vd",
      "expanded_url" : "http:\/\/www2.jetblue.com\/deals\/a-midsummer-flights-dream-sale\/?source=EM080613_Hero_Airways",
      "display_url" : "www2.jetblue.com\/deals\/a-midsum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364758010066763776",
  "text" : "Stupidly cheap flights from @JetBlue to BUF from BOS, FLL, RSW, MCO (for @nickelcityruby!): http:\/\/t.co\/AA1jxyx7Vd",
  "id" : 364758010066763776,
  "created_at" : "2013-08-06 14:41:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 3, 18 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QxeW3sUvXe",
      "expanded_url" : "http:\/\/ftp.ruby-lang.org",
      "display_url" : "ftp.ruby-lang.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/yypREwUGIa",
      "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org\/issues\/259",
      "display_url" : "github.com\/ruby\/www.ruby-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364752988948008960",
  "text" : "RT @TheDeadSerious: Beware of ruby source packages downloaded from http:\/\/t.co\/QxeW3sUvXe today - something's shifty there right now: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/QxeW3sUvXe",
        "expanded_url" : "http:\/\/ftp.ruby-lang.org",
        "display_url" : "ftp.ruby-lang.org"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/yypREwUGIa",
        "expanded_url" : "https:\/\/github.com\/ruby\/www.ruby-lang.org\/issues\/259",
        "display_url" : "github.com\/ruby\/www.ruby-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364752721259139072",
    "text" : "Beware of ruby source packages downloaded from http:\/\/t.co\/QxeW3sUvXe today - something's shifty there right now: https:\/\/t.co\/yypREwUGIa",
    "id" : 364752721259139072,
    "created_at" : "2013-08-06 14:20:00 +0000",
    "user" : {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "protected" : false,
      "id_str" : "6151392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3718326228\/d5ccd985ca3f1398820eb033bf3936ff_normal.jpeg",
      "id" : 6151392,
      "verified" : false
    }
  },
  "id" : 364752988948008960,
  "created_at" : "2013-08-06 14:21:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 40, 55 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/fvdEYDSVcf",
      "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/polish-your-trade-nickel-city-ruby-set-for-september\/50603",
      "display_url" : "buffalo.com\/news\/blog\/poli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364745017971052545",
  "text" : "Starting to see some local coverage for @nickelcityruby! http:\/\/t.co\/fvdEYDSVcf",
  "id" : 364745017971052545,
  "created_at" : "2013-08-06 13:49:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "indices" : [ 3, 17 ],
      "id_str" : "25321479",
      "id" : 25321479
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 143, 144 ],
      "id_str" : "632391390",
      "id" : 632391390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/HzRTD2LlUo",
      "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/polish-your-trade-nickel-city-ruby-set-for-september\/50603",
      "display_url" : "buffalo.com\/news\/blog\/poli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364744883703406592",
  "text" : "RT @BuffaloDotCom: Programming aficionado? Learn new language &amp; discuss the industry at Nickel City Ruby in Sept. More: http:\/\/t.co\/HzRTD2L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Z80 Labs",
        "screen_name" : "Z80Labs",
        "indices" : [ 128, 136 ],
        "id_str" : "632391390",
        "id" : 632391390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/HzRTD2LlUo",
        "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/polish-your-trade-nickel-city-ruby-set-for-september\/50603",
        "display_url" : "buffalo.com\/news\/blog\/poli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364415989917945856",
    "text" : "Programming aficionado? Learn new language &amp; discuss the industry at Nickel City Ruby in Sept. More: http:\/\/t.co\/HzRTD2LlUo @Z80Labs",
    "id" : 364415989917945856,
    "created_at" : "2013-08-05 16:01:57 +0000",
    "user" : {
      "name" : "Buffalo Dot Com",
      "screen_name" : "BuffaloDotCom",
      "protected" : false,
      "id_str" : "25321479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467067080139759616\/zJQOtsXK_normal.jpeg",
      "id" : 25321479,
      "verified" : false
    }
  },
  "id" : 364744883703406592,
  "created_at" : "2013-08-06 13:48:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 9, 17 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 35, 44 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 73, 87 ],
      "id_str" : "15060778",
      "id" : 15060778
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 88, 97 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Eric Wastl",
      "screen_name" : "topaz2078",
      "indices" : [ 98, 108 ],
      "id_str" : "2254035434",
      "id" : 2254035434
    }, {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 109, 115 ],
      "id_str" : "15477591",
      "id" : 15477591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/K9pMaqk9JP",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo",
      "display_url" : "openhack.github.io\/buffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "364735235390320641",
  "text" : "Heads up @synacor, who\u2019s coming to @openhack? http:\/\/t.co\/K9pMaqk9JP \/cc @gnuconsulting @sabiddle @topaz2078 @Braxo",
  "id" : 364735235390320641,
  "created_at" : "2013-08-06 13:10:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 8, 17 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/K9pMaqk9JP",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo",
      "display_url" : "openhack.github.io\/buffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "364734661143957504",
  "text" : "Buffalo @openhack is tonight! http:\/\/t.co\/K9pMaqk9JP",
  "id" : 364734661143957504,
  "created_at" : "2013-08-06 13:08:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Sears",
      "screen_name" : "mattsears",
      "indices" : [ 3, 13 ],
      "id_str" : "14579367",
      "id" : 14579367
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HVR9lHX8w0",
      "expanded_url" : "http:\/\/bit.ly\/1cryWRV",
      "display_url" : "bit.ly\/1cryWRV"
    } ]
  },
  "geo" : { },
  "id_str" : "364604142762721280",
  "text" : "RT @mattsears: Be sure you get to @nickelcityruby in September. It looks like it's going to be a great conference - http:\/\/t.co\/HVR9lHX8w0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/HVR9lHX8w0",
        "expanded_url" : "http:\/\/bit.ly\/1cryWRV",
        "display_url" : "bit.ly\/1cryWRV"
      } ]
    },
    "geo" : { },
    "id_str" : "364469130944315392",
    "text" : "Be sure you get to @nickelcityruby in September. It looks like it's going to be a great conference - http:\/\/t.co\/HVR9lHX8w0",
    "id" : 364469130944315392,
    "created_at" : "2013-08-05 19:33:07 +0000",
    "user" : {
      "name" : "Matt Sears",
      "screen_name" : "mattsears",
      "protected" : false,
      "id_str" : "14579367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474933129623252992\/qqCE6auG_normal.jpeg",
      "id" : 14579367,
      "verified" : false
    }
  },
  "id" : 364604142762721280,
  "created_at" : "2013-08-06 04:29:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364490881069350913",
  "text" : "RT @nickbilton: Amazing that today a 2-year-old start-up sells for $1 billion and a 135-year-old newspaper sells for $250 million.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364489534069018624",
    "text" : "Amazing that today a 2-year-old start-up sells for $1 billion and a 135-year-old newspaper sells for $250 million.",
    "id" : 364489534069018624,
    "created_at" : "2013-08-05 20:54:11 +0000",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477230361802338304\/I5i2rB_D_normal.jpeg",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 364490881069350913,
  "created_at" : "2013-08-05 20:59:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 47, 55 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 56, 65 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/vR9FTm1tBv",
      "expanded_url" : "http:\/\/synb.org\/",
      "display_url" : "synb.org"
    } ]
  },
  "geo" : { },
  "id_str" : "364477559695609856",
  "text" : "This looks awesome: http:\/\/t.co\/vR9FTm1tBv \/cc @jayunit @bquarant",
  "id" : 364477559695609856,
  "created_at" : "2013-08-05 20:06:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Naramore",
      "screen_name" : "ElizabethN",
      "indices" : [ 0, 11 ],
      "id_str" : "9697482",
      "id" : 9697482
    }, {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 12, 24 ],
      "id_str" : "6144652",
      "id" : 6144652
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 53, 68 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "PyCon",
      "screen_name" : "pycon",
      "indices" : [ 109, 115 ],
      "id_str" : "9475182",
      "id" : 9475182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364443156395200512",
  "geo" : { },
  "id_str" : "364454791591624705",
  "in_reply_to_user_id" : 9697482,
  "text" : "@ElizabethN @ryanbriones that's been my approach for @nickelcityruby - based on other regional confs, forked @pycon's code of conduct too",
  "id" : 364454791591624705,
  "in_reply_to_status_id" : 364443156395200512,
  "created_at" : "2013-08-05 18:36:08 +0000",
  "in_reply_to_screen_name" : "ElizabethN",
  "in_reply_to_user_id_str" : "9697482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umair",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364453245952851970",
  "text" : "RT @umairh: The greatest minds of my generation are making test tube burgers, banner ads, and 3d printed sex toys.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364452781195005952",
    "text" : "The greatest minds of my generation are making test tube burgers, banner ads, and 3d printed sex toys.",
    "id" : 364452781195005952,
    "created_at" : "2013-08-05 18:28:08 +0000",
    "user" : {
      "name" : "umair",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427316127916494848\/idsuKJeo_normal.jpeg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 364453245952851970,
  "created_at" : "2013-08-05 18:29:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364451837334007809",
  "geo" : { },
  "id_str" : "364452660272832512",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella for us it's more about concepts. the \"Movable\" concern. \"Visible\", \"Trashable\", etc. What models are concerned with what.",
  "id" : 364452660272832512,
  "in_reply_to_status_id" : 364451837334007809,
  "created_at" : "2013-08-05 18:27:40 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hWbMo3y8en",
      "expanded_url" : "http:\/\/ignitebuffalo.com\/",
      "display_url" : "ignitebuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364452053088616448",
  "text" : "RT @kevinpurdy: Summary tweet: we're looking for nerds of all kinds with fun obsessions to talk at Ignite Buffalo, Sept. 19. Details: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hWbMo3y8en",
        "expanded_url" : "http:\/\/ignitebuffalo.com\/",
        "display_url" : "ignitebuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "364451877003743232",
    "text" : "Summary tweet: we're looking for nerds of all kinds with fun obsessions to talk at Ignite Buffalo, Sept. 19. Details: http:\/\/t.co\/hWbMo3y8en",
    "id" : 364451877003743232,
    "created_at" : "2013-08-05 18:24:33 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 364452053088616448,
  "created_at" : "2013-08-05 18:25:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364450867287556096",
  "text" : "RT @kevinpurdy: Do you want to talk about something you're obsessed with at Ignite Buffalo? And get free beer for the night of Sept. 19? Hi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364450838171119617",
    "text" : "Do you want to talk about something you're obsessed with at Ignite Buffalo? And get free beer for the night of Sept. 19? Hit me up here.",
    "id" : 364450838171119617,
    "created_at" : "2013-08-05 18:20:25 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 364450867287556096,
  "created_at" : "2013-08-05 18:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 3, 14 ],
      "id_str" : "14390268",
      "id" : 14390268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/NeiUn91VVC",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364435539425902592",
  "text" : "RT @rachelober: Come see me at Nickel City Ruby in September! http:\/\/t.co\/NeiUn91VVC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/NeiUn91VVC",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "364400835003826179",
    "text" : "Come see me at Nickel City Ruby in September! http:\/\/t.co\/NeiUn91VVC",
    "id" : 364400835003826179,
    "created_at" : "2013-08-05 15:01:43 +0000",
    "user" : {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "protected" : false,
      "id_str" : "14390268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321996605296640\/ekU7oNFN_normal.jpeg",
      "id" : 14390268,
      "verified" : false
    }
  },
  "id" : 364435539425902592,
  "created_at" : "2013-08-05 17:19:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 0, 10 ],
      "id_str" : "14437070",
      "id" : 14437070
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 11, 18 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 19, 25 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364425569032601600",
  "geo" : { },
  "id_str" : "364426385831378945",
  "in_reply_to_user_id" : 14437070,
  "text" : "@marksands @soffes @mattt ah, cool. i'm more curious about the bigger picture, and especially integration\/functional testing",
  "id" : 364426385831378945,
  "in_reply_to_status_id" : 364425569032601600,
  "created_at" : "2013-08-05 16:43:15 +0000",
  "in_reply_to_screen_name" : "marksands",
  "in_reply_to_user_id_str" : "14437070",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    }, {
      "name" : "NSHipster",
      "screen_name" : "NSHipster",
      "indices" : [ 7, 17 ],
      "id_str" : "629523445",
      "id" : 629523445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/OeXVgfzV6m",
      "expanded_url" : "http:\/\/nshipster.com\/testing\/",
      "display_url" : "nshipster.com\/testing\/"
    } ]
  },
  "in_reply_to_status_id_str" : "364423058359980034",
  "geo" : { },
  "id_str" : "364423538372907011",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt @NSHipster How about http:\/\/t.co\/OeXVgfzV6m ?",
  "id" : 364423538372907011,
  "in_reply_to_status_id" : 364423058359980034,
  "created_at" : "2013-08-05 16:31:56 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364401377042108416",
  "geo" : { },
  "id_str" : "364401564540092416",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark At least someone gets the reference.",
  "id" : 364401564540092416,
  "in_reply_to_status_id" : 364401377042108416,
  "created_at" : "2013-08-05 15:04:37 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 0, 13 ],
      "id_str" : "6082492",
      "id" : 6082492
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364400597128069123",
  "geo" : { },
  "id_str" : "364401046837149697",
  "in_reply_to_user_id" : 6082492,
  "text" : "@greggpollack i'd appreciate (another) @nickelcityruby shoutout! :)",
  "id" : 364401046837149697,
  "in_reply_to_status_id" : 364400597128069123,
  "created_at" : "2013-08-05 15:02:34 +0000",
  "in_reply_to_screen_name" : "greggpollack",
  "in_reply_to_user_id_str" : "6082492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364400119849824256",
  "text" : "46 days and the tickets run out...46 days!! http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 364400119849824256,
  "created_at" : "2013-08-05 14:58:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zalar",
      "screen_name" : "ZalarMark",
      "indices" : [ 0, 10 ],
      "id_str" : "483153848",
      "id" : 483153848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364222932379508736",
  "geo" : { },
  "id_str" : "364227098799374337",
  "in_reply_to_user_id" : 483153848,
  "text" : "@ZalarMark started Avengers and now lacking the energy. Enjoy it!",
  "id" : 364227098799374337,
  "in_reply_to_status_id" : 364222932379508736,
  "created_at" : "2013-08-05 03:31:22 +0000",
  "in_reply_to_screen_name" : "ZalarMark",
  "in_reply_to_user_id_str" : "483153848",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364205765692628992",
  "geo" : { },
  "id_str" : "364207522862743552",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy a duel happens sometimes. Saw it last summer.",
  "id" : 364207522862743552,
  "in_reply_to_status_id" : 364205765692628992,
  "created_at" : "2013-08-05 02:13:34 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "couchtour",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364199858812354560",
  "text" : "Hopes for tonight's #phish #couchtour: Ride Captain Ride, Scent of a Mule (theremin!)",
  "id" : 364199858812354560,
  "created_at" : "2013-08-05 01:43:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "364198158164697088",
  "text" : "We have a lot of tickets left for http:\/\/t.co\/3UAdoKZw7Q ! It's going to be an awesome, small, and super valuable conf to attend. Be here!",
  "id" : 364198158164697088,
  "created_at" : "2013-08-05 01:36:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/jDkFSe5XbV",
      "expanded_url" : "https:\/\/twitter.com\/joshkorin\/status\/363897055292297216",
      "display_url" : "twitter.com\/joshkorin\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "363902331630268417",
  "geo" : { },
  "id_str" : "363902800939335680",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo too pumped to sleep if this is true: https:\/\/t.co\/jDkFSe5XbV",
  "id" : 363902800939335680,
  "in_reply_to_status_id" : 363902331630268417,
  "created_at" : "2013-08-04 06:02:43 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363899598730825728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1957252843, -80.5613033878 ]
  },
  "id_str" : "363900117986078720",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant conspiracy.",
  "id" : 363900117986078720,
  "in_reply_to_status_id" : 363899598730825728,
  "created_at" : "2013-08-04 05:52:03 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 3, 13 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "video",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ZAnKh1EKUQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/clGJV7NL3I\/",
      "display_url" : "instagram.com\/p\/clGJV7NL3I\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363896244722089984",
  "text" : "RT @Phish_FTR: Steam #video http:\/\/t.co\/ZAnKh1EKUQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "video",
        "indices" : [ 6, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/ZAnKh1EKUQ",
        "expanded_url" : "http:\/\/instagram.com\/p\/clGJV7NL3I\/",
        "display_url" : "instagram.com\/p\/clGJV7NL3I\/"
      } ]
    },
    "geo" : { },
    "id_str" : "363895670563815424",
    "text" : "Steam #video http:\/\/t.co\/ZAnKh1EKUQ",
    "id" : 363895670563815424,
    "created_at" : "2013-08-04 05:34:23 +0000",
    "user" : {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "protected" : false,
      "id_str" : "153850397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000065818163\/de7aca9d2eb0c2005f7df69ad86aafa4_normal.jpeg",
      "id" : 153850397,
      "verified" : false
    }
  },
  "id" : 363896244722089984,
  "created_at" : "2013-08-04 05:36:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363895438413283329",
  "text" : "Rock &amp; Roll &gt; Steam, necessary fogginess for SF.",
  "id" : 363895438413283329,
  "created_at" : "2013-08-04 05:33:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363892476953628672",
  "geo" : { },
  "id_str" : "363895319492182017",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo This entire show has been amazing.",
  "id" : 363895319492182017,
  "in_reply_to_status_id" : 363892476953628672,
  "created_at" : "2013-08-04 05:32:59 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363876804421242880",
  "geo" : { },
  "id_str" : "363878580737949696",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment still in first set of tonight's! Give it an hour or two more :)",
  "id" : 363878580737949696,
  "in_reply_to_status_id" : 363876804421242880,
  "created_at" : "2013-08-04 04:26:28 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "indices" : [ 10, 20 ],
      "id_str" : "71065878",
      "id" : 71065878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363875072315887618",
  "geo" : { },
  "id_str" : "363875437451026432",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @jacknagel this is why my favorite part of MIT license is \u201CAS IS\u201D",
  "id" : 363875437451026432,
  "in_reply_to_status_id" : 363875072315887618,
  "created_at" : "2013-08-04 04:13:59 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "indices" : [ 3, 13 ],
      "id_str" : "71065878",
      "id" : 71065878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363874679461003264",
  "text" : "RT @jacknagel: Maybe it's unfair to generalize, but a not-insignificant number of people have unreasonable expectations about pull request \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363862241499553792",
    "text" : "Maybe it's unfair to generalize, but a not-insignificant number of people have unreasonable expectations about pull request turnaround time.",
    "id" : 363862241499553792,
    "created_at" : "2013-08-04 03:21:33 +0000",
    "user" : {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "protected" : false,
      "id_str" : "71065878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2647371303\/6548d0cfa9c822d9a55657537f529142_normal.jpeg",
      "id" : 71065878,
      "verified" : false
    }
  },
  "id" : 363874679461003264,
  "created_at" : "2013-08-04 04:10:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "indices" : [ 3, 13 ],
      "id_str" : "71065878",
      "id" : 71065878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363874663908536320",
  "text" : "RT @jacknagel: Having some \"thoughts\" about the \"GitHub generation\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363860370944827393",
    "text" : "Having some \"thoughts\" about the \"GitHub generation\".",
    "id" : 363860370944827393,
    "created_at" : "2013-08-04 03:14:07 +0000",
    "user" : {
      "name" : "Jack Nagel",
      "screen_name" : "jacknagel",
      "protected" : false,
      "id_str" : "71065878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2647371303\/6548d0cfa9c822d9a55657537f529142_normal.jpeg",
      "id" : 71065878,
      "verified" : false
    }
  },
  "id" : 363874663908536320,
  "created_at" : "2013-08-04 04:10:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    }, {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 46, 58 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363870850719961088",
  "geo" : { },
  "id_str" : "363871140021682176",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato I\u2019ve seen some. You should talk to @john_floren sometime, he\u2019s contributed to the kernel.",
  "id" : 363871140021682176,
  "in_reply_to_status_id" : 363870850719961088,
  "created_at" : "2013-08-04 03:56:54 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqui Maher",
      "screen_name" : "jacqui",
      "indices" : [ 0, 7 ],
      "id_str" : "355203",
      "id" : 355203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363868372460519424",
  "geo" : { },
  "id_str" : "363868631932739586",
  "in_reply_to_user_id" : 355203,
  "text" : "@jacqui I don't even anymore.",
  "id" : 363868631932739586,
  "in_reply_to_status_id" : 363868372460519424,
  "created_at" : "2013-08-04 03:46:56 +0000",
  "in_reply_to_screen_name" : "jacqui",
  "in_reply_to_user_id_str" : "355203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 8, 14 ]
    }, {
      "text" : "couchtour",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/NrHVDZObSA",
      "expanded_url" : "http:\/\/i.imgur.com\/mSW7pLJ.gif",
      "display_url" : "i.imgur.com\/mSW7pLJ.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "363865207312875520",
  "text" : "Current #phish #couchtour status http:\/\/t.co\/NrHVDZObSA",
  "id" : 363865207312875520,
  "created_at" : "2013-08-04 03:33:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ANDREW W.K.",
      "screen_name" : "AndrewWK",
      "indices" : [ 3, 12 ],
      "id_str" : "42744294",
      "id" : 42744294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363862556076548098",
  "text" : "RT @AndrewWK: Playing Role-Playing Games counts as partying.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363841981010558976",
    "text" : "Playing Role-Playing Games counts as partying.",
    "id" : 363841981010558976,
    "created_at" : "2013-08-04 02:01:02 +0000",
    "user" : {
      "name" : "ANDREW W.K.",
      "screen_name" : "AndrewWK",
      "protected" : false,
      "id_str" : "42744294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474004600823894016\/-Zy1asQQ_normal.png",
      "id" : 42744294,
      "verified" : true
    }
  },
  "id" : 363862556076548098,
  "created_at" : "2013-08-04 03:22:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363856400130129920",
  "geo" : { },
  "id_str" : "363857024829759488",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Space for a grill, perhaps? (Easily best part of not being in Boston area)",
  "id" : 363857024829759488,
  "in_reply_to_status_id" : 363856400130129920,
  "created_at" : "2013-08-04 03:00:49 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363856400130129920",
  "geo" : { },
  "id_str" : "363856954411597824",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Nice!",
  "id" : 363856954411597824,
  "in_reply_to_status_id" : 363856400130129920,
  "created_at" : "2013-08-04 03:00:32 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/DrZn7LXuZK",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjHgWwzQ",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjHg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363855878820073473",
  "text" : "View my 3 latest photos on Flickr: http:\/\/t.co\/DrZn7LXuZK",
  "id" : 363855878820073473,
  "created_at" : "2013-08-04 02:56:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Pochron",
      "screen_name" : "frogwentcrazy",
      "indices" : [ 3, 17 ],
      "id_str" : "38924066",
      "id" : 38924066
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 47, 62 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 66, 72 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "ruby",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/N2GuQHoYGY",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3550-a-diverse-conference?utm_content=buffercc8a3&utm_source=buffer&utm_medium=twitter&utm_campaign=Buffer",
      "display_url" : "37signals.com\/svn\/posts\/3550\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363849809452871680",
  "text" : "RT @frogwentcrazy: An overview of the prep for @nickelcityruby by @qrush : http:\/\/t.co\/N2GuQHoYGY #buffalo #ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 28, 43 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 47, 53 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "ruby",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/N2GuQHoYGY",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3550-a-diverse-conference?utm_content=buffercc8a3&utm_source=buffer&utm_medium=twitter&utm_campaign=Buffer",
        "display_url" : "37signals.com\/svn\/posts\/3550\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363770441531662336",
    "text" : "An overview of the prep for @nickelcityruby by @qrush : http:\/\/t.co\/N2GuQHoYGY #buffalo #ruby",
    "id" : 363770441531662336,
    "created_at" : "2013-08-03 21:16:46 +0000",
    "user" : {
      "name" : "Gary Pochron",
      "screen_name" : "garypochron",
      "protected" : false,
      "id_str" : "36580514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821294155\/ade795d65bee581aa36a565bd32bba42_normal.jpeg",
      "id" : 36580514,
      "verified" : false
    }
  },
  "id" : 363849809452871680,
  "created_at" : "2013-08-04 02:32:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363792240864268289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6713919156, -79.6044652072 ]
  },
  "id_str" : "363792995092410369",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw it\u2019s such a terrible Stockholm Syndrome too. Many believe they have no way out and seek zero inspiration elsewhere",
  "id" : 363792995092410369,
  "in_reply_to_status_id" : 363792240864268289,
  "created_at" : "2013-08-03 22:46:23 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363791931119108096",
  "text" : "iOS7 is absolutely terrible on battery life in areas with low connectivity. Embarrassingly bad.",
  "id" : 363791931119108096,
  "created_at" : "2013-08-03 22:42:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/HXfzAozH7I",
      "expanded_url" : "http:\/\/buff.ly\/1eiS3u2",
      "display_url" : "buff.ly\/1eiS3u2"
    } ]
  },
  "geo" : { },
  "id_str" : "363758912459128832",
  "text" : "RT @steveklabnik: A great post about making @nickelcityruby a diverse conference http:\/\/t.co\/HXfzAozH7I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/HXfzAozH7I",
        "expanded_url" : "http:\/\/buff.ly\/1eiS3u2",
        "display_url" : "buff.ly\/1eiS3u2"
      } ]
    },
    "geo" : { },
    "id_str" : "363698342364069888",
    "text" : "A great post about making @nickelcityruby a diverse conference http:\/\/t.co\/HXfzAozH7I",
    "id" : 363698342364069888,
    "created_at" : "2013-08-03 16:30:16 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 363758912459128832,
  "created_at" : "2013-08-03 20:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363757970926354432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.6120608371, -79.6025543192 ]
  },
  "id_str" : "363758685828292608",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits lame, our experiences have been amazing. What happened?",
  "id" : 363758685828292608,
  "in_reply_to_status_id" : 363757970926354432,
  "created_at" : "2013-08-03 20:30:03 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Severini",
      "screen_name" : "luckiestmonkey",
      "indices" : [ 0, 15 ],
      "id_str" : "7141792",
      "id" : 7141792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363509392999596032",
  "geo" : { },
  "id_str" : "363510434172637184",
  "in_reply_to_user_id" : 7141792,
  "text" : "@luckiestmonkey oh god. Couch tour is so good.",
  "id" : 363510434172637184,
  "in_reply_to_status_id" : 363509392999596032,
  "created_at" : "2013-08-03 04:03:35 +0000",
  "in_reply_to_screen_name" : "luckiestmonkey",
  "in_reply_to_user_id_str" : "7141792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik  Hodne",
      "screen_name" : "henrikhodne",
      "indices" : [ 0, 12 ],
      "id_str" : "14746604",
      "id" : 14746604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363495735225880578",
  "geo" : { },
  "id_str" : "363502702124621824",
  "in_reply_to_user_id" : 14746604,
  "text" : "@henrikhodne woot! We have more seats than tickets right now. Not worried about it yet.",
  "id" : 363502702124621824,
  "in_reply_to_status_id" : 363495735225880578,
  "created_at" : "2013-08-03 03:32:52 +0000",
  "in_reply_to_screen_name" : "henrikhodne",
  "in_reply_to_user_id_str" : "14746604",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik  Hodne",
      "screen_name" : "henrikhodne",
      "indices" : [ 0, 12 ],
      "id_str" : "14746604",
      "id" : 14746604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363495077034737666",
  "geo" : { },
  "id_str" : "363495400910503936",
  "in_reply_to_user_id" : 14746604,
  "text" : "@henrikhodne You'll get one if you want it. We'll have *plenty* of space.",
  "id" : 363495400910503936,
  "in_reply_to_status_id" : 363495077034737666,
  "created_at" : "2013-08-03 03:03:51 +0000",
  "in_reply_to_screen_name" : "henrikhodne",
  "in_reply_to_user_id_str" : "14746604",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 3, 11 ],
      "id_str" : "14662889",
      "id" : 14662889
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 135, 140 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363493993469837312",
  "text" : "RT @bokmann: If you're writing ruby and haven't been to one of the outstanding regional conferences, what's stopping you? Dive in with @nic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 122, 137 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363421803563057152",
    "text" : "If you're writing ruby and haven't been to one of the outstanding regional conferences, what's stopping you? Dive in with @nickelcityruby",
    "id" : 363421803563057152,
    "created_at" : "2013-08-02 22:11:24 +0000",
    "user" : {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "protected" : false,
      "id_str" : "14662889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226947944\/dbock-headshot-tight_normal.jpg",
      "id" : 14662889,
      "verified" : false
    }
  },
  "id" : 363493993469837312,
  "created_at" : "2013-08-03 02:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 0, 9 ],
      "id_str" : "19278778",
      "id" : 19278778
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 10, 21 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363400819565006849",
  "geo" : { },
  "id_str" : "363403856236904448",
  "in_reply_to_user_id" : 19278778,
  "text" : "@gogaruco @joshsusser congrats on selling out! Hoping we make it that far.",
  "id" : 363403856236904448,
  "in_reply_to_status_id" : 363400819565006849,
  "created_at" : "2013-08-02 21:00:05 +0000",
  "in_reply_to_screen_name" : "gogaruco",
  "in_reply_to_user_id_str" : "19278778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/DCZ2g69tsg",
      "expanded_url" : "http:\/\/bit.ly\/19Cr6Uq",
      "display_url" : "bit.ly\/19Cr6Uq"
    } ]
  },
  "geo" : { },
  "id_str" : "363403151790977024",
  "text" : "RT @ashedryden: Super excited for @nickelcityruby. Cannot believe tickets are only $99 for this: http:\/\/t.co\/DCZ2g69tsg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 18, 33 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/DCZ2g69tsg",
        "expanded_url" : "http:\/\/bit.ly\/19Cr6Uq",
        "display_url" : "bit.ly\/19Cr6Uq"
      } ]
    },
    "geo" : { },
    "id_str" : "363390117224124416",
    "text" : "Super excited for @nickelcityruby. Cannot believe tickets are only $99 for this: http:\/\/t.co\/DCZ2g69tsg",
    "id" : 363390117224124416,
    "created_at" : "2013-08-02 20:05:30 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 363403151790977024,
  "created_at" : "2013-08-02 20:57:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Miller",
      "screen_name" : "bensie",
      "indices" : [ 0, 7 ],
      "id_str" : "15394959",
      "id" : 15394959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363385270529302528",
  "geo" : { },
  "id_str" : "363389628956426241",
  "in_reply_to_user_id" : 15394959,
  "text" : "@bensie sounds like its not working right then. also i'd look into intrinsicContentSize.",
  "id" : 363389628956426241,
  "in_reply_to_status_id" : 363385270529302528,
  "created_at" : "2013-08-02 20:03:33 +0000",
  "in_reply_to_screen_name" : "bensie",
  "in_reply_to_user_id_str" : "15394959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363315239850229762",
  "geo" : { },
  "id_str" : "363315568687849472",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan new apartment closer to @coworkbuffalo i hope...",
  "id" : 363315568687849472,
  "in_reply_to_status_id" : 363315239850229762,
  "created_at" : "2013-08-02 15:09:16 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Miller",
      "screen_name" : "incanus77",
      "indices" : [ 3, 13 ],
      "id_str" : "4765141",
      "id" : 4765141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/s1mn\/status\/363310182568165376\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/asjK35ctsx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq8r6eCAAAFsCf.png",
      "id_str" : "363310182572359680",
      "id" : 363310182572359680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq8r6eCAAAFsCf.png",
      "sizes" : [ {
        "h" : 229,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/asjK35ctsx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363311841776119808",
  "text" : "RT @incanus77: Ladies &amp; gentlemen, the App Store: http:\/\/t.co\/asjK35ctsx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/s1mn\/status\/363310182568165376\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/asjK35ctsx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq8r6eCAAAFsCf.png",
        "id_str" : "363310182572359680",
        "id" : 363310182572359680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq8r6eCAAAFsCf.png",
        "sizes" : [ {
          "h" : 229,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 130,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/asjK35ctsx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363311670682071040",
    "text" : "Ladies &amp; gentlemen, the App Store: http:\/\/t.co\/asjK35ctsx",
    "id" : 363311670682071040,
    "created_at" : "2013-08-02 14:53:46 +0000",
    "user" : {
      "name" : "Justin Miller",
      "screen_name" : "incanus77",
      "protected" : false,
      "id_str" : "4765141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1730880458\/6611288273_3f2969e2e4_o_normal.jpg",
      "id" : 4765141,
      "verified" : false
    }
  },
  "id" : 363311841776119808,
  "created_at" : "2013-08-02 14:54:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mr dr erin williams",
      "screen_name" : "williamsjoe",
      "indices" : [ 3, 15 ],
      "id_str" : "16316680",
      "id" : 16316680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/IUWHO6iQ2A",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/ad174409145b9ebc1c7c64403cdc7345\/tumblr_mpe9l5Y1Ky1qdlh1io1_250.gif",
      "display_url" : "24.media.tumblr.com\/ad174409145b9e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363309208688529409",
  "text" : "RT @williamsjoe: Current Status: http:\/\/t.co\/IUWHO6iQ2A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/IUWHO6iQ2A",
        "expanded_url" : "http:\/\/24.media.tumblr.com\/ad174409145b9ebc1c7c64403cdc7345\/tumblr_mpe9l5Y1Ky1qdlh1io1_250.gif",
        "display_url" : "24.media.tumblr.com\/ad174409145b9e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363308934762725378",
    "text" : "Current Status: http:\/\/t.co\/IUWHO6iQ2A",
    "id" : 363308934762725378,
    "created_at" : "2013-08-02 14:42:54 +0000",
    "user" : {
      "name" : "mr dr erin williams",
      "screen_name" : "williamsjoe",
      "protected" : false,
      "id_str" : "16316680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000258100430\/feda6c14c9a9938feb64c4eb79c39249_normal.jpeg",
      "id" : 16316680,
      "verified" : false
    }
  },
  "id" : 363309208688529409,
  "created_at" : "2013-08-02 14:43:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363277605174124544",
  "geo" : { },
  "id_str" : "363278186269782016",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek el oh el",
  "id" : 363278186269782016,
  "in_reply_to_status_id" : 363277605174124544,
  "created_at" : "2013-08-02 12:40:43 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shmorky",
      "screen_name" : "sashmorky",
      "indices" : [ 3, 13 ],
      "id_str" : "212760779",
      "id" : 212760779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/zGXiDTotLd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vtX-kDqHHqs",
      "display_url" : "youtube.com\/watch?v=vtX-kD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363147397850857472",
  "text" : "RT @sashmorky: Let's play SUPER MARIO 64!!! MAZAMBLE!!! http:\/\/t.co\/zGXiDTotLd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/zGXiDTotLd",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vtX-kDqHHqs",
        "display_url" : "youtube.com\/watch?v=vtX-kD\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363141879077928960",
    "text" : "Let's play SUPER MARIO 64!!! MAZAMBLE!!! http:\/\/t.co\/zGXiDTotLd",
    "id" : 363141879077928960,
    "created_at" : "2013-08-02 03:39:05 +0000",
    "user" : {
      "name" : "Shmorky",
      "screen_name" : "sashmorky",
      "protected" : false,
      "id_str" : "212760779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565370347776536576\/Kv6MjFoR_normal.png",
      "id" : 212760779,
      "verified" : false
    }
  },
  "id" : 363147397850857472,
  "created_at" : "2013-08-02 04:01:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363121719638503424",
  "geo" : { },
  "id_str" : "363123920012324864",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant planning to go back on it. I miss it. I hate getting hungry.",
  "id" : 363123920012324864,
  "in_reply_to_status_id" : 363121719638503424,
  "created_at" : "2013-08-02 02:27:43 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363089352127033345",
  "text" : "And off the plane. Whoever has good luck with flying, cherish it.",
  "id" : 363089352127033345,
  "created_at" : "2013-08-02 00:10:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363087527982272512",
  "geo" : { },
  "id_str" : "363087631665479680",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety doubtful",
  "id" : 363087631665479680,
  "in_reply_to_status_id" : 363087527982272512,
  "created_at" : "2013-08-02 00:03:31 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363087111102017537",
  "geo" : { },
  "id_str" : "363087233097531392",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety yes. Deboarding now.",
  "id" : 363087233097531392,
  "in_reply_to_status_id" : 363087111102017537,
  "created_at" : "2013-08-02 00:01:56 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363084598789410816",
  "text" : "My terrible luck with flying continues: cargo box being loaded scratched the hull of the plane and now waiting at least 30 mins to check it.",
  "id" : 363084598789410816,
  "created_at" : "2013-08-01 23:51:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 95, 105 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363075708773339136",
  "text" : "RT @jonasdowney: Really enjoyed spending a week with the curated selection of sweet weirdos at @37signals.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 78, 88 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363057508304158721",
    "text" : "Really enjoyed spending a week with the curated selection of sweet weirdos at @37signals.",
    "id" : 363057508304158721,
    "created_at" : "2013-08-01 22:03:49 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 363075708773339136,
  "created_at" : "2013-08-01 23:16:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rapid LED",
      "screen_name" : "rapidled",
      "indices" : [ 38, 47 ],
      "id_str" : "141855887",
      "id" : 141855887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/GQsl5iG9ei",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3592-bootstrapped-profitable-proud-rapid-led",
      "display_url" : "37signals.com\/svn\/posts\/3592\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362974462724931584",
  "text" : "RT @wilderemily: The latest BP&amp;P: @rapidled. I'm loving working on this series! Check out the story here: http:\/\/t.co\/GQsl5iG9ei",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rapid LED",
        "screen_name" : "rapidled",
        "indices" : [ 21, 30 ],
        "id_str" : "141855887",
        "id" : 141855887
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/GQsl5iG9ei",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3592-bootstrapped-profitable-proud-rapid-led",
        "display_url" : "37signals.com\/svn\/posts\/3592\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362974194021040129",
    "text" : "The latest BP&amp;P: @rapidled. I'm loving working on this series! Check out the story here: http:\/\/t.co\/GQsl5iG9ei",
    "id" : 362974194021040129,
    "created_at" : "2013-08-01 16:32:46 +0000",
    "user" : {
      "name" : "Emily Triplett Lentz",
      "screen_name" : "emilytlentz",
      "protected" : false,
      "id_str" : "55330075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442792521177894913\/2s9xRuFD_normal.jpeg",
      "id" : 55330075,
      "verified" : false
    }
  },
  "id" : 362974462724931584,
  "created_at" : "2013-08-01 16:33:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/tYSBZLRA6y",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjHdxTuZ",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjHd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362973569073950721",
  "text" : "View my 5 latest photos on Flickr: http:\/\/t.co\/tYSBZLRA6y",
  "id" : 362973569073950721,
  "created_at" : "2013-08-01 16:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362947954635583490",
  "geo" : { },
  "id_str" : "362949876667002882",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh yep, @nickelcityruby has a GIL",
  "id" : 362949876667002882,
  "in_reply_to_status_id" : 362947954635583490,
  "created_at" : "2013-08-01 14:56:08 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/yaSV1S8FHY",
      "expanded_url" : "http:\/\/imgur.com\/a\/Lj9Cy",
      "display_url" : "imgur.com\/a\/Lj9Cy"
    } ]
  },
  "geo" : { },
  "id_str" : "362943908348575746",
  "text" : "\"Every incredible human achievement in history was done with slaves\" http:\/\/t.co\/yaSV1S8FHY",
  "id" : 362943908348575746,
  "created_at" : "2013-08-01 14:32:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TTdRtboMCt",
      "expanded_url" : "https:\/\/basecamp.com\/uptime",
      "display_url" : "basecamp.com\/uptime"
    } ]
  },
  "geo" : { },
  "id_str" : "362936575165874177",
  "text" : "RT @dhh: On the note of bragging about uptime, Basecamp has 100% over the last ~two months. 99.994% since launch: https:\/\/t.co\/TTdRtboMCt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/TTdRtboMCt",
        "expanded_url" : "https:\/\/basecamp.com\/uptime",
        "display_url" : "basecamp.com\/uptime"
      } ]
    },
    "geo" : { },
    "id_str" : "362935750435672065",
    "text" : "On the note of bragging about uptime, Basecamp has 100% over the last ~two months. 99.994% since launch: https:\/\/t.co\/TTdRtboMCt",
    "id" : 362935750435672065,
    "created_at" : "2013-08-01 14:00:00 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 362936575165874177,
  "created_at" : "2013-08-01 14:03:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
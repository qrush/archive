Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cantino",
      "screen_name" : "tectonic",
      "indices" : [ 0, 9 ],
      "id_str" : "9813372",
      "id" : 9813372
    }, {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 10, 23 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297205827603951617",
  "geo" : { },
  "id_str" : "297207139578023936",
  "in_reply_to_user_id" : 9813372,
  "text" : "@tectonic @gilesgoatboy this should be more than CSRF - PGP, private keys, what to do if a box is compromised, etc",
  "id" : 297207139578023936,
  "in_reply_to_status_id" : 297205827603951617,
  "created_at" : "2013-02-01 04:57:58 +0000",
  "in_reply_to_screen_name" : "tectonic",
  "in_reply_to_user_id_str" : "9813372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noel Rappin",
      "screen_name" : "noelrap",
      "indices" : [ 0, 8 ],
      "id_str" : "1515231",
      "id" : 1515231
    }, {
      "name" : "Aaron Bedra",
      "screen_name" : "abedra",
      "indices" : [ 9, 16 ],
      "id_str" : "8839052",
      "id" : 8839052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297199157976899587",
  "geo" : { },
  "id_str" : "297201987106258944",
  "in_reply_to_user_id" : 1515231,
  "text" : "@noelrap @abedra this is just an idea- I\u2019m leading enough things. Someone needs to step up",
  "id" : 297201987106258944,
  "in_reply_to_status_id" : 297199157976899587,
  "created_at" : "2013-02-01 04:37:30 +0000",
  "in_reply_to_screen_name" : "noelrap",
  "in_reply_to_user_id_str" : "1515231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297199535892090880",
  "geo" : { },
  "id_str" : "297201732402962433",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan (\uFF61-_-\uFF61)",
  "id" : 297201732402962433,
  "in_reply_to_status_id" : 297199535892090880,
  "created_at" : "2013-02-01 04:36:29 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Howard \u0B18(\u0A6D\u02CA\u1D55\u02CB)\u0A6D",
      "screen_name" : "damncabbage",
      "indices" : [ 0, 12 ],
      "id_str" : "17407102",
      "id" : 17407102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297198554538201088",
  "geo" : { },
  "id_str" : "297201488650985473",
  "in_reply_to_user_id" : 17407102,
  "text" : "@damncabbage just general stuff a ruby developer should know about security, incidents, etc",
  "id" : 297201488650985473,
  "in_reply_to_status_id" : 297198554538201088,
  "created_at" : "2013-02-01 04:35:31 +0000",
  "in_reply_to_screen_name" : "damncabbage",
  "in_reply_to_user_id_str" : "17407102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297198911288901632",
  "geo" : { },
  "id_str" : "297201361559367680",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 exactly",
  "id" : 297201361559367680,
  "in_reply_to_status_id" : 297198911288901632,
  "created_at" : "2013-02-01 04:35:00 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297198694401449984",
  "text" : "So, idea- someone needs to start a security guides site for Ruby in general. Basic to advanced stuff. More than the Rails guide. CC license.",
  "id" : 297198694401449984,
  "created_at" : "2013-02-01 04:24:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297198203600789504",
  "text" : "New guides could focus the ops\/sec people that want to improve the situation - can contribute real work instead of whine\/flail\/troll.",
  "id" : 297198203600789504,
  "created_at" : "2013-02-01 04:22:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/VkGM9FsF",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "297196957854740481",
  "text" : "Thinking it could work like http:\/\/t.co\/VkGM9FsF - short tutorials and more reading links. Everything from PGP on. (I am not an expert here)",
  "id" : 297196957854740481,
  "created_at" : "2013-02-01 04:17:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297196566035456000",
  "text" : "Would you read\/write\/contribute to a guides site for basic to advanced security\/stuff focused for Ruby folk? Short guides on what, how, why.",
  "id" : 297196566035456000,
  "created_at" : "2013-02-01 04:15:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297192358209003520",
  "geo" : { },
  "id_str" : "297193505204355072",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark you're spoiling them!",
  "id" : 297193505204355072,
  "in_reply_to_status_id" : 297192358209003520,
  "created_at" : "2013-02-01 04:03:47 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 8, 21 ],
      "id_str" : "23820237",
      "id" : 23820237
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 69, 80 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297182669098332160",
  "geo" : { },
  "id_str" : "297183062272380928",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @IanCAnderson Honestly, at this point, this is YAMLConf. Get @tenderlove to keynote.",
  "id" : 297183062272380928,
  "in_reply_to_status_id" : 297182669098332160,
  "created_at" : "2013-02-01 03:22:18 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "297181662020775937",
  "text" : "Very grateful for those with ops\/sysadmin experience (of which I have very little) that have helped with http:\/\/t.co\/bdjsRgTW - thank you.",
  "id" : 297181662020775937,
  "created_at" : "2013-02-01 03:16:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297168537775128576",
  "text" : "RT @rubygems_status: As of right now, 100% of gems available are tamper free. Usage of rubygems is now proved safe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297130703445979136",
    "text" : "As of right now, 100% of gems available are tamper free. Usage of rubygems is now proved safe.",
    "id" : 297130703445979136,
    "created_at" : "2013-01-31 23:54:14 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 297168537775128576,
  "created_at" : "2013-02-01 02:24:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "#techismaterial",
      "screen_name" : "steveklabnik",
      "indices" : [ 7, 20 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/3AvUSsWs",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=z_SQO3vv3p8",
      "display_url" : "youtube.com\/watch?v=z_SQO3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "297161941653286912",
  "geo" : { },
  "id_str" : "297162035404369920",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @steveklabnik Better link - http:\/\/t.co\/3AvUSsWs",
  "id" : 297162035404369920,
  "in_reply_to_status_id" : 297161941653286912,
  "created_at" : "2013-02-01 01:58:44 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Gl3eClD7",
      "expanded_url" : "http:\/\/weknowmemes.com\/wp-content\/uploads\/2012\/01\/skirllex-bee-gif.gif",
      "display_url" : "weknowmemes.com\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/DFjZ8St2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=q4thsH4Eyfw",
      "display_url" : "youtube.com\/watch?v=q4thsH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "297147759180533760",
  "geo" : { },
  "id_str" : "297161941653286912",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Just say yes! http:\/\/t.co\/Gl3eClD7 http:\/\/t.co\/DFjZ8St2",
  "id" : 297161941653286912,
  "in_reply_to_status_id" : 297147759180533760,
  "created_at" : "2013-02-01 01:58:22 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 10, 21 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297159752348233728",
  "geo" : { },
  "id_str" : "297160468160737282",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango @shellscape is his name Franzia?",
  "id" : 297160468160737282,
  "in_reply_to_status_id" : 297159752348233728,
  "created_at" : "2013-02-01 01:52:31 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 12, 21 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297154096660639745",
  "geo" : { },
  "id_str" : "297159177598545920",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape @reybango It's just bitter.",
  "id" : 297159177598545920,
  "in_reply_to_status_id" : 297154096660639745,
  "created_at" : "2013-02-01 01:47:23 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 0, 10 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297132647761735681",
  "geo" : { },
  "id_str" : "297138529945935872",
  "in_reply_to_user_id" : 784519,
  "text" : "@KirinDave :(",
  "id" : 297138529945935872,
  "in_reply_to_status_id" : 297132647761735681,
  "created_at" : "2013-02-01 00:25:20 +0000",
  "in_reply_to_screen_name" : "KirinDave",
  "in_reply_to_user_id_str" : "784519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rey Bango",
      "screen_name" : "reybango",
      "indices" : [ 0, 9 ],
      "id_str" : "1589691",
      "id" : 1589691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297126203561762817",
  "geo" : { },
  "id_str" : "297127191953686528",
  "in_reply_to_user_id" : 1589691,
  "text" : "@reybango go for it.",
  "id" : 297127191953686528,
  "in_reply_to_status_id" : 297126203561762817,
  "created_at" : "2013-01-31 23:40:17 +0000",
  "in_reply_to_screen_name" : "reybango",
  "in_reply_to_user_id_str" : "1589691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297103786919477248",
  "text" : "533 tests, 1337 assertions",
  "id" : 297103786919477248,
  "created_at" : "2013-01-31 22:07:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 23, 33 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297081615316824065",
  "geo" : { },
  "id_str" : "297081834775396352",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc NOOOOOOOOO \/cc @asianmack",
  "id" : 297081834775396352,
  "in_reply_to_status_id" : 297081615316824065,
  "created_at" : "2013-01-31 20:40:03 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/bAxUf5gx",
      "expanded_url" : "http:\/\/tinyurl.com\/anqa5s5",
      "display_url" : "tinyurl.com\/anqa5s5"
    } ]
  },
  "geo" : { },
  "id_str" : "297081551253016578",
  "text" : "RT @rubygems_status: Big thanks to Red Hat for providing security forensics of the comprised box. Details here - http:\/\/t.co\/bAxUf5gx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/bAxUf5gx",
        "expanded_url" : "http:\/\/tinyurl.com\/anqa5s5",
        "display_url" : "tinyurl.com\/anqa5s5"
      } ]
    },
    "geo" : { },
    "id_str" : "297081478746103808",
    "text" : "Big thanks to Red Hat for providing security forensics of the comprised box. Details here - http:\/\/t.co\/bAxUf5gx",
    "id" : 297081478746103808,
    "created_at" : "2013-01-31 20:38:38 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 297081551253016578,
  "created_at" : "2013-01-31 20:38:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 3, 9 ],
      "id_str" : "10255262",
      "id" : 10255262
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 24, 33 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297080274083266560",
  "text" : "RT @ReinH: If you think @rubygems doesn't know how to secure an infra and you do then you should offer to help them in addition to criti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 13, 22 ],
        "id_str" : "14881835",
        "id" : 14881835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297078953955434496",
    "text" : "If you think @rubygems doesn't know how to secure an infra and you do then you should offer to help them in addition to criticizing.",
    "id" : 297078953955434496,
    "created_at" : "2013-01-31 20:28:36 +0000",
    "user" : {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "protected" : false,
      "id_str" : "10255262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73343025\/s_ec3528dde7dd4363eb85ed30d9f0738e_normal.jpg",
      "id" : 10255262,
      "verified" : false
    }
  },
  "id" : 297080274083266560,
  "created_at" : "2013-01-31 20:33:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297077777901965314",
  "text" : "RT @bitsweat: Security researchers are often correct, and are often remarkably antisocial assholes. Calling this out is taboo. Walter So ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297075759141490688",
    "text" : "Security researchers are often correct, and are often remarkably antisocial assholes. Calling this out is taboo. Walter Sobchak effect.",
    "id" : 297075759141490688,
    "created_at" : "2013-01-31 20:15:55 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 297077777901965314,
  "created_at" : "2013-01-31 20:23:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297074189448384512",
  "text" : "OH \"[Amazon] should use AWS\"",
  "id" : 297074189448384512,
  "created_at" : "2013-01-31 20:09:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 3, 11 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297065324300345345",
  "text" : "RT @whit537: I just noticed that Twitter looks like a Twitter Bootstrap site.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297064776960471040",
    "text" : "I just noticed that Twitter looks like a Twitter Bootstrap site.",
    "id" : 297064776960471040,
    "created_at" : "2013-01-31 19:32:16 +0000",
    "user" : {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "protected" : false,
      "id_str" : "34175404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560974605255319554\/CbOeWpFu_normal.jpeg",
      "id" : 34175404,
      "verified" : false
    }
  },
  "id" : 297065324300345345,
  "created_at" : "2013-01-31 19:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297040614971817985",
  "geo" : { },
  "id_str" : "297041545532669954",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz haha basically.",
  "id" : 297041545532669954,
  "in_reply_to_status_id" : 297040614971817985,
  "created_at" : "2013-01-31 17:59:57 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297036400971350016",
  "geo" : { },
  "id_str" : "297039798093373441",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 on a more serious note, we need more people involved and thinking about security and IR - this can't be ignored.",
  "id" : 297039798093373441,
  "in_reply_to_status_id" : 297036400971350016,
  "created_at" : "2013-01-31 17:53:01 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297036400971350016",
  "geo" : { },
  "id_str" : "297039595244244993",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 cry",
  "id" : 297039595244244993,
  "in_reply_to_status_id" : 297036400971350016,
  "created_at" : "2013-01-31 17:52:12 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Dente",
      "screen_name" : "kevindente",
      "indices" : [ 0, 11 ],
      "id_str" : "778112",
      "id" : 778112
    }, {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 12, 24 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297036384756195330",
  "geo" : { },
  "id_str" : "297039048667709440",
  "in_reply_to_user_id" : 778112,
  "text" : "@kevindente @alanstevens i had a feeling this and Angular are kind of the complexity response to backbone. :(",
  "id" : 297039048667709440,
  "in_reply_to_status_id" : 297036384756195330,
  "created_at" : "2013-01-31 17:50:02 +0000",
  "in_reply_to_screen_name" : "kevindente",
  "in_reply_to_user_id_str" : "778112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297027950291869696",
  "text" : "This is why I shouldn't read the comments.",
  "id" : 297027950291869696,
  "created_at" : "2013-01-31 17:05:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297027915512696832",
  "text" : "\"Rails needs to die\" \"systemic engineering incompetence that apparently pervades an entire language community\" :(",
  "id" : 297027915512696832,
  "created_at" : "2013-01-31 17:05:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/4RMhJlsJ",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=5145397",
      "display_url" : "news.ycombinator.com\/item?id=5145397"
    } ]
  },
  "geo" : { },
  "id_str" : "297027749229518848",
  "text" : "All of http:\/\/t.co\/4RMhJlsJ is making me :(",
  "id" : 297027749229518848,
  "created_at" : "2013-01-31 17:05:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/297012505048399873\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/T4aMpoZy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB8zTLnCQAARuAF.jpg",
      "id_str" : "297012505056788480",
      "id" : 297012505056788480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB8zTLnCQAARuAF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T4aMpoZy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297012505048399873",
  "text" : "Does your dog give you high fives when sleeping? Mine does. http:\/\/t.co\/T4aMpoZy",
  "id" : 297012505048399873,
  "created_at" : "2013-01-31 16:04:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 3, 11 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/I8X4KEnM",
      "expanded_url" : "http:\/\/bit.ly\/U2t0aF",
      "display_url" : "bit.ly\/U2t0aF"
    } ]
  },
  "geo" : { },
  "id_str" : "297010377466712064",
  "text" : "RT @patio11: What the Ruby on Rails security issue means for your startup (including for those who don't use Rails): http:\/\/t.co\/I8X4KEnM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/I8X4KEnM",
        "expanded_url" : "http:\/\/bit.ly\/U2t0aF",
        "display_url" : "bit.ly\/U2t0aF"
      } ]
    },
    "geo" : { },
    "id_str" : "297001142775341056",
    "text" : "What the Ruby on Rails security issue means for your startup (including for those who don't use Rails): http:\/\/t.co\/I8X4KEnM",
    "id" : 297001142775341056,
    "created_at" : "2013-01-31 15:19:25 +0000",
    "user" : {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "protected" : false,
      "id_str" : "20844341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476049306072276993\/s9QMnPC5_normal.jpeg",
      "id" : 20844341,
      "verified" : false
    }
  },
  "id" : 297010377466712064,
  "created_at" : "2013-01-31 15:56:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Chadwick",
      "screen_name" : "vertis",
      "indices" : [ 0, 7 ],
      "id_str" : "18786379",
      "id" : 18786379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296969939032604672",
  "geo" : { },
  "id_str" : "296990117841756161",
  "in_reply_to_user_id" : 18786379,
  "text" : "@vertis Thanks man.",
  "id" : 296990117841756161,
  "in_reply_to_status_id" : 296969939032604672,
  "created_at" : "2013-01-31 14:35:36 +0000",
  "in_reply_to_screen_name" : "vertis",
  "in_reply_to_user_id_str" : "18786379",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/e3W7qczu",
      "expanded_url" : "http:\/\/gembundler.com\/git.html",
      "display_url" : "gembundler.com\/git.html"
    } ]
  },
  "geo" : { },
  "id_str" : "296988623012786176",
  "text" : "RT @rubygems_status: Can\u2019t push? Best workaround until our API is restored is to use http:\/\/t.co\/e3W7qczu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/e3W7qczu",
        "expanded_url" : "http:\/\/gembundler.com\/git.html",
        "display_url" : "gembundler.com\/git.html"
      } ]
    },
    "geo" : { },
    "id_str" : "296988577731072004",
    "text" : "Can\u2019t push? Best workaround until our API is restored is to use http:\/\/t.co\/e3W7qczu",
    "id" : 296988577731072004,
    "created_at" : "2013-01-31 14:29:29 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296988623012786176,
  "created_at" : "2013-01-31 14:29:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hashrocket",
      "screen_name" : "hashrocket",
      "indices" : [ 0, 11 ],
      "id_str" : "12621452",
      "id" : 12621452
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 38, 47 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 81, 91 ],
      "id_str" : "18047782",
      "id" : 18047782
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 92, 98 ],
      "id_str" : "8000842",
      "id" : 8000842
    }, {
      "name" : "Shay Arnett",
      "screen_name" : "shayarnett",
      "indices" : [ 99, 110 ],
      "id_str" : "14009722",
      "id" : 14009722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "296985118214602752",
  "geo" : { },
  "id_str" : "296985556238348288",
  "in_reply_to_user_id" : 12621452,
  "text" : "@hashrocket This should fly under the @OpenHack banner! http:\/\/t.co\/Dih7bxvF \/cc @p_elliott @tpope @shayarnett",
  "id" : 296985556238348288,
  "in_reply_to_status_id" : 296985118214602752,
  "created_at" : "2013-01-31 14:17:28 +0000",
  "in_reply_to_screen_name" : "hashrocket",
  "in_reply_to_user_id_str" : "12621452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296981089304600576",
  "geo" : { },
  "id_str" : "296981605552095232",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking thanks man.",
  "id" : 296981605552095232,
  "in_reply_to_status_id" : 296981089304600576,
  "created_at" : "2013-01-31 14:01:47 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 49, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296981103842058241",
  "geo" : { },
  "id_str" : "296981581812359168",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky Be honest, you wanted to fit in a #yolo",
  "id" : 296981581812359168,
  "in_reply_to_status_id" : 296981103842058241,
  "created_at" : "2013-01-31 14:01:41 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 13, 26 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296975482019258368",
  "geo" : { },
  "id_str" : "296975918197518337",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer @markimbriaco I don't think people or companies in the Ruby community understand that it is a community-run, volunteer effort",
  "id" : 296975918197518337,
  "in_reply_to_status_id" : 296975482019258368,
  "created_at" : "2013-01-31 13:39:11 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Benson",
      "screen_name" : "natebenson",
      "indices" : [ 0, 11 ],
      "id_str" : "25678101",
      "id" : 25678101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296975041126625280",
  "geo" : { },
  "id_str" : "296975565561413633",
  "in_reply_to_user_id" : 25678101,
  "text" : "@natebenson Definitely recognize Summit Park Mall on a few of these",
  "id" : 296975565561413633,
  "in_reply_to_status_id" : 296975041126625280,
  "created_at" : "2013-01-31 13:37:47 +0000",
  "in_reply_to_screen_name" : "natebenson",
  "in_reply_to_user_id_str" : "25678101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296962488493285376",
  "geo" : { },
  "id_str" : "296964125932802049",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic lack of sleep does things",
  "id" : 296964125932802049,
  "in_reply_to_status_id" : 296962488493285376,
  "created_at" : "2013-01-31 12:52:19 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296939669751463936",
  "text" : "Got woken up by a panting dog during a terrible wind storm, but things are seeming a little more brighter today.",
  "id" : 296939669751463936,
  "created_at" : "2013-01-31 11:15:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/kYHlSZUZ",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296939424447610880",
  "text" : "RT @samkottler: We basically just rebuilt the http:\/\/t.co\/kYHlSZUZ infrastructure in a night - should be ready to relaunch tomorrow at s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/kYHlSZUZ",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "296879905596137472",
    "text" : "We basically just rebuilt the http:\/\/t.co\/kYHlSZUZ infrastructure in a night - should be ready to relaunch tomorrow at some point",
    "id" : 296879905596137472,
    "created_at" : "2013-01-31 07:17:39 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 296939424447610880,
  "created_at" : "2013-01-31 11:14:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "indices" : [ 3, 16 ],
      "id_str" : "90286855",
      "id" : 90286855
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 31, 40 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/VyfIYfyl",
      "expanded_url" : "http:\/\/bit.ly\/11iNf1r",
      "display_url" : "bit.ly\/11iNf1r"
    } ]
  },
  "geo" : { },
  "id_str" : "296939254213402624",
  "text" : "RT @TheChangelog: It's time to @OpenHack your city! Fork it. Add your city. OpenHack. http:\/\/t.co\/VyfIYfyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 13, 22 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/VyfIYfyl",
        "expanded_url" : "http:\/\/bit.ly\/11iNf1r",
        "display_url" : "bit.ly\/11iNf1r"
      } ]
    },
    "geo" : { },
    "id_str" : "296831087177502720",
    "text" : "It's time to @OpenHack your city! Fork it. Add your city. OpenHack. http:\/\/t.co\/VyfIYfyl",
    "id" : 296831087177502720,
    "created_at" : "2013-01-31 04:03:40 +0000",
    "user" : {
      "name" : "The Changelog",
      "screen_name" : "TheChangelog",
      "protected" : false,
      "id_str" : "90286855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420553878\/3ce7f958eb7d25c30ca97d2fc43cbf7d_normal.jpeg",
      "id" : 90286855,
      "verified" : false
    }
  },
  "id" : 296939254213402624,
  "created_at" : "2013-01-31 11:13:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Austin",
      "screen_name" : "openhackatx",
      "indices" : [ 3, 15 ],
      "id_str" : "1080641148",
      "id" : 1080641148
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/openhackatx\/status\/296796262584430592\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qTaX5DjC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB5uoNpCMAE0RGg.jpg",
      "id_str" : "296796262588624897",
      "id" : 296796262588624897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB5uoNpCMAE0RGg.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qTaX5DjC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296939224152809472",
  "text" : "RT @openhackatx: OpenHack - 33 hackers showed up! This is quite an auspicious start. Wide range of interests and skills. http:\/\/t.co\/qTa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/openhackatx\/status\/296796262584430592\/photo\/1",
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/qTaX5DjC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BB5uoNpCMAE0RGg.jpg",
        "id_str" : "296796262588624897",
        "id" : 296796262588624897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB5uoNpCMAE0RGg.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qTaX5DjC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296796262584430592",
    "text" : "OpenHack - 33 hackers showed up! This is quite an auspicious start. Wide range of interests and skills. http:\/\/t.co\/qTaX5DjC",
    "id" : 296796262584430592,
    "created_at" : "2013-01-31 01:45:18 +0000",
    "user" : {
      "name" : "OpenHack Austin",
      "screen_name" : "openhackatx",
      "protected" : false,
      "id_str" : "1080641148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3095663108\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 1080641148,
      "verified" : false
    }
  },
  "id" : 296939224152809472,
  "created_at" : "2013-01-31 11:13:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Oakes",
      "screen_name" : "benjaminoakes",
      "indices" : [ 0, 14 ],
      "id_str" : "75192522",
      "id" : 75192522
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 15, 31 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 38, 46 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296825489866256384",
  "geo" : { },
  "id_str" : "296855910301708288",
  "in_reply_to_user_id" : 75192522,
  "text" : "@benjaminoakes @rubygems_status oops. @evanphx if you have another second?",
  "id" : 296855910301708288,
  "in_reply_to_status_id" : 296825489866256384,
  "created_at" : "2013-01-31 05:42:18 +0000",
  "in_reply_to_screen_name" : "benjaminoakes",
  "in_reply_to_user_id_str" : "75192522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296853790638870529",
  "geo" : { },
  "id_str" : "296854591469932545",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick Bringing this up in #rubygems for you.",
  "id" : 296854591469932545,
  "in_reply_to_status_id" : 296853790638870529,
  "created_at" : "2013-01-31 05:37:04 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296848556462059520",
  "geo" : { },
  "id_str" : "296853892963123200",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel I'm no stranger to following you and your frustration :) The security\/signing discussion is super offtopic tonight.",
  "id" : 296853892963123200,
  "in_reply_to_status_id" : 296848556462059520,
  "created_at" : "2013-01-31 05:34:18 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian C. Anderson",
      "screen_name" : "IanCAnderson",
      "indices" : [ 0, 13 ],
      "id_str" : "23820237",
      "id" : 23820237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296840475707596803",
  "geo" : { },
  "id_str" : "296843842462838784",
  "in_reply_to_user_id" : 23820237,
  "text" : "@IanCAnderson thanks man.",
  "id" : 296843842462838784,
  "in_reply_to_status_id" : 296840475707596803,
  "created_at" : "2013-01-31 04:54:21 +0000",
  "in_reply_to_screen_name" : "IanCAnderson",
  "in_reply_to_user_id_str" : "23820237",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/aXp333Ey",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yo3uxqwTxk0",
      "display_url" : "youtube.com\/watch?v=yo3uxq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296838779757527041",
  "text" : "How do we go about fixing the problem? http:\/\/t.co\/aXp333Ey",
  "id" : 296838779757527041,
  "created_at" : "2013-01-31 04:34:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    }, {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 13, 22 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296833764447899649",
  "geo" : { },
  "id_str" : "296836758014935040",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded @ralphbod nyoooo! definitely could get something published even with the existing content and background. so good.",
  "id" : 296836758014935040,
  "in_reply_to_status_id" : 296833764447899649,
  "created_at" : "2013-01-31 04:26:12 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 7, 14 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296833997793812480",
  "geo" : { },
  "id_str" : "296836303629197313",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz @Croaky PORMO",
  "id" : 296836303629197313,
  "in_reply_to_status_id" : 296833997793812480,
  "created_at" : "2013-01-31 04:24:24 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    }, {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 75, 87 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296826457659957248",
  "geo" : { },
  "id_str" : "296832548208779265",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod oh it's so good. I was going to tweet about it this morning too. @starguarded should turn this into a book.",
  "id" : 296832548208779265,
  "in_reply_to_status_id" : 296826457659957248,
  "created_at" : "2013-01-31 04:09:29 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296832139524202497",
  "text" : "You need to have an extremely cool head to do ops\/IR. Utmost respect...I lack the \"extreme\" and \"cool\" parts of the head.",
  "id" : 296832139524202497,
  "created_at" : "2013-01-31 04:07:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Landers",
      "screen_name" : "bradleyland",
      "indices" : [ 10, 22 ],
      "id_str" : "18256709",
      "id" : 18256709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/iUY2lebz",
      "expanded_url" : "http:\/\/tinyurl.com\/anqa5s5",
      "display_url" : "tinyurl.com\/anqa5s5"
    } ]
  },
  "geo" : { },
  "id_str" : "296832029792804864",
  "text" : "Thanks to @bradleyland for starting http:\/\/t.co\/iUY2lebz - keeping my sanity in my first big ops issue.",
  "id" : 296832029792804864,
  "created_at" : "2013-01-31 04:07:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/iUY2lebz",
      "expanded_url" : "http:\/\/tinyurl.com\/anqa5s5",
      "display_url" : "tinyurl.com\/anqa5s5"
    }, {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296801405346402304",
  "text" : "I'm going to keep updating http:\/\/t.co\/iUY2lebz with what's going on in http:\/\/t.co\/t7WATcFT land tonight. Stay tuned.",
  "id" : 296801405346402304,
  "created_at" : "2013-01-31 02:05:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/iUY2lebz",
      "expanded_url" : "http:\/\/tinyurl.com\/anqa5s5",
      "display_url" : "tinyurl.com\/anqa5s5"
    } ]
  },
  "geo" : { },
  "id_str" : "296798702532689921",
  "text" : "Latest info about the http:\/\/t.co\/t7WATcFT outage is here - http:\/\/t.co\/iUY2lebz Our status site is having trouble too.",
  "id" : 296798702532689921,
  "created_at" : "2013-01-31 01:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 3, 15 ],
      "id_str" : "15399388",
      "id" : 15399388
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 70, 79 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "OpenHack Austin",
      "screen_name" : "openhackatx",
      "indices" : [ 83, 95 ],
      "id_str" : "1080641148",
      "id" : 1080641148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296795717580759042",
  "text" : "RT @happymrdave: Wow, we have like 30+ people at the inaugural Austin @openhack! \/ @openhackatx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 53, 62 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "OpenHack Austin",
        "screen_name" : "openhackatx",
        "indices" : [ 66, 78 ],
        "id_str" : "1080641148",
        "id" : 1080641148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296795436587552768",
    "text" : "Wow, we have like 30+ people at the inaugural Austin @openhack! \/ @openhackatx",
    "id" : 296795436587552768,
    "created_at" : "2013-01-31 01:42:00 +0000",
    "user" : {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "protected" : false,
      "id_str" : "15399388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1263308947\/Screen_shot_2011-03-05_at_8.01.18_PM_normal.png",
      "id" : 15399388,
      "verified" : false
    }
  },
  "id" : 296795717580759042,
  "created_at" : "2013-01-31 01:43:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polychronopolous",
      "screen_name" : "claco",
      "indices" : [ 0, 6 ],
      "id_str" : "14816130",
      "id" : 14816130
    }, {
      "name" : "Adrian Pike",
      "screen_name" : "adrianpike",
      "indices" : [ 7, 18 ],
      "id_str" : "12453752",
      "id" : 12453752
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 19, 35 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296785324791709696",
  "geo" : { },
  "id_str" : "296785617818353665",
  "in_reply_to_user_id" : 14816130,
  "text" : "@claco @adrianpike @rubygems_status we're getting off our current manually setup infrastructure.",
  "id" : 296785617818353665,
  "in_reply_to_status_id" : 296785324791709696,
  "created_at" : "2013-01-31 01:02:59 +0000",
  "in_reply_to_screen_name" : "claco",
  "in_reply_to_user_id_str" : "14816130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher G",
      "screen_name" : "galtenberg",
      "indices" : [ 0, 11 ],
      "id_str" : "17296646",
      "id" : 17296646
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296784279701180417",
  "geo" : { },
  "id_str" : "296784637089443840",
  "in_reply_to_user_id" : 17296646,
  "text" : "@galtenberg Yes! Please! Can you hop in #rubygems-verification on freenode?",
  "id" : 296784637089443840,
  "in_reply_to_status_id" : 296784279701180417,
  "created_at" : "2013-01-31 00:59:06 +0000",
  "in_reply_to_screen_name" : "galtenberg",
  "in_reply_to_user_id_str" : "17296646",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/qQdFYANV",
      "expanded_url" : "http:\/\/irc.freenode.net",
      "display_url" : "irc.freenode.net"
    } ]
  },
  "geo" : { },
  "id_str" : "296784472714670081",
  "text" : "We're fixing stuff in #rubygems on http:\/\/t.co\/qQdFYANV and several smaller channels. Where are you?",
  "id" : 296784472714670081,
  "created_at" : "2013-01-31 00:58:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296782200748273664",
  "geo" : { },
  "id_str" : "296782864173920256",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr because the old infrastructure is a manually setup jankfest. Time to actually use chef\/puppet and do it right.",
  "id" : 296782864173920256,
  "in_reply_to_status_id" : 296782200748273664,
  "created_at" : "2013-01-31 00:52:03 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296782685194567680",
  "text" : "RT @rubygems_status: We\u2019re going to do things right, but it might mean the API is down for a few hours to a day or more. Stay tuned for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296782055633731584",
    "text" : "We\u2019re going to do things right, but it might mean the API is down for a few hours to a day or more. Stay tuned for more updates.",
    "id" : 296782055633731584,
    "created_at" : "2013-01-31 00:48:50 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296782685194567680,
  "created_at" : "2013-01-31 00:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296782679217668098",
  "text" : "RT @rubygems_status: Our plan is: Repoint off Rackspace, setup new infrastructure on AWS, point to AWS once set up, properly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296781815048437761",
    "text" : "Our plan is: Repoint off Rackspace, setup new infrastructure on AWS, point to AWS once set up, properly.",
    "id" : 296781815048437761,
    "created_at" : "2013-01-31 00:47:53 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296782679217668098,
  "created_at" : "2013-01-31 00:51:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296775913209749506",
  "text" : "RT @rubygems_status: We are back in maintenance mode - going to spin down our backend box soon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296775754648268800",
    "text" : "We are back in maintenance mode - going to spin down our backend box soon.",
    "id" : 296775754648268800,
    "created_at" : "2013-01-31 00:23:48 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296775913209749506,
  "created_at" : "2013-01-31 00:24:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296773513187033088",
  "geo" : { },
  "id_str" : "296774651240132609",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH I responded to you privately on IRC. Basically, :(",
  "id" : 296774651240132609,
  "in_reply_to_status_id" : 296773513187033088,
  "created_at" : "2013-01-31 00:19:25 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 13, 22 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296772707700310016",
  "geo" : { },
  "id_str" : "296772903586897920",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick @fowlduck We don't have proof that the s3 creds were taken, but we can't prove otherwise. reset the existing ones regardless :(",
  "id" : 296772903586897920,
  "in_reply_to_status_id" : 296772707700310016,
  "created_at" : "2013-01-31 00:12:28 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296768783752765440",
  "geo" : { },
  "id_str" : "296769278525444098",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH annnnd no code :(",
  "id" : 296769278525444098,
  "in_reply_to_status_id" : 296768783752765440,
  "created_at" : "2013-01-30 23:58:04 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jade Rubick",
      "screen_name" : "JadeRubick",
      "indices" : [ 0, 11 ],
      "id_str" : "202857808",
      "id" : 202857808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296762893393858560",
  "geo" : { },
  "id_str" : "296765713400594432",
  "in_reply_to_user_id" : 202857808,
  "text" : "@JadeRubick \"labor\" is most of the problem, imo. lots of consumers, very little producers",
  "id" : 296765713400594432,
  "in_reply_to_status_id" : 296762893393858560,
  "created_at" : "2013-01-30 23:43:54 +0000",
  "in_reply_to_screen_name" : "JadeRubick",
  "in_reply_to_user_id_str" : "202857808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296765156908752897",
  "geo" : { },
  "id_str" : "296765347867009024",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel #rubygems irc, rubygems-discuss mailing list, stay active, be patient, be persistent.",
  "id" : 296765347867009024,
  "in_reply_to_status_id" : 296765156908752897,
  "created_at" : "2013-01-30 23:42:27 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296758937661865984",
  "text" : "Unhappy with RubyGems? Get involved. I was unhappy and fixed things. You can too.",
  "id" : 296758937661865984,
  "created_at" : "2013-01-30 23:16:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296757258770083840",
  "geo" : { },
  "id_str" : "296758045680222209",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler Yes! No one should think this is acceptable. The problem is RubyGems has been like this for years. I got involved despite that",
  "id" : 296758045680222209,
  "in_reply_to_status_id" : 296757258770083840,
  "created_at" : "2013-01-30 23:13:26 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296753402166259712",
  "geo" : { },
  "id_str" : "296755710207873024",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler :( I have a pretty weak understanding.",
  "id" : 296755710207873024,
  "in_reply_to_status_id" : 296753402166259712,
  "created_at" : "2013-01-30 23:04:09 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296746333098881024",
  "text" : "RT @rubygems_status: Ongoing analysis of checking the integrity of gems against known good sets now. Currently no changed gems have been ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296745313274822657",
    "text" : "Ongoing analysis of checking the integrity of gems against known good sets now. Currently no changed gems have been found.",
    "id" : 296745313274822657,
    "created_at" : "2013-01-30 22:22:50 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296746333098881024,
  "created_at" : "2013-01-30 22:26:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Evans",
      "screen_name" : "hughevans",
      "indices" : [ 0, 10 ],
      "id_str" : "12751382",
      "id" : 12751382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296731593102487552",
  "geo" : { },
  "id_str" : "296736093452247040",
  "in_reply_to_user_id" : 12751382,
  "text" : "@hughevans This has nothing to do with the current problems.",
  "id" : 296736093452247040,
  "in_reply_to_status_id" : 296731593102487552,
  "created_at" : "2013-01-30 21:46:12 +0000",
  "in_reply_to_screen_name" : "hughevans",
  "in_reply_to_user_id_str" : "12751382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 0, 13 ],
      "id_str" : "18210643",
      "id" : 18210643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296731911898923010",
  "geo" : { },
  "id_str" : "296732303466573828",
  "in_reply_to_user_id" : 18210643,
  "text" : "@josephruscio I can share the metadata or the gems with you for those gems if you want to try - qrush on freenode.",
  "id" : 296732303466573828,
  "in_reply_to_status_id" : 296731911898923010,
  "created_at" : "2013-01-30 21:31:08 +0000",
  "in_reply_to_screen_name" : "josephruscio",
  "in_reply_to_user_id_str" : "18210643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 0, 13 ],
      "id_str" : "18210643",
      "id" : 18210643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296731911898923010",
  "geo" : { },
  "id_str" : "296732227855851520",
  "in_reply_to_user_id" : 18210643,
  "text" : "@josephruscio i'm pretty sure that's only going to run code on our end, not on the end-user's. I haven't tried though.",
  "id" : 296732227855851520,
  "in_reply_to_status_id" : 296731911898923010,
  "created_at" : "2013-01-30 21:30:50 +0000",
  "in_reply_to_screen_name" : "josephruscio",
  "in_reply_to_user_id_str" : "18210643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joernchen",
      "screen_name" : "joernchen",
      "indices" : [ 0, 10 ],
      "id_str" : "19395266",
      "id" : 19395266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296725471595491329",
  "geo" : { },
  "id_str" : "296727473159303169",
  "in_reply_to_user_id" : 19395266,
  "text" : "@joernchen yes, i did.",
  "id" : 296727473159303169,
  "in_reply_to_status_id" : 296725471595491329,
  "created_at" : "2013-01-30 21:11:57 +0000",
  "in_reply_to_screen_name" : "joernchen",
  "in_reply_to_user_id_str" : "19395266",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 3, 10 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/IfyhPuIY",
      "expanded_url" : "http:\/\/ow.ly\/hh7et",
      "display_url" : "ow.ly\/hh7et"
    } ]
  },
  "geo" : { },
  "id_str" : "296727333694488577",
  "text" : "RT @heroku: Ruby deploys now enabled if your app requires no new gems http:\/\/t.co\/IfyhPuIY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/IfyhPuIY",
        "expanded_url" : "http:\/\/ow.ly\/hh7et",
        "display_url" : "ow.ly\/hh7et"
      } ]
    },
    "geo" : { },
    "id_str" : "296727257802735618",
    "text" : "Ruby deploys now enabled if your app requires no new gems http:\/\/t.co\/IfyhPuIY",
    "id" : 296727257802735618,
    "created_at" : "2013-01-30 21:11:05 +0000",
    "user" : {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "protected" : false,
      "id_str" : "10257182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464169564171821056\/43sHKeth_normal.png",
      "id" : 10257182,
      "verified" : false
    }
  },
  "id" : 296727333694488577,
  "created_at" : "2013-01-30 21:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    }, {
      "name" : "mr dr erin williams",
      "screen_name" : "williamsjoe",
      "indices" : [ 10, 22 ],
      "id_str" : "16316680",
      "id" : 16316680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296724638300532736",
  "geo" : { },
  "id_str" : "296727065691058177",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt @williamsjoe \"manage the operation\" is the problem. it's volunteer run. i barely have enough spare time to answer support issues.",
  "id" : 296727065691058177,
  "in_reply_to_status_id" : 296724638300532736,
  "created_at" : "2013-01-30 21:10:20 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 13, 24 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296726183817654272",
  "geo" : { },
  "id_str" : "296726384867414017",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide @trevorturk ENHANCE",
  "id" : 296726384867414017,
  "in_reply_to_status_id" : 296726183817654272,
  "created_at" : "2013-01-30 21:07:37 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dimitar Haralanov",
      "screen_name" : "dalizard",
      "indices" : [ 0, 9 ],
      "id_str" : "15977887",
      "id" : 15977887
    }, {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 10, 15 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296720963775635456",
  "geo" : { },
  "id_str" : "296721532196122624",
  "in_reply_to_user_id" : 15977887,
  "text" : "@daLizard @obie there's some furious checksum verification going on. chances that things have been fucked up seriously are low, hopefully",
  "id" : 296721532196122624,
  "in_reply_to_status_id" : 296720963775635456,
  "created_at" : "2013-01-30 20:48:20 +0000",
  "in_reply_to_screen_name" : "dalizard",
  "in_reply_to_user_id_str" : "15977887",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    }, {
      "name" : "mr dr erin williams",
      "screen_name" : "williamsjoe",
      "indices" : [ 10, 22 ],
      "id_str" : "16316680",
      "id" : 16316680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/FNVXjrbn",
      "expanded_url" : "http:\/\/update.gemcutter.org\/2009\/12\/08\/gemcutter-security-alert.html",
      "display_url" : "update.gemcutter.org\/2009\/12\/08\/gem\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "296716169359007745",
  "geo" : { },
  "id_str" : "296721246085849088",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt @williamsjoe This is the first security incident we've had since http:\/\/t.co\/FNVXjrbn. What can we do instead next time?",
  "id" : 296721246085849088,
  "in_reply_to_status_id" : 296716169359007745,
  "created_at" : "2013-01-30 20:47:12 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 3, 16 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296719192093241344",
  "text" : "RT @markimbriaco: Security theater right now, live on the internet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296719019040464896",
    "text" : "Security theater right now, live on the internet.",
    "id" : 296719019040464896,
    "created_at" : "2013-01-30 20:38:21 +0000",
    "user" : {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "protected" : false,
      "id_str" : "9887162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471493631283441664\/aiwoVRj7_normal.jpeg",
      "id" : 9887162,
      "verified" : false
    }
  },
  "id" : 296719192093241344,
  "created_at" : "2013-01-30 20:39:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerred",
      "screen_name" : "justicefries",
      "indices" : [ 0, 13 ],
      "id_str" : "188906158",
      "id" : 188906158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296713417375502338",
  "geo" : { },
  "id_str" : "296713854497460225",
  "in_reply_to_user_id" : 188906158,
  "text" : "@justicefries Hi, I'm jerkoff.",
  "id" : 296713854497460225,
  "in_reply_to_status_id" : 296713417375502338,
  "created_at" : "2013-01-30 20:17:50 +0000",
  "in_reply_to_screen_name" : "justicefries",
  "in_reply_to_user_id_str" : "188906158",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Bloomgarden",
      "screen_name" : "Aughr",
      "indices" : [ 0, 6 ],
      "id_str" : "2386451",
      "id" : 2386451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296707291233779712",
  "geo" : { },
  "id_str" : "296707957297655808",
  "in_reply_to_user_id" : 2386451,
  "text" : "@Aughr Yes, please do so. I couldn't find a way to do that on the site.",
  "id" : 296707957297655808,
  "in_reply_to_status_id" : 296707291233779712,
  "created_at" : "2013-01-30 19:54:24 +0000",
  "in_reply_to_screen_name" : "Aughr",
  "in_reply_to_user_id_str" : "2386451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Heffner",
      "screen_name" : "mheffner",
      "indices" : [ 0, 9 ],
      "id_str" : "11031062",
      "id" : 11031062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296706922122448898",
  "geo" : { },
  "id_str" : "296707236791738369",
  "in_reply_to_user_id" : 11031062,
  "text" : "@mheffner nope, i deleted it. I'm sure it's on some mirrors still. :\/",
  "id" : 296707236791738369,
  "in_reply_to_status_id" : 296706922122448898,
  "created_at" : "2013-01-30 19:51:32 +0000",
  "in_reply_to_screen_name" : "mheffner",
  "in_reply_to_user_id_str" : "11031062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296706472761491457",
  "text" : "RT @rubygems_status: Finished analysis of gems on S3 and found no other uses of the exploit. Currently working to checksum the most popu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296705350768406528",
    "text" : "Finished analysis of gems on S3 and found no other uses of the exploit. Currently working to checksum the most popular gems.",
    "id" : 296705350768406528,
    "created_at" : "2013-01-30 19:44:02 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296706472761491457,
  "created_at" : "2013-01-30 19:48:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ruscio",
      "screen_name" : "josephruscio",
      "indices" : [ 0, 13 ],
      "id_str" : "18210643",
      "id" : 18210643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296703255105384448",
  "geo" : { },
  "id_str" : "296706002798133248",
  "in_reply_to_user_id" : 18210643,
  "text" : "@josephruscio We don't have a config\/librato.yml set up on our production server, so it didn't copy anything.",
  "id" : 296706002798133248,
  "in_reply_to_status_id" : 296703255105384448,
  "created_at" : "2013-01-30 19:46:38 +0000",
  "in_reply_to_screen_name" : "josephruscio",
  "in_reply_to_user_id_str" : "18210643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Franck Verrot",
      "screen_name" : "franckverrot",
      "indices" : [ 17, 30 ],
      "id_str" : "48102727",
      "id" : 48102727
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 31, 39 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296701767440277504",
  "geo" : { },
  "id_str" : "296702283389992962",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 @franckverrot @evanphx there is a team of contributors and maintainers- but I don\u2019t deny that things could have been better",
  "id" : 296702283389992962,
  "in_reply_to_status_id" : 296701767440277504,
  "created_at" : "2013-01-30 19:31:51 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 0, 8 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296701548694761472",
  "geo" : { },
  "id_str" : "296702070130622464",
  "in_reply_to_user_id" : 34175404,
  "text" : "@whit537 woot!",
  "id" : 296702070130622464,
  "in_reply_to_status_id" : 296701548694761472,
  "created_at" : "2013-01-30 19:31:00 +0000",
  "in_reply_to_screen_name" : "whit537",
  "in_reply_to_user_id_str" : "34175404",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    }, {
      "name" : "benmmurphy",
      "screen_name" : "benmmurphy",
      "indices" : [ 8, 19 ],
      "id_str" : "17311483",
      "id" : 17311483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296631737541345280",
  "geo" : { },
  "id_str" : "296701436245442560",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr @benmmurphy yep, this has always been a threat\u2026 sadly I lack the bandwidth and knowledge to solve it.",
  "id" : 296701436245442560,
  "in_reply_to_status_id" : 296631737541345280,
  "created_at" : "2013-01-30 19:28:29 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Connor",
      "screen_name" : "ashconnor",
      "indices" : [ 0, 10 ],
      "id_str" : "96160973",
      "id" : 96160973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296659724353560576",
  "geo" : { },
  "id_str" : "296700887831826432",
  "in_reply_to_user_id" : 96160973,
  "text" : "@ashconnor none of this was Rails\u2019 fault - vuln was in YAML parsing libs.",
  "id" : 296700887831826432,
  "in_reply_to_status_id" : 296659724353560576,
  "created_at" : "2013-01-30 19:26:18 +0000",
  "in_reply_to_screen_name" : "ashconnor",
  "in_reply_to_user_id_str" : "96160973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Rogish",
      "screen_name" : "MattRogish",
      "indices" : [ 0, 11 ],
      "id_str" : "8866232",
      "id" : 8866232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296698852570976257",
  "geo" : { },
  "id_str" : "296700692301742080",
  "in_reply_to_user_id" : 8866232,
  "text" : "@MattRogish my outlook is positive right now. We are being cautious and checking everything anyway",
  "id" : 296700692301742080,
  "in_reply_to_status_id" : 296698852570976257,
  "created_at" : "2013-01-30 19:25:32 +0000",
  "in_reply_to_screen_name" : "MattRogish",
  "in_reply_to_user_id_str" : "8866232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296686218308104192",
  "geo" : { },
  "id_str" : "296699883572846592",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen I have access to both. Sorry that I haven\u2019t been RTing everything today :(",
  "id" : 296699883572846592,
  "in_reply_to_status_id" : 296686218308104192,
  "created_at" : "2013-01-30 19:22:19 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296698659763019776",
  "text" : "It\u2019s all hands on deck in #rubygems on Freenode. If you want to help, go there, and please be patient.",
  "id" : 296698659763019776,
  "created_at" : "2013-01-30 19:17:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296697465204256768",
  "text" : "I was just thinking last night that the http:\/\/t.co\/t7WATcFT twitter search was really boring and just robot tweets\u2026",
  "id" : 296697465204256768,
  "created_at" : "2013-01-30 19:12:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 3, 9 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296697203907510272",
  "text" : "RT @nzkoz: Handling security issues is hard, and piling on doesn\u2019t help anything. But asking questions tomorrow does.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296696699106238465",
    "text" : "Handling security issues is hard, and piling on doesn\u2019t help anything. But asking questions tomorrow does.",
    "id" : 296696699106238465,
    "created_at" : "2013-01-30 19:09:40 +0000",
    "user" : {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "protected" : false,
      "id_str" : "11294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000239013338\/8ef360106b3a7420ce56f3aa8a84506b_normal.jpeg",
      "id" : 11294,
      "verified" : false
    }
  },
  "id" : 296697203907510272,
  "created_at" : "2013-01-30 19:11:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 3, 10 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/iqSM4Hh0",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Kn6kvs69",
      "expanded_url" : "http:\/\/ow.ly\/hgQU8",
      "display_url" : "ow.ly\/hgQU8"
    } ]
  },
  "geo" : { },
  "id_str" : "296694939365027840",
  "text" : "RT @heroku: We are temporarily taking Ruby deploys offline for your protection due to a recent http:\/\/t.co\/iqSM4Hh0 vulnerability http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/iqSM4Hh0",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      }, {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/Kn6kvs69",
        "expanded_url" : "http:\/\/ow.ly\/hgQU8",
        "display_url" : "ow.ly\/hgQU8"
      } ]
    },
    "geo" : { },
    "id_str" : "296693401573797889",
    "text" : "We are temporarily taking Ruby deploys offline for your protection due to a recent http:\/\/t.co\/iqSM4Hh0 vulnerability http:\/\/t.co\/Kn6kvs69",
    "id" : 296693401573797889,
    "created_at" : "2013-01-30 18:56:33 +0000",
    "user" : {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "protected" : false,
      "id_str" : "10257182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464169564171821056\/43sHKeth_normal.png",
      "id" : 10257182,
      "verified" : false
    }
  },
  "id" : 296694939365027840,
  "created_at" : "2013-01-30 19:02:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "indices" : [ 0, 8 ],
      "id_str" : "15201409",
      "id" : 15201409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296686721561665538",
  "geo" : { },
  "id_str" : "296686851866120195",
  "in_reply_to_user_id" : 15201409,
  "text" : "@tcollen We haven't unindexed anything yet...but :(",
  "id" : 296686851866120195,
  "in_reply_to_status_id" : 296686721561665538,
  "created_at" : "2013-01-30 18:30:32 +0000",
  "in_reply_to_screen_name" : "tcollen",
  "in_reply_to_user_id_str" : "15201409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 53, 69 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296685694087221248",
  "text" : "TL;DR - Halt your deploys until give an all clear on @rubygems_status. We're double-checking all gems to ensure they have not been tampered.",
  "id" : 296685694087221248,
  "created_at" : "2013-01-30 18:25:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296684095289819136",
  "text" : "Basically, your deploys aren't going to work for a while until this is all fixed.",
  "id" : 296684095289819136,
  "created_at" : "2013-01-30 18:19:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296684012066451457",
  "text" : "We're going to start with the latest version of *all* gems, then all of top 100, then all of top 1000, and then everything else.",
  "id" : 296684012066451457,
  "created_at" : "2013-01-30 18:19:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296683910157447169",
  "text" : "Ok, here's the deal - we're going to do a verification of all gems since we don't know if they have been modified.",
  "id" : 296683910157447169,
  "created_at" : "2013-01-30 18:18:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296676239727529984",
  "text" : "However a different party pushed the 'exploit' gems and someone else then submitted to HN. Full-blown meltdown.",
  "id" : 296676239727529984,
  "created_at" : "2013-01-30 17:48:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296676138279899136",
  "text" : "I'd just like to say sorry - we did learn about this issue a few days ago, privately. We should have disabled gem pushes immediately.",
  "id" : 296676138279899136,
  "created_at" : "2013-01-30 17:47:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/4zaSHChz",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=5140109",
      "display_url" : "news.ycombinator.com\/item?id=5140109"
    } ]
  },
  "geo" : { },
  "id_str" : "296654367715627009",
  "text" : "Posted to HN about this http:\/\/t.co\/bdjsRgTW fiasco. Ugh. http:\/\/t.co\/4zaSHChz",
  "id" : 296654367715627009,
  "created_at" : "2013-01-30 16:21:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Willis Webber",
      "screen_name" : "Mephux",
      "indices" : [ 0, 7 ],
      "id_str" : "7810112",
      "id" : 7810112
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 31, 39 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296652732679479297",
  "geo" : { },
  "id_str" : "296654052987662337",
  "in_reply_to_user_id" : 7810112,
  "text" : "@Mephux bug evan on freenode \/ @evanphx. he's going to sniff the logs.",
  "id" : 296654052987662337,
  "in_reply_to_status_id" : 296652732679479297,
  "created_at" : "2013-01-30 16:20:12 +0000",
  "in_reply_to_screen_name" : "Mephux",
  "in_reply_to_user_id_str" : "7810112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296652278725738496",
  "text" : "RT @rubygems_status: We're currently auditing all the exploit vectors and logs. We've disabled push access until we finish work, but the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296647396199391234",
    "text" : "We're currently auditing all the exploit vectors and logs. We've disabled push access until we finish work, but the rest of the site is back",
    "id" : 296647396199391234,
    "created_at" : "2013-01-30 15:53:45 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 296652278725738496,
  "created_at" : "2013-01-30 16:13:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Willis Webber",
      "screen_name" : "Mephux",
      "indices" : [ 0, 7 ],
      "id_str" : "7810112",
      "id" : 7810112
    }, {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 8, 24 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296650551561691136",
  "geo" : { },
  "id_str" : "296652259998199808",
  "in_reply_to_user_id" : 7810112,
  "text" : "@Mephux @postmodern_mod3 Zero, to our knowledge currently. They didn't get the S3 keys.",
  "id" : 296652259998199808,
  "in_reply_to_status_id" : 296650551561691136,
  "created_at" : "2013-01-30 16:13:04 +0000",
  "in_reply_to_screen_name" : "Mephux",
  "in_reply_to_user_id_str" : "7810112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296649777851027457",
  "text" : "Current status: (\u30CE\u0CA0\u76CA\u0CA0)\u30CE\u5F61\u253B\u2501\u253B",
  "id" : 296649777851027457,
  "created_at" : "2013-01-30 16:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296648196522913792",
  "text" : "Well, it's 11am and I'm completely drained.",
  "id" : 296648196522913792,
  "created_at" : "2013-01-30 15:56:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 0, 7 ],
      "id_str" : "1566201",
      "id" : 1566201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296647595416240128",
  "geo" : { },
  "id_str" : "296647966440189952",
  "in_reply_to_user_id" : 1566201,
  "text" : "@zapnap in the process of",
  "id" : 296647966440189952,
  "in_reply_to_status_id" : 296647595416240128,
  "created_at" : "2013-01-30 15:56:01 +0000",
  "in_reply_to_screen_name" : "zapnap",
  "in_reply_to_user_id_str" : "1566201",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296647479397609472",
  "text" : "We're bringing http:\/\/t.co\/t7WATcFT back up, without the Push API. Real fix coming later today along with post-mortem.",
  "id" : 296647479397609472,
  "created_at" : "2013-01-30 15:54:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296638346283868160",
  "text" : "Someone posted http:\/\/t.co\/bdjsRgTW's config\/*.yml to pastie. Didn't include the S3 bucket secret key, but going to reset everything anyway.",
  "id" : 296638346283868160,
  "created_at" : "2013-01-30 15:17:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296634379319508994",
  "text" : "People on the internet are fucking assholes.",
  "id" : 296634379319508994,
  "created_at" : "2013-01-30 15:02:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296630024583393281",
  "text" : "Going to put http:\/\/t.co\/t7WATcFT into maintenance mode until we can push the fix out. Hold on folks.",
  "id" : 296630024583393281,
  "created_at" : "2013-01-30 14:44:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Henson",
      "screen_name" : "elaptics",
      "indices" : [ 0, 9 ],
      "id_str" : "11490402",
      "id" : 11490402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296628271469187072",
  "geo" : { },
  "id_str" : "296628683597295617",
  "in_reply_to_user_id" : 11490402,
  "text" : "@elaptics sigh.",
  "id" : 296628683597295617,
  "in_reply_to_status_id" : 296628271469187072,
  "created_at" : "2013-01-30 14:39:23 +0000",
  "in_reply_to_screen_name" : "elaptics",
  "in_reply_to_user_id_str" : "11490402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "indices" : [ 3, 16 ],
      "id_str" : "290180065",
      "id" : 290180065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/koS39omf",
      "expanded_url" : "http:\/\/bit.ly\/128Eb3P",
      "display_url" : "bit.ly\/128Eb3P"
    } ]
  },
  "geo" : { },
  "id_str" : "296628206172270593",
  "text" : "RT @EricHolthaus: Buffalo\/Niagara Falls area is most extremely warm spot in US right now: Daily high temp record broken by 12 degrees. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/koS39omf",
        "expanded_url" : "http:\/\/bit.ly\/128Eb3P",
        "display_url" : "bit.ly\/128Eb3P"
      } ]
    },
    "geo" : { },
    "id_str" : "296623335666749440",
    "text" : "Buffalo\/Niagara Falls area is most extremely warm spot in US right now: Daily high temp record broken by 12 degrees. http:\/\/t.co\/koS39omf",
    "id" : 296623335666749440,
    "created_at" : "2013-01-30 14:18:08 +0000",
    "user" : {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "protected" : false,
      "id_str" : "290180065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458779628161597440\/mWG3M6gy_normal.jpeg",
      "id" : 290180065,
      "verified" : true
    }
  },
  "id" : 296628206172270593,
  "created_at" : "2013-01-30 14:37:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 0, 16 ],
      "id_str" : "19539935",
      "id" : 19539935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296620687626489857",
  "geo" : { },
  "id_str" : "296623415492751361",
  "in_reply_to_user_id" : 19539935,
  "text" : "@laurenvoswinkel nice! Bring some other PGH folk!",
  "id" : 296623415492751361,
  "in_reply_to_status_id" : 296620687626489857,
  "created_at" : "2013-01-30 14:18:27 +0000",
  "in_reply_to_screen_name" : "laurenvoswinkel",
  "in_reply_to_user_id_str" : "19539935",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Lutley",
      "screen_name" : "elutley",
      "indices" : [ 0, 8 ],
      "id_str" : "141385784",
      "id" : 141385784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296616553951154178",
  "geo" : { },
  "id_str" : "296617950515961856",
  "in_reply_to_user_id" : 141385784,
  "text" : "@elutley gasp the horror of not going into an office! Whatever will the modern programmer do?!",
  "id" : 296617950515961856,
  "in_reply_to_status_id" : 296616553951154178,
  "created_at" : "2013-01-30 13:56:44 +0000",
  "in_reply_to_screen_name" : "elutley",
  "in_reply_to_user_id_str" : "141385784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296511362266439680",
  "text" : "Also, my home screen folder labels are now all kanji. (\u00B4\uFF65\u0414\uFF65)\u300D",
  "id" : 296511362266439680,
  "created_at" : "2013-01-30 06:53:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296511228497522689",
  "text" : "This is a kanji emoji on every iOS device on the planet: \uFF3F|\uFFE3|\u25CB",
  "id" : 296511228497522689,
  "created_at" : "2013-01-30 06:52:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296505927119536128",
  "geo" : { },
  "id_str" : "296506451936018433",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I can\u2019t update it since I don\u2019t have enough space :(",
  "id" : 296506451936018433,
  "in_reply_to_status_id" : 296505927119536128,
  "created_at" : "2013-01-30 06:33:41 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/296505312293314561\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/edfNvczZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB1mArYCYAIXJKC.png",
      "id_str" : "296505312305897474",
      "id" : 296505312305897474,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB1mArYCYAIXJKC.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/edfNvczZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296505312293314561",
  "text" : "Vine takes up a shitload of space and there is no way in app to delete it. Reinstalling. (\uFF1B\u00B4\u0414`A http:\/\/t.co\/edfNvczZ",
  "id" : 296505312293314561,
  "created_at" : "2013-01-30 06:29:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "indices" : [ 3, 11 ],
      "id_str" : "16316447",
      "id" : 16316447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/wyC8PiAv",
      "expanded_url" : "http:\/\/vine.co\/v\/bJFmAzjhOMK",
      "display_url" : "vine.co\/v\/bJFmAzjhOMK"
    } ]
  },
  "geo" : { },
  "id_str" : "296484272112549888",
  "text" : "RT @watch84: OpenHack! #buffalo http:\/\/t.co\/wyC8PiAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/wyC8PiAv",
        "expanded_url" : "http:\/\/vine.co\/v\/bJFmAzjhOMK",
        "display_url" : "vine.co\/v\/bJFmAzjhOMK"
      } ]
    },
    "geo" : { },
    "id_str" : "296409885640384512",
    "text" : "OpenHack! #buffalo http:\/\/t.co\/wyC8PiAv",
    "id" : 296409885640384512,
    "created_at" : "2013-01-30 00:09:58 +0000",
    "user" : {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "protected" : false,
      "id_str" : "16316447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508105131569999872\/HtraEaM5_normal.jpeg",
      "id" : 16316447,
      "verified" : false
    }
  },
  "id" : 296484272112549888,
  "created_at" : "2013-01-30 05:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 24, 38 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/7W0LL32A",
      "expanded_url" : "http:\/\/vine.co\/v\/bJFzvD01e9v",
      "display_url" : "vine.co\/v\/bJFzvD01e9v"
    } ]
  },
  "geo" : { },
  "id_str" : "296484263354834944",
  "text" : "RT @aquaranto: OpenHack @coworkbuffalo http:\/\/t.co\/7W0LL32A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 9, 23 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/7W0LL32A",
        "expanded_url" : "http:\/\/vine.co\/v\/bJFzvD01e9v",
        "display_url" : "vine.co\/v\/bJFzvD01e9v"
      } ]
    },
    "geo" : { },
    "id_str" : "296406811848876033",
    "text" : "OpenHack @coworkbuffalo http:\/\/t.co\/7W0LL32A",
    "id" : 296406811848876033,
    "created_at" : "2013-01-29 23:57:45 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 296484263354834944,
  "created_at" : "2013-01-30 05:05:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 24, 33 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 37, 51 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296413488153247744",
  "text" : "Such a packed house for @openhack at @coworkbuffalo, our router is having trouble keeping up. Woot!",
  "id" : 296413488153247744,
  "created_at" : "2013-01-30 00:24:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "296392703183298560",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Headhunters: God Make Me Funky \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 296392703183298560,
  "created_at" : "2013-01-29 23:01:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 27, 34 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 39, 49 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 53, 67 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 72, 81 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/296392408210497536\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/av5Cy7yy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBz_Uy4CYAAlahm.jpg",
      "id_str" : "296392408218886144",
      "id" : 296392408218886144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBz_Uy4CYAAlahm.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/av5Cy7yy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296392408210497536",
  "text" : "\u201CWe\u2019re like a sexy picnic\u201D @nb3004 and @magnachef at @coworkbuffalo for @openhack ! http:\/\/t.co\/av5Cy7yy",
  "id" : 296392408210497536,
  "created_at" : "2013-01-29 23:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/Z2jpCdhq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=x0d0pQgLNws",
      "display_url" : "youtube.com\/watch?v=x0d0pQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296366566034001920",
  "text" : "FOOTBALL! AMERICA! JESUS! http:\/\/t.co\/Z2jpCdhq #superbowl",
  "id" : 296366566034001920,
  "created_at" : "2013-01-29 21:17:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/IO0cZkVv",
      "expanded_url" : "http:\/\/www.craigslist.org\/about\/best\/sdo\/2370048082.html",
      "display_url" : "craigslist.org\/about\/best\/sdo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296361206875299840",
  "text" : "\"Last outing, we had a group that was so charged we attracted bears.\" http:\/\/t.co\/IO0cZkVv",
  "id" : 296361206875299840,
  "created_at" : "2013-01-29 20:56:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 3, 15 ],
      "id_str" : "6927562",
      "id" : 6927562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296310894739210241",
  "text" : "RT @thomasfuchs: As a programmer, never underestimate your ability to come up with ridiculously complex solutions for simple problems.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296310588680830977",
    "text" : "As a programmer, never underestimate your ability to come up with ridiculously complex solutions for simple problems.",
    "id" : 296310588680830977,
    "created_at" : "2013-01-29 17:35:24 +0000",
    "user" : {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "protected" : false,
      "id_str" : "6927562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528509543119343616\/bDhQei1L_normal.jpeg",
      "id" : 6927562,
      "verified" : false
    }
  },
  "id" : 296310894739210241,
  "created_at" : "2013-01-29 17:36:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezekiel Templin",
      "screen_name" : "ezkl",
      "indices" : [ 0, 5 ],
      "id_str" : "9468622",
      "id" : 9468622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296286248081969153",
  "geo" : { },
  "id_str" : "296291272052862977",
  "in_reply_to_user_id" : 9468622,
  "text" : "@ezkl awesome. Anyone else in Erie we can notify or groups we can post to?",
  "id" : 296291272052862977,
  "in_reply_to_status_id" : 296286248081969153,
  "created_at" : "2013-01-29 16:18:38 +0000",
  "in_reply_to_screen_name" : "ezkl",
  "in_reply_to_user_id_str" : "9468622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 88, 101 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 102, 110 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 111, 123 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 124, 138 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/949OBlpc",
      "expanded_url" : "http:\/\/barcampbuffalo.org\/",
      "display_url" : "barcampbuffalo.org"
    } ]
  },
  "geo" : { },
  "id_str" : "296285436769345538",
  "text" : "Hey PGH folks...anyone want to come up to Buffalo Saturday for http:\/\/t.co\/949OBlpc ? + @justinxreese @whit537 @juliepagano @Carols10cents",
  "id" : 296285436769345538,
  "created_at" : "2013-01-29 15:55:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296275555890905089",
  "geo" : { },
  "id_str" : "296275912373182464",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich is it version 11.0?",
  "id" : 296275912373182464,
  "in_reply_to_status_id" : 296275555890905089,
  "created_at" : "2013-01-29 15:17:36 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 27, 35 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/296275549276487680\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/J7uhfWL1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BByVCtbCQAALZPj.jpg",
      "id_str" : "296275549284876288",
      "id" : 296275549284876288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BByVCtbCQAALZPj.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/J7uhfWL1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296275549276487680",
  "text" : "I was really hoping to get @theBMFT for breakfast. http:\/\/t.co\/J7uhfWL1",
  "id" : 296275549276487680,
  "created_at" : "2013-01-29 15:16:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "travis jeffery",
      "screen_name" : "travisjeffery",
      "indices" : [ 24, 38 ],
      "id_str" : "679103",
      "id" : 679103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/MpoaOmnL",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3413-welcome-travis-jeffery-to-37signals",
      "display_url" : "37signals.com\/svn\/posts\/3413\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296109086087454720",
  "text" : "RT @jasonfried: Welcome @travisjeffery to 37signals: http:\/\/t.co\/MpoaOmnL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "travis jeffery",
        "screen_name" : "travisjeffery",
        "indices" : [ 8, 22 ],
        "id_str" : "679103",
        "id" : 679103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/MpoaOmnL",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3413-welcome-travis-jeffery-to-37signals",
        "display_url" : "37signals.com\/svn\/posts\/3413\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "296027257942728704",
    "text" : "Welcome @travisjeffery to 37signals: http:\/\/t.co\/MpoaOmnL",
    "id" : 296027257942728704,
    "created_at" : "2013-01-28 22:49:32 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 296109086087454720,
  "created_at" : "2013-01-29 04:14:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/AZNcaaAH",
      "expanded_url" : "https:\/\/github.com\/qrush\/motion-settings-bundle",
      "display_url" : "github.com\/qrush\/motion-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296075476571656192",
  "text" : "Cut v0.1.1 of motion-settings-bundle, this time with more settings! https:\/\/t.co\/AZNcaaAH",
  "id" : 296075476571656192,
  "created_at" : "2013-01-29 02:01:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296062361998073857",
  "text" : "Actually, disregard! I figured out what I was doing wrong.",
  "id" : 296062361998073857,
  "created_at" : "2013-01-29 01:09:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296061522197745664",
  "text" : "I'm looking for a gem, unix script, or something that takes a file\/input and reformats into a given column length (say, 25). Any ideas?",
  "id" : 296061522197745664,
  "created_at" : "2013-01-29 01:05:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296033940546924545",
  "text" : "Epic day of bug squashing for Basecamp iOS today. Getting so close!",
  "id" : 296033940546924545,
  "created_at" : "2013-01-28 23:16:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296019490511147008",
  "text" : "Someone set the distance settings to Minimum in Buffalo. Or we have a really shitty graphics card.",
  "id" : 296019490511147008,
  "created_at" : "2013-01-28 22:18:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 14, 26 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296004936255283202",
  "geo" : { },
  "id_str" : "296005587966230529",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm @SteveStreza Oops, I updated Xcode and it deleted all existing SDKs and simulators I had installed &gt;:[",
  "id" : 296005587966230529,
  "in_reply_to_status_id" : 296004936255283202,
  "created_at" : "2013-01-28 21:23:26 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296002755993169920",
  "text" : "BRACE FOR IMPACT",
  "id" : 296002755993169920,
  "created_at" : "2013-01-28 21:12:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295978810187341824",
  "geo" : { },
  "id_str" : "295979108872093696",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz I'm compiling once again! That was some awesome turnaround. Thanks man.",
  "id" : 295979108872093696,
  "in_reply_to_status_id" : 295978810187341824,
  "created_at" : "2013-01-28 19:38:13 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295978926260506625",
  "text" : "RT @RubyMotion: RubyMotion 1.32 is available, adding support for Xcode 4.6 \/ iOS 6.1 SDK (+ a few bug fixes). Enjoy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295978559091134465",
    "text" : "RubyMotion 1.32 is available, adding support for Xcode 4.6 \/ iOS 6.1 SDK (+ a few bug fixes). Enjoy!",
    "id" : 295978559091134465,
    "created_at" : "2013-01-28 19:36:02 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 295978926260506625,
  "created_at" : "2013-01-28 19:37:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 0, 4 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295977652664274944",
  "geo" : { },
  "id_str" : "295977838014787584",
  "in_reply_to_user_id" : 10452222,
  "text" : "@lrz thank you, I was just about to post to the list about this.",
  "id" : 295977838014787584,
  "in_reply_to_status_id" : 295977652664274944,
  "created_at" : "2013-01-28 19:33:10 +0000",
  "in_reply_to_screen_name" : "lrz",
  "in_reply_to_user_id_str" : "10452222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 105, 109 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295977103210450946",
  "text" : "RubyMotion devs - beware of updating XCode today: It deletes your 5.1\/6.0 simulators and SDKs &gt;:[ \/cc @lrz",
  "id" : 295977103210450946,
  "created_at" : "2013-01-28 19:30:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Lindsay",
      "screen_name" : "adamlindsay",
      "indices" : [ 0, 12 ],
      "id_str" : "49763",
      "id" : 49763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295924383162171392",
  "geo" : { },
  "id_str" : "295936844502294528",
  "in_reply_to_user_id" : 49763,
  "text" : "@adamlindsay maybe @NYWineWench will?",
  "id" : 295936844502294528,
  "in_reply_to_status_id" : 295924383162171392,
  "created_at" : "2013-01-28 16:50:16 +0000",
  "in_reply_to_screen_name" : "adamlindsay",
  "in_reply_to_user_id_str" : "49763",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295901499706441728",
  "geo" : { },
  "id_str" : "295901625573330944",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi holy shit a crossfade.",
  "id" : 295901625573330944,
  "in_reply_to_status_id" : 295901499706441728,
  "created_at" : "2013-01-28 14:30:19 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295900796984373248",
  "geo" : { },
  "id_str" : "295901454047272961",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi the kids face :o",
  "id" : 295901454047272961,
  "in_reply_to_status_id" : 295900796984373248,
  "created_at" : "2013-01-28 14:29:38 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/eGxwfR1o",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5J2kc4oZTVU",
      "display_url" : "youtube.com\/watch?v=5J2kc4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295901216578338816",
  "text" : "Current status: BEES! http:\/\/t.co\/eGxwfR1o",
  "id" : 295901216578338816,
  "created_at" : "2013-01-28 14:28:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "follow @mattetti",
      "screen_name" : "merbist",
      "indices" : [ 9, 17 ],
      "id_str" : "1549117117",
      "id" : 1549117117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295761475497246720",
  "geo" : { },
  "id_str" : "295781613902639104",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety @merbist this doesn\u2019t surprise me one bit.",
  "id" : 295781613902639104,
  "in_reply_to_status_id" : 295761475497246720,
  "created_at" : "2013-01-28 06:33:26 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295781004487049216",
  "text" : "RT @rjs: When designing an app get the mechanics and flow right first. Those are the walls and foundation. The rest is furniture you can ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294942302382739457",
    "text" : "When designing an app get the mechanics and flow right first. Those are the walls and foundation. The rest is furniture you can move around.",
    "id" : 294942302382739457,
    "created_at" : "2013-01-25 22:58:19 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 295781004487049216,
  "created_at" : "2013-01-28 06:31:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "indices" : [ 16, 32 ],
      "id_str" : "620654544",
      "id" : 620654544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295779597797187585",
  "text" : "HUMAN laughs at @SelfAwareROOMBA, requests FOLLOW for APPLIANCE narratives",
  "id" : 295779597797187585,
  "created_at" : "2013-01-28 06:25:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 10, 19 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295777351671889921",
  "text" : "40ish for @OpenHack in Pittsburgh and Chicago! Keep the momentum rolling!",
  "id" : 295777351671889921,
  "created_at" : "2013-01-28 06:16:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 3, 12 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/5aCXCc4f",
      "expanded_url" : "http:\/\/guestlistapp.com\/events\/145317",
      "display_url" : "guestlistapp.com\/events\/145317"
    } ]
  },
  "geo" : { },
  "id_str" : "295777107584356352",
  "text" : "RT @DockYard: 13 already signed up for next week\u2019s OpenHack in Boston: http:\/\/t.co\/5aCXCc4f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/5aCXCc4f",
        "expanded_url" : "http:\/\/guestlistapp.com\/events\/145317",
        "display_url" : "guestlistapp.com\/events\/145317"
      } ]
    },
    "geo" : { },
    "id_str" : "294910278712320000",
    "text" : "13 already signed up for next week\u2019s OpenHack in Boston: http:\/\/t.co\/5aCXCc4f",
    "id" : 294910278712320000,
    "created_at" : "2013-01-25 20:51:04 +0000",
    "user" : {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "protected" : false,
      "id_str" : "18545770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000606125141\/c367193b2bf7b32dad02e39c9db058f5_normal.jpeg",
      "id" : 18545770,
      "verified" : false
    }
  },
  "id" : 295777107584356352,
  "created_at" : "2013-01-28 06:15:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Chen",
      "screen_name" : "franklinchen",
      "indices" : [ 3, 16 ],
      "id_str" : "15734947",
      "id" : 15734947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/DJjZQp7A",
      "expanded_url" : "http:\/\/bit.ly\/10MKFjZ",
      "display_url" : "bit.ly\/10MKFjZ"
    } ]
  },
  "geo" : { },
  "id_str" : "295777088995209219",
  "text" : "RT @franklinchen: My blog: Attending the first OpenHack Pittsburgh meeting http:\/\/t.co\/DJjZQp7A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/DJjZQp7A",
        "expanded_url" : "http:\/\/bit.ly\/10MKFjZ",
        "display_url" : "bit.ly\/10MKFjZ"
      } ]
    },
    "geo" : { },
    "id_str" : "295029008851152896",
    "text" : "My blog: Attending the first OpenHack Pittsburgh meeting http:\/\/t.co\/DJjZQp7A",
    "id" : 295029008851152896,
    "created_at" : "2013-01-26 04:42:51 +0000",
    "user" : {
      "name" : "Franklin Chen",
      "screen_name" : "franklinchen",
      "protected" : false,
      "id_str" : "15734947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149890502\/franklin_normal.jpg",
      "id" : 15734947,
      "verified" : false
    }
  },
  "id" : 295777088995209219,
  "created_at" : "2013-01-28 06:15:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braintree ",
      "screen_name" : "braintree",
      "indices" : [ 3, 13 ],
      "id_str" : "12831202",
      "id" : 12831202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/2gsonpJf",
      "expanded_url" : "http:\/\/www.meetup.com\/Chicago-Github-Open-Hack\/events\/98996772\/",
      "display_url" : "meetup.com\/Chicago-Github\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295777073195253760",
  "text" : "RT @braintree: Come out and hack tomorrow at Braintree HQ w. OpenHack Chicago: http:\/\/t.co\/2gsonpJf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/2gsonpJf",
        "expanded_url" : "http:\/\/www.meetup.com\/Chicago-Github-Open-Hack\/events\/98996772\/",
        "display_url" : "meetup.com\/Chicago-Github\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295714404824137728",
    "text" : "Come out and hack tomorrow at Braintree HQ w. OpenHack Chicago: http:\/\/t.co\/2gsonpJf",
    "id" : 295714404824137728,
    "created_at" : "2013-01-28 02:06:22 +0000",
    "user" : {
      "name" : "Braintree ",
      "screen_name" : "braintree",
      "protected" : false,
      "id_str" : "12831202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509036712601739264\/mgD1tpPz_normal.jpeg",
      "id" : 12831202,
      "verified" : true
    }
  },
  "id" : 295777073195253760,
  "created_at" : "2013-01-28 06:15:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295724219797479425",
  "text" : "OH \u201CI was a feminist since 3rd grade\u201D",
  "id" : 295724219797479425,
  "created_at" : "2013-01-28 02:45:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "food",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/GHOZ0qnl",
      "expanded_url" : "http:\/\/vine.co\/v\/bJMmLiaxL9Y",
      "display_url" : "vine.co\/v\/bJMmLiaxL9Y"
    } ]
  },
  "geo" : { },
  "id_str" : "295679456494907392",
  "text" : "This is so much #food. http:\/\/t.co\/GHOZ0qnl",
  "id" : 295679456494907392,
  "created_at" : "2013-01-27 23:47:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 25, 30 ]
    }, {
      "text" : "husky",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/gUQU3gx9",
      "expanded_url" : "http:\/\/vine.co\/v\/bJhVxTF0nDZ",
      "display_url" : "vine.co\/v\/bJhVxTF0nDZ"
    } ]
  },
  "geo" : { },
  "id_str" : "295676682164109313",
  "text" : "Sasha and Geddy WRASSLIN #pets #husky http:\/\/t.co\/gUQU3gx9",
  "id" : 295676682164109313,
  "created_at" : "2013-01-27 23:36:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/CLhbDtkf",
      "expanded_url" : "http:\/\/vine.co\/v\/bJheQLmmV3H",
      "display_url" : "vine.co\/v\/bJheQLmmV3H"
    } ]
  },
  "geo" : { },
  "id_str" : "295653645960228864",
  "text" : "Preparing for taycos! http:\/\/t.co\/CLhbDtkf",
  "id" : 295653645960228864,
  "created_at" : "2013-01-27 22:04:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "husky",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/86RoPvh2",
      "expanded_url" : "http:\/\/vine.co\/v\/bJbd2bh7Qh7",
      "display_url" : "vine.co\/v\/bJbd2bh7Qh7"
    } ]
  },
  "geo" : { },
  "id_str" : "295626993049956352",
  "text" : "There Will Be Mud. #pets #husky #buffalo http:\/\/t.co\/86RoPvh2",
  "id" : 295626993049956352,
  "created_at" : "2013-01-27 20:19:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/IFEQnjR2",
      "expanded_url" : "http:\/\/buffalonews.com\/apps\/pbcs.dll\/article?AID=\/20130126\/CITYANDREGION\/130129322\/1002",
      "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295603685508136960",
  "text" : "RT @BuffaloRising: \"More than $1 billion in new construction is in the works in downtown Buffalo. . . \"  http:\/\/t.co\/IFEQnjR2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/IFEQnjR2",
        "expanded_url" : "http:\/\/buffalonews.com\/apps\/pbcs.dll\/article?AID=\/20130126\/CITYANDREGION\/130129322\/1002",
        "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295591693720354816",
    "text" : "\"More than $1 billion in new construction is in the works in downtown Buffalo. . . \"  http:\/\/t.co\/IFEQnjR2",
    "id" : 295591693720354816,
    "created_at" : "2013-01-27 17:58:46 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 295603685508136960,
  "created_at" : "2013-01-27 18:46:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/uWz0uZ7C",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TcK0MYgnHjo&list=UUCHcEUksSVKsRDH86j77Ntg",
      "display_url" : "youtube.com\/watch?v=TcK0MY\u2026"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/19IgWdYD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=z5Otla5157c&list=UUCHcEUksSVKsRDH86j77Ntg&index=1",
      "display_url" : "youtube.com\/watch?v=z5Otla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295602620389793792",
  "text" : "The Lonely Island production video has gone way up... it doesn't have the same feel. then: http:\/\/t.co\/uWz0uZ7C now: http:\/\/t.co\/19IgWdYD",
  "id" : 295602620389793792,
  "created_at" : "2013-01-27 18:42:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/MHikybvA",
      "expanded_url" : "http:\/\/bryko.tumblr.com\/post\/41567030506\/rip",
      "display_url" : "bryko.tumblr.com\/post\/415670305\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295586527470317568",
  "text" : "\"Long live the king\" http:\/\/t.co\/MHikybvA",
  "id" : 295586527470317568,
  "created_at" : "2013-01-27 17:38:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 3, 12 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/kVwc6nNi",
      "expanded_url" : "http:\/\/vimeo.com\/58018330",
      "display_url" : "vimeo.com\/58018330"
    } ]
  },
  "geo" : { },
  "id_str" : "295576761805197312",
  "text" : "RT @roidrage: Nice little video shot at the Chemex factory in Pittsfield, MA. Courtesy of Five Elephant Coffee: http:\/\/t.co\/kVwc6nNi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/kVwc6nNi",
        "expanded_url" : "http:\/\/vimeo.com\/58018330",
        "display_url" : "vimeo.com\/58018330"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.5098572765, 13.4580532582 ]
    },
    "id_str" : "295573832771710976",
    "text" : "Nice little video shot at the Chemex factory in Pittsfield, MA. Courtesy of Five Elephant Coffee: http:\/\/t.co\/kVwc6nNi",
    "id" : 295573832771710976,
    "created_at" : "2013-01-27 16:47:47 +0000",
    "user" : {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "protected" : false,
      "id_str" : "14658472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2938540224\/9ffc554b0eabb077a915cfe0d56f3c1f_normal.jpeg",
      "id" : 14658472,
      "verified" : false
    }
  },
  "id" : 295576761805197312,
  "created_at" : "2013-01-27 16:59:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 0, 7 ],
      "id_str" : "39617149",
      "id" : 39617149
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 8, 19 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/SMotvalE",
      "expanded_url" : "http:\/\/pine.fm\/LearnToProgram\/",
      "display_url" : "pine.fm\/LearnToProgram\/"
    } ]
  },
  "in_reply_to_status_id_str" : "295409198030790657",
  "geo" : { },
  "id_str" : "295415970871246849",
  "in_reply_to_user_id" : 39617149,
  "text" : "@cczona @ashedryden Learn to Program. http:\/\/t.co\/SMotvalE",
  "id" : 295415970871246849,
  "in_reply_to_status_id" : 295409198030790657,
  "created_at" : "2013-01-27 06:20:30 +0000",
  "in_reply_to_screen_name" : "cczona",
  "in_reply_to_user_id_str" : "39617149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Williams",
      "screen_name" : "justin",
      "indices" : [ 0, 7 ],
      "id_str" : "929",
      "id" : 929
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 8, 15 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295411977457643522",
  "geo" : { },
  "id_str" : "295415618302246914",
  "in_reply_to_user_id" : 929,
  "text" : "@justin @soffes what a sad story of a completely unhealthy workaholic. Wonder what he\u2019ll think of that in 5, 10, 20 years.",
  "id" : 295415618302246914,
  "in_reply_to_status_id" : 295411977457643522,
  "created_at" : "2013-01-27 06:19:06 +0000",
  "in_reply_to_screen_name" : "justin",
  "in_reply_to_user_id_str" : "929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boardgames",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/X0CPvz8J",
      "expanded_url" : "http:\/\/vine.co\/v\/bJaD0MW7lw2",
      "display_url" : "vine.co\/v\/bJaD0MW7lw2"
    } ]
  },
  "geo" : { },
  "id_str" : "295362620553326592",
  "text" : "Cards Against Humanity. #boardgames http:\/\/t.co\/X0CPvz8J",
  "id" : 295362620553326592,
  "created_at" : "2013-01-27 02:48:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 23, 34 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/VKbinwJW",
      "expanded_url" : "http:\/\/vine.co\/v\/bJzFE3x25hb",
      "display_url" : "vine.co\/v\/bJzFE3x25hb"
    } ]
  },
  "geo" : { },
  "id_str" : "295332801375514624",
  "text" : "Shake Shack burgers at @kevinpurdy's http:\/\/t.co\/VKbinwJW",
  "id" : 295332801375514624,
  "created_at" : "2013-01-27 00:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/7vY8XfSM",
      "expanded_url" : "http:\/\/vinepeek.com\/",
      "display_url" : "vinepeek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "295312787217981440",
  "text" : "This feels like what aliens would be watching if they wanted to learn what Earth was like right now: http:\/\/t.co\/7vY8XfSM",
  "id" : 295312787217981440,
  "created_at" : "2013-01-26 23:30:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Pie Inglis",
      "screen_name" : "zachinglis",
      "indices" : [ 0, 11 ],
      "id_str" : "770545",
      "id" : 770545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295303463116627968",
  "geo" : { },
  "id_str" : "295304212894580737",
  "in_reply_to_user_id" : 770545,
  "text" : "@zachinglis if you like complicated board games with a lot of depth that stays interesting throughout the entire game, it's awesome.",
  "id" : 295304212894580737,
  "in_reply_to_status_id" : 295303463116627968,
  "created_at" : "2013-01-26 22:56:25 +0000",
  "in_reply_to_screen_name" : "zachinglis",
  "in_reply_to_user_id_str" : "770545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boardgames",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/h2Eet2cZ",
      "expanded_url" : "http:\/\/vine.co\/v\/bJu0Fe3KIdv",
      "display_url" : "vine.co\/v\/bJu0Fe3KIdv"
    } ]
  },
  "geo" : { },
  "id_str" : "295303419923677184",
  "text" : "Agricola! #boardgames http:\/\/t.co\/h2Eet2cZ",
  "id" : 295303419923677184,
  "created_at" : "2013-01-26 22:53:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295259325985878016",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer one of the brew guys helped me out and kept watch\u2026just wanted to say thanks!",
  "id" : 295259325985878016,
  "created_at" : "2013-01-26 19:58:03 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295239109948096513",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer meant to ask- are dogs ok in the brewery? Just for a fill or two. If not, no problem :)",
  "id" : 295239109948096513,
  "created_at" : "2013-01-26 18:37:43 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    }, {
      "name" : "The Barkyard",
      "screen_name" : "theBarkyard",
      "indices" : [ 71, 83 ],
      "id_str" : "57851296",
      "id" : 57851296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295191759850459137",
  "geo" : { },
  "id_str" : "295221106321793025",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer Roger! 2 growler fills coming up today after a visit to @thebarkyard",
  "id" : 295221106321793025,
  "in_reply_to_status_id" : 295191759850459137,
  "created_at" : "2013-01-26 17:26:11 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot(t)",
      "screen_name" : "elliottkember",
      "indices" : [ 3, 17 ],
      "id_str" : "903351",
      "id" : 903351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6dfHiLqL",
      "expanded_url" : "http:\/\/ruby.sys-con.com\/node\/315210",
      "display_url" : "ruby.sys-con.com\/node\/315210"
    } ]
  },
  "geo" : { },
  "id_str" : "295203862141362176",
  "text" : "RT @elliottkember: \"Ruby on Rails Won't Make It In 2007 and Forget About AJAX\" http:\/\/t.co\/6dfHiLqL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/6dfHiLqL",
        "expanded_url" : "http:\/\/ruby.sys-con.com\/node\/315210",
        "display_url" : "ruby.sys-con.com\/node\/315210"
      } ]
    },
    "geo" : { },
    "id_str" : "295203671384416256",
    "text" : "\"Ruby on Rails Won't Make It In 2007 and Forget About AJAX\" http:\/\/t.co\/6dfHiLqL",
    "id" : 295203671384416256,
    "created_at" : "2013-01-26 16:16:54 +0000",
    "user" : {
      "name" : "Elliot(t)",
      "screen_name" : "elliottkember",
      "protected" : false,
      "id_str" : "903351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527343390195585024\/tBxCTKxd_normal.jpeg",
      "id" : 903351,
      "verified" : false
    }
  },
  "id" : 295203862141362176,
  "created_at" : "2013-01-26 16:17:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 12, 21 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295044465972895746",
  "geo" : { },
  "id_str" : "295045177008087040",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark @shildner this is so Montana",
  "id" : 295045177008087040,
  "in_reply_to_status_id" : 295044465972895746,
  "created_at" : "2013-01-26 05:47:06 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295036178569236480",
  "text" : "@juliepagano USE THUNDERSTONE!",
  "id" : 295036178569236480,
  "created_at" : "2013-01-26 05:11:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295027548314816512",
  "text" : "@juliepagano the next one is better",
  "id" : 295027548314816512,
  "created_at" : "2013-01-26 04:37:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boardgames",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/xFxNeach",
      "expanded_url" : "http:\/\/vine.co\/v\/b5EvLMq56JP",
      "display_url" : "vine.co\/v\/b5EvLMq56JP"
    } ]
  },
  "geo" : { },
  "id_str" : "295024272009728001",
  "text" : "Lost Cities! #boardgames http:\/\/t.co\/xFxNeach",
  "id" : 295024272009728001,
  "created_at" : "2013-01-26 04:24:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bang",
      "indices" : [ 6, 11 ]
    }, {
      "text" : "boardgames",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/99nynShl",
      "expanded_url" : "http:\/\/vine.co\/v\/b5EK9EY0zn5",
      "display_url" : "vine.co\/v\/b5EK9EY0zn5"
    } ]
  },
  "geo" : { },
  "id_str" : "295015405993459712",
  "text" : "Bang! #bang #boardgames http:\/\/t.co\/99nynShl",
  "id" : 295015405993459712,
  "created_at" : "2013-01-26 03:48:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "husky",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/eKo61hAU",
      "expanded_url" : "http:\/\/vine.co\/v\/b50gD0JAuOt",
      "display_url" : "vine.co\/v\/b50gD0JAuOt"
    } ]
  },
  "geo" : { },
  "id_str" : "294992845817929728",
  "text" : "Feet are tasty, don't hurt me no more. #pets #husky http:\/\/t.co\/eKo61hAU",
  "id" : 294992845817929728,
  "created_at" : "2013-01-26 02:19:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/ITMEPjaT",
      "expanded_url" : "https:\/\/soundcloud.com\/catalinarhymemixers\/da-fuckin-catalina-rhyme-mixer-ft-haddaway-jay-z-black-eyed-peas",
      "display_url" : "soundcloud.com\/catalinarhymem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294991171736973313",
  "text" : "Snapping necks, shipping apps. WAH! https:\/\/t.co\/ITMEPjaT",
  "id" : 294991171736973313,
  "created_at" : "2013-01-26 02:12:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khan Noonien Snow",
      "screen_name" : "winterstormkhan",
      "indices" : [ 3, 19 ],
      "id_str" : "1120600298",
      "id" : 1120600298
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294974795802632193",
  "text" : "RT @winterstormkhan: @qrush How could I disappoint my loyal subject.... *AHEM* followers?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "294917236097961984",
    "geo" : { },
    "id_str" : "294972168192815104",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush How could I disappoint my loyal subject.... *AHEM* followers?",
    "id" : 294972168192815104,
    "in_reply_to_status_id" : 294917236097961984,
    "created_at" : "2013-01-26 00:56:59 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Khan Noonien Snow",
      "screen_name" : "winterstormkhan",
      "protected" : false,
      "id_str" : "1120600298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3163081919\/e99479c19e6299cc53f7a07b841d7f5a_normal.jpeg",
      "id" : 1120600298,
      "verified" : false
    }
  },
  "id" : 294974795802632193,
  "created_at" : "2013-01-26 01:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vine",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294968526094098432",
  "text" : "Has there been a #vine engagement proposal yet? 6 seconds is plenty of time.",
  "id" : 294968526094098432,
  "created_at" : "2013-01-26 00:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "husky",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/bYogHdr4",
      "expanded_url" : "http:\/\/vine.co\/v\/b52FvgPJiWT",
      "display_url" : "vine.co\/v\/b52FvgPJiWT"
    } ]
  },
  "geo" : { },
  "id_str" : "294966942966620160",
  "text" : "Blowing coat time again. (\uFF1E\u4EBA\uFF1C;) #pets #husky http:\/\/t.co\/bYogHdr4",
  "id" : 294966942966620160,
  "created_at" : "2013-01-26 00:36:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 25, 30 ]
    }, {
      "text" : "husky",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Fogcx6Rr",
      "expanded_url" : "http:\/\/vine.co\/v\/b52nBKqLW3v",
      "display_url" : "vine.co\/v\/b52nBKqLW3v"
    } ]
  },
  "geo" : { },
  "id_str" : "294956372393594880",
  "text" : "Ged chomping on Mr. Cow. #pets #husky http:\/\/t.co\/Fogcx6Rr",
  "id" : 294956372393594880,
  "created_at" : "2013-01-25 23:54:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khan",
      "screen_name" : "WINTER_STORM_KH",
      "indices" : [ 0, 16 ],
      "id_str" : "1120307358",
      "id" : 1120307358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294922201470230528",
  "geo" : { },
  "id_str" : "294926566218137600",
  "in_reply_to_user_id" : 1120307358,
  "text" : "@WINTER_STORM_KH LOL",
  "id" : 294926566218137600,
  "in_reply_to_status_id" : 294922201470230528,
  "created_at" : "2013-01-25 21:55:47 +0000",
  "in_reply_to_screen_name" : "WINTER_STORM_KH",
  "in_reply_to_user_id_str" : "1120307358",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294917236097961984",
  "text" : "Please, someone register @WINTER_STORM_KHAN. You know what to do.",
  "id" : 294917236097961984,
  "created_at" : "2013-01-25 21:18:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 3, 14 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/benjaminws\/status\/294916901153423363\/photo\/1",
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/QpARISv8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBfBW-wCQAEKy2j.png",
      "id_str" : "294916901161811969",
      "id" : 294916901161811969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBfBW-wCQAEKy2j.png",
      "sizes" : [ {
        "h" : 49,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 49,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 298
      } ],
      "display_url" : "pic.twitter.com\/QpARISv8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294916992324993026",
  "text" : "RT @benjaminws: We could have told you how deadly Khan is. http:\/\/t.co\/QpARISv8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/benjaminws\/status\/294916901153423363\/photo\/1",
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/QpARISv8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBfBW-wCQAEKy2j.png",
        "id_str" : "294916901161811969",
        "id" : 294916901161811969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBfBW-wCQAEKy2j.png",
        "sizes" : [ {
          "h" : 49,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 49,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 298
        } ],
        "display_url" : "pic.twitter.com\/QpARISv8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294916901153423363",
    "text" : "We could have told you how deadly Khan is. http:\/\/t.co\/QpARISv8",
    "id" : 294916901153423363,
    "created_at" : "2013-01-25 21:17:23 +0000",
    "user" : {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "protected" : false,
      "id_str" : "14188391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572829103221268480\/Yz-uQhpX_normal.jpeg",
      "id" : 14188391,
      "verified" : false
    }
  },
  "id" : 294916992324993026,
  "created_at" : "2013-01-25 21:17:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/qEinxqo7",
      "expanded_url" : "http:\/\/flatluigi.tumblr.com\/post\/41443795900\/did-you-know-how-hilarious-the-patch-notes-to-the-sims",
      "display_url" : "flatluigi.tumblr.com\/post\/414437959\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294916009423405057",
  "text" : "\"Fixed an issue that caused Sims to leave their Toddler inside a bar at closing time.\" http:\/\/t.co\/qEinxqo7",
  "id" : 294916009423405057,
  "created_at" : "2013-01-25 21:13:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 0, 15 ],
      "id_str" : "6151392",
      "id" : 6151392
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 52, 61 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294911168563261440",
  "geo" : { },
  "id_str" : "294911445211152384",
  "in_reply_to_user_id" : 6151392,
  "text" : "@TheDeadSerious i am biased, but jekyll is simpler. @migreyes will hopefully write more about soon.",
  "id" : 294911445211152384,
  "in_reply_to_status_id" : 294911168563261440,
  "created_at" : "2013-01-25 20:55:42 +0000",
  "in_reply_to_screen_name" : "TheDeadSerious",
  "in_reply_to_user_id_str" : "6151392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vine",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/qcrY40xP",
      "expanded_url" : "http:\/\/5secondfilms.com\/",
      "display_url" : "5secondfilms.com"
    } ]
  },
  "geo" : { },
  "id_str" : "294911138251038721",
  "text" : "I've also realized that #vine is http:\/\/t.co\/qcrY40xP as a service.",
  "id" : 294911138251038721,
  "created_at" : "2013-01-25 20:54:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 0, 8 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294910615674298368",
  "geo" : { },
  "id_str" : "294910930125459456",
  "in_reply_to_user_id" : 41296337,
  "text" : "@LOUDBOT PORKCHOP SANDWICHES!",
  "id" : 294910930125459456,
  "in_reply_to_status_id" : 294910615674298368,
  "created_at" : "2013-01-25 20:53:39 +0000",
  "in_reply_to_screen_name" : "LOUDBOT",
  "in_reply_to_user_id_str" : "41296337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/m3baAHIn",
      "expanded_url" : "http:\/\/basecamp.com\/help",
      "display_url" : "basecamp.com\/help"
    } ]
  },
  "geo" : { },
  "id_str" : "294909304673284096",
  "text" : "Get some Basecamp help, now generated by Jekyll! http:\/\/t.co\/m3baAHIn",
  "id" : 294909304673284096,
  "created_at" : "2013-01-25 20:47:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294890591702093824",
  "text" : "The Weather Channel has finally figured out how to increase viewership\/reach: Turn storm names into memes.",
  "id" : 294890591702093824,
  "created_at" : "2013-01-25 19:32:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/bZDd4Fxt",
      "expanded_url" : "http:\/\/www.weather.com\/news\/weather-winter\/winter-storm-khan-20130124",
      "display_url" : "weather.com\/news\/weather-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294890363775225856",
  "text" : "KHAAAAAAN! http:\/\/t.co\/bZDd4Fxt",
  "id" : 294890363775225856,
  "created_at" : "2013-01-25 19:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294874513064202240",
  "geo" : { },
  "id_str" : "294875968328314882",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman  I had a pringles-esque container of them but never knew how to play",
  "id" : 294875968328314882,
  "in_reply_to_status_id" : 294874513064202240,
  "created_at" : "2013-01-25 18:34:44 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vine",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294869628721696768",
  "text" : "Holy shit, #vine is going to change funny internet cat videos.",
  "id" : 294869628721696768,
  "created_at" : "2013-01-25 18:09:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Suttles",
      "screen_name" : "jlsuttles",
      "indices" : [ 0, 10 ],
      "id_str" : "21170138",
      "id" : 21170138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294864724175224832",
  "geo" : { },
  "id_str" : "294869049400250370",
  "in_reply_to_user_id" : 21170138,
  "text" : "@jlsuttles Pair flying is NOT RECOMMENDED",
  "id" : 294869049400250370,
  "in_reply_to_status_id" : 294864724175224832,
  "created_at" : "2013-01-25 18:07:14 +0000",
  "in_reply_to_screen_name" : "jlsuttles",
  "in_reply_to_user_id_str" : "21170138",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gatesman",
      "screen_name" : "12protons",
      "indices" : [ 3, 13 ],
      "id_str" : "1075535245",
      "id" : 1075535245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294868659032178690",
  "text" : "RT @12protons: I now understand why Lloyd's fish tacos are a big deal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294865000613437441",
    "text" : "I now understand why Lloyd's fish tacos are a big deal.",
    "id" : 294865000613437441,
    "created_at" : "2013-01-25 17:51:09 +0000",
    "user" : {
      "name" : "Mark Gatesman",
      "screen_name" : "12protons",
      "protected" : false,
      "id_str" : "1075535245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3150199988\/e4552c8f2ea6f39c83fc3e8ffa51a8c0_normal.png",
      "id" : 1075535245,
      "verified" : false
    }
  },
  "id" : 294868659032178690,
  "created_at" : "2013-01-25 18:05:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bishop",
      "screen_name" : "gnuconsulting",
      "indices" : [ 0, 14 ],
      "id_str" : "15060778",
      "id" : 15060778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294829444646989824",
  "geo" : { },
  "id_str" : "294867355912245249",
  "in_reply_to_user_id" : 15060778,
  "text" : "@gnuconsulting Just saw it! Will get to it.",
  "id" : 294867355912245249,
  "in_reply_to_status_id" : 294829444646989824,
  "created_at" : "2013-01-25 18:00:30 +0000",
  "in_reply_to_screen_name" : "gnuconsulting",
  "in_reply_to_user_id_str" : "15060778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294844882604916738",
  "text" : "Any day I get to use Array#zip is a good day.",
  "id" : 294844882604916738,
  "created_at" : "2013-01-25 16:31:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/DXSBZmrQ",
      "expanded_url" : "http:\/\/www.buffalonews.com\/apps\/pbcs.dll\/article?AID=%2F20130125%2FCITYANDREGION%2F130129487%2F1010",
      "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294826709641994240",
  "text" : "Huge deal for Buffalo and Elmwood Village: http:\/\/t.co\/DXSBZmrQ",
  "id" : 294826709641994240,
  "created_at" : "2013-01-25 15:18:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik  Hodne",
      "screen_name" : "henrikhodne",
      "indices" : [ 0, 12 ],
      "id_str" : "14746604",
      "id" : 14746604
    }, {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 13, 22 ],
      "id_str" : "252481460",
      "id" : 252481460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294668874094366720",
  "geo" : { },
  "id_str" : "294671174066130944",
  "in_reply_to_user_id" : 14746604,
  "text" : "@henrikhodne @travisci does this support RubyMotion?!",
  "id" : 294671174066130944,
  "in_reply_to_status_id" : 294668874094366720,
  "created_at" : "2013-01-25 05:00:57 +0000",
  "in_reply_to_screen_name" : "henrikhodne",
  "in_reply_to_user_id_str" : "14746604",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Staple",
      "screen_name" : "AndyStaple",
      "indices" : [ 0, 11 ],
      "id_str" : "34352961",
      "id" : 34352961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294656602198380546",
  "geo" : { },
  "id_str" : "294661707324878848",
  "in_reply_to_user_id" : 34352961,
  "text" : "@AndyStaple thanks! How\u2019d it go?",
  "id" : 294661707324878848,
  "in_reply_to_status_id" : 294656602198380546,
  "created_at" : "2013-01-25 04:23:20 +0000",
  "in_reply_to_screen_name" : "AndyStaple",
  "in_reply_to_user_id_str" : "34352961",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294490144264814593",
  "geo" : { },
  "id_str" : "294491185345622016",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff Congrats!",
  "id" : 294491185345622016,
  "in_reply_to_status_id" : 294490144264814593,
  "created_at" : "2013-01-24 17:05:44 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294282128684896257",
  "geo" : { },
  "id_str" : "294292037371559936",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden humans be human",
  "id" : 294292037371559936,
  "in_reply_to_status_id" : 294282128684896257,
  "created_at" : "2013-01-24 03:54:24 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294284273060569089",
  "geo" : { },
  "id_str" : "294291934200094720",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain it\u2019s like this every day. For me.",
  "id" : 294291934200094720,
  "in_reply_to_status_id" : 294284273060569089,
  "created_at" : "2013-01-24 03:53:59 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/jr2J6sHf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WPKGidTdyds",
      "display_url" : "youtube.com\/watch?v=WPKGid\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "294277436529598464",
  "geo" : { },
  "id_str" : "294278968000016384",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed This is better: http:\/\/t.co\/jr2J6sHf",
  "id" : 294278968000016384,
  "in_reply_to_status_id" : 294277436529598464,
  "created_at" : "2013-01-24 03:02:28 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/KPb6eYsq",
      "expanded_url" : "http:\/\/harthur.wordpress.com\/2013\/01\/24\/771\/",
      "display_url" : "harthur.wordpress.com\/2013\/01\/24\/771\/"
    } ]
  },
  "geo" : { },
  "id_str" : "294278617909841922",
  "text" : "Stuff like this is why people don't contribute to open source: http:\/\/t.co\/KPb6eYsq",
  "id" : 294278617909841922,
  "created_at" : "2013-01-24 03:01:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Starkman",
      "screen_name" : "MarkStarkman",
      "indices" : [ 0, 13 ],
      "id_str" : "139263008",
      "id" : 139263008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294218124927062016",
  "geo" : { },
  "id_str" : "294269053999128578",
  "in_reply_to_user_id" : 139263008,
  "text" : "@MarkStarkman Thanks!",
  "id" : 294269053999128578,
  "in_reply_to_status_id" : 294218124927062016,
  "created_at" : "2013-01-24 02:23:04 +0000",
  "in_reply_to_screen_name" : "MarkStarkman",
  "in_reply_to_user_id_str" : "139263008",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 11, 19 ],
      "id_str" : "900882032",
      "id" : 900882032
    }, {
      "name" : "Frank Gourmet Dogs",
      "screen_name" : "FindFrankNow",
      "indices" : [ 24, 37 ],
      "id_str" : "843961676",
      "id" : 843961676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/hgfYT1rs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "294202787879874560",
  "text" : "New trucks @theBMFT and @FindFrankNow added to http:\/\/t.co\/hgfYT1rs - Welcome!",
  "id" : 294202787879874560,
  "created_at" : "2013-01-23 21:59:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294184921734463488",
  "text" : "OH \"see for every techcrunch article about brogramming doggy sex, there is someone building really cool shit\"",
  "id" : 294184921734463488,
  "created_at" : "2013-01-23 20:48:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 50, 59 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/j8uGXZjf",
      "expanded_url" : "https:\/\/guestlistapp.com\/events\/145317",
      "display_url" : "guestlistapp.com\/events\/145317"
    } ]
  },
  "geo" : { },
  "id_str" : "294175989464973312",
  "text" : "RT @bcardarella: OpenHack next Thursday hosted at @DockYard! https:\/\/t.co\/j8uGXZjf Everybody welcome, please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DockYard",
        "screen_name" : "DockYard",
        "indices" : [ 33, 42 ],
        "id_str" : "18545770",
        "id" : 18545770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 65 ],
        "url" : "https:\/\/t.co\/j8uGXZjf",
        "expanded_url" : "https:\/\/guestlistapp.com\/events\/145317",
        "display_url" : "guestlistapp.com\/events\/145317"
      } ]
    },
    "geo" : { },
    "id_str" : "294175709017026560",
    "text" : "OpenHack next Thursday hosted at @DockYard! https:\/\/t.co\/j8uGXZjf Everybody welcome, please RT",
    "id" : 294175709017026560,
    "created_at" : "2013-01-23 20:12:09 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 294175989464973312,
  "created_at" : "2013-01-23 20:13:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/mwIiX7Sp",
      "expanded_url" : "http:\/\/trash.io",
      "display_url" : "trash.io"
    } ]
  },
  "geo" : { },
  "id_str" : "294167086303948801",
  "text" : "Just GIMME PIZZA'd http:\/\/t.co\/mwIiX7Sp. What is this I don't even.",
  "id" : 294167086303948801,
  "created_at" : "2013-01-23 19:37:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Han",
      "screen_name" : "knowtheory",
      "indices" : [ 0, 11 ],
      "id_str" : "14227842",
      "id" : 14227842
    }, {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 12, 23 ],
      "id_str" : "14284130",
      "id" : 14284130
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 24, 35 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Elad Meidar",
      "screen_name" : "eladmeidar",
      "indices" : [ 58, 69 ],
      "id_str" : "16815376",
      "id" : 16815376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294161932980736002",
  "geo" : { },
  "id_str" : "294166530973892608",
  "in_reply_to_user_id" : 14227842,
  "text" : "@knowtheory @hiro_asari @ashedryden WTF is this bullshit, @eladmeidar ?",
  "id" : 294166530973892608,
  "in_reply_to_status_id" : 294161932980736002,
  "created_at" : "2013-01-23 19:35:40 +0000",
  "in_reply_to_screen_name" : "knowtheory",
  "in_reply_to_user_id_str" : "14227842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 12, 20 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294162028107554817",
  "geo" : { },
  "id_str" : "294162354596376576",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @noahhlo Yes!!",
  "id" : 294162354596376576,
  "in_reply_to_status_id" : 294162028107554817,
  "created_at" : "2013-01-23 19:19:05 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294155013377376256",
  "geo" : { },
  "id_str" : "294155116813119489",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr I just emailed support@ about this. There's a lot of them.",
  "id" : 294155116813119489,
  "in_reply_to_status_id" : 294155013377376256,
  "created_at" : "2013-01-23 18:50:19 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 33, 40 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 69 ],
      "url" : "https:\/\/t.co\/zEmFS4Am",
      "expanded_url" : "https:\/\/github.com\/mosedykes\/mosedykes.github.com",
      "display_url" : "github.com\/mosedykes\/mose\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294154165662384128",
  "text" : "Oh cool I found spam accounts on @github pages: https:\/\/t.co\/zEmFS4Am",
  "id" : 294154165662384128,
  "created_at" : "2013-01-23 18:46:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 33 ],
      "url" : "https:\/\/t.co\/m9uafzrO",
      "expanded_url" : "https:\/\/github.com\/search?q=Gay&type=Code&ref=searchresults",
      "display_url" : "github.com\/search?q=Gay&t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "294153769892052993",
  "geo" : { },
  "id_str" : "294153943192326144",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden https:\/\/t.co\/m9uafzrO is a lot worse",
  "id" : 294153943192326144,
  "in_reply_to_status_id" : 294153769892052993,
  "created_at" : "2013-01-23 18:45:39 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294151757687312384",
  "geo" : { },
  "id_str" : "294153318723362816",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Not filtering it by Ruby is much worse. I'm sure there's even worse searches we could do.",
  "id" : 294153318723362816,
  "in_reply_to_status_id" : 294151757687312384,
  "created_at" : "2013-01-23 18:43:10 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 48 ],
      "url" : "https:\/\/t.co\/1ULPw79P",
      "expanded_url" : "https:\/\/github.com\/search?q=Gay+extension%3Arb&type=Code&ref=searchresults",
      "display_url" : "github.com\/search?q=Gay+e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294151489914540032",
  "text" : "Presented without comment: https:\/\/t.co\/1ULPw79P",
  "id" : 294151489914540032,
  "created_at" : "2013-01-23 18:35:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 0, 9 ],
      "id_str" : "876930312",
      "id" : 876930312
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294133895564251136",
  "geo" : { },
  "id_str" : "294139168349618176",
  "in_reply_to_user_id" : 876930312,
  "text" : "@BfloFRED @coworkbuffalo Thanks!",
  "id" : 294139168349618176,
  "in_reply_to_status_id" : 294133895564251136,
  "created_at" : "2013-01-23 17:46:57 +0000",
  "in_reply_to_screen_name" : "BfloFRED",
  "in_reply_to_user_id_str" : "876930312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 3, 12 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294138948735860737",
  "text" : "RT @ubuwaits: \u201CLook at all the cool things white people in SF will be able to do!\u201D \u2014the documentary about interaction design I just watched",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294138850819858432",
    "text" : "\u201CLook at all the cool things white people in SF will be able to do!\u201D \u2014the documentary about interaction design I just watched",
    "id" : 294138850819858432,
    "created_at" : "2013-01-23 17:45:41 +0000",
    "user" : {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "protected" : false,
      "id_str" : "6980232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558939000488996864\/n0Z8lT5p_normal.jpeg",
      "id" : 6980232,
      "verified" : false
    }
  },
  "id" : 294138948735860737,
  "created_at" : "2013-01-23 17:46:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 0, 9 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294121484744527872",
  "geo" : { },
  "id_str" : "294129475103367169",
  "in_reply_to_user_id" : 876930312,
  "text" : "@BfloFRED Replied, sorry about that.",
  "id" : 294129475103367169,
  "in_reply_to_status_id" : 294121484744527872,
  "created_at" : "2013-01-23 17:08:26 +0000",
  "in_reply_to_screen_name" : "BfloFRED",
  "in_reply_to_user_id_str" : "876930312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294090900034945024",
  "geo" : { },
  "id_str" : "294107204494184448",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded what?!",
  "id" : 294107204494184448,
  "in_reply_to_status_id" : 294090900034945024,
  "created_at" : "2013-01-23 15:39:56 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Chupp",
      "screen_name" : "semanticart",
      "indices" : [ 0, 12 ],
      "id_str" : "14212434",
      "id" : 14212434
    }, {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 13, 20 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/l93Np1KT",
      "expanded_url" : "http:\/\/howfuckedisthet.com\/green\/",
      "display_url" : "howfuckedisthet.com\/green\/"
    } ]
  },
  "in_reply_to_status_id_str" : "294086387056123905",
  "geo" : { },
  "id_str" : "294087119952039936",
  "in_reply_to_user_id" : 14212434,
  "text" : "@semanticart @jayroh http:\/\/t.co\/l93Np1KT",
  "id" : 294087119952039936,
  "in_reply_to_status_id" : 294086387056123905,
  "created_at" : "2013-01-23 14:20:07 +0000",
  "in_reply_to_screen_name" : "semanticart",
  "in_reply_to_user_id_str" : "14212434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/zxX6dPmQ",
      "expanded_url" : "http:\/\/www.thewho.net\/whotabs\/gear\/guitar\/marshallstack.html",
      "display_url" : "thewho.net\/whotabs\/gear\/g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "293750895403999233",
  "geo" : { },
  "id_str" : "294080684794990595",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed also they practically invented the Marshall Stack - JUST TO BE LOUD http:\/\/t.co\/zxX6dPmQ",
  "id" : 294080684794990595,
  "in_reply_to_status_id" : 293750895403999233,
  "created_at" : "2013-01-23 13:54:33 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/5moSiY0W",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=WT5uAIPFft8&desktop_uri=%2Fwatch%3Fv%3DWT5uAIPFft8",
      "display_url" : "m.youtube.com\/#\/watch?v=WT5u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "293750895403999233",
  "geo" : { },
  "id_str" : "294079813604503552",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed how can Keith Moon not be your spirit animal. http:\/\/t.co\/5moSiY0W",
  "id" : 294079813604503552,
  "in_reply_to_status_id" : 293750895403999233,
  "created_at" : "2013-01-23 13:51:05 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 0, 11 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293750895403999233",
  "geo" : { },
  "id_str" : "294078969765064706",
  "in_reply_to_user_id" : 38408851,
  "text" : "@Jonplussed wat",
  "id" : 294078969765064706,
  "in_reply_to_status_id" : 293750895403999233,
  "created_at" : "2013-01-23 13:47:44 +0000",
  "in_reply_to_screen_name" : "Jonplussed",
  "in_reply_to_user_id_str" : "38408851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/tBWsaYh2",
      "expanded_url" : "http:\/\/actualfacebookgraphsearches.tumblr.com\/",
      "display_url" : "actualfacebookgraphsearches.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "293906186401636352",
  "text" : "\u201CSingle women who live nearby and who are interested in men and like Getting Drunk\u201D - http:\/\/t.co\/tBWsaYh2",
  "id" : 293906186401636352,
  "created_at" : "2013-01-23 02:21:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/I6sZcKqS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=TLN_ka1ZSDg",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293904988785221632",
  "text" : "Apparently there was an episode of Dexter's Lab filled with intentional bleeps - http:\/\/t.co\/I6sZcKqS",
  "id" : 293904988785221632,
  "created_at" : "2013-01-23 02:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293901678468530177",
  "geo" : { },
  "id_str" : "293903781832298498",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones youtube video linked in the presentation didn't.",
  "id" : 293903781832298498,
  "in_reply_to_status_id" : 293901678468530177,
  "created_at" : "2013-01-23 02:11:36 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 36, 48 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/omnbKEWP",
      "expanded_url" : "http:\/\/www.bravemule.com\/li54\/",
      "display_url" : "bravemule.com\/li54\/"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/X1aFIHYK",
      "expanded_url" : "http:\/\/www.bravemule.com\/fe54\/",
      "display_url" : "bravemule.com\/fe54\/"
    } ]
  },
  "geo" : { },
  "id_str" : "293902845428772864",
  "text" : "The Bravemule finale is coming from @starguarded soon - so worth diving into this great story. http:\/\/t.co\/omnbKEWP http:\/\/t.co\/X1aFIHYK",
  "id" : 293902845428772864,
  "created_at" : "2013-01-23 02:07:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293900432508612608",
  "geo" : { },
  "id_str" : "293900874038792192",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded pumped!",
  "id" : 293900874038792192,
  "in_reply_to_status_id" : 293900432508612608,
  "created_at" : "2013-01-23 02:00:03 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293888184771813377",
  "geo" : { },
  "id_str" : "293900677455953920",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones It's pronounced \"weiner\" ? Are you fucking kidding me?",
  "id" : 293900677455953920,
  "in_reply_to_status_id" : 293888184771813377,
  "created_at" : "2013-01-23 01:59:16 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293886831773220865",
  "geo" : { },
  "id_str" : "293887601654501376",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones latest xcode\/safari remote debugging has been amazing.",
  "id" : 293887601654501376,
  "in_reply_to_status_id" : 293886831773220865,
  "created_at" : "2013-01-23 01:07:19 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob martin",
      "screen_name" : "version2beta",
      "indices" : [ 0, 13 ],
      "id_str" : "9431062",
      "id" : 9431062
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 14, 19 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293830001969754112",
  "geo" : { },
  "id_str" : "293864459330527233",
  "in_reply_to_user_id" : 9431062,
  "text" : "@version2beta @avdi this is sad. I also had to google MKE. \u00B4\u0434` ;",
  "id" : 293864459330527233,
  "in_reply_to_status_id" : 293830001969754112,
  "created_at" : "2013-01-22 23:35:21 +0000",
  "in_reply_to_screen_name" : "version2beta",
  "in_reply_to_user_id_str" : "9431062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marxist Tarot Card",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293817130510610432",
  "geo" : { },
  "id_str" : "293862525404078081",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I\u2019m sure there are many gems that do this kind of thing. So what?",
  "id" : 293862525404078081,
  "in_reply_to_status_id" : 293817130510610432,
  "created_at" : "2013-01-22 23:27:40 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "12 Grain",
      "screen_name" : "12grainstudio",
      "indices" : [ 0, 14 ],
      "id_str" : "15650314",
      "id" : 15650314
    }, {
      "name" : "Tweet Historian",
      "screen_name" : "thistorian",
      "indices" : [ 45, 56 ],
      "id_str" : "1031730690",
      "id" : 1031730690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293838920750338048",
  "geo" : { },
  "id_str" : "293839079399895041",
  "in_reply_to_user_id" : 15650314,
  "text" : "@12grainstudio careful, you're sounding like @thistorian",
  "id" : 293839079399895041,
  "in_reply_to_status_id" : 293838920750338048,
  "created_at" : "2013-01-22 21:54:30 +0000",
  "in_reply_to_screen_name" : "12grainstudio",
  "in_reply_to_user_id_str" : "15650314",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 32, 43 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/NX00v6W0",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/gaming\/comments\/172gas\/when_i_get_bored_in_the_sims_i_start_doing\/c81n99a",
      "display_url" : "reddit.com\/r\/gaming\/comme\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "293834747350753280",
  "geo" : { },
  "id_str" : "293835025315659777",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Seriously. Is there @MattBinder Bat Signal yet? http:\/\/t.co\/NX00v6W0",
  "id" : 293835025315659777,
  "in_reply_to_status_id" : 293834747350753280,
  "created_at" : "2013-01-22 21:38:23 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293834555666857984",
  "text" : "Top post on Reddit right now - someone recreated a plantation complete with slaves in the Sims. Stop this internet train, I want to get off.",
  "id" : 293834555666857984,
  "created_at" : "2013-01-22 21:36:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/QVvFVbgC",
      "expanded_url" : "http:\/\/gun.io\/",
      "display_url" : "gun.io"
    } ]
  },
  "geo" : { },
  "id_str" : "293830475368247296",
  "text" : "&gt;&gt;&gt;&gt;&gt;&gt;&gt;:[ http:\/\/t.co\/QVvFVbgC",
  "id" : 293830475368247296,
  "created_at" : "2013-01-22 21:20:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Refresh Rochester",
      "screen_name" : "refreshroc",
      "indices" : [ 0, 11 ],
      "id_str" : "50738786",
      "id" : 50738786
    }, {
      "name" : "BfloFRED",
      "screen_name" : "BfloFRED",
      "indices" : [ 17, 26 ],
      "id_str" : "876930312",
      "id" : 876930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293808155748622336",
  "geo" : { },
  "id_str" : "293808998904393728",
  "in_reply_to_user_id" : 50738786,
  "text" : "@refreshroc Ping @BfloFRED!",
  "id" : 293808998904393728,
  "in_reply_to_status_id" : 293808155748622336,
  "created_at" : "2013-01-22 19:54:58 +0000",
  "in_reply_to_screen_name" : "refreshroc",
  "in_reply_to_user_id_str" : "50738786",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 36, 47 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/VvK98Eaz",
      "expanded_url" : "http:\/\/i.imgur.com\/hrP7ENv.gif",
      "display_url" : "i.imgur.com\/hrP7ENv.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "293799511388729344",
  "geo" : { },
  "id_str" : "293799727634448384",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat http:\/\/t.co\/VvK98Eaz (via @joanofdark)",
  "id" : 293799727634448384,
  "in_reply_to_status_id" : 293799511388729344,
  "created_at" : "2013-01-22 19:18:08 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 17, 29 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LX1Y1ktL",
      "expanded_url" : "http:\/\/www.growtedxbuffalo.com\/",
      "display_url" : "growtedxbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "293752619762065409",
  "text" : "RT @kevinpurdy: .@TEDxBuffalo wants to grow in size &amp; diversity in 2013. Need a trip, and cash, to get there. Can you help? http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 1, 13 ],
        "id_str" : "140515765",
        "id" : 140515765
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/LX1Y1ktL",
        "expanded_url" : "http:\/\/www.growtedxbuffalo.com\/",
        "display_url" : "growtedxbuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "293752517580447745",
    "text" : ".@TEDxBuffalo wants to grow in size &amp; diversity in 2013. Need a trip, and cash, to get there. Can you help? http:\/\/t.co\/LX1Y1ktL",
    "id" : 293752517580447745,
    "created_at" : "2013-01-22 16:10:32 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 293752619762065409,
  "created_at" : "2013-01-22 16:10:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 3, 9 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/7oIyul55",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=5097592",
      "display_url" : "news.ycombinator.com\/item?id=5097592"
    } ]
  },
  "geo" : { },
  "id_str" : "293750358029791232",
  "text" : "RT @javan: \"Basecamp: the app any web developer should be able to create themselves in a week or two.\" http:\/\/t.co\/7oIyul55",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/7oIyul55",
        "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=5097592",
        "display_url" : "news.ycombinator.com\/item?id=5097592"
      } ]
    },
    "geo" : { },
    "id_str" : "293749640942215168",
    "text" : "\"Basecamp: the app any web developer should be able to create themselves in a week or two.\" http:\/\/t.co\/7oIyul55",
    "id" : 293749640942215168,
    "created_at" : "2013-01-22 15:59:06 +0000",
    "user" : {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "protected" : false,
      "id_str" : "1679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526722729123143680\/0-ppDKP__normal.jpeg",
      "id" : 1679,
      "verified" : false
    }
  },
  "id" : 293750358029791232,
  "created_at" : "2013-01-22 16:01:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293746265332785152",
  "text" : "Things no one says, ever: \"I can't wait to see what Hacker News thinks about this!\"",
  "id" : 293746265332785152,
  "created_at" : "2013-01-22 15:45:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/hfRdKRnE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=C-eYIeUPD0s&list=UUzk0m5Ibzv-JDJHRrNNbGyw&index=104",
      "display_url" : "youtube.com\/watch?v=C-eYIe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293742311752486913",
  "text" : "Current status: http:\/\/t.co\/hfRdKRnE",
  "id" : 293742311752486913,
  "created_at" : "2013-01-22 15:29:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/lIM6wJjR",
      "expanded_url" : "http:\/\/www.dev.gd\/20130122-the-joys-of-having-a-forever-project.html",
      "display_url" : "dev.gd\/20130122-the-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293727069475598336",
  "text" : "The joys (or my guilt) of a Forever Project: http:\/\/t.co\/lIM6wJjR",
  "id" : 293727069475598336,
  "created_at" : "2013-01-22 14:29:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 27, 38 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293709631216295936",
  "geo" : { },
  "id_str" : "293713289538584580",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante what. I\u2019m sure @shellscape will take some",
  "id" : 293713289538584580,
  "in_reply_to_status_id" : 293709631216295936,
  "created_at" : "2013-01-22 13:34:39 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293563097807982592",
  "geo" : { },
  "id_str" : "293563498645032962",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule :( no idea what you are complaining about but this much hate can\u2019t be healthy.",
  "id" : 293563498645032962,
  "in_reply_to_status_id" : 293563097807982592,
  "created_at" : "2013-01-22 03:39:26 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 0, 13 ],
      "id_str" : "14255877",
      "id" : 14255877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293560692131385344",
  "geo" : { },
  "id_str" : "293561030225842176",
  "in_reply_to_user_id" : 14255877,
  "text" : "@justinxreese wow, damn. I\u2019d imagine &gt; 20 is hectic!",
  "id" : 293561030225842176,
  "in_reply_to_status_id" : 293560692131385344,
  "created_at" : "2013-01-22 03:29:38 +0000",
  "in_reply_to_screen_name" : "justinxreese",
  "in_reply_to_user_id_str" : "14255877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Justin Reese",
      "screen_name" : "justinxreese",
      "indices" : [ 15, 28 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 29, 37 ],
      "id_str" : "34175404",
      "id" : 34175404
    }, {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 38, 50 ],
      "id_str" : "906546798",
      "id" : 906546798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293557820077514752",
  "geo" : { },
  "id_str" : "293560282352082944",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @justinxreese @whit537 @OpenHackPGH nametags too! How\u2019d it go? (And how were intros?)",
  "id" : 293560282352082944,
  "in_reply_to_status_id" : 293557820077514752,
  "created_at" : "2013-01-22 03:26:40 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293559617361965057",
  "geo" : { },
  "id_str" : "293559988947922944",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson damn!",
  "id" : 293559988947922944,
  "in_reply_to_status_id" : 293559617361965057,
  "created_at" : "2013-01-22 03:25:30 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 7, 17 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293553407749394434",
  "text" : "Whelp, @aquaranto is not a blond anymore. She\u2019s a\u2026purple?",
  "id" : 293553407749394434,
  "created_at" : "2013-01-22 02:59:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/99Olw8PV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ba7rRfKIHxU&feature=fvwp&NR=1",
      "display_url" : "youtube.com\/watch?v=ba7rRf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293541071500222466",
  "text" : "Current status: http:\/\/t.co\/99Olw8PV",
  "id" : 293541071500222466,
  "created_at" : "2013-01-22 02:10:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 3, 10 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 21, 32 ],
      "id_str" : "426455861",
      "id" : 426455861
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 37, 47 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403794589487104",
  "text" : "RT @gabebw: Based on @cadeparade and @aquaranto, developers are like werewolves: after a year of being married to one...YOU BECOME ONE d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lindsay Cade",
        "screen_name" : "cadeparade",
        "indices" : [ 9, 20 ],
        "id_str" : "426455861",
        "id" : 426455861
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 25, 35 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293228418001166336",
    "text" : "Based on @cadeparade and @aquaranto, developers are like werewolves: after a year of being married to one...YOU BECOME ONE dun dun dunnnn",
    "id" : 293228418001166336,
    "created_at" : "2013-01-21 05:27:57 +0000",
    "user" : {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "protected" : false,
      "id_str" : "224887329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522042513951977472\/vthKCPDr_normal.jpeg",
      "id" : 224887329,
      "verified" : false
    }
  },
  "id" : 293403794589487104,
  "created_at" : "2013-01-21 17:04:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    }, {
      "name" : "Noel Rappin",
      "screen_name" : "noelrap",
      "indices" : [ 10, 18 ],
      "id_str" : "1515231",
      "id" : 1515231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293403242904293377",
  "geo" : { },
  "id_str" : "293403512723894272",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems @noelrap They just hate Ruby on proggit.",
  "id" : 293403512723894272,
  "in_reply_to_status_id" : 293403242904293377,
  "created_at" : "2013-01-21 17:03:43 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293395421324271616",
  "geo" : { },
  "id_str" : "293397297121878016",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape sick :(",
  "id" : 293397297121878016,
  "in_reply_to_status_id" : 293395421324271616,
  "created_at" : "2013-01-21 16:39:01 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293171701846507520",
  "geo" : { },
  "id_str" : "293176762202996736",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems WC3 doesn\u2019t work on lion (\u3000\uFF9F\u0434\uFF9F)",
  "id" : 293176762202996736,
  "in_reply_to_status_id" : 293171701846507520,
  "created_at" : "2013-01-21 02:02:41 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Campbell",
      "screen_name" : "Colin_Campbell",
      "indices" : [ 3, 18 ],
      "id_str" : "16618689",
      "id" : 16618689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293174178721431553",
  "text" : "RT @Colin_Campbell: iOS architecture, where MVC stands for Massive View Controller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293167951132098560",
    "text" : "iOS architecture, where MVC stands for Massive View Controller",
    "id" : 293167951132098560,
    "created_at" : "2013-01-21 01:27:41 +0000",
    "user" : {
      "name" : "Colin Campbell",
      "screen_name" : "Colin_Campbell",
      "protected" : false,
      "id_str" : "16618689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724751787\/393335_10151035296045394_579315393_21909384_190914705_n_normal.jpg",
      "id" : 16618689,
      "verified" : false
    }
  },
  "id" : 293174178721431553,
  "created_at" : "2013-01-21 01:52:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293157719282696192",
  "text" : "Ok, I like one commercial - the one where a dude is rocking out to Fly by Night. Apparently this is an ad, not a snippet from my daily life.",
  "id" : 293157719282696192,
  "created_at" : "2013-01-21 00:47:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha\u0142 Po\u0142tyn",
      "screen_name" : "holek_",
      "indices" : [ 0, 7 ],
      "id_str" : "75356636",
      "id" : 75356636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293015707388608512",
  "geo" : { },
  "id_str" : "293155583459221504",
  "in_reply_to_user_id" : 75356636,
  "text" : "@holek_ they were killing performance since most of that data was in Redis. Haven\u2019t had the time it energy to fix it.",
  "id" : 293155583459221504,
  "in_reply_to_status_id" : 293015707388608512,
  "created_at" : "2013-01-21 00:38:32 +0000",
  "in_reply_to_screen_name" : "holek_",
  "in_reply_to_user_id_str" : "75356636",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Crozat",
      "screen_name" : "benjamincrozat",
      "indices" : [ 0, 15 ],
      "id_str" : "71785320",
      "id" : 71785320
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 16, 28 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293154794133155840",
  "geo" : { },
  "id_str" : "293154955488010241",
  "in_reply_to_user_id" : 71785320,
  "text" : "@benjamincrozat @SteveStreza oh snap",
  "id" : 293154955488010241,
  "in_reply_to_status_id" : 293154794133155840,
  "created_at" : "2013-01-21 00:36:02 +0000",
  "in_reply_to_screen_name" : "benjamincrozat",
  "in_reply_to_user_id_str" : "71785320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Benjamin Crozat",
      "screen_name" : "benjamincrozat",
      "indices" : [ 13, 28 ],
      "id_str" : "71785320",
      "id" : 71785320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293149532643024897",
  "geo" : { },
  "id_str" : "293154670443114496",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza @benjamincrozat holy crap. Can you get that on your device or simulator only?",
  "id" : 293154670443114496,
  "in_reply_to_status_id" : 293149532643024897,
  "created_at" : "2013-01-21 00:34:54 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293128241915523072",
  "text" : "Worst part of being sick: terrible car commercials. And light beer. And insurance. Actually, all commercials.",
  "id" : 293128241915523072,
  "created_at" : "2013-01-20 22:49:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293047950404382720",
  "geo" : { },
  "id_str" : "293054928832851969",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair there\u2019s a gemset plugin for rbenv.",
  "id" : 293054928832851969,
  "in_reply_to_status_id" : 293047950404382720,
  "created_at" : "2013-01-20 17:58:34 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 7, 17 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293022620906041344",
  "text" : "&lt;3 \u201C@aquaranto: The wind was loud and scary. Geddy decided it was time to poop. Hello 3am. I\u2019d love to go outside\u201D",
  "id" : 293022620906041344,
  "created_at" : "2013-01-20 15:50:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Brown",
      "screen_name" : "BrownWebDesign",
      "indices" : [ 0, 15 ],
      "id_str" : "18452956",
      "id" : 18452956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293017937583951873",
  "geo" : { },
  "id_str" : "293022272820760576",
  "in_reply_to_user_id" : 18452956,
  "text" : "@BrownWebDesign crap! Get better.",
  "id" : 293022272820760576,
  "in_reply_to_status_id" : 293017937583951873,
  "created_at" : "2013-01-20 15:48:48 +0000",
  "in_reply_to_screen_name" : "BrownWebDesign",
  "in_reply_to_user_id_str" : "18452956",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sickbuddies",
      "indices" : [ 17, 29 ]
    }, {
      "text" : "madeuphashtags",
      "indices" : [ 30, 45 ]
    }, {
      "text" : "fml",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293013331311206401",
  "geo" : { },
  "id_str" : "293022225328652288",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench woo #sickbuddies #madeuphashtags #fml",
  "id" : 293022225328652288,
  "in_reply_to_status_id" : 293013331311206401,
  "created_at" : "2013-01-20 15:48:37 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293021887095795713",
  "text" : "Sabres jersey for the first time this year. It counts as a hoodie when sick right?",
  "id" : 293021887095795713,
  "created_at" : "2013-01-20 15:47:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293012827411718145",
  "text" : "Sick. Fuck.",
  "id" : 293012827411718145,
  "created_at" : "2013-01-20 15:11:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292827989505363968",
  "geo" : { },
  "id_str" : "292842930920624129",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton @withloudhands oooh, he\u2019ll save children but not british children",
  "id" : 292842930920624129,
  "in_reply_to_status_id" : 292827989505363968,
  "created_at" : "2013-01-20 03:56:10 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292814625337131009",
  "geo" : { },
  "id_str" : "292815145112047616",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton on a horse made of crystal he patrols the land",
  "id" : 292815145112047616,
  "in_reply_to_status_id" : 292814625337131009,
  "created_at" : "2013-01-20 02:05:45 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292814222411329539",
  "text" : "Washington, Washington.",
  "id" : 292814222411329539,
  "created_at" : "2013-01-20 02:02:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292777790795829248",
  "geo" : { },
  "id_str" : "292779639254970368",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski does she throw poop?",
  "id" : 292779639254970368,
  "in_reply_to_status_id" : 292777790795829248,
  "created_at" : "2013-01-19 23:44:40 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292759497938698240",
  "geo" : { },
  "id_str" : "292762560317493248",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark ((((\uFF1B\uFF9F\u0414\uFF9F)))))))",
  "id" : 292762560317493248,
  "in_reply_to_status_id" : 292759497938698240,
  "created_at" : "2013-01-19 22:36:48 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 14, 22 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 23, 32 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292367803795767296",
  "geo" : { },
  "id_str" : "292368175545331712",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons @noahhlo @shildner How about this: Dataline, with Dr. Noah and Shaun. Call in with your data problems. Lightning round too.",
  "id" : 292368175545331712,
  "in_reply_to_status_id" : 292367803795767296,
  "created_at" : "2013-01-18 20:29:39 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 9, 18 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292367523310100480",
  "geo" : { },
  "id_str" : "292367690931240961",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo @shildner Immediate subscribe.",
  "id" : 292367690931240961,
  "in_reply_to_status_id" : 292367523310100480,
  "created_at" : "2013-01-18 20:27:44 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292350370716479488",
  "text" : "Variable names that are way funnier out of context: HAMBURGER_SPACE",
  "id" : 292350370716479488,
  "created_at" : "2013-01-18 19:18:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292346802190028800",
  "text" : "`brew cleanup` and save yourself some space.",
  "id" : 292346802190028800,
  "created_at" : "2013-01-18 19:04:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/292299211515506688\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/KC3pFNZs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA50lY8CMAAyqHJ.png",
      "id_str" : "292299211523895296",
      "id" : 292299211523895296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA50lY8CMAAyqHJ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/KC3pFNZs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292299211515506688",
  "text" : "Settings &gt; General &gt; Keyboards &gt; Japanese Kana. Then hit ^_^. This is all baked into iOS. http:\/\/t.co\/KC3pFNZs",
  "id" : 292299211515506688,
  "created_at" : "2013-01-18 15:55:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/292144316795715584\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/xFm7Rvte",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA3ntVICAAAjEcS.png",
      "id_str" : "292144316799909888",
      "id" : 292144316799909888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA3ntVICAAAjEcS.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/xFm7Rvte"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292144316795715584",
  "text" : "You can play as Finn in jtpck. That is all. http:\/\/t.co\/xFm7Rvte",
  "id" : 292144316795715584,
  "created_at" : "2013-01-18 05:40:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 7, 19 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292129304387665920",
  "geo" : { },
  "id_str" : "292129443793735680",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @therealadam yes! I couldn\u2019t remember the name.",
  "id" : 292129443793735680,
  "in_reply_to_status_id" : 292129304387665920,
  "created_at" : "2013-01-18 04:41:01 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292102254205497344",
  "geo" : { },
  "id_str" : "292107473161170944",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison sure! nick [at] quaran.to",
  "id" : 292107473161170944,
  "in_reply_to_status_id" : 292102254205497344,
  "created_at" : "2013-01-18 03:13:43 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 72 ],
      "url" : "https:\/\/t.co\/Zx73urDX",
      "expanded_url" : "https:\/\/gist.github.com\/4562056",
      "display_url" : "gist.github.com\/4562056"
    } ]
  },
  "geo" : { },
  "id_str" : "292107419004325889",
  "text" : "Published my Monorail custom game mode for Halo 4: https:\/\/t.co\/Zx73urDX Try it out!",
  "id" : 292107419004325889,
  "created_at" : "2013-01-18 03:13:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292094931479187457",
  "text" : "Someone just gave me a bitcookie?",
  "id" : 292094931479187457,
  "created_at" : "2013-01-18 02:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292094728906887170",
  "text" : "Is Minecraft for 360 worth it? Can you play with folks using the PC version?",
  "id" : 292094728906887170,
  "created_at" : "2013-01-18 02:23:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292093798962569218",
  "geo" : { },
  "id_str" : "292094411809107968",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage I agree, and it\u2019s not a criticism of recent stuff- just an observation. It\u2019s harder to be public :)",
  "id" : 292094411809107968,
  "in_reply_to_status_id" : 292093798962569218,
  "created_at" : "2013-01-18 02:21:49 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 8, 19 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 52, 63 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292088197020786688",
  "geo" : { },
  "id_str" : "292088463669481472",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @joshsusser No worries! I already talked to @joshsusser about it. I'd much rather conflict with a west coast conf.",
  "id" : 292088463669481472,
  "in_reply_to_status_id" : 292088197020786688,
  "created_at" : "2013-01-18 01:58:11 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292087333099016192",
  "text" : "Be public by default.",
  "id" : 292087333099016192,
  "created_at" : "2013-01-18 01:53:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/tyL7GhDW",
      "expanded_url" : "http:\/\/ahmetalpbalkan.com\/blog\/a-cry-for-help\/",
      "display_url" : "ahmetalpbalkan.com\/blog\/a-cry-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292078239063609344",
  "text" : "Another open source guilt cry for help: http:\/\/t.co\/tyL7GhDW",
  "id" : 292078239063609344,
  "created_at" : "2013-01-18 01:17:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "why the lucky stiff",
      "screen_name" : "_why",
      "indices" : [ 8, 13 ],
      "id_str" : "275198114",
      "id" : 275198114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292067928571011074",
  "text" : "What if @_why reappeared? What if it was at a conference? How awkward would that be? Would he get a standing ovation...for deleting himself?",
  "id" : 292067928571011074,
  "created_at" : "2013-01-18 00:36:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 84, 88 ],
      "id_str" : "16521996",
      "id" : 16521996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/azg2WJoI",
      "expanded_url" : "http:\/\/byfat.xxx\/what-is-opensource-and-why-do-i-feel-so-guilty\/",
      "display_url" : "byfat.xxx\/what-is-openso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292067294811664384",
  "text" : "I'm glad more are talking about guilt and open source - http:\/\/t.co\/azg2WJoI Thanks @fat.",
  "id" : 292067294811664384,
  "created_at" : "2013-01-18 00:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 13, 24 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292037465219403776",
  "text" : "@juliepagano @ashedryden This would smell so gross",
  "id" : 292037465219403776,
  "created_at" : "2013-01-17 22:35:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lockfort",
      "screen_name" : "clockfort",
      "indices" : [ 0, 10 ],
      "id_str" : "16381663",
      "id" : 16381663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292028066534932480",
  "geo" : { },
  "id_str" : "292028181207199744",
  "in_reply_to_user_id" : 16381663,
  "text" : "@clockfort New Star Trek? What?",
  "id" : 292028181207199744,
  "in_reply_to_status_id" : 292028066534932480,
  "created_at" : "2013-01-17 21:58:38 +0000",
  "in_reply_to_screen_name" : "clockfort",
  "in_reply_to_user_id_str" : "16381663",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/RlnV6yxL",
      "expanded_url" : "http:\/\/i190.photobucket.com\/albums\/z35\/royone_bucket\/Princess%20Bride\/mawwiage.jpg",
      "display_url" : "i190.photobucket.com\/albums\/z35\/roy\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291996152809795584",
  "geo" : { },
  "id_str" : "291996742382145536",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @aquaranto Mawwiage. http:\/\/t.co\/RlnV6yxL",
  "id" : 291996742382145536,
  "in_reply_to_status_id" : 291996152809795584,
  "created_at" : "2013-01-17 19:53:43 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291995349873225729",
  "geo" : { },
  "id_str" : "291995825423392768",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto WHY DO HATE AMERICA? THANKS OBAMA",
  "id" : 291995825423392768,
  "in_reply_to_status_id" : 291995349873225729,
  "created_at" : "2013-01-17 19:50:04 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/OAuFvIuE",
      "expanded_url" : "http:\/\/www.animalshirts.net\/eagleshirts\/10-3242.jpg",
      "display_url" : "animalshirts.net\/eagleshirts\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291994591467536385",
  "text" : "I need a shirt like this: http:\/\/t.co\/OAuFvIuE",
  "id" : 291994591467536385,
  "created_at" : "2013-01-17 19:45:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 3, 10 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291981831794999297",
  "text" : "RT @cpytel: I believe students should not be paying for extended training programs, employers should be",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291702358512119808",
    "text" : "I believe students should not be paying for extended training programs, employers should be",
    "id" : 291702358512119808,
    "created_at" : "2013-01-17 00:23:56 +0000",
    "user" : {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "protected" : false,
      "id_str" : "9488922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617210225\/headshot_normal.png",
      "id" : 9488922,
      "verified" : false
    }
  },
  "id" : 291981831794999297,
  "created_at" : "2013-01-17 18:54:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291979641751736320",
  "geo" : { },
  "id_str" : "291980302962810880",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh You guys need to rebase more. wtf.",
  "id" : 291980302962810880,
  "in_reply_to_status_id" : 291979641751736320,
  "created_at" : "2013-01-17 18:48:23 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phillip Bowden",
      "screen_name" : "pbowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2134761",
      "id" : 2134761
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 13, 27 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291979236930097152",
  "text" : "RT @pbowden: @garybernhardt \"UNIX was written at the MULTICS hackathon. Thompson was totally jacked on free Mountain Dew and won some ra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gary Bernhardt",
        "screen_name" : "garybernhardt",
        "indices" : [ 0, 14 ],
        "id_str" : "809685",
        "id" : 809685
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "290614810209579010",
    "geo" : { },
    "id_str" : "290615382656569344",
    "in_reply_to_user_id" : 809685,
    "text" : "@garybernhardt \"UNIX was written at the MULTICS hackathon. Thompson was totally jacked on free Mountain Dew and won some rad door prizes\"",
    "id" : 290615382656569344,
    "in_reply_to_status_id" : 290614810209579010,
    "created_at" : "2013-01-14 00:24:41 +0000",
    "in_reply_to_screen_name" : "garybernhardt",
    "in_reply_to_user_id_str" : "809685",
    "user" : {
      "name" : "Phillip Bowden",
      "screen_name" : "pbowden",
      "protected" : false,
      "id_str" : "2134761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485472807094996993\/MpXJ6d3V_normal.png",
      "id" : 2134761,
      "verified" : false
    }
  },
  "id" : 291979236930097152,
  "created_at" : "2013-01-17 18:44:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291979159650050049",
  "text" : "RT @garybernhardt: Let's pause to remember how lucky we are that Thompson and Ritchie went to a one-month dev bootcamp, then created Uni ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290614810209579010",
    "text" : "Let's pause to remember how lucky we are that Thompson and Ritchie went to a one-month dev bootcamp, then created Unix at a startup weekend.",
    "id" : 290614810209579010,
    "created_at" : "2013-01-14 00:22:24 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 291979159650050049,
  "created_at" : "2013-01-17 18:43:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest W. Durbin III",
      "screen_name" : "EWDurbin",
      "indices" : [ 0, 9 ],
      "id_str" : "14590010",
      "id" : 14590010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291976226355167232",
  "geo" : { },
  "id_str" : "291976446044426244",
  "in_reply_to_user_id" : 14590010,
  "text" : "@EWDurbin WTF?",
  "id" : 291976446044426244,
  "in_reply_to_status_id" : 291976226355167232,
  "created_at" : "2013-01-17 18:33:04 +0000",
  "in_reply_to_screen_name" : "EWDurbin",
  "in_reply_to_user_id_str" : "14590010",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 9, 19 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291797148973023232",
  "geo" : { },
  "id_str" : "291797336005419008",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @jtrupiano not enough piles of money",
  "id" : 291797336005419008,
  "in_reply_to_status_id" : 291797148973023232,
  "created_at" : "2013-01-17 06:41:20 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Whitaker",
      "screen_name" : "GovInTrenches",
      "indices" : [ 0, 14 ],
      "id_str" : "1102678854",
      "id" : 1102678854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291351676613443584",
  "geo" : { },
  "id_str" : "291797149149184000",
  "in_reply_to_user_id" : 10780832,
  "text" : "@GovInTrenches wow, awesome. How did the intros go?",
  "id" : 291797149149184000,
  "in_reply_to_status_id" : 291351676613443584,
  "created_at" : "2013-01-17 06:40:36 +0000",
  "in_reply_to_screen_name" : "CivicWhitaker",
  "in_reply_to_user_id_str" : "10780832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291766296008347648",
  "geo" : { },
  "id_str" : "291767040711196673",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d ryeodhaus",
  "id" : 291767040711196673,
  "in_reply_to_status_id" : 291766296008347648,
  "created_at" : "2013-01-17 04:40:57 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291739078490210304",
  "text" : "The lights never get enough credit.",
  "id" : 291739078490210304,
  "created_at" : "2013-01-17 02:49:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/291736027452801025\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/6ZsouoNl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAx0Xw0CAAA3mo-.jpg",
      "id_str" : "291736027461189632",
      "id" : 291736027461189632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAx0Xw0CAAA3mo-.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6ZsouoNl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291736027452801025",
  "text" : "Umphrey\u2019s McGee is so good live. Crazy happy that they came to Buffalo. http:\/\/t.co\/6ZsouoNl",
  "id" : 291736027452801025,
  "created_at" : "2013-01-17 02:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/291728610258219008\/photo\/1",
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/YdEbdSzu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAxtoBmCcAAg9gl.jpg",
      "id_str" : "291728610262413312",
      "id" : 291728610262413312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAxtoBmCcAAg9gl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YdEbdSzu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291728610258219008",
  "text" : "Umphrey\u2019s. So good! http:\/\/t.co\/YdEbdSzu",
  "id" : 291728610258219008,
  "created_at" : "2013-01-17 02:08:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bair",
      "screen_name" : "adambair",
      "indices" : [ 0, 9 ],
      "id_str" : "10647472",
      "id" : 10647472
    }, {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 10, 21 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291690203557552129",
  "geo" : { },
  "id_str" : "291709824884940801",
  "in_reply_to_user_id" : 10647472,
  "text" : "@adambair @jamesuriah I\u2019m fine with that, but TF has been literally zero setup. I would love to pay them.",
  "id" : 291709824884940801,
  "in_reply_to_status_id" : 291690203557552129,
  "created_at" : "2013-01-17 00:53:36 +0000",
  "in_reply_to_screen_name" : "adambair",
  "in_reply_to_user_id_str" : "10647472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 79 ],
      "url" : "https:\/\/t.co\/to0dK5Am",
      "expanded_url" : "https:\/\/rubygems.org\/search?utf8=%E2%9C%93&query=appblade",
      "display_url" : "rubygems.org\/search?utf8=%E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291675547694661633",
  "geo" : { },
  "id_str" : "291676595943518208",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah Looks like you sell swiss army knives. Also - https:\/\/t.co\/to0dK5Am",
  "id" : 291676595943518208,
  "in_reply_to_status_id" : 291675547694661633,
  "created_at" : "2013-01-16 22:41:34 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 0, 11 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291674762613252096",
  "geo" : { },
  "id_str" : "291675004737818625",
  "in_reply_to_user_id" : 21390942,
  "text" : "@jamesuriah TestFlight.",
  "id" : 291675004737818625,
  "in_reply_to_status_id" : 291674762613252096,
  "created_at" : "2013-01-16 22:35:14 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/VPwzFmF7",
      "expanded_url" : "http:\/\/edmonton.en.craigslist.ca\/stp\/3542260564.html",
      "display_url" : "edmonton.en.craigslist.ca\/stp\/3542260564\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291673953989193729",
  "text" : "\/play makeitso http:\/\/t.co\/VPwzFmF7",
  "id" : 291673953989193729,
  "created_at" : "2013-01-16 22:31:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    }, {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "indices" : [ 72, 88 ],
      "id_str" : "11133442",
      "id" : 11133442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/rg8NTmwo",
      "expanded_url" : "http:\/\/edmonton.en.craigslist.ca\/stp\/3542260564.html",
      "display_url" : "edmonton.en.craigslist.ca\/stp\/3542260564\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291672909267750912",
  "text" : "RT @beep: \u201CNothing weird is going to happen.\u201D http:\/\/t.co\/rg8NTmwo \/via @aworkinglibrary",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mandy Brown",
        "screen_name" : "aworkinglibrary",
        "indices" : [ 62, 78 ],
        "id_str" : "11133442",
        "id" : 11133442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/rg8NTmwo",
        "expanded_url" : "http:\/\/edmonton.en.craigslist.ca\/stp\/3542260564.html",
        "display_url" : "edmonton.en.craigslist.ca\/stp\/3542260564\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291672447923679232",
    "text" : "\u201CNothing weird is going to happen.\u201D http:\/\/t.co\/rg8NTmwo \/via @aworkinglibrary",
    "id" : 291672447923679232,
    "created_at" : "2013-01-16 22:25:05 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561270834401382400\/AJ669BlB_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 291672909267750912,
  "created_at" : "2013-01-16 22:26:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291663644775813121",
  "geo" : { },
  "id_str" : "291666934896939009",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade drunken ideas for games are hard to sue about ;)",
  "id" : 291666934896939009,
  "in_reply_to_status_id" : 291663644775813121,
  "created_at" : "2013-01-16 22:03:10 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Brennan",
      "screen_name" : "jasonbrennan",
      "indices" : [ 0, 13 ],
      "id_str" : "822640",
      "id" : 822640
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 80, 84 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291629186467115008",
  "geo" : { },
  "id_str" : "291630060828504064",
  "in_reply_to_user_id" : 822640,
  "text" : "@jasonbrennan Is this any different from the console baked into RubyMotion? \/cc @lrz",
  "id" : 291630060828504064,
  "in_reply_to_status_id" : 291629186467115008,
  "created_at" : "2013-01-16 19:36:39 +0000",
  "in_reply_to_screen_name" : "jasonbrennan",
  "in_reply_to_user_id_str" : "822640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291624577304518657",
  "geo" : { },
  "id_str" : "291625239425732608",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella Yes.",
  "id" : 291625239425732608,
  "in_reply_to_status_id" : 291624577304518657,
  "created_at" : "2013-01-16 19:17:29 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291624325612728322",
  "text" : "First official beta build going out for our Basecamp iOS testers. If you didn't get an invite, you'll have to wait...hopefully not long!",
  "id" : 291624325612728322,
  "created_at" : "2013-01-16 19:13:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291584760252346368",
  "text" : "RT @fending: This google doodle just cost the global economy a bunch of productivity loss.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291584675288326144",
    "text" : "This google doodle just cost the global economy a bunch of productivity loss.",
    "id" : 291584675288326144,
    "created_at" : "2013-01-16 16:36:18 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 291584760252346368,
  "created_at" : "2013-01-16 16:36:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291573668172161024",
  "geo" : { },
  "id_str" : "291574722347536384",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy amazing",
  "id" : 291574722347536384,
  "in_reply_to_status_id" : 291573668172161024,
  "created_at" : "2013-01-16 15:56:45 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291569524141076483",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy did you see today's google doodle!!?",
  "id" : 291569524141076483,
  "created_at" : "2013-01-16 15:36:06 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RIT Tiger Hockey",
      "screen_name" : "RITMHKY",
      "indices" : [ 78, 86 ],
      "id_str" : "701577752",
      "id" : 701577752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291566109751128064",
  "text" : "Today's google doodle is totally a rip of an idea I had from 2 years ago when @RITMHKY got to the Frozen Four...it was called TORONTO DRIFT",
  "id" : 291566109751128064,
  "created_at" : "2013-01-16 15:22:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291549978655088641",
  "geo" : { },
  "id_str" : "291565652685246464",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d Holy shit.",
  "id" : 291565652685246464,
  "in_reply_to_status_id" : 291549978655088641,
  "created_at" : "2013-01-16 15:20:43 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Umphrey's McGee",
      "screen_name" : "umphreysmcgee",
      "indices" : [ 0, 14 ],
      "id_str" : "16724705",
      "id" : 16724705
    }, {
      "name" : "Town Ballroom",
      "screen_name" : "townballroom",
      "indices" : [ 15, 28 ],
      "id_str" : "23723314",
      "id" : 23723314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291270558392414208",
  "geo" : { },
  "id_str" : "291562675916390400",
  "in_reply_to_user_id" : 16724705,
  "text" : "@umphreysmcgee @townballroom first show here too! When are you guys actually starting? 630 sounds super early.",
  "id" : 291562675916390400,
  "in_reply_to_status_id" : 291270558392414208,
  "created_at" : "2013-01-16 15:08:53 +0000",
  "in_reply_to_screen_name" : "umphreysmcgee",
  "in_reply_to_user_id_str" : "16724705",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horia Constantin",
      "screen_name" : "ConstantinHoria",
      "indices" : [ 0, 16 ],
      "id_str" : "769262971",
      "id" : 769262971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291534769634828288",
  "geo" : { },
  "id_str" : "291541424380448768",
  "in_reply_to_user_id" : 769262971,
  "text" : "@ConstantinHoria it will bump both. Any .gem download will. (gem install -V to see)",
  "id" : 291541424380448768,
  "in_reply_to_status_id" : 291534769634828288,
  "created_at" : "2013-01-16 13:44:26 +0000",
  "in_reply_to_screen_name" : "ConstantinHoria",
  "in_reply_to_user_id_str" : "769262971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky Mountain Ruby",
      "screen_name" : "rockymtnruby",
      "indices" : [ 0, 13 ],
      "id_str" : "288454983",
      "id" : 288454983
    }, {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 14, 23 ],
      "id_str" : "17875219",
      "id" : 17875219
    }, {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "indices" : [ 24, 31 ],
      "id_str" : "5284122",
      "id" : 5284122
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 32, 46 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 47, 57 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291418749125410817",
  "in_reply_to_user_id" : 288454983,
  "text" : "@rockymtnruby @mghaught @kobier @Carols10cents @jremsikjr I\u2019d love to know what weekends are still available in 2013. Entering this is hard.",
  "id" : 291418749125410817,
  "created_at" : "2013-01-16 05:36:58 +0000",
  "in_reply_to_screen_name" : "rockymtnruby",
  "in_reply_to_user_id_str" : "288454983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky Mountain Ruby",
      "screen_name" : "rockymtnruby",
      "indices" : [ 0, 13 ],
      "id_str" : "288454983",
      "id" : 288454983
    }, {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 14, 23 ],
      "id_str" : "17875219",
      "id" : 17875219
    }, {
      "name" : "Coby Randquist",
      "screen_name" : "kobier",
      "indices" : [ 24, 31 ],
      "id_str" : "5284122",
      "id" : 5284122
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 32, 46 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 47, 57 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291415956436164608",
  "geo" : { },
  "id_str" : "291418049112834048",
  "in_reply_to_user_id" : 288454983,
  "text" : "@rockymtnruby @mghaught @kobier @Carols10cents @jremsikjr how can I get on the regional conf list? I couldn\u2019t when signed into Groups.",
  "id" : 291418049112834048,
  "in_reply_to_status_id" : 291415956436164608,
  "created_at" : "2013-01-16 05:34:11 +0000",
  "in_reply_to_screen_name" : "rockymtnruby",
  "in_reply_to_user_id_str" : "288454983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky Mountain Ruby",
      "screen_name" : "rockymtnruby",
      "indices" : [ 0, 13 ],
      "id_str" : "288454983",
      "id" : 288454983
    }, {
      "name" : "Marty Haught",
      "screen_name" : "mghaught",
      "indices" : [ 14, 23 ],
      "id_str" : "17875219",
      "id" : 17875219
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 86, 96 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 97, 107 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 108, 123 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 124, 130 ],
      "id_str" : "34287352",
      "id" : 34287352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291415956436164608",
  "geo" : { },
  "id_str" : "291417331903631360",
  "in_reply_to_user_id" : 288454983,
  "text" : "@rockymtnruby @mghaught gahhh we need to get a date for our buffalo conf down. :( \/cc @aquaranto @aspleenic @1ofyourmeteors @byllc",
  "id" : 291417331903631360,
  "in_reply_to_status_id" : 291415956436164608,
  "created_at" : "2013-01-16 05:31:20 +0000",
  "in_reply_to_screen_name" : "rockymtnruby",
  "in_reply_to_user_id_str" : "288454983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 0, 11 ],
      "id_str" : "381521407",
      "id" : 381521407
    }, {
      "name" : "Stuart Liston",
      "screen_name" : "stuliston",
      "indices" : [ 12, 22 ],
      "id_str" : "66106097",
      "id" : 66106097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291308091432120322",
  "geo" : { },
  "id_str" : "291310172977102848",
  "in_reply_to_user_id" : 381521407,
  "text" : "@RubyMotion @stuliston Yes!",
  "id" : 291310172977102848,
  "in_reply_to_status_id" : 291308091432120322,
  "created_at" : "2013-01-15 22:25:32 +0000",
  "in_reply_to_screen_name" : "RubyMotion",
  "in_reply_to_user_id_str" : "381521407",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 3, 12 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "indices" : [ 21, 30 ],
      "id_str" : "17137749",
      "id" : 17137749
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/shildner\/status\/291299008520011777\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/cw2XyToM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BArm56bCQAAkji3.jpg",
      "id_str" : "291299008528400384",
      "id" : 291299008528400384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BArm56bCQAAkji3.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/cw2XyToM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291299250422304768",
  "text" : "RT @shildner: @qrush @tzmartin @coworkbuffalo The elusive white buffalo! http:\/\/t.co\/cw2XyToM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "\uF8FF tz martin",
        "screen_name" : "tzmartin",
        "indices" : [ 7, 16 ],
        "id_str" : "17137749",
        "id" : 17137749
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 17, 31 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/shildner\/status\/291299008520011777\/photo\/1",
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/cw2XyToM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BArm56bCQAAkji3.jpg",
        "id_str" : "291299008528400384",
        "id" : 291299008528400384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BArm56bCQAAkji3.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/cw2XyToM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "291298206745239553",
    "geo" : { },
    "id_str" : "291299008520011777",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @tzmartin @coworkbuffalo The elusive white buffalo! http:\/\/t.co\/cw2XyToM",
    "id" : 291299008520011777,
    "in_reply_to_status_id" : 291298206745239553,
    "created_at" : "2013-01-15 21:41:10 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "protected" : false,
      "id_str" : "16225196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440887180529897472\/Hp3eZzzI_normal.jpeg",
      "id" : 16225196,
      "verified" : false
    }
  },
  "id" : 291299250422304768,
  "created_at" : "2013-01-15 21:42:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "indices" : [ 0, 9 ],
      "id_str" : "17137749",
      "id" : 17137749
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 50, 59 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291297751227064320",
  "geo" : { },
  "id_str" : "291298206745239553",
  "in_reply_to_user_id" : 17137749,
  "text" : "@tzmartin @coworkbuffalo oh it just got PRINTED - @shildner has a real one!",
  "id" : 291298206745239553,
  "in_reply_to_status_id" : 291297751227064320,
  "created_at" : "2013-01-15 21:37:59 +0000",
  "in_reply_to_screen_name" : "tzmartin",
  "in_reply_to_user_id_str" : "17137749",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "basic derek",
      "screen_name" : "djbender",
      "indices" : [ 0, 9 ],
      "id_str" : "14161178",
      "id" : 14161178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/DNgxCX8H",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/FPSRussia#History",
      "display_url" : "en.wikipedia.org\/wiki\/FPSRussia\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291258225498656768",
  "geo" : { },
  "id_str" : "291260470302760960",
  "in_reply_to_user_id" : 14161178,
  "text" : "@djbender http:\/\/t.co\/DNgxCX8H he's from the south.",
  "id" : 291260470302760960,
  "in_reply_to_status_id" : 291258225498656768,
  "created_at" : "2013-01-15 19:08:02 +0000",
  "in_reply_to_screen_name" : "djbender",
  "in_reply_to_user_id_str" : "14161178",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291257966697521152",
  "text" : "Oops, apparently it's the poster of the videos, not the fake russian guy. But still...wtf.",
  "id" : 291257966697521152,
  "created_at" : "2013-01-15 18:58:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/Cx96GZaG",
      "expanded_url" : "http:\/\/kottke.org\/13\/01\/youtube-gun-nut-shot-dead",
      "display_url" : "kottke.org\/13\/01\/youtube-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291257741266264065",
  "text" : "Holy shit, the FPSRussia guy was shot to death. http:\/\/t.co\/Cx96GZaG",
  "id" : 291257741266264065,
  "created_at" : "2013-01-15 18:57:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291248310008815616",
  "geo" : { },
  "id_str" : "291249278154846208",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl *not* all that different. Just saying, this shouldn't be an excuse to stop you from using it now.",
  "id" : 291249278154846208,
  "in_reply_to_status_id" : 291248310008815616,
  "created_at" : "2013-01-15 18:23:33 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291248310008815616",
  "geo" : { },
  "id_str" : "291249170155704321",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl the output that CS generates is really that all that different. Following what the compiler has done has rarely been a problem for me.",
  "id" : 291249170155704321,
  "in_reply_to_status_id" : 291248310008815616,
  "created_at" : "2013-01-15 18:23:07 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291246894863241218",
  "geo" : { },
  "id_str" : "291247243116306432",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl why not now? been debugging CS almost 2 years without it.",
  "id" : 291247243116306432,
  "in_reply_to_status_id" : 291246894863241218,
  "created_at" : "2013-01-15 18:15:28 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knight Slider",
      "screen_name" : "TheKnightSlider",
      "indices" : [ 0, 16 ],
      "id_str" : "599824167",
      "id" : 599824167
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 73, 87 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291242732888944640",
  "geo" : { },
  "id_str" : "291242904532422656",
  "in_reply_to_user_id" : 599824167,
  "text" : "@TheKnightSlider Do want. When are you coming to Main &amp; Mohawk?! \/cc @coworkbuffalo",
  "id" : 291242904532422656,
  "in_reply_to_status_id" : 291242732888944640,
  "created_at" : "2013-01-15 17:58:14 +0000",
  "in_reply_to_screen_name" : "TheKnightSlider",
  "in_reply_to_user_id_str" : "599824167",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291238449057521664",
  "text" : "Today in @37signals life - guessing who works without clothes.",
  "id" : 291238449057521664,
  "created_at" : "2013-01-15 17:40:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291236362118635521",
  "geo" : { },
  "id_str" : "291237523475279872",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits That's terrifying to me.",
  "id" : 291237523475279872,
  "in_reply_to_status_id" : 291236362118635521,
  "created_at" : "2013-01-15 17:36:51 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 44, 58 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "indices" : [ 62, 71 ],
      "id_str" : "17137749",
      "id" : 17137749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/eiHuk6a9",
      "expanded_url" : "https:\/\/sketchfab.com\/show\/mv3XlrFRPuVZoREQ8HXIxHUmlv4",
      "display_url" : "sketchfab.com\/show\/mv3XlrFRP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291222887740882944",
  "text" : "I can't say enough how awesome this is - 3D @CoworkBuffalo by @tzmartin : https:\/\/t.co\/eiHuk6a9",
  "id" : 291222887740882944,
  "created_at" : "2013-01-15 16:38:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 39, 47 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 48, 58 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/q04CtWUL",
      "expanded_url" : "http:\/\/www.crazyblinddate.com\/",
      "display_url" : "crazyblinddate.com"
    } ]
  },
  "geo" : { },
  "id_str" : "291199255975165952",
  "text" : "Is this hearton?! http:\/\/t.co\/q04CtWUL @jayunit @mikeburns",
  "id" : 291199255975165952,
  "created_at" : "2013-01-15 15:04:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Chang Khin Boon",
      "screen_name" : "lxcid",
      "indices" : [ 0, 6 ],
      "id_str" : "28384294",
      "id" : 28384294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291036555202658304",
  "geo" : { },
  "id_str" : "291060070794551296",
  "in_reply_to_user_id" : 28384294,
  "text" : "@lxcid but he\u2019s taking it at face value. Obviously not the same domain. Sad that there\u2019s not more choices.",
  "id" : 291060070794551296,
  "in_reply_to_status_id" : 291036555202658304,
  "created_at" : "2013-01-15 05:51:43 +0000",
  "in_reply_to_screen_name" : "lxcid",
  "in_reply_to_user_id_str" : "28384294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291031282417274880",
  "geo" : { },
  "id_str" : "291058064184991744",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill custom mode!",
  "id" : 291058064184991744,
  "in_reply_to_status_id" : 291031282417274880,
  "created_at" : "2013-01-15 05:43:44 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 0, 10 ],
      "id_str" : "15847711",
      "id" : 15847711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291031282417274880",
  "geo" : { },
  "id_str" : "291032525550268417",
  "in_reply_to_user_id" : 15847711,
  "text" : "@benhamill haha no, it\u2019s a Halo 4 game type I\u2019m trying out ;)",
  "id" : 291032525550268417,
  "in_reply_to_status_id" : 291031282417274880,
  "created_at" : "2013-01-15 04:02:15 +0000",
  "in_reply_to_screen_name" : "benhamill",
  "in_reply_to_user_id_str" : "15847711",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291030986060341248",
  "text" : "Monorail is a hit with 4 people...insane to see the constant Railgun fire. I wish there was a way to distribute this game type better.",
  "id" : 291030986060341248,
  "created_at" : "2013-01-15 03:56:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Adams",
      "screen_name" : "adams_ea",
      "indices" : [ 0, 9 ],
      "id_str" : "187416164",
      "id" : 187416164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291024788598693888",
  "geo" : { },
  "id_str" : "291030668815785987",
  "in_reply_to_user_id" : 187416164,
  "text" : "@adams_ea thanks!",
  "id" : 291030668815785987,
  "in_reply_to_status_id" : 291024788598693888,
  "created_at" : "2013-01-15 03:54:53 +0000",
  "in_reply_to_screen_name" : "adams_ea",
  "in_reply_to_user_id_str" : "187416164",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291020081595551746",
  "geo" : { },
  "id_str" : "291020406528290817",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle Hey, I didn't compare to Ruby! ;)",
  "id" : 291020406528290817,
  "in_reply_to_status_id" : 291020081595551746,
  "created_at" : "2013-01-15 03:14:06 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291020109227651073",
  "text" : "\"Doom 3 has 601k [LoC]\" ... \"They re-wrote all required STL[4] functions\" \"*ALWAYS* use \u007B \u007D even when optional\" ...BEAUTY!",
  "id" : 291020109227651073,
  "created_at" : "2013-01-15 03:12:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/uiEbwfbK",
      "expanded_url" : "http:\/\/kotaku.com\/5975610\/the-exceptional-beauty-of-doom-3s-source-code?post=56177550",
      "display_url" : "kotaku.com\/5975610\/the-ex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291018925381136384",
  "text" : "C++ programmers have such a warped sense of \"beauty\". I guess when you're trapped using one language it happens. http:\/\/t.co\/uiEbwfbK",
  "id" : 291018925381136384,
  "created_at" : "2013-01-15 03:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 0, 13 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/qU3gdrso",
      "expanded_url" : "http:\/\/developer.apple.com\/library\/ios\/#documentation\/UserExperience\/Conceptual\/AutolayoutPG\/Articles\/formatLanguage.html",
      "display_url" : "developer.apple.com\/library\/ios\/#d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291015343089020928",
  "in_reply_to_user_id" : 9896112,
  "text" : "@jonathanpenn I meant to link you: http:\/\/t.co\/qU3gdrso",
  "id" : 291015343089020928,
  "created_at" : "2013-01-15 02:53:59 +0000",
  "in_reply_to_screen_name" : "jonathanpenn",
  "in_reply_to_user_id_str" : "9896112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Stubenbord",
      "screen_name" : "JessStubenbord",
      "indices" : [ 3, 18 ],
      "id_str" : "735635256",
      "id" : 735635256
    }, {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 87, 97 ],
      "id_str" : "817437266",
      "id" : 817437266
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 98, 106 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Seven Week Startup",
      "screen_name" : "7weekstartup",
      "indices" : [ 107, 120 ],
      "id_str" : "960884047",
      "id" : 960884047
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 121, 135 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 139, 140 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "NextPlex",
      "screen_name" : "nplex",
      "indices" : [ 139, 140 ],
      "id_str" : "534757903",
      "id" : 534757903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291011808079257600",
  "text" : "RT @JessStubenbord: Continually surprised the up and coming tech community in #Buffalo @BuffaloJS @wnyruby @7weekstartup @coworkbuffalo  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo JavaScript",
        "screen_name" : "BuffaloJS",
        "indices" : [ 67, 77 ],
        "id_str" : "817437266",
        "id" : 817437266
      }, {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 78, 86 ],
        "id_str" : "205886758",
        "id" : 205886758
      }, {
        "name" : "Seven Week Startup",
        "screen_name" : "7weekstartup",
        "indices" : [ 87, 100 ],
        "id_str" : "960884047",
        "id" : 960884047
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 101, 115 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Z80 Labs",
        "screen_name" : "Z80Labs",
        "indices" : [ 116, 124 ],
        "id_str" : "632391390",
        "id" : 632391390
      }, {
        "name" : "NextPlex",
        "screen_name" : "nplex",
        "indices" : [ 125, 131 ],
        "id_str" : "534757903",
        "id" : 534757903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291001140978515969",
    "text" : "Continually surprised the up and coming tech community in #Buffalo @BuffaloJS @wnyruby @7weekstartup @coworkbuffalo @Z80Labs @nplex",
    "id" : 291001140978515969,
    "created_at" : "2013-01-15 01:57:33 +0000",
    "user" : {
      "name" : "Jess Stubenbord",
      "screen_name" : "JessStubenbord",
      "protected" : false,
      "id_str" : "735635256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494105071047548930\/ky1YLUBl_normal.jpeg",
      "id" : 735635256,
      "verified" : false
    }
  },
  "id" : 291011808079257600,
  "created_at" : "2013-01-15 02:39:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291002732855320578",
  "geo" : { },
  "id_str" : "291003719204630529",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden YOUR HAIR IS NOT BLUE!!?!",
  "id" : 291003719204630529,
  "in_reply_to_status_id" : 291002732855320578,
  "created_at" : "2013-01-15 02:07:47 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290995605902348289",
  "geo" : { },
  "id_str" : "291002409956823040",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Wat?",
  "id" : 291002409956823040,
  "in_reply_to_status_id" : 290995605902348289,
  "created_at" : "2013-01-15 02:02:35 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Hinson",
      "screen_name" : "clayhinson",
      "indices" : [ 0, 11 ],
      "id_str" : "1970061",
      "id" : 1970061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290992863653801984",
  "geo" : { },
  "id_str" : "290995485924261888",
  "in_reply_to_user_id" : 1970061,
  "text" : "@clayhinson thanks!",
  "id" : 290995485924261888,
  "in_reply_to_status_id" : 290992863653801984,
  "created_at" : "2013-01-15 01:35:04 +0000",
  "in_reply_to_screen_name" : "clayhinson",
  "in_reply_to_user_id_str" : "1970061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 20, 30 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 138 ],
      "url" : "https:\/\/t.co\/eaQE7ERm",
      "expanded_url" : "https:\/\/37signals.wufoo.com\/forms\/apply-to-test-the-basecamp-iphone-app\/",
      "display_url" : "37signals.wufoo.com\/forms\/apply-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290994448580632576",
  "text" : "Hey Basecamp users! @37signals has a new iPhone app you want. (Also it\u2019s written in RubyMotion!) Apply for the beta: https:\/\/t.co\/eaQE7ERm",
  "id" : 290994448580632576,
  "created_at" : "2013-01-15 01:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 98 ],
      "url" : "https:\/\/t.co\/ibGAKBM5",
      "expanded_url" : "https:\/\/37signals.wufoo.com\/forms\/apply-to-test-the-basecamp-iphone-app\/",
      "display_url" : "37signals.wufoo.com\/forms\/apply-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290983767483510784",
  "text" : "RT @rjs: Want to beta test a Basecamp iPhone app from 37signals? Apply here: https:\/\/t.co\/ibGAKBM5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 89 ],
        "url" : "https:\/\/t.co\/ibGAKBM5",
        "expanded_url" : "https:\/\/37signals.wufoo.com\/forms\/apply-to-test-the-basecamp-iphone-app\/",
        "display_url" : "37signals.wufoo.com\/forms\/apply-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "290972718256492544",
    "text" : "Want to beta test a Basecamp iPhone app from 37signals? Apply here: https:\/\/t.co\/ibGAKBM5",
    "id" : 290972718256492544,
    "created_at" : "2013-01-15 00:04:36 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 290983767483510784,
  "created_at" : "2013-01-15 00:48:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290964750190395392",
  "text" : "Almost 20 folks @coworkbuffalo for BuffaloJS. Packed house!",
  "id" : 290964750190395392,
  "created_at" : "2013-01-14 23:32:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290889971479498753",
  "geo" : { },
  "id_str" : "290890398006669312",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft \"Although we are a bunch of guys, women are welcome to participate.\"",
  "id" : 290890398006669312,
  "in_reply_to_status_id" : 290889971479498753,
  "created_at" : "2013-01-14 18:37:30 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 76, 89 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/yJ7tm8Cj",
      "expanded_url" : "http:\/\/www.meetup.com\/AustinBrogrammers\/",
      "display_url" : "meetup.com\/AustinBrogramm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290890270143287296",
  "text" : "\"Meet the guys, talk code, find a wingman\/pivot?\" http:\/\/t.co\/yJ7tm8Cj (via @moonpolysoft)",
  "id" : 290890270143287296,
  "created_at" : "2013-01-14 18:36:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/uZWv9PuZ",
      "expanded_url" : "http:\/\/turntable.fm\/mashupfm",
      "display_url" : "turntable.fm\/mashupfm"
    } ]
  },
  "geo" : { },
  "id_str" : "290869284924698624",
  "text" : "DJing in the mashup.fm room. Now playing Gorillaz vs Chicago #turntablefm http:\/\/t.co\/uZWv9PuZ",
  "id" : 290869284924698624,
  "created_at" : "2013-01-14 17:13:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/8dDp5YAg",
      "expanded_url" : "http:\/\/words.steveklabnik.com\/rails-has-two-default-stacks",
      "display_url" : "words.steveklabnik.com\/rails-has-two-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290867129509629952",
  "text" : "\"skipping straight to the tool that solves my pain without feeling that pain [...] just confuses\" - http:\/\/t.co\/8dDp5YAg",
  "id" : 290867129509629952,
  "created_at" : "2013-01-14 17:05:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290864758096277505",
  "text" : "OH \"It's like seed sharing, except with boars\"",
  "id" : 290864758096277505,
  "created_at" : "2013-01-14 16:55:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Neuland",
      "screen_name" : "derekneuland",
      "indices" : [ 0, 13 ],
      "id_str" : "9842672",
      "id" : 9842672
    }, {
      "name" : "Buffalo Food Trucks",
      "screen_name" : "BfloFoodTruck",
      "indices" : [ 14, 28 ],
      "id_str" : "884066306",
      "id" : 884066306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/hgfYT1rs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "in_reply_to_status_id_str" : "290854145500520448",
  "geo" : { },
  "id_str" : "290859735417241600",
  "in_reply_to_user_id" : 9842672,
  "text" : "@derekneuland @BfloFoodTruck This is nice but doesn't show where they are all going to be one page: http:\/\/t.co\/hgfYT1rs",
  "id" : 290859735417241600,
  "in_reply_to_status_id" : 290854145500520448,
  "created_at" : "2013-01-14 16:35:39 +0000",
  "in_reply_to_screen_name" : "derekneuland",
  "in_reply_to_user_id_str" : "9842672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "indices" : [ 3, 13 ],
      "id_str" : "817437266",
      "id" : 817437266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/swaFBL3A",
      "expanded_url" : "https:\/\/gather.at\/e\/6299a0f3",
      "display_url" : "gather.at\/e\/6299a0f3"
    } ]
  },
  "geo" : { },
  "id_str" : "290848309130690560",
  "text" : "RT @BuffaloJS: Buffalojs First Meetup about 7 hours from now at CoworkBuffalo https:\/\/t.co\/swaFBL3A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/gather.at\" rel=\"nofollow\"\u003EGather.at\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 84 ],
        "url" : "https:\/\/t.co\/swaFBL3A",
        "expanded_url" : "https:\/\/gather.at\/e\/6299a0f3",
        "display_url" : "gather.at\/e\/6299a0f3"
      } ]
    },
    "geo" : { },
    "id_str" : "290845240645017602",
    "text" : "Buffalojs First Meetup about 7 hours from now at CoworkBuffalo https:\/\/t.co\/swaFBL3A",
    "id" : 290845240645017602,
    "created_at" : "2013-01-14 15:38:03 +0000",
    "user" : {
      "name" : "Buffalo JavaScript",
      "screen_name" : "BuffaloJS",
      "protected" : false,
      "id_str" : "817437266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2610143091\/l6yzj9lm8dkcmc3qdqed_normal.png",
      "id" : 817437266,
      "verified" : false
    }
  },
  "id" : 290848309130690560,
  "created_at" : "2013-01-14 15:50:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290702066446381056",
  "geo" : { },
  "id_str" : "290703749356331009",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Pokemon on iOS makes so much sense. Trading would actually happen.",
  "id" : 290703749356331009,
  "in_reply_to_status_id" : 290702066446381056,
  "created_at" : "2013-01-14 06:15:49 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/290646387853492224\/photo\/1",
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/9jniZEWx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAiVWY-CAAA9-T9.jpg",
      "id_str" : "290646387857686528",
      "id" : 290646387857686528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAiVWY-CAAA9-T9.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9jniZEWx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290671182716469248",
  "text" : "RT @aquaranto: Another Mario! http:\/\/t.co\/9jniZEWx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/290646387853492224\/photo\/1",
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/9jniZEWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAiVWY-CAAA9-T9.jpg",
        "id_str" : "290646387857686528",
        "id" : 290646387857686528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAiVWY-CAAA9-T9.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9jniZEWx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290646387853492224",
    "text" : "Another Mario! http:\/\/t.co\/9jniZEWx",
    "id" : 290646387853492224,
    "created_at" : "2013-01-14 02:27:54 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 290671182716469248,
  "created_at" : "2013-01-14 04:06:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290665246480297985",
  "geo" : { },
  "id_str" : "290668821541441536",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety ship it!!!!",
  "id" : 290668821541441536,
  "in_reply_to_status_id" : 290665246480297985,
  "created_at" : "2013-01-14 03:57:02 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/6DkvXIaE",
      "expanded_url" : "http:\/\/codecolossus.com\/blog\/2013\/01\/13\/goals-as-a-programmer-for-2013.html#.UPN-hjYJoTo.twitter",
      "display_url" : "codecolossus.com\/blog\/2013\/01\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290668796459483136",
  "text" : "RT @rubiety: Resurrecting my coding blog, finally: My Goals as a Programmer for 2013 | Code Colossus http:\/\/t.co\/6DkvXIaE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/6DkvXIaE",
        "expanded_url" : "http:\/\/codecolossus.com\/blog\/2013\/01\/13\/goals-as-a-programmer-for-2013.html#.UPN-hjYJoTo.twitter",
        "display_url" : "codecolossus.com\/blog\/2013\/01\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "290665246480297985",
    "text" : "Resurrecting my coding blog, finally: My Goals as a Programmer for 2013 | Code Colossus http:\/\/t.co\/6DkvXIaE",
    "id" : 290665246480297985,
    "created_at" : "2013-01-14 03:42:49 +0000",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 290668796459483136,
  "created_at" : "2013-01-14 03:56:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290653886174347265",
  "text" : "OH \u201CI made pizza in a coffee maker once\u201D",
  "id" : 290653886174347265,
  "created_at" : "2013-01-14 02:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    }, {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 10, 23 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290646909897560066",
  "geo" : { },
  "id_str" : "290646991912968193",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @jonathanpenn please don\u2019t ever say PORO",
  "id" : 290646991912968193,
  "in_reply_to_status_id" : 290646909897560066,
  "created_at" : "2013-01-14 02:30:17 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "756161",
      "id" : 756161
    }, {
      "name" : "Jonathan Penn",
      "screen_name" : "jonathanpenn",
      "indices" : [ 10, 23 ],
      "id_str" : "9896112",
      "id" : 9896112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290646604401213440",
  "geo" : { },
  "id_str" : "290646706943574017",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @jonathanpenn more camel.",
  "id" : 290646706943574017,
  "in_reply_to_status_id" : 290646604401213440,
  "created_at" : "2013-01-14 02:29:09 +0000",
  "in_reply_to_screen_name" : "zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/pGvmVBsh",
      "expanded_url" : "http:\/\/flic.kr\/p\/dLjx64",
      "display_url" : "flic.kr\/p\/dLjx64"
    } ]
  },
  "geo" : { },
  "id_str" : "290622952511250432",
  "text" : "Andy sauce! Apparently I can make logos too. http:\/\/t.co\/pGvmVBsh",
  "id" : 290622952511250432,
  "created_at" : "2013-01-14 00:54:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290605527501778944",
  "text" : "Wrapped the auto-Railgun and no shields game mode into a new game type - Monorail! \uD83D\uDE9D Doctor Q on XBL if you want it.",
  "id" : 290605527501778944,
  "created_at" : "2013-01-13 23:45:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 19, 26 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290603901802131456",
  "geo" : { },
  "id_str" : "290604407219953664",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto I think @tekkub will squee at this.",
  "id" : 290604407219953664,
  "in_reply_to_status_id" : 290603901802131456,
  "created_at" : "2013-01-13 23:41:04 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/290603901802131456\/photo\/1",
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/izn04ezq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAhutYHCMAAwGrg.jpg",
      "id_str" : "290603901810520064",
      "id" : 290603901810520064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAhutYHCMAAwGrg.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/izn04ezq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290604239586226176",
  "text" : "RT @aquaranto: Mario! http:\/\/t.co\/izn04ezq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/290603901802131456\/photo\/1",
        "indices" : [ 7, 27 ],
        "url" : "http:\/\/t.co\/izn04ezq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAhutYHCMAAwGrg.jpg",
        "id_str" : "290603901810520064",
        "id" : 290603901810520064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAhutYHCMAAwGrg.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/izn04ezq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290603901802131456",
    "text" : "Mario! http:\/\/t.co\/izn04ezq",
    "id" : 290603901802131456,
    "created_at" : "2013-01-13 23:39:04 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 290604239586226176,
  "created_at" : "2013-01-13 23:40:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290603515708051458",
  "text" : "I\u2019ve found a way to fix Halo 4\u2019s pitiful railgun: custom mode with Unlimited Ammo set to Bottomless Clip. No reloading, it\u2019s scary good.",
  "id" : 290603515708051458,
  "created_at" : "2013-01-13 23:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Robinson",
      "screen_name" : "_rbsn",
      "indices" : [ 0, 6 ],
      "id_str" : "2160164963",
      "id" : 2160164963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290595542273245184",
  "text" : "@_rbsn always spaces. Definitely a ruby thing.",
  "id" : 290595542273245184,
  "created_at" : "2013-01-13 23:05:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290573274201600001",
  "geo" : { },
  "id_str" : "290588124545949696",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d lol at dogs that hate outside.",
  "id" : 290588124545949696,
  "in_reply_to_status_id" : 290573274201600001,
  "created_at" : "2013-01-13 22:36:22 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290558850451521536",
  "text" : "First bike ride with the husky in months. Can\u2019t express how excited he was.",
  "id" : 290558850451521536,
  "created_at" : "2013-01-13 20:40:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290526625743912960",
  "text" : "Wow, didn't know you could command-click local files in iTerm and they'll open up in your $EDITOR.",
  "id" : 290526625743912960,
  "created_at" : "2013-01-13 18:31:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Rs9Ot2ob",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7jGbtIdOZ-M",
      "display_url" : "youtube.com\/watch?v=7jGbtI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290520969146163200",
  "text" : "Current status: http:\/\/t.co\/Rs9Ot2ob",
  "id" : 290520969146163200,
  "created_at" : "2013-01-13 18:09:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Gaebel \u272D",
      "screen_name" : "gryghostvisuals",
      "indices" : [ 0, 16 ],
      "id_str" : "218159376",
      "id" : 218159376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290495724859318273",
  "geo" : { },
  "id_str" : "290497768848506880",
  "in_reply_to_user_id" : 218159376,
  "text" : "@gryghostvisuals no. I just reload. I\u2019m not in Jekyll on a daily basis to care about more than that.",
  "id" : 290497768848506880,
  "in_reply_to_status_id" : 290495724859318273,
  "created_at" : "2013-01-13 16:37:19 +0000",
  "in_reply_to_screen_name" : "gryghostvisuals",
  "in_reply_to_user_id_str" : "218159376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Gaebel \u272D",
      "screen_name" : "gryghostvisuals",
      "indices" : [ 0, 16 ],
      "id_str" : "218159376",
      "id" : 218159376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290493267244625920",
  "geo" : { },
  "id_str" : "290494644922507266",
  "in_reply_to_user_id" : 218159376,
  "text" : "@gryghostvisuals :) i just use --auto !",
  "id" : 290494644922507266,
  "in_reply_to_status_id" : 290493267244625920,
  "created_at" : "2013-01-13 16:24:55 +0000",
  "in_reply_to_screen_name" : "gryghostvisuals",
  "in_reply_to_user_id_str" : "218159376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290489998468341760",
  "text" : "RT @rubiety: @qrush Especially since it is currently 39 in San Diego and 34 where I am in sweltering Palm Desert.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "290485664150061059",
    "geo" : { },
    "id_str" : "290489792997777409",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Especially since it is currently 39 in San Diego and 34 where I am in sweltering Palm Desert.",
    "id" : 290489792997777409,
    "in_reply_to_status_id" : 290485664150061059,
    "created_at" : "2013-01-13 16:05:38 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 290489998468341760,
  "created_at" : "2013-01-13 16:06:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290485664150061059",
  "text" : "It\u2019s 64 out in January in Buffalo, and I\u2019m going to go hack on my porch. Something is very wrong about this.",
  "id" : 290485664150061059,
  "created_at" : "2013-01-13 15:49:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 43, 54 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290453425576087554",
  "geo" : { },
  "id_str" : "290458250774736896",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending Barkyard! Barkyard! Barkyard! \/cc @kevinpurdy",
  "id" : 290458250774736896,
  "in_reply_to_status_id" : 290453425576087554,
  "created_at" : "2013-01-13 14:00:18 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/DBiBARJA",
      "expanded_url" : "http:\/\/37svn.com\/3264",
      "display_url" : "37svn.com\/3264"
    } ]
  },
  "in_reply_to_status_id_str" : "290331529526255616",
  "geo" : { },
  "id_str" : "290334910890258432",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky convention, autocompletion, and more. 37 started the same way, sub gave it order. http:\/\/t.co\/DBiBARJA",
  "id" : 290334910890258432,
  "in_reply_to_status_id" : 290331529526255616,
  "created_at" : "2013-01-13 05:50:11 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 12, 19 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290286418637504512",
  "geo" : { },
  "id_str" : "290330367540482048",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @Croaky could these be a sub instead? \u2018bot deploy'",
  "id" : 290330367540482048,
  "in_reply_to_status_id" : 290286418637504512,
  "created_at" : "2013-01-13 05:32:08 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 28, 39 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290284648670560256",
  "geo" : { },
  "id_str" : "290285203451179009",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench Towne! You and @Jonplussed should get tickets",
  "id" : 290285203451179009,
  "in_reply_to_status_id" : 290284648670560256,
  "created_at" : "2013-01-13 02:32:40 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290284275343962112",
  "text" : "Seeing Umphrey\u2019s McGee on Wednesday. Yes!",
  "id" : 290284275343962112,
  "created_at" : "2013-01-13 02:28:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290269898272288768",
  "text" : "Experiencing bij.",
  "id" : 290269898272288768,
  "created_at" : "2013-01-13 01:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290163466424160256",
  "geo" : { },
  "id_str" : "290267699265802242",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws matrix something?",
  "id" : 290267699265802242,
  "in_reply_to_status_id" : 290163466424160256,
  "created_at" : "2013-01-13 01:23:07 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290267141138161667",
  "geo" : { },
  "id_str" : "290267622598135808",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr up to you man. You\u2019re in it daily :)",
  "id" : 290267622598135808,
  "in_reply_to_status_id" : 290267141138161667,
  "created_at" : "2013-01-13 01:22:48 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "indices" : [ 3, 15 ],
      "id_str" : "906546798",
      "id" : 906546798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ko5TANZG",
      "expanded_url" : "http:\/\/www.meetup.com\/pittsburgh-ruby\/events\/96033112\/",
      "display_url" : "meetup.com\/pittsburgh-rub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290266722768941058",
  "text" : "RT @OpenHackPGH: Just 7 days left to RSVP for the first OpenHackPGH. Please respond so we can have an accurate count for food. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/ko5TANZG",
        "expanded_url" : "http:\/\/www.meetup.com\/pittsburgh-ruby\/events\/96033112\/",
        "display_url" : "meetup.com\/pittsburgh-rub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "290252157926649856",
    "text" : "Just 7 days left to RSVP for the first OpenHackPGH. Please respond so we can have an accurate count for food. http:\/\/t.co\/ko5TANZG",
    "id" : 290252157926649856,
    "created_at" : "2013-01-13 00:21:21 +0000",
    "user" : {
      "name" : "OpenHack Pittsburgh",
      "screen_name" : "OpenHackPGH",
      "protected" : false,
      "id_str" : "906546798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2999669692\/b62b12f60738a31585a880c970d66aae_normal.png",
      "id" : 906546798,
      "verified" : false
    }
  },
  "id" : 290266722768941058,
  "created_at" : "2013-01-13 01:19:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290252928416088065",
  "geo" : { },
  "id_str" : "290260384252846080",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr :( burn it all!",
  "id" : 290260384252846080,
  "in_reply_to_status_id" : 290252928416088065,
  "created_at" : "2013-01-13 00:54:03 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitchell Hashimoto",
      "screen_name" : "mitchellh",
      "indices" : [ 0, 10 ],
      "id_str" : "12819682",
      "id" : 12819682
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 11, 19 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290257940462583809",
  "geo" : { },
  "id_str" : "290259850649288705",
  "in_reply_to_user_id" : 12819682,
  "text" : "@mitchellh @evanphx yep!",
  "id" : 290259850649288705,
  "in_reply_to_status_id" : 290257940462583809,
  "created_at" : "2013-01-13 00:51:55 +0000",
  "in_reply_to_screen_name" : "mitchellh",
  "in_reply_to_user_id_str" : "12819682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290163282474565633",
  "text" : "Stopped at the most hoarder board game store ever in Cleveland on the way home from #codemash. Happy to support but creepy as fuck.",
  "id" : 290163282474565633,
  "created_at" : "2013-01-12 18:28:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/PO9Vc1iZ",
      "expanded_url" : "http:\/\/dlvr.it\/2nDTdv",
      "display_url" : "dlvr.it\/2nDTdv"
    } ]
  },
  "geo" : { },
  "id_str" : "290118178762280960",
  "text" : "Watch all of this, please - http:\/\/t.co\/PO9Vc1iZ",
  "id" : 290118178762280960,
  "created_at" : "2013-01-12 15:28:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dusty Burwell",
      "screen_name" : "dustyburwell",
      "indices" : [ 0, 13 ],
      "id_str" : "21663430",
      "id" : 21663430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289985428264722433",
  "geo" : { },
  "id_str" : "290117960763326464",
  "in_reply_to_user_id" : 21663430,
  "text" : "@dustyburwell not right now, sorry.",
  "id" : 290117960763326464,
  "in_reply_to_status_id" : 289985428264722433,
  "created_at" : "2013-01-12 15:28:06 +0000",
  "in_reply_to_screen_name" : "dustyburwell",
  "in_reply_to_user_id_str" : "21663430",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 40, 52 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289962465683443712",
  "text" : "I might run out of favorites favoriting @juliepagano\u2019s tweets.",
  "id" : 289962465683443712,
  "created_at" : "2013-01-12 05:10:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 37, 43 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 58, 70 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/Bv8ZG2jO",
      "expanded_url" : "http:\/\/instagr.am\/p\/UXqU8Mhcf7\/",
      "display_url" : "instagr.am\/p\/UXqU8Mhcf7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "289955920958607360",
  "text" : "RT @steveklabnik: King of Tokyo with @qrush, coreyhaines, @juliepagano, and @laurencoswinkel http:\/\/t.co\/Bv8ZG2jO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 19, 25 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "juliepagano",
        "screen_name" : "juliepagano",
        "indices" : [ 40, 52 ],
        "id_str" : "2874563195",
        "id" : 2874563195
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/Bv8ZG2jO",
        "expanded_url" : "http:\/\/instagr.am\/p\/UXqU8Mhcf7\/",
        "display_url" : "instagr.am\/p\/UXqU8Mhcf7\/"
      } ]
    },
    "geo" : { },
    "id_str" : "289946809546182657",
    "text" : "King of Tokyo with @qrush, coreyhaines, @juliepagano, and @laurencoswinkel http:\/\/t.co\/Bv8ZG2jO",
    "id" : 289946809546182657,
    "created_at" : "2013-01-12 04:08:01 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 289955920958607360,
  "created_at" : "2013-01-12 04:44:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289880120053878785",
  "geo" : { },
  "id_str" : "289903259764789248",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash where?! I can halp",
  "id" : 289903259764789248,
  "in_reply_to_status_id" : 289880120053878785,
  "created_at" : "2013-01-12 01:14:57 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289877385879355393",
  "text" : "Just picked my first lock. That first turn was awesome. #codemash",
  "id" : 289877385879355393,
  "created_at" : "2013-01-11 23:32:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis, esq.",
      "screen_name" : "dbagcurtis",
      "indices" : [ 28, 39 ],
      "id_str" : "1081083446",
      "id" : 1081083446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289865942039674880",
  "text" : "Favorite new troll account: @dbagcurtis",
  "id" : 289865942039674880,
  "created_at" : "2013-01-11 22:46:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 13, 28 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289864377732046849",
  "geo" : { },
  "id_str" : "289865316396310529",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy @franklinwebber well how else would you find Senior Solutions Architects ?!",
  "id" : 289865316396310529,
  "in_reply_to_status_id" : 289864377732046849,
  "created_at" : "2013-01-11 22:44:11 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289854411910569984",
  "geo" : { },
  "id_str" : "289854897468366848",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes sorry, I am dumb. I mean the last version of m.",
  "id" : 289854897468366848,
  "in_reply_to_status_id" : 289854411910569984,
  "created_at" : "2013-01-11 22:02:47 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289852517809000448",
  "geo" : { },
  "id_str" : "289854104749084672",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes sorry, does the last one work?",
  "id" : 289854104749084672,
  "in_reply_to_status_id" : 289852517809000448,
  "created_at" : "2013-01-11 21:59:38 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289850434192015362",
  "geo" : { },
  "id_str" : "289851822531813376",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes strange! Is the last version ok?",
  "id" : 289851822531813376,
  "in_reply_to_status_id" : 289850434192015362,
  "created_at" : "2013-01-11 21:50:34 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289849919810961408",
  "geo" : { },
  "id_str" : "289850288460922881",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes no. Sounds broken.",
  "id" : 289850288460922881,
  "in_reply_to_status_id" : 289849919810961408,
  "created_at" : "2013-01-11 21:44:28 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Banwart",
      "screen_name" : "sbanwart",
      "indices" : [ 3, 12 ],
      "id_str" : "7620782",
      "id" : 7620782
    }, {
      "name" : "Jim Holmes",
      "screen_name" : "aJimHolmes",
      "indices" : [ 33, 44 ],
      "id_str" : "248722643",
      "id" : 248722643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289849098104868864",
  "text" : "RT @sbanwart: A big thank you to @aJimHolmes and all the volunteers who make this possible. #codemash",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Holmes",
        "screen_name" : "aJimHolmes",
        "indices" : [ 19, 30 ],
        "id_str" : "248722643",
        "id" : 248722643
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "codemash",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289833497005268992",
    "text" : "A big thank you to @aJimHolmes and all the volunteers who make this possible. #codemash",
    "id" : 289833497005268992,
    "created_at" : "2013-01-11 20:37:45 +0000",
    "user" : {
      "name" : "Scott Banwart",
      "screen_name" : "sbanwart",
      "protected" : false,
      "id_str" : "7620782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1744808464\/img_3212-2_normal.jpg",
      "id" : 7620782,
      "verified" : false
    }
  },
  "id" : 289849098104868864,
  "created_at" : "2013-01-11 21:39:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289792760565866496",
  "geo" : { },
  "id_str" : "289843272061440001",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot suggestion for a section - When not to have a review.",
  "id" : 289843272061440001,
  "in_reply_to_status_id" : 289792760565866496,
  "created_at" : "2013-01-11 21:16:35 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ZY2OBNMb",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Tidal_locking",
      "display_url" : "en.wikipedia.org\/wiki\/Tidal_loc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "289840764131897345",
  "geo" : { },
  "id_str" : "289841033074843649",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza More on this: http:\/\/t.co\/ZY2OBNMb",
  "id" : 289841033074843649,
  "in_reply_to_status_id" : 289840764131897345,
  "created_at" : "2013-01-11 21:07:41 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/XFzKZaY4",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/cdp\/member-reviews\/A3HWDERS2J9GFL\/ref=cm_pdp_rev_all?ie=UTF8&sort_by=MostRecentReview",
      "display_url" : "amazon.com\/gp\/cdp\/member-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "289840367686279168",
  "geo" : { },
  "id_str" : "289840646188044288",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried More gold in this mine: \"This film is so silly (even by Beatles standards), it's almost unwatchable.\" http:\/\/t.co\/XFzKZaY4",
  "id" : 289840646188044288,
  "in_reply_to_status_id" : 289840367686279168,
  "created_at" : "2013-01-11 21:06:09 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289839651819233280",
  "geo" : { },
  "id_str" : "289840265802428417",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried \"If you start a business of any substance and you follow the rules in this book, you will fail.\" !",
  "id" : 289840265802428417,
  "in_reply_to_status_id" : 289839651819233280,
  "created_at" : "2013-01-11 21:04:38 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 11, 26 ],
      "id_str" : "81525784",
      "id" : 81525784
    }, {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 27, 43 ],
      "id_str" : "19539935",
      "id" : 19539935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289818060867657728",
  "geo" : { },
  "id_str" : "289820194732400640",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto @franklinwebber @laurenvoswinkel it\u2019s Big Buck Hunter time.",
  "id" : 289820194732400640,
  "in_reply_to_status_id" : 289818060867657728,
  "created_at" : "2013-01-11 19:44:53 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289816852975198208",
  "geo" : { },
  "id_str" : "289817465276493824",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule 1.0 isn\u2019t webscale",
  "id" : 289817465276493824,
  "in_reply_to_status_id" : 289816852975198208,
  "created_at" : "2013-01-11 19:34:02 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289816187242688512",
  "geo" : { },
  "id_str" : "289816559130640385",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba separate. this isn't SVN",
  "id" : 289816559130640385,
  "in_reply_to_status_id" : 289816187242688512,
  "created_at" : "2013-01-11 19:30:26 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289813733256073216",
  "geo" : { },
  "id_str" : "289813977133895680",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik coupons and QR codes for shit.",
  "id" : 289813977133895680,
  "in_reply_to_status_id" : 289813733256073216,
  "created_at" : "2013-01-11 19:20:11 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289813582365982720",
  "text" : "Still haven't used any iOS Passbook passes yet, and I feel that's because the setup &amp; code behind it are wildly complicated. #codemash",
  "id" : 289813582365982720,
  "created_at" : "2013-01-11 19:18:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289809142812647424",
  "geo" : { },
  "id_str" : "289809602734870528",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik TUK ER JERB!",
  "id" : 289809602734870528,
  "in_reply_to_status_id" : 289809142812647424,
  "created_at" : "2013-01-11 19:02:48 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289809142812647424",
  "geo" : { },
  "id_str" : "289809527975600129",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik THEY TUKK OUR JOBS!",
  "id" : 289809527975600129,
  "in_reply_to_status_id" : 289809142812647424,
  "created_at" : "2013-01-11 19:02:30 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/O5rmIqoA",
      "expanded_url" : "http:\/\/www.stevepoland.com\/dear-buffalo-entrepreneurs-geeks-2013-is-our-year-events-schedule-and-call-for-volunteers\/",
      "display_url" : "stevepoland.com\/dear-buffalo-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289805806529019905",
  "text" : "Dear Buffalo: Your tech community is here. Get involved! http:\/\/t.co\/O5rmIqoA",
  "id" : 289805806529019905,
  "created_at" : "2013-01-11 18:47:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Package Repo",
      "screen_name" : "Gemfury",
      "indices" : [ 0, 8 ],
      "id_str" : "259492334",
      "id" : 259492334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/qOetnNUg",
      "expanded_url" : "http:\/\/rdoc.info",
      "display_url" : "rdoc.info"
    } ]
  },
  "in_reply_to_status_id_str" : "289782899446796289",
  "geo" : { },
  "id_str" : "289783447801700352",
  "in_reply_to_user_id" : 259492334,
  "text" : "@Gemfury was hoping for a pull request to link to your site for each gem like http:\/\/t.co\/qOetnNUg \u2026what do you think?",
  "id" : 289783447801700352,
  "in_reply_to_status_id" : 289782899446796289,
  "created_at" : "2013-01-11 17:18:52 +0000",
  "in_reply_to_screen_name" : "Gemfury",
  "in_reply_to_user_id_str" : "259492334",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Doubrovkine",
      "screen_name" : "dblockdotorg",
      "indices" : [ 0, 13 ],
      "id_str" : "210932450",
      "id" : 210932450
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 14, 21 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 22, 31 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 80, 88 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 89, 96 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289769547806932992",
  "geo" : { },
  "id_str" : "289777417952821248",
  "in_reply_to_user_id" : 210932450,
  "text" : "@dblockdotorg @heroku @rubygems looks like an error on Heroku\u2019s side. Any ideas @ddollar @hone02 ?",
  "id" : 289777417952821248,
  "in_reply_to_status_id" : 289769547806932992,
  "created_at" : "2013-01-11 16:54:54 +0000",
  "in_reply_to_screen_name" : "dblockdotorg",
  "in_reply_to_user_id_str" : "210932450",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Austin Hughey",
      "screen_name" : "jaustinhughey",
      "indices" : [ 19, 33 ],
      "id_str" : "72242732",
      "id" : 72242732
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 52, 61 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 110 ],
      "url" : "https:\/\/t.co\/AC9o6eMp",
      "expanded_url" : "https:\/\/blog.engineyard.com\/2013\/lets-talk-about-openhack\/",
      "display_url" : "blog.engineyard.com\/2013\/lets-talk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289741165002117120",
  "text" : "Great article from @jaustinhughey about starting an @openhack in Austin! More more more! https:\/\/t.co\/AC9o6eMp",
  "id" : 289741165002117120,
  "created_at" : "2013-01-11 14:30:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289642654336172032",
  "geo" : { },
  "id_str" : "289643585261953025",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt But yeah man, miss ya! Maybe next year. For as crazy\/overwhelming CodeMash is, I love it.",
  "id" : 289643585261953025,
  "in_reply_to_status_id" : 289642654336172032,
  "created_at" : "2013-01-11 08:03:06 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289642654336172032",
  "geo" : { },
  "id_str" : "289642840923983872",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt Fail.",
  "id" : 289642840923983872,
  "in_reply_to_status_id" : 289642654336172032,
  "created_at" : "2013-01-11 08:00:09 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    }, {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 9, 22 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289640875531849728",
  "geo" : { },
  "id_str" : "289641192507977728",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash @stevenharman GL HF",
  "id" : 289641192507977728,
  "in_reply_to_status_id" : 289640875531849728,
  "created_at" : "2013-01-11 07:53:36 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289639873743319040",
  "geo" : { },
  "id_str" : "289640016051834880",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash Milk was a bad choice",
  "id" : 289640016051834880,
  "in_reply_to_status_id" : 289639873743319040,
  "created_at" : "2013-01-11 07:48:55 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 3, 18 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289636239085293568",
  "text" : "RT @franklinwebber: Lets have a moment of silence for the brave men and women who clean the mens' bathrooms at #codemash.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "codemash",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289635929688252416",
    "text" : "Lets have a moment of silence for the brave men and women who clean the mens' bathrooms at #codemash.",
    "id" : 289635929688252416,
    "created_at" : "2013-01-11 07:32:41 +0000",
    "user" : {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "protected" : false,
      "id_str" : "81525784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554674427741212672\/SWkje87X_normal.jpeg",
      "id" : 81525784,
      "verified" : false
    }
  },
  "id" : 289636239085293568,
  "created_at" : "2013-01-11 07:33:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "indices" : [ 3, 13 ],
      "id_str" : "15847711",
      "id" : 15847711
    }, {
      "name" : "Steam",
      "screen_name" : "steam_games",
      "indices" : [ 20, 32 ],
      "id_str" : "36803580",
      "id" : 36803580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/zlWexKGS",
      "expanded_url" : "http:\/\/store.steampowered.com\/app\/212680\/",
      "display_url" : "store.steampowered.com\/app\/212680\/"
    } ]
  },
  "geo" : { },
  "id_str" : "289591817257750528",
  "text" : "RT @benhamill: From @steam_games: Save 50% on FTL: Faster Than Light on Steam http:\/\/t.co\/zlWexKGS This wekend. $5. Do it. You don't eve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steam",
        "screen_name" : "steam_games",
        "indices" : [ 5, 17 ],
        "id_str" : "36803580",
        "id" : 36803580
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/zlWexKGS",
        "expanded_url" : "http:\/\/store.steampowered.com\/app\/212680\/",
        "display_url" : "store.steampowered.com\/app\/212680\/"
      } ]
    },
    "geo" : { },
    "id_str" : "289552900013826049",
    "text" : "From @steam_games: Save 50% on FTL: Faster Than Light on Steam http:\/\/t.co\/zlWexKGS This wekend. $5. Do it. You don't even have to thank me.",
    "id" : 289552900013826049,
    "created_at" : "2013-01-11 02:02:45 +0000",
    "user" : {
      "name" : "Ben Hamill",
      "screen_name" : "benhamill",
      "protected" : false,
      "id_str" : "15847711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537481391529668608\/gE-0Orxe_normal.png",
      "id" : 15847711,
      "verified" : false
    }
  },
  "id" : 289591817257750528,
  "created_at" : "2013-01-11 04:37:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289566324332560384",
  "geo" : { },
  "id_str" : "289568394863325186",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx as a SPAAAAACETEAM!",
  "id" : 289568394863325186,
  "in_reply_to_status_id" : 289566324332560384,
  "created_at" : "2013-01-11 03:04:19 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 15, 25 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 26, 38 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 39, 52 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Societal Obstacle",
      "screen_name" : "laurenvoswinkel",
      "indices" : [ 53, 69 ],
      "id_str" : "19539935",
      "id" : 19539935
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 70, 82 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/289566728235671552\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/qKL4bO7I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAS_Z7fCYAIygmD.png",
      "id_str" : "289566728244060162",
      "id" : 289566728244060162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAS_Z7fCYAIygmD.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/qKL4bO7I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289566728235671552",
  "text" : "Spaceteam with @aquaranto @coreyhaines @steveklabnik @laurenvoswinkel @juliepagano !! http:\/\/t.co\/qKL4bO7I",
  "id" : 289566728235671552,
  "created_at" : "2013-01-11 02:57:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289543343359262721",
  "geo" : { },
  "id_str" : "289543630857830400",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik DEEP BREATHING",
  "id" : 289543630857830400,
  "in_reply_to_status_id" : 289543343359262721,
  "created_at" : "2013-01-11 01:25:55 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 74, 83 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/QEDDeSiI",
      "expanded_url" : "http:\/\/openhack.github.com",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "289543558044717058",
  "text" : "Thanks for dealing with my GIF obsession, and if you want more info about @OpenHack: http:\/\/t.co\/QEDDeSiI #codemash",
  "id" : 289543558044717058,
  "created_at" : "2013-01-11 01:25:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Andrew Heil",
      "screen_name" : "andrewpheil",
      "indices" : [ 14, 26 ],
      "id_str" : "62357140",
      "id" : 62357140
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 27, 37 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 69, 80 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289541600118460416",
  "geo" : { },
  "id_str" : "289543226602446848",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @andrewpheil @aquaranto Yes! After LIGHTNING TALKS \/cc @joefiorini",
  "id" : 289543226602446848,
  "in_reply_to_status_id" : 289541600118460416,
  "created_at" : "2013-01-11 01:24:19 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289532983852023808",
  "geo" : { },
  "id_str" : "289536010327580672",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh ha, thanks! We opted for a way cheaper option\u2026$7 carabiner+bungee cord off amazon.",
  "id" : 289536010327580672,
  "in_reply_to_status_id" : 289532983852023808,
  "created_at" : "2013-01-11 00:55:38 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 3, 15 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 21, 30 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289524600918921216",
  "text" : "RT @coreyhaines: Hey @codemash, lightning talks start soon! Come over to Zambezi! BETTER THAN THE ALTERNATIVE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "codemash",
        "screen_name" : "codemash",
        "indices" : [ 4, 13 ],
        "id_str" : "7469772",
        "id" : 7469772
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289523636619055104",
    "text" : "Hey @codemash, lightning talks start soon! Come over to Zambezi! BETTER THAN THE ALTERNATIVE!",
    "id" : 289523636619055104,
    "created_at" : "2013-01-11 00:06:28 +0000",
    "user" : {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "protected" : false,
      "id_str" : "11458102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559070931516411904\/TBA7KnoH_normal.jpeg",
      "id" : 11458102,
      "verified" : false
    }
  },
  "id" : 289524600918921216,
  "created_at" : "2013-01-11 00:10:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289524565128921088",
  "text" : "Hey #codemash there are lightning talks with REAL LIGHTNING going on in Zambezi (sp?) behind the main stage. \u26A1\u26A1\u26A1",
  "id" : 289524565128921088,
  "created_at" : "2013-01-11 00:10:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 0, 10 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289502849535205376",
  "geo" : { },
  "id_str" : "289503602500845569",
  "in_reply_to_user_id" : 14848965,
  "text" : "@GFontenot good to hear. I\u2019d love to hear more as to why you wouldn\u2019t run screaming away from Xcode and everything around it.",
  "id" : 289503602500845569,
  "in_reply_to_status_id" : 289502849535205376,
  "created_at" : "2013-01-10 22:46:52 +0000",
  "in_reply_to_screen_name" : "GFontenot",
  "in_reply_to_user_id_str" : "14848965",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 0, 10 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289501757875318785",
  "geo" : { },
  "id_str" : "289502331723206656",
  "in_reply_to_user_id" : 14848965,
  "text" : "@GFontenot have you written any apps with RubyMotion yet? Mostly curious if this opinion has experience behind it ;)",
  "id" : 289502331723206656,
  "in_reply_to_status_id" : 289501757875318785,
  "created_at" : "2013-01-10 22:41:49 +0000",
  "in_reply_to_screen_name" : "GFontenot",
  "in_reply_to_user_id_str" : "14848965",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Doubrovkine",
      "screen_name" : "dblockdotorg",
      "indices" : [ 0, 13 ],
      "id_str" : "210932450",
      "id" : 210932450
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 14, 21 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 22, 31 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289498218709004288",
  "geo" : { },
  "id_str" : "289501661062369281",
  "in_reply_to_user_id" : 210932450,
  "text" : "@dblockdotorg @heroku @rubygems no pingdom alerts here. AWS must be at fault.",
  "id" : 289501661062369281,
  "in_reply_to_status_id" : 289498218709004288,
  "created_at" : "2013-01-10 22:39:09 +0000",
  "in_reply_to_screen_name" : "dblockdotorg",
  "in_reply_to_user_id_str" : "210932450",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289500383812915200",
  "geo" : { },
  "id_str" : "289500654483951617",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d you\u2019re an egg",
  "id" : 289500654483951617,
  "in_reply_to_status_id" : 289500383812915200,
  "created_at" : "2013-01-10 22:35:09 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 0, 10 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289499915644719104",
  "geo" : { },
  "id_str" : "289500527849512960",
  "in_reply_to_user_id" : 14848965,
  "text" : "@GFontenot had no idea, but makes sense now. Yet another reason RubyMotion needs to succeed - gems &amp; modules have this figured out.",
  "id" : 289500527849512960,
  "in_reply_to_status_id" : 289499915644719104,
  "created_at" : "2013-01-10 22:34:39 +0000",
  "in_reply_to_screen_name" : "GFontenot",
  "in_reply_to_user_id_str" : "14848965",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 44, 48 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289499154756038656",
  "geo" : { },
  "id_str" : "289499546722123777",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza not even sure what that means. @lrz any ideas?",
  "id" : 289499546722123777,
  "in_reply_to_status_id" : 289499154756038656,
  "created_at" : "2013-01-10 22:30:45 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289498163046408192",
  "geo" : { },
  "id_str" : "289498904414806016",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza quite clearly you\u2019re going to deal with both, but i\u2019ve been doing fine so far. It\u2019s the Super Munchkin of iOS.",
  "id" : 289498904414806016,
  "in_reply_to_status_id" : 289498163046408192,
  "created_at" : "2013-01-10 22:28:12 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289498163046408192",
  "geo" : { },
  "id_str" : "289498612558336003",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza circular refs? I don\u2019t see any leakage.",
  "id" : 289498612558336003,
  "in_reply_to_status_id" : 289498163046408192,
  "created_at" : "2013-01-10 22:27:02 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289497155780083712",
  "geo" : { },
  "id_str" : "289497572958171136",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I know you\u2019re trolling but I\u2019m extremely bullish about it. It works.",
  "id" : 289497572958171136,
  "in_reply_to_status_id" : 289497155780083712,
  "created_at" : "2013-01-10 22:22:54 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289496771615420416",
  "geo" : { },
  "id_str" : "289497289372876802",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza my rejection of most apple tools most likely has me biased\u2026I think we can do better. I hope to see that happen.",
  "id" : 289497289372876802,
  "in_reply_to_status_id" : 289496771615420416,
  "created_at" : "2013-01-10 22:21:47 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289496771615420416",
  "geo" : { },
  "id_str" : "289496983461298176",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza gems that work with RubyMotion. I\u2019m not convinced CocoaPods is the best way forward.",
  "id" : 289496983461298176,
  "in_reply_to_status_id" : 289496771615420416,
  "created_at" : "2013-01-10 22:20:34 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289495721781100544",
  "geo" : { },
  "id_str" : "289496177559363585",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens oh snap! I have a talk to prep for BuffaloJS\u2026not sure. We should catch up here though!",
  "id" : 289496177559363585,
  "in_reply_to_status_id" : 289495721781100544,
  "created_at" : "2013-01-10 22:17:21 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289495658560360449",
  "geo" : { },
  "id_str" : "289496001847382016",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza sounds like packaging more RM gems and using modules will fix this.",
  "id" : 289496001847382016,
  "in_reply_to_status_id" : 289495658560360449,
  "created_at" : "2013-01-10 22:16:40 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 17, 24 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289495426187538432",
  "geo" : { },
  "id_str" : "289495680261713920",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza and @mwhuss has helped me realize why: modules.",
  "id" : 289495680261713920,
  "in_reply_to_status_id" : 289495426187538432,
  "created_at" : "2013-01-10 22:15:23 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289495395179057152",
  "geo" : { },
  "id_str" : "289495522639757313",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss modules.",
  "id" : 289495522639757313,
  "in_reply_to_status_id" : 289495395179057152,
  "created_at" : "2013-01-10 22:14:45 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289495200093577216",
  "geo" : { },
  "id_str" : "289495353999380480",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I don\u2019t use any prefixes and I fail to see the purpose of them.",
  "id" : 289495353999380480,
  "in_reply_to_status_id" : 289495200093577216,
  "created_at" : "2013-01-10 22:14:05 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspect2013",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289494977141161984",
  "text" : "Definitely going to be talking about how much these patterns bother me at #inspect2013, and how RubyMotion fixes them.",
  "id" : 289494977141161984,
  "created_at" : "2013-01-10 22:12:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289494740011978752",
  "text" : "Patterns I hate about most Objective-C code I see: naming things [INITIALS][CLASS]. NQButton. NQWindow. NQKillMyself.",
  "id" : 289494740011978752,
  "created_at" : "2013-01-10 22:11:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289491214951137280",
  "geo" : { },
  "id_str" : "289492251074252800",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto rowbutt",
  "id" : 289492251074252800,
  "in_reply_to_status_id" : 289491214951137280,
  "created_at" : "2013-01-10 22:01:45 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Unw1M9d3",
      "expanded_url" : "http:\/\/lightningtalks.codemash.org",
      "display_url" : "lightningtalks.codemash.org"
    } ]
  },
  "geo" : { },
  "id_str" : "289490782686154752",
  "text" : "Just signed up for a lightning talk. You should too! http:\/\/t.co\/Unw1M9d3 #codemash",
  "id" : 289490782686154752,
  "created_at" : "2013-01-10 21:55:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 14, 27 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/FezELClj",
      "expanded_url" : "http:\/\/github.com\/lifo\/docrails",
      "display_url" : "github.com\/lifo\/docrails"
    } ]
  },
  "in_reply_to_status_id_str" : "289487493387141120",
  "geo" : { },
  "id_str" : "289488396043300866",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders @steveklabnik http:\/\/t.co\/FezELClj has public commit access",
  "id" : 289488396043300866,
  "in_reply_to_status_id" : 289487493387141120,
  "created_at" : "2013-01-10 21:46:26 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 5, 18 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289474892250898432",
  "text" : "Yes, @steveklabnik just quoted GQ in a talk. #codemash",
  "id" : 289474892250898432,
  "created_at" : "2013-01-10 20:52:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/JLwsW9ng",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins\/",
      "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289472676190371841",
  "text" : "If you missed it yesterday - here\u2019s how I use Jekyll with SCSS and CoffeeScrip, without plugins. http:\/\/t.co\/JLwsW9ng",
  "id" : 289472676190371841,
  "created_at" : "2013-01-10 20:43:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289466110565298177",
  "geo" : { },
  "id_str" : "289466916031037440",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan :( we try to save permanent deletes for absolutely necessary situations. Been meaning to make a 15 minute window for repushes :\/",
  "id" : 289466916031037440,
  "in_reply_to_status_id" : 289466110565298177,
  "created_at" : "2013-01-10 20:21:05 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289465269594750976",
  "geo" : { },
  "id_str" : "289465632611778561",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan agghhhh\u2026can you just yank and bump? :(",
  "id" : 289465632611778561,
  "in_reply_to_status_id" : 289465269594750976,
  "created_at" : "2013-01-10 20:15:59 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289464932079120385",
  "text" : "RT @steveklabnik: Every time someone says their editor 'supports refactoring' I cringe a little.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289462938585141248",
    "text" : "Every time someone says their editor 'supports refactoring' I cringe a little.",
    "id" : 289462938585141248,
    "created_at" : "2013-01-10 20:05:17 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 289464932079120385,
  "created_at" : "2013-01-10 20:13:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 0, 10 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289432670402916352",
  "geo" : { },
  "id_str" : "289432721367896064",
  "in_reply_to_user_id" : 14848965,
  "text" : "@GFontenot YES thank you!",
  "id" : 289432721367896064,
  "in_reply_to_status_id" : 289432670402916352,
  "created_at" : "2013-01-10 18:05:12 +0000",
  "in_reply_to_screen_name" : "GFontenot",
  "in_reply_to_user_id_str" : "14848965",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289432286200467458",
  "text" : "Looking for that GIF of a kid smashing a toy hammer on a keyboard and windows icons flying out. Any takers?",
  "id" : 289432286200467458,
  "created_at" : "2013-01-10 18:03:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 65, 74 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289423694265208835",
  "text" : "Hey, I just #codemash \u2018d you \/ And this is crazy \/ so vote on my @OpenHack Pecha Kucha maybe?",
  "id" : 289423694265208835,
  "created_at" : "2013-01-10 17:29:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/NJdqWZAL",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "289413642540163074",
  "geo" : { },
  "id_str" : "289413734554812416",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison http:\/\/t.co\/NJdqWZAL ...want to help!?!",
  "id" : 289413734554812416,
  "in_reply_to_status_id" : 289413642540163074,
  "created_at" : "2013-01-10 16:49:46 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289412341412548608",
  "geo" : { },
  "id_str" : "289412906406260737",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden It's just when I happen to have downtime and focus on stuff like this.",
  "id" : 289412906406260737,
  "in_reply_to_status_id" : 289412341412548608,
  "created_at" : "2013-01-10 16:46:28 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289412081613160450",
  "geo" : { },
  "id_str" : "289412857970425858",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods Doubtful. CoffeeScript is too good to look away from.",
  "id" : 289412857970425858,
  "in_reply_to_status_id" : 289412081613160450,
  "created_at" : "2013-01-10 16:46:17 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Package Repo",
      "screen_name" : "Gemfury",
      "indices" : [ 0, 8 ],
      "id_str" : "259492334",
      "id" : 259492334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/9q884c5J",
      "expanded_url" : "http:\/\/rubygems.org\/gems\/m",
      "display_url" : "rubygems.org\/gems\/m"
    } ]
  },
  "in_reply_to_status_id_str" : "289405967886594048",
  "geo" : { },
  "id_str" : "289412583948156928",
  "in_reply_to_user_id" : 259492334,
  "text" : "@Gemfury This is some cool stuff. Can we get a permalink and link it on every rubygems#show page? http:\/\/t.co\/9q884c5J",
  "id" : 289412583948156928,
  "in_reply_to_status_id" : 289405967886594048,
  "created_at" : "2013-01-10 16:45:11 +0000",
  "in_reply_to_screen_name" : "Gemfury",
  "in_reply_to_user_id_str" : "259492334",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Package Repo",
      "screen_name" : "Gemfury",
      "indices" : [ 3, 11 ],
      "id_str" : "259492334",
      "id" : 259492334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rpofw8fo",
      "expanded_url" : "http:\/\/badge.fury.io\/",
      "display_url" : "badge.fury.io"
    } ]
  },
  "geo" : { },
  "id_str" : "289412419548233728",
  "text" : "RT @Gemfury: Gem authors, we've built something special for you and the Ruby community. Try Gem Badge for your RubyGems - http:\/\/t.co\/rp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/rpofw8fo",
        "expanded_url" : "http:\/\/badge.fury.io\/",
        "display_url" : "badge.fury.io"
      } ]
    },
    "geo" : { },
    "id_str" : "289405967886594048",
    "text" : "Gem authors, we've built something special for you and the Ruby community. Try Gem Badge for your RubyGems - http:\/\/t.co\/rpofw8fo",
    "id" : 289405967886594048,
    "created_at" : "2013-01-10 16:18:54 +0000",
    "user" : {
      "name" : "Your Package Repo",
      "screen_name" : "Gemfury",
      "protected" : false,
      "id_str" : "259492334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1582784589\/twitter2_normal.png",
      "id" : 259492334,
      "verified" : false
    }
  },
  "id" : 289412419548233728,
  "created_at" : "2013-01-10 16:44:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "289412111766024194",
  "text" : "Hurray, http:\/\/t.co\/bdjsRgTW support queue cleared! #codemash",
  "id" : 289412111766024194,
  "created_at" : "2013-01-10 16:43:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289407427038806017",
  "geo" : { },
  "id_str" : "289408344786087936",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk INVITE PLZ",
  "id" : 289408344786087936,
  "in_reply_to_status_id" : 289407427038806017,
  "created_at" : "2013-01-10 16:28:20 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289405710092075009",
  "text" : "ClojureScript first impressions: ((((((((((((WTF :is \"this\"))))))",
  "id" : 289405710092075009,
  "created_at" : "2013-01-10 16:17:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matniss Oakenshield",
      "screen_name" : "mattenoble",
      "indices" : [ 3, 14 ],
      "id_str" : "112439285",
      "id" : 112439285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289402190894870531",
  "text" : "RT @mattenoble: Commenters on HN (Basecamp Breeze) can't imagine a world where there's people who don't know how to use Google Groups.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289402000377004032",
    "text" : "Commenters on HN (Basecamp Breeze) can't imagine a world where there's people who don't know how to use Google Groups.",
    "id" : 289402000377004032,
    "created_at" : "2013-01-10 16:03:08 +0000",
    "user" : {
      "name" : "Matniss Oakenshield",
      "screen_name" : "mattenoble",
      "protected" : false,
      "id_str" : "112439285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468616222662086656\/VonIKZXu_normal.png",
      "id" : 112439285,
      "verified" : false
    }
  },
  "id" : 289402190894870531,
  "created_at" : "2013-01-10 16:03:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289395867176284160",
  "text" : "Dart first impressions: caters to Java\/C# devs that don\u2019t know JS, debugging without source maps outside of Chrome sounds terrifying.",
  "id" : 289395867176284160,
  "created_at" : "2013-01-10 15:38:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289395177271996416",
  "geo" : { },
  "id_str" : "289395394767638528",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle haha, it\u2019s a sign for me that we aren\u2019t the best audience :)",
  "id" : 289395394767638528,
  "in_reply_to_status_id" : 289395177271996416,
  "created_at" : "2013-01-10 15:36:53 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/R3oSh0fR",
      "expanded_url" : "http:\/\/37svn.com\/3391",
      "display_url" : "37svn.com\/3391"
    } ]
  },
  "geo" : { },
  "id_str" : "289391113477976065",
  "text" : "Breeze is here! Using it as a private techie mailing list. Try it out! http:\/\/t.co\/R3oSh0fR",
  "id" : 289391113477976065,
  "created_at" : "2013-01-10 15:19:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289384211775901697",
  "geo" : { },
  "id_str" : "289384634775642112",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald haven\u2019t seen the do syntax\u2026still don\u2019t get it from that example",
  "id" : 289384634775642112,
  "in_reply_to_status_id" : 289384211775901697,
  "created_at" : "2013-01-10 14:54:08 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Remsik",
      "screen_name" : "jremsikjr",
      "indices" : [ 0, 10 ],
      "id_str" : "1942",
      "id" : 1942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289381174437089280",
  "geo" : { },
  "id_str" : "289384234773274624",
  "in_reply_to_user_id" : 1942,
  "text" : "@jremsikjr sure!",
  "id" : 289384234773274624,
  "in_reply_to_status_id" : 289381174437089280,
  "created_at" : "2013-01-10 14:52:32 +0000",
  "in_reply_to_screen_name" : "jremsikjr",
  "in_reply_to_user_id_str" : "1942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289381799287726081",
  "geo" : { },
  "id_str" : "289384172617871360",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Gangham style zombie mashups",
  "id" : 289384172617871360,
  "in_reply_to_status_id" : 289381799287726081,
  "created_at" : "2013-01-10 14:52:17 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289381799287726081",
  "geo" : { },
  "id_str" : "289384094004031489",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn zombies",
  "id" : 289384094004031489,
  "in_reply_to_status_id" : 289381799287726081,
  "created_at" : "2013-01-10 14:51:59 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 25, 34 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289377377807642624",
  "text" : "Would love to talk about @openhack at #codemash but not sure how. Maybe Pecha Kucha?",
  "id" : 289377377807642624,
  "created_at" : "2013-01-10 14:25:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289208351605260288",
  "geo" : { },
  "id_str" : "289258308374781952",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy woot! They need to get on twitter.",
  "id" : 289258308374781952,
  "in_reply_to_status_id" : 289208351605260288,
  "created_at" : "2013-01-10 06:32:09 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289232192092123138",
  "geo" : { },
  "id_str" : "289233907608604672",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini with Breeze?",
  "id" : 289233907608604672,
  "in_reply_to_status_id" : 289232192092123138,
  "created_at" : "2013-01-10 04:55:11 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/289228803178393601\/photo\/1",
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/AazQk25q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAOMEGiCcAAOwTM.jpg",
      "id_str" : "289228803182587904",
      "id" : 289228803182587904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAOMEGiCcAAOwTM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/AazQk25q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289228803178393601",
  "text" : "Dwarf Fortress in Smallworld. http:\/\/t.co\/AazQk25q",
  "id" : 289228803178393601,
  "created_at" : "2013-01-10 04:34:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289187456274817024",
  "geo" : { },
  "id_str" : "289187761523679232",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash in Salon B!",
  "id" : 289187761523679232,
  "in_reply_to_status_id" : 289187456274817024,
  "created_at" : "2013-01-10 01:51:49 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289182386053324801",
  "text" : "Bringing a ton of board games down to the conf area. Who\u2019s ready?! #codemash",
  "id" : 289182386053324801,
  "created_at" : "2013-01-10 01:30:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289156896923975680",
  "geo" : { },
  "id_str" : "289157898100150273",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude gross",
  "id" : 289157898100150273,
  "in_reply_to_status_id" : 289156896923975680,
  "created_at" : "2013-01-09 23:53:09 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/289153254187732992\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/ZaxDUOeZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BANHWknCEAAq2FS.jpg",
      "id_str" : "289153254191927296",
      "id" : 289153254191927296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BANHWknCEAAq2FS.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZaxDUOeZ"
    } ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289153254187732992",
  "text" : "Nacho cheesecake. This is a thing. #codemash http:\/\/t.co\/ZaxDUOeZ",
  "id" : 289153254187732992,
  "created_at" : "2013-01-09 23:34:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289150333110849537",
  "geo" : { },
  "id_str" : "289151872571420674",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik restaurant off the lobby",
  "id" : 289151872571420674,
  "in_reply_to_status_id" : 289150333110849537,
  "created_at" : "2013-01-09 23:29:13 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289145564350775296",
  "geo" : { },
  "id_str" : "289149613330538497",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik we are at great karoo\u2026ugh",
  "id" : 289149613330538497,
  "in_reply_to_status_id" : 289145564350775296,
  "created_at" : "2013-01-09 23:20:14 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dusty Burwell",
      "screen_name" : "dustyburwell",
      "indices" : [ 0, 13 ],
      "id_str" : "21663430",
      "id" : 21663430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289141101435187201",
  "geo" : { },
  "id_str" : "289142188414205952",
  "in_reply_to_user_id" : 21663430,
  "text" : "@dustyburwell we are at the Great Karoo (ugh)",
  "id" : 289142188414205952,
  "in_reply_to_status_id" : 289141101435187201,
  "created_at" : "2013-01-09 22:50:44 +0000",
  "in_reply_to_screen_name" : "dustyburwell",
  "in_reply_to_user_id_str" : "21663430",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289139915936129025",
  "text" : "@juliepagano they do seen ridiculous",
  "id" : 289139915936129025,
  "created_at" : "2013-01-09 22:41:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 43, 56 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 57, 62 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 63, 75 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 76, 87 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289136981764603904",
  "text" : "Hey #codemash\u2026 what are your dinner plans? @steveklabnik @objo @juliepagano @joefiorini (and anyone else!)",
  "id" : 289136981764603904,
  "created_at" : "2013-01-09 22:30:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kavok",
      "screen_name" : "experienceBij",
      "indices" : [ 3, 17 ],
      "id_str" : "234500076",
      "id" : 234500076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289134551379357697",
  "text" : "RT @experienceBij: EXPERIENCE BIJECTION",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289132662130626560",
    "text" : "EXPERIENCE BIJECTION",
    "id" : 289132662130626560,
    "created_at" : "2013-01-09 22:12:53 +0000",
    "user" : {
      "name" : "Kavok",
      "screen_name" : "experienceBij",
      "protected" : false,
      "id_str" : "234500076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1207755306\/bij_normal.jpg",
      "id" : 234500076,
      "verified" : false
    }
  },
  "id" : 289134551379357697,
  "created_at" : "2013-01-09 22:20:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289128151060185088",
  "geo" : { },
  "id_str" : "289129441127432192",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm BURN IT ALL",
  "id" : 289129441127432192,
  "in_reply_to_status_id" : 289128151060185088,
  "created_at" : "2013-01-09 22:00:05 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289125995712217088",
  "text" : "@juliepagano yay!",
  "id" : 289125995712217088,
  "created_at" : "2013-01-09 21:46:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289123698038935552",
  "geo" : { },
  "id_str" : "289125910785974273",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej \u201Cahhhhhhh\u201D",
  "id" : 289125910785974273,
  "in_reply_to_status_id" : 289123698038935552,
  "created_at" : "2013-01-09 21:46:03 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 41, 51 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289120832318484480",
  "geo" : { },
  "id_str" : "289121453683646469",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt holy crap, those might be @aquaranto\u2019s laughs?!",
  "id" : 289121453683646469,
  "in_reply_to_status_id" : 289120832318484480,
  "created_at" : "2013-01-09 21:28:20 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289121345055379456",
  "text" : "RT @garybernhardt: Wat is about a year old. Reminder that someone on Reddit claimed that the video was fake because there are women laug ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289120832318484480",
    "text" : "Wat is about a year old. Reminder that someone on Reddit claimed that the video was fake because there are women laughing. Nice work, dick.",
    "id" : 289120832318484480,
    "created_at" : "2013-01-09 21:25:52 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 289121345055379456,
  "created_at" : "2013-01-09 21:27:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 3, 12 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/ILmw5wv2",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins\/",
      "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289117836503293952",
  "text" : "RT @blowmage: \"If I need more than what Jekyll provides by default, I don\u2019t use Jekyll.\"\nhttp:\/\/t.co\/ILmw5wv2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/ILmw5wv2",
        "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins\/",
        "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289117082333884416",
    "text" : "\"If I need more than what Jekyll provides by default, I don\u2019t use Jekyll.\"\nhttp:\/\/t.co\/ILmw5wv2",
    "id" : 289117082333884416,
    "created_at" : "2013-01-09 21:10:58 +0000",
    "user" : {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "protected" : false,
      "id_str" : "57753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562384831791636480\/qT0xLSn9_normal.jpeg",
      "id" : 57753,
      "verified" : false
    }
  },
  "id" : 289117836503293952,
  "created_at" : "2013-01-09 21:13:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289117734049030146",
  "text" : "RT @jasonfried: Breeze customers: We've removed the code at the end of your Breeze email addresses. Nice and clean now. The old address  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289098173354483712",
    "text" : "Breeze customers: We've removed the code at the end of your Breeze email addresses. Nice and clean now. The old address will still work too.",
    "id" : 289098173354483712,
    "created_at" : "2013-01-09 19:55:50 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 289117734049030146,
  "created_at" : "2013-01-09 21:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289115663245651968",
  "geo" : { },
  "id_str" : "289115756170461184",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein yeah i'm specifically referring to SCSS. :)",
  "id" : 289115756170461184,
  "in_reply_to_status_id" : 289115663245651968,
  "created_at" : "2013-01-09 21:05:42 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dead.letter",
      "screen_name" : "benjaminws",
      "indices" : [ 0, 11 ],
      "id_str" : "14188391",
      "id" : 14188391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289112619896414209",
  "geo" : { },
  "id_str" : "289112854064418816",
  "in_reply_to_user_id" : 14188391,
  "text" : "@benjaminws Where is this being played!!?!? we need to play some games tonight.",
  "id" : 289112854064418816,
  "in_reply_to_status_id" : 289112619896414209,
  "created_at" : "2013-01-09 20:54:10 +0000",
  "in_reply_to_screen_name" : "benjaminws",
  "in_reply_to_user_id_str" : "14188391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/JLwsW9ng",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins\/",
      "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289112655325696001",
  "text" : "Here's how I use Jekyll, SCSS, and CoffeeScript without any plugins: http:\/\/t.co\/JLwsW9ng",
  "id" : 289112655325696001,
  "created_at" : "2013-01-09 20:53:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 3, 11 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nkohari\/status\/289098730278359040\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/VFL2Empq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMVw3OCEAAafMy.jpg",
      "id_str" : "289098730282553344",
      "id" : 289098730282553344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMVw3OCEAAafMy.jpg",
      "sizes" : [ {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 521
      } ],
      "display_url" : "pic.twitter.com\/VFL2Empq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289098942040403968",
  "text" : "RT @nkohari: I present, \/r\/programming. http:\/\/t.co\/VFL2Empq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nkohari\/status\/289098730278359040\/photo\/1",
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/VFL2Empq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMVw3OCEAAafMy.jpg",
        "id_str" : "289098730282553344",
        "id" : 289098730282553344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMVw3OCEAAafMy.jpg",
        "sizes" : [ {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 521
        } ],
        "display_url" : "pic.twitter.com\/VFL2Empq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289098730278359040",
    "text" : "I present, \/r\/programming. http:\/\/t.co\/VFL2Empq",
    "id" : 289098730278359040,
    "created_at" : "2013-01-09 19:58:03 +0000",
    "user" : {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "protected" : false,
      "id_str" : "6532552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486557242955534337\/o_ehcxEA_normal.jpeg",
      "id" : 6532552,
      "verified" : false
    }
  },
  "id" : 289098942040403968,
  "created_at" : "2013-01-09 19:58:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/orVARNwV",
      "expanded_url" : "http:\/\/speakerdeck.com",
      "display_url" : "speakerdeck.com"
    } ]
  },
  "geo" : { },
  "id_str" : "289097769166184448",
  "text" : "Is there a http:\/\/t.co\/orVARNwV or something similar for written work?",
  "id" : 289097769166184448,
  "created_at" : "2013-01-09 19:54:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/TwMMLtSm",
      "expanded_url" : "http:\/\/37svn.com\/3389",
      "display_url" : "37svn.com\/3389"
    } ]
  },
  "geo" : { },
  "id_str" : "289096792245665792",
  "text" : "\"If shit is broken, we\u2019ll fix it now, lest we be stuck with it for decades.\" - http:\/\/t.co\/TwMMLtSm",
  "id" : 289096792245665792,
  "created_at" : "2013-01-09 19:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 49, 62 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 63, 78 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289094153307045888",
  "geo" : { },
  "id_str" : "289094357221535745",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines Yay! We should get some dinner! \/cc @steveklabnik @franklinwebber",
  "id" : 289094357221535745,
  "in_reply_to_status_id" : 289094153307045888,
  "created_at" : "2013-01-09 19:40:40 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Fabian Perez",
      "screen_name" : "fabrahamlincoln",
      "indices" : [ 13, 29 ],
      "id_str" : "137877410",
      "id" : 137877410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/NSdF7pu3",
      "expanded_url" : "http:\/\/blog.rubygems.org\/",
      "display_url" : "blog.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "289086655984435200",
  "geo" : { },
  "id_str" : "289087200010850304",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @fabrahamlincoln that sounds like a poor use of everyone's time then :) http:\/\/t.co\/NSdF7pu3 could use some help though",
  "id" : 289087200010850304,
  "in_reply_to_status_id" : 289086655984435200,
  "created_at" : "2013-01-09 19:12:14 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Fabian Perez",
      "screen_name" : "fabrahamlincoln",
      "indices" : [ 13, 29 ],
      "id_str" : "137877410",
      "id" : 137877410
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 60, 71 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289083458817499136",
  "geo" : { },
  "id_str" : "289086149534830592",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @fabrahamlincoln What's wrong with the design? @thoughtbot has sponsored us before. There's so many other problems to solve.",
  "id" : 289086149534830592,
  "in_reply_to_status_id" : 289083458817499136,
  "created_at" : "2013-01-09 19:08:03 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289061542685716481",
  "geo" : { },
  "id_str" : "289066073511297025",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark NOOOOOO",
  "id" : 289066073511297025,
  "in_reply_to_status_id" : 289061542685716481,
  "created_at" : "2013-01-09 17:48:17 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289062172741492736",
  "text" : "RT @aquaranto: Where are all the #codemash ladies?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "codemash",
        "indices" : [ 18, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289057331126362113",
    "text" : "Where are all the #codemash ladies?",
    "id" : 289057331126362113,
    "created_at" : "2013-01-09 17:13:32 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 289062172741492736,
  "created_at" : "2013-01-09 17:32:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/289050615764643842\/photo\/1",
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/O8qm9Xv5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BALqAOsCcAM5zvG.jpg",
      "id_str" : "289050615768838147",
      "id" : 289050615768838147,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BALqAOsCcAM5zvG.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O8qm9Xv5"
    } ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289050615764643842",
  "text" : "Serious Artemis setup at #codemash! http:\/\/t.co\/O8qm9Xv5",
  "id" : 289050615764643842,
  "created_at" : "2013-01-09 16:46:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/289038602216804353\/photo\/1",
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/XwuoW9k1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BALfE8wCEAA-xMT.jpg",
      "id_str" : "289038602225192960",
      "id" : 289038602225192960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BALfE8wCEAA-xMT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XwuoW9k1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289038602216804353",
  "text" : "Behold, thy name is gluttony. http:\/\/t.co\/XwuoW9k1",
  "id" : 289038602216804353,
  "created_at" : "2013-01-09 15:59:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Dammkoehler",
      "screen_name" : "net_zer0",
      "indices" : [ 0, 9 ],
      "id_str" : "16638058",
      "id" : 16638058
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 10, 19 ],
      "id_str" : "7469772",
      "id" : 7469772
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 66, 79 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 80, 95 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289012381193994241",
  "geo" : { },
  "id_str" : "289017991096594432",
  "in_reply_to_user_id" : 16638058,
  "text" : "@net_zer0 @codemash I would love to help with this next year. \/cc @steveklabnik @franklinwebber",
  "id" : 289017991096594432,
  "in_reply_to_status_id" : 289012381193994241,
  "created_at" : "2013-01-09 14:37:13 +0000",
  "in_reply_to_screen_name" : "net_zer0",
  "in_reply_to_user_id_str" : "16638058",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/ADACvlLl",
      "expanded_url" : "https:\/\/gist.github.com\/4491216",
      "display_url" : "gist.github.com\/4491216"
    } ]
  },
  "geo" : { },
  "id_str" : "288903610505506816",
  "text" : "Lots of crazy C code in the original ping. Insane that it's a \"one night hack\" https:\/\/t.co\/ADACvlLl",
  "id" : 288903610505506816,
  "created_at" : "2013-01-09 07:02:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/IdIzKjsI",
      "expanded_url" : "http:\/\/ftp.arl.army.mil\/~mike\/ping.html",
      "display_url" : "ftp.arl.army.mil\/~mike\/ping.html"
    } ]
  },
  "geo" : { },
  "id_str" : "288903058744803328",
  "text" : "\"If I'd known [...] it would be my most famous accomplishment in life, I might have worked on it another day or two\" http:\/\/t.co\/IdIzKjsI",
  "id" : 288903058744803328,
  "created_at" : "2013-01-09 07:00:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288877492947783680",
  "geo" : { },
  "id_str" : "288896296482402304",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden booooo! :(",
  "id" : 288896296482402304,
  "in_reply_to_status_id" : 288877492947783680,
  "created_at" : "2013-01-09 06:33:39 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288895751461937152",
  "text" : "Made it to Kalahari. Let the African tackiness begin! #codemash",
  "id" : 288895751461937152,
  "created_at" : "2013-01-09 06:31:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288828329941929984",
  "text" : "En route to #codemash!",
  "id" : 288828329941929984,
  "created_at" : "2013-01-09 02:03:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 13, 21 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288814848798756864",
  "geo" : { },
  "id_str" : "288820804639133696",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @wnyruby heck yes! You\u2019re more than welcome to stay at the Q house.",
  "id" : 288820804639133696,
  "in_reply_to_status_id" : 288814848798756864,
  "created_at" : "2013-01-09 01:33:40 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 16, 24 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 36, 44 ],
      "id_str" : "632391390",
      "id" : 632391390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288814362829918208",
  "text" : "20 folks in for @wnyruby tonight at @Z80Labs. Love bringing together this community.",
  "id" : 288814362829918208,
  "created_at" : "2013-01-09 01:08:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "indices" : [ 3, 11 ],
      "id_str" : "632391390",
      "id" : 632391390
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 63, 71 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Zvnp0SGb",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/95216982\/?a=ce1_grp&rv=ce1&_af_eid=95216982&_af=event",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288763470797733888",
  "text" : "RT @Z80Labs: Hey #Buffalo - we're hosting the WNY Ruby Meetup (@wnyruby) tonight at 7:30: http:\/\/t.co\/Zvnp0SGb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 50, 58 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/Zvnp0SGb",
        "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/95216982\/?a=ce1_grp&rv=ce1&_af_eid=95216982&_af=event",
        "display_url" : "meetup.com\/Western-New-Yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288687624531636226",
    "text" : "Hey #Buffalo - we're hosting the WNY Ruby Meetup (@wnyruby) tonight at 7:30: http:\/\/t.co\/Zvnp0SGb",
    "id" : 288687624531636226,
    "created_at" : "2013-01-08 16:44:27 +0000",
    "user" : {
      "name" : "Z80 Labs",
      "screen_name" : "Z80Labs",
      "protected" : false,
      "id_str" : "632391390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2392404739\/mq56yhjfsi7ht1pfwckx_normal.png",
      "id" : 632391390,
      "verified" : false
    }
  },
  "id" : 288763470797733888,
  "created_at" : "2013-01-08 21:45:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288750174845693953",
  "geo" : { },
  "id_str" : "288750347441291264",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw Works here. Fucking Cloudfront &gt;:[",
  "id" : 288750347441291264,
  "in_reply_to_status_id" : 288750174845693953,
  "created_at" : "2013-01-08 20:53:42 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Miller",
      "screen_name" : "jqr",
      "indices" : [ 0, 4 ],
      "id_str" : "14351457",
      "id" : 14351457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288745093198925824",
  "geo" : { },
  "id_str" : "288749672288370688",
  "in_reply_to_user_id" : 14351457,
  "text" : "@jqr Me too. I have barely any time to work on the site, and would love this to be contributed.",
  "id" : 288749672288370688,
  "in_reply_to_status_id" : 288745093198925824,
  "created_at" : "2013-01-08 20:51:01 +0000",
  "in_reply_to_screen_name" : "jqr",
  "in_reply_to_user_id_str" : "14351457",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 62 ],
      "url" : "https:\/\/t.co\/bTKGbTAy",
      "expanded_url" : "https:\/\/rpm.newrelic.com\/public\/notes\/k8JdO2LsEUR",
      "display_url" : "rpm.newrelic.com\/public\/notes\/k\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "288745768465084417",
  "geo" : { },
  "id_str" : "288746524136054785",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck Everything seems alright here. https:\/\/t.co\/bTKGbTAy",
  "id" : 288746524136054785,
  "in_reply_to_status_id" : 288745768465084417,
  "created_at" : "2013-01-08 20:38:30 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/YTvllLSn",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/rubyonrails-security\/61bkgvnSGTQ\/discussion",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288743152469307392",
  "text" : "YOU! THE ONE WHO IS PROGRAMMING NOW. EXPERIENCE A RAILS UPGRADE. https:\/\/t.co\/YTvllLSn",
  "id" : 288743152469307392,
  "created_at" : "2013-01-08 20:25:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Eric Sipple",
      "screen_name" : "saalon",
      "indices" : [ 12, 19 ],
      "id_str" : "14860855",
      "id" : 14860855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 41 ],
      "url" : "https:\/\/t.co\/Odzcbdug",
      "expanded_url" : "https:\/\/github.com\/coworkbuffalo\/coworkbuffalo.github.com\/blob\/master\/assets\/index.scss",
      "display_url" : "github.com\/coworkbuffalo\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "288713515517218816",
  "geo" : { },
  "id_str" : "288714911054454785",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @saalon https:\/\/t.co\/Odzcbdug has mixins, variables, and it's pretty small.",
  "id" : 288714911054454785,
  "in_reply_to_status_id" : 288713515517218816,
  "created_at" : "2013-01-08 18:32:53 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288712818830745601",
  "geo" : { },
  "id_str" : "288712879568474112",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella thats the joke",
  "id" : 288712879568474112,
  "in_reply_to_status_id" : 288712818830745601,
  "created_at" : "2013-01-08 18:24:49 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 3, 8 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288712412142657536",
  "text" : "RT @al3x: I can\u2019t take anything published on Svbtle seriously. It\u2019s the yoga studio bulletin board of the World Wide Web.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278956842032435200",
    "text" : "I can\u2019t take anything published on Svbtle seriously. It\u2019s the yoga studio bulletin board of the World Wide Web.",
    "id" : 278956842032435200,
    "created_at" : "2012-12-12 20:17:48 +0000",
    "user" : {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "protected" : false,
      "id_str" : "18713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513088789585993728\/s1DnFxP6_normal.jpeg",
      "id" : 18713,
      "verified" : false
    }
  },
  "id" : 288712412142657536,
  "created_at" : "2013-01-08 18:22:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288708031284379648",
  "text" : "1) Start a private blogging network 2) ???? 3) Profit!",
  "id" : 288708031284379648,
  "created_at" : "2013-01-08 18:05:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Akita",
      "screen_name" : "AkitaOnRails",
      "indices" : [ 0, 13 ],
      "id_str" : "3982931",
      "id" : 3982931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288512513694371840",
  "geo" : { },
  "id_str" : "288512940884230144",
  "in_reply_to_user_id" : 3982931,
  "text" : "@AkitaOnRails wrong link?",
  "id" : 288512940884230144,
  "in_reply_to_status_id" : 288512513694371840,
  "created_at" : "2013-01-08 05:10:20 +0000",
  "in_reply_to_screen_name" : "AkitaOnRails",
  "in_reply_to_user_id_str" : "3982931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 12, 23 ],
      "id_str" : "129873542",
      "id" : 129873542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288509971711262720",
  "geo" : { },
  "id_str" : "288512146030080000",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini @rubybuddha see all the peoples! We get in late tomorrow.",
  "id" : 288512146030080000,
  "in_reply_to_status_id" : 288509971711262720,
  "created_at" : "2013-01-08 05:07:10 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Akita",
      "screen_name" : "AkitaOnRails",
      "indices" : [ 0, 13 ],
      "id_str" : "3982931",
      "id" : 3982931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288511576959483904",
  "geo" : { },
  "id_str" : "288512007546736640",
  "in_reply_to_user_id" : 3982931,
  "text" : "@AkitaOnRails huh?",
  "id" : 288512007546736640,
  "in_reply_to_status_id" : 288511576959483904,
  "created_at" : "2013-01-08 05:06:37 +0000",
  "in_reply_to_screen_name" : "AkitaOnRails",
  "in_reply_to_user_id_str" : "3982931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/k5DmLdNh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=07So_lJQyqw",
      "display_url" : "youtube.com\/watch?v=07So_l\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "288475375963615233",
  "geo" : { },
  "id_str" : "288475591253061633",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik http:\/\/t.co\/k5DmLdNh",
  "id" : 288475591253061633,
  "in_reply_to_status_id" : 288475375963615233,
  "created_at" : "2013-01-08 02:41:55 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288474713473294337",
  "geo" : { },
  "id_str" : "288475264021848064",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik also We\u2019re bringing ALL THE GAMES",
  "id" : 288475264021848064,
  "in_reply_to_status_id" : 288474713473294337,
  "created_at" : "2013-01-08 02:40:37 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288474713473294337",
  "geo" : { },
  "id_str" : "288475136988942336",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik yay! See you there on Wednesday!",
  "id" : 288475136988942336,
  "in_reply_to_status_id" : 288474713473294337,
  "created_at" : "2013-01-08 02:40:06 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    }, {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 9, 22 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "charley baker",
      "screen_name" : "charley_baker",
      "indices" : [ 23, 37 ],
      "id_str" : "14385792",
      "id" : 14385792
    }, {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 38, 43 ],
      "id_str" : "14816059",
      "id" : 14816059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288434317691072512",
  "geo" : { },
  "id_str" : "288435746447163393",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash @stevenharman @charley_baker @chzy nice! We\u2019ll be there very late tomorrow.",
  "id" : 288435746447163393,
  "in_reply_to_status_id" : 288434317691072512,
  "created_at" : "2013-01-08 00:03:35 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 16, 29 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https:\/\/t.co\/DM7vnY7S",
      "expanded_url" : "https:\/\/github.com\/qrush",
      "display_url" : "github.com\/qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "288432500718575616",
  "text" : "Hey, looks like @technoweenie merged CalendarAboutNothing into GitHub! Yay! https:\/\/t.co\/DM7vnY7S",
  "id" : 288432500718575616,
  "created_at" : "2013-01-07 23:50:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 10, 22 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288412470400385026",
  "geo" : { },
  "id_str" : "288415319012298752",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @sstephenson This just feels paranoid to me. For local development I don't see any problems.",
  "id" : 288415319012298752,
  "in_reply_to_status_id" : 288412470400385026,
  "created_at" : "2013-01-07 22:42:25 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288399189895938051",
  "geo" : { },
  "id_str" : "288415157166690307",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette sounds enterprise!",
  "id" : 288415157166690307,
  "in_reply_to_status_id" : 288399189895938051,
  "created_at" : "2013-01-07 22:41:46 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sahil Lavingia",
      "screen_name" : "shl",
      "indices" : [ 3, 7 ],
      "id_str" : "16347964",
      "id" : 16347964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288412552105431040",
  "text" : "RT @shl: \"Are you raising money?\"\n\n\"We raise money every day, from our customers.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279631733941485568",
    "text" : "\"Are you raising money?\"\n\n\"We raise money every day, from our customers.\"",
    "id" : 279631733941485568,
    "created_at" : "2012-12-14 16:59:35 +0000",
    "user" : {
      "name" : "Sahil Lavingia",
      "screen_name" : "shl",
      "protected" : false,
      "id_str" : "16347964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2374496291\/y9a7z6e8xau88v4t6ovh_normal.png",
      "id" : 16347964,
      "verified" : false
    }
  },
  "id" : 288412552105431040,
  "created_at" : "2013-01-07 22:31:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 10, 22 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288411765052678144",
  "geo" : { },
  "id_str" : "288412288619249664",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @sstephenson that's insane if you have lots of projects. What's \"dangerous\" about it?",
  "id" : 288412288619249664,
  "in_reply_to_status_id" : 288411765052678144,
  "created_at" : "2013-01-07 22:30:22 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nolan Brubaker",
      "screen_name" : "palendae",
      "indices" : [ 3, 12 ],
      "id_str" : "29798769",
      "id" : 29798769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288406208493260800",
  "text" : "RT @palendae: So I just saw a bunch of developers piss all over a service that is working to help get them money for their OSS contribut ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288396261349003265",
    "text" : "So I just saw a bunch of developers piss all over a service that is working to help get them money for their OSS contributions.\n\nJesus.",
    "id" : 288396261349003265,
    "created_at" : "2013-01-07 21:26:41 +0000",
    "user" : {
      "name" : "Nolan Brubaker",
      "screen_name" : "palendae",
      "protected" : false,
      "id_str" : "29798769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452113724539535363\/Ig3sB9XE_normal.jpeg",
      "id" : 29798769,
      "verified" : false
    }
  },
  "id" : 288406208493260800,
  "created_at" : "2013-01-07 22:06:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 46, 56 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288393394261204993",
  "geo" : { },
  "id_str" : "288394525125267458",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark This is another reason why I gave @aquaranto a flat one :)",
  "id" : 288394525125267458,
  "in_reply_to_status_id" : 288393394261204993,
  "created_at" : "2013-01-07 21:19:47 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288362272886243328",
  "text" : "OH \"can you take my spit with you?\"",
  "id" : 288362272886243328,
  "created_at" : "2013-01-07 19:11:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/FOW7uwNT",
      "expanded_url" : "http:\/\/nshipster.com\/nil\/",
      "display_url" : "nshipster.com\/nil\/"
    } ]
  },
  "geo" : { },
  "id_str" : "288322020498866176",
  "text" : "Another thing RubyMotion shields you from, this absolute stupidness: http:\/\/t.co\/FOW7uwNT",
  "id" : 288322020498866176,
  "created_at" : "2013-01-07 16:31:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288177124706242562",
  "geo" : { },
  "id_str" : "288177937591713793",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette I don\u2019t understand the need for granular access. Why can\u2019t you trust everyone internally?",
  "id" : 288177937591713793,
  "in_reply_to_status_id" : 288177124706242562,
  "created_at" : "2013-01-07 06:59:09 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288070107832414210",
  "geo" : { },
  "id_str" : "288171566204854272",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette this is way beyond what 37 would need. seems complicated.",
  "id" : 288171566204854272,
  "in_reply_to_status_id" : 288070107832414210,
  "created_at" : "2013-01-07 06:33:50 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288148895408746496",
  "text" : "RT @TweetsofOld: Rochester, the flower or flour city, spell it as you choose, has degenerated, and is now universally known as the beer  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288147044193931264",
    "text" : "Rochester, the flower or flour city, spell it as you choose, has degenerated, and is now universally known as the beer city. NY1879",
    "id" : 288147044193931264,
    "created_at" : "2013-01-07 04:56:23 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 288148895408746496,
  "created_at" : "2013-01-07 05:03:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 3, 17 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 31, 43 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 105, 111 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 116, 126 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288096142032515073",
  "text" : "RT @joshuaclayton: Had some of @whereslloyd's Rocket Sauce tonight and it was absolutely amazing; thanks @qrush and @aquaranto!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 12, 24 ],
        "id_str" : "156689065",
        "id" : 156689065
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 86, 92 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 97, 107 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288095939778981888",
    "text" : "Had some of @whereslloyd's Rocket Sauce tonight and it was absolutely amazing; thanks @qrush and @aquaranto!!!",
    "id" : 288095939778981888,
    "created_at" : "2013-01-07 01:33:19 +0000",
    "user" : {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "protected" : false,
      "id_str" : "10293122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156127762\/Josh-Clayton_normal.png",
      "id" : 10293122,
      "verified" : false
    }
  },
  "id" : 288096142032515073,
  "created_at" : "2013-01-07 01:34:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288068915760861185",
  "geo" : { },
  "id_str" : "288069219726274560",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette we just check the password in. Why not?",
  "id" : 288069219726274560,
  "in_reply_to_status_id" : 288068915760861185,
  "created_at" : "2013-01-06 23:47:08 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054456166277120",
  "geo" : { },
  "id_str" : "288065546304507905",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald agreed",
  "id" : 288065546304507905,
  "in_reply_to_status_id" : 288054456166277120,
  "created_at" : "2013-01-06 23:32:32 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288058996580024320",
  "geo" : { },
  "id_str" : "288065421205184512",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba thanks!",
  "id" : 288065421205184512,
  "in_reply_to_status_id" : 288058996580024320,
  "created_at" : "2013-01-06 23:32:03 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288057264391192576",
  "geo" : { },
  "id_str" : "288065319644307456",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman agreed.",
  "id" : 288065319644307456,
  "in_reply_to_status_id" : 288057264391192576,
  "created_at" : "2013-01-06 23:31:38 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288053906087505923",
  "text" : "I\u2019m really sick of the hero worship around _why. Just feels unhealthy.",
  "id" : 288053906087505923,
  "created_at" : "2013-01-06 22:46:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288040441432113154",
  "geo" : { },
  "id_str" : "288041676772081664",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej what game is that?",
  "id" : 288041676772081664,
  "in_reply_to_status_id" : 288040441432113154,
  "created_at" : "2013-01-06 21:57:41 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 0, 6 ],
      "id_str" : "21778760",
      "id" : 21778760
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 7, 19 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 20, 26 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288035084588695554",
  "geo" : { },
  "id_str" : "288036570529951744",
  "in_reply_to_user_id" : 21778760,
  "text" : "@ntljk @rocketslide @javan YES",
  "id" : 288036570529951744,
  "in_reply_to_status_id" : 288035084588695554,
  "created_at" : "2013-01-06 21:37:24 +0000",
  "in_reply_to_screen_name" : "ntljk",
  "in_reply_to_user_id_str" : "21778760",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/65ScGe4d",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=krb2OdQksMc",
      "display_url" : "youtube.com\/watch?v=krb2Od\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287960684640206848",
  "text" : "Best HN comment on the _why thread...\"This so reminds me of this monty python 'Life of Brian' scene: http:\/\/t.co\/65ScGe4d\"",
  "id" : 287960684640206848,
  "created_at" : "2013-01-06 16:35:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287794174378524673",
  "text" : "@AlMehltretter hey! Lots of networking\u2026and usually beer, not look aid!",
  "id" : 287794174378524673,
  "created_at" : "2013-01-06 05:34:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287748933252419584",
  "geo" : { },
  "id_str" : "287793911559233538",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss \uD83D\uDCA9",
  "id" : 287793911559233538,
  "in_reply_to_status_id" : 287748933252419584,
  "created_at" : "2013-01-06 05:33:10 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/287742440918626304\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/BI72uR1m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_5EObpCMAAEPPu.jpg",
      "id_str" : "287742440927014912",
      "id" : 287742440927014912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_5EObpCMAAEPPu.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/BI72uR1m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287742548758376448",
  "text" : "RT @aquaranto: Buffalo buffalo buffalo buffalo buffalo buffalo http:\/\/t.co\/BI72uR1m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aquaranto\/status\/287742440918626304\/photo\/1",
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/BI72uR1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_5EObpCMAAEPPu.jpg",
        "id_str" : "287742440927014912",
        "id" : 287742440927014912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_5EObpCMAAEPPu.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/BI72uR1m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287742440918626304",
    "text" : "Buffalo buffalo buffalo buffalo buffalo buffalo http:\/\/t.co\/BI72uR1m",
    "id" : 287742440918626304,
    "created_at" : "2013-01-06 02:08:39 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 287742548758376448,
  "created_at" : "2013-01-06 02:09:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Cohen",
      "screen_name" : "jeffcohen",
      "indices" : [ 0, 10 ],
      "id_str" : "14635093",
      "id" : 14635093
    }, {
      "name" : "Cory Flanigan",
      "screen_name" : "seeflanigan",
      "indices" : [ 11, 23 ],
      "id_str" : "17843244",
      "id" : 17843244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/vaoMCA0W",
      "expanded_url" : "http:\/\/guides.rubygems.org\/rubygems-org-api",
      "display_url" : "guides.rubygems.org\/rubygems-org-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "287652090644402176",
  "geo" : { },
  "id_str" : "287661683030257664",
  "in_reply_to_user_id" : 14635093,
  "text" : "@jeffcohen @seeflanigan most of the http:\/\/t.co\/t7WATcFT API is public. http:\/\/t.co\/vaoMCA0W",
  "id" : 287661683030257664,
  "in_reply_to_status_id" : 287652090644402176,
  "created_at" : "2013-01-05 20:47:44 +0000",
  "in_reply_to_screen_name" : "jeffcohen",
  "in_reply_to_user_id_str" : "14635093",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 3, 14 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287472235395022848",
  "text" : "RT @joanofdark: It's huskies all the way down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287423731683434497",
    "text" : "It's huskies all the way down.",
    "id" : 287423731683434497,
    "created_at" : "2013-01-05 05:02:12 +0000",
    "user" : {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "protected" : false,
      "id_str" : "12734002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52337868\/76195_normal.jpeg",
      "id" : 12734002,
      "verified" : false
    }
  },
  "id" : 287472235395022848,
  "created_at" : "2013-01-05 08:14:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287087764128808960",
  "geo" : { },
  "id_str" : "287472137135063040",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat nooo\u2026noo. You buy.",
  "id" : 287472137135063040,
  "in_reply_to_status_id" : 287087764128808960,
  "created_at" : "2013-01-05 08:14:33 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287426007080783874",
  "text" : "@objo 1:BACON",
  "id" : 287426007080783874,
  "created_at" : "2013-01-05 05:11:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287402745122672640",
  "geo" : { },
  "id_str" : "287403739621511168",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents It\u2019ll be NickelCityRubyConf! And details coming soon once we get a venue.",
  "id" : 287403739621511168,
  "in_reply_to_status_id" : 287402745122672640,
  "created_at" : "2013-01-05 03:42:45 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287400124349546496",
  "geo" : { },
  "id_str" : "287403577889157122",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan HUMOR!",
  "id" : 287403577889157122,
  "in_reply_to_status_id" : 287400124349546496,
  "created_at" : "2013-01-05 03:42:07 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287396283554082816",
  "text" : "Super excited to organize a Ruby conference in Buffalo\u2026plans within plans within plans!",
  "id" : 287396283554082816,
  "created_at" : "2013-01-05 03:13:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 52, 60 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/287351729907978241\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/FmArDEfs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_zg4DtCUAAShCa.jpg",
      "id_str" : "287351729916366848",
      "id" : 287351729916366848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_zg4DtCUAAShCa.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/FmArDEfs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287351729907978241",
  "text" : "Don\u2019t put your OCD cutting board in the washer. \/cc @fending http:\/\/t.co\/FmArDEfs",
  "id" : 287351729907978241,
  "created_at" : "2013-01-05 00:16:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "287226421322076160",
  "text" : "DJing in the CoworkBuffalo room. Now playing &lt;&lt;DJ TOPCAT&gt;&gt; #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 287226421322076160,
  "created_at" : "2013-01-04 15:58:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 38, 48 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/OwilDHtR",
      "expanded_url" : "http:\/\/basecamp.com\/uptime",
      "display_url" : "basecamp.com\/uptime"
    } ]
  },
  "geo" : { },
  "id_str" : "287221622094565376",
  "text" : "RT @dhh: Really proud of the ops team @37signals. They managed to get the brand-new Basecamp to four nines in 2012: http:\/\/t.co\/OwilDHtR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 29, 39 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/OwilDHtR",
        "expanded_url" : "http:\/\/basecamp.com\/uptime",
        "display_url" : "basecamp.com\/uptime"
      } ]
    },
    "geo" : { },
    "id_str" : "287219621273169920",
    "text" : "Really proud of the ops team @37signals. They managed to get the brand-new Basecamp to four nines in 2012: http:\/\/t.co\/OwilDHtR",
    "id" : 287219621273169920,
    "created_at" : "2013-01-04 15:31:08 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 287221622094565376,
  "created_at" : "2013-01-04 15:39:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287059614636335104",
  "geo" : { },
  "id_str" : "287059837257400321",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan been listening to Greensky Bluegrass. Don\u2019t Lie is great, lots of full concerts on YouTube.",
  "id" : 287059837257400321,
  "in_reply_to_status_id" : 287059614636335104,
  "created_at" : "2013-01-04 04:56:13 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287035077769195520",
  "geo" : { },
  "id_str" : "287036140492578817",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv haven\u2019t seen this though. Looks like they\u2019re finally writing jokes!",
  "id" : 287036140492578817,
  "in_reply_to_status_id" : 287035077769195520,
  "created_at" : "2013-01-04 03:22:03 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287035077769195520",
  "geo" : { },
  "id_str" : "287035591399444480",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv of course. JUSSSSTICE",
  "id" : 287035591399444480,
  "in_reply_to_status_id" : 287035077769195520,
  "created_at" : "2013-01-04 03:19:52 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287029019172552704",
  "text" : "A wild twitter thread hits you for 9999! You die\u2026",
  "id" : 287029019172552704,
  "created_at" : "2013-01-04 02:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Munc",
      "screen_name" : "muncman",
      "indices" : [ 0, 8 ],
      "id_str" : "3959561",
      "id" : 3959561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286972953986486272",
  "geo" : { },
  "id_str" : "286976251510521856",
  "in_reply_to_user_id" : 3959561,
  "text" : "@muncman I tried to pick up iOS several times and the reality of dealing with XCode, ObjC was just too much. RM stuck for me, and still has.",
  "id" : 286976251510521856,
  "in_reply_to_status_id" : 286972953986486272,
  "created_at" : "2013-01-03 23:24:04 +0000",
  "in_reply_to_screen_name" : "muncman",
  "in_reply_to_user_id_str" : "3959561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Munc",
      "screen_name" : "muncman",
      "indices" : [ 0, 8 ],
      "id_str" : "3959561",
      "id" : 3959561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286972953986486272",
  "geo" : { },
  "id_str" : "286976093985071104",
  "in_reply_to_user_id" : 3959561,
  "text" : "@muncman I guess so? Coming from the Ruby world I don't see why you'd waste your time with XCode, etc anymore. I am biased though :)",
  "id" : 286976093985071104,
  "in_reply_to_status_id" : 286972953986486272,
  "created_at" : "2013-01-03 23:23:27 +0000",
  "in_reply_to_screen_name" : "muncman",
  "in_reply_to_user_id_str" : "3959561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan",
      "screen_name" : "alandipert",
      "indices" : [ 0, 11 ],
      "id_str" : "40270600",
      "id" : 40270600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286968197989670913",
  "geo" : { },
  "id_str" : "286970896768442368",
  "in_reply_to_user_id" : 40270600,
  "text" : "@alandipert these aren't empty files though",
  "id" : 286970896768442368,
  "in_reply_to_status_id" : 286968197989670913,
  "created_at" : "2013-01-03 23:02:48 +0000",
  "in_reply_to_screen_name" : "alandipert",
  "in_reply_to_user_id_str" : "40270600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Munc",
      "screen_name" : "muncman",
      "indices" : [ 0, 8 ],
      "id_str" : "3959561",
      "id" : 3959561
    }, {
      "name" : "_Zach McArtor",
      "screen_name" : "zmcartor",
      "indices" : [ 9, 18 ],
      "id_str" : "19977631",
      "id" : 19977631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286967279739105281",
  "geo" : { },
  "id_str" : "286970545919098880",
  "in_reply_to_user_id" : 3959561,
  "text" : "@muncman @zmcartor Most of those are obj-c\/xcode specific. maybe the only one is &gt; 1 class per file, but that's just lazy coding.",
  "id" : 286970545919098880,
  "in_reply_to_status_id" : 286967279739105281,
  "created_at" : "2013-01-03 23:01:24 +0000",
  "in_reply_to_screen_name" : "muncman",
  "in_reply_to_user_id_str" : "3959561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 54, 64 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286966539331174401",
  "text" : "Yet another day that I love being a software mechanic @37signals. Apps need tuneups and oil changes sometimes too.",
  "id" : 286966539331174401,
  "created_at" : "2013-01-03 22:45:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Munc",
      "screen_name" : "muncman",
      "indices" : [ 0, 8 ],
      "id_str" : "3959561",
      "id" : 3959561
    }, {
      "name" : "_Zach McArtor",
      "screen_name" : "zmcartor",
      "indices" : [ 9, 18 ],
      "id_str" : "19977631",
      "id" : 19977631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286964739991556096",
  "geo" : { },
  "id_str" : "286965633369899009",
  "in_reply_to_user_id" : 3959561,
  "text" : "@muncman @zmcartor testing",
  "id" : 286965633369899009,
  "in_reply_to_status_id" : 286964739991556096,
  "created_at" : "2013-01-03 22:41:53 +0000",
  "in_reply_to_screen_name" : "muncman",
  "in_reply_to_user_id_str" : "3959561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "indices" : [ 3, 13 ],
      "id_str" : "699463",
      "id" : 699463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286957723952750593",
  "text" : "RT @sandofsky: Unsolicited redesigns are a designer's Star Trek fan fiction.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286957597993619456",
    "text" : "Unsolicited redesigns are a designer's Star Trek fan fiction.",
    "id" : 286957597993619456,
    "created_at" : "2013-01-03 22:09:57 +0000",
    "user" : {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "protected" : false,
      "id_str" : "699463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559402317724655616\/AzzPv12Z_normal.jpeg",
      "id" : 699463,
      "verified" : false
    }
  },
  "id" : 286957723952750593,
  "created_at" : "2013-01-03 22:10:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286933565416026112",
  "text" : "Clear your Rails app of empty helpers: `find app\/helpers -type f | xargs wc -l | grep '^ *2 ' | awk '\u007Bprint $2\u007D' | xargs rm`",
  "id" : 286933565416026112,
  "created_at" : "2013-01-03 20:34:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286881289745879040",
  "text" : "Looking for some examples of email-only games...did anyone play any?",
  "id" : 286881289745879040,
  "created_at" : "2013-01-03 17:06:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286877441677488128",
  "geo" : { },
  "id_str" : "286878237689278465",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic sure, but most people don't know how to do that. this isn't aimed at sysadmins ;)",
  "id" : 286878237689278465,
  "in_reply_to_status_id" : 286877441677488128,
  "created_at" : "2013-01-03 16:54:36 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/3U2tiTQ3",
      "expanded_url" : "http:\/\/www.vim.org\/scripts\/script.php?script_id=1813",
      "display_url" : "vim.org\/scripts\/script\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "286876001152159745",
  "geo" : { },
  "id_str" : "286876439029092352",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc you need greplace.vim then. :Gsearch \"term\", replace as needed in buffer, :Greplace. http:\/\/t.co\/3U2tiTQ3",
  "id" : 286876439029092352,
  "in_reply_to_status_id" : 286876001152159745,
  "created_at" : "2013-01-03 16:47:27 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Ryan Wilcox",
      "screen_name" : "rwilcox",
      "indices" : [ 13, 21 ],
      "id_str" : "11766092",
      "id" : 11766092
    }, {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 22, 34 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286869670928191489",
  "geo" : { },
  "id_str" : "286870038596706304",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza @rwilcox @marcoarment did you start listening to phish yet?",
  "id" : 286870038596706304,
  "in_reply_to_status_id" : 286869670928191489,
  "created_at" : "2013-01-03 16:22:01 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/JDVBlKN1",
      "expanded_url" : "http:\/\/vimeo.com\/56651783",
      "display_url" : "vimeo.com\/56651783"
    } ]
  },
  "geo" : { },
  "id_str" : "286867137522446336",
  "text" : "Great introduction to Breeze: http:\/\/t.co\/JDVBlKN1",
  "id" : 286867137522446336,
  "created_at" : "2013-01-03 16:10:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/d9TRzTtv",
      "expanded_url" : "http:\/\/ashfurrow.com\/blog\/seven-deadly-sins-of-modern-objective-c",
      "display_url" : "ashfurrow.com\/blog\/seven-dea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286862675420516352",
  "text" : "It's a good sign that using RubyMotion lets you avoid 6\/7 of these \"sins\": http:\/\/t.co\/d9TRzTtv",
  "id" : 286862675420516352,
  "created_at" : "2013-01-03 15:52:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286691507577159682",
  "geo" : { },
  "id_str" : "286691708182335488",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza FAAAAAAAAAAAART",
  "id" : 286691708182335488,
  "in_reply_to_status_id" : 286691507577159682,
  "created_at" : "2013-01-03 04:33:24 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 74, 83 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 85, 96 ],
      "id_str" : "1742",
      "id" : 1742
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 102, 109 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 66 ],
      "url" : "https:\/\/t.co\/jo9xCCmD",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/rbenv#simple-ruby-version-management-rbenv",
      "display_url" : "github.com\/sstephenson\/rb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286665109667975168",
  "text" : "RT @sstephenson: A positive pitch for rbenv: https:\/\/t.co\/jo9xCCmD Thanks @bitsweat, @trevorturk, and @mislav for the help.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Kemper",
        "screen_name" : "bitsweat",
        "indices" : [ 57, 66 ],
        "id_str" : "9462972",
        "id" : 9462972
      }, {
        "name" : "Trevor Turk",
        "screen_name" : "trevorturk",
        "indices" : [ 68, 79 ],
        "id_str" : "1742",
        "id" : 1742
      }, {
        "name" : "Mislav Marohni\u0107",
        "screen_name" : "mislav",
        "indices" : [ 85, 92 ],
        "id_str" : "7516242",
        "id" : 7516242
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 49 ],
        "url" : "https:\/\/t.co\/jo9xCCmD",
        "expanded_url" : "https:\/\/github.com\/sstephenson\/rbenv#simple-ruby-version-management-rbenv",
        "display_url" : "github.com\/sstephenson\/rb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286663609973633024",
    "text" : "A positive pitch for rbenv: https:\/\/t.co\/jo9xCCmD Thanks @bitsweat, @trevorturk, and @mislav for the help.",
    "id" : 286663609973633024,
    "created_at" : "2013-01-03 02:41:45 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 286665109667975168,
  "created_at" : "2013-01-03 02:47:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/6XvHz5Rx",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/?fromgroups=#!topic\/rubyonrails-security\/DCNTNp_qjFM",
      "display_url" : "groups.google.com\/forum\/?fromgro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286607477338935299",
  "text" : "Please please upgrade your Rails apps. Already deployed 4 today. https:\/\/t.co\/6XvHz5Rx",
  "id" : 286607477338935299,
  "created_at" : "2013-01-02 22:58:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 20, 28 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286602729797861377",
  "geo" : { },
  "id_str" : "286606987301625857",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes pretty sure @jayunit is on the hunt!",
  "id" : 286606987301625857,
  "in_reply_to_status_id" : 286602729797861377,
  "created_at" : "2013-01-02 22:56:45 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/JFemuaPe",
      "expanded_url" : "http:\/\/www.reddit.com\/user\/RATES_CASTLES",
      "display_url" : "reddit.com\/user\/RATES_CAS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286584641559859201",
  "text" : "Best novelty Reddit account so far of 2013, RATES_CASTLES: http:\/\/t.co\/JFemuaPe",
  "id" : 286584641559859201,
  "created_at" : "2013-01-02 21:27:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 7, 13 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286569475589947392",
  "geo" : { },
  "id_str" : "286578284555288576",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr @mattt test a lot? no idea about gems for this.",
  "id" : 286578284555288576,
  "in_reply_to_status_id" : 286569475589947392,
  "created_at" : "2013-01-02 21:02:42 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "286550427808448512",
  "text" : "DJing in the CoworkBuffalo room. Now playing Arty Fufkin #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 286550427808448512,
  "created_at" : "2013-01-02 19:12:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 51, 61 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/VbZoWgqj",
      "expanded_url" : "http:\/\/basecamp.com\/breeze",
      "display_url" : "basecamp.com\/breeze"
    } ]
  },
  "geo" : { },
  "id_str" : "286519085565624321",
  "text" : "Excited to see Breeze launch, and for our products @37signals to reach a whole new group of people. http:\/\/t.co\/VbZoWgqj",
  "id" : 286519085565624321,
  "created_at" : "2013-01-02 17:07:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Chad Whitacre",
      "screen_name" : "whit537",
      "indices" : [ 9, 17 ],
      "id_str" : "34175404",
      "id" : 34175404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 88, 109 ],
      "url" : "https:\/\/t.co\/v7ZrRgKC",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/wiki\/Contribution-Guidelines",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "286510250578833408",
  "geo" : { },
  "id_str" : "286510855783346177",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @whit537 http:\/\/t.co\/bdjsRgTW has followed the rubinius model since the start. https:\/\/t.co\/v7ZrRgKC Building a team != Commit bit.",
  "id" : 286510855783346177,
  "in_reply_to_status_id" : 286510250578833408,
  "created_at" : "2013-01-02 16:34:45 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/OwM5wT9y",
      "expanded_url" : "http:\/\/truth-out.org\/news\/item\/13645-how-bicycling-is-transforming-business",
      "display_url" : "truth-out.org\/news\/item\/1364\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286481520225558528",
  "text" : "RT @NYWineWench: Buffalo, take note. Cities expand bicycling infrastructure to attract young people:  http:\/\/t.co\/OwM5wT9y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/OwM5wT9y",
        "expanded_url" : "http:\/\/truth-out.org\/news\/item\/13645-how-bicycling-is-transforming-business",
        "display_url" : "truth-out.org\/news\/item\/1364\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286480762281287682",
    "text" : "Buffalo, take note. Cities expand bicycling infrastructure to attract young people:  http:\/\/t.co\/OwM5wT9y",
    "id" : 286480762281287682,
    "created_at" : "2013-01-02 14:35:10 +0000",
    "user" : {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "protected" : false,
      "id_str" : "72991857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553240923862089728\/a60saFx7_normal.jpeg",
      "id" : 72991857,
      "verified" : false
    }
  },
  "id" : 286481520225558528,
  "created_at" : "2013-01-02 14:38:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 3, 9 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 34, 43 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 60, 66 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 68, 78 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286310452118577156",
  "text" : "RT @parkr: Had an awesome time at @openhack in Buffalo with @qrush, @aquaranto &amp; co. Cool to meet everyone &amp; was productive. Tha ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 23, 32 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 49, 55 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 57, 67 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286297679066185728",
    "text" : "Had an awesome time at @openhack in Buffalo with @qrush, @aquaranto &amp; co. Cool to meet everyone &amp; was productive. Thanks for the invite!",
    "id" : 286297679066185728,
    "created_at" : "2013-01-02 02:27:40 +0000",
    "user" : {
      "name" : "Parker",
      "screen_name" : "parkr",
      "protected" : false,
      "id_str" : "1928021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518473290554146816\/vMQWizt5_normal.jpeg",
      "id" : 1928021,
      "verified" : false
    }
  },
  "id" : 286310452118577156,
  "created_at" : "2013-01-02 03:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286307924471578624",
  "geo" : { },
  "id_str" : "286310420271218688",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant yes. So good. Iron man!!",
  "id" : 286310420271218688,
  "in_reply_to_status_id" : 286307924471578624,
  "created_at" : "2013-01-02 03:18:18 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Iacono",
      "screen_name" : "jfi",
      "indices" : [ 0, 4 ],
      "id_str" : "23231331",
      "id" : 23231331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286243426868031488",
  "in_reply_to_user_id" : 23231331,
  "text" : "@jfi hey, it's nick [at] quaran.to",
  "id" : 286243426868031488,
  "created_at" : "2013-01-01 22:52:05 +0000",
  "in_reply_to_screen_name" : "jfi",
  "in_reply_to_user_id_str" : "23231331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/yt1kMg66",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/",
      "display_url" : "coworkbuffalo.com\/newsletter\/"
    } ]
  },
  "geo" : { },
  "id_str" : "286212417569034240",
  "text" : "RT @coworkbuffalo: We've posted our email newsletters up for all to see: http:\/\/t.co\/yt1kMg66 Sign up there to receive them hot out of t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/yt1kMg66",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/",
        "display_url" : "coworkbuffalo.com\/newsletter\/"
      } ]
    },
    "geo" : { },
    "id_str" : "286211434122207234",
    "text" : "We've posted our email newsletters up for all to see: http:\/\/t.co\/yt1kMg66 Sign up there to receive them hot out of the Markdown oven!",
    "id" : 286211434122207234,
    "created_at" : "2013-01-01 20:44:58 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 286212417569034240,
  "created_at" : "2013-01-01 20:48:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286185993684545536",
  "geo" : { },
  "id_str" : "286186861007872000",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j that\u2019s no moon\u2026",
  "id" : 286186861007872000,
  "in_reply_to_status_id" : 286185993684545536,
  "created_at" : "2013-01-01 19:07:19 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 0, 14 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286177301480239104",
  "geo" : { },
  "id_str" : "286186388607619072",
  "in_reply_to_user_id" : 491801330,
  "text" : "@coworkbuffalo crap I have to build tables both real and virtual today?!",
  "id" : 286186388607619072,
  "in_reply_to_status_id" : 286177301480239104,
  "created_at" : "2013-01-01 19:05:26 +0000",
  "in_reply_to_screen_name" : "coworkbuffalo",
  "in_reply_to_user_id_str" : "491801330",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 6, 15 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/Y8KaiEh5",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/94844072\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286130716130017280",
  "text" : "Also, @OpenHack Buffalo is tonight! http:\/\/t.co\/Y8KaiEh5",
  "id" : 286130716130017280,
  "created_at" : "2013-01-01 15:24:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/loZh39Sn",
      "expanded_url" : "http:\/\/quaran.to\/2012\/",
      "display_url" : "quaran.to\/2012\/"
    } ]
  },
  "geo" : { },
  "id_str" : "286130494410739712",
  "text" : "Hi 2013! And thanks, 2012: http:\/\/t.co\/loZh39Sn",
  "id" : 286130494410739712,
  "created_at" : "2013-01-01 15:23:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286130391025332224",
  "text" : "RT @coworkbuffalo: We are up and open. Happy 2013!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286130291045724162",
    "text" : "We are up and open. Happy 2013!",
    "id" : 286130291045724162,
    "created_at" : "2013-01-01 15:22:32 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 286130391025332224,
  "created_at" : "2013-01-01 15:22:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
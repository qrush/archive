Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495021589038379008",
  "geo" : { },
  "id_str" : "495022231097835521",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris Commencing countdown, engines on",
  "id" : 495022231097835521,
  "in_reply_to_status_id" : 495021589038379008,
  "created_at" : "2014-08-01 01:44:31 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/494973997218422787\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/V9eKvIEKHa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt6AOcOCUAAqBI6.jpg",
      "id_str" : "494973994638921728",
      "id" : 494973994638921728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt6AOcOCUAAqBI6.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/V9eKvIEKHa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245685647, -78.8793559001 ]
  },
  "id_str" : "494973997218422787",
  "text" : "Actual current status http:\/\/t.co\/V9eKvIEKHa",
  "id" : 494973997218422787,
  "created_at" : "2014-07-31 22:32:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/05clWE1uSu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wusGIl3v044",
      "display_url" : "youtube.com\/watch?v=wusGIl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494972287381028864",
  "text" : "Current status https:\/\/t.co\/05clWE1uSu",
  "id" : 494972287381028864,
  "created_at" : "2014-07-31 22:26:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494957433999994880",
  "geo" : { },
  "id_str" : "494957643853594625",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik don't look at the bathroom photos for these listings",
  "id" : 494957643853594625,
  "in_reply_to_status_id" : 494957433999994880,
  "created_at" : "2014-07-31 21:27:52 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istvan Hoka",
      "screen_name" : "ihoka",
      "indices" : [ 0, 6 ],
      "id_str" : "3309751",
      "id" : 3309751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494735405317505024",
  "geo" : { },
  "id_str" : "494953824184844288",
  "in_reply_to_user_id" : 3309751,
  "text" : "@ihoka the iPad app is in ObjC.",
  "id" : 494953824184844288,
  "in_reply_to_status_id" : 494735405317505024,
  "created_at" : "2014-07-31 21:12:42 +0000",
  "in_reply_to_screen_name" : "ihoka",
  "in_reply_to_user_id_str" : "3309751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimball Fink-Jensen",
      "screen_name" : "kfinkjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "15699712",
      "id" : 15699712
    }, {
      "name" : "Jonno the Fusspot",
      "screen_name" : "JonnoTheFusspot",
      "indices" : [ 13, 29 ],
      "id_str" : "72127378",
      "id" : 72127378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494939756535377920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9093019255, -78.878398053 ]
  },
  "id_str" : "494944524838268928",
  "in_reply_to_user_id" : 15699712,
  "text" : "@kfinkjensen @JonnoTheFusspot correct",
  "id" : 494944524838268928,
  "in_reply_to_status_id" : 494939756535377920,
  "created_at" : "2014-07-31 20:35:45 +0000",
  "in_reply_to_screen_name" : "kfinkjensen",
  "in_reply_to_user_id_str" : "15699712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 0, 12 ],
      "id_str" : "15387091",
      "id" : 15387091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494924394997637121",
  "geo" : { },
  "id_str" : "494924802864320512",
  "in_reply_to_user_id" : 15387091,
  "text" : "@levineuland Ah.",
  "id" : 494924802864320512,
  "in_reply_to_status_id" : 494924394997637121,
  "created_at" : "2014-07-31 19:17:22 +0000",
  "in_reply_to_screen_name" : "levineuland",
  "in_reply_to_user_id_str" : "15387091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/XYkbSiKJmD",
      "expanded_url" : "https:\/\/developer.apple.com\/library\/ios\/documentation\/Cocoa\/Conceptual\/DatesAndTimes\/Articles\/dtCalendricalCalculations.html#\/\/apple_ref\/doc\/uid\/TP40007836-SW3",
      "display_url" : "developer.apple.com\/library\/ios\/do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494923628668911618",
  "text" : "\"\/\/ Calculate when, according to Tom Lehrer, World War III will end\" WTF APPLE? https:\/\/t.co\/XYkbSiKJmD",
  "id" : 494923628668911618,
  "created_at" : "2014-07-31 19:12:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494922836101058561",
  "geo" : { },
  "id_str" : "494923336002977792",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik Been doing this for at least a month. Maybe two. So tired of it.",
  "id" : 494923336002977792,
  "in_reply_to_status_id" : 494922836101058561,
  "created_at" : "2014-07-31 19:11:33 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494923248774037505",
  "text" : "When you know you're too deep in the docs, this section header comes up: \"Working with Eras with Backward Time Flow\"",
  "id" : 494923248774037505,
  "created_at" : "2014-07-31 19:11:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 79, 90 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/494920438938488833\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/wDqFKBwInr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt5PhCHCUAAu7cw.png",
      "id_str" : "494920437977993216",
      "id" : 494920437977993216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt5PhCHCUAAu7cw.png",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/wDqFKBwInr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494920438938488833",
  "text" : "Maybe took \"I\u2019d like to hear what it means to you\" too literally on the latest @thoughtbot post. http:\/\/t.co\/wDqFKBwInr",
  "id" : 494920438938488833,
  "created_at" : "2014-07-31 19:00:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/494919669875089409\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/n7YCTgaZtL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt5O0PACIAAC3Fc.png",
      "id_str" : "494919668344168448",
      "id" : 494919668344168448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt5O0PACIAAC3Fc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1244,
        "resize" : "fit",
        "w" : 1662
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/n7YCTgaZtL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494919669875089409",
  "text" : "Stress relief: frying fish. http:\/\/t.co\/n7YCTgaZtL",
  "id" : 494919669875089409,
  "created_at" : "2014-07-31 18:56:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 115, 121 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 132, 140 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/oRmd1hmU4q",
      "expanded_url" : "http:\/\/www.aqueousband.net\/",
      "display_url" : "aqueousband.net"
    } ]
  },
  "geo" : { },
  "id_str" : "494889819265171456",
  "text" : "RT @UnclePhilsBlog: #AQnet has new stuff! Upcoming shows, recent media etc http:\/\/t.co\/oRmd1hmU4q  Check it out! A @qrush creation. @Aqueou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 95, 101 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 112, 124 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "AQband",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/oRmd1hmU4q",
        "expanded_url" : "http:\/\/www.aqueousband.net\/",
        "display_url" : "aqueousband.net"
      } ]
    },
    "geo" : { },
    "id_str" : "494889749862449152",
    "text" : "#AQnet has new stuff! Upcoming shows, recent media etc http:\/\/t.co\/oRmd1hmU4q  Check it out! A @qrush creation. @AqueousBand #AQband",
    "id" : 494889749862449152,
    "created_at" : "2014-07-31 16:58:05 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 494889819265171456,
  "created_at" : "2014-07-31 16:58:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brown",
      "screen_name" : "jtbrown",
      "indices" : [ 0, 8 ],
      "id_str" : "18850537",
      "id" : 18850537
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 9, 15 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494860920947240960",
  "geo" : { },
  "id_str" : "494883369348390912",
  "in_reply_to_user_id" : 18850537,
  "text" : "@jtbrown @mattt are you using this in any apps yet? Feels a lot like AFN in Swift. Was hoping for something else, maybe :)",
  "id" : 494883369348390912,
  "in_reply_to_status_id" : 494860920947240960,
  "created_at" : "2014-07-31 16:32:44 +0000",
  "in_reply_to_screen_name" : "jtbrown",
  "in_reply_to_user_id_str" : "18850537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brown",
      "screen_name" : "jtbrown",
      "indices" : [ 3, 11 ],
      "id_str" : "18850537",
      "id" : 18850537
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 55, 61 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/OYXnC8CHc4",
      "expanded_url" : "https:\/\/github.com\/Alamofire\/Alamofire",
      "display_url" : "github.com\/Alamofire\/Alam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494877623227396096",
  "text" : "RT @jtbrown: Alamofire: Elegant Networking in Swift by @mattt https:\/\/t.co\/OYXnC8CHc4\n\nCool.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mattt Thompson",
        "screen_name" : "mattt",
        "indices" : [ 42, 48 ],
        "id_str" : "35803",
        "id" : 35803
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/OYXnC8CHc4",
        "expanded_url" : "https:\/\/github.com\/Alamofire\/Alamofire",
        "display_url" : "github.com\/Alamofire\/Alam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494860920947240960",
    "text" : "Alamofire: Elegant Networking in Swift by @mattt https:\/\/t.co\/OYXnC8CHc4\n\nCool.",
    "id" : 494860920947240960,
    "created_at" : "2014-07-31 15:03:32 +0000",
    "user" : {
      "name" : "Josh Brown",
      "screen_name" : "jtbrown",
      "protected" : false,
      "id_str" : "18850537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000106061928\/5f016f2c52cdc99a30da442e1a22922d_normal.jpeg",
      "id" : 18850537,
      "verified" : false
    }
  },
  "id" : 494877623227396096,
  "created_at" : "2014-07-31 16:09:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 10, 25 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494874167603249152",
  "geo" : { },
  "id_str" : "494874893024903168",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @UnclePhilsBlog we need a photo up there!",
  "id" : 494874893024903168,
  "in_reply_to_status_id" : 494874167603249152,
  "created_at" : "2014-07-31 15:59:03 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 14, 25 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/s12TwA9gQZ",
      "expanded_url" : "http:\/\/thesweethome.com\/reviews\/best-trash-can\/",
      "display_url" : "thesweethome.com\/reviews\/best-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494871248908742659",
  "text" : "The fruits of @kevinpurdy's labors: The Best Kitchen Trash Can  http:\/\/t.co\/s12TwA9gQZ",
  "id" : 494871248908742659,
  "created_at" : "2014-07-31 15:44:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "justinromack",
      "screen_name" : "justinromack",
      "indices" : [ 0, 13 ],
      "id_str" : "11214822",
      "id" : 11214822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494864609589751810",
  "geo" : { },
  "id_str" : "494866141261463552",
  "in_reply_to_user_id" : 11214822,
  "text" : "@justinromack @JZ Really it was just one: Button text is now easier to read when Button Shapes is on. But yes...more!!",
  "id" : 494866141261463552,
  "in_reply_to_status_id" : 494864609589751810,
  "created_at" : "2014-07-31 15:24:16 +0000",
  "in_reply_to_screen_name" : "justinromack",
  "in_reply_to_user_id_str" : "11214822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 26, 32 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/WcO4fKntVr",
      "expanded_url" : "http:\/\/livephish.com\/",
      "display_url" : "livephish.com"
    } ]
  },
  "geo" : { },
  "id_str" : "494863946898108417",
  "text" : "What! FREE HD webcast for @Phish's showt this weekend. Never miss a Sunday show. http:\/\/t.co\/WcO4fKntVr",
  "id" : 494863946898108417,
  "created_at" : "2014-07-31 15:15:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/hvcGU9AScL",
      "expanded_url" : "http:\/\/37svn.com\/3766",
      "display_url" : "37svn.com\/3766"
    } ]
  },
  "geo" : { },
  "id_str" : "494863369652813824",
  "text" : "A great look into how we structured and built Basecamp's iPad app hand in hand with Rails: http:\/\/t.co\/hvcGU9AScL",
  "id" : 494863369652813824,
  "created_at" : "2014-07-31 15:13:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 34, 44 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/HN2T6onoUp",
      "expanded_url" : "http:\/\/bit.ly\/1s7bf84",
      "display_url" : "bit.ly\/1s7bf84"
    } ]
  },
  "geo" : { },
  "id_str" : "494862575591387137",
  "text" : "RT @JZ: We're getting big results @37signals building hybrid apps with tiny teams. Heres a deep look at how: http:\/\/t.co\/HN2T6onoUp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 26, 36 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/HN2T6onoUp",
        "expanded_url" : "http:\/\/bit.ly\/1s7bf84",
        "display_url" : "bit.ly\/1s7bf84"
      } ]
    },
    "geo" : { },
    "id_str" : "494862451146383362",
    "text" : "We're getting big results @37signals building hybrid apps with tiny teams. Heres a deep look at how: http:\/\/t.co\/HN2T6onoUp",
    "id" : 494862451146383362,
    "created_at" : "2014-07-31 15:09:37 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 494862575591387137,
  "created_at" : "2014-07-31 15:10:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Green",
      "screen_name" : "jagthedrummer",
      "indices" : [ 0, 14 ],
      "id_str" : "19013274",
      "id" : 19013274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/cJFh5Fi1gK",
      "expanded_url" : "http:\/\/phish.net\/song\/the-lizards",
      "display_url" : "phish.net\/song\/the-lizar\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "494857483643404289",
  "geo" : { },
  "id_str" : "494859695375409153",
  "in_reply_to_user_id" : 19013274,
  "text" : "@jagthedrummer every 5 shows on average, 303 plays...not exactly rare. Just enough. http:\/\/t.co\/cJFh5Fi1gK",
  "id" : 494859695375409153,
  "in_reply_to_status_id" : 494857483643404289,
  "created_at" : "2014-07-31 14:58:40 +0000",
  "in_reply_to_screen_name" : "jagthedrummer",
  "in_reply_to_user_id_str" : "19013274",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 25, 39 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494855057154658305",
  "text" : "Busy and productive week @coworkbuffalo. Happy to see the space bustling!!",
  "id" : 494855057154658305,
  "created_at" : "2014-07-31 14:40:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Green",
      "screen_name" : "jagthedrummer",
      "indices" : [ 0, 14 ],
      "id_str" : "19013274",
      "id" : 19013274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494853806849404928",
  "geo" : { },
  "id_str" : "494854329111543810",
  "in_reply_to_user_id" : 19013274,
  "text" : "@jagthedrummer Encore last night!",
  "id" : 494854329111543810,
  "in_reply_to_status_id" : 494853806849404928,
  "created_at" : "2014-07-31 14:37:20 +0000",
  "in_reply_to_screen_name" : "jagthedrummer",
  "in_reply_to_user_id_str" : "19013274",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494820207756869632",
  "geo" : { },
  "id_str" : "494849847552245761",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown thanks!",
  "id" : 494849847552245761,
  "in_reply_to_status_id" : 494820207756869632,
  "created_at" : "2014-07-31 14:19:32 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Xg1GqSXZg1",
      "expanded_url" : "http:\/\/aqueousband.net",
      "display_url" : "aqueousband.net"
    } ]
  },
  "geo" : { },
  "id_str" : "494819285995237377",
  "text" : "Made the homepage for http:\/\/t.co\/Xg1GqSXZg1 way more interesting last night. Feels like a real website now!",
  "id" : 494819285995237377,
  "created_at" : "2014-07-31 12:18:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 0, 15 ],
      "id_str" : "130242651",
      "id" : 130242651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494804864678240256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243440135, -78.8791335282 ]
  },
  "id_str" : "494806933669281792",
  "in_reply_to_user_id" : 130242651,
  "text" : "@Chris_Langford tell me about it",
  "id" : 494806933669281792,
  "in_reply_to_status_id" : 494804864678240256,
  "created_at" : "2014-07-31 11:29:00 +0000",
  "in_reply_to_screen_name" : "Chris_Langford",
  "in_reply_to_user_id_str" : "130242651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494682836755304448",
  "geo" : { },
  "id_str" : "494683165332484097",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy :( My dad's a fire captain there. Not sure if he was on or not.",
  "id" : 494683165332484097,
  "in_reply_to_status_id" : 494682836755304448,
  "created_at" : "2014-07-31 03:17:12 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 0, 15 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494681414001238017",
  "geo" : { },
  "id_str" : "494681943905013762",
  "in_reply_to_user_id" : 129537034,
  "text" : "@death2normalcy Just awful. Saw the smoke from my place.",
  "id" : 494681943905013762,
  "in_reply_to_status_id" : 494681414001238017,
  "created_at" : "2014-07-31 03:12:20 +0000",
  "in_reply_to_screen_name" : "death2normalcy",
  "in_reply_to_user_id_str" : "129537034",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494681430123741186",
  "text" : "Lizards!!!",
  "id" : 494681430123741186,
  "created_at" : "2014-07-31 03:10:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Krawczyk",
      "screen_name" : "KatieKraw",
      "indices" : [ 0, 10 ],
      "id_str" : "48773551",
      "id" : 48773551
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 11, 22 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494654997368680448",
  "geo" : { },
  "id_str" : "494677427818209280",
  "in_reply_to_user_id" : 48773551,
  "text" : "@KatieKraw @dangigante woot woot :)",
  "id" : 494677427818209280,
  "in_reply_to_status_id" : 494654997368680448,
  "created_at" : "2014-07-31 02:54:24 +0000",
  "in_reply_to_screen_name" : "KatieKraw",
  "in_reply_to_user_id_str" : "48773551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 88, 103 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/aEgODQd9cJ",
      "expanded_url" : "http:\/\/www.bizjournals.com\/buffalo\/news\/2014\/07\/30\/plenty-of-new-restaurants-slated-to-open-in.html",
      "display_url" : "bizjournals.com\/buffalo\/news\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494663084170956800",
  "text" : "Awesome news: Several new restaurants opening in Buffalo all within walking distance of @nickelcityruby: http:\/\/t.co\/aEgODQd9cJ",
  "id" : 494663084170956800,
  "created_at" : "2014-07-31 01:57:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimball Fink-Jensen",
      "screen_name" : "kfinkjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "15699712",
      "id" : 15699712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494627387959558146",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243987827, -78.8792055892 ]
  },
  "id_str" : "494629008445698048",
  "in_reply_to_user_id" : 15699712,
  "text" : "@kfinkjensen yeah jury is out on that for now. Syncing is not easy. The rest of the app isn\u2019t really offline capable.",
  "id" : 494629008445698048,
  "in_reply_to_status_id" : 494627387959558146,
  "created_at" : "2014-07-30 23:42:00 +0000",
  "in_reply_to_screen_name" : "kfinkjensen",
  "in_reply_to_user_id_str" : "15699712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimball Fink-Jensen",
      "screen_name" : "kfinkjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "15699712",
      "id" : 15699712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494621439010418688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240750705, -78.8802319473 ]
  },
  "id_str" : "494626225470459904",
  "in_reply_to_user_id" : 15699712,
  "text" : "@kfinkjensen you can do this for todolosts in the same project.",
  "id" : 494626225470459904,
  "in_reply_to_status_id" : 494621439010418688,
  "created_at" : "2014-07-30 23:30:56 +0000",
  "in_reply_to_screen_name" : "kfinkjensen",
  "in_reply_to_user_id_str" : "15699712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Borsa",
      "screen_name" : "JohnBorsa",
      "indices" : [ 3, 13 ],
      "id_str" : "18756512",
      "id" : 18756512
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JohnBorsa\/status\/494619376121679872\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/KCU6ULvCz2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt09s6bCMAIlplo.jpg",
      "id_str" : "494619375886807042",
      "id" : 494619375886807042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt09s6bCMAIlplo.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/KCU6ULvCz2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494621811523342336",
  "text" : "RT @JohnBorsa: Buffalo Fire on the 800 Block of Elmwood Ave. for major house fire. http:\/\/t.co\/KCU6ULvCz2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JohnBorsa\/status\/494619376121679872\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/KCU6ULvCz2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt09s6bCMAIlplo.jpg",
        "id_str" : "494619375886807042",
        "id" : 494619375886807042,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt09s6bCMAIlplo.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/KCU6ULvCz2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494619376121679872",
    "text" : "Buffalo Fire on the 800 Block of Elmwood Ave. for major house fire. http:\/\/t.co\/KCU6ULvCz2",
    "id" : 494619376121679872,
    "created_at" : "2014-07-30 23:03:43 +0000",
    "user" : {
      "name" : "John Borsa",
      "screen_name" : "JohnBorsa",
      "protected" : false,
      "id_str" : "18756512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523155087058018304\/lVCaDvJa_normal.jpeg",
      "id" : 18756512,
      "verified" : false
    }
  },
  "id" : 494621811523342336,
  "created_at" : "2014-07-30 23:13:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/BRjZsyC0h3",
      "expanded_url" : "https:\/\/twitter.com\/FindFrankNow\/status\/494612096500649986",
      "display_url" : "twitter.com\/FindFrankNow\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494615884678590465",
  "text" : "Holy shit, can see the smoke from this from my place: https:\/\/t.co\/BRjZsyC0h3",
  "id" : 494615884678590465,
  "created_at" : "2014-07-30 22:49:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Gourmet Dogs",
      "screen_name" : "FindFrankNow",
      "indices" : [ 3, 16 ],
      "id_str" : "843961676",
      "id" : 843961676
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FindFrankNow\/status\/494612096500649986\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/L19LCKqkct",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt03FENCYAASLIu.jpg",
      "id_str" : "494612094247919616",
      "id" : 494612094247919616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt03FENCYAASLIu.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/L19LCKqkct"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494615642654662656",
  "text" : "RT @FindFrankNow: CLOSING NOW: there is a house on fire across the street from First Presbyterian Church! http:\/\/t.co\/L19LCKqkct",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FindFrankNow\/status\/494612096500649986\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/L19LCKqkct",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt03FENCYAASLIu.jpg",
        "id_str" : "494612094247919616",
        "id" : 494612094247919616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt03FENCYAASLIu.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/L19LCKqkct"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494612096500649986",
    "text" : "CLOSING NOW: there is a house on fire across the street from First Presbyterian Church! http:\/\/t.co\/L19LCKqkct",
    "id" : 494612096500649986,
    "created_at" : "2014-07-30 22:34:47 +0000",
    "user" : {
      "name" : "Frank Gourmet Dogs",
      "screen_name" : "FindFrankNow",
      "protected" : false,
      "id_str" : "843961676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3620756067\/aef7a6fa7303c9f9c04184f24ef44fbb_normal.jpeg",
      "id" : 843961676,
      "verified" : false
    }
  },
  "id" : 494615642654662656,
  "created_at" : "2014-07-30 22:48:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/TYVlyowkjO",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/rss\/customerreviews\/id=898020776\/sortBy=mostRecent\/xml",
      "display_url" : "itunes.apple.com\/us\/rss\/custome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494613876336787456",
  "text" : "\"Copyright 2008 Apple Inc\" in the feed for every iOS app's reviews. That was 6 years ago. https:\/\/t.co\/TYVlyowkjO",
  "id" : 494613876336787456,
  "created_at" : "2014-07-30 22:41:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494605500009697281",
  "text" : "@juliepagano thanks! &lt;3",
  "id" : 494605500009697281,
  "created_at" : "2014-07-30 22:08:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    }, {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 10, 20 ],
      "id_str" : "942661",
      "id" : 942661
    }, {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 89, 99 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494602583432904704",
  "geo" : { },
  "id_str" : "494605070001262593",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak @nate_west we decided to dig into the platform more and learn it. And we hired @zachwaugh, who kicked ass on this",
  "id" : 494605070001262593,
  "in_reply_to_status_id" : 494602583432904704,
  "created_at" : "2014-07-30 22:06:52 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494579281729552385",
  "geo" : { },
  "id_str" : "494579482552832000",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine If you bring someone or can play piano, we can make this happen",
  "id" : 494579482552832000,
  "in_reply_to_status_id" : 494579281729552385,
  "created_at" : "2014-07-30 20:25:12 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    }, {
      "name" : "Michael Hamad",
      "screen_name" : "MikeHamad",
      "indices" : [ 13, 23 ],
      "id_str" : "27085484",
      "id" : 27085484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494576041067696128",
  "geo" : { },
  "id_str" : "494576268848156672",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 @MikeHamad taboot taboot!",
  "id" : 494576268848156672,
  "in_reply_to_status_id" : 494576041067696128,
  "created_at" : "2014-07-30 20:12:25 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 59, 68 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 73, 82 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/JQoOEvxl1E",
      "expanded_url" : "http:\/\/i.imgur.com\/lRvgWFx.jpg",
      "display_url" : "i.imgur.com\/lRvgWFx.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "494556227771584512",
  "text" : "Epic Pokemon battles going on recently, here's one between @mr_ndrsn and @shildner. Still open for beta testers. http:\/\/t.co\/JQoOEvxl1E",
  "id" : 494556227771584512,
  "created_at" : "2014-07-30 18:52:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494519135486083072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8907358429, -78.8762813191 ]
  },
  "id_str" : "494519831064887296",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents wat",
  "id" : 494519831064887296,
  "in_reply_to_status_id" : 494519135486083072,
  "created_at" : "2014-07-30 16:28:10 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 22, 33 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494517281989206016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8904653655, -78.8745961246 ]
  },
  "id_str" : "494517950087299072",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe @evanphx @samkottler did you all get a pingdom alert?",
  "id" : 494517950087299072,
  "in_reply_to_status_id" : 494517281989206016,
  "created_at" : "2014-07-30 16:20:41 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 85, 93 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 94, 105 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 106, 118 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/33aYAp9qxm",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "494515042596184065",
  "text" : "Looks like http:\/\/t.co\/33aYAp9qxm is having some issues...we're looking into it. \/cc @evanphx @samkottler @dwradcliffe",
  "id" : 494515042596184065,
  "created_at" : "2014-07-30 16:09:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00E9amus Bellamy",
      "screen_name" : "SeamusBellamy",
      "indices" : [ 0, 14 ],
      "id_str" : "128321519",
      "id" : 128321519
    }, {
      "name" : "Jacqui Cheng",
      "screen_name" : "ejacqui",
      "indices" : [ 15, 23 ],
      "id_str" : "46023",
      "id" : 46023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494486164380737536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915661833, -78.8721951355 ]
  },
  "id_str" : "494489302370627584",
  "in_reply_to_user_id" : 128321519,
  "text" : "@SeamusBellamy @ejacqui let me know how it goes! Curious to see how it\u2019s used by more full time\/avid iPad users",
  "id" : 494489302370627584,
  "in_reply_to_status_id" : 494486164380737536,
  "created_at" : "2014-07-30 14:26:51 +0000",
  "in_reply_to_screen_name" : "SeamusBellamy",
  "in_reply_to_user_id_str" : "128321519",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494487544344506369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915661833, -78.8721951355 ]
  },
  "id_str" : "494488955078053889",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd one of many",
  "id" : 494488955078053889,
  "in_reply_to_status_id" : 494487544344506369,
  "created_at" : "2014-07-30 14:25:28 +0000",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494486812211941376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915661833, -78.8721951355 ]
  },
  "id_str" : "494488923687899136",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west nope this is ObjC",
  "id" : 494488923687899136,
  "in_reply_to_status_id" : 494486812211941376,
  "created_at" : "2014-07-30 14:25:21 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/E2HSogTdpx",
      "expanded_url" : "https:\/\/basecamp.com\/announcements\/42",
      "display_url" : "basecamp.com\/announcements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494485293429714945",
  "text" : "Happy to finally say Basecamp for iPad is here! https:\/\/t.co\/E2HSogTdpx",
  "id" : 494485293429714945,
  "created_at" : "2014-07-30 14:10:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 54, 69 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/y1AgITKJcR",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "494484414588784640",
  "text" : "Happy to see some more registrations this morning for @nickelcityruby. Can you make it? http:\/\/t.co\/y1AgITKJcR",
  "id" : 494484414588784640,
  "created_at" : "2014-07-30 14:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Machell",
      "screen_name" : "ben_machell",
      "indices" : [ 3, 15 ],
      "id_str" : "336028534",
      "id" : 336028534
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ben_machell\/status\/494467142843383808\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/iOq3MvxQ1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtyzPvgIIAAGoT9.jpg",
      "id_str" : "494467142134538240",
      "id" : 494467142134538240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtyzPvgIIAAGoT9.jpg",
      "sizes" : [ {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/iOq3MvxQ1z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494470897474891777",
  "text" : "RT @ben_machell: Only just realised I've lived most of my life operating solely via these commands http:\/\/t.co\/iOq3MvxQ1z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ben_machell\/status\/494467142843383808\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/iOq3MvxQ1z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtyzPvgIIAAGoT9.jpg",
        "id_str" : "494467142134538240",
        "id" : 494467142134538240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtyzPvgIIAAGoT9.jpg",
        "sizes" : [ {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/iOq3MvxQ1z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494467142843383808",
    "text" : "Only just realised I've lived most of my life operating solely via these commands http:\/\/t.co\/iOq3MvxQ1z",
    "id" : 494467142843383808,
    "created_at" : "2014-07-30 12:58:48 +0000",
    "user" : {
      "name" : "Ben Machell",
      "screen_name" : "ben_machell",
      "protected" : false,
      "id_str" : "336028534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552066088180404224\/vVVcY50s_normal.jpeg",
      "id" : 336028534,
      "verified" : true
    }
  },
  "id" : 494470897474891777,
  "created_at" : "2014-07-30 13:13:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 3, 10 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494470801916051456",
  "text" : "RT @nb3004: I feel like Ray Liotta in Goodfellas. This helicopter won't stop flying over the Elmwood Village.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.9251019471, -78.870765539 ]
    },
    "id_str" : "494468605590138880",
    "text" : "I feel like Ray Liotta in Goodfellas. This helicopter won't stop flying over the Elmwood Village.",
    "id" : 494468605590138880,
    "created_at" : "2014-07-30 13:04:37 +0000",
    "user" : {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "protected" : false,
      "id_str" : "5452072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477084296000585728\/PVswHXyq_normal.jpeg",
      "id" : 5452072,
      "verified" : false
    }
  },
  "id" : 494470801916051456,
  "created_at" : "2014-07-30 13:13:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494312433662455808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241811776, -78.8791403634 ]
  },
  "id_str" : "494323224604180481",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove also we don\u2019t have push anywhere yet. Focus has been on catching up with native dev first. We have a lot to do and learn still.",
  "id" : 494323224604180481,
  "in_reply_to_status_id" : 494312433662455808,
  "created_at" : "2014-07-30 03:26:55 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494312433662455808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.917465393, -78.8767594676 ]
  },
  "id_str" : "494313243838382080",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove yeah we hear this a lot. Sessions are shared on web if you log out there. No push notifications anywhere yet.",
  "id" : 494313243838382080,
  "in_reply_to_status_id" : 494312433662455808,
  "created_at" : "2014-07-30 02:47:15 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Mehle",
      "screen_name" : "jrmehle",
      "indices" : [ 0, 8 ],
      "id_str" : "10267212",
      "id" : 10267212
    }, {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 9, 18 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 19, 29 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494238673202728960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924298894, -78.8789592994 ]
  },
  "id_str" : "494242485799878656",
  "in_reply_to_user_id" : 10267212,
  "text" : "@jrmehle @fowlduck @nexxylove sorry :( We use Campfire every day still. Lots of alternatives out there but none seem to have the same spirit",
  "id" : 494242485799878656,
  "in_reply_to_status_id" : 494238673202728960,
  "created_at" : "2014-07-29 22:06:05 +0000",
  "in_reply_to_screen_name" : "jrmehle",
  "in_reply_to_user_id_str" : "10267212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 10, 20 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Vrn3trrDxt",
      "expanded_url" : "http:\/\/37signals.com",
      "display_url" : "37signals.com"
    } ]
  },
  "in_reply_to_status_id_str" : "494237553403625472",
  "geo" : { },
  "id_str" : "494237634076491776",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @nexxylove Use Flint. Did you see the letter at http:\/\/t.co\/Vrn3trrDxt ?",
  "id" : 494237634076491776,
  "in_reply_to_status_id" : 494237553403625472,
  "created_at" : "2014-07-29 21:46:49 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494236911225954304",
  "geo" : { },
  "id_str" : "494237011952160769",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove what doesn't work about the iPhone app? Use it daily here.",
  "id" : 494237011952160769,
  "in_reply_to_status_id" : 494236911225954304,
  "created_at" : "2014-07-29 21:44:20 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 56, 66 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/0PEbK6yQkp",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494229110697127937",
  "text" : "RT @zachwaugh: Happy to share what I\u2019ve been working on @37signals. Basecamp for iPad, out today - https:\/\/t.co\/0PEbK6yQkp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 41, 51 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/0PEbK6yQkp",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494225653038723073",
    "text" : "Happy to share what I\u2019ve been working on @37signals. Basecamp for iPad, out today - https:\/\/t.co\/0PEbK6yQkp",
    "id" : 494225653038723073,
    "created_at" : "2014-07-29 20:59:12 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 494229110697127937,
  "created_at" : "2014-07-29 21:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 3, 13 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/494226560241512449\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/enbXeE27sG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvYcBdCIAEAWPv.png",
      "id_str" : "494226560065347585",
      "id" : 494226560065347585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvYcBdCIAEAWPv.png",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 342
      } ],
      "display_url" : "pic.twitter.com\/enbXeE27sG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/vjboHiW09w",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494229076312219649",
  "text" : "RT @37signals: Basecamp comes to iPad with a brand new app: https:\/\/t.co\/vjboHiW09w http:\/\/t.co\/enbXeE27sG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/37signals\/status\/494226560241512449\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/enbXeE27sG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvYcBdCIAEAWPv.png",
        "id_str" : "494226560065347585",
        "id" : 494226560065347585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvYcBdCIAEAWPv.png",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 342
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 342
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 342
        } ],
        "display_url" : "pic.twitter.com\/enbXeE27sG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/vjboHiW09w",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494226560241512449",
    "text" : "Basecamp comes to iPad with a brand new app: https:\/\/t.co\/vjboHiW09w http:\/\/t.co\/enbXeE27sG",
    "id" : 494226560241512449,
    "created_at" : "2014-07-29 21:02:48 +0000",
    "user" : {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "protected" : false,
      "id_str" : "11132462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431920925563289600\/EVCDdTmr_normal.png",
      "id" : 11132462,
      "verified" : false
    }
  },
  "id" : 494229076312219649,
  "created_at" : "2014-07-29 21:12:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bfHSuAB0y5",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494228299699073024",
  "text" : "RT @jasonfried: If you're one of the millions who uses Basecamp, and you have an iPad, you'll want this \u2014&gt; https:\/\/t.co\/bfHSuAB0y5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/bfHSuAB0y5",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/basecamp-for-ipad-official\/id898020776?ls=1&mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/basecam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494206451225985024",
    "text" : "If you're one of the millions who uses Basecamp, and you have an iPad, you'll want this \u2014&gt; https:\/\/t.co\/bfHSuAB0y5",
    "id" : 494206451225985024,
    "created_at" : "2014-07-29 19:42:54 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 494228299699073024,
  "created_at" : "2014-07-29 21:09:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494191064522428416",
  "geo" : { },
  "id_str" : "494191492898889728",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy shhhhh",
  "id" : 494191492898889728,
  "in_reply_to_status_id" : 494191064522428416,
  "created_at" : "2014-07-29 18:43:28 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494190141536096256",
  "text" : "OH \"It's an odd era, when so many people have to keep abreast of what some rich people in California are offering for their lives.\"",
  "id" : 494190141536096256,
  "created_at" : "2014-07-29 18:38:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis M. Kitchen",
      "screen_name" : "DenisKitchen",
      "indices" : [ 3, 16 ],
      "id_str" : "14668857",
      "id" : 14668857
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494182903794761731",
  "text" : "RT @DenisKitchen: Looking forward to @nickelcityruby. Just got my tickets.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 19, 34 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "491574292249735168",
    "geo" : { },
    "id_str" : "494155204867416064",
    "in_reply_to_user_id" : 1067596351,
    "text" : "Looking forward to @nickelcityruby. Just got my tickets.",
    "id" : 494155204867416064,
    "in_reply_to_status_id" : 491574292249735168,
    "created_at" : "2014-07-29 16:19:16 +0000",
    "in_reply_to_screen_name" : "nickelcityruby",
    "in_reply_to_user_id_str" : "1067596351",
    "user" : {
      "name" : "Denis M. Kitchen",
      "screen_name" : "DenisKitchen",
      "protected" : false,
      "id_str" : "14668857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53805961\/DMK_SouthPark_normal.jpg",
      "id" : 14668857,
      "verified" : false
    }
  },
  "id" : 494182903794761731,
  "created_at" : "2014-07-29 18:09:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494169202698096642",
  "geo" : { },
  "id_str" : "494169694538973184",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh better get your thetans checked",
  "id" : 494169694538973184,
  "in_reply_to_status_id" : 494169202698096642,
  "created_at" : "2014-07-29 17:16:51 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494152511125585920",
  "geo" : { },
  "id_str" : "494154226923077633",
  "in_reply_to_user_id" : 5743852,
  "text" : "@grossberg Correction: Notepad2. Also no version control either. Lots of index_BAK_NAQ_072914.asp",
  "id" : 494154226923077633,
  "in_reply_to_status_id" : 494152511125585920,
  "created_at" : "2014-07-29 16:15:23 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg ",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494151777936089089",
  "geo" : { },
  "id_str" : "494152511125585920",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg First programming job during school I worked with a 4th year who coded VB in Notepad. When I found Notepad++ he didn't use it.",
  "id" : 494152511125585920,
  "in_reply_to_status_id" : 494151777936089089,
  "created_at" : "2014-07-29 16:08:34 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "indices" : [ 3, 10 ],
      "id_str" : "14883887",
      "id" : 14883887
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCRC2014",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494150569234161664",
  "text" : "RT @fkumro: Got my ticket for @nickelcityruby this year, can't wait! #NCRC2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 18, 33 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCRC2014",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494135298125991938",
    "text" : "Got my ticket for @nickelcityruby this year, can't wait! #NCRC2014",
    "id" : 494135298125991938,
    "created_at" : "2014-07-29 15:00:10 +0000",
    "user" : {
      "name" : "Frank K",
      "screen_name" : "fkumro",
      "protected" : false,
      "id_str" : "14883887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726397886\/14b04f7e9a417778e4cf1efeac186896_normal.png",
      "id" : 14883887,
      "verified" : false
    }
  },
  "id" : 494150569234161664,
  "created_at" : "2014-07-29 16:00:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCRC2014",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/7GaA4rSLBv",
      "expanded_url" : "http:\/\/thoughtcatalog.com\/lauren-modery\/2014\/03\/move-over-austin-buffalo-is-the-new-it-city\/",
      "display_url" : "thoughtcatalog.com\/lauren-modery\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494150559302041600",
  "text" : "RT @nickelcityruby: Need more reasons to come to Buffalo for #NCRC2014 - check this article out: http:\/\/t.co\/7GaA4rSLBv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCRC2014",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/7GaA4rSLBv",
        "expanded_url" : "http:\/\/thoughtcatalog.com\/lauren-modery\/2014\/03\/move-over-austin-buffalo-is-the-new-it-city\/",
        "display_url" : "thoughtcatalog.com\/lauren-modery\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494143614835236864",
    "text" : "Need more reasons to come to Buffalo for #NCRC2014 - check this article out: http:\/\/t.co\/7GaA4rSLBv",
    "id" : 494143614835236864,
    "created_at" : "2014-07-29 15:33:13 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 494150559302041600,
  "created_at" : "2014-07-29 16:00:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/FwY6kt6nAm",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
      "display_url" : "nickelcityruby.com\/#register"
    } ]
  },
  "geo" : { },
  "id_str" : "494131527551180800",
  "text" : "RT @nickelcityruby: Tickets are flying off the proverbial shelves!!  Make sure you get yours!! http:\/\/t.co\/FwY6kt6nAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/FwY6kt6nAm",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#register",
        "display_url" : "nickelcityruby.com\/#register"
      } ]
    },
    "geo" : { },
    "id_str" : "494131311255494657",
    "text" : "Tickets are flying off the proverbial shelves!!  Make sure you get yours!! http:\/\/t.co\/FwY6kt6nAm",
    "id" : 494131311255494657,
    "created_at" : "2014-07-29 14:44:19 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 494131527551180800,
  "created_at" : "2014-07-29 14:45:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/494131031813804032\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/pAR6JVGqlc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtuBjcmCYAIuZ4V.png",
      "id_str" : "494131030098337794",
      "id" : 494131030098337794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtuBjcmCYAIuZ4V.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1698
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pAR6JVGqlc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494131031813804032",
  "text" : "If anyone is up for challenging\/testing the Pokemon bot today, let me know! Hoping to not break it too much. http:\/\/t.co\/pAR6JVGqlc",
  "id" : 494131031813804032,
  "created_at" : "2014-07-29 14:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 0, 11 ],
      "id_str" : "76750013",
      "id" : 76750013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494103503397081090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243777506, -78.8791411557 ]
  },
  "id_str" : "494104085386104832",
  "in_reply_to_user_id" : 76750013,
  "text" : "@ashstarr88 I feel I\u2019ve never told you",
  "id" : 494104085386104832,
  "in_reply_to_status_id" : 494103503397081090,
  "created_at" : "2014-07-29 12:56:08 +0000",
  "in_reply_to_screen_name" : "ashstarr88",
  "in_reply_to_user_id_str" : "76750013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243179877, -78.8791954704 ]
  },
  "id_str" : "493960605368188928",
  "text" : "Even dumber idea: have a set of 8 rooms with one gym leader each. Earn badges for each.",
  "id" : 493960605368188928,
  "created_at" : "2014-07-29 03:26:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 98, 107 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243179877, -78.8791954704 ]
  },
  "id_str" : "493960143030059010",
  "text" : "Dumb idea: open a Pokemon gym via a Campfire public room. Anyone up for a challenge tomorrow? \/cc @mr_ndrsn",
  "id" : 493960143030059010,
  "created_at" : "2014-07-29 03:24:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 19, 29 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/FS3ftwxLoD",
      "expanded_url" : "http:\/\/instagram.com\/p\/rAxinTDdfR\/",
      "display_url" : "instagram.com\/p\/rAxinTDdfR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493947635326144512",
  "text" : "And in other news, @aquaranto is a badass: http:\/\/t.co\/FS3ftwxLoD",
  "id" : 493947635326144512,
  "created_at" : "2014-07-29 02:34:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sigismond McLaughlin",
      "screen_name" : "sinistersig",
      "indices" : [ 0, 12 ],
      "id_str" : "1686323516",
      "id" : 1686323516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493870378008457216",
  "geo" : { },
  "id_str" : "493875757446598658",
  "in_reply_to_user_id" : 1686323516,
  "text" : "@sinistersig on github you can drop any html into that branch and they'll serve it",
  "id" : 493875757446598658,
  "in_reply_to_status_id" : 493870378008457216,
  "created_at" : "2014-07-28 21:48:51 +0000",
  "in_reply_to_screen_name" : "sinistersig",
  "in_reply_to_user_id_str" : "1686323516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Arnott",
      "screen_name" : "noir",
      "indices" : [ 3, 8 ],
      "id_str" : "11677062",
      "id" : 11677062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493870225864294400",
  "text" : "RT @noir: \u201CXcode quit unexpectedly.\u201D\n\nLet\u2019s be honest. It wasn\u2019t that unexpected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493802468786987009",
    "text" : "\u201CXcode quit unexpectedly.\u201D\n\nLet\u2019s be honest. It wasn\u2019t that unexpected.",
    "id" : 493802468786987009,
    "created_at" : "2014-07-28 16:57:37 +0000",
    "user" : {
      "name" : "Nick Arnott",
      "screen_name" : "noir",
      "protected" : false,
      "id_str" : "11677062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480431070328786944\/SzCkJfni_normal.jpeg",
      "id" : 11677062,
      "verified" : false
    }
  },
  "id" : 493870225864294400,
  "created_at" : "2014-07-28 21:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sigismond McLaughlin",
      "screen_name" : "sinistersig",
      "indices" : [ 0, 12 ],
      "id_str" : "1686323516",
      "id" : 1686323516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/PJdIVbawlE",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2013\/01\/09\/use-jekyll-scss-coffeescript-without-plugins\/",
      "display_url" : "quaran.to\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "493865880263340033",
  "geo" : { },
  "id_str" : "493868835590922241",
  "in_reply_to_user_id" : 1686323516,
  "text" : "@sinistersig Haha not too often. http:\/\/t.co\/PJdIVbawlE",
  "id" : 493868835590922241,
  "in_reply_to_status_id" : 493865880263340033,
  "created_at" : "2014-07-28 21:21:20 +0000",
  "in_reply_to_screen_name" : "sinistersig",
  "in_reply_to_user_id_str" : "1686323516",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/493817824582696960\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/K3cckzHyxB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtpksVWCMAAQT_M.jpg",
      "id_str" : "493817821957074944",
      "id" : 493817821957074944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtpksVWCMAAQT_M.jpg",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/K3cckzHyxB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493834681167929344",
  "text" : "RT @AqueousBand: Love getting stuff like this from y'all! Thanks @whatup_haumy! http:\/\/t.co\/K3cckzHyxB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/493817824582696960\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/K3cckzHyxB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtpksVWCMAAQT_M.jpg",
        "id_str" : "493817821957074944",
        "id" : 493817821957074944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtpksVWCMAAQT_M.jpg",
        "sizes" : [ {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/K3cckzHyxB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493817824582696960",
    "text" : "Love getting stuff like this from y'all! Thanks @whatup_haumy! http:\/\/t.co\/K3cckzHyxB",
    "id" : 493817824582696960,
    "created_at" : "2014-07-28 17:58:38 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 493834681167929344,
  "created_at" : "2014-07-28 19:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/sOujhHJ2oG",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kFd2Mi2FTzs",
      "display_url" : "youtube.com\/watch?v=kFd2Mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "493823500302684160",
  "text" : "Current status: https:\/\/t.co\/sOujhHJ2oG",
  "id" : 493823500302684160,
  "created_at" : "2014-07-28 18:21:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 39, 45 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493585805776932864",
  "text" : "MPP is getting treated tonight. Insane @phish setlist tonight.",
  "id" : 493585805776932864,
  "created_at" : "2014-07-28 02:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Iredale",
      "screen_name" : "iosengineer",
      "indices" : [ 0, 12 ],
      "id_str" : "242536500",
      "id" : 242536500
    }, {
      "name" : "Tony Hung",
      "screen_name" : "Thung",
      "indices" : [ 13, 19 ],
      "id_str" : "10315872",
      "id" : 10315872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493578656292155393",
  "geo" : { },
  "id_str" : "493579179795820544",
  "in_reply_to_user_id" : 242536500,
  "text" : "@iosengineer @Thung yeah, that's just a limitation of uiwebview. I don't think most people who aren't app developers notice ;)",
  "id" : 493579179795820544,
  "in_reply_to_status_id" : 493578656292155393,
  "created_at" : "2014-07-28 02:10:21 +0000",
  "in_reply_to_screen_name" : "iosengineer",
  "in_reply_to_user_id_str" : "242536500",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/493573499936460801\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/sMejJhG19a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtmGez2CIAAVFjB.png",
      "id_str" : "493573498044817408",
      "id" : 493573498044817408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtmGez2CIAAVFjB.png",
      "sizes" : [ {
        "h" : 1316,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1316,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sMejJhG19a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493573499936460801",
  "text" : "Carving out new rooms for dwarves is always cathartic. http:\/\/t.co\/sMejJhG19a",
  "id" : 493573499936460801,
  "created_at" : "2014-07-28 01:47:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Hung",
      "screen_name" : "Thung",
      "indices" : [ 0, 6 ],
      "id_str" : "10315872",
      "id" : 10315872
    }, {
      "name" : "Adam Iredale",
      "screen_name" : "iosengineer",
      "indices" : [ 7, 19 ],
      "id_str" : "242536500",
      "id" : 242536500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492625756036411392",
  "geo" : { },
  "id_str" : "493568433510821888",
  "in_reply_to_user_id" : 10315872,
  "text" : "@Thung @iosengineer it was, but that shouldn't make it slow. what's slow about it? would love to hear what's going on.",
  "id" : 493568433510821888,
  "in_reply_to_status_id" : 492625756036411392,
  "created_at" : "2014-07-28 01:27:39 +0000",
  "in_reply_to_screen_name" : "Thung",
  "in_reply_to_user_id_str" : "10315872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/LpR3GM7Tiz",
      "expanded_url" : "https:\/\/jarv.co\/faq",
      "display_url" : "jarv.co\/faq"
    } ]
  },
  "geo" : { },
  "id_str" : "493567152712982528",
  "text" : "\"because they are aided by artificial intelligence and futuristic tech.\" What in the actual fuck? https:\/\/t.co\/LpR3GM7Tiz",
  "id" : 493567152712982528,
  "created_at" : "2014-07-28 01:22:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 47, 56 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 57, 67 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 68, 77 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 78, 89 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/493565483149303812\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/skxpc7dC5a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btl_MNCCUAAXa9-.png",
      "id_str" : "493565481807138816",
      "id" : 493565481807138816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btl_MNCCUAAXa9-.png",
      "sizes" : [ {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 908,
        "resize" : "fit",
        "w" : 1056
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/skxpc7dC5a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493565483149303812",
  "text" : "And, PvP is in. A new era begins tomorrow! \/cc @shildner @asianmack @mr_ndrsn @joanofdark http:\/\/t.co\/skxpc7dC5a",
  "id" : 493565483149303812,
  "created_at" : "2014-07-28 01:15:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/OsZpS1GP0B",
      "expanded_url" : "https:\/\/github.com\/qrush\/mon",
      "display_url" : "github.com\/qrush\/mon"
    } ]
  },
  "in_reply_to_status_id_str" : "493557539582509056",
  "geo" : { },
  "id_str" : "493557867929026560",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda Code is terrible but it's here. https:\/\/t.co\/OsZpS1GP0B",
  "id" : 493557867929026560,
  "in_reply_to_status_id" : 493557539582509056,
  "created_at" : "2014-07-28 00:45:40 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493556883488538624",
  "geo" : { },
  "id_str" : "493557429225799682",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda and this is why I'm currently adding PvP support to my pokemon battle bot -_-",
  "id" : 493557429225799682,
  "in_reply_to_status_id" : 493556883488538624,
  "created_at" : "2014-07-28 00:43:55 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493552154339065856",
  "geo" : { },
  "id_str" : "493552369607512064",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh Confirmation bias?",
  "id" : 493552369607512064,
  "in_reply_to_status_id" : 493552154339065856,
  "created_at" : "2014-07-28 00:23:49 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493543562727133185",
  "geo" : { },
  "id_str" : "493550207422836737",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn yeah will consider once the little dude figures out how to climb. this is mostly a dog gate.",
  "id" : 493550207422836737,
  "in_reply_to_status_id" : 493543562727133185,
  "created_at" : "2014-07-28 00:15:13 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493531776267345920",
  "geo" : { },
  "id_str" : "493534120115326976",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn i did not think of that...",
  "id" : 493534120115326976,
  "in_reply_to_status_id" : 493531776267345920,
  "created_at" : "2014-07-27 23:11:18 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 33, 49 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/493513525839409152\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ih3MEvU2ES",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtlP7wjCcAAZckM.jpg",
      "id_str" : "493513522236518400",
      "id" : 493513522236518400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtlP7wjCcAAZckM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ih3MEvU2ES"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KyepKMGXno",
      "expanded_url" : "http:\/\/blueantstudio.blogspot.com\/2006\/08\/homebrew-baby-safety-gate.html",
      "display_url" : "blueantstudio.blogspot.com\/2006\/08\/homebr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "493513525839409152",
  "text" : "Finally made this baby gate that @whentheponydies recommended, turned out great. Based off: http:\/\/t.co\/KyepKMGXno http:\/\/t.co\/ih3MEvU2ES",
  "id" : 493513525839409152,
  "created_at" : "2014-07-27 21:49:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1598644159",
      "id" : 1598644159
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HistoricalPics\/status\/493259551433842688\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/WoGZYlgeaw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btho8syIEAAgdba.jpg",
      "id_str" : "493259551219912704",
      "id" : 493259551219912704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btho8syIEAAgdba.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WoGZYlgeaw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493384455470329856",
  "text" : "RT @HistoricalPics: Niagara falls without water. 1969 http:\/\/t.co\/WoGZYlgeaw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HistoricalPics\/status\/493259551433842688\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/WoGZYlgeaw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Btho8syIEAAgdba.jpg",
        "id_str" : "493259551219912704",
        "id" : 493259551219912704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btho8syIEAAgdba.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WoGZYlgeaw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493259551433842688",
    "text" : "Niagara falls without water. 1969 http:\/\/t.co\/WoGZYlgeaw",
    "id" : 493259551433842688,
    "created_at" : "2014-07-27 05:00:16 +0000",
    "user" : {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "protected" : false,
      "id_str" : "1598644159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000427629583\/884341028bb46b82f4dc8743b9ad24d7_normal.jpeg",
      "id" : 1598644159,
      "verified" : false
    }
  },
  "id" : 493384455470329856,
  "created_at" : "2014-07-27 13:16:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 3, 10 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mkdevo\/status\/493374237961236480\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/oPp0A6kAAn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtjRQSnIQAA7O0f.jpg",
      "id_str" : "493374237001138176",
      "id" : 493374237001138176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtjRQSnIQAA7O0f.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oPp0A6kAAn"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "couchtour",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/JbYmj0CXI0",
      "expanded_url" : "http:\/\/imgur.com\/a\/HkYGj",
      "display_url" : "imgur.com\/a\/HkYGj"
    } ]
  },
  "geo" : { },
  "id_str" : "493374684205813763",
  "text" : "RT @mkdevo: Last night's Merriweather webcast setbreak factoids:\n\nhttp:\/\/t.co\/JbYmj0CXI0\n\n#phish #couchtour http:\/\/t.co\/oPp0A6kAAn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mkdevo\/status\/493374237961236480\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/oPp0A6kAAn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtjRQSnIQAA7O0f.jpg",
        "id_str" : "493374237001138176",
        "id" : 493374237001138176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtjRQSnIQAA7O0f.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oPp0A6kAAn"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "couchtour",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/JbYmj0CXI0",
        "expanded_url" : "http:\/\/imgur.com\/a\/HkYGj",
        "display_url" : "imgur.com\/a\/HkYGj"
      } ]
    },
    "geo" : { },
    "id_str" : "493374237961236480",
    "text" : "Last night's Merriweather webcast setbreak factoids:\n\nhttp:\/\/t.co\/JbYmj0CXI0\n\n#phish #couchtour http:\/\/t.co\/oPp0A6kAAn",
    "id" : 493374237961236480,
    "created_at" : "2014-07-27 12:35:59 +0000",
    "user" : {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "protected" : false,
      "id_str" : "158371168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564127014987120640\/dkdEJyOf_normal.jpeg",
      "id" : 158371168,
      "verified" : false
    }
  },
  "id" : 493374684205813763,
  "created_at" : "2014-07-27 12:37:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul",
      "screen_name" : "phalt_",
      "indices" : [ 0, 7 ],
      "id_str" : "198444822",
      "id" : 198444822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/5JCx2bS72m",
      "expanded_url" : "http:\/\/github.com\/qrush\/mon",
      "display_url" : "github.com\/qrush\/mon"
    } ]
  },
  "in_reply_to_status_id_str" : "493348135058821120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244162655, -78.8790707477 ]
  },
  "id_str" : "493365175316017154",
  "in_reply_to_user_id" : 198444822,
  "text" : "@phalt_ but the pokeapi has been a big help. Battle simulator is here: http:\/\/t.co\/5JCx2bS72m",
  "id" : 493365175316017154,
  "in_reply_to_status_id" : 493348135058821120,
  "created_at" : "2014-07-27 11:59:58 +0000",
  "in_reply_to_screen_name" : "phalt_",
  "in_reply_to_user_id_str" : "198444822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul",
      "screen_name" : "phalt_",
      "indices" : [ 0, 7 ],
      "id_str" : "198444822",
      "id" : 198444822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/7vQNNvZT18",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/492366980838461440",
      "display_url" : "twitter.com\/qrush\/status\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "493348135058821120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244162655, -78.8790707477 ]
  },
  "id_str" : "493364997322313728",
  "in_reply_to_user_id" : 198444822,
  "text" : "@phalt_ it\u2019s already been happening: https:\/\/t.co\/7vQNNvZT18 however for data I used the csv\u2019s from veekun\/pokedex",
  "id" : 493364997322313728,
  "in_reply_to_status_id" : 493348135058821120,
  "created_at" : "2014-07-27 11:59:16 +0000",
  "in_reply_to_screen_name" : "phalt_",
  "in_reply_to_user_id_str" : "198444822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493220477998206977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243440785, -78.8794309583 ]
  },
  "id_str" : "493223200315015168",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock new workshop: Dwarven Malpractice Insurance Agency",
  "id" : 493223200315015168,
  "in_reply_to_status_id" : 493220477998206977,
  "created_at" : "2014-07-27 02:35:49 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 3, 18 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493222911793045505",
  "text" : "RT @importantshock: And THAT is why Dwarf Fortress is the greatest game of all time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493220536827527169",
    "text" : "And THAT is why Dwarf Fortress is the greatest game of all time.",
    "id" : 493220536827527169,
    "created_at" : "2014-07-27 02:25:14 +0000",
    "user" : {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "protected" : false,
      "id_str" : "7611992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536121826632822784\/8TOOJwu6_normal.jpeg",
      "id" : 7611992,
      "verified" : false
    }
  },
  "id" : 493222911793045505,
  "created_at" : "2014-07-27 02:34:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 3, 18 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493222874203713536",
  "text" : "RT @importantshock: \u201CPeople have reported bad dwarven doctors misdiagnosing a broken rib as \"rotten lungs\" and then performing surgery to r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493220477998206977",
    "text" : "\u201CPeople have reported bad dwarven doctors misdiagnosing a broken rib as \"rotten lungs\" and then performing surgery to remove the lungs.\u201D",
    "id" : 493220477998206977,
    "created_at" : "2014-07-27 02:25:00 +0000",
    "user" : {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "protected" : false,
      "id_str" : "7611992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536121826632822784\/8TOOJwu6_normal.jpeg",
      "id" : 7611992,
      "verified" : false
    }
  },
  "id" : 493222874203713536,
  "created_at" : "2014-07-27 02:34:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 92, 106 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/x3crhXkzIb",
      "expanded_url" : "http:\/\/www.andrewalexanderprice.com\/blog20131204.php#.U9RW5tm9LCR",
      "display_url" : "andrewalexanderprice.com\/blog20131204.p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243845819, -78.8791786228 ]
  },
  "id_str" : "493209170326208513",
  "text" : "Neat look at walkable, traditional cities and their role. Hyper idealized but fun read. \/cc @BuffaloRising http:\/\/t.co\/x3crhXkzIb",
  "id" : 493209170326208513,
  "created_at" : "2014-07-27 01:40:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "UpstateLIVE",
      "screen_name" : "UpstateLIVE",
      "indices" : [ 107, 119 ],
      "id_str" : "2934894724",
      "id" : 2934894724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aqband",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "chaffees",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RAHlLNjq6N",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-25",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "493082086996074498",
  "text" : "RT @UnclePhilsBlog: Nothing like a 20m Kitty to start things off. http:\/\/t.co\/RAHlLNjq6N #aqband #chaffees @UpstateLIVE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UpstateLIVE",
        "screen_name" : "UpstateLIVE",
        "indices" : [ 87, 99 ],
        "id_str" : "2934894724",
        "id" : 2934894724
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aqband",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "chaffees",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/RAHlLNjq6N",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-25",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492872961506824193",
    "text" : "Nothing like a 20m Kitty to start things off. http:\/\/t.co\/RAHlLNjq6N #aqband #chaffees @UpstateLIVE",
    "id" : 492872961506824193,
    "created_at" : "2014-07-26 03:24:05 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 493082086996074498,
  "created_at" : "2014-07-26 17:15:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Distill Conference",
      "screen_name" : "distill",
      "indices" : [ 57, 65 ],
      "id_str" : "1115593148",
      "id" : 1115593148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493081314795327488",
  "text" : "RT @aspleenic: So...two conferences. @nickelcityruby and @distill - don't miss either - get your tickets now. Seriously, for real you guys!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 22, 37 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Distill Conference",
        "screen_name" : "distill",
        "indices" : [ 42, 50 ],
        "id_str" : "1115593148",
        "id" : 1115593148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492862578990002177",
    "text" : "So...two conferences. @nickelcityruby and @distill - don't miss either - get your tickets now. Seriously, for real you guys!!",
    "id" : 492862578990002177,
    "created_at" : "2014-07-26 02:42:50 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 493081314795327488,
  "created_at" : "2014-07-26 17:12:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 3, 12 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 17, 29 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492851580203307008",
  "text" : "RT @LawnMemo: If @AqueousBand is near you, make sure you go see them.  Last night's show featured huge jams then went all over.  Incredible\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 3, 15 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492736392665911296",
    "text" : "If @AqueousBand is near you, make sure you go see them.  Last night's show featured huge jams then went all over.  Incredible show",
    "id" : 492736392665911296,
    "created_at" : "2014-07-25 18:21:25 +0000",
    "user" : {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "protected" : false,
      "id_str" : "829816736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2636172354\/9789c0e866bb44699f61010858641fc6_normal.jpeg",
      "id" : 829816736,
      "verified" : false
    }
  },
  "id" : 492851580203307008,
  "created_at" : "2014-07-26 01:59:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "indices" : [ 3, 14 ],
      "id_str" : "982762350",
      "id" : 982762350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "Rochester",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492834246235414528",
  "text" : "RT @NWSBUFFALO: #Buffalo NY has had 24 80F+ days this year, while #Rochester NY has had 33 such days. Normal 80F+ days through the 25th is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Rochester",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492832213659303936",
    "text" : "#Buffalo NY has had 24 80F+ days this year, while #Rochester NY has had 33 such days. Normal 80F+ days through the 25th is BUF- 31, ROC- 34.",
    "id" : 492832213659303936,
    "created_at" : "2014-07-26 00:42:10 +0000",
    "user" : {
      "name" : "NWS BUFFALO",
      "screen_name" : "NWSBUFFALO",
      "protected" : false,
      "id_str" : "982762350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465137770696957952\/-6l64r-b_normal.jpeg",
      "id" : 982762350,
      "verified" : true
    }
  },
  "id" : 492834246235414528,
  "created_at" : "2014-07-26 00:50:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/lTBdkl42j3",
      "expanded_url" : "http:\/\/m.washingtonpost.com\/lifestyle\/travel\/in-buffalo-ny-a-new-vitality-is-giving-the-once-gritty-city-wings\/2014\/07\/24\/f8ff6156-1126-11e4-98ee-daea85133bc9_story.html",
      "display_url" : "m.washingtonpost.com\/lifestyle\/trav\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9538851548, -78.8811884063 ]
  },
  "id_str" : "492692362255032320",
  "text" : "Buffalo in the WaPo today: http:\/\/t.co\/lTBdkl42j3",
  "id" : 492692362255032320,
  "created_at" : "2014-07-25 15:26:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Social Bicycles",
      "screen_name" : "SocialBicycles",
      "indices" : [ 25, 40 ],
      "id_str" : "147608374",
      "id" : 147608374
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/492670836000583680\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/V71CkgTWgO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtZRg2PIgAA8GeB.jpg",
      "id_str" : "492670834000297984",
      "id" : 492670834000297984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtZRg2PIgAA8GeB.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 810,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/V71CkgTWgO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492671862443216896",
  "text" : "RT @coworkbuffalo: First @socialbicycles sighting on Main Street! Nifty. Anyone seen others? http:\/\/t.co\/V71CkgTWgO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Social Bicycles",
        "screen_name" : "SocialBicycles",
        "indices" : [ 6, 21 ],
        "id_str" : "147608374",
        "id" : 147608374
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/492670836000583680\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/V71CkgTWgO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtZRg2PIgAA8GeB.jpg",
        "id_str" : "492670834000297984",
        "id" : 492670834000297984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtZRg2PIgAA8GeB.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 810,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/V71CkgTWgO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492670836000583680",
    "text" : "First @socialbicycles sighting on Main Street! Nifty. Anyone seen others? http:\/\/t.co\/V71CkgTWgO",
    "id" : 492670836000583680,
    "created_at" : "2014-07-25 14:00:55 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 492671862443216896,
  "created_at" : "2014-07-25 14:05:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 3, 13 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/RHq1qQjQF5",
      "expanded_url" : "http:\/\/lanyrd.com\/2014\/ncrc14\/",
      "display_url" : "lanyrd.com\/2014\/ncrc14\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492649484426301440",
  "text" : "RT @ericnagel: .@NickelCityRuby 2014, 3rd-4th October 2014 in Buffalo http:\/\/t.co\/RHq1qQjQF5 #ruby #buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 1, 16 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruby",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/RHq1qQjQF5",
        "expanded_url" : "http:\/\/lanyrd.com\/2014\/ncrc14\/",
        "display_url" : "lanyrd.com\/2014\/ncrc14\/"
      } ]
    },
    "geo" : { },
    "id_str" : "492648300550438912",
    "text" : ".@NickelCityRuby 2014, 3rd-4th October 2014 in Buffalo http:\/\/t.co\/RHq1qQjQF5 #ruby #buffalo",
    "id" : 492648300550438912,
    "created_at" : "2014-07-25 12:31:22 +0000",
    "user" : {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "protected" : false,
      "id_str" : "2522211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569936469033103360\/hf8UNWOJ_normal.jpeg",
      "id" : 2522211,
      "verified" : false
    }
  },
  "id" : 492649484426301440,
  "created_at" : "2014-07-25 12:36:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492541803858755584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241831533, -78.8790170846 ]
  },
  "id_str" : "492631279855091712",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN great idea!! Thanks!",
  "id" : 492631279855091712,
  "in_reply_to_status_id" : 492541803858755584,
  "created_at" : "2014-07-25 11:23:44 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Pesce",
      "screen_name" : "mpesce",
      "indices" : [ 3, 10 ],
      "id_str" : "3099501",
      "id" : 3099501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/PDyC4taqgA",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Fg85ggZSHMw",
      "display_url" : "youtube.com\/watch?v=Fg85gg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492631160090927105",
  "text" : "RT @mpesce: CUMBERBACH.\nIS.\nALAN TURING.\n\nhttps:\/\/t.co\/PDyC4taqgA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/PDyC4taqgA",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Fg85ggZSHMw",
        "display_url" : "youtube.com\/watch?v=Fg85gg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492616004023750656",
    "text" : "CUMBERBACH.\nIS.\nALAN TURING.\n\nhttps:\/\/t.co\/PDyC4taqgA",
    "id" : 492616004023750656,
    "created_at" : "2014-07-25 10:23:02 +0000",
    "user" : {
      "name" : "Mark Pesce",
      "screen_name" : "mpesce",
      "protected" : false,
      "id_str" : "3099501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567414871872921602\/DZFwKxXa_normal.jpeg",
      "id" : 3099501,
      "verified" : false
    }
  },
  "id" : 492631160090927105,
  "created_at" : "2014-07-25 11:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 0, 12 ],
      "id_str" : "15387091",
      "id" : 15387091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492514018385330176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243109469, -78.8790285867 ]
  },
  "id_str" : "492514410007502848",
  "in_reply_to_user_id" : 15387091,
  "text" : "@levineuland yeah was reading about the sequels! Amazed they continued it.",
  "id" : 492514410007502848,
  "in_reply_to_status_id" : 492514018385330176,
  "created_at" : "2014-07-25 03:39:20 +0000",
  "in_reply_to_screen_name" : "levineuland",
  "in_reply_to_user_id_str" : "15387091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243109469, -78.8790285867 ]
  },
  "id_str" : "492514270282645507",
  "text" : "This is my problem with \u201Cmodern\u201D mobile games: there\u2019s no depth. Or story. Just replayability and monetization :(",
  "id" : 492514270282645507,
  "created_at" : "2014-07-25 03:38:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243109469, -78.8790285867 ]
  },
  "id_str" : "492513942401318913",
  "text" : "Then you are left to your own devices in Zelda style, open world adventure\/rogue like with 8 different possible endings.",
  "id" : 492513942401318913,
  "created_at" : "2014-07-25 03:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243109469, -78.8790285867 ]
  },
  "id_str" : "492513764969684992",
  "text" : "Game starts off with your dad DYING on a sinking cruise ship that you (10 yrs old) and him were the ONLY CREW",
  "id" : 492513764969684992,
  "created_at" : "2014-07-25 03:36:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241892711, -78.8797155502 ]
  },
  "id_str" : "492513497960288256",
  "text" : "Found my GBC cart of Survival Kids, and this game is MESSED UP. No modern analysis of it either that seems easy to find.",
  "id" : 492513497960288256,
  "created_at" : "2014-07-25 03:35:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "indices" : [ 3, 9 ],
      "id_str" : "21937199",
      "id" : 21937199
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/haley\/status\/492507642351194112\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/rxMZPiY5Sd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtW9FrVCMAAYrir.jpg",
      "id_str" : "492507639494881280",
      "id" : 492507639494881280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtW9FrVCMAAYrir.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/rxMZPiY5Sd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492507771015663616",
  "text" : "RT @haley: I want to die http:\/\/t.co\/rxMZPiY5Sd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/haley\/status\/492507642351194112\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/rxMZPiY5Sd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtW9FrVCMAAYrir.jpg",
        "id_str" : "492507639494881280",
        "id" : 492507639494881280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtW9FrVCMAAYrir.jpg",
        "sizes" : [ {
          "h" : 601,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/rxMZPiY5Sd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492507642351194112",
    "text" : "I want to die http:\/\/t.co\/rxMZPiY5Sd",
    "id" : 492507642351194112,
    "created_at" : "2014-07-25 03:12:26 +0000",
    "user" : {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "protected" : false,
      "id_str" : "21937199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571591291764514816\/QJjCMPPP_normal.jpeg",
      "id" : 21937199,
      "verified" : false
    }
  },
  "id" : 492507771015663616,
  "created_at" : "2014-07-25 03:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241143545, -78.8796957873 ]
  },
  "id_str" : "492507172543021056",
  "text" : "Awful: threats of C&amp;D for not responding within a few days to an all volunteer open source help queue. :(",
  "id" : 492507172543021056,
  "created_at" : "2014-07-25 03:10:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924037115, -78.8791166037 ]
  },
  "id_str" : "492498109532880897",
  "text" : "Lesson learned for next time: put floor grates or a locked door in the way of water, because elves can swim!",
  "id" : 492498109532880897,
  "created_at" : "2014-07-25 02:34:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492496559586545664",
  "text" : "Lined up an execution squad of (unarmed) marksdwarves, he lept off the edge while trying to escape my squad. Didn't make it far.",
  "id" : 492496559586545664,
  "created_at" : "2014-07-25 02:28:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492496329034047489",
  "text" : "Also, in pure dwarf fortress fashion: I trapped that elf merchant by channeling a z-level around him.",
  "id" : 492496329034047489,
  "created_at" : "2014-07-25 02:27:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492495300255178753",
  "text" : "Holy shit, jumping\/climbing changes the game for Dwarf Fortress. An elf merchant just escaped a drowning by jumping UP a z-level.",
  "id" : 492495300255178753,
  "created_at" : "2014-07-25 02:23:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 7, 14 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/izDTmTDhRZ",
      "expanded_url" : "http:\/\/i342.photobucket.com\/albums\/o402\/chrisrushing\/gifs\/freakout.gif",
      "display_url" : "i342.photobucket.com\/albums\/o402\/ch\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "492478830372585473",
  "geo" : { },
  "id_str" : "492479210544300032",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp @sylvzc http:\/\/t.co\/izDTmTDhRZ",
  "id" : 492479210544300032,
  "in_reply_to_status_id" : 492478830372585473,
  "created_at" : "2014-07-25 01:19:28 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lanyrd",
      "screen_name" : "lanyrd",
      "indices" : [ 31, 38 ],
      "id_str" : "169942861",
      "id" : 169942861
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 43, 58 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/DtzEAaLqVD",
      "expanded_url" : "http:\/\/lanyrd.com\/2014\/ncrc14\/",
      "display_url" : "lanyrd.com\/2014\/ncrc14\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492478310450880512",
  "text" : "Filled out our speaker list on @Lanyrd for @nickelcityruby: http:\/\/t.co\/DtzEAaLqVD Now it's your turn to fill in our attendee list!",
  "id" : 492478310450880512,
  "created_at" : "2014-07-25 01:15:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Smith",
      "screen_name" : "brianthecoder",
      "indices" : [ 0, 14 ],
      "id_str" : "9548262",
      "id" : 9548262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/OsZpS1GP0B",
      "expanded_url" : "https:\/\/github.com\/qrush\/mon",
      "display_url" : "github.com\/qrush\/mon"
    } ]
  },
  "in_reply_to_status_id_str" : "492367312524017664",
  "geo" : { },
  "id_str" : "492368814005170176",
  "in_reply_to_user_id" : 9548262,
  "text" : "@brianthecoder a campfire bot that uses https:\/\/t.co\/OsZpS1GP0B",
  "id" : 492368814005170176,
  "in_reply_to_status_id" : 492367312524017664,
  "created_at" : "2014-07-24 18:00:47 +0000",
  "in_reply_to_screen_name" : "brianthecoder",
  "in_reply_to_user_id_str" : "9548262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/492366980838461440\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/GmgmemawWn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtU9KMHCcAAUKOI.png",
      "id_str" : "492366979525668864",
      "id" : 492366979525668864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtU9KMHCcAAUKOI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1346,
        "resize" : "fit",
        "w" : 1648
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GmgmemawWn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492366980838461440",
  "text" : "The Pokemon battle bot has a new high score for damage in one shot: 341! http:\/\/t.co\/GmgmemawWn",
  "id" : 492366980838461440,
  "created_at" : "2014-07-24 17:53:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492351491055685632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8914180538, -78.8726147544 ]
  },
  "id_str" : "492363293315440640",
  "in_reply_to_user_id" : 159163092,
  "text" : "@BuffaloHAWNY @coworkbuffalo sadly the benches are like that too. :(",
  "id" : 492363293315440640,
  "in_reply_to_status_id" : 492351491055685632,
  "created_at" : "2014-07-24 17:38:51 +0000",
  "in_reply_to_screen_name" : "HAWNY716",
  "in_reply_to_user_id_str" : "159163092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/tT23xCxo9t",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2695-nickelcityruby2013-smash-the-monolith-refactoring-legacy-rails-applications",
      "display_url" : "confreaks.com\/videos\/2695-ni\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "492338032498851840",
  "geo" : { },
  "id_str" : "492338344571830272",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps this one? http:\/\/t.co\/tT23xCxo9t",
  "id" : 492338344571830272,
  "in_reply_to_status_id" : 492338032498851840,
  "created_at" : "2014-07-24 15:59:43 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Richardson",
      "screen_name" : "pixelnibbler",
      "indices" : [ 3, 16 ],
      "id_str" : "112217740",
      "id" : 112217740
    }, {
      "name" : "Aled Evans",
      "screen_name" : "4L3D",
      "indices" : [ 18, 23 ],
      "id_str" : "786807306",
      "id" : 786807306
    }, {
      "name" : "Jon Fisher",
      "screen_name" : "ergonjon",
      "indices" : [ 24, 33 ],
      "id_str" : "166965484",
      "id" : 166965484
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 107, 117 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pixelnibbler\/status\/492304603468537857\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IKBVvMWJz4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUEbaAIcAARjCs.png",
      "id_str" : "492304603149791232",
      "id" : 492304603149791232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUEbaAIcAARjCs.png",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IKBVvMWJz4"
    } ],
    "hashtags" : [ {
      "text" : "billmurray",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "basecamp",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492332133130588162",
  "text" : "RT @pixelnibbler: @4l3d @ergonjon Love it! Here's what happened on my last project.. #billmurray #basecamp @37signals http:\/\/t.co\/IKBVvMWJz4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aled Evans",
        "screen_name" : "4L3D",
        "indices" : [ 0, 5 ],
        "id_str" : "786807306",
        "id" : 786807306
      }, {
        "name" : "Jon Fisher",
        "screen_name" : "ergonjon",
        "indices" : [ 6, 15 ],
        "id_str" : "166965484",
        "id" : 166965484
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 89, 99 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pixelnibbler\/status\/492304603468537857\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/IKBVvMWJz4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUEbaAIcAARjCs.png",
        "id_str" : "492304603149791232",
        "id" : 492304603149791232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUEbaAIcAARjCs.png",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IKBVvMWJz4"
      } ],
      "hashtags" : [ {
        "text" : "billmurray",
        "indices" : [ 67, 78 ]
      }, {
        "text" : "basecamp",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "492301858329722880",
    "geo" : { },
    "id_str" : "492304603468537857",
    "in_reply_to_user_id" : 786807306,
    "text" : "@4l3d @ergonjon Love it! Here's what happened on my last project.. #billmurray #basecamp @37signals http:\/\/t.co\/IKBVvMWJz4",
    "id" : 492304603468537857,
    "in_reply_to_status_id" : 492301858329722880,
    "created_at" : "2014-07-24 13:45:38 +0000",
    "in_reply_to_screen_name" : "4L3D",
    "in_reply_to_user_id_str" : "786807306",
    "user" : {
      "name" : "Paul Richardson",
      "screen_name" : "pixelnibbler",
      "protected" : false,
      "id_str" : "112217740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508708152766771201\/4oCLOyb__normal.png",
      "id" : 112217740,
      "verified" : false
    }
  },
  "id" : 492332133130588162,
  "created_at" : "2014-07-24 15:35:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 1, 13 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Larkin Square",
      "screen_name" : "larkinsquare",
      "indices" : [ 28, 41 ],
      "id_str" : "36047275",
      "id" : 36047275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/uMkxQh7VBU",
      "expanded_url" : "https:\/\/flic.kr\/p\/oavjs1",
      "display_url" : "flic.kr\/p\/oavjs1"
    } ]
  },
  "geo" : { },
  "id_str" : "492328363302731776",
  "text" : ".@AqueousBand killing it at @LarkinSquare last night. Big and growing audience. Loving it. https:\/\/t.co\/uMkxQh7VBU",
  "id" : 492328363302731776,
  "created_at" : "2014-07-24 15:20:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 14, 29 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492303054301978624",
  "geo" : { },
  "id_str" : "492325901493739521",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @UnclePhilsBlog I approve of this message",
  "id" : 492325901493739521,
  "in_reply_to_status_id" : 492303054301978624,
  "created_at" : "2014-07-24 15:10:16 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Colvin",
      "screen_name" : "2john4tv",
      "indices" : [ 0, 9 ],
      "id_str" : "16047997",
      "id" : 16047997
    }, {
      "name" : "Chandu Tennety",
      "screen_name" : "tennety",
      "indices" : [ 10, 18 ],
      "id_str" : "42727981",
      "id" : 42727981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491736949418229760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242045329, -78.8791176039 ]
  },
  "id_str" : "492160542874673152",
  "in_reply_to_user_id" : 16047997,
  "text" : "@2john4tv @tennety do all three! PROBLEM SOLVED!",
  "id" : 492160542874673152,
  "in_reply_to_status_id" : 491736949418229760,
  "created_at" : "2014-07-24 04:13:11 +0000",
  "in_reply_to_screen_name" : "2john4tv",
  "in_reply_to_user_id_str" : "16047997",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 14, 29 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492087763953397760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8760492057, -78.8495835476 ]
  },
  "id_str" : "492093187503030272",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @UnclePhilsBlog also looks like a broken cymbal. Badass.",
  "id" : 492093187503030272,
  "in_reply_to_status_id" : 492087763953397760,
  "created_at" : "2014-07-23 23:45:33 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 95, 110 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 111, 124 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8760579901, -78.8496035963 ]
  },
  "id_str" : "492087610387345409",
  "text" : "Space\/funky groove going now. Is there a Type II yet for AQ? I think Dave needs a theremin. Cc @UnclePhilsBlog @antelopeezer",
  "id" : 492087610387345409,
  "created_at" : "2014-07-23 23:23:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/M9rwAzBNhd",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-23",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492083198835175424",
  "text" : "RT @UnclePhilsBlog: Median &gt; Staring into the Sun http:\/\/t.co\/M9rwAzBNhd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/M9rwAzBNhd",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-23",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492083156149751808",
    "text" : "Median &gt; Staring into the Sun http:\/\/t.co\/M9rwAzBNhd",
    "id" : 492083156149751808,
    "created_at" : "2014-07-23 23:05:41 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 492083198835175424,
  "created_at" : "2014-07-23 23:05:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 21, 33 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/492077622977769473\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4d1ImDwHu6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtQ1_QgCUAAoVYW.jpg",
      "id_str" : "492077620167593984",
      "id" : 492077620167593984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtQ1_QgCUAAoVYW.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4d1ImDwHu6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/M9rwAzBNhd",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-23",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492077671690403840",
  "text" : "RT @UnclePhilsBlog: .@AqueousBand starting out strong! http:\/\/t.co\/M9rwAzBNhd http:\/\/t.co\/4d1ImDwHu6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 1, 13 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/492077622977769473\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/4d1ImDwHu6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtQ1_QgCUAAoVYW.jpg",
        "id_str" : "492077620167593984",
        "id" : 492077620167593984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtQ1_QgCUAAoVYW.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4d1ImDwHu6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/M9rwAzBNhd",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-23",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492077622977769473",
    "text" : ".@AqueousBand starting out strong! http:\/\/t.co\/M9rwAzBNhd http:\/\/t.co\/4d1ImDwHu6",
    "id" : 492077622977769473,
    "created_at" : "2014-07-23 22:43:42 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 492077671690403840,
  "created_at" : "2014-07-23 22:43:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 5, 17 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Larkin Square",
      "screen_name" : "larkinsquare",
      "indices" : [ 28, 41 ],
      "id_str" : "36047275",
      "id" : 36047275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/T1Tjay7J0D",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53d035ad498e95981391d663?s=HL4n30azJVJYFD0rTWnh_CrdqHc&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8759957291, -78.849691217 ]
  },
  "id_str" : "492072343779704833",
  "text" : "It's @AqueousBand time. (at @LarkinSquare w\/ 2 others) https:\/\/t.co\/T1Tjay7J0D",
  "id" : 492072343779704833,
  "created_at" : "2014-07-23 22:22:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 3, 12 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/konklone\/status\/491665680870014976\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/B4ZtnntOE0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtK_VLfCEAABapA.png",
      "id_str" : "491665679917912064",
      "id" : 491665679917912064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtK_VLfCEAABapA.png",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 66,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/B4ZtnntOE0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/CaiBzcfOzT",
      "expanded_url" : "https:\/\/github.com\/Microsoft",
      "display_url" : "github.com\/Microsoft"
    } ]
  },
  "geo" : { },
  "id_str" : "492005145966698496",
  "text" : "RT @konklone: Microsoft has a GitHub account now, and their bio is basically an apology. https:\/\/t.co\/CaiBzcfOzT http:\/\/t.co\/B4ZtnntOE0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/konklone\/status\/491665680870014976\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/B4ZtnntOE0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtK_VLfCEAABapA.png",
        "id_str" : "491665679917912064",
        "id" : 491665679917912064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtK_VLfCEAABapA.png",
        "sizes" : [ {
          "h" : 234,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 66,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/B4ZtnntOE0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/CaiBzcfOzT",
        "expanded_url" : "https:\/\/github.com\/Microsoft",
        "display_url" : "github.com\/Microsoft"
      } ]
    },
    "geo" : { },
    "id_str" : "491665680870014976",
    "text" : "Microsoft has a GitHub account now, and their bio is basically an apology. https:\/\/t.co\/CaiBzcfOzT http:\/\/t.co\/B4ZtnntOE0",
    "id" : 491665680870014976,
    "created_at" : "2014-07-22 19:26:47 +0000",
    "user" : {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "protected" : false,
      "id_str" : "5232171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226668113\/blue_normal.png",
      "id" : 5232171,
      "verified" : false
    }
  },
  "id" : 492005145966698496,
  "created_at" : "2014-07-23 17:55:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marius Butuc",
      "screen_name" : "mariusbutuc",
      "indices" : [ 0, 12 ],
      "id_str" : "7290652",
      "id" : 7290652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/gLlyAXKtG9",
      "expanded_url" : "https:\/\/ti.to\/nickelcityruby\/coderetreat",
      "display_url" : "ti.to\/nickelcityruby\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "491990665895899138",
  "geo" : { },
  "id_str" : "491991286505693184",
  "in_reply_to_user_id" : 7290652,
  "text" : "@mariusbutuc Some details from last year: https:\/\/t.co\/gLlyAXKtG9 basically goes all day, intensive pairing and mind-bending.",
  "id" : 491991286505693184,
  "in_reply_to_status_id" : 491990665895899138,
  "created_at" : "2014-07-23 17:00:38 +0000",
  "in_reply_to_screen_name" : "mariusbutuc",
  "in_reply_to_user_id_str" : "7290652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marius Butuc",
      "screen_name" : "mariusbutuc",
      "indices" : [ 0, 12 ],
      "id_str" : "7290652",
      "id" : 7290652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491957585017196544",
  "geo" : { },
  "id_str" : "491987580401905664",
  "in_reply_to_user_id" : 7290652,
  "text" : "@mariusbutuc yes! We're locking down info. Hoping to have it all done this week. Have any specific questions?",
  "id" : 491987580401905664,
  "in_reply_to_status_id" : 491957585017196544,
  "created_at" : "2014-07-23 16:45:54 +0000",
  "in_reply_to_screen_name" : "mariusbutuc",
  "in_reply_to_user_id_str" : "7290652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Rudick",
      "screen_name" : "tmrudick",
      "indices" : [ 0, 9 ],
      "id_str" : "15198826",
      "id" : 15198826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491976226937270272",
  "geo" : { },
  "id_str" : "491976428158603264",
  "in_reply_to_user_id" : 15198826,
  "text" : "@tmrudick don't forget that smell too.",
  "id" : 491976428158603264,
  "in_reply_to_status_id" : 491976226937270272,
  "created_at" : "2014-07-23 16:01:35 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 3, 17 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 45, 60 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491951609983668225",
  "text" : "RT @SteelCityRuby: Lineup just announced for @nickelcityruby -- looks awesome!! Not that far a drive from Pittsburgh-- who wants to go on a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 26, 41 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491940190840057858",
    "text" : "Lineup just announced for @nickelcityruby -- looks awesome!! Not that far a drive from Pittsburgh-- who wants to go on a road trip in Oct???",
    "id" : 491940190840057858,
    "created_at" : "2014-07-23 13:37:35 +0000",
    "user" : {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "protected" : false,
      "id_str" : "404851600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551460511951228928\/ExkXJuce_normal.png",
      "id" : 404851600,
      "verified" : false
    }
  },
  "id" : 491951609983668225,
  "created_at" : "2014-07-23 14:22:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NqAX3XTbuf",
      "expanded_url" : "http:\/\/i.imgur.com\/7tH3XNR.png",
      "display_url" : "i.imgur.com\/7tH3XNR.png"
    } ]
  },
  "geo" : { },
  "id_str" : "491763509412102145",
  "text" : "Split out the pokemon battler to its own bot...and Professor Oak is unforgiving. http:\/\/t.co\/NqAX3XTbuf",
  "id" : 491763509412102145,
  "created_at" : "2014-07-23 01:55:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Eeeeeee",
      "screen_name" : "rare_basement",
      "indices" : [ 3, 17 ],
      "id_str" : "30957285",
      "id" : 30957285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491744840019746816",
  "text" : "RT @rare_basement: i need $250k so i can teach stray dogs to code",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491744406232260608",
    "text" : "i need $250k so i can teach stray dogs to code",
    "id" : 491744406232260608,
    "created_at" : "2014-07-23 00:39:37 +0000",
    "user" : {
      "name" : "Amber Eeeeeee",
      "screen_name" : "rare_basement",
      "protected" : false,
      "id_str" : "30957285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1673708657\/atwit_normal.PNG",
      "id" : 30957285,
      "verified" : false
    }
  },
  "id" : 491744840019746816,
  "created_at" : "2014-07-23 00:41:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491647664245964800",
  "geo" : { },
  "id_str" : "491648646283538432",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 yes! those ring lights and the venue was fantastic. Would rather go there than PGH or Mansfield.",
  "id" : 491648646283538432,
  "in_reply_to_status_id" : 491647664245964800,
  "created_at" : "2014-07-22 18:19:06 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491647276628987904",
  "geo" : { },
  "id_str" : "491647476542103552",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc I don't think they have hit here yet. But sounds like they might.",
  "id" : 491647476542103552,
  "in_reply_to_status_id" : 491647276628987904,
  "created_at" : "2014-07-22 18:14:27 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Caudill",
      "screen_name" : "voxdolo",
      "indices" : [ 0, 8 ],
      "id_str" : "8654722",
      "id" : 8654722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491645075852505088",
  "geo" : { },
  "id_str" : "491645585980547074",
  "in_reply_to_user_id" : 8654722,
  "text" : "@voxdolo oh nooooo CMON i just started a Dwarf Fortress game.",
  "id" : 491645585980547074,
  "in_reply_to_status_id" : 491645075852505088,
  "created_at" : "2014-07-22 18:06:56 +0000",
  "in_reply_to_screen_name" : "voxdolo",
  "in_reply_to_user_id_str" : "8654722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/m4x3VS3GFM",
      "expanded_url" : "http:\/\/fox8.com\/2014\/06\/20\/mayfly-invasion-bugs-causing-a-mess-along-lake-erie\/",
      "display_url" : "fox8.com\/2014\/06\/20\/may\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "491644070658605056",
  "geo" : { },
  "id_str" : "491644696263798786",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc uhhhhh http:\/\/t.co\/m4x3VS3GFM",
  "id" : 491644696263798786,
  "in_reply_to_status_id" : 491644070658605056,
  "created_at" : "2014-07-22 18:03:24 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/1fmd6Axsll",
      "expanded_url" : "http:\/\/www.kare11.com\/story\/news\/local\/2014\/07\/22\/mayfly-hatch-blankets-mississippi-river-communities\/12984001\/?utm_source=feedblitz&utm_medium=FeedBlitzRss&utm_campaign=kare\/home",
      "display_url" : "kare11.com\/story\/news\/loc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491642359013068800",
  "text" : "This is something out of a horror movie: http:\/\/t.co\/1fmd6Axsll",
  "id" : 491642359013068800,
  "created_at" : "2014-07-22 17:54:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bergquist",
      "screen_name" : "cbquist",
      "indices" : [ 3, 11 ],
      "id_str" : "16785742",
      "id" : 16785742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cbquist\/status\/491636337398022145\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/O5HdaczFrq",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtKkpCHCQAAlOIp.png",
      "id_str" : "491636334184775680",
      "id" : 491636334184775680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtKkpCHCQAAlOIp.png",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 536
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 536
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 536
      } ],
      "display_url" : "pic.twitter.com\/O5HdaczFrq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KFLGum7pgZ",
      "expanded_url" : "http:\/\/1.usa.gov\/1niE9zX",
      "display_url" : "1.usa.gov\/1niE9zX"
    } ]
  },
  "geo" : { },
  "id_str" : "491642327178301441",
  "text" : "RT @cbquist: That radar signal? It's from mayflies. \"massive mayfly event\" in upper Mississippi River basin http:\/\/t.co\/KFLGum7pgZ http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cbquist\/status\/491636337398022145\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/O5HdaczFrq",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtKkpCHCQAAlOIp.png",
        "id_str" : "491636334184775680",
        "id" : 491636334184775680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtKkpCHCQAAlOIp.png",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 536
        } ],
        "display_url" : "pic.twitter.com\/O5HdaczFrq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/KFLGum7pgZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1niE9zX",
        "display_url" : "1.usa.gov\/1niE9zX"
      } ]
    },
    "geo" : { },
    "id_str" : "491636337398022145",
    "text" : "That radar signal? It's from mayflies. \"massive mayfly event\" in upper Mississippi River basin http:\/\/t.co\/KFLGum7pgZ http:\/\/t.co\/O5HdaczFrq",
    "id" : 491636337398022145,
    "created_at" : "2014-07-22 17:30:11 +0000",
    "user" : {
      "name" : "Charles Bergquist",
      "screen_name" : "cbquist",
      "protected" : false,
      "id_str" : "16785742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562454709261172738\/OrQrpDJe_normal.jpeg",
      "id" : 16785742,
      "verified" : false
    }
  },
  "id" : 491642327178301441,
  "created_at" : "2014-07-22 17:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Herr",
      "screen_name" : "breaknewsman",
      "indices" : [ 0, 13 ],
      "id_str" : "459199157",
      "id" : 459199157
    }, {
      "name" : "Assemblyman SeanRyan",
      "screen_name" : "SeanMRyan149",
      "indices" : [ 14, 27 ],
      "id_str" : "455216345",
      "id" : 455216345
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 56, 70 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/491637196256858112\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GTsvBZtFiL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKla83CIAAqE6E.jpg",
      "id_str" : "491637191768940544",
      "id" : 491637191768940544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKla83CIAAqE6E.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/GTsvBZtFiL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491636492536520704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915091232, -78.8726938796 ]
  },
  "id_str" : "491637196256858112",
  "in_reply_to_user_id" : 459199157,
  "text" : "@breaknewsman @SeanMRyan149 yes! Small traffic jam with @coworkbuffalo\u2019s bikes today http:\/\/t.co\/GTsvBZtFiL",
  "id" : 491637196256858112,
  "in_reply_to_status_id" : 491636492536520704,
  "created_at" : "2014-07-22 17:33:36 +0000",
  "in_reply_to_screen_name" : "breaknewsman",
  "in_reply_to_user_id_str" : "459199157",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fort Pitt Web Shop",
      "screen_name" : "FortPittWeb",
      "indices" : [ 3, 15 ],
      "id_str" : "2281215073",
      "id" : 2281215073
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 56, 70 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pittsburgh",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2IpuQAYo8H",
      "expanded_url" : "http:\/\/steelcityruby.org",
      "display_url" : "steelcityruby.org"
    } ]
  },
  "geo" : { },
  "id_str" : "491637063649730561",
  "text" : "RT @FortPittWeb: Hey #Pittsburgh, only a few weeks \u2018til @SteelCityRuby! Get your tickets now: http:\/\/t.co\/2IpuQAYo8H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 39, 53 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pittsburgh",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/2IpuQAYo8H",
        "expanded_url" : "http:\/\/steelcityruby.org",
        "display_url" : "steelcityruby.org"
      } ]
    },
    "geo" : { },
    "id_str" : "491634996566687745",
    "text" : "Hey #Pittsburgh, only a few weeks \u2018til @SteelCityRuby! Get your tickets now: http:\/\/t.co\/2IpuQAYo8H",
    "id" : 491634996566687745,
    "created_at" : "2014-07-22 17:24:51 +0000",
    "user" : {
      "name" : "Fort Pitt Web Shop",
      "screen_name" : "FortPittWeb",
      "protected" : false,
      "id_str" : "2281215073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445980772277555201\/y9WboPI0_normal.png",
      "id" : 2281215073,
      "verified" : false
    }
  },
  "id" : 491637063649730561,
  "created_at" : "2014-07-22 17:33:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Software for Good",
      "screen_name" : "softwareforgood",
      "indices" : [ 3, 19 ],
      "id_str" : "94656986",
      "id" : 94656986
    }, {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 33, 47 ],
      "id_str" : "15913837",
      "id" : 15913837
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DQF28QfoEj",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#talks",
      "display_url" : "nickelcityruby.com\/#talks"
    } ]
  },
  "geo" : { },
  "id_str" : "491622212751740928",
  "text" : "RT @softwareforgood: Congrats to @MutualArising on being selected to speak @nickelcityruby in October. http:\/\/t.co\/DQF28QfoEj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric S",
        "screen_name" : "MutualArising",
        "indices" : [ 12, 26 ],
        "id_str" : "15913837",
        "id" : 15913837
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 54, 69 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/DQF28QfoEj",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#talks",
        "display_url" : "nickelcityruby.com\/#talks"
      } ]
    },
    "geo" : { },
    "id_str" : "491598741984407552",
    "text" : "Congrats to @MutualArising on being selected to speak @nickelcityruby in October. http:\/\/t.co\/DQF28QfoEj",
    "id" : 491598741984407552,
    "created_at" : "2014-07-22 15:00:48 +0000",
    "user" : {
      "name" : "Software for Good",
      "screen_name" : "softwareforgood",
      "protected" : false,
      "id_str" : "94656986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420557665635270656\/hOzpUJnK_normal.jpeg",
      "id" : 94656986,
      "verified" : false
    }
  },
  "id" : 491622212751740928,
  "created_at" : "2014-07-22 16:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_leticia",
      "screen_name" : "_leticia",
      "indices" : [ 3, 12 ],
      "id_str" : "14478745",
      "id" : 14478745
    }, {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 24, 33 ],
      "id_str" : "49102992",
      "id" : 49102992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 48, 63 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491592287919411202",
  "text" : "RT @_leticia: My friend @poteland is speaking @ @nickelcityruby and he's looking for sponsorships. Companies, look at this guy! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pote",
        "screen_name" : "poteland",
        "indices" : [ 10, 19 ],
        "id_str" : "49102992",
        "id" : 49102992
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 34, 49 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491579452225490944",
    "text" : "My friend @poteland is speaking @ @nickelcityruby and he's looking for sponsorships. Companies, look at this guy! :)",
    "id" : 491579452225490944,
    "created_at" : "2014-07-22 13:44:09 +0000",
    "user" : {
      "name" : "_leticia",
      "screen_name" : "_leticia",
      "protected" : false,
      "id_str" : "14478745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1105002956\/fande_8_normal.jpg",
      "id" : 14478745,
      "verified" : false
    }
  },
  "id" : 491592287919411202,
  "created_at" : "2014-07-22 14:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 3, 12 ],
      "id_str" : "49102992",
      "id" : 49102992
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 62, 77 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/FQTmn9g24Z",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "491592259540754433",
  "text" : "RT @poteland: I'm exited to announce that I'll be speaking at @nickelcityruby in October!! Brilliant speaker lineup, can't wait &lt;3 \nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 48, 63 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/FQTmn9g24Z",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "491576072841203712",
    "text" : "I'm exited to announce that I'll be speaking at @nickelcityruby in October!! Brilliant speaker lineup, can't wait &lt;3 \nhttp:\/\/t.co\/FQTmn9g24Z",
    "id" : 491576072841203712,
    "created_at" : "2014-07-22 13:30:43 +0000",
    "user" : {
      "name" : "pote",
      "screen_name" : "poteland",
      "protected" : false,
      "id_str" : "49102992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1395984707\/RedMage_normal.png",
      "id" : 49102992,
      "verified" : false
    }
  },
  "id" : 491592259540754433,
  "created_at" : "2014-07-22 14:35:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 3, 17 ],
      "id_str" : "15913837",
      "id" : 15913837
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 53, 68 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491592242130210816",
  "text" : "RT @MutualArising: Happy to announce I'm speaking at @nickelcityruby this year! Hope to see you in lovely Buffalo in October!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 34, 49 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491445600466919424",
    "text" : "Happy to announce I'm speaking at @nickelcityruby this year! Hope to see you in lovely Buffalo in October!",
    "id" : 491445600466919424,
    "created_at" : "2014-07-22 04:52:16 +0000",
    "user" : {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "protected" : false,
      "id_str" : "15913837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000473983129\/c7b155bfe4b6374c5d3c517105d61a14_normal.jpeg",
      "id" : 15913837,
      "verified" : false
    }
  },
  "id" : 491592242130210816,
  "created_at" : "2014-07-22 14:34:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 16, 31 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/491587182025379840\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/9pIGLwFcBX",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtJ37yBCIAA9i20.png",
      "id_str" : "491587178258898944",
      "id" : 491587178258898944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtJ37yBCIAA9i20.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/9pIGLwFcBX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/k0JoWwqapI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "491587182025379840",
  "text" : "Here's our 2014 @nickelcityruby speaker lineup: http:\/\/t.co\/k0JoWwqapI IT'S HAPPENING!!! http:\/\/t.co\/9pIGLwFcBX",
  "id" : 491587182025379840,
  "created_at" : "2014-07-22 14:14:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491578047888240640",
  "text" : "RT @nickelcityruby: We had 115 AMAZING submissions to the CFP. Thanks to everyone that submitted!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491574966559596546",
    "text" : "We had 115 AMAZING submissions to the CFP. Thanks to everyone that submitted!",
    "id" : 491574966559596546,
    "created_at" : "2014-07-22 13:26:19 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 491578047888240640,
  "created_at" : "2014-07-22 13:38:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ELasYXyqKQ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "491578028737048577",
  "text" : "RT @nickelcityruby: We're excited to announce our speaker lineup! http:\/\/t.co\/ELasYXyqKQ\nWe'll be doing speaker spotlights over the next fe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/ELasYXyqKQ",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "491574292249735168",
    "text" : "We're excited to announce our speaker lineup! http:\/\/t.co\/ELasYXyqKQ\nWe'll be doing speaker spotlights over the next few weeks! Stay tuned!!",
    "id" : 491574292249735168,
    "created_at" : "2014-07-22 13:23:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 491578028737048577,
  "created_at" : "2014-07-22 13:38:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HdguO8oIn1",
      "expanded_url" : "http:\/\/i.imgur.com\/tQ96FAe.jpg",
      "display_url" : "i.imgur.com\/tQ96FAe.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "491411919526297600",
  "text" : "Brains are dumb. Considering learning piano and it seems daunting. This Dwarf Fortress flowchart though? No problem. http:\/\/t.co\/HdguO8oIn1",
  "id" : 491411919526297600,
  "created_at" : "2014-07-22 02:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 2, 8 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 64, 76 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491409269103656960",
  "text" : "4 @phish concerts so far for this month and closing it out with @AqueousBand this week. Problem? (nope!)",
  "id" : 491409269103656960,
  "created_at" : "2014-07-22 02:27:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491406185279414272",
  "geo" : { },
  "id_str" : "491407916591616000",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller this is great for small array lengths (several thousand ish)\u2026found my first segfault when giving it way too much data once",
  "id" : 491407916591616000,
  "in_reply_to_status_id" : 491406185279414272,
  "created_at" : "2014-07-22 02:22:31 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491402693668110340",
  "text" : "RT @drbrain: Today I start work on improving RubyGems\u2194\uFE0EBundler compatibility thanks to a grant from Ruby Central",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491273153813819392",
    "text" : "Today I start work on improving RubyGems\u2194\uFE0EBundler compatibility thanks to a grant from Ruby Central",
    "id" : 491273153813819392,
    "created_at" : "2014-07-21 17:27:01 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 491402693668110340,
  "created_at" : "2014-07-22 02:01:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/9vQNo1MN5j",
      "expanded_url" : "http:\/\/www.marco.org\/2011\/05\/26\/geek-intro-to-phish",
      "display_url" : "marco.org\/2011\/05\/26\/gee\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "491398354321297408",
  "geo" : { },
  "id_str" : "491398588157530113",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr as you know, it's never too late: http:\/\/t.co\/9vQNo1MN5j",
  "id" : 491398588157530113,
  "in_reply_to_status_id" : 491398354321297408,
  "created_at" : "2014-07-22 01:45:27 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491396393102475264",
  "geo" : { },
  "id_str" : "491396610006343680",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats Dang. because you need to stop for a roast beef sandwich from Mimi's in Waltham. Charlie's has nothing on it.",
  "id" : 491396610006343680,
  "in_reply_to_status_id" : 491396393102475264,
  "created_at" : "2014-07-22 01:37:36 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491395733707558913",
  "geo" : { },
  "id_str" : "491395873486536704",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats Did you drive? Are you headed back through MA?",
  "id" : 491395873486536704,
  "in_reply_to_status_id" : 491395733707558913,
  "created_at" : "2014-07-22 01:34:40 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eeph6CuiFt",
      "expanded_url" : "http:\/\/blog.priceonomics.com\/post\/48216173465\/the-business-of-phish",
      "display_url" : "blog.priceonomics.com\/post\/482161734\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491383259147042817",
  "text" : "\"It\u2019s also what ended up making them gob fulls of money, so that worked out nicely.\" - http:\/\/t.co\/eeph6CuiFt",
  "id" : 491383259147042817,
  "created_at" : "2014-07-22 00:44:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 7, 20 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/0iF0CkXSYi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wGpqbqzQ8Nc",
      "display_url" : "youtube.com\/watch?v=wGpqbq\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "491329708114456576",
  "geo" : { },
  "id_str" : "491330002877558784",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @jennschiffer https:\/\/t.co\/0iF0CkXSYi",
  "id" : 491330002877558784,
  "in_reply_to_status_id" : 491329708114456576,
  "created_at" : "2014-07-21 21:12:55 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491320365059432448",
  "geo" : { },
  "id_str" : "491320526145462272",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora Well you could just buy another Roomba.",
  "id" : 491320526145462272,
  "in_reply_to_status_id" : 491320365059432448,
  "created_at" : "2014-07-21 20:35:16 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491310791552139265",
  "geo" : { },
  "id_str" : "491311004257886208",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora Until you have to dig hair out of it with its special comb. Just wait.",
  "id" : 491311004257886208,
  "in_reply_to_status_id" : 491310791552139265,
  "created_at" : "2014-07-21 19:57:26 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/nuG4QNgkX6",
      "expanded_url" : "http:\/\/www.clickhole.com\/video\/watch-supercut-every-time-harrison-ford-says-harri-553",
      "display_url" : "clickhole.com\/video\/watch-su\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239146573, -78.879102358 ]
  },
  "id_str" : "491308569531121664",
  "text" : "HARRISON FORD. http:\/\/t.co\/nuG4QNgkX6",
  "id" : 491308569531121664,
  "created_at" : "2014-07-21 19:47:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491302936132083712",
  "text" : "Sending out some rejections for @nickelcityruby today. This is making me sad, too many nice people and talks, not enough slots.",
  "id" : 491302936132083712,
  "created_at" : "2014-07-21 19:25:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Thor Jensen",
      "screen_name" : "kthorjensen",
      "indices" : [ 3, 15 ],
      "id_str" : "25319959",
      "id" : 25319959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/NuzA6cXeTH",
      "expanded_url" : "https:\/\/33.media.tumblr.com\/d2b403eea168ce6844fb084936c5d6fe\/tumblr_n92lz21CMF1tc3qa6o1_500.png",
      "display_url" : "33.media.tumblr.com\/d2b403eea168ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491290969212338177",
  "text" : "RT @kthorjensen: damn Ryu is 50 today https:\/\/t.co\/NuzA6cXeTH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/NuzA6cXeTH",
        "expanded_url" : "https:\/\/33.media.tumblr.com\/d2b403eea168ce6844fb084936c5d6fe\/tumblr_n92lz21CMF1tc3qa6o1_500.png",
        "display_url" : "33.media.tumblr.com\/d2b403eea168ce\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "491288678333812736",
    "text" : "damn Ryu is 50 today https:\/\/t.co\/NuzA6cXeTH",
    "id" : 491288678333812736,
    "created_at" : "2014-07-21 18:28:43 +0000",
    "user" : {
      "name" : "K. Thor Jensen",
      "screen_name" : "kthorjensen",
      "protected" : false,
      "id_str" : "25319959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458811893449117696\/PgPopg33_normal.jpeg",
      "id" : 25319959,
      "verified" : false
    }
  },
  "id" : 491290969212338177,
  "created_at" : "2014-07-21 18:37:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 3, 14 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/wGnBffdgee",
      "expanded_url" : "http:\/\/domflags.com\/",
      "display_url" : "domflags.com"
    } ]
  },
  "geo" : { },
  "id_str" : "491271491913129984",
  "text" : "RT @phillapier: Finally shipped! DomFlags \u2013 a devtools extension to create keyboard shortcuts to DOM elements. http:\/\/t.co\/wGnBffdgee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/wGnBffdgee",
        "expanded_url" : "http:\/\/domflags.com\/",
        "display_url" : "domflags.com"
      } ]
    },
    "geo" : { },
    "id_str" : "491271381959847936",
    "text" : "Finally shipped! DomFlags \u2013 a devtools extension to create keyboard shortcuts to DOM elements. http:\/\/t.co\/wGnBffdgee",
    "id" : 491271381959847936,
    "created_at" : "2014-07-21 17:19:59 +0000",
    "user" : {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "protected" : false,
      "id_str" : "14555937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524667159994064896\/cBqViwE3_normal.jpeg",
      "id" : 14555937,
      "verified" : false
    }
  },
  "id" : 491271491913129984,
  "created_at" : "2014-07-21 17:20:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Kineke",
      "screen_name" : "ZKineke",
      "indices" : [ 0, 8 ],
      "id_str" : "30627125",
      "id" : 30627125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491230361092128769",
  "geo" : { },
  "id_str" : "491231281552695296",
  "in_reply_to_user_id" : 30627125,
  "text" : "@ZKineke ah ha. geez.",
  "id" : 491231281552695296,
  "in_reply_to_status_id" : 491230361092128769,
  "created_at" : "2014-07-21 14:40:38 +0000",
  "in_reply_to_screen_name" : "ZKineke",
  "in_reply_to_user_id_str" : "30627125",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3fMdt5yp88",
      "expanded_url" : "http:\/\/www.wgrz.com\/story\/news\/local\/westside\/2014\/07\/20\/buffalo-police-missing-person-alert\/12923995\/",
      "display_url" : "wgrz.com\/story\/news\/loc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491228653557010432",
  "text" : "Awful: No amber alert for a missing 11 year old from Buffalo. But a teen runs away in Rochester and everyone gets it: http:\/\/t.co\/3fMdt5yp88",
  "id" : 491228653557010432,
  "created_at" : "2014-07-21 14:30:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491066006799147008",
  "geo" : { },
  "id_str" : "491066138436984832",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive been listening to Mansfield\u2019s continually. Can\u2019t wait to hear this one.",
  "id" : 491066138436984832,
  "in_reply_to_status_id" : 491066006799147008,
  "created_at" : "2014-07-21 03:44:25 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491046668104519680",
  "text" : "@juliepagano SPACESHIP!! SPACESSSHIPP!!!!!!",
  "id" : 491046668104519680,
  "created_at" : "2014-07-21 02:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491043943023263745",
  "geo" : { },
  "id_str" : "491046602329440257",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester brutal, sorry to hear :(",
  "id" : 491046602329440257,
  "in_reply_to_status_id" : 491043943023263745,
  "created_at" : "2014-07-21 02:26:47 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491029695962836992",
  "geo" : { },
  "id_str" : "491030434277363713",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal of course, it's Dwarf Fortress. Also agree with previous reply.",
  "id" : 491030434277363713,
  "in_reply_to_status_id" : 491029695962836992,
  "created_at" : "2014-07-21 01:22:33 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491028021919223808",
  "text" : "Couldn't make this up if I tried, straight from the Dwarf Fortress release notes: \"Babies don't start strapped with a knife\"",
  "id" : 491028021919223808,
  "created_at" : "2014-07-21 01:12:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PaPvMfv9FY",
      "expanded_url" : "http:\/\/robnapier.net\/i-dont-know-swift",
      "display_url" : "robnapier.net\/i-dont-know-sw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491026485629579265",
  "text" : "Ouch: \"[Apple should] spend several months writing nontrivial applications in the language and reviewing the results\" http:\/\/t.co\/PaPvMfv9FY",
  "id" : 491026485629579265,
  "created_at" : "2014-07-21 01:06:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491024542127493121",
  "geo" : { },
  "id_str" : "491024854301147136",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo stream dumped on Hood? Oh man. That was fucking amazing.",
  "id" : 491024854301147136,
  "in_reply_to_status_id" : 491024542127493121,
  "created_at" : "2014-07-21 01:00:22 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491014554319474689",
  "text" : "RT @dwarfort_txt: stopped ghosts from maintaining secret identities",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491009922662817793",
    "text" : "stopped ghosts from maintaining secret identities",
    "id" : 491009922662817793,
    "created_at" : "2014-07-21 00:01:02 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 491014554319474689,
  "created_at" : "2014-07-21 00:19:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490998355611619328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0553924472, -78.8642384647 ]
  },
  "id_str" : "491001546663268352",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded uhhhhhhhhhhhhhhhhh",
  "id" : 491001546663268352,
  "in_reply_to_status_id" : 490998355611619328,
  "created_at" : "2014-07-20 23:27:45 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490889185939578881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9347741416, -78.7318773367 ]
  },
  "id_str" : "490942182644129792",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff you\u2019ll do awesome. Congrats!!!",
  "id" : 490942182644129792,
  "in_reply_to_status_id" : 490889185939578881,
  "created_at" : "2014-07-20 19:31:52 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9366374994, -78.7315452286 ]
  },
  "id_str" : "490942059834929152",
  "text" : "Of course, new dwarf fort version is out just as I start a fortress inside a waterfall surrounded by wild cotton and huge trees",
  "id" : 490942059834929152,
  "created_at" : "2014-07-20 19:31:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bay 12 Games",
      "screen_name" : "Bay12Games",
      "indices" : [ 3, 14 ],
      "id_str" : "1721634937",
      "id" : 1721634937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/IWSnbP5AQk",
      "expanded_url" : "http:\/\/www.bay12games.com\/dwarves",
      "display_url" : "bay12games.com\/dwarves"
    } ]
  },
  "geo" : { },
  "id_str" : "490941830041567232",
  "text" : "RT @Bay12Games: Dwarf Fortress 0.40.04 is up at http:\/\/t.co\/IWSnbP5AQk\nMore crashes fixed, fewer idle dwarves in trees, fewer babies with k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/IWSnbP5AQk",
        "expanded_url" : "http:\/\/www.bay12games.com\/dwarves",
        "display_url" : "bay12games.com\/dwarves"
      } ]
    },
    "geo" : { },
    "id_str" : "490938310504620032",
    "text" : "Dwarf Fortress 0.40.04 is up at http:\/\/t.co\/IWSnbP5AQk\nMore crashes fixed, fewer idle dwarves in trees, fewer babies with knives",
    "id" : 490938310504620032,
    "created_at" : "2014-07-20 19:16:29 +0000",
    "user" : {
      "name" : "Bay 12 Games",
      "screen_name" : "Bay12Games",
      "protected" : false,
      "id_str" : "1721634937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000399430976\/3e4cbdc8054f9a456f5c236825513d21_normal.png",
      "id" : 1721634937,
      "verified" : false
    }
  },
  "id" : 490941830041567232,
  "created_at" : "2014-07-20 19:30:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9760663052, -87.907048859 ]
  },
  "id_str" : "490918482679050240",
  "text" : "Bye Chicago, it\u2019s been real. Thanks for all the random friend meetups.",
  "id" : 490918482679050240,
  "created_at" : "2014-07-20 17:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/FrR0Aqpd8X",
      "expanded_url" : "http:\/\/copsub.com\/\/wp_blog\/wp_content\/uploads\/2014\/07\/sys_eng.jpg",
      "display_url" : "copsub.com\/\/wp_blog\/wp_co\u2026"
    }, {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Tmfz015yLN",
      "expanded_url" : "http:\/\/copsub.com\/the-thermodynamic-ice-bag\/",
      "display_url" : "copsub.com\/the-thermodyna\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "490843382646710272",
  "text" : "Many parallels to this in web\/app design: A spacecraft according to\u2026 http:\/\/t.co\/FrR0Aqpd8X  (from http:\/\/t.co\/Tmfz015yLN)",
  "id" : 490843382646710272,
  "created_at" : "2014-07-20 12:59:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490670549379862528",
  "geo" : { },
  "id_str" : "490671786145497088",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive it felt that way!",
  "id" : 490671786145497088,
  "in_reply_to_status_id" : 490670549379862528,
  "created_at" : "2014-07-20 01:37:24 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/qB1vHo3koT",
      "expanded_url" : "https:\/\/flic.kr\/p\/o6XETW",
      "display_url" : "flic.kr\/p\/o6XETW"
    } ]
  },
  "geo" : { },
  "id_str" : "490617314102870016",
  "text" : "Current preshow status https:\/\/t.co\/qB1vHo3koT",
  "id" : 490617314102870016,
  "created_at" : "2014-07-19 22:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490349351185944576",
  "geo" : { },
  "id_str" : "490349662579093504",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo the CMAC download was ready before we left the lot even. Crazy.",
  "id" : 490349662579093504,
  "in_reply_to_status_id" : 490349351185944576,
  "created_at" : "2014-07-19 04:17:24 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 0, 12 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490334336126697474",
  "geo" : { },
  "id_str" : "490336111411994627",
  "in_reply_to_user_id" : 14231571,
  "text" : "@marcoarment why aren't you listening to the phish webcast!?",
  "id" : 490336111411994627,
  "in_reply_to_status_id" : 490334336126697474,
  "created_at" : "2014-07-19 03:23:33 +0000",
  "in_reply_to_screen_name" : "marcoarment",
  "in_reply_to_user_id_str" : "14231571",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490331286721298432",
  "text" : "Missing Piper by one night yet again!",
  "id" : 490331286721298432,
  "created_at" : "2014-07-19 03:04:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 22, 31 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490324123898241024",
  "text" : "First time running an @openhack in another city tonight. Happy to see this works well elsewhere. Thanks to everyone who came!",
  "id" : 490324123898241024,
  "created_at" : "2014-07-19 02:35:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490171111582072833",
  "geo" : { },
  "id_str" : "490318774491697152",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney I passed a place on Lake with a lot of \"LOOK -&gt;\" graffiti and plexiglass. Was too scared to peek.",
  "id" : 490318774491697152,
  "in_reply_to_status_id" : 490171111582072833,
  "created_at" : "2014-07-19 02:14:40 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basecamp",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/6M7ZGGqN41",
      "expanded_url" : "https:\/\/flic.kr\/p\/onxUVj",
      "display_url" : "flic.kr\/p\/onxUVj"
    } ]
  },
  "geo" : { },
  "id_str" : "490229147566751744",
  "text" : "Spotted: real life #basecamp! https:\/\/t.co\/6M7ZGGqN41",
  "id" : 490229147566751744,
  "created_at" : "2014-07-18 20:18:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/pMQKBl6WiZ",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53c97df6498e26c01843599a?s=b_6dwkV6ZT-L4ErtO99zHHWCLmw&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8983273651, -87.6868328988 ]
  },
  "id_str" : "490225809140240385",
  "text" : "I'm at Pitchfork Music Festival (Chicago, IL) w\/ 12 others https:\/\/t.co\/pMQKBl6WiZ",
  "id" : 490225809140240385,
  "created_at" : "2014-07-18 20:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/McJmE7Gepw",
      "expanded_url" : "https:\/\/flic.kr\/p\/o6gJXp",
      "display_url" : "flic.kr\/p\/o6gJXp"
    } ]
  },
  "geo" : { },
  "id_str" : "490222755497791488",
  "text" : "H2OOOO https:\/\/t.co\/McJmE7Gepw",
  "id" : 490222755497791488,
  "created_at" : "2014-07-18 19:53:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 32, 42 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/duG5jScuwu",
      "expanded_url" : "https:\/\/flic.kr\/p\/opoivg",
      "display_url" : "flic.kr\/p\/opoivg"
    } ]
  },
  "geo" : { },
  "id_str" : "490164777956564992",
  "text" : "Did not expect this Museum near @37signals. https:\/\/t.co\/duG5jScuwu",
  "id" : 490164777956564992,
  "created_at" : "2014-07-18 16:02:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Elmwood Village ",
      "screen_name" : "ElmwoodVillage",
      "indices" : [ 114, 129 ],
      "id_str" : "25105151",
      "id" : 25105151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kcRssvunaW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=V5t4VkvXQaM&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=V5t4Vk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "490161112747241472",
  "text" : "RT @AqueousBand: If you haven't already, take a minute here and check out some of our recent Bidwell Park show in @ElmwoodVillage!\n\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elmwood Village ",
        "screen_name" : "ElmwoodVillage",
        "indices" : [ 97, 112 ],
        "id_str" : "25105151",
        "id" : 25105151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kcRssvunaW",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=V5t4VkvXQaM&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=V5t4Vk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "490160653681037312",
    "text" : "If you haven't already, take a minute here and check out some of our recent Bidwell Park show in @ElmwoodVillage!\n\nhttp:\/\/t.co\/kcRssvunaW",
    "id" : 490160653681037312,
    "created_at" : "2014-07-18 15:46:21 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 490161112747241472,
  "created_at" : "2014-07-18 15:48:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490155876796203008",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda \"Software Mechanic\"",
  "id" : 490155876796203008,
  "created_at" : "2014-07-18 15:27:22 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8857646874, -87.6284054574 ]
  },
  "id_str" : "490145897137713153",
  "text" : "It\u2019s normal to feel completely unsafe as the entire El platform sways when a train arrives, right?",
  "id" : 490145897137713153,
  "created_at" : "2014-07-18 14:47:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6hCblC52WT",
      "expanded_url" : "http:\/\/www.investigativepost.org\/2014\/07\/17\/the-scajaquada-crippled-creek\/",
      "display_url" : "investigativepost.org\/2014\/07\/17\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "490138200162054144",
  "text" : "RT @kevinpurdy: Building the Walden Galleria took away 65 percent of the wetlands that once filtered the (putrid) Scajaquada Creek: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6hCblC52WT",
        "expanded_url" : "http:\/\/www.investigativepost.org\/2014\/07\/17\/the-scajaquada-crippled-creek\/",
        "display_url" : "investigativepost.org\/2014\/07\/17\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "490137869319553024",
    "text" : "Building the Walden Galleria took away 65 percent of the wetlands that once filtered the (putrid) Scajaquada Creek: http:\/\/t.co\/6hCblC52WT",
    "id" : 490137869319553024,
    "created_at" : "2014-07-18 14:15:49 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 490138200162054144,
  "created_at" : "2014-07-18 14:17:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 0, 10 ],
      "id_str" : "15031577",
      "id" : 15031577
    }, {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 11, 16 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 70, 78 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 79, 87 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490127875786678272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9497198845, -87.7247971371 ]
  },
  "id_str" : "490129084316270593",
  "in_reply_to_user_id" : 15031577,
  "text" : "@tcopeland @JEG2 where is the rubygems developers list moving to? \/cc @drbrain @evanphx",
  "id" : 490129084316270593,
  "in_reply_to_status_id" : 490127875786678272,
  "created_at" : "2014-07-18 13:40:54 +0000",
  "in_reply_to_screen_name" : "tcopeland",
  "in_reply_to_user_id_str" : "15031577",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490120389238865923",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97963824, -87.9069041947 ]
  },
  "id_str" : "490121284945051648",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh I left it at home with my BROLTIMORE aviators",
  "id" : 490121284945051648,
  "in_reply_to_status_id" : 490120389238865923,
  "created_at" : "2014-07-18 13:09:55 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9785416266, -87.9102224764 ]
  },
  "id_str" : "490118489466617856",
  "text" : "Hello Chicago. Apparently \u201CBROHIO\u201D shirts exist and I want to injure something.",
  "id" : 490118489466617856,
  "created_at" : "2014-07-18 12:58:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490113558672207876",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.0010154369, -87.9259398022 ]
  },
  "id_str" : "490114250992406529",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit I was hoping for some kind of graffiti or evil portal behind it",
  "id" : 490114250992406529,
  "in_reply_to_status_id" : 490113558672207876,
  "created_at" : "2014-07-18 12:41:57 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/490078522845589504\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/txhCz33OIx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bs0b0W7CQAAYsLn.png",
      "id_str" : "490078520773591040",
      "id" : 490078520773591040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bs0b0W7CQAAYsLn.png",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1738
      } ],
      "display_url" : "pic.twitter.com\/txhCz33OIx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490078522845589504",
  "text" : "Dwarf Fortress has a calendar now while loading a world. I cannot imagine the horrors. http:\/\/t.co\/txhCz33OIx",
  "id" : 490078522845589504,
  "created_at" : "2014-07-18 10:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Borenstein",
      "screen_name" : "pborenstein",
      "indices" : [ 0, 12 ],
      "id_str" : "3675931",
      "id" : 3675931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489952235603099648",
  "geo" : { },
  "id_str" : "489953066653741057",
  "in_reply_to_user_id" : 3675931,
  "text" : "@pborenstein Awesome! thanks.",
  "id" : 489953066653741057,
  "in_reply_to_status_id" : 489952235603099648,
  "created_at" : "2014-07-18 02:01:28 +0000",
  "in_reply_to_screen_name" : "pborenstein",
  "in_reply_to_user_id_str" : "3675931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/489950670917615616\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/C5B0v6Xk1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsynidGCAAIf902.png",
      "id_str" : "489950669843857410",
      "id" : 489950669843857410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsynidGCAAIf902.png",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 872,
        "resize" : "fit",
        "w" : 1508
      } ],
      "display_url" : "pic.twitter.com\/C5B0v6Xk1d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489950670917615616",
  "text" : "New Dwarf Fortress does not seem to work well on OSX. :( http:\/\/t.co\/C5B0v6Xk1d",
  "id" : 489950670917615616,
  "created_at" : "2014-07-18 01:51:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "triflin brand indeed",
      "screen_name" : "vogon",
      "indices" : [ 0, 6 ],
      "id_str" : "6326912",
      "id" : 6326912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489947186269270016",
  "geo" : { },
  "id_str" : "489947348059963392",
  "in_reply_to_user_id" : 6326912,
  "text" : "@vogon everything is great until you reach the Mun and realize your landing gear is on backwards",
  "id" : 489947348059963392,
  "in_reply_to_status_id" : 489947186269270016,
  "created_at" : "2014-07-18 01:38:45 +0000",
  "in_reply_to_screen_name" : "vogon",
  "in_reply_to_user_id_str" : "6326912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489844488169205760",
  "geo" : { },
  "id_str" : "489845896071229440",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi Do you live in 1900?",
  "id" : 489845896071229440,
  "in_reply_to_status_id" : 489844488169205760,
  "created_at" : "2014-07-17 18:55:37 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/bEtyWOXeEA",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aNL0UIk6QPs",
      "display_url" : "youtube.com\/watch?v=aNL0UI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "489830429575225344",
  "geo" : { },
  "id_str" : "489830690364461056",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard apparently this song works on most dogs, not him though https:\/\/t.co\/bEtyWOXeEA",
  "id" : 489830690364461056,
  "in_reply_to_status_id" : 489830429575225344,
  "created_at" : "2014-07-17 17:55:11 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessicard",
      "screen_name" : "jessicard",
      "indices" : [ 0, 10 ],
      "id_str" : "253464752",
      "id" : 253464752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489809873505632257",
  "geo" : { },
  "id_str" : "489830263191375872",
  "in_reply_to_user_id" : 253464752,
  "text" : "@jessicard almost got my husky doing this yesterday. Will video next time.",
  "id" : 489830263191375872,
  "in_reply_to_status_id" : 489809873505632257,
  "created_at" : "2014-07-17 17:53:30 +0000",
  "in_reply_to_screen_name" : "jessicard",
  "in_reply_to_user_id_str" : "253464752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley needs tats",
      "screen_name" : "rabcyr",
      "indices" : [ 0, 7 ],
      "id_str" : "26157562",
      "id" : 26157562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489827663314309120",
  "geo" : { },
  "id_str" : "489827817639526400",
  "in_reply_to_user_id" : 26157562,
  "text" : "@rabcyr i cannot imagine how awful this must be",
  "id" : 489827817639526400,
  "in_reply_to_status_id" : 489827663314309120,
  "created_at" : "2014-07-17 17:43:46 +0000",
  "in_reply_to_screen_name" : "rabcyr",
  "in_reply_to_user_id_str" : "26157562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/jsxiss1qyD",
      "expanded_url" : "http:\/\/m.rollingstone.com\/music\/news\/paul-mccartney-the-long-and-winding-q-a-20140717",
      "display_url" : "m.rollingstone.com\/music\/news\/pau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489827556367925249",
  "text" : "*Paul McCartney* on setlists: \"But it's not like I'm Phish, you know.\" http:\/\/t.co\/jsxiss1qyD",
  "id" : 489827556367925249,
  "created_at" : "2014-07-17 17:42:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "indices" : [ 70, 82 ],
      "id_str" : "2347646468",
      "id" : 2347646468
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BrutalHouse\/status\/489622772914876416\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/K8glCqbvbv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
      "id_str" : "489622769747783680",
      "id" : 489622769747783680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1311,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/K8glCqbvbv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243515991, -78.8790760283 ]
  },
  "id_str" : "489624494512676867",
  "text" : "My safe house for when the zombies come. Have had dreams about this. \u201C@BrutalHouse:\nBuffalo City Court Building http:\/\/t.co\/K8glCqbvbv\u201D",
  "id" : 489624494512676867,
  "created_at" : "2014-07-17 04:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "indices" : [ 3, 15 ],
      "id_str" : "2347646468",
      "id" : 2347646468
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BrutalHouse\/status\/489622772914876416\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/HamwUmU1em",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
      "id_str" : "489622769747783680",
      "id" : 489622769747783680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1311,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HamwUmU1em"
    } ],
    "hashtags" : [ {
      "text" : "Brutal",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489624244729307138",
  "text" : "RT @BrutalHouse: A #Brutal Masterpiece\n\u2014\nBuffalo City Court Building, New York State http:\/\/t.co\/HamwUmU1em",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BrutalHouse\/status\/489622772914876416\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/HamwUmU1em",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
        "id_str" : "489622769747783680",
        "id" : 489622769747783680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bst9UKDCcAAWMyT.jpg",
        "sizes" : [ {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1311,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HamwUmU1em"
      } ],
      "hashtags" : [ {
        "text" : "Brutal",
        "indices" : [ 2, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489622772914876416",
    "text" : "A #Brutal Masterpiece\n\u2014\nBuffalo City Court Building, New York State http:\/\/t.co\/HamwUmU1em",
    "id" : 489622772914876416,
    "created_at" : "2014-07-17 04:09:00 +0000",
    "user" : {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "protected" : false,
      "id_str" : "2347646468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442441264932200448\/GL0rhIe5_normal.jpeg",
      "id" : 2347646468,
      "verified" : false
    }
  },
  "id" : 489624244729307138,
  "created_at" : "2014-07-17 04:14:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489622296093786112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242725085, -78.8789956683 ]
  },
  "id_str" : "489622457993543680",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo too short. 2001 was awesome.",
  "id" : 489622457993543680,
  "in_reply_to_status_id" : 489622296093786112,
  "created_at" : "2014-07-17 04:07:45 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    }, {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 7, 18 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489596985561731072",
  "geo" : { },
  "id_str" : "489597718596042753",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx @bizarchive has a song been repeated like Fuego on every venue for a tour before? Been thinking of ways to visualize this...",
  "id" : 489597718596042753,
  "in_reply_to_status_id" : 489596985561731072,
  "created_at" : "2014-07-17 02:29:27 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 16, 25 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 26, 39 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489593520273895424",
  "geo" : { },
  "id_str" : "489597100129124353",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @LawnMemo @antelopeezer 24 hours too late! Maybe in Chicago.",
  "id" : 489597100129124353,
  "in_reply_to_status_id" : 489593520273895424,
  "created_at" : "2014-07-17 02:26:59 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/sEC00Rk9vx",
      "expanded_url" : "http:\/\/mixlr.com\/lvnphish\/",
      "display_url" : "mixlr.com\/lvnphish\/"
    } ]
  },
  "in_reply_to_status_id_str" : "489594749880258560",
  "geo" : { },
  "id_str" : "489596088899235840",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody Not at tonight's, but: http:\/\/t.co\/sEC00Rk9vx",
  "id" : 489596088899235840,
  "in_reply_to_status_id" : 489594749880258560,
  "created_at" : "2014-07-17 02:22:58 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489592133582467072",
  "text" : "Cavern &gt; Piper. LOVING IT.",
  "id" : 489592133582467072,
  "created_at" : "2014-07-17 02:07:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 0, 13 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489572535915122688",
  "geo" : { },
  "id_str" : "489587370484711424",
  "in_reply_to_user_id" : 2469964320,
  "text" : "@LadyIvanGrey thanks!!",
  "id" : 489587370484711424,
  "in_reply_to_status_id" : 489572535915122688,
  "created_at" : "2014-07-17 01:48:19 +0000",
  "in_reply_to_screen_name" : "LadyIvanGrey",
  "in_reply_to_user_id_str" : "2469964320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "indices" : [ 0, 6 ],
      "id_str" : "21937199",
      "id" : 21937199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489577520711233536",
  "geo" : { },
  "id_str" : "489578361010663424",
  "in_reply_to_user_id" : 21937199,
  "text" : "@haley not worth it. I couldn't stomach past a few chapters in the sequel. it's just awful. Just wikipedia it if you're curious.",
  "id" : 489578361010663424,
  "in_reply_to_status_id" : 489577520711233536,
  "created_at" : "2014-07-17 01:12:31 +0000",
  "in_reply_to_screen_name" : "haley",
  "in_reply_to_user_id_str" : "21937199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annalee",
      "screen_name" : "leeflower",
      "indices" : [ 0, 10 ],
      "id_str" : "30861631",
      "id" : 30861631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Dn8c0vinDm",
      "expanded_url" : "https:\/\/www.destroyallsoftware.com\/talks\/wat",
      "display_url" : "destroyallsoftware.com\/talks\/wat"
    } ]
  },
  "in_reply_to_status_id_str" : "489570819769925633",
  "geo" : { },
  "id_str" : "489571612279066624",
  "in_reply_to_user_id" : 30861631,
  "text" : "@leeflower I had a front row seat for this: https:\/\/t.co\/Dn8c0vinDm",
  "id" : 489571612279066624,
  "in_reply_to_status_id" : 489570819769925633,
  "created_at" : "2014-07-17 00:45:42 +0000",
  "in_reply_to_screen_name" : "leeflower",
  "in_reply_to_user_id_str" : "30861631",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 0, 13 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/28v1EskJKe",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/9632833726\/",
      "display_url" : "flickr.com\/photos\/qrush\/9\u2026"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/jTD3Lxi9Au",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/qrush\/11541970804\/",
      "display_url" : "flickr.com\/photos\/qrush\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "489570439031554048",
  "geo" : { },
  "id_str" : "489570752555786240",
  "in_reply_to_user_id" : 2469964320,
  "text" : "@LadyIvanGrey Husky! https:\/\/t.co\/28v1EskJKe https:\/\/t.co\/jTD3Lxi9Au",
  "id" : 489570752555786240,
  "in_reply_to_status_id" : 489570439031554048,
  "created_at" : "2014-07-17 00:42:17 +0000",
  "in_reply_to_screen_name" : "LadyIvanGrey",
  "in_reply_to_user_id_str" : "2469964320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 0, 13 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489569455467274242",
  "geo" : { },
  "id_str" : "489569952815259648",
  "in_reply_to_user_id" : 2469964320,
  "text" : "@LadyIvanGrey first one looks like my dog.",
  "id" : 489569952815259648,
  "in_reply_to_status_id" : 489569455467274242,
  "created_at" : "2014-07-17 00:39:07 +0000",
  "in_reply_to_screen_name" : "LadyIvanGrey",
  "in_reply_to_user_id_str" : "2469964320",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/E4ptuMPDMy",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/niS5ZO9DNgk\/SHUzS-8Qx68J",
      "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "489567305651986434",
  "geo" : { },
  "id_str" : "489567968028659712",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy http:\/\/t.co\/EmUiG90kOd needs an adoption center: https:\/\/t.co\/E4ptuMPDMy",
  "id" : 489567968028659712,
  "in_reply_to_status_id" : 489567305651986434,
  "created_at" : "2014-07-17 00:31:13 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bundler Team",
      "screen_name" : "bundlerio",
      "indices" : [ 3, 13 ],
      "id_str" : "221951588",
      "id" : 221951588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/8wXoqxdqvE",
      "expanded_url" : "http:\/\/bundler.io\/blog\/2014\/07\/16\/bundler-api-outages.html",
      "display_url" : "bundler.io\/blog\/2014\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489563576529481729",
  "text" : "RT @bundlerio: The API had some issues yesterday and today, here\u2019s what happened: http:\/\/t.co\/8wXoqxdqvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/8wXoqxdqvE",
        "expanded_url" : "http:\/\/bundler.io\/blog\/2014\/07\/16\/bundler-api-outages.html",
        "display_url" : "bundler.io\/blog\/2014\/07\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489560668278767617",
    "text" : "The API had some issues yesterday and today, here\u2019s what happened: http:\/\/t.co\/8wXoqxdqvE",
    "id" : 489560668278767617,
    "created_at" : "2014-07-17 00:02:13 +0000",
    "user" : {
      "name" : "The Bundler Team",
      "screen_name" : "bundlerio",
      "protected" : false,
      "id_str" : "221951588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570427812549390336\/4e77LXIo_normal.png",
      "id" : 221951588,
      "verified" : false
    }
  },
  "id" : 489563576529481729,
  "created_at" : "2014-07-17 00:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julz",
      "screen_name" : "lvnphish",
      "indices" : [ 3, 12 ],
      "id_str" : "15944661",
      "id" : 15944661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couchtour",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "letsdothis",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/KMbd2gAUPu",
      "expanded_url" : "http:\/\/www.mixlr.com\/lvnphish",
      "display_url" : "mixlr.com\/lvnphish"
    } ]
  },
  "geo" : { },
  "id_str" : "489563433465937921",
  "text" : "RT @lvnphish: Ready to get back on the train!!! Streaming at DTE tonight - http:\/\/t.co\/KMbd2gAUPu #couchtour #letsdothis \u2764\uFE0F\uD83C\uDFB9\uD83C\uDFB8\u2B55\uFE0F\uD83C\uDF35",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "couchtour",
        "indices" : [ 84, 94 ]
      }, {
        "text" : "letsdothis",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/KMbd2gAUPu",
        "expanded_url" : "http:\/\/www.mixlr.com\/lvnphish",
        "display_url" : "mixlr.com\/lvnphish"
      } ]
    },
    "geo" : { },
    "id_str" : "489449507063476224",
    "text" : "Ready to get back on the train!!! Streaming at DTE tonight - http:\/\/t.co\/KMbd2gAUPu #couchtour #letsdothis \u2764\uFE0F\uD83C\uDFB9\uD83C\uDFB8\u2B55\uFE0F\uD83C\uDF35",
    "id" : 489449507063476224,
    "created_at" : "2014-07-16 16:40:30 +0000",
    "user" : {
      "name" : "Julz",
      "screen_name" : "lvnphish",
      "protected" : false,
      "id_str" : "15944661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546114599968579584\/POJB0eBS_normal.jpeg",
      "id" : 15944661,
      "verified" : false
    }
  },
  "id" : 489563433465937921,
  "created_at" : "2014-07-17 00:13:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    }, {
      "name" : "Julz",
      "screen_name" : "lvnphish",
      "indices" : [ 13, 22 ],
      "id_str" : "15944661",
      "id" : 15944661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489554493961691136",
  "geo" : { },
  "id_str" : "489563332546793472",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 @lvnphish thanks!!!",
  "id" : 489563332546793472,
  "in_reply_to_status_id" : 489554493961691136,
  "created_at" : "2014-07-17 00:12:48 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/njKzg0mFpK",
      "expanded_url" : "http:\/\/logos.ryandoeng.es\/2014\/07\/16\/pining-for-the-fjords\/",
      "display_url" : "logos.ryandoeng.es\/2014\/07\/16\/pin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9228026727, -78.8772931765 ]
  },
  "id_str" : "489540714267570176",
  "text" : "\u201CTwitter needs its own judgemental murder of crows\u201D http:\/\/t.co\/njKzg0mFpK",
  "id" : 489540714267570176,
  "created_at" : "2014-07-16 22:42:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 46, 60 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/WQXumpOtcA",
      "expanded_url" : "http:\/\/buffalorising.com\/2014\/07\/niagara-distilling-company-to-open-on-ellicott-street\/",
      "display_url" : "buffalorising.com\/2014\/07\/niagar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489510853582921728",
  "text" : "There's a distillery moving a block away from @coworkbuffalo. DANGER DANGER http:\/\/t.co\/WQXumpOtcA",
  "id" : 489510853582921728,
  "created_at" : "2014-07-16 20:44:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489504453548978176",
  "text" : "Diomede, AK is literally a glacier Dwarf Fortress. Water \"drawn from a mountain spring\", \"permafrost does not allow pipelines [underground]\"",
  "id" : 489504453548978176,
  "created_at" : "2014-07-16 20:18:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Templier",
      "screen_name" : "jayztemplier",
      "indices" : [ 0, 13 ],
      "id_str" : "34562994",
      "id" : 34562994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489501991748775936",
  "geo" : { },
  "id_str" : "489503530663673856",
  "in_reply_to_user_id" : 34562994,
  "text" : "@jayztemplier hoping to add pvp, move effects, non-attack moves. not in that order. who knows what. it's MIT, feel free to do whatever!",
  "id" : 489503530663673856,
  "in_reply_to_status_id" : 489501991748775936,
  "created_at" : "2014-07-16 20:15:10 +0000",
  "in_reply_to_screen_name" : "jayztemplier",
  "in_reply_to_user_id_str" : "34562994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/giLeEwx8Ty",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Diomede,_Alaska",
      "display_url" : "en.wikipedia.org\/wiki\/Diomede,_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489503336903634944",
  "text" : "Real life Dwarf Fortress: \"Frozen ground and lack of soil on the rocky island also prevents digging graves\" http:\/\/t.co\/giLeEwx8Ty",
  "id" : 489503336903634944,
  "created_at" : "2014-07-16 20:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489502646277918720",
  "geo" : { },
  "id_str" : "489502901899763712",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Grabbed 7\/4. Thanks!",
  "id" : 489502901899763712,
  "in_reply_to_status_id" : 489502646277918720,
  "created_at" : "2014-07-16 20:12:40 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 17, 29 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 35, 41 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/6xJcfTPz0s",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=cOsxL9e0L80",
      "display_url" : "youtube.com\/watch?v=cOsxL9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489498550188118016",
  "text" : "Small snippet of @AqueousBand post @phish last night. Can't wait to hear the entire set. https:\/\/t.co\/6xJcfTPz0s",
  "id" : 489498550188118016,
  "created_at" : "2014-07-16 19:55:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Templier",
      "screen_name" : "jayztemplier",
      "indices" : [ 0, 13 ],
      "id_str" : "34562994",
      "id" : 34562994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489496114492899328",
  "geo" : { },
  "id_str" : "489496427769626625",
  "in_reply_to_user_id" : 34562994,
  "text" : "@jayztemplier what are you planning to add?",
  "id" : 489496427769626625,
  "in_reply_to_status_id" : 489496114492899328,
  "created_at" : "2014-07-16 19:46:57 +0000",
  "in_reply_to_screen_name" : "jayztemplier",
  "in_reply_to_user_id_str" : "34562994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489486926379229185",
  "geo" : { },
  "id_str" : "489488100897595395",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit how about a finger with a photo of the 600 block of Main Street that was supposed to be finished months ago?",
  "id" : 489488100897595395,
  "in_reply_to_status_id" : 489486926379229185,
  "created_at" : "2014-07-16 19:13:52 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 81, 87 ]
    }, {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wDolZeOD7N",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-15",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489485310548770818",
  "text" : "RT @UnclePhilsBlog: @AqueousBand played a top notch energy filled set w multiple #phish teases and the first 2001 in 260+ shows. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 61, 67 ]
      }, {
        "text" : "AQband",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/wDolZeOD7N",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-15",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489473272883732481",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand played a top notch energy filled set w multiple #phish teases and the first 2001 in 260+ shows. http:\/\/t.co\/wDolZeOD7N #AQband",
    "id" : 489473272883732481,
    "created_at" : "2014-07-16 18:14:56 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 489485310548770818,
  "created_at" : "2014-07-16 19:02:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Benziger",
      "screen_name" : "tybenz",
      "indices" : [ 0, 7 ],
      "id_str" : "25610580",
      "id" : 25610580
    }, {
      "name" : "J\u00E9r\u00E9my Templier",
      "screen_name" : "jayztemplier",
      "indices" : [ 8, 21 ],
      "id_str" : "34562994",
      "id" : 34562994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/zmIUKb6lh2",
      "expanded_url" : "http:\/\/github.com\/qrush\/mon",
      "display_url" : "github.com\/qrush\/mon"
    } ]
  },
  "in_reply_to_status_id_str" : "489483342812033025",
  "geo" : { },
  "id_str" : "489483639357714432",
  "in_reply_to_user_id" : 25610580,
  "text" : "@tybenz @jayztemplier http:\/\/t.co\/zmIUKb6lh2",
  "id" : 489483639357714432,
  "in_reply_to_status_id" : 489483342812033025,
  "created_at" : "2014-07-16 18:56:08 +0000",
  "in_reply_to_screen_name" : "tybenz",
  "in_reply_to_user_id_str" : "25610580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/489478906815451136\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/r18jrgbSNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsr6eFmCAAAEVkq.png",
      "id_str" : "489478904327831552",
      "id" : 489478904327831552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsr6eFmCAAAEVkq.png",
      "sizes" : [ {
        "h" : 626,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 147,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r18jrgbSNp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489478906815451136",
  "text" : "Pokemon battle bot is currently at a 2 win streak, and then http:\/\/t.co\/r18jrgbSNp",
  "id" : 489478906815451136,
  "created_at" : "2014-07-16 18:37:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Smith",
      "screen_name" : "paytonrules",
      "indices" : [ 0, 12 ],
      "id_str" : "1437841",
      "id" : 1437841
    }, {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 13, 27 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489426642750545920",
  "geo" : { },
  "id_str" : "489465530378485760",
  "in_reply_to_user_id" : 1437841,
  "text" : "@paytonrules @meaganewaller that's not *too* far :)",
  "id" : 489465530378485760,
  "in_reply_to_status_id" : 489426642750545920,
  "created_at" : "2014-07-16 17:44:10 +0000",
  "in_reply_to_screen_name" : "paytonrules",
  "in_reply_to_user_id_str" : "1437841",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489463809929515009",
  "text" : "Have a few speaker invites for @nickelcityruby going out. Waiting on a few still, and haven't sent out any rejects yet. Will do soon!!",
  "id" : 489463809929515009,
  "created_at" : "2014-07-16 17:37:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 3, 17 ],
      "id_str" : "369585978",
      "id" : 369585978
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 88, 103 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489463647194734592",
  "text" : "RT @meaganewaller: Really excited that my \"Learning from Failure\" talk got accepted for @NickelCityRuby (!!!!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 69, 84 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489426324511924224",
    "text" : "Really excited that my \"Learning from Failure\" talk got accepted for @NickelCityRuby (!!!!)",
    "id" : 489426324511924224,
    "created_at" : "2014-07-16 15:08:23 +0000",
    "user" : {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "protected" : false,
      "id_str" : "369585978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559117803043950592\/Dxshutmf_normal.jpeg",
      "id" : 369585978,
      "verified" : false
    }
  },
  "id" : 489463647194734592,
  "created_at" : "2014-07-16 17:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489444193626894336",
  "geo" : { },
  "id_str" : "489446117566734336",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo haters gonna hate. it was fantastic.",
  "id" : 489446117566734336,
  "in_reply_to_status_id" : 489444193626894336,
  "created_at" : "2014-07-16 16:27:02 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 30, 44 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489438433652510721",
  "geo" : { },
  "id_str" : "489444166766571520",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin We had pit tickets. @Carols10cents exhausted her luck for the year. I think the vocals were a little rough given our proximity",
  "id" : 489444166766571520,
  "in_reply_to_status_id" : 489438433652510721,
  "created_at" : "2014-07-16 16:19:17 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Austin",
      "screen_name" : "sjaustin",
      "indices" : [ 0, 9 ],
      "id_str" : "1798581",
      "id" : 1798581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489437940981202944",
  "geo" : { },
  "id_str" : "489438274046263296",
  "in_reply_to_user_id" : 1798581,
  "text" : "@sjaustin where were you sitting?",
  "id" : 489438274046263296,
  "in_reply_to_status_id" : 489437940981202944,
  "created_at" : "2014-07-16 15:55:52 +0000",
  "in_reply_to_screen_name" : "sjaustin",
  "in_reply_to_user_id_str" : "1798581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Schofield",
      "screen_name" : "uberzealot",
      "indices" : [ 0, 11 ],
      "id_str" : "227046773",
      "id" : 227046773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489428643903713280",
  "geo" : { },
  "id_str" : "489430788610355201",
  "in_reply_to_user_id" : 227046773,
  "text" : "@uberzealot well if you can fly me there ;)",
  "id" : 489430788610355201,
  "in_reply_to_status_id" : 489428643903713280,
  "created_at" : "2014-07-16 15:26:07 +0000",
  "in_reply_to_screen_name" : "uberzealot",
  "in_reply_to_user_id_str" : "227046773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Schofield",
      "screen_name" : "uberzealot",
      "indices" : [ 0, 11 ],
      "id_str" : "227046773",
      "id" : 227046773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489428204881731584",
  "geo" : { },
  "id_str" : "489428390403788800",
  "in_reply_to_user_id" : 227046773,
  "text" : "@uberzealot Nah, next and final show of the summer for me is this Saturday. You going?",
  "id" : 489428390403788800,
  "in_reply_to_status_id" : 489428204881731584,
  "created_at" : "2014-07-16 15:16:36 +0000",
  "in_reply_to_screen_name" : "uberzealot",
  "in_reply_to_user_id_str" : "227046773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 3, 9 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/90uu5mOVVF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=65612bXie6E",
      "display_url" : "youtube.com\/watch?v=65612b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489426766654480384",
  "text" : "RT @phish: Watch Now in HD: \"Chalk Dust Torture\" from Phish's 7\/13\/14 show at Randall's Island in New York, NY: https:\/\/t.co\/90uu5mOVVF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/90uu5mOVVF",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=65612bXie6E",
        "display_url" : "youtube.com\/watch?v=65612b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489426429114085376",
    "text" : "Watch Now in HD: \"Chalk Dust Torture\" from Phish's 7\/13\/14 show at Randall's Island in New York, NY: https:\/\/t.co\/90uu5mOVVF",
    "id" : 489426429114085376,
    "created_at" : "2014-07-16 15:08:48 +0000",
    "user" : {
      "name" : "Phish",
      "screen_name" : "phish",
      "protected" : false,
      "id_str" : "14503997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524599876630216704\/KczioeHn_normal.jpeg",
      "id" : 14503997,
      "verified" : true
    }
  },
  "id" : 489426766654480384,
  "created_at" : "2014-07-16 15:10:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 0, 11 ],
      "id_str" : "76750013",
      "id" : 76750013
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 12, 24 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 25, 40 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/UaftWuN0Ts",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-15",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "489278833460137984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243304348, -78.8791694865 ]
  },
  "id_str" : "489280946835714048",
  "in_reply_to_user_id" : 76750013,
  "text" : "@ashstarr88 @AqueousBand @UnclePhilsBlog looks like it\u2019s here http:\/\/t.co\/UaftWuN0Ts",
  "id" : 489280946835714048,
  "in_reply_to_status_id" : 489278833460137984,
  "created_at" : "2014-07-16 05:30:42 +0000",
  "in_reply_to_screen_name" : "ashstarr88",
  "in_reply_to_user_id_str" : "76750013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489232479774343168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8666899856, -77.2436188844 ]
  },
  "id_str" : "489232855323529216",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester I think Trey forgot the dance",
  "id" : 489232855323529216,
  "in_reply_to_status_id" : 489232479774343168,
  "created_at" : "2014-07-16 02:19:36 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 70, 85 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 86, 99 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8666058296, -77.2436154511 ]
  },
  "id_str" : "489232203105054720",
  "text" : "Last 2 Rochester shows: Meatstick. Possibly Nick Tahou\u2019s preshow? \/cc @UnclePhilsBlog @antelopeezer",
  "id" : 489232203105054720,
  "created_at" : "2014-07-16 02:17:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489212342798802944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8666020285, -77.2435710844 ]
  },
  "id_str" : "489213817591570434",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive nice funk jam during it. Best I\u2019ve heard, lyrics were a bit choppy",
  "id" : 489213817591570434,
  "in_reply_to_status_id" : 489212342798802944,
  "created_at" : "2014-07-16 01:03:57 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 16, 25 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 26, 39 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489058219697143808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8666076156, -77.2435608413 ]
  },
  "id_str" : "489199452184264704",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @LawnMemo @antelopeezer DING DING DING",
  "id" : 489199452184264704,
  "in_reply_to_status_id" : 489058219697143808,
  "created_at" : "2014-07-16 00:06:52 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 3, 17 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Carols10cents\/status\/489196304598196225\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/CyJKaCvhN7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsn5cl8CYAAEZO8.jpg",
      "id_str" : "489196304161988608",
      "id" : 489196304161988608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsn5cl8CYAAEZO8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 918,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CyJKaCvhN7"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489196461452574720",
  "text" : "RT @Carols10cents: Page side rage side #phish http:\/\/t.co\/CyJKaCvhN7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetlanes.com\" rel=\"nofollow\"\u003ETweet Lanes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Carols10cents\/status\/489196304598196225\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/CyJKaCvhN7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsn5cl8CYAAEZO8.jpg",
        "id_str" : "489196304161988608",
        "id" : 489196304161988608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsn5cl8CYAAEZO8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 918,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CyJKaCvhN7"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 20, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489196304598196225",
    "text" : "Page side rage side #phish http:\/\/t.co\/CyJKaCvhN7",
    "id" : 489196304598196225,
    "created_at" : "2014-07-15 23:54:22 +0000",
    "user" : {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "protected" : false,
      "id_str" : "194688433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446291681252364288\/_okxMUY1_normal.jpeg",
      "id" : 194688433,
      "verified" : false
    }
  },
  "id" : 489196461452574720,
  "created_at" : "2014-07-15 23:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 4, 10 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/489192164958552064\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/7PnIFUUtaC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsn1rcZCMAEH3qt.jpg",
      "id_str" : "489192161250783233",
      "id" : 489192161250783233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsn1rcZCMAEH3qt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7PnIFUUtaC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8668079898, -77.2437297554 ]
  },
  "id_str" : "489192164958552064",
  "text" : "The @phish from Vermont! http:\/\/t.co\/7PnIFUUtaC",
  "id" : 489192164958552064,
  "created_at" : "2014-07-15 23:37:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 16, 25 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 26, 39 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489058219697143808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924346893, -78.8792415247 ]
  },
  "id_str" : "489114474477928448",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog @LawnMemo @antelopeezer any idea when the lot opens?",
  "id" : 489114474477928448,
  "in_reply_to_status_id" : 489058219697143808,
  "created_at" : "2014-07-15 18:29:12 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 31, 40 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489082009721909248",
  "geo" : { },
  "id_str" : "489083626261209089",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel I have been bugging @borncamp to build one. $1\/month\/site.",
  "id" : 489083626261209089,
  "in_reply_to_status_id" : 489082009721909248,
  "created_at" : "2014-07-15 16:26:37 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "indices" : [ 0, 15 ],
      "id_str" : "415345747",
      "id" : 415345747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489076604002258944",
  "geo" : { },
  "id_str" : "489076966436261888",
  "in_reply_to_user_id" : 415345747,
  "text" : "@parkerwightman yeah, glad I didn't stay up for it.",
  "id" : 489076966436261888,
  "in_reply_to_status_id" : 489076604002258944,
  "created_at" : "2014-07-15 16:00:10 +0000",
  "in_reply_to_screen_name" : "parkerwightman",
  "in_reply_to_user_id_str" : "415345747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489073988325228546",
  "geo" : { },
  "id_str" : "489074259977707520",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik holy shit",
  "id" : 489074259977707520,
  "in_reply_to_status_id" : 489073988325228546,
  "created_at" : "2014-07-15 15:49:24 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489059707684798465",
  "geo" : { },
  "id_str" : "489060298825818112",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam Good. Now going to see Phish tonight. :P",
  "id" : 489060298825818112,
  "in_reply_to_status_id" : 489059707684798465,
  "created_at" : "2014-07-15 14:53:56 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489057104410341376",
  "geo" : { },
  "id_str" : "489059627510665216",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam what kind of question is this? It's The Who. Of course they win.",
  "id" : 489059627510665216,
  "in_reply_to_status_id" : 489057104410341376,
  "created_at" : "2014-07-15 14:51:16 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489056643510845442",
  "geo" : { },
  "id_str" : "489057062786064384",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams unless you start yanking out random cables",
  "id" : 489057062786064384,
  "in_reply_to_status_id" : 489056643510845442,
  "created_at" : "2014-07-15 14:41:04 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 89, 98 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 99, 112 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 113, 128 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489055477511114752",
  "text" : "Hoping for a Piper tonight. Daresay a Rock and Roll, but I could be dreaming. Any picks? @LawnMemo @antelopeezer @UnclePhilsBlog",
  "id" : 489055477511114752,
  "created_at" : "2014-07-15 14:34:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlueStreamProduction",
      "screen_name" : "bluestreamprod",
      "indices" : [ 3, 18 ],
      "id_str" : "459738418",
      "id" : 459738418
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 32, 44 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 57, 63 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "UpstateLIVE",
      "screen_name" : "UpstateLIVE",
      "indices" : [ 86, 98 ],
      "id_str" : "2934894724",
      "id" : 2934894724
    }, {
      "name" : "V-Pub The Villager",
      "screen_name" : "VPubVillager",
      "indices" : [ 99, 112 ],
      "id_str" : "2325855433",
      "id" : 2325855433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CMAC",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "phish",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489054168087154688",
  "text" : "RT @bluestreamprod: It's today! @AqueousBand plays #CMAC @phish after party hosted by @UpstateLIVE @VPubVillager 245 S Main St Canandaigua,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 12, 24 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Phish",
        "screen_name" : "phish",
        "indices" : [ 37, 43 ],
        "id_str" : "14503997",
        "id" : 14503997
      }, {
        "name" : "UpstateLIVE",
        "screen_name" : "UpstateLIVE",
        "indices" : [ 66, 78 ],
        "id_str" : "2934894724",
        "id" : 2934894724
      }, {
        "name" : "V-Pub The Villager",
        "screen_name" : "VPubVillager",
        "indices" : [ 79, 92 ],
        "id_str" : "2325855433",
        "id" : 2325855433
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CMAC",
        "indices" : [ 31, 36 ]
      }, {
        "text" : "phish",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489053250528608257",
    "text" : "It's today! @AqueousBand plays #CMAC @phish after party hosted by @UpstateLIVE @VPubVillager 245 S Main St Canandaigua,NY 11p 18+ $8 #phish",
    "id" : 489053250528608257,
    "created_at" : "2014-07-15 14:25:55 +0000",
    "user" : {
      "name" : "BlueStreamProduction",
      "screen_name" : "bluestreamprod",
      "protected" : false,
      "id_str" : "459738418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531537843609276417\/Jq4rOuSu_normal.jpeg",
      "id" : 459738418,
      "verified" : false
    }
  },
  "id" : 489054168087154688,
  "created_at" : "2014-07-15 14:29:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 34, 43 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488892493799649280",
  "geo" : { },
  "id_str" : "488895651028013056",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark the computer did beat @shildner on his first match today\u2026so this is a keeper",
  "id" : 488895651028013056,
  "in_reply_to_status_id" : 488892493799649280,
  "created_at" : "2014-07-15 03:59:41 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rubiety\/status\/488892172167426050\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/hHeTTyDuTA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsjk1prCUAEy0JW.jpg",
      "id_str" : "488892169940258817",
      "id" : 488892169940258817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsjk1prCUAEy0JW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/hHeTTyDuTA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488892349221576704",
  "text" : "RT @rubiety: \u201CPlease call me,\u201D says the chicken wing. http:\/\/t.co\/hHeTTyDuTA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rubiety\/status\/488892172167426050\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/hHeTTyDuTA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsjk1prCUAEy0JW.jpg",
        "id_str" : "488892169940258817",
        "id" : 488892169940258817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsjk1prCUAEy0JW.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/hHeTTyDuTA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488892172167426050",
    "text" : "\u201CPlease call me,\u201D says the chicken wing. http:\/\/t.co\/hHeTTyDuTA",
    "id" : 488892172167426050,
    "created_at" : "2014-07-15 03:45:51 +0000",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 488892349221576704,
  "created_at" : "2014-07-15 03:46:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H\u00E9ctor Cer\u00F3n",
      "screen_name" : "Telematica",
      "indices" : [ 0, 11 ],
      "id_str" : "20288163",
      "id" : 20288163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/KVV071nBr5",
      "expanded_url" : "http:\/\/sportsnaut.com\/wp-content\/uploads\/2014\/02\/OJKyt.gif",
      "display_url" : "sportsnaut.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "488890693000388608",
  "geo" : { },
  "id_str" : "488890911015702529",
  "in_reply_to_user_id" : 20288163,
  "text" : "@Telematica http:\/\/t.co\/KVV071nBr5",
  "id" : 488890911015702529,
  "in_reply_to_status_id" : 488890693000388608,
  "created_at" : "2014-07-15 03:40:51 +0000",
  "in_reply_to_screen_name" : "Telematica",
  "in_reply_to_user_id_str" : "20288163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488890475084914688",
  "text" : "Fallon's monologue tonight is aaaaawful.",
  "id" : 488890475084914688,
  "created_at" : "2014-07-15 03:39:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hot mic",
      "screen_name" : "fivetanley",
      "indices" : [ 0, 11 ],
      "id_str" : "306497372",
      "id" : 306497372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/OsZpS1GP0B",
      "expanded_url" : "https:\/\/github.com\/qrush\/mon",
      "display_url" : "github.com\/qrush\/mon"
    } ]
  },
  "in_reply_to_status_id_str" : "488889922107895808",
  "geo" : { },
  "id_str" : "488890258499461120",
  "in_reply_to_user_id" : 306497372,
  "text" : "@fivetanley it's a Scamp bot. if you want it: https:\/\/t.co\/OsZpS1GP0B (Rakefile has a small example)",
  "id" : 488890258499461120,
  "in_reply_to_status_id" : 488889922107895808,
  "created_at" : "2014-07-15 03:38:15 +0000",
  "in_reply_to_screen_name" : "fivetanley",
  "in_reply_to_user_id_str" : "306497372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/488889081678405633\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Dy78mfRLga",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsjiB1cCIAEVnfI.png",
      "id_str" : "488889080722104321",
      "id" : 488889080722104321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsjiB1cCIAEVnfI.png",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1182,
        "resize" : "fit",
        "w" : 1584
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Dy78mfRLga"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488889081678405633",
  "text" : "And types are in. Causing some ridiculous moves to happen. http:\/\/t.co\/Dy78mfRLga",
  "id" : 488889081678405633,
  "created_at" : "2014-07-15 03:33:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488755424364359681",
  "geo" : { },
  "id_str" : "488757605016166401",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark Local Man Loses 3025 Pounds, Exists Only In Two Dimensions",
  "id" : 488757605016166401,
  "in_reply_to_status_id" : 488755424364359681,
  "created_at" : "2014-07-14 18:51:08 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/VmJ23qdIjD",
      "expanded_url" : "http:\/\/bulbapedia.bulbagarden.net\/wiki\/Damage",
      "display_url" : "bulbapedia.bulbagarden.net\/wiki\/Damage"
    } ]
  },
  "geo" : { },
  "id_str" : "488700770481471488",
  "text" : "The battles so far are missing the \"STAB * TYPE * CRITICAL\" part of the Damage formula here: http:\/\/t.co\/VmJ23qdIjD",
  "id" : 488700770481471488,
  "created_at" : "2014-07-14 15:05:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/488700368914616322\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/3Qbq0DLRJe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsg2ZTdCYAAz7oa.png",
      "id_str" : "488700367916392448",
      "id" : 488700367916392448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsg2ZTdCYAAz7oa.png",
      "sizes" : [ {
        "h" : 1168,
        "resize" : "fit",
        "w" : 1612
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3Qbq0DLRJe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488700368914616322",
  "text" : "Pokemon battles are coming to our Campfire All Nerds channel soon, once I get types\/critical hits in. Next up: PVP. http:\/\/t.co\/3Qbq0DLRJe",
  "id" : 488700368914616322,
  "created_at" : "2014-07-14 15:03:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/p53W1CEecO",
      "expanded_url" : "http:\/\/kottke.org\/14\/07\/mobility-on-demand",
      "display_url" : "kottke.org\/14\/07\/mobility\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488697242195202049",
  "text" : "Imagine this kind of system in the US: I'd buy in within a heartbeat. http:\/\/t.co\/p53W1CEecO",
  "id" : 488697242195202049,
  "created_at" : "2014-07-14 14:51:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488525616497438720",
  "text" : "RT @rubygems_status: We'll be back in a flash!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488524677996744704",
    "text" : "We'll be back in a flash!",
    "id" : 488524677996744704,
    "created_at" : "2014-07-14 03:25:34 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 488525616497438720,
  "created_at" : "2014-07-14 03:29:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Souperman",
      "screen_name" : "Buffalucci",
      "indices" : [ 0, 11 ],
      "id_str" : "16256129",
      "id" : 16256129
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 12, 24 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488418595202813952",
  "geo" : { },
  "id_str" : "488420475031138304",
  "in_reply_to_user_id" : 16256129,
  "text" : "@Buffalucci @BuffaloEats wrong schumer",
  "id" : 488420475031138304,
  "in_reply_to_status_id" : 488418595202813952,
  "created_at" : "2014-07-13 20:31:30 +0000",
  "in_reply_to_screen_name" : "Buffalucci",
  "in_reply_to_user_id_str" : "16256129",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/C5tD1uQyxu",
      "expanded_url" : "http:\/\/www.meetup.com\/ChicagoRuby\/events\/188465462\/",
      "display_url" : "meetup.com\/ChicagoRuby\/ev\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "488190616522604545",
  "geo" : { },
  "id_str" : "488390552031748096",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines next! going to do an openhack as well - http:\/\/t.co\/C5tD1uQyxu",
  "id" : 488390552031748096,
  "in_reply_to_status_id" : 488190616522604545,
  "created_at" : "2014-07-13 18:32:36 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487954106149896193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241969719, -78.8801691091 ]
  },
  "id_str" : "487954988316893186",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer convinced the \u201Ctypes\u201D don\u2019t matter or are noticed to most fans. Useful for categorizing though.",
  "id" : 487954988316893186,
  "in_reply_to_status_id" : 487954106149896193,
  "created_at" : "2014-07-12 13:41:49 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487812648780570624",
  "text" : "LMAO if you didn't spend your night listening to phish and implementing pokemon battle statistics",
  "id" : 487812648780570624,
  "created_at" : "2014-07-12 04:16:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u0431\u0440\u043E\u0441\u044C\u043A\u0438\u043Da \u041A\u0441\u0435\u043D\u0438\u044F",
      "screen_name" : "dogglesfan",
      "indices" : [ 0, 11 ],
      "id_str" : "2858414563",
      "id" : 2858414563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487811549403160577",
  "geo" : { },
  "id_str" : "487812371067305984",
  "in_reply_to_user_id" : 15925574,
  "text" : "@dogglesfan &gt; Ecch - that must have been poisonous!\n&gt; You feel deathly sick.\n&gt; You die.",
  "id" : 487812371067305984,
  "in_reply_to_status_id" : 487811549403160577,
  "created_at" : "2014-07-12 04:15:07 +0000",
  "in_reply_to_screen_name" : "dexterhaslem",
  "in_reply_to_user_id_str" : "15925574",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487792759718559745",
  "geo" : { },
  "id_str" : "487792895886258176",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby Full Stack Baby",
  "id" : 487792895886258176,
  "in_reply_to_status_id" : 487792759718559745,
  "created_at" : "2014-07-12 02:57:43 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/PdnSzloQPH",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/phish\/comments\/2agrur\/71114_randalls_island_n1_unofficial_setlist_thread\/",
      "display_url" : "reddit.com\/r\/phish\/commen\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487763873433653248",
  "geo" : { },
  "id_str" : "487764691213504513",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer 2 on http:\/\/t.co\/PdnSzloQPH",
  "id" : 487764691213504513,
  "in_reply_to_status_id" : 487763873433653248,
  "created_at" : "2014-07-12 01:05:39 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coldbrew",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "coffee",
      "indices" : [ 62, 69 ]
    }, {
      "text" : "roaster",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "smallbatch",
      "indices" : [ 79, 90 ]
    }, {
      "text" : "icedcoffee",
      "indices" : [ 91, 102 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "trap",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/wTdXUGCV3M",
      "expanded_url" : "http:\/\/instagram.com\/p\/qU5JUIMOS-\/",
      "display_url" : "instagram.com\/p\/qU5JUIMOS-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "487751991385288704",
  "text" : "RT @PublicEspresso: HIPSTER TRAP...and now we wait. #coldbrew #coffee #roaster #smallbatch #icedcoffee #buffalo #trap\u2026 http:\/\/t.co\/wTdXUGCV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coldbrew",
        "indices" : [ 32, 41 ]
      }, {
        "text" : "coffee",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "roaster",
        "indices" : [ 50, 58 ]
      }, {
        "text" : "smallbatch",
        "indices" : [ 59, 70 ]
      }, {
        "text" : "icedcoffee",
        "indices" : [ 71, 82 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 83, 91 ]
      }, {
        "text" : "trap",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/wTdXUGCV3M",
        "expanded_url" : "http:\/\/instagram.com\/p\/qU5JUIMOS-\/",
        "display_url" : "instagram.com\/p\/qU5JUIMOS-\/"
      } ]
    },
    "geo" : { },
    "id_str" : "487715388567072769",
    "text" : "HIPSTER TRAP...and now we wait. #coldbrew #coffee #roaster #smallbatch #icedcoffee #buffalo #trap\u2026 http:\/\/t.co\/wTdXUGCV3M",
    "id" : 487715388567072769,
    "created_at" : "2014-07-11 21:49:44 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 487751991385288704,
  "created_at" : "2014-07-12 00:15:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487686159926321153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8922110813, -78.8713218237 ]
  },
  "id_str" : "487699973140516865",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos did you see the csvs?",
  "id" : 487699973140516865,
  "in_reply_to_status_id" : 487686159926321153,
  "created_at" : "2014-07-11 20:48:29 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/1lbUJ6eJep",
      "expanded_url" : "http:\/\/pokeapi.co",
      "display_url" : "pokeapi.co"
    }, {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/V2bqULHNnC",
      "expanded_url" : "https:\/\/github.com\/veekun\/pokedex\/tree\/master\/pokedex\/data\/csv",
      "display_url" : "github.com\/veekun\/pokedex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487685203192590336",
  "text" : "I thought http:\/\/t.co\/1lbUJ6eJep was pretty ridiculous, and then I found https:\/\/t.co\/V2bqULHNnC",
  "id" : 487685203192590336,
  "created_at" : "2014-07-11 19:49:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "indices" : [ 11, 19 ],
      "id_str" : "6440892",
      "id" : 6440892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487655132419457024",
  "geo" : { },
  "id_str" : "487655756531908608",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @mjeaton yeah the metaphor stretches a bit. but still, ridiculous",
  "id" : 487655756531908608,
  "in_reply_to_status_id" : 487655132419457024,
  "created_at" : "2014-07-11 17:52:47 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "indices" : [ 3, 11 ],
      "id_str" : "6440892",
      "id" : 6440892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487654582860791808",
  "text" : "RT @mjeaton: Best comment I've read in a long time 'You don't see musicians who have just learned to play the guitar writing \"why I'm leavi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483620293567848449",
    "text" : "Best comment I've read in a long time 'You don't see musicians who have just learned to play the guitar writing \"why I'm leaving the piano\"'",
    "id" : 483620293567848449,
    "created_at" : "2014-06-30 14:37:17 +0000",
    "user" : {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "protected" : false,
      "id_str" : "6440892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461484716902731776\/cDTO0m3A_normal.jpeg",
      "id" : 6440892,
      "verified" : false
    }
  },
  "id" : 487654582860791808,
  "created_at" : "2014-07-11 17:48:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Christopher Saunders",
      "screen_name" : "chris_saunders",
      "indices" : [ 11, 26 ],
      "id_str" : "19147270",
      "id" : 19147270
    }, {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 27, 32 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487653681492676608",
  "geo" : { },
  "id_str" : "487653809225596928",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier @chris_saunders @inky I still need to try the new Dwarf Fortress.",
  "id" : 487653809225596928,
  "in_reply_to_status_id" : 487653681492676608,
  "created_at" : "2014-07-11 17:45:02 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 0, 5 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487650483109371904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916361942, -78.8719816151 ]
  },
  "id_str" : "487650996756033536",
  "in_reply_to_user_id" : 13148,
  "text" : "@inky that last one is for Excalibur. Is it sad I recognize this?",
  "id" : 487650996756033536,
  "in_reply_to_status_id" : 487650483109371904,
  "created_at" : "2014-07-11 17:33:52 +0000",
  "in_reply_to_screen_name" : "inky",
  "in_reply_to_user_id_str" : "13148",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "indices" : [ 3, 8 ],
      "id_str" : "13148",
      "id" : 13148
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/inky\/status\/487650483109371904\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/IwBrddq7Zb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsR7hy7IcAIy0Bf.png",
      "id_str" : "487650480198545410",
      "id" : 487650480198545410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsR7hy7IcAIy0Bf.png",
      "sizes" : [ {
        "h" : 104,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 144,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com\/IwBrddq7Zb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487650868670390272",
  "text" : "RT @inky: Nethack source code is intriguing http:\/\/t.co\/IwBrddq7Zb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/inky\/status\/487650483109371904\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/IwBrddq7Zb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsR7hy7IcAIy0Bf.png",
        "id_str" : "487650480198545410",
        "id" : 487650480198545410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsR7hy7IcAIy0Bf.png",
        "sizes" : [ {
          "h" : 104,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 144,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 467
        } ],
        "display_url" : "pic.twitter.com\/IwBrddq7Zb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487650483109371904",
    "text" : "Nethack source code is intriguing http:\/\/t.co\/IwBrddq7Zb",
    "id" : 487650483109371904,
    "created_at" : "2014-07-11 17:31:49 +0000",
    "user" : {
      "name" : "HI\u039BTVS",
      "screen_name" : "inky",
      "protected" : false,
      "id_str" : "13148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572039184349532160\/Erg45AVZ_normal.png",
      "id" : 13148,
      "verified" : false
    }
  },
  "id" : 487650868670390272,
  "created_at" : "2014-07-11 17:33:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/qLP8YmMbHq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XRCu8v9V8EY&list=UU2bkHVIDjXS7sgrgjFtzOXQ",
      "display_url" : "youtube.com\/watch?v=XRCu8v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487643475324592129",
  "text" : "Home-brewed coffee owes part of its popularity to baseball (and the Yankees): https:\/\/t.co\/qLP8YmMbHq",
  "id" : 487643475324592129,
  "created_at" : "2014-07-11 17:03:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Worth",
      "screen_name" : "jwworth",
      "indices" : [ 3, 11 ],
      "id_str" : "184604362",
      "id" : 184604362
    }, {
      "name" : "ChicagoRuby",
      "screen_name" : "ChicagoRuby",
      "indices" : [ 25, 37 ],
      "id_str" : "14050855",
      "id" : 14050855
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 42, 48 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Vets Prevail",
      "screen_name" : "VetsPrevail",
      "indices" : [ 63, 75 ],
      "id_str" : "47752415",
      "id" : 47752415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyonrails",
      "indices" : [ 128, 140 ]
    }, {
      "text" : "chicago",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ql6COxkgda",
      "expanded_url" : "http:\/\/meetu.ps\/2p8Rkl",
      "display_url" : "meetu.ps\/2p8Rkl"
    } ]
  },
  "geo" : { },
  "id_str" : "487626645281316864",
  "text" : "RT @jwworth: Next Friday @ChicagoRuby and @qrush are coming to @vetsprevail !  Come hack and socialize:  http:\/\/t.co\/ql6COxkgda #rubyonrail\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ChicagoRuby",
        "screen_name" : "ChicagoRuby",
        "indices" : [ 12, 24 ],
        "id_str" : "14050855",
        "id" : 14050855
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 29, 35 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Vets Prevail",
        "screen_name" : "VetsPrevail",
        "indices" : [ 50, 62 ],
        "id_str" : "47752415",
        "id" : 47752415
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyonrails",
        "indices" : [ 115, 127 ]
      }, {
        "text" : "chicago",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/ql6COxkgda",
        "expanded_url" : "http:\/\/meetu.ps\/2p8Rkl",
        "display_url" : "meetu.ps\/2p8Rkl"
      } ]
    },
    "geo" : { },
    "id_str" : "487623983139786752",
    "text" : "Next Friday @ChicagoRuby and @qrush are coming to @vetsprevail !  Come hack and socialize:  http:\/\/t.co\/ql6COxkgda #rubyonrails #chicago",
    "id" : 487623983139786752,
    "created_at" : "2014-07-11 15:46:31 +0000",
    "user" : {
      "name" : "Jake Worth",
      "screen_name" : "jwworth",
      "protected" : false,
      "id_str" : "184604362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567028763003613184\/j7dWD1Ah_normal.jpeg",
      "id" : 184604362,
      "verified" : false
    }
  },
  "id" : 487626645281316864,
  "created_at" : "2014-07-11 15:57:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "setlists",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "Virginiabeach",
      "indices" : [ 54, 68 ]
    }, {
      "text" : "virginia",
      "indices" : [ 69, 78 ]
    }, {
      "text" : "AQband",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "AQnet",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/U3ySgMajAk",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-10",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487621849212137472",
  "text" : "RT @UnclePhilsBlog: @AqueousBand #setlists 2014-07-10 #Virginiabeach #virginia http:\/\/t.co\/U3ySgMajAk Extended one set show. #AQband #AQnet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "setlists",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "Virginiabeach",
        "indices" : [ 34, 48 ]
      }, {
        "text" : "virginia",
        "indices" : [ 49, 58 ]
      }, {
        "text" : "AQband",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "AQnet",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/U3ySgMajAk",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-10",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487618548425322496",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand #setlists 2014-07-10 #Virginiabeach #virginia http:\/\/t.co\/U3ySgMajAk Extended one set show. #AQband #AQnet",
    "id" : 487618548425322496,
    "created_at" : "2014-07-11 15:24:56 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 487621849212137472,
  "created_at" : "2014-07-11 15:38:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ Maurer",
      "screen_name" : "cjmaurer",
      "indices" : [ 3, 12 ],
      "id_str" : "27631137",
      "id" : 27631137
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cjmaurer\/status\/487603618229407744\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/iCmhK9QIrZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsRQ6DdCUAEuiS_.jpg",
      "id_str" : "487603617952583681",
      "id" : 487603617952583681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsRQ6DdCUAEuiS_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iCmhK9QIrZ"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/go3Td8pyKG",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/07\/10\/silicon-valleys-real-estate-crunch-is-a-golden-opportunity-for-other-american-cities\/?ncid=twittersocialshare",
      "display_url" : "techcrunch.com\/2014\/07\/10\/sil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487605120754921472",
  "text" : "RT @cjmaurer: A map showing population GROWTH in #Buffalo?\n http:\/\/t.co\/go3Td8pyKG http:\/\/t.co\/iCmhK9QIrZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cjmaurer\/status\/487603618229407744\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/iCmhK9QIrZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsRQ6DdCUAEuiS_.jpg",
        "id_str" : "487603617952583681",
        "id" : 487603617952583681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsRQ6DdCUAEuiS_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iCmhK9QIrZ"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/go3Td8pyKG",
        "expanded_url" : "http:\/\/techcrunch.com\/2014\/07\/10\/silicon-valleys-real-estate-crunch-is-a-golden-opportunity-for-other-american-cities\/?ncid=twittersocialshare",
        "display_url" : "techcrunch.com\/2014\/07\/10\/sil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487603618229407744",
    "text" : "A map showing population GROWTH in #Buffalo?\n http:\/\/t.co\/go3Td8pyKG http:\/\/t.co\/iCmhK9QIrZ",
    "id" : 487603618229407744,
    "created_at" : "2014-07-11 14:25:36 +0000",
    "user" : {
      "name" : "CJ Maurer",
      "screen_name" : "cjmaurer",
      "protected" : false,
      "id_str" : "27631137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000859769132\/gzxMkSg6_normal.png",
      "id" : 27631137,
      "verified" : false
    }
  },
  "id" : 487605120754921472,
  "created_at" : "2014-07-11 14:31:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/487604966127697920\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/yHhv7tqC0p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsRSIYdCQAABBNu.jpg",
      "id_str" : "487604963619520512",
      "id" : 487604963619520512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsRSIYdCQAABBNu.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/yHhv7tqC0p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916339297, -78.8720333018 ]
  },
  "id_str" : "487604966127697920",
  "text" : "How is coffee grind formed? http:\/\/t.co\/yHhv7tqC0p",
  "id" : 487604966127697920,
  "created_at" : "2014-07-11 14:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea P. Foertsch",
      "screen_name" : "DisruptiveSpace",
      "indices" : [ 0, 16 ],
      "id_str" : "1527970406",
      "id" : 1527970406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487590946893475840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916339297, -78.8720333018 ]
  },
  "id_str" : "487604792793890816",
  "in_reply_to_user_id" : 1527970406,
  "text" : "@DisruptiveSpace thanks for stopping by!",
  "id" : 487604792793890816,
  "in_reply_to_status_id" : 487590946893475840,
  "created_at" : "2014-07-11 14:30:16 +0000",
  "in_reply_to_screen_name" : "DisruptiveSpace",
  "in_reply_to_user_id_str" : "1527970406",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 3, 8 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487393310906937345",
  "text" : "RT @popo: Dear techies: I'm learning Ruby On Rails, but need help when I hit walls. StackOverflow yes, but is there any live help\/screencas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487390394540646400",
    "text" : "Dear techies: I'm learning Ruby On Rails, but need help when I hit walls. StackOverflow yes, but is there any live help\/screencast avail?",
    "id" : 487390394540646400,
    "created_at" : "2014-07-11 00:18:19 +0000",
    "user" : {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "protected" : false,
      "id_str" : "2247381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000130437906\/b3f515a0057bb42812f2f71048b49d26_normal.jpeg",
      "id" : 2247381,
      "verified" : false
    }
  },
  "id" : 487393310906937345,
  "created_at" : "2014-07-11 00:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 0, 12 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487372113972432897",
  "geo" : { },
  "id_str" : "487373118000754689",
  "in_reply_to_user_id" : 21758029,
  "text" : "@BuffaloEats TAMALES!!!! Where is this? Always at Larkin?",
  "id" : 487373118000754689,
  "in_reply_to_status_id" : 487372113972432897,
  "created_at" : "2014-07-10 23:09:40 +0000",
  "in_reply_to_screen_name" : "BuffaloEats",
  "in_reply_to_user_id_str" : "21758029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 0, 15 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 16, 24 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 79, 90 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487310347674460160",
  "geo" : { },
  "id_str" : "487316778817556481",
  "in_reply_to_user_id" : 290866979,
  "text" : "@thompson_caleb @sikachu pretty sure we've said no to extortionists before \/cc @thoughtbot",
  "id" : 487316778817556481,
  "in_reply_to_status_id" : 487310347674460160,
  "created_at" : "2014-07-10 19:25:48 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "peckedbythedove",
      "indices" : [ 3, 19 ],
      "id_str" : "180810102",
      "id" : 180810102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/peckedbythedove\/status\/487306899591675904\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/HcHBohIIiK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsNDCczCIAAog3m.jpg",
      "id_str" : "487306894055186432",
      "id" : 487306894055186432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsNDCczCIAAog3m.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 628
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 628
      } ],
      "display_url" : "pic.twitter.com\/HcHBohIIiK"
    } ],
    "hashtags" : [ {
      "text" : "brilliance",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "phish",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487308379052711936",
  "text" : "RT @peckedbythedove: my coworker Blake created this masterpiece. #brilliance #phish http:\/\/t.co\/HcHBohIIiK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/peckedbythedove\/status\/487306899591675904\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/HcHBohIIiK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsNDCczCIAAog3m.jpg",
        "id_str" : "487306894055186432",
        "id" : 487306894055186432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsNDCczCIAAog3m.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/HcHBohIIiK"
      } ],
      "hashtags" : [ {
        "text" : "brilliance",
        "indices" : [ 44, 55 ]
      }, {
        "text" : "phish",
        "indices" : [ 56, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487306899591675904",
    "text" : "my coworker Blake created this masterpiece. #brilliance #phish http:\/\/t.co\/HcHBohIIiK",
    "id" : 487306899591675904,
    "created_at" : "2014-07-10 18:46:33 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "peckedbythedove",
      "protected" : false,
      "id_str" : "180810102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568615493901484032\/SFtPMXaj_normal.jpeg",
      "id" : 180810102,
      "verified" : false
    }
  },
  "id" : 487308379052711936,
  "created_at" : "2014-07-10 18:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 20, 35 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/pB5FvPVA3a",
      "expanded_url" : "http:\/\/huffingtonpost.com\/malerie-yolencohen\/buffalo-ny-20-surprising-reasons-travel_b_5567822.html",
      "display_url" : "huffingtonpost.com\/malerie-yolenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487301702521851904",
  "text" : "RT @zobar2: Come to @nickelcityruby! It smells like Cheerios around here. http:\/\/t.co\/pB5FvPVA3a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 8, 23 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/pB5FvPVA3a",
        "expanded_url" : "http:\/\/huffingtonpost.com\/malerie-yolencohen\/buffalo-ny-20-surprising-reasons-travel_b_5567822.html",
        "display_url" : "huffingtonpost.com\/malerie-yolenc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487301518904004608",
    "text" : "Come to @nickelcityruby! It smells like Cheerios around here. http:\/\/t.co\/pB5FvPVA3a",
    "id" : 487301518904004608,
    "created_at" : "2014-07-10 18:25:10 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 487301702521851904,
  "created_at" : "2014-07-10 18:25:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 75, 90 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/41SOg8PYoO",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/malerie-yolencohen\/buffalo-ny-20-surprising-reasons-travel_b_5567822.html?utm_hp_ref=tw",
      "display_url" : "huffingtonpost.com\/malerie-yolenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487296854388785152",
  "text" : "Apparently the manuscript to Huckleberry Finn is in the same library where @nickelcityruby is held. Awesome! http:\/\/t.co\/41SOg8PYoO",
  "id" : 487296854388785152,
  "created_at" : "2014-07-10 18:06:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487266099340115968",
  "geo" : { },
  "id_str" : "487266639402893314",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Uber for doctor visits.",
  "id" : 487266639402893314,
  "in_reply_to_status_id" : 487266099340115968,
  "created_at" : "2014-07-10 16:06:34 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 72, 86 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487239280650354688",
  "geo" : { },
  "id_str" : "487253645616877569",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit * resists urge to take photo of empty storefront next to @coworkbuffalo *",
  "id" : 487253645616877569,
  "in_reply_to_status_id" : 487239280650354688,
  "created_at" : "2014-07-10 15:14:56 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "indices" : [ 3, 14 ],
      "id_str" : "126030998",
      "id" : 126030998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YwAOdHQRst",
      "expanded_url" : "http:\/\/www.bravemule.com\/in50\/",
      "display_url" : "bravemule.com\/in50\/"
    } ]
  },
  "geo" : { },
  "id_str" : "487231542779850753",
  "text" : "RT @0xabad1dea: if all my tweets about Dwarf Fortress got your attention but you haven't time to learn to play, read this instead. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/YwAOdHQRst",
        "expanded_url" : "http:\/\/www.bravemule.com\/in50\/",
        "display_url" : "bravemule.com\/in50\/"
      } ]
    },
    "geo" : { },
    "id_str" : "487049731047444482",
    "text" : "if all my tweets about Dwarf Fortress got your attention but you haven't time to learn to play, read this instead. http:\/\/t.co\/YwAOdHQRst",
    "id" : 487049731047444482,
    "created_at" : "2014-07-10 01:44:39 +0000",
    "user" : {
      "name" : "The Melissa Virus",
      "screen_name" : "0xabad1dea",
      "protected" : false,
      "id_str" : "126030998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528398279571038208\/Zc_ZWgUI_normal.png",
      "id" : 126030998,
      "verified" : false
    }
  },
  "id" : 487231542779850753,
  "created_at" : "2014-07-10 13:47:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "indices" : [ 3, 15 ],
      "id_str" : "2347646468",
      "id" : 2347646468
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BrutalHouse\/status\/487168839814504448\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/al4rBzt5NY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsLFek6IIAAvc0N.jpg",
      "id_str" : "487168838803660800",
      "id" : 487168838803660800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsLFek6IIAAvc0N.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 667
      } ],
      "display_url" : "pic.twitter.com\/al4rBzt5NY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/bNIN1xih1m",
      "expanded_url" : "http:\/\/www.canadianbusiness.com\/blogs-and-comment\/what-torontos-skyline-will-look-like-in-2020\/",
      "display_url" : "canadianbusiness.com\/blogs-and-comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487196784016384000",
  "text" : "RT @BrutalHouse: Upward growth, not only London look what is happening in Toronto\n\u2014\nhttp:\/\/t.co\/bNIN1xih1m http:\/\/t.co\/al4rBzt5NY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BrutalHouse\/status\/487168839814504448\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/al4rBzt5NY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsLFek6IIAAvc0N.jpg",
        "id_str" : "487168838803660800",
        "id" : 487168838803660800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsLFek6IIAAvc0N.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 667
        } ],
        "display_url" : "pic.twitter.com\/al4rBzt5NY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/bNIN1xih1m",
        "expanded_url" : "http:\/\/www.canadianbusiness.com\/blogs-and-comment\/what-torontos-skyline-will-look-like-in-2020\/",
        "display_url" : "canadianbusiness.com\/blogs-and-comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487168839814504448",
    "text" : "Upward growth, not only London look what is happening in Toronto\n\u2014\nhttp:\/\/t.co\/bNIN1xih1m http:\/\/t.co\/al4rBzt5NY",
    "id" : 487168839814504448,
    "created_at" : "2014-07-10 09:37:57 +0000",
    "user" : {
      "name" : "This Brutal House",
      "screen_name" : "BrutalHouse",
      "protected" : false,
      "id_str" : "2347646468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442441264932200448\/GL0rhIe5_normal.jpeg",
      "id" : 2347646468,
      "verified" : false
    }
  },
  "id" : 487196784016384000,
  "created_at" : "2014-07-10 11:28:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 3, 15 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/4YaNIhQziF",
      "expanded_url" : "http:\/\/io9.com\/homestar-runner-is-coming-back-to-life-1602658798",
      "display_url" : "io9.com\/homestar-runne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487078533689118722",
  "text" : "RT @SaraJChipps: yissssss http:\/\/t.co\/4YaNIhQziF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/4YaNIhQziF",
        "expanded_url" : "http:\/\/io9.com\/homestar-runner-is-coming-back-to-life-1602658798",
        "display_url" : "io9.com\/homestar-runne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487074829837664257",
    "text" : "yissssss http:\/\/t.co\/4YaNIhQziF",
    "id" : 487074829837664257,
    "created_at" : "2014-07-10 03:24:23 +0000",
    "user" : {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "protected" : false,
      "id_str" : "15524875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475386075997683712\/TOSOGa0K_normal.png",
      "id" : 15524875,
      "verified" : false
    }
  },
  "id" : 487078533689118722,
  "created_at" : "2014-07-10 03:39:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 6, 15 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/487045557068636160\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4XWj1FElvw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsJVWffCMAA3h7H.png",
      "id_str" : "487045554606583808",
      "id" : 487045554606583808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsJVWffCMAA3h7H.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4XWj1FElvw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924557171, -78.8793583343 ]
  },
  "id_str" : "487045557068636160",
  "text" : "Sadly @bquarant just doesn\u2019t get emoji http:\/\/t.co\/4XWj1FElvw",
  "id" : 487045557068636160,
  "created_at" : "2014-07-10 01:28:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/INLdfSQMlZ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WuP78X6H5JU",
      "display_url" : "youtube.com\/watch?v=WuP78X\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243427916, -78.8791571122 ]
  },
  "id_str" : "487042864124141570",
  "text" : "IPHONE QUICK DRAW SYSTEM https:\/\/t.co\/INLdfSQMlZ",
  "id" : 487042864124141570,
  "created_at" : "2014-07-10 01:17:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Pike",
      "screen_name" : "rob_pike",
      "indices" : [ 3, 12 ],
      "id_str" : "197263266",
      "id" : 197263266
    }, {
      "name" : "Andrew Gerrand",
      "screen_name" : "enneff",
      "indices" : [ 43, 50 ],
      "id_str" : "14309166",
      "id" : 14309166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/U8oMm4ve0f",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WuP78X6H5JU",
      "display_url" : "youtube.com\/watch?v=WuP78X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487042702672797696",
  "text" : "RT @rob_pike: The best thing ever, TOTH to @enneff https:\/\/t.co\/U8oMm4ve0f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Gerrand",
        "screen_name" : "enneff",
        "indices" : [ 29, 36 ],
        "id_str" : "14309166",
        "id" : 14309166
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/U8oMm4ve0f",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WuP78X6H5JU",
        "display_url" : "youtube.com\/watch?v=WuP78X\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487041469799079937",
    "text" : "The best thing ever, TOTH to @enneff https:\/\/t.co\/U8oMm4ve0f",
    "id" : 487041469799079937,
    "created_at" : "2014-07-10 01:11:49 +0000",
    "user" : {
      "name" : "Rob Pike",
      "screen_name" : "rob_pike",
      "protected" : false,
      "id_str" : "197263266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1134816781\/robicon1_normal.jpg",
      "id" : 197263266,
      "verified" : false
    }
  },
  "id" : 487042702672797696,
  "created_at" : "2014-07-10 01:16:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/GWpOnwhaBX",
      "expanded_url" : "https:\/\/flic.kr\/p\/ogrQTY",
      "display_url" : "flic.kr\/p\/ogrQTY"
    } ]
  },
  "geo" : { },
  "id_str" : "486978406471331840",
  "text" : "\"WHALE HUNTING WITH GUN AND CAMERA\", a good sequel to \"WHALE HUNTING WITH GUN\" https:\/\/t.co\/GWpOnwhaBX",
  "id" : 486978406471331840,
  "created_at" : "2014-07-09 21:01:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rust Belt Hipster",
      "screen_name" : "Buffalo_Hipster",
      "indices" : [ 3, 19 ],
      "id_str" : "547376889",
      "id" : 547376889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486965556793184257",
  "text" : "RT @Buffalo_Hipster: FYI Co-Op cashier, telling me the produce guy is the one with all the tattoos isn't very helpful in your store.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486965219802226689",
    "text" : "FYI Co-Op cashier, telling me the produce guy is the one with all the tattoos isn't very helpful in your store.",
    "id" : 486965219802226689,
    "created_at" : "2014-07-09 20:08:50 +0000",
    "user" : {
      "name" : "Rust Belt Hipster",
      "screen_name" : "Buffalo_Hipster",
      "protected" : false,
      "id_str" : "547376889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2055610413\/centterm2_normal.jpg",
      "id" : 547376889,
      "verified" : false
    }
  },
  "id" : 486965556793184257,
  "created_at" : "2014-07-09 20:10:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/JNfrwdptEG",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=uaQ1vXdf1Q0&list=PL4BTpcGHvOirJmiY0w-w3fXcIeUHVxGpE",
      "display_url" : "youtube.com\/watch?v=uaQ1vX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486959042082770944",
  "text" : "Tons of full-length concert videos have returned to YouTube. Here's one. It's pretty OK. https:\/\/t.co\/JNfrwdptEG",
  "id" : 486959042082770944,
  "created_at" : "2014-07-09 19:44:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Great Foodini",
      "screen_name" : "Gr8Foodini",
      "indices" : [ 0, 11 ],
      "id_str" : "1696845847",
      "id" : 1696845847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486703963119837184",
  "geo" : { },
  "id_str" : "486910531182133248",
  "in_reply_to_user_id" : 1696845847,
  "text" : "@Gr8Foodini Bringing the truck? ;)",
  "id" : 486910531182133248,
  "in_reply_to_status_id" : 486703963119837184,
  "created_at" : "2014-07-09 16:31:31 +0000",
  "in_reply_to_screen_name" : "Gr8Foodini",
  "in_reply_to_user_id_str" : "1696845847",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 3, 8 ],
      "id_str" : "3364",
      "id" : 3364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/oxlGfZfBTQ",
      "expanded_url" : "https:\/\/max.omb.gov\/maxportal\/",
      "display_url" : "max.omb.gov\/maxportal\/"
    } ]
  },
  "geo" : { },
  "id_str" : "486883361055453184",
  "text" : "RT @cjoh: Want to fix procurement? Make it so instead of spending millions of dollars on this: https:\/\/t.co\/oxlGfZfBTQ they can just buy Ba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/oxlGfZfBTQ",
        "expanded_url" : "https:\/\/max.omb.gov\/maxportal\/",
        "display_url" : "max.omb.gov\/maxportal\/"
      } ]
    },
    "geo" : { },
    "id_str" : "486883147834200065",
    "text" : "Want to fix procurement? Make it so instead of spending millions of dollars on this: https:\/\/t.co\/oxlGfZfBTQ they can just buy Basecamp.",
    "id" : 486883147834200065,
    "created_at" : "2014-07-09 14:42:42 +0000",
    "user" : {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "protected" : false,
      "id_str" : "3364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000681085924\/1e889c21e483e36bd67798eef968375e_normal.jpeg",
      "id" : 3364,
      "verified" : false
    }
  },
  "id" : 486883361055453184,
  "created_at" : "2014-07-09 14:43:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486730941709049856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243374756, -78.8791361266 ]
  },
  "id_str" : "486732358884663296",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza STRIKE THE EARTH",
  "id" : 486732358884663296,
  "in_reply_to_status_id" : 486730941709049856,
  "created_at" : "2014-07-09 04:43:32 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 41, 56 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486692915691810816",
  "text" : "There's too many good talk proposals for @nickelcityruby. Can everyone just come and speak for 2 minutes? How does that sound?",
  "id" : 486692915691810816,
  "created_at" : "2014-07-09 02:06:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486692458642698240",
  "text" : "Couldn't make this up if I tried, listening to a bootleg stream that just got saved from a dead phone by a vape pen battery.",
  "id" : 486692458642698240,
  "created_at" : "2014-07-09 02:04:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SsEADP24Np",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=8006869",
      "display_url" : "news.ycombinator.com\/item?id=8006869"
    } ]
  },
  "geo" : { },
  "id_str" : "486634070156136448",
  "text" : "RT @steveklabnik: Twitter cares so little about its users that people actually try things like https:\/\/t.co\/SsEADP24Np",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/SsEADP24Np",
        "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=8006869",
        "display_url" : "news.ycombinator.com\/item?id=8006869"
      } ]
    },
    "geo" : { },
    "id_str" : "486633034763227138",
    "text" : "Twitter cares so little about its users that people actually try things like https:\/\/t.co\/SsEADP24Np",
    "id" : 486633034763227138,
    "created_at" : "2014-07-08 22:08:51 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 486634070156136448,
  "created_at" : "2014-07-08 22:12:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 0, 9 ],
      "id_str" : "18824526",
      "id" : 18824526
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 10, 22 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 23, 36 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 37, 46 ],
      "id_str" : "2998581",
      "id" : 2998581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486623332121329664",
  "geo" : { },
  "id_str" : "486623698019835905",
  "in_reply_to_user_id" : 18824526,
  "text" : "@jacobian @juliepagano @lindseybieda @kerrizor LOL'Reilly",
  "id" : 486623698019835905,
  "in_reply_to_status_id" : 486623332121329664,
  "created_at" : "2014-07-08 21:31:45 +0000",
  "in_reply_to_screen_name" : "jacobian",
  "in_reply_to_user_id_str" : "18824526",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486622464512753664",
  "geo" : { },
  "id_str" : "486622704523415552",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer oops :) I'd flip Ice out for NICU. I don't know why, Ice never jived well with me.",
  "id" : 486622704523415552,
  "in_reply_to_status_id" : 486622464512753664,
  "created_at" : "2014-07-08 21:27:48 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486618553261760512",
  "geo" : { },
  "id_str" : "486619528143437824",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer NICU, Steam, Halfway, Guelah, Horn.",
  "id" : 486619528143437824,
  "in_reply_to_status_id" : 486618553261760512,
  "created_at" : "2014-07-08 21:15:11 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/WVr0zkxHIr",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/North_Dumpling_Island",
      "display_url" : "en.wikipedia.org\/wiki\/North_Dum\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486612970219114496",
  "geo" : { },
  "id_str" : "486614041951879170",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik ooh, and private islands with their own currency and navies too http:\/\/t.co\/WVr0zkxHIr",
  "id" : 486614041951879170,
  "in_reply_to_status_id" : 486612970219114496,
  "created_at" : "2014-07-08 20:53:23 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/XvpvmGiD2G",
      "expanded_url" : "http:\/\/i1.ytimg.com\/vi\/wUfT0YqG8go\/hqdefault.jpg",
      "display_url" : "i1.ytimg.com\/vi\/wUfT0YqG8go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486613184711639040",
  "text" : "Bringing back memories...this is on the 3DS eShop this week. It's like pre-Hearthstone. http:\/\/t.co\/XvpvmGiD2G",
  "id" : 486613184711639040,
  "created_at" : "2014-07-08 20:49:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "indices" : [ 3, 18 ],
      "id_str" : "14248784",
      "id" : 14248784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/xlaSpfSpZF",
      "expanded_url" : "http:\/\/www.marriedtothesea.com\/070814",
      "display_url" : "marriedtothesea.com\/070814"
    } ]
  },
  "geo" : { },
  "id_str" : "486545977499590656",
  "text" : "RT @drewtoothpaste: This comic sums up my years of experience in dealing with CSS: http:\/\/t.co\/xlaSpfSpZF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/xlaSpfSpZF",
        "expanded_url" : "http:\/\/www.marriedtothesea.com\/070814",
        "display_url" : "marriedtothesea.com\/070814"
      } ]
    },
    "geo" : { },
    "id_str" : "486545839884484608",
    "text" : "This comic sums up my years of experience in dealing with CSS: http:\/\/t.co\/xlaSpfSpZF",
    "id" : 486545839884484608,
    "created_at" : "2014-07-08 16:22:22 +0000",
    "user" : {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "protected" : false,
      "id_str" : "14248784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1484619295\/drew-twit-avatar-2011_normal.jpg",
      "id" : 14248784,
      "verified" : false
    }
  },
  "id" : 486545977499590656,
  "created_at" : "2014-07-08 16:22:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486541367095476224",
  "geo" : { },
  "id_str" : "486541816255094784",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit nice! Highly suggest the \"Quickstart guide\", and follow it exactly. Granted you embark in a peaceful place, it works",
  "id" : 486541816255094784,
  "in_reply_to_status_id" : 486541367095476224,
  "created_at" : "2014-07-08 16:06:23 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    }, {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 76, 91 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheBuffaloNews\/status\/486528912650797056\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KGorHe3M0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsBwnOECIAATwlN.png",
      "id_str" : "486512578848235520",
      "id" : 486512578848235520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsBwnOECIAATwlN.png",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KGorHe3M0F"
    } ],
    "hashtags" : [ {
      "text" : "Sharknado2",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/1yMpFI5uBI",
      "expanded_url" : "http:\/\/the.Fish",
      "display_url" : "the.Fish"
    } ]
  },
  "geo" : { },
  "id_str" : "486541021019643904",
  "text" : "RT @markpoloncarz: Appropriate as we do Squish http:\/\/t.co\/1yMpFI5uBI here \"@TheBuffaloNews: Scenes from #Sharknado2 shot in Buffalo http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Buffalo News",
        "screen_name" : "TheBuffaloNews",
        "indices" : [ 57, 72 ],
        "id_str" : "43805270",
        "id" : 43805270
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheBuffaloNews\/status\/486528912650797056\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/KGorHe3M0F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsBwnOECIAATwlN.png",
        "id_str" : "486512578848235520",
        "id" : 486512578848235520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsBwnOECIAATwlN.png",
        "sizes" : [ {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KGorHe3M0F"
      } ],
      "hashtags" : [ {
        "text" : "Sharknado2",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/1yMpFI5uBI",
        "expanded_url" : "http:\/\/the.Fish",
        "display_url" : "the.Fish"
      } ]
    },
    "geo" : { },
    "id_str" : "486540868942184448",
    "text" : "Appropriate as we do Squish http:\/\/t.co\/1yMpFI5uBI here \"@TheBuffaloNews: Scenes from #Sharknado2 shot in Buffalo http:\/\/t.co\/KGorHe3M0F\"",
    "id" : 486540868942184448,
    "created_at" : "2014-07-08 16:02:37 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 486541021019643904,
  "created_at" : "2014-07-08 16:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486532536508502017",
  "geo" : { },
  "id_str" : "486533004362141698",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel looks like the same car.",
  "id" : 486533004362141698,
  "in_reply_to_status_id" : 486532536508502017,
  "created_at" : "2014-07-08 15:31:22 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486526499680681984",
  "geo" : { },
  "id_str" : "486526818921349122",
  "in_reply_to_user_id" : 65247837,
  "text" : "@DanAlfano @bquarant Just talked to him yesterday. Busy saving people, etc",
  "id" : 486526818921349122,
  "in_reply_to_status_id" : 486526499680681984,
  "created_at" : "2014-07-08 15:06:47 +0000",
  "in_reply_to_screen_name" : "Hoonidan",
  "in_reply_to_user_id_str" : "65247837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486517118356045824",
  "geo" : { },
  "id_str" : "486517801771745281",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west it's interesting to see \"storytelling\" games come out. I don't think DF tries to tell anything. You do as you make sense of it.",
  "id" : 486517801771745281,
  "in_reply_to_status_id" : 486517118356045824,
  "created_at" : "2014-07-08 14:30:57 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate West",
      "screen_name" : "nate_west",
      "indices" : [ 0, 10 ],
      "id_str" : "942661",
      "id" : 942661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486516196498350080",
  "geo" : { },
  "id_str" : "486516280657059840",
  "in_reply_to_user_id" : 942661,
  "text" : "@nate_west -ly amazing",
  "id" : 486516280657059840,
  "in_reply_to_status_id" : 486516196498350080,
  "created_at" : "2014-07-08 14:24:55 +0000",
  "in_reply_to_screen_name" : "nate_west",
  "in_reply_to_user_id_str" : "942661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/xs3N1wZS0I",
      "expanded_url" : "http:\/\/dwarffortresswiki.org\/images\/e\/e6\/FlowchartDF.png",
      "display_url" : "dwarffortresswiki.org\/images\/e\/e6\/Fl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486514415466856448",
  "text" : "Just a handy flowchart for going from a caravan to happy dwarves (don't worry, you'll internalize this soon): http:\/\/t.co\/xs3N1wZS0I",
  "id" : 486514415466856448,
  "created_at" : "2014-07-08 14:17:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "peregrine",
      "indices" : [ 0, 10 ],
      "id_str" : "896131",
      "id" : 896131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/JLC7u3ZvQK",
      "expanded_url" : "http:\/\/dwarffortresswiki.org\/index.php\/v0.34:Quickstart_guide",
      "display_url" : "dwarffortresswiki.org\/index.php\/v0.3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486512597844242433",
  "geo" : { },
  "id_str" : "486512721899184131",
  "in_reply_to_user_id" : 896131,
  "text" : "@peregrine follow this guide by the letter - http:\/\/t.co\/JLC7u3ZvQK",
  "id" : 486512721899184131,
  "in_reply_to_status_id" : 486512597844242433,
  "created_at" : "2014-07-08 14:10:46 +0000",
  "in_reply_to_screen_name" : "peregrine",
  "in_reply_to_user_id_str" : "896131",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486512558199681026",
  "text" : "\"Startled people climb up the walls of their homes a little too often.\"",
  "id" : 486512558199681026,
  "created_at" : "2014-07-08 14:10:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486512397796929537",
  "text" : "\"Some dwarves have life-long dreams and [...] They cannot yet realize their dreams of taking over the world.\"",
  "id" : 486512397796929537,
  "created_at" : "2014-07-08 14:09:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486512230934921217",
  "text" : "\"Change one line and the world erupts in no-quarter knife fights apparently... hopefully we've emerged from that.\"",
  "id" : 486512230934921217,
  "created_at" : "2014-07-08 14:08:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/NOVhiYuM1L",
      "expanded_url" : "http:\/\/www.bay12games.com\/dwarves\/",
      "display_url" : "bay12games.com\/dwarves\/"
    } ]
  },
  "geo" : { },
  "id_str" : "486512069642948608",
  "text" : "New Dwarf Fortress version in 2 years is out!! http:\/\/t.co\/NOVhiYuM1L",
  "id" : 486512069642948608,
  "created_at" : "2014-07-08 14:08:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486510523861565441",
  "text" : "One thing's for sure: Google cares a lot more about branding on its StreetView car. Bing's SUV just had a tiny logo on the driver side door.",
  "id" : 486510523861565441,
  "created_at" : "2014-07-08 14:02:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486509600326164481",
  "text" : "Spotted a Bing streetview (?) car on Elmwood today. That's a first.",
  "id" : 486509600326164481,
  "created_at" : "2014-07-08 13:58:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486509271454998528",
  "text" : "Enabling Settings &gt; General &gt; Accessibility &gt; Button Shapes is like iOS7 bizarro world.",
  "id" : 486509271454998528,
  "created_at" : "2014-07-08 13:57:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "indices" : [ 3, 17 ],
      "id_str" : "14852199",
      "id" : 14852199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DhlbMP1W4j",
      "expanded_url" : "http:\/\/www.nintendo.co.uk\/Iwata-Asks\/Iwata-Asks-The-Legend-of-Zelda-Spirit-Tracks\/Iwata-Asks-Zelda-Handheld-History-\/3-Make-All-Characters-Suspicious-Types\/3-Make-All-Characters-Suspicious-Types-233845.html",
      "display_url" : "nintendo.co.uk\/Iwata-Asks\/Iwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486477919175184384",
  "text" : "RT @christinelove: Link\u2019s Awakening was explicitly inspired by Twin Peaks? THAT IS REALLY REALLY WEIRD. http:\/\/t.co\/DhlbMP1W4j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/DhlbMP1W4j",
        "expanded_url" : "http:\/\/www.nintendo.co.uk\/Iwata-Asks\/Iwata-Asks-The-Legend-of-Zelda-Spirit-Tracks\/Iwata-Asks-Zelda-Handheld-History-\/3-Make-All-Characters-Suspicious-Types\/3-Make-All-Characters-Suspicious-Types-233845.html",
        "display_url" : "nintendo.co.uk\/Iwata-Asks\/Iwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486378452501532672",
    "text" : "Link\u2019s Awakening was explicitly inspired by Twin Peaks? THAT IS REALLY REALLY WEIRD. http:\/\/t.co\/DhlbMP1W4j",
    "id" : 486378452501532672,
    "created_at" : "2014-07-08 05:17:14 +0000",
    "user" : {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "protected" : false,
      "id_str" : "14852199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550029740006846465\/cGY1Trqg_normal.jpeg",
      "id" : 14852199,
      "verified" : false
    }
  },
  "id" : 486477919175184384,
  "created_at" : "2014-07-08 11:52:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/4XigAMlAcs",
      "expanded_url" : "http:\/\/www.jambase.com\/Articles\/121796\/DJ-Drastic-X-Talks-Phish-Vs.-Hip-Hop-Mashup",
      "display_url" : "jambase.com\/Articles\/12179\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486296514873282560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241190227, -78.8790407066 ]
  },
  "id_str" : "486297479986421760",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik haha no. No talent here. DrasticX did: http:\/\/t.co\/4XigAMlAcs",
  "id" : 486297479986421760,
  "in_reply_to_status_id" : 486296514873282560,
  "created_at" : "2014-07-07 23:55:28 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Gillooly",
      "screen_name" : "mattgillooly",
      "indices" : [ 3, 16 ],
      "id_str" : "693093",
      "id" : 693093
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mattgillooly\/status\/486277371142864897\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/CoqOJI73ul",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-asOrIgAEx32x.jpg",
      "id_str" : "486277369423233025",
      "id" : 486277369423233025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-asOrIgAEx32x.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CoqOJI73ul"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486281481166520320",
  "text" : "RT @mattgillooly: See, now this is why I use rbenv. http:\/\/t.co\/CoqOJI73ul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mattgillooly\/status\/486277371142864897\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/CoqOJI73ul",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-asOrIgAEx32x.jpg",
        "id_str" : "486277369423233025",
        "id" : 486277369423233025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-asOrIgAEx32x.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CoqOJI73ul"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.8871730566, -71.4349110146 ]
    },
    "id_str" : "486277371142864897",
    "text" : "See, now this is why I use rbenv. http:\/\/t.co\/CoqOJI73ul",
    "id" : 486277371142864897,
    "created_at" : "2014-07-07 22:35:34 +0000",
    "user" : {
      "name" : "Matt Gillooly",
      "screen_name" : "mattgillooly",
      "protected" : false,
      "id_str" : "693093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423193464\/greenroom-1_normal.jpg",
      "id" : 693093,
      "verified" : false
    }
  },
  "id" : 486281481166520320,
  "created_at" : "2014-07-07 22:51:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9388299358, -78.883043355 ]
  },
  "id_str" : "486280140914434048",
  "text" : "Backstreet boys playing at full volume in wegmans. Deep in an office park in Rochester, someone is laughing.",
  "id" : 486280140914434048,
  "created_at" : "2014-07-07 22:46:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Clark",
      "screen_name" : "mappingbabel",
      "indices" : [ 3, 16 ],
      "id_str" : "86351835",
      "id" : 86351835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486278972549128193",
  "text" : "RT @mappingbabel: Haha! Some bloke has raised $44,784 to make potato salad! The average wage in his state, Ohio, is $46,703. Haha! This isn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486272620480831488",
    "text" : "Haha! Some bloke has raised $44,784 to make potato salad! The average wage in his state, Ohio, is $46,703. Haha! This isn't hell at all!",
    "id" : 486272620480831488,
    "created_at" : "2014-07-07 22:16:41 +0000",
    "user" : {
      "name" : "Jack Clark",
      "screen_name" : "mappingbabel",
      "protected" : false,
      "id_str" : "86351835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2528989837\/u8uz1kydl0nlzuhsa418_normal.jpeg",
      "id" : 86351835,
      "verified" : false
    }
  },
  "id" : 486278972549128193,
  "created_at" : "2014-07-07 22:41:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/dJXiQdLzjh",
      "expanded_url" : "http:\/\/pokeapi.co\/",
      "display_url" : "pokeapi.co"
    } ]
  },
  "geo" : { },
  "id_str" : "486247291469049856",
  "text" : "*Resists urges to implement as a Campfire bot* http:\/\/t.co\/dJXiQdLzjh",
  "id" : 486247291469049856,
  "created_at" : "2014-07-07 20:36:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/5iROee9N1v",
      "expanded_url" : "http:\/\/livephish.com",
      "display_url" : "livephish.com"
    } ]
  },
  "in_reply_to_status_id_str" : "486239987068063744",
  "geo" : { },
  "id_str" : "486242370443177985",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity Also the http:\/\/t.co\/5iROee9N1v HD webcasts have been amazing. Instant out from the parking lot too! :P",
  "id" : 486242370443177985,
  "in_reply_to_status_id" : 486239987068063744,
  "created_at" : "2014-07-07 20:16:29 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486239987068063744",
  "geo" : { },
  "id_str" : "486240108085915648",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity well, CMAC is coming up! Not going to Randall's, looks fun though.",
  "id" : 486240108085915648,
  "in_reply_to_status_id" : 486239987068063744,
  "created_at" : "2014-07-07 20:07:30 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/YD6b6RsNsd",
      "expanded_url" : "http:\/\/phish.com\/randallsisland\/",
      "display_url" : "phish.com\/randallsisland\/"
    } ]
  },
  "geo" : { },
  "id_str" : "486239481935048706",
  "text" : "What time are The Doors?\n9:30 PM, April 9, 1967\n\n(The copy here is priceless: http:\/\/t.co\/YD6b6RsNsd)",
  "id" : 486239481935048706,
  "created_at" : "2014-07-07 20:05:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/E3N1lrDSr9",
      "expanded_url" : "http:\/\/juliepagano.com\/blog\/2014\/06\/30\/speaker-support-of-awesomeness\/",
      "display_url" : "juliepagano.com\/blog\/2014\/06\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486227414318473216",
  "text" : "Some good reminders for conf organizers and any speaker, really: http:\/\/t.co\/E3N1lrDSr9",
  "id" : 486227414318473216,
  "created_at" : "2014-07-07 19:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486227314271727616",
  "text" : "@juliepagano great slides! funny how I feel similar, and haven't submitted any talks lately :|",
  "id" : 486227314271727616,
  "created_at" : "2014-07-07 19:16:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Balter",
      "screen_name" : "BenBalter",
      "indices" : [ 3, 13 ],
      "id_str" : "16211142",
      "id" : 16211142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/WPR80BSnvL",
      "expanded_url" : "http:\/\/ben.balter.com\/2014\/07\/07\/analysis-of-federal-executive-domains-part-deux\/",
      "display_url" : "ben.balter.com\/2014\/07\/07\/ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486217657985687557",
  "text" : "RT @BenBalter: The bulk of .Gov's run open source, 87% use no detectable CMS, 17% need www., only 1\/4 support SSL &amp; other fun facts: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/WPR80BSnvL",
        "expanded_url" : "http:\/\/ben.balter.com\/2014\/07\/07\/analysis-of-federal-executive-domains-part-deux\/",
        "display_url" : "ben.balter.com\/2014\/07\/07\/ana\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486213237940051968",
    "text" : "The bulk of .Gov's run open source, 87% use no detectable CMS, 17% need www., only 1\/4 support SSL &amp; other fun facts: http:\/\/t.co\/WPR80BSnvL",
    "id" : 486213237940051968,
    "created_at" : "2014-07-07 18:20:43 +0000",
    "user" : {
      "name" : "Ben Balter",
      "screen_name" : "BenBalter",
      "protected" : false,
      "id_str" : "16211142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504989503564443648\/rWZu4dnD_normal.jpeg",
      "id" : 16211142,
      "verified" : false
    }
  },
  "id" : 486217657985687557,
  "created_at" : "2014-07-07 18:38:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "Luminus Media, LLC",
      "screen_name" : "luminusmedia",
      "indices" : [ 13, 26 ],
      "id_str" : "88742394",
      "id" : 88742394
    }, {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 27, 39 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486206003533185024",
  "geo" : { },
  "id_str" : "486207029338329088",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac @luminusmedia @timbouchard CHOOCE THEM!",
  "id" : 486207029338329088,
  "in_reply_to_status_id" : 486206003533185024,
  "created_at" : "2014-07-07 17:56:03 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luminus Media, LLC",
      "screen_name" : "luminusmedia",
      "indices" : [ 0, 13 ],
      "id_str" : "88742394",
      "id" : 88742394
    }, {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 14, 26 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/IH4Yur9ObU",
      "expanded_url" : "http:\/\/vasilisexpress.com\/",
      "display_url" : "vasilisexpress.com"
    } ]
  },
  "in_reply_to_status_id_str" : "486202575768014849",
  "geo" : { },
  "id_str" : "486202842361769984",
  "in_reply_to_user_id" : 88742394,
  "text" : "@luminusmedia @timbouchard i hereby nominate http:\/\/t.co\/IH4Yur9ObU",
  "id" : 486202842361769984,
  "in_reply_to_status_id" : 486202575768014849,
  "created_at" : "2014-07-07 17:39:25 +0000",
  "in_reply_to_screen_name" : "luminusmedia",
  "in_reply_to_user_id_str" : "88742394",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luminus Media, LLC",
      "screen_name" : "luminusmedia",
      "indices" : [ 3, 16 ],
      "id_str" : "88742394",
      "id" : 88742394
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/luminusmedia\/status\/486202575768014849\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/NHMb40lTCu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br9Wqp6IYAEtOYv.jpg",
      "id_str" : "486202575583469569",
      "id" : 486202575583469569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br9Wqp6IYAEtOYv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/NHMb40lTCu"
    } ],
    "hashtags" : [ {
      "text" : "BuffalosWorstWebsite",
      "indices" : [ 74, 95 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/2G79Tbn1Xn",
      "expanded_url" : "http:\/\/www.buffalosworstwebsite.com\/",
      "display_url" : "buffalosworstwebsite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "486202776934825986",
  "text" : "RT @luminusmedia: We're giving away a FREE website project to whoever has #BuffalosWorstWebsite!!! #buffalo  http:\/\/t.co\/2G79Tbn1Xn http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/luminusmedia\/status\/486202575768014849\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/NHMb40lTCu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Br9Wqp6IYAEtOYv.jpg",
        "id_str" : "486202575583469569",
        "id" : 486202575583469569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br9Wqp6IYAEtOYv.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        } ],
        "display_url" : "pic.twitter.com\/NHMb40lTCu"
      } ],
      "hashtags" : [ {
        "text" : "BuffalosWorstWebsite",
        "indices" : [ 56, 77 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/2G79Tbn1Xn",
        "expanded_url" : "http:\/\/www.buffalosworstwebsite.com\/",
        "display_url" : "buffalosworstwebsite.com"
      } ]
    },
    "geo" : { },
    "id_str" : "486202575768014849",
    "text" : "We're giving away a FREE website project to whoever has #BuffalosWorstWebsite!!! #buffalo  http:\/\/t.co\/2G79Tbn1Xn http:\/\/t.co\/NHMb40lTCu",
    "id" : 486202575768014849,
    "created_at" : "2014-07-07 17:38:21 +0000",
    "user" : {
      "name" : "Luminus Media, LLC",
      "screen_name" : "luminusmedia",
      "protected" : false,
      "id_str" : "88742394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1689254776\/twitter-luminus_normal.jpg",
      "id" : 88742394,
      "verified" : false
    }
  },
  "id" : 486202776934825986,
  "created_at" : "2014-07-07 17:39:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486194822038822914",
  "geo" : { },
  "id_str" : "486195431194378240",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Had a feeling this would happen. Just going to wait until the RC for all of this, especially after Mavericks nuked my laptop.",
  "id" : 486195431194378240,
  "in_reply_to_status_id" : 486194822038822914,
  "created_at" : "2014-07-07 17:09:58 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/gvaabQN7nP",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3758-contest-two-free-3-day-passes-to-pitchfork-music-festival",
      "display_url" : "signalvnoise.com\/posts\/3758-con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486183460189384704",
  "text" : "Basecamp is giving away 2 full passes to Pitchfork, and sponsoring it too! http:\/\/t.co\/gvaabQN7nP",
  "id" : 486183460189384704,
  "created_at" : "2014-07-07 16:22:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-A",
      "screen_name" : "MileHighMusik",
      "indices" : [ 0, 14 ],
      "id_str" : "184501661",
      "id" : 184501661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/t1aUMdQ8Sg",
      "expanded_url" : "http:\/\/www.audiomack.com\/album\/dj-drastic-x\/phish-vs-hip-hop-phish-hop",
      "display_url" : "audiomack.com\/album\/dj-drast\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486180798291116033",
  "geo" : { },
  "id_str" : "486183115979632642",
  "in_reply_to_user_id" : 184501661,
  "text" : "@MileHighMusik liking this. heard http:\/\/t.co\/t1aUMdQ8Sg yet?",
  "id" : 486183115979632642,
  "in_reply_to_status_id" : 486180798291116033,
  "created_at" : "2014-07-07 16:21:02 +0000",
  "in_reply_to_screen_name" : "MileHighMusik",
  "in_reply_to_user_id_str" : "184501661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 42, 48 ]
    }, {
      "text" : "nirvana",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "AQband",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "livemusic",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Oizh87rxPX",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-05",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486130251450167298",
  "text" : "RT @UnclePhilsBlog: @AqueousBand Setlists #AQnet 07\/05\/2014 #nirvana returns. http:\/\/t.co\/Oizh87rxPX #AQband #livemusic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 22, 28 ]
      }, {
        "text" : "nirvana",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "AQband",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "livemusic",
        "indices" : [ 89, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/Oizh87rxPX",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-05",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486130065697435648",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand Setlists #AQnet 07\/05\/2014 #nirvana returns. http:\/\/t.co\/Oizh87rxPX #AQband #livemusic",
    "id" : 486130065697435648,
    "created_at" : "2014-07-07 12:50:14 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 486130251450167298,
  "created_at" : "2014-07-07 12:50:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 10, 21 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485954442454634497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242235736, -78.8793316811 ]
  },
  "id_str" : "485958504495054849",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @Dianna_2Ns nice! Someday I need to start a Daily Piper ;)",
  "id" : 485958504495054849,
  "in_reply_to_status_id" : 485954442454634497,
  "created_at" : "2014-07-07 01:28:30 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/UcYYG4HKxx",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=7996059",
      "display_url" : "news.ycombinator.com\/item?id=7996059"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241257906, -78.8789827377 ]
  },
  "id_str" : "485932550016081920",
  "text" : "A real HN comment: \u201CI used to have that passion, when I was young (I\u2019m 29 now\u2026\u201D https:\/\/t.co\/UcYYG4HKxx",
  "id" : 485932550016081920,
  "created_at" : "2014-07-06 23:45:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 3, 13 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/wqo95d3VoW",
      "expanded_url" : "http:\/\/nyr.kr\/1j4PNPp",
      "display_url" : "nyr.kr\/1j4PNPp"
    } ]
  },
  "geo" : { },
  "id_str" : "485892256004452354",
  "text" : "RT @NewYorker: A look back at Arthur Miller\u2019s 1998 piece on life before air conditioning: http:\/\/t.co\/wqo95d3VoW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/wqo95d3VoW",
        "expanded_url" : "http:\/\/nyr.kr\/1j4PNPp",
        "display_url" : "nyr.kr\/1j4PNPp"
      } ]
    },
    "geo" : { },
    "id_str" : "485887248961785856",
    "text" : "A look back at Arthur Miller\u2019s 1998 piece on life before air conditioning: http:\/\/t.co\/wqo95d3VoW",
    "id" : 485887248961785856,
    "created_at" : "2014-07-06 20:45:22 +0000",
    "user" : {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "protected" : false,
      "id_str" : "14677919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421413599441981441\/GMZ5UIRl_normal.jpeg",
      "id" : 14677919,
      "verified" : true
    }
  },
  "id" : 485892256004452354,
  "created_at" : "2014-07-06 21:05:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 25, 36 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485875838827913216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242629605, -78.8791779523 ]
  },
  "id_str" : "485876131032080384",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown maybe half. @phillapier had more luck selling warm beer to desperate people",
  "id" : 485876131032080384,
  "in_reply_to_status_id" : 485875838827913216,
  "created_at" : "2014-07-06 20:01:11 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242629605, -78.8791779523 ]
  },
  "id_str" : "485875300874469376",
  "text" : "Finally home in Buffalo and the weather is perfect.",
  "id" : 485875300874469376,
  "created_at" : "2014-07-06 19:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/485846597377355778\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/TRAtIwrzfg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br4S5-6CMAAA8hF.jpg",
      "id_str" : "485846597150846976",
      "id" : 485846597150846976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br4S5-6CMAAA8hF.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/TRAtIwrzfg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485846597377355778",
  "text" : "Another daily reminder to test network failure and error states. http:\/\/t.co\/TRAtIwrzfg",
  "id" : 485846597377355778,
  "created_at" : "2014-07-06 18:03:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Morehouse",
      "screen_name" : "gmorehou",
      "indices" : [ 3, 12 ],
      "id_str" : "823779530",
      "id" : 823779530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/fdhK0hLWyK",
      "expanded_url" : "http:\/\/gigaom.com\/2014\/06\/30\/the-dark-side-of-io-how-the-u-k-is-making-web-domain-profits-from-a-shady-cold-war-land-deal\/",
      "display_url" : "gigaom.com\/2014\/06\/30\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "485845023653523457",
  "text" : "RT @gmorehou: Don't buy .io domains: http:\/\/t.co\/fdhK0hLWyK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/fdhK0hLWyK",
        "expanded_url" : "http:\/\/gigaom.com\/2014\/06\/30\/the-dark-side-of-io-how-the-u-k-is-making-web-domain-profits-from-a-shady-cold-war-land-deal\/",
        "display_url" : "gigaom.com\/2014\/06\/30\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484219474485452800",
    "text" : "Don't buy .io domains: http:\/\/t.co\/fdhK0hLWyK",
    "id" : 484219474485452800,
    "created_at" : "2014-07-02 06:18:13 +0000",
    "user" : {
      "name" : "Gordon Morehouse",
      "screen_name" : "gmorehou",
      "protected" : false,
      "id_str" : "823779530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2623862039\/ptwh04teaj6y5p1qhrca_normal.jpeg",
      "id" : 823779530,
      "verified" : false
    }
  },
  "id" : 485845023653523457,
  "created_at" : "2014-07-06 17:57:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 1, 11 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Ravenous21",
      "screen_name" : "Ravenous21",
      "indices" : [ 16, 27 ],
      "id_str" : "17057066",
      "id" : 17057066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/2DCljs985T",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b958de498ed323f385eb17?s=rWBtGISwzKXFYYWNtuo3UYbhHv4&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.080504, -73.78474255 ]
  },
  "id_str" : "485787955999821824",
  "text" : ".@aquaranto (at @Ravenous21 w\/ 2 others) https:\/\/t.co\/2DCljs985T",
  "id" : 485787955999821824,
  "created_at" : "2014-07-06 14:10:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0547023472, -73.8026570064 ]
  },
  "id_str" : "485623901129424898",
  "text" : "Shout out to the wedding next door to a Phish show who hired a house band.",
  "id" : 485623901129424898,
  "created_at" : "2014-07-06 03:18:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551216938, -73.806015635 ]
  },
  "id_str" : "485617147016527873",
  "text" : "Even the SPAC bartenders are dancing to this Wingsuit &gt; Piper. Easily best segue of the night.",
  "id" : 485617147016527873,
  "created_at" : "2014-07-06 02:52:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485616042774118401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551019436, -73.8054816233 ]
  },
  "id_str" : "485616651472097280",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester felt that halfway though Wingsuit. Explosions.",
  "id" : 485616651472097280,
  "in_reply_to_status_id" : 485616042774118401,
  "created_at" : "2014-07-06 02:50:06 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485610686899576832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0550193397, -73.8058909364 ]
  },
  "id_str" : "485610953531068416",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx woops. Well I\u2019d like a Fee anyway :)",
  "id" : 485610953531068416,
  "in_reply_to_status_id" : 485610686899576832,
  "created_at" : "2014-07-06 02:27:28 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 38, 49 ],
      "id_str" : "247090698",
      "id" : 247090698
    }, {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 50, 56 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0548620224, -73.8059925009 ]
  },
  "id_str" : "485610215954333696",
  "text" : "Noticed Trey\u2019s megaphone onstage\u2026 \/cc @bizarchive @zzyzx",
  "id" : 485610215954333696,
  "created_at" : "2014-07-06 02:24:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 61, 76 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485607739511431169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.055109052, -73.8058047883 ]
  },
  "id_str" : "485607951629942786",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik :( hoping to do another official game night at @nickelcityruby to provide a non-bar option.",
  "id" : 485607951629942786,
  "in_reply_to_status_id" : 485607739511431169,
  "created_at" : "2014-07-06 02:15:32 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485601253037068288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0549064465, -73.8060137071 ]
  },
  "id_str" : "485607519864102913",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik that would level most humans. Apparently you rolled well.",
  "id" : 485607519864102913,
  "in_reply_to_status_id" : 485601253037068288,
  "created_at" : "2014-07-06 02:13:49 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485605569139859456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551254989, -73.8053908085 ]
  },
  "id_str" : "485606753606705153",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester I bet they\u2019ll break by Chicago. Not a bad thing.",
  "id" : 485606753606705153,
  "in_reply_to_status_id" : 485605569139859456,
  "created_at" : "2014-07-06 02:10:46 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Podrazik",
      "screen_name" : "nataliepo",
      "indices" : [ 0, 10 ],
      "id_str" : "5744892",
      "id" : 5744892
    }, {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 11, 23 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485606118908248064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0552107518, -73.8054239217 ]
  },
  "id_str" : "485606512400687104",
  "in_reply_to_user_id" : 5744892,
  "text" : "@nataliepo @SaraJChipps nope :( oh well. Next time!",
  "id" : 485606512400687104,
  "in_reply_to_status_id" : 485606118908248064,
  "created_at" : "2014-07-06 02:09:49 +0000",
  "in_reply_to_screen_name" : "nataliepo",
  "in_reply_to_user_id_str" : "5744892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    }, {
      "name" : "Wesley Lawrence",
      "screen_name" : "wesleyl524",
      "indices" : [ 12, 23 ],
      "id_str" : "19888131",
      "id" : 19888131
    }, {
      "name" : "lizzy",
      "screen_name" : "thinlizzy17",
      "indices" : [ 24, 36 ],
      "id_str" : "16152076",
      "id" : 16152076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485604849254285313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551971808, -73.8054931353 ]
  },
  "id_str" : "485605937839759361",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive @wesleyl524 @thinlizzy17 sounds good. Seen too many other live PDA updates here \uD83D\uDE11\uD83D\uDE26",
  "id" : 485605937839759361,
  "in_reply_to_status_id" : 485604849254285313,
  "created_at" : "2014-07-06 02:07:32 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485603615512330242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0549920527, -73.806023638 ]
  },
  "id_str" : "485604242615316480",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive far page side near the pav bar is pretty open and has a great view right now.",
  "id" : 485604242615316480,
  "in_reply_to_status_id" : 485603615512330242,
  "created_at" : "2014-07-06 02:00:48 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485599983563837444",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0550551601, -73.8053682523 ]
  },
  "id_str" : "485600789935558658",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik you ok dude?",
  "id" : 485600789935558658,
  "in_reply_to_status_id" : 485599983563837444,
  "created_at" : "2014-07-06 01:47:05 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551297361, -73.8056178168 ]
  },
  "id_str" : "485588521420193792",
  "text" : "First Ghost and now vacuum solo for this tour. \uD83D\uDC7B\uD83D\uDC4D",
  "id" : 485588521420193792,
  "created_at" : "2014-07-06 00:58:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485582320028901376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0546559534, -73.8058680297 ]
  },
  "id_str" : "485582680893833216",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 hoping for it. Last saw it in Rochester.",
  "id" : 485582680893833216,
  "in_reply_to_status_id" : 485582320028901376,
  "created_at" : "2014-07-06 00:35:07 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485571879797661696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0546520977, -73.8058780041 ]
  },
  "id_str" : "485580712695701504",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive would still like to buy you a beer and talk stats :) follow for DM?",
  "id" : 485580712695701504,
  "in_reply_to_status_id" : 485571879797661696,
  "created_at" : "2014-07-06 00:27:18 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/KcecIufiBI",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b890f7498e264a5bc721ca?s=LVZu75BaEkUF7WOFIEeCWakkETM&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0551505417, -73.8056561351 ]
  },
  "id_str" : "485573298517192704",
  "text" : "It's that time again (@ Saratoga Performing Arts Center for Phish w\/ 81 others) https:\/\/t.co\/KcecIufiBI",
  "id" : 485573298517192704,
  "created_at" : "2014-07-05 23:57:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CuseJuice13",
      "screen_name" : "CuseJuice13",
      "indices" : [ 0, 12 ],
      "id_str" : "189294199",
      "id" : 189294199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485522433609596929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0819197279, -73.7851726078 ]
  },
  "id_str" : "485523206506160129",
  "in_reply_to_user_id" : 189294199,
  "text" : "@CuseJuice13 yeah hoping I can grab one. Thanks!",
  "id" : 485523206506160129,
  "in_reply_to_status_id" : 485522433609596929,
  "created_at" : "2014-07-05 20:38:47 +0000",
  "in_reply_to_screen_name" : "CuseJuice13",
  "in_reply_to_user_id_str" : "189294199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CuseJuice13",
      "screen_name" : "CuseJuice13",
      "indices" : [ 0, 12 ],
      "id_str" : "189294199",
      "id" : 189294199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485495730904526850",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0791828748, -73.7861983475 ]
  },
  "id_str" : "485520381353029633",
  "in_reply_to_user_id" : 189294199,
  "text" : "@CuseJuice13 is this still available?",
  "id" : 485520381353029633,
  "in_reply_to_status_id" : 485495730904526850,
  "created_at" : "2014-07-05 20:27:34 +0000",
  "in_reply_to_screen_name" : "CuseJuice13",
  "in_reply_to_user_id_str" : "189294199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin McCarthy",
      "screen_name" : "kmccarth",
      "indices" : [ 3, 12 ],
      "id_str" : "14353271",
      "id" : 14353271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nUpzBqirfm",
      "expanded_url" : "http:\/\/kottke.org\/13\/08\/the-surprising-ages-of-the-founding-fathers-on-july-4-1776",
      "display_url" : "kottke.org\/13\/08\/the-surp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "485392861538435074",
  "text" : "RT @kmccarth: How old were the Founding Fathers that signed the Declaration of Independence? Some of the ages are surprising. \n\nhttp:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/nUpzBqirfm",
        "expanded_url" : "http:\/\/kottke.org\/13\/08\/the-surprising-ages-of-the-founding-fathers-on-july-4-1776",
        "display_url" : "kottke.org\/13\/08\/the-surp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "485379206168477696",
    "text" : "How old were the Founding Fathers that signed the Declaration of Independence? Some of the ages are surprising. \n\nhttp:\/\/t.co\/nUpzBqirfm",
    "id" : 485379206168477696,
    "created_at" : "2014-07-05 11:06:35 +0000",
    "user" : {
      "name" : "Kevin McCarthy",
      "screen_name" : "kmccarth",
      "protected" : false,
      "id_str" : "14353271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000064568009\/6f25c0f02ba3a31a3c9046fc150d514c_normal.png",
      "id" : 14353271,
      "verified" : false
    }
  },
  "id" : 485392861538435074,
  "created_at" : "2014-07-05 12:00:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485259441873248256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3724085038, -71.1221090985 ]
  },
  "id_str" : "485260051821506560",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive yeah, saw it on the video.",
  "id" : 485260051821506560,
  "in_reply_to_status_id" : 485259441873248256,
  "created_at" : "2014-07-05 03:13:06 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TweetsofOld\/status\/485250987511132161\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/K1j6MVALiY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Brv1MliCAAAajG3.jpg",
      "id_str" : "485250981454544896",
      "id" : 485250981454544896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brv1MliCAAAajG3.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K1j6MVALiY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485251716833480704",
  "text" : "RT @TweetsofOld: DUCK EXPLODES, PUTS OUT EYE.--Rhadamanthus, Prize Fowl, Eats Pan of Yeast and Flies Into a Hundred Pieces. PA1910 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TweetsofOld\/status\/485250987511132161\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/K1j6MVALiY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Brv1MliCAAAajG3.jpg",
        "id_str" : "485250981454544896",
        "id" : 485250981454544896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brv1MliCAAAajG3.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/K1j6MVALiY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "485250987511132161",
    "text" : "DUCK EXPLODES, PUTS OUT EYE.--Rhadamanthus, Prize Fowl, Eats Pan of Yeast and Flies Into a Hundred Pieces. PA1910 http:\/\/t.co\/K1j6MVALiY",
    "id" : 485250987511132161,
    "created_at" : "2014-07-05 02:37:05 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 485251716833480704,
  "created_at" : "2014-07-05 02:39:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 7, 17 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3723328128, -71.122280212 ]
  },
  "id_str" : "485249978105729024",
  "text" : "I wish @livephish had a half show option.",
  "id" : 485249978105729024,
  "created_at" : "2014-07-05 02:33:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485249294069284864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37235828, -71.1221153215 ]
  },
  "id_str" : "485249525414506496",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo upper body workout in the pav, gotta fit it in",
  "id" : 485249525414506496,
  "in_reply_to_status_id" : 485249294069284864,
  "created_at" : "2014-07-05 02:31:17 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.1097283627, -70.8769747604 ]
  },
  "id_str" : "485106044582887424",
  "text" : "Boston friends, I have great Sox tickets for tomorrow that we can\u2019t use now. Let me know if you want them. \u26BE\uFE0F",
  "id" : 485106044582887424,
  "created_at" : "2014-07-04 17:01:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 3, 11 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tomdale\/status\/485061725004509184\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/KysjpzTSu2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrtJETJIAAAKTKk.jpg",
      "id_str" : "485061723079311360",
      "id" : 485061723079311360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrtJETJIAAAKTKk.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/KysjpzTSu2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485061832529289216",
  "text" : "RT @tomdale: http:\/\/t.co\/KysjpzTSu2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tomdale\/status\/485061725004509184\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/KysjpzTSu2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrtJETJIAAAKTKk.jpg",
        "id_str" : "485061723079311360",
        "id" : 485061723079311360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrtJETJIAAAKTKk.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/KysjpzTSu2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "485061725004509184",
    "text" : "http:\/\/t.co\/KysjpzTSu2",
    "id" : 485061725004509184,
    "created_at" : "2014-07-04 14:05:01 +0000",
    "user" : {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "protected" : false,
      "id_str" : "668863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317834118\/avatar_normal.png",
      "id" : 668863,
      "verified" : false
    }
  },
  "id" : 485061832529289216,
  "created_at" : "2014-07-04 14:05:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Tw7QuYvLew",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ev7x_y8LOMc&index=7&list=PL38ZwelW-Y3S_y7cioEMG66yFUVFwWIyJ",
      "display_url" : "youtube.com\/watch?v=Ev7x_y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "485053194071195648",
  "text" : "Haven't seen this usage of YouTube annotations before - show chords\/tabs on a video! https:\/\/t.co\/Tw7QuYvLew",
  "id" : 485053194071195648,
  "created_at" : "2014-07-04 13:31:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Bridget",
      "screen_name" : "dragonladyB17",
      "indices" : [ 8, 22 ],
      "id_str" : "158443907",
      "id" : 158443907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485026404937920512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3740134258, -71.1211485933 ]
  },
  "id_str" : "485029172385816576",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @dragonladyB17 he\u2019ll save children but not the British children",
  "id" : 485029172385816576,
  "in_reply_to_status_id" : 485026404937920512,
  "created_at" : "2014-07-04 11:55:40 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484893694445621249",
  "geo" : { },
  "id_str" : "484896120871854081",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer Doors weren't until later, 645 i think?",
  "id" : 484896120871854081,
  "in_reply_to_status_id" : 484893694445621249,
  "created_at" : "2014-07-04 03:06:58 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 34, 40 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2YJwv6cLlv",
      "expanded_url" : "http:\/\/www.blitzortung.org\/Webpages\/index.php?lang=en&page_0=30",
      "display_url" : "blitzortung.org\/Webpages\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484892772449935363",
  "text" : "Insane amounts of lightning. Live @phish stream. REAL LIGHTNING. http:\/\/t.co\/2YJwv6cLlv",
  "id" : 484892772449935363,
  "created_at" : "2014-07-04 02:53:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484891261086617600",
  "text" : "Weather in Boston just took an extreme turn for the worse. Hope everyone is making it out of the fireworks safely.",
  "id" : 484891261086617600,
  "created_at" : "2014-07-04 02:47:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484806409201000448",
  "geo" : { },
  "id_str" : "484806715842785280",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo how about bandwidth? MiFi or something else dedicated?",
  "id" : 484806715842785280,
  "in_reply_to_status_id" : 484806409201000448,
  "created_at" : "2014-07-03 21:11:42 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484801007684030464",
  "geo" : { },
  "id_str" : "484803985556373504",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo in any case would love to know what hardware you used, how to broadcast it (Ustream? Justin.tv?). Would love to try at an AQ show.",
  "id" : 484803985556373504,
  "in_reply_to_status_id" : 484801007684030464,
  "created_at" : "2014-07-03 21:00:52 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484801007684030464",
  "geo" : { },
  "id_str" : "484801676960727041",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo Well distribution is easy, given Amazon S3\/Cloudfront. Bandwidth at the venue would be a problem.",
  "id" : 484801676960727041,
  "in_reply_to_status_id" : 484801007684030464,
  "created_at" : "2014-07-03 20:51:41 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484797158642565120",
  "geo" : { },
  "id_str" : "484798376366862337",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo yeah. i wonder what the minimal cost\/AV setup would be. Video doesn't need to be super professional, just stationary. Good audio.",
  "id" : 484798376366862337,
  "in_reply_to_status_id" : 484797158642565120,
  "created_at" : "2014-07-03 20:38:34 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484795988373041152",
  "geo" : { },
  "id_str" : "484796335053615104",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo Starting to wonder if the \"next\" band will take over by doing this. I bet there's an way to execute this without costing thousands",
  "id" : 484796335053615104,
  "in_reply_to_status_id" : 484795988373041152,
  "created_at" : "2014-07-03 20:30:28 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/T1V2hSzaIU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Nfja-SW1Vcg&t=31m15s",
      "display_url" : "youtube.com\/watch?v=Nfja-S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484778597774012417",
  "text" : "Just can't get over Ghost &gt; Weekapaug. Perfect transition. https:\/\/t.co\/T1V2hSzaIU",
  "id" : 484778597774012417,
  "created_at" : "2014-07-03 19:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YOU ARE CARRYING:",
      "screen_name" : "YouAreCarrying",
      "indices" : [ 3, 18 ],
      "id_str" : "2588364937",
      "id" : 2588364937
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484777460555583488",
  "text" : "RT @YouAreCarrying: @qrush a wallet, a lariat (no, you left it with your coat), a black hemisphere, a ring, a collective of lions' meat, Ja\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thegia.com\/\" rel=\"nofollow\"\u003Einfocom_ebooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "484776870974877696",
    "geo" : { },
    "id_str" : "484777087736115201",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush a wallet, a lariat (no, you left it with your coat), a black hemisphere, a ring, a collective of lions' meat, Jack of all Traits.",
    "id" : 484777087736115201,
    "in_reply_to_status_id" : 484776870974877696,
    "created_at" : "2014-07-03 19:13:59 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "YOU ARE CARRYING:",
      "screen_name" : "YouAreCarrying",
      "protected" : false,
      "id_str" : "2588364937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486092291715518464\/Jhpr1jRK_normal.jpeg",
      "id" : 2588364937,
      "verified" : false
    }
  },
  "id" : 484777460555583488,
  "created_at" : "2014-07-03 19:15:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YOU ARE CARRYING:",
      "screen_name" : "YouAreCarrying",
      "indices" : [ 0, 15 ],
      "id_str" : "2588364937",
      "id" : 2588364937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484776870974877696",
  "in_reply_to_user_id" : 2588364937,
  "text" : "@YouAreCarrying i",
  "id" : 484776870974877696,
  "created_at" : "2014-07-03 19:13:07 +0000",
  "in_reply_to_screen_name" : "YouAreCarrying",
  "in_reply_to_user_id_str" : "2588364937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484775407968092160",
  "geo" : { },
  "id_str" : "484775544840810496",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit ooh missed marketing opportunity. Well if the \"canal\" ever continues next door to Harbor Center, BOOM!",
  "id" : 484775544840810496,
  "in_reply_to_status_id" : 484775407968092160,
  "created_at" : "2014-07-03 19:07:51 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484773889286078466",
  "geo" : { },
  "id_str" : "484774116671909888",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit it'll be even more Buffalo when several senior citizens plow into it",
  "id" : 484774116671909888,
  "in_reply_to_status_id" : 484773889286078466,
  "created_at" : "2014-07-03 19:02:10 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484773228439949312",
  "geo" : { },
  "id_str" : "484773607693103104",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit While we're at it - a raised walkway across Sheridan that *is* a giant donut. Could even be half donut\/hot dog for Ted's!",
  "id" : 484773607693103104,
  "in_reply_to_status_id" : 484773228439949312,
  "created_at" : "2014-07-03 19:00:09 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/RRFkSCdIGt",
      "expanded_url" : "http:\/\/media.idownloadblog.com\/wp-content\/uploads\/2010\/03\/hackers1.jpg",
      "display_url" : "media.idownloadblog.com\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/tLcAhCklEu",
      "expanded_url" : "http:\/\/bills.buffalonews.com\/2014\/07\/03\/let-bidding-begin-potential-buyers-access-bills-financial-books\/",
      "display_url" : "bills.buffalonews.com\/2014\/07\/03\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484758870230052866",
  "text" : "I found the \"virtual data room\" that Bills buyers are granted access to. http:\/\/t.co\/RRFkSCdIGt (From http:\/\/t.co\/tLcAhCklEu)",
  "id" : 484758870230052866,
  "created_at" : "2014-07-03 18:01:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Graham",
      "screen_name" : "ByTimGraham",
      "indices" : [ 0, 12 ],
      "id_str" : "41540854",
      "id" : 41540854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484758010850320384",
  "geo" : { },
  "id_str" : "484758139020247040",
  "in_reply_to_user_id" : 41540854,
  "text" : "@ByTimGraham I deserved that one :)",
  "id" : 484758139020247040,
  "in_reply_to_status_id" : 484758010850320384,
  "created_at" : "2014-07-03 17:58:41 +0000",
  "in_reply_to_screen_name" : "ByTimGraham",
  "in_reply_to_user_id_str" : "41540854",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Graham",
      "screen_name" : "ByTimGraham",
      "indices" : [ 0, 12 ],
      "id_str" : "41540854",
      "id" : 41540854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484757702493872128",
  "geo" : { },
  "id_str" : "484757909310812160",
  "in_reply_to_user_id" : 5743852,
  "text" : "@ByTimGraham ok just read it. That's the latest and greatest BS term I've ever heard.",
  "id" : 484757909310812160,
  "in_reply_to_status_id" : 484757702493872128,
  "created_at" : "2014-07-03 17:57:46 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Graham",
      "screen_name" : "ByTimGraham",
      "indices" : [ 0, 12 ],
      "id_str" : "41540854",
      "id" : 41540854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484757456879243264",
  "geo" : { },
  "id_str" : "484757702493872128",
  "in_reply_to_user_id" : 41540854,
  "text" : "@ByTimGraham WTF is a \"virtual data room\"",
  "id" : 484757702493872128,
  "in_reply_to_status_id" : 484757456879243264,
  "created_at" : "2014-07-03 17:56:57 +0000",
  "in_reply_to_screen_name" : "ByTimGraham",
  "in_reply_to_user_id_str" : "41540854",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484748612153249792",
  "geo" : { },
  "id_str" : "484748725462786048",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer Not suggesting a similar path, trying to understand how others are doing it. Lazily ;P",
  "id" : 484748725462786048,
  "in_reply_to_status_id" : 484748612153249792,
  "created_at" : "2014-07-03 17:21:17 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484748326886469632",
  "text" : "So there's a company and several people working full time on NPM. What about pip, CPAN, and other OSS package managers?",
  "id" : 484748326886469632,
  "created_at" : "2014-07-03 17:19:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Dockery",
      "screen_name" : "S_Dockery",
      "indices" : [ 3, 13 ],
      "id_str" : "246914812",
      "id" : 246914812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ZnFSHvIKEC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QoLywiaM6PA",
      "display_url" : "youtube.com\/watch?v=QoLywi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484746822700007424",
  "text" : "RT @S_Dockery: The most important speech ever delivered in America's fictitious military history https:\/\/t.co\/ZnFSHvIKEC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/ZnFSHvIKEC",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QoLywiaM6PA",
        "display_url" : "youtube.com\/watch?v=QoLywi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484738139668635648",
    "text" : "The most important speech ever delivered in America's fictitious military history https:\/\/t.co\/ZnFSHvIKEC",
    "id" : 484738139668635648,
    "created_at" : "2014-07-03 16:39:13 +0000",
    "user" : {
      "name" : "Stephen Dockery",
      "screen_name" : "S_Dockery",
      "protected" : false,
      "id_str" : "246914812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452592799733391360\/Nh8goidL_normal.jpeg",
      "id" : 246914812,
      "verified" : false
    }
  },
  "id" : 484746822700007424,
  "created_at" : "2014-07-03 17:13:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 0, 13 ],
      "id_str" : "6742522",
      "id" : 6742522
    }, {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 14, 23 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484745153530572802",
  "geo" : { },
  "id_str" : "484745926020698112",
  "in_reply_to_user_id" : 6742522,
  "text" : "@hypatiadotca @jacobian not sure if that would be good or bad. Or if there even would be a way to raise enough $",
  "id" : 484745926020698112,
  "in_reply_to_status_id" : 484745153530572802,
  "created_at" : "2014-07-03 17:10:09 +0000",
  "in_reply_to_screen_name" : "hypatiadotca",
  "in_reply_to_user_id_str" : "6742522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 0, 13 ],
      "id_str" : "6742522",
      "id" : 6742522
    }, {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 14, 23 ],
      "id_str" : "18824526",
      "id" : 18824526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484745153530572802",
  "geo" : { },
  "id_str" : "484745849596305408",
  "in_reply_to_user_id" : 6742522,
  "text" : "@hypatiadotca @jacobian i'm not interested in working on it full time. i think it would change the dynamics of the project immensely though",
  "id" : 484745849596305408,
  "in_reply_to_status_id" : 484745153530572802,
  "created_at" : "2014-07-03 17:09:51 +0000",
  "in_reply_to_screen_name" : "hypatiadotca",
  "in_reply_to_user_id_str" : "6742522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 0, 9 ],
      "id_str" : "18824526",
      "id" : 18824526
    }, {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 10, 23 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/6A8ysI1S9b",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "484734759424118784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3646088241, -71.0939651242 ]
  },
  "id_str" : "484736187009998849",
  "in_reply_to_user_id" : 18824526,
  "text" : "@jacobian @hypatiadotca feeling that for years now with http:\/\/t.co\/6A8ysI1S9b. People demand more than we can give as volunteers.",
  "id" : 484736187009998849,
  "in_reply_to_status_id" : 484734759424118784,
  "created_at" : "2014-07-03 16:31:27 +0000",
  "in_reply_to_screen_name" : "jacobian",
  "in_reply_to_user_id_str" : "18824526",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Elmwood Village ",
      "screen_name" : "ElmwoodVillage",
      "indices" : [ 50, 65 ],
      "id_str" : "25105151",
      "id" : 25105151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bidwell",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "AQband",
      "indices" : [ 123, 130 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 131, 139 ]
    }, {
      "text" : "freemusic",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/TTdNUVSXL8",
      "expanded_url" : "http:\/\/youtu.be\/VgtKwvILZaU",
      "display_url" : "youtu.be\/VgtKwvILZaU"
    } ]
  },
  "geo" : { },
  "id_str" : "484718987205300229",
  "text" : "RT @UnclePhilsBlog: @AqueousBand #bidwell parkway @ElmwoodVillage Set 1 complete video. http:\/\/t.co\/TTdNUVSXL8 share away. #AQband #buffalo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Elmwood Village ",
        "screen_name" : "ElmwoodVillage",
        "indices" : [ 30, 45 ],
        "id_str" : "25105151",
        "id" : 25105151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bidwell",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "AQband",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 111, 119 ]
      }, {
        "text" : "freemusic",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/TTdNUVSXL8",
        "expanded_url" : "http:\/\/youtu.be\/VgtKwvILZaU",
        "display_url" : "youtu.be\/VgtKwvILZaU"
      } ]
    },
    "geo" : { },
    "id_str" : "484717846073987072",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand #bidwell parkway @ElmwoodVillage Set 1 complete video. http:\/\/t.co\/TTdNUVSXL8 share away. #AQband #buffalo #freemusic",
    "id" : 484717846073987072,
    "created_at" : "2014-07-03 15:18:34 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 484718987205300229,
  "created_at" : "2014-07-03 15:23:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloverHSQ",
      "screen_name" : "cloverHSQ",
      "indices" : [ 44, 54 ],
      "id_str" : "176215070",
      "id" : 176215070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Hp073INYND",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b5667d498e9d7f417a14ae?s=kcCDxj3amOoNOqtn6RPmZkr4s-A&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.372779, -71.118267 ]
  },
  "id_str" : "484703048535916544",
  "text" : "VC backed coffee time. (@ Clover Food Lab - @cloverhsq) https:\/\/t.co\/Hp073INYND",
  "id" : 484703048535916544,
  "created_at" : "2014-07-03 14:19:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/NBZGNMv7zV",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
      "display_url" : "nickelcityruby.com\/#speak"
    } ]
  },
  "geo" : { },
  "id_str" : "484695403330551808",
  "text" : "Today's the last day to submit for @nickelcityruby!! http:\/\/t.co\/NBZGNMv7zV",
  "id" : 484695403330551808,
  "created_at" : "2014-07-03 13:49:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3719823738, -71.1224934074 ]
  },
  "id_str" : "484529519240294401",
  "text" : "@melissadclayton \uD83D\uDC4D",
  "id" : 484529519240294401,
  "created_at" : "2014-07-03 02:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3719997371, -71.1230529398 ]
  },
  "id_str" : "484525737467064320",
  "text" : "Looking like July 4th baseball in Boston is going to be a tropical storm-out. \uD83D\uDC4E",
  "id" : 484525737467064320,
  "created_at" : "2014-07-03 02:35:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484502312178548736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37178181, -71.12225631 ]
  },
  "id_str" : "484511418423574528",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier holy shit",
  "id" : 484511418423574528,
  "in_reply_to_status_id" : 484502312178548736,
  "created_at" : "2014-07-03 01:38:18 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloverHSQ",
      "screen_name" : "cloverHSQ",
      "indices" : [ 42, 52 ],
      "id_str" : "176215070",
      "id" : 176215070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Uu64ZbmoDc",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b48fb8498e68a8fe41d3d5?s=Bou2CzQ6q7H7-cZJ1_A-tJ7A9zM&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.372779, -71.118267 ]
  },
  "id_str" : "484472451494342656",
  "text" : "VC backed food time. (@ Clover Food Lab - @cloverhsq) https:\/\/t.co\/Uu64ZbmoDc",
  "id" : 484472451494342656,
  "created_at" : "2014-07-02 23:03:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 1, 12 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/484469382823682048\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/KapY1xdkCo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrkuVTgCUAELbRv.jpg",
      "id_str" : "484469378465812481",
      "id" : 484469378465812481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrkuVTgCUAELbRv.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/KapY1xdkCo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3804466373, -71.1201359543 ]
  },
  "id_str" : "484469382823682048",
  "text" : ".@tenderlove I found your new laptop bag http:\/\/t.co\/KapY1xdkCo",
  "id" : 484469382823682048,
  "created_at" : "2014-07-02 22:51:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484448274649079808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37178181, -71.12225631 ]
  },
  "id_str" : "484448460163121152",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm highly recommend Dwarf Builder and the Jolly Bastion tile set.",
  "id" : 484448460163121152,
  "in_reply_to_status_id" : 484448274649079808,
  "created_at" : "2014-07-02 21:28:08 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37178181, -71.12225631 ]
  },
  "id_str" : "484447932775538688",
  "text" : "New Dwarf Fortress release in almost 2 years next week! STRIKE THE EARTH!",
  "id" : 484447932775538688,
  "created_at" : "2014-07-02 21:26:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joanne chang-myers",
      "screen_name" : "jbchang",
      "indices" : [ 33, 41 ],
      "id_str" : "31391307",
      "id" : 31391307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/m48s8FYVWX",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b445ee498e3c7b88bc57b5?s=K_Egnw9S7PC8K7-Vxv4EZvDT41I&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3511567113, -71.048793067 ]
  },
  "id_str" : "484393219804131328",
  "text" : "I'm at Flour Bakery &amp; Cafe - @jbchang (Boston, MA) https:\/\/t.co\/m48s8FYVWX",
  "id" : 484393219804131328,
  "created_at" : "2014-07-02 17:48:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian pearce",
      "screen_name" : "brian_pearce",
      "indices" : [ 0, 13 ],
      "id_str" : "23118393",
      "id" : 23118393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484386877948952576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3522591609, -71.0497904209 ]
  },
  "id_str" : "484390500560945153",
  "in_reply_to_user_id" : 23118393,
  "text" : "@brian_pearce yanking does not delete the gem by design. It\u2019s meant to prevent a total wipeout of history",
  "id" : 484390500560945153,
  "in_reply_to_status_id" : 484386877948952576,
  "created_at" : "2014-07-02 17:37:49 +0000",
  "in_reply_to_screen_name" : "brian_pearce",
  "in_reply_to_user_id_str" : "23118393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Czarnecki",
      "screen_name" : "CzarneckiD",
      "indices" : [ 0, 11 ],
      "id_str" : "13393",
      "id" : 13393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484389949626916864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3520290965, -71.0500576005 ]
  },
  "id_str" : "484390388967284736",
  "in_reply_to_user_id" : 13393,
  "text" : "@CzarneckiD I don\u2019t think this is enough",
  "id" : 484390388967284736,
  "in_reply_to_status_id" : 484389949626916864,
  "created_at" : "2014-07-02 17:37:22 +0000",
  "in_reply_to_screen_name" : "CzarneckiD",
  "in_reply_to_user_id_str" : "13393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.352602315, -71.0495196066 ]
  },
  "id_str" : "484386663682936833",
  "text" : "Maybe that\u2019s my fault for trying to keep on top of email. But still. \uD83D\uDE3E",
  "id" : 484386663682936833,
  "created_at" : "2014-07-02 17:22:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3525780982, -71.049545213 ]
  },
  "id_str" : "484386537954488320",
  "text" : "Something needs to be done about mistakenly pushed private gems. I shouldn\u2019t be getting personal emails about this. Especially on vacation.",
  "id" : 484386537954488320,
  "created_at" : "2014-07-02 17:22:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/484376916967686144\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/gC15K7tEGP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjaPJvCIAARZ4k.jpg",
      "id_str" : "484376913788411904",
      "id" : 484376913788411904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjaPJvCIAARZ4k.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gC15K7tEGP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3521352218, -71.0504046935 ]
  },
  "id_str" : "484376916967686144",
  "text" : "Harry! http:\/\/t.co\/gC15K7tEGP",
  "id" : 484376916967686144,
  "created_at" : "2014-07-02 16:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484366408550469632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.356390997, -71.0624672817 ]
  },
  "id_str" : "484368918136385536",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss so you earned 60%?",
  "id" : 484368918136385536,
  "in_reply_to_status_id" : 484366408550469632,
  "created_at" : "2014-07-02 16:12:03 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3707159322, -71.1114228877 ]
  },
  "id_str" : "484364781449539584",
  "text" : "Another first: a Bitcoin shirt spotted in the wild. \uD83D\uDE29",
  "id" : 484364781449539584,
  "created_at" : "2014-07-02 15:55:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 4, 14 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/djttF6a8l2",
      "expanded_url" : "http:\/\/nyti.ms\/1qryOcs",
      "display_url" : "nyti.ms\/1qryOcs"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3724017281, -71.1222700053 ]
  },
  "id_str" : "484361447019778049",
  "text" : "Wow @phishmaps made the NYT! Congrats!! http:\/\/t.co\/djttF6a8l2",
  "id" : 484361447019778049,
  "created_at" : "2014-07-02 15:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 3, 16 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Phish",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "SummerTour",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/X487hjErwb",
      "expanded_url" : "http:\/\/nyti.ms\/1qryOcs",
      "display_url" : "nyti.ms\/1qryOcs"
    } ]
  },
  "geo" : { },
  "id_str" : "484361353088360448",
  "text" : "RT @Jmkrochester: How One Phish Fan \u2018Sees\u2019 Music http:\/\/t.co\/X487hjErwb #Phish #SummerTour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Phish",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "SummerTour",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/X487hjErwb",
        "expanded_url" : "http:\/\/nyti.ms\/1qryOcs",
        "display_url" : "nyti.ms\/1qryOcs"
      } ]
    },
    "geo" : { },
    "id_str" : "484360697711566848",
    "text" : "How One Phish Fan \u2018Sees\u2019 Music http:\/\/t.co\/X487hjErwb #Phish #SummerTour",
    "id" : 484360697711566848,
    "created_at" : "2014-07-02 15:39:23 +0000",
    "user" : {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "protected" : false,
      "id_str" : "121941652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000598018115\/8fe5c6de1a66ac02709ef1548853d67f_normal.jpeg",
      "id" : 121941652,
      "verified" : false
    }
  },
  "id" : 484361353088360448,
  "created_at" : "2014-07-02 15:42:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/AhdqZ8N6d6",
      "expanded_url" : "http:\/\/mic.com\/articles\/92449\/six-months-after-legalizing-marijuana-two-big-things-have-happened-in-colorado",
      "display_url" : "mic.com\/articles\/92449\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484361276940754945",
  "text" : "RT @steveklabnik: Six months after legalization in Colorado, revenue is even larger than expected, and crime has dropped http:\/\/t.co\/AhdqZ8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/AhdqZ8N6d6",
        "expanded_url" : "http:\/\/mic.com\/articles\/92449\/six-months-after-legalizing-marijuana-two-big-things-have-happened-in-colorado",
        "display_url" : "mic.com\/articles\/92449\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484360871096094720",
    "text" : "Six months after legalization in Colorado, revenue is even larger than expected, and crime has dropped http:\/\/t.co\/AhdqZ8N6d6",
    "id" : 484360871096094720,
    "created_at" : "2014-07-02 15:40:05 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 484361276940754945,
  "created_at" : "2014-07-02 15:41:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "indices" : [ 3, 13 ],
      "id_str" : "16712921",
      "id" : 16712921
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 116, 129 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/1iLnWRzQoW",
      "expanded_url" : "http:\/\/m.pcgamer.com\/2014\/07\/02\/hearthstone-tournament\/",
      "display_url" : "m.pcgamer.com\/2014\/07\/02\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484361257785376768",
  "text" : "RT @eviltrout: Unbelievable. A Hearthstone tournament that won't allow women to play. http:\/\/t.co\/1iLnWRzQoW - (via @steveklabnik)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Dream of the 90s",
        "screen_name" : "steveklabnik",
        "indices" : [ 101, 114 ],
        "id_str" : "22386062",
        "id" : 22386062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/1iLnWRzQoW",
        "expanded_url" : "http:\/\/m.pcgamer.com\/2014\/07\/02\/hearthstone-tournament\/",
        "display_url" : "m.pcgamer.com\/2014\/07\/02\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484360791773421568",
    "text" : "Unbelievable. A Hearthstone tournament that won't allow women to play. http:\/\/t.co\/1iLnWRzQoW - (via @steveklabnik)",
    "id" : 484360791773421568,
    "created_at" : "2014-07-02 15:39:46 +0000",
    "user" : {
      "name" : "Robin Ward",
      "screen_name" : "eviltrout",
      "protected" : false,
      "id_str" : "16712921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517726840090132481\/JOhTPFiy_normal.jpeg",
      "id" : 16712921,
      "verified" : false
    }
  },
  "id" : 484361257785376768,
  "created_at" : "2014-07-02 15:41:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/TOR7QZJNjl",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
      "display_url" : "nickelcityruby.com\/#speak"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xYLdDyA03Y",
      "expanded_url" : "http:\/\/i.imgur.com\/16hDXbX.jpg",
      "display_url" : "i.imgur.com\/16hDXbX.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "484347056643780608",
  "text" : "One more day to submit a talk idea for @nickelcityruby! http:\/\/t.co\/TOR7QZJNjl (Oh, and here's a new view too: http:\/\/t.co\/xYLdDyA03Y)",
  "id" : 484347056643780608,
  "created_at" : "2014-07-02 14:45:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 57, 72 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iPefH1Xaom",
      "expanded_url" : "http:\/\/i.imgur.com\/16hDXbX.jpg",
      "display_url" : "i.imgur.com\/16hDXbX.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "484346702254444547",
  "text" : "RT @aspleenic: For those of you thinking about coming to @nickelcityruby - this is what Buffalo looks like http:\/\/t.co\/iPefH1Xaom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 42, 57 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/iPefH1Xaom",
        "expanded_url" : "http:\/\/i.imgur.com\/16hDXbX.jpg",
        "display_url" : "i.imgur.com\/16hDXbX.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "484316132590235648",
    "text" : "For those of you thinking about coming to @nickelcityruby - this is what Buffalo looks like http:\/\/t.co\/iPefH1Xaom",
    "id" : 484316132590235648,
    "created_at" : "2014-07-02 12:42:18 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 484346702254444547,
  "created_at" : "2014-07-02 14:43:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 20, 32 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Elmwood Village ",
      "screen_name" : "ElmwoodVillage",
      "indices" : [ 33, 48 ],
      "id_str" : "25105151",
      "id" : 25105151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aqband",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/6XKyOY40Kj",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-01",
      "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484342887342022656",
  "text" : "RT @UnclePhilsBlog: @AqueousBand @ElmwoodVillage 2 sets. Nena and Creedence cover debuts. Hoy show. http:\/\/t.co\/6XKyOY40Kj #aqband",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Elmwood Village ",
        "screen_name" : "ElmwoodVillage",
        "indices" : [ 13, 28 ],
        "id_str" : "25105151",
        "id" : 25105151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aqband",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/6XKyOY40Kj",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2014-07-01",
        "display_url" : "aqueousband.net\/shows\/2014-07-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484193154103791616",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand @ElmwoodVillage 2 sets. Nena and Creedence cover debuts. Hoy show. http:\/\/t.co\/6XKyOY40Kj #aqband",
    "id" : 484193154103791616,
    "created_at" : "2014-07-02 04:33:38 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 484342887342022656,
  "created_at" : "2014-07-02 14:28:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484341748664397824",
  "geo" : { },
  "id_str" : "484342350248833024",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo did you listen to that Ghost yet!? Also, damn.",
  "id" : 484342350248833024,
  "in_reply_to_status_id" : 484341748664397824,
  "created_at" : "2014-07-02 14:26:29 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/484298270802337792\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jLValjvNl3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BriStQwCYAA1e7s.png",
      "id_str" : "484298266230546432",
      "id" : 484298266230546432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BriStQwCYAA1e7s.png",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jLValjvNl3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.372357181, -71.1221765029 ]
  },
  "id_str" : "484298270802337792",
  "text" : "Captions on the Martians videos are amazing. http:\/\/t.co\/jLValjvNl3",
  "id" : 484298270802337792,
  "created_at" : "2014-07-02 11:31:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 85, 94 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.992384747, -71.2203362646 ]
  },
  "id_str" : "484160026974502912",
  "text" : "A little biased but Ghost &gt; Paug is an amazing way to first see a Ghost live. \/cc @LawnMemo",
  "id" : 484160026974502912,
  "created_at" : "2014-07-02 02:22:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484142905766862848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9925021386, -71.2204920454 ]
  },
  "id_str" : "484147482117431297",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive no covers yet either!",
  "id" : 484147482117431297,
  "in_reply_to_status_id" : 484142905766862848,
  "created_at" : "2014-07-02 01:32:09 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/pD4EuRzmt7",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b34c6a498ebc716d346f18?s=nKwK4qRd7vcriCrIIZTLPO8Nhsg&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9935719099, -71.2181471255 ]
  },
  "id_str" : "484125305700110337",
  "text" : "Fuego! (@ Xfinity Center for Phish w\/ 93 others) https:\/\/t.co\/pD4EuRzmt7",
  "id" : 484125305700110337,
  "created_at" : "2014-07-02 00:04:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484109273174376448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9924443129, -71.2188751692 ]
  },
  "id_str" : "484109524215660546",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer hey they need to schedule earlier!",
  "id" : 484109524215660546,
  "in_reply_to_status_id" : 484109273174376448,
  "created_at" : "2014-07-01 23:01:19 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484109273174376448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.992726234, -71.220090754 ]
  },
  "id_str" : "484109425112662017",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer",
  "id" : 484109425112662017,
  "in_reply_to_status_id" : 484109273174376448,
  "created_at" : "2014-07-01 23:00:55 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484108278574895104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9927368296, -71.2200455598 ]
  },
  "id_str" : "484109047356874752",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer no where close to starting. No one is inside yet",
  "id" : 484109047356874752,
  "in_reply_to_status_id" : 484108278574895104,
  "created_at" : "2014-07-01 22:59:25 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Braun",
      "screen_name" : "leydenjar",
      "indices" : [ 0, 10 ],
      "id_str" : "7589652",
      "id" : 7589652
    }, {
      "name" : "Matt Binder",
      "screen_name" : "MattBinder",
      "indices" : [ 19, 30 ],
      "id_str" : "14931637",
      "id" : 14931637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484082142335729664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9941022108, -71.2160692458 ]
  },
  "id_str" : "484099883595345920",
  "in_reply_to_user_id" : 7589652,
  "text" : "@leydenjar I think @MattBinder has been doing a fine job on the shaming front",
  "id" : 484099883595345920,
  "in_reply_to_status_id" : 484082142335729664,
  "created_at" : "2014-07-01 22:23:01 +0000",
  "in_reply_to_screen_name" : "leydenjar",
  "in_reply_to_user_id_str" : "7589652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483719764796141568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9923210047, -71.2184431468 ]
  },
  "id_str" : "484088024368545792",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo let me know when you arrive! Owe you a beer at least.",
  "id" : 484088024368545792,
  "in_reply_to_status_id" : 483719764796141568,
  "created_at" : "2014-07-01 21:35:53 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/KrieDBgGNA",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b2de32498eefe7c9998156?s=Fwk2WjpDizsNAKNXm9-8Qx-0qmk&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.343239, -71.068787 ]
  },
  "id_str" : "484006963572133888",
  "text" : "MORE (@ South End Formaggio) https:\/\/t.co\/KrieDBgGNA",
  "id" : 484006963572133888,
  "created_at" : "2014-07-01 16:13:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Elmwood Village ",
      "screen_name" : "ElmwoodVillage",
      "indices" : [ 29, 44 ],
      "id_str" : "25105151",
      "id" : 25105151
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 45, 57 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squishthephish",
      "indices" : [ 128, 140 ]
    }, {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "buffalo",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483968166708539394",
  "text" : "RT @UnclePhilsBlog: Tonight! @ElmwoodVillage @AqueousBand FREE. Food trucks, vendors, awesome weather, WHERE ELSE WOULD YOU BE? #squishthep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elmwood Village ",
        "screen_name" : "ElmwoodVillage",
        "indices" : [ 9, 24 ],
        "id_str" : "25105151",
        "id" : 25105151
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 25, 37 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squishthephish",
        "indices" : [ 108, 123 ]
      }, {
        "text" : "AQband",
        "indices" : [ 124, 131 ]
      }, {
        "text" : "buffalo",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483966924137959424",
    "text" : "Tonight! @ElmwoodVillage @AqueousBand FREE. Food trucks, vendors, awesome weather, WHERE ELSE WOULD YOU BE? #squishthephish #AQband #buffalo",
    "id" : 483966924137959424,
    "created_at" : "2014-07-01 13:34:41 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 483968166708539394,
  "created_at" : "2014-07-01 13:39:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crema Cafe",
      "screen_name" : "cremacambridge",
      "indices" : [ 50, 65 ],
      "id_str" : "88663970",
      "id" : 88663970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/1liRSYRdw0",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b2a260498e6029e28bd841?s=CrgDtnIpoUYZFBTXePms9-axx7g&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3734931062, -71.1206875242 ]
  },
  "id_str" : "483942827156848640",
  "text" : "The Boston coffee tour continues. (@ Crema Cafe - @cremacambridge) https:\/\/t.co\/1liRSYRdw0",
  "id" : 483942827156848640,
  "created_at" : "2014-07-01 11:58:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
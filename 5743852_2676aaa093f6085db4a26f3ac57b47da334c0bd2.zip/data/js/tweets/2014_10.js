Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ira Glass",
      "screen_name" : "iraglass",
      "indices" : [ 3, 12 ],
      "id_str" : "14589511",
      "id" : 14589511
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/iraglass\/status\/528348902660272128\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/mKhit2iZRA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1UShVjCQAEZQd2.jpg",
      "id_str" : "528348895214977025",
      "id" : 528348895214977025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1UShVjCQAEZQd2.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 859
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/mKhit2iZRA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528349537119649792",
  "text" : "RT @iraglass: Me dressed as dog dressed as me, part two. http:\/\/t.co\/mKhit2iZRA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/iraglass\/status\/528348902660272128\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/mKhit2iZRA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1UShVjCQAEZQd2.jpg",
        "id_str" : "528348895214977025",
        "id" : 528348895214977025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1UShVjCQAEZQd2.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 859
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 860
        } ],
        "display_url" : "pic.twitter.com\/mKhit2iZRA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528348902660272128",
    "text" : "Me dressed as dog dressed as me, part two. http:\/\/t.co\/mKhit2iZRA",
    "id" : 528348902660272128,
    "created_at" : "2014-11-01 00:52:49 +0000",
    "user" : {
      "name" : "Ira Glass",
      "screen_name" : "iraglass",
      "protected" : false,
      "id_str" : "14589511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480213585281298433\/gmgzaZsx_normal.jpeg",
      "id" : 14589511,
      "verified" : true
    }
  },
  "id" : 528349537119649792,
  "created_at" : "2014-11-01 00:55:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528332043852070912",
  "text" : "Acorns has now earned me over $1, which means that is more than any savings account I have ever had. \uD83D\uDCB8",
  "id" : 528332043852070912,
  "created_at" : "2014-10-31 23:45:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 0, 9 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528331159634079744",
  "in_reply_to_user_id" : 18176030,
  "text" : "@drakkhen does not sound any better",
  "id" : 528331159634079744,
  "created_at" : "2014-10-31 23:42:19 +0000",
  "in_reply_to_screen_name" : "drakkhen",
  "in_reply_to_user_id_str" : "18176030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 0, 14 ],
      "id_str" : "543918403",
      "id" : 543918403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528323414281682945",
  "geo" : { },
  "id_str" : "528323634041868288",
  "in_reply_to_user_id" : 543918403,
  "text" : "@TheDefenseman our husky is currently howling at every visitor on the porch. Close enough",
  "id" : 528323634041868288,
  "in_reply_to_status_id" : 528323414281682945,
  "created_at" : "2014-10-31 23:12:24 +0000",
  "in_reply_to_screen_name" : "TheDefenseman",
  "in_reply_to_user_id_str" : "543918403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528320395628118016",
  "geo" : { },
  "id_str" : "528320500863221760",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham I have a post about this",
  "id" : 528320500863221760,
  "in_reply_to_status_id" : 528320395628118016,
  "created_at" : "2014-10-31 22:59:57 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528317141255471105",
  "geo" : { },
  "id_str" : "528319948070715392",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx It\u2019s Ice (Cream)",
  "id" : 528319948070715392,
  "in_reply_to_status_id" : 528317141255471105,
  "created_at" : "2014-10-31 22:57:45 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/steJmpwjtD",
      "expanded_url" : "http:\/\/buffalonews.com",
      "display_url" : "buffalonews.com"
    } ]
  },
  "geo" : { },
  "id_str" : "528298573591371776",
  "text" : "My favorite part of reading http:\/\/t.co\/steJmpwjtD is when I get redirected to a spam site from one of their awful ads. When will it die?",
  "id" : 528298573591371776,
  "created_at" : "2014-10-31 21:32:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 64, 76 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/vCHHJVTbkb",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=TLttGScMnFg",
      "display_url" : "youtube.com\/watch?v=TLttGS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528278617194000384",
  "text" : "Much smoother (and less eardrum blasting than in person) cut of @AqueousBand's 20\/20 from last weekend: https:\/\/t.co\/vCHHJVTbkb",
  "id" : 528278617194000384,
  "created_at" : "2014-10-31 20:13:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528266025767555074",
  "geo" : { },
  "id_str" : "528266519365832705",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik agreed :)",
  "id" : 528266519365832705,
  "in_reply_to_status_id" : 528266025767555074,
  "created_at" : "2014-10-31 19:25:27 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528264033292808194",
  "geo" : { },
  "id_str" : "528265020611002368",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik you didn't get off at Vegas? -_-",
  "id" : 528265020611002368,
  "in_reply_to_status_id" : 528264033292808194,
  "created_at" : "2014-10-31 19:19:30 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/1vHVXMPBHB",
      "expanded_url" : "http:\/\/codepen.io\/qrush\/pen\/Dbafj",
      "display_url" : "codepen.io\/qrush\/pen\/Dbafj"
    }, {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/cEf85eyPEe",
      "expanded_url" : "http:\/\/www.connoratherton.com\/walkway",
      "display_url" : "connoratherton.com\/walkway"
    } ]
  },
  "geo" : { },
  "id_str" : "528261985180217345",
  "text" : "Walkway.js is pretty neat: http:\/\/t.co\/1vHVXMPBHB (via http:\/\/t.co\/cEf85eyPEe)",
  "id" : 528261985180217345,
  "created_at" : "2014-10-31 19:07:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "indices" : [ 0, 6 ],
      "id_str" : "21937199",
      "id" : 21937199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528259020310605824",
  "geo" : { },
  "id_str" : "528259255317843968",
  "in_reply_to_user_id" : 21937199,
  "text" : "@haley sweet. GL HF",
  "id" : 528259255317843968,
  "in_reply_to_status_id" : 528259020310605824,
  "created_at" : "2014-10-31 18:56:35 +0000",
  "in_reply_to_screen_name" : "haley",
  "in_reply_to_user_id_str" : "21937199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "indices" : [ 0, 6 ],
      "id_str" : "21937199",
      "id" : 21937199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527215588494434304",
  "geo" : { },
  "id_str" : "528255951967907842",
  "in_reply_to_user_id" : 21937199,
  "text" : "@haley any bites yet? Also sent :)",
  "id" : 528255951967907842,
  "in_reply_to_status_id" : 527215588494434304,
  "created_at" : "2014-10-31 18:43:28 +0000",
  "in_reply_to_screen_name" : "haley",
  "in_reply_to_user_id_str" : "21937199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528223088328970241",
  "geo" : { },
  "id_str" : "528247327350607872",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 mean girls.",
  "id" : 528247327350607872,
  "in_reply_to_status_id" : 528223088328970241,
  "created_at" : "2014-10-31 18:09:11 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "indices" : [ 3, 10 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/KEFUGizihq",
      "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/a-code-of-conduct-is-not-enough",
      "display_url" : "modelviewculture.com\/pieces\/a-code-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528243376618233856",
  "text" : "RT @Strabd: \"A Code of Conduct Is Not Enough\" https:\/\/t.co\/KEFUGizihq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/KEFUGizihq",
        "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/a-code-of-conduct-is-not-enough",
        "display_url" : "modelviewculture.com\/pieces\/a-code-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528243117959307265",
    "text" : "\"A Code of Conduct Is Not Enough\" https:\/\/t.co\/KEFUGizihq",
    "id" : 528243117959307265,
    "created_at" : "2014-10-31 17:52:28 +0000",
    "user" : {
      "name" : "Strand McDadJokes ",
      "screen_name" : "Strabd",
      "protected" : false,
      "id_str" : "18032208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482639528008507392\/9mrjXlKj_normal.jpeg",
      "id" : 18032208,
      "verified" : false
    }
  },
  "id" : 528243376618233856,
  "created_at" : "2014-10-31 17:53:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 13, 26 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528236589479366656",
  "geo" : { },
  "id_str" : "528241378237878272",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick @gilesgoatboy works great here. I cannot stand Xcode without it. AppCode has a decent vim plugin too.",
  "id" : 528241378237878272,
  "in_reply_to_status_id" : 528236589479366656,
  "created_at" : "2014-10-31 17:45:33 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    }, {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 13, 26 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/nzh5GoAjGo",
      "expanded_url" : "https:\/\/github.com\/XVimProject\/XVim",
      "display_url" : "github.com\/XVimProject\/XV\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "528236196192079872",
  "geo" : { },
  "id_str" : "528236371887288320",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick @gilesgoatboy i have used XVim every day for nearly a year. Sometimes buggy but worth it. https:\/\/t.co\/nzh5GoAjGo",
  "id" : 528236371887288320,
  "in_reply_to_status_id" : 528236196192079872,
  "created_at" : "2014-10-31 17:25:39 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/LsoHjjvagt",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Pubd-spHN-0",
      "display_url" : "youtube.com\/watch?v=Pubd-s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "528222686007136258",
  "geo" : { },
  "id_str" : "528222774465425408",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 https:\/\/t.co\/LsoHjjvagt",
  "id" : 528222774465425408,
  "in_reply_to_status_id" : 528222686007136258,
  "created_at" : "2014-10-31 16:31:37 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528189273343012864",
  "geo" : { },
  "id_str" : "528221077517119488",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 stop trying to make gamehendge happen",
  "id" : 528221077517119488,
  "in_reply_to_status_id" : 528189273343012864,
  "created_at" : "2014-10-31 16:24:53 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 0, 10 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/M1VMsBOrMM",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/whitneyjefferson\/katy-perry-dressed-as-a-cheeto-for-halloween",
      "display_url" : "buzzfeed.com\/whitneyjeffers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528220137615523841",
  "in_reply_to_user_id" : 816041347,
  "text" : "@BreadHive http:\/\/t.co\/M1VMsBOrMM",
  "id" : 528220137615523841,
  "created_at" : "2014-10-31 16:21:09 +0000",
  "in_reply_to_screen_name" : "BreadHive",
  "in_reply_to_user_id_str" : "816041347",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528199226078281729",
  "geo" : { },
  "id_str" : "528199452998119424",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold Without a doubt!",
  "id" : 528199452998119424,
  "in_reply_to_status_id" : 528199226078281729,
  "created_at" : "2014-10-31 14:58:57 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Brenna",
      "screen_name" : "brennx0r",
      "indices" : [ 80, 89 ],
      "id_str" : "14605313",
      "id" : 14605313
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tenderlove\/status\/528199181681168384\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/DLpk97R1aH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SKW2eCAAAiW-V.jpg",
      "id_str" : "528199181492420608",
      "id" : 528199181492420608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SKW2eCAAAiW-V.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/DLpk97R1aH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528199403756998656",
  "text" : "RT @tenderlove: I was thinking about dressing up as a puppet for Halloween. \/cc @brennx0r http:\/\/t.co\/DLpk97R1aH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brenna",
        "screen_name" : "brennx0r",
        "indices" : [ 64, 73 ],
        "id_str" : "14605313",
        "id" : 14605313
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tenderlove\/status\/528199181681168384\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/DLpk97R1aH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SKW2eCAAAiW-V.jpg",
        "id_str" : "528199181492420608",
        "id" : 528199181492420608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SKW2eCAAAiW-V.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/DLpk97R1aH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528199181681168384",
    "text" : "I was thinking about dressing up as a puppet for Halloween. \/cc @brennx0r http:\/\/t.co\/DLpk97R1aH",
    "id" : 528199181681168384,
    "created_at" : "2014-10-31 14:57:53 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 528199403756998656,
  "created_at" : "2014-10-31 14:58:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528195896782372865",
  "geo" : { },
  "id_str" : "528196010355355648",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold yeah but I always appreciated RIT's complete ignorance of that and focus on everything else. That's all gone now.",
  "id" : 528196010355355648,
  "in_reply_to_status_id" : 528195896782372865,
  "created_at" : "2014-10-31 14:45:16 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528191602678718465",
  "text" : "RIT's struggle to be nationally ranked on every list imaginable is sad to watch.",
  "id" : 528191602678718465,
  "created_at" : "2014-10-31 14:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528190624046927872",
  "text" : "RT @coworkbuffalo: Today it\u2019s free to check out the space! And we have donuts. SPOOKY DONUTS! \uD83D\uDC80\uD83D\uDC7B\uD83C\uDF83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528190588391153664",
    "text" : "Today it\u2019s free to check out the space! And we have donuts. SPOOKY DONUTS! \uD83D\uDC80\uD83D\uDC7B\uD83C\uDF83",
    "id" : 528190588391153664,
    "created_at" : "2014-10-31 14:23:44 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 528190624046927872,
  "created_at" : "2014-10-31 14:23:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "indices" : [ 3, 10 ],
      "id_str" : "167533114",
      "id" : 167533114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ruby",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/oIl4VBeZiz",
      "expanded_url" : "http:\/\/youtu.be\/296W8yekKew",
      "display_url" : "youtu.be\/296W8yekKew"
    } ]
  },
  "geo" : { },
  "id_str" : "528180815058849792",
  "text" : "RT @6ftdan: Nickel City Ruby 2014- How to be an Awesome Junior Developer: http:\/\/t.co\/oIl4VBeZiz #Ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ruby",
        "indices" : [ 85, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/oIl4VBeZiz",
        "expanded_url" : "http:\/\/youtu.be\/296W8yekKew",
        "display_url" : "youtu.be\/296W8yekKew"
      } ]
    },
    "geo" : { },
    "id_str" : "525940053659238400",
    "text" : "Nickel City Ruby 2014- How to be an Awesome Junior Developer: http:\/\/t.co\/oIl4VBeZiz #Ruby",
    "id" : 525940053659238400,
    "created_at" : "2014-10-25 09:20:54 +0000",
    "user" : {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "protected" : false,
      "id_str" : "167533114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000545692325\/7b2ae5a114d3cce5450f757db9007a77_normal.jpeg",
      "id" : 167533114,
      "verified" : false
    }
  },
  "id" : 528180815058849792,
  "created_at" : "2014-10-31 13:44:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenner Kliemann",
      "screen_name" : "KennerKliemann",
      "indices" : [ 3, 18 ],
      "id_str" : "1484858438",
      "id" : 1484858438
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 109, 117 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/hOS4oOWPHY",
      "expanded_url" : "http:\/\/youtu.be\/vSPoG93apkI?list=UUWnPjmqvljcafA0z2U1fwKQ",
      "display_url" : "youtu.be\/vSPoG93apkI?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528180732225519616",
  "text" : "RT @KennerKliemann: Nickel City Ruby 2014- Keynote: Abstractions Breed Intuition: http:\/\/t.co\/hOS4oOWPHY via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 89, 97 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/hOS4oOWPHY",
        "expanded_url" : "http:\/\/youtu.be\/vSPoG93apkI?list=UUWnPjmqvljcafA0z2U1fwKQ",
        "display_url" : "youtu.be\/vSPoG93apkI?li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526933009199423488",
    "text" : "Nickel City Ruby 2014- Keynote: Abstractions Breed Intuition: http:\/\/t.co\/hOS4oOWPHY via @YouTube",
    "id" : 526933009199423488,
    "created_at" : "2014-10-28 03:06:34 +0000",
    "user" : {
      "name" : "Kenner Kliemann",
      "screen_name" : "KennerKliemann",
      "protected" : false,
      "id_str" : "1484858438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3761220055\/7b389d72c36c83a85e5e4745b1de0e90_normal.jpeg",
      "id" : 1484858438,
      "verified" : false
    }
  },
  "id" : 528180732225519616,
  "created_at" : "2014-10-31 13:44:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ross",
      "screen_name" : "anthonysross",
      "indices" : [ 3, 16 ],
      "id_str" : "30954003",
      "id" : 30954003
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/blkQqp6Oab",
      "expanded_url" : "http:\/\/youtu.be\/rOE9ydzHQ88",
      "display_url" : "youtu.be\/rOE9ydzHQ88"
    } ]
  },
  "geo" : { },
  "id_str" : "528180708519329795",
  "text" : "RT @anthonysross: Nickel City Ruby 2014- Opening Keynote: http:\/\/t.co\/blkQqp6Oab via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 67, 75 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/blkQqp6Oab",
        "expanded_url" : "http:\/\/youtu.be\/rOE9ydzHQ88",
        "display_url" : "youtu.be\/rOE9ydzHQ88"
      } ]
    },
    "geo" : { },
    "id_str" : "527600450569117697",
    "text" : "Nickel City Ruby 2014- Opening Keynote: http:\/\/t.co\/blkQqp6Oab via @YouTube",
    "id" : 527600450569117697,
    "created_at" : "2014-10-29 23:18:44 +0000",
    "user" : {
      "name" : "Anthony Ross",
      "screen_name" : "anthonysross",
      "protected" : false,
      "id_str" : "30954003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460904458465980416\/7vjOuR51_normal.jpeg",
      "id" : 30954003,
      "verified" : false
    }
  },
  "id" : 528180708519329795,
  "created_at" : "2014-10-31 13:44:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deadmau5",
      "screen_name" : "deadmau5",
      "indices" : [ 3, 12 ],
      "id_str" : "22412376",
      "id" : 22412376
    }, {
      "name" : "Alejandro Jodorowsky",
      "screen_name" : "alejodorowsky",
      "indices" : [ 54, 68 ],
      "id_str" : "140048972",
      "id" : 140048972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528179273161375745",
  "text" : "RT @deadmau5: asked my agent if he could reach out to @alejodorowsky and his team to see if i could score Dune. work of passion. no money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alejandro Jodorowsky",
        "screen_name" : "alejodorowsky",
        "indices" : [ 40, 54 ],
        "id_str" : "140048972",
        "id" : 140048972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527244311289925633",
    "text" : "asked my agent if he could reach out to @alejodorowsky and his team to see if i could score Dune. work of passion. no money.",
    "id" : 527244311289925633,
    "created_at" : "2014-10-28 23:43:34 +0000",
    "user" : {
      "name" : "deadmau5",
      "screen_name" : "deadmau5",
      "protected" : false,
      "id_str" : "22412376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525674381251334144\/d9jYSrpO_normal.png",
      "id" : 22412376,
      "verified" : true
    }
  },
  "id" : 528179273161375745,
  "created_at" : "2014-10-31 13:38:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528178998833340416",
  "geo" : { },
  "id_str" : "528179192911773697",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel been that way for months",
  "id" : 528179192911773697,
  "in_reply_to_status_id" : 528178998833340416,
  "created_at" : "2014-10-31 13:38:27 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/PPnCqaGADa",
      "expanded_url" : "http:\/\/youtu.be\/ZYvJ3XmrHF4",
      "display_url" : "youtu.be\/ZYvJ3XmrHF4"
    } ]
  },
  "geo" : { },
  "id_str" : "528147753503690753",
  "text" : "A great reminder that (most) every band starts at the bottom. http:\/\/t.co\/PPnCqaGADa",
  "id" : 528147753503690753,
  "created_at" : "2014-10-31 11:33:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 3, 13 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/528145946853400577\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/uKveABvKuV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1RZ7mbIIAAEIHt.jpg",
      "id_str" : "528145936770670592",
      "id" : 528145936770670592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1RZ7mbIIAAEIHt.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uKveABvKuV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528146330640596992",
  "text" : "RT @BreadHive: Happy Halloween! We have orange &amp; black bagels - or make any bagel a vampire for $1. Worry about teeth not gluten \uD83C\uDF83 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/528145946853400577\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/uKveABvKuV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1RZ7mbIIAAEIHt.jpg",
        "id_str" : "528145936770670592",
        "id" : 528145936770670592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1RZ7mbIIAAEIHt.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uKveABvKuV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528145946853400577",
    "text" : "Happy Halloween! We have orange &amp; black bagels - or make any bagel a vampire for $1. Worry about teeth not gluten \uD83C\uDF83 http:\/\/t.co\/uKveABvKuV",
    "id" : 528145946853400577,
    "created_at" : "2014-10-31 11:26:20 +0000",
    "user" : {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "protected" : false,
      "id_str" : "816041347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459318201117974529\/Pzr0U68v_normal.png",
      "id" : 816041347,
      "verified" : false
    }
  },
  "id" : 528146330640596992,
  "created_at" : "2014-10-31 11:27:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 0, 4 ],
      "id_str" : "14602130",
      "id" : 14602130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528031144185319425",
  "geo" : { },
  "id_str" : "528040143257481217",
  "in_reply_to_user_id" : 14602130,
  "text" : "@cra hey cool, thanks",
  "id" : 528040143257481217,
  "in_reply_to_status_id" : 528031144185319425,
  "created_at" : "2014-10-31 04:25:55 +0000",
  "in_reply_to_screen_name" : "cra",
  "in_reply_to_user_id_str" : "14602130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528030170418913280",
  "text" : "So I can\u2019t tweet any links now due to Twitter thinking I am a spam bot. \uD83D\uDE1E",
  "id" : 528030170418913280,
  "created_at" : "2014-10-31 03:46:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 9, 20 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/sS3XJBR8Fa",
      "expanded_url" : "http:\/\/opensource.apple.com\/source\/ruby\/ruby-106\/gem.1",
      "display_url" : "opensource.apple.com\/source\/ruby\/ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528019668598935553",
  "text" : "Sad that @jimweirich's name is spelled wrong on every default Apple install - http:\/\/t.co\/sS3XJBR8Fa",
  "id" : 528019668598935553,
  "created_at" : "2014-10-31 03:04:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 8, 14 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/oNiSVVDMz2",
      "expanded_url" : "http:\/\/opensource.apple.com\/source\/RubyGems\/RubyGems-28\/gem-sqlite3.txt",
      "display_url" : "opensource.apple.com\/source\/RubyGem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528019400415121408",
  "text" : "I found @jamis - http:\/\/t.co\/oNiSVVDMz2",
  "id" : 528019400415121408,
  "created_at" : "2014-10-31 03:03:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/gX88wnYQqb",
      "expanded_url" : "http:\/\/opensource.apple.com\/release\/os-x-1010\/",
      "display_url" : "opensource.apple.com\/release\/os-x-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528019365526925312",
  "text" : "Lots of fun stuff on http:\/\/t.co\/gX88wnYQqb",
  "id" : 528019365526925312,
  "created_at" : "2014-10-31 03:03:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Avery A.",
      "screen_name" : "averycodes",
      "indices" : [ 9, 20 ],
      "id_str" : "15199116",
      "id" : 15199116
    }, {
      "name" : "Ryan Brown",
      "screen_name" : "ryan_sb",
      "indices" : [ 21, 29 ],
      "id_str" : "165290994",
      "id" : 165290994
    }, {
      "name" : "Dennis Gaebel \u272D",
      "screen_name" : "gryghostvisuals",
      "indices" : [ 30, 46 ],
      "id_str" : "218159376",
      "id" : 218159376
    }, {
      "name" : "Jesse Shawl",
      "screen_name" : "jshawl",
      "indices" : [ 47, 54 ],
      "id_str" : "149035331",
      "id" : 149035331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/6k6RXcNrQb",
      "expanded_url" : "https:\/\/github.com\/gitready\/gitready\/issues\/47",
      "display_url" : "github.com\/gitready\/gitre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "527892244976517122",
  "geo" : { },
  "id_str" : "528018013383962624",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @averycodes @ryan_sb @gryghostvisuals @jshawl https:\/\/t.co\/6k6RXcNrQb",
  "id" : 528018013383962624,
  "in_reply_to_status_id" : 527892244976517122,
  "created_at" : "2014-10-31 02:57:59 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 0, 13 ],
      "id_str" : "16159121",
      "id" : 16159121
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 14, 21 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527956693607776256",
  "geo" : { },
  "id_str" : "527956897207681024",
  "in_reply_to_user_id" : 16159121,
  "text" : "@chaseclemons @sylvzc holy shit",
  "id" : 527956897207681024,
  "in_reply_to_status_id" : 527956693607776256,
  "created_at" : "2014-10-30 22:55:07 +0000",
  "in_reply_to_screen_name" : "chaseclemons",
  "in_reply_to_user_id_str" : "16159121",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527954519918116865",
  "geo" : { },
  "id_str" : "527954837158518784",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc thanks! and seriously.",
  "id" : 527954837158518784,
  "in_reply_to_status_id" : 527954519918116865,
  "created_at" : "2014-10-30 22:46:56 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527953593400590338",
  "geo" : { },
  "id_str" : "527953715991678976",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc 12 months in 2 weeks. D:",
  "id" : 527953715991678976,
  "in_reply_to_status_id" : 527953593400590338,
  "created_at" : "2014-10-30 22:42:29 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527951484525490178",
  "geo" : { },
  "id_str" : "527951949631860737",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns I hear ya. :) Pixelmator is really great for simple stuff like this. or Keynote.",
  "id" : 527951949631860737,
  "in_reply_to_status_id" : 527951484525490178,
  "created_at" : "2014-10-30 22:35:28 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/3KCbOX49ga",
      "expanded_url" : "http:\/\/nounproject.com\/",
      "display_url" : "nounproject.com"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/iAvcq7KdBI",
      "expanded_url" : "http:\/\/aqueousband.com",
      "display_url" : "aqueousband.com"
    } ]
  },
  "in_reply_to_status_id_str" : "527951036896800768",
  "geo" : { },
  "id_str" : "527951248872734720",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns There's a ton of public domain icons on http:\/\/t.co\/3KCbOX49ga. Found a fun teardrop for http:\/\/t.co\/iAvcq7KdBI there",
  "id" : 527951248872734720,
  "in_reply_to_status_id" : 527951036896800768,
  "created_at" : "2014-10-30 22:32:41 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527950505868537857",
  "text" : "Learning to walk is one thing. Learning to see what's beneath you...that's an entirely new problem.",
  "id" : 527950505868537857,
  "created_at" : "2014-10-30 22:29:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 0, 5 ],
      "id_str" : "819606",
      "id" : 819606
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 6, 19 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527938408162021376",
  "geo" : { },
  "id_str" : "527939369185718272",
  "in_reply_to_user_id" : 819606,
  "text" : "@janl @steveklabnik Ry\u2019leh Design Patterns",
  "id" : 527939369185718272,
  "in_reply_to_status_id" : 527938408162021376,
  "created_at" : "2014-10-30 21:45:28 +0000",
  "in_reply_to_screen_name" : "janl",
  "in_reply_to_user_id_str" : "819606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527936778288644096",
  "text" : "RT @coworkbuffalo: Reminder! Free Friday at our space is tomorrow. Get your downtown on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527930261171085313",
    "text" : "Reminder! Free Friday at our space is tomorrow. Get your downtown on.",
    "id" : 527930261171085313,
    "created_at" : "2014-10-30 21:09:17 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 527936778288644096,
  "created_at" : "2014-10-30 21:35:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/yTtNsajgjt",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/2014\/10\/29\/free-friday-this-friday.html",
      "display_url" : "coworkbuffalo.com\/newsletter\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527935309535657984",
  "text" : "Free Friday is back! Stop on by @coworkbuffalo tomorrow: http:\/\/t.co\/yTtNsajgjt",
  "id" : 527935309535657984,
  "created_at" : "2014-10-30 21:29:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ckdake",
      "screen_name" : "ckdake",
      "indices" : [ 0, 7 ],
      "id_str" : "17077173",
      "id" : 17077173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527921636318937088",
  "geo" : { },
  "id_str" : "527921855324123136",
  "in_reply_to_user_id" : 17077173,
  "text" : "@ckdake Doesn't seem like it. Only if I had my payment information plugged in before. How nice of them to turn that on for me.",
  "id" : 527921855324123136,
  "in_reply_to_status_id" : 527921636318937088,
  "created_at" : "2014-10-30 20:35:53 +0000",
  "in_reply_to_screen_name" : "ckdake",
  "in_reply_to_user_id_str" : "17077173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ckdake",
      "screen_name" : "ckdake",
      "indices" : [ 0, 7 ],
      "id_str" : "17077173",
      "id" : 17077173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527920354090831872",
  "geo" : { },
  "id_str" : "527921382370197504",
  "in_reply_to_user_id" : 17077173,
  "text" : "@ckdake thanks, just shut that off after resetting my password. haven't been in their admin in years",
  "id" : 527921382370197504,
  "in_reply_to_status_id" : 527920354090831872,
  "created_at" : "2014-10-30 20:34:00 +0000",
  "in_reply_to_screen_name" : "ckdake",
  "in_reply_to_user_id_str" : "17077173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ckdake",
      "screen_name" : "ckdake",
      "indices" : [ 0, 7 ],
      "id_str" : "17077173",
      "id" : 17077173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527920178915315712",
  "geo" : { },
  "id_str" : "527920281482833920",
  "in_reply_to_user_id" : 5743852,
  "text" : "@ckdake i've never authorized that in any way, just started happening at some point. I don't see a dime for it.",
  "id" : 527920281482833920,
  "in_reply_to_status_id" : 527920178915315712,
  "created_at" : "2014-10-30 20:29:38 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ckdake",
      "screen_name" : "ckdake",
      "indices" : [ 0, 7 ],
      "id_str" : "17077173",
      "id" : 17077173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527919554157367297",
  "geo" : { },
  "id_str" : "527920178915315712",
  "in_reply_to_user_id" : 17077173,
  "text" : "@ckdake disqus has been doing that for a long time and I hate it.",
  "id" : 527920178915315712,
  "in_reply_to_status_id" : 527919554157367297,
  "created_at" : "2014-10-30 20:29:13 +0000",
  "in_reply_to_screen_name" : "ckdake",
  "in_reply_to_user_id_str" : "17077173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 49, 58 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/as9mvvAvn6",
      "expanded_url" : "http:\/\/gitready.com",
      "display_url" : "gitready.com"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/BKMqJ1Ri4Q",
      "expanded_url" : "https:\/\/github.com\/gitready\/gitready\/issues\/47",
      "display_url" : "github.com\/gitready\/gitre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527913361854693377",
  "text" : "If you're interested in http:\/\/t.co\/as9mvvAvn6 \/ @gitready: https:\/\/t.co\/BKMqJ1Ri4Q",
  "id" : 527913361854693377,
  "created_at" : "2014-10-30 20:02:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick",
      "screen_name" : "nickolus",
      "indices" : [ 0, 9 ],
      "id_str" : "42160020",
      "id" : 42160020
    }, {
      "name" : "Mark Otto",
      "screen_name" : "mdo",
      "indices" : [ 10, 14 ],
      "id_str" : "8207832",
      "id" : 8207832
    }, {
      "name" : "Paul",
      "screen_name" : "phalt_",
      "indices" : [ 15, 22 ],
      "id_str" : "198444822",
      "id" : 198444822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527900109535580160",
  "geo" : { },
  "id_str" : "527907786978385920",
  "in_reply_to_user_id" : 42160020,
  "text" : "@nickolus @mdo @phalt_ that there\u2019s a lot of VC money to burn?",
  "id" : 527907786978385920,
  "in_reply_to_status_id" : 527900109535580160,
  "created_at" : "2014-10-30 19:39:59 +0000",
  "in_reply_to_screen_name" : "nickolus",
  "in_reply_to_user_id_str" : "42160020",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/as9mvvAvn6",
      "expanded_url" : "http:\/\/gitready.com",
      "display_url" : "gitready.com"
    } ]
  },
  "geo" : { },
  "id_str" : "527891284435156993",
  "text" : "http:\/\/t.co\/as9mvvAvn6 is up for renewal in 60 days - anyone up for taking over stewardship of it? Been long neglected.",
  "id" : 527891284435156993,
  "created_at" : "2014-10-30 18:34:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/lC84Ykr3Ip",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/e\/ea\/Toymax_Creepy_Crawlers.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "527832683804913664",
  "geo" : { },
  "id_str" : "527835898553974784",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw holy crap http:\/\/t.co\/lC84Ykr3Ip",
  "id" : 527835898553974784,
  "in_reply_to_status_id" : 527832683804913664,
  "created_at" : "2014-10-30 14:54:19 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 0, 10 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527824830834700288",
  "geo" : { },
  "id_str" : "527825676682805248",
  "in_reply_to_user_id" : 250785234,
  "text" : "@Mechaphil agreed, but Spot has some. And there's Mazurek's in Market Arcade",
  "id" : 527825676682805248,
  "in_reply_to_status_id" : 527824830834700288,
  "created_at" : "2014-10-30 14:13:42 +0000",
  "in_reply_to_screen_name" : "Mechaphil",
  "in_reply_to_user_id_str" : "250785234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 51, 65 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527822850464706560",
  "geo" : { },
  "id_str" : "527824926145650689",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard we have plenty of garbage cans in the @coworkbuffalo basement if you needed one",
  "id" : 527824926145650689,
  "in_reply_to_status_id" : 527822850464706560,
  "created_at" : "2014-10-30 14:10:43 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 17, 27 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 51, 66 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dKHLXsQ7XH",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/4654-nickelcityruby2014-my-little-c-extension-lego-robots-are-magic",
      "display_url" : "confreaks.com\/videos\/4654-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527820655551463426",
  "text" : "The always funny @tehviking talked about ponies at @nickelcityruby. And some C stuff. But mostly ponies - http:\/\/t.co\/dKHLXsQ7XH",
  "id" : 527820655551463426,
  "created_at" : "2014-10-30 13:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 3, 17 ],
      "id_str" : "369585978",
      "id" : 369585978
    }, {
      "name" : "Ruby Rogues",
      "screen_name" : "rubyrogues",
      "indices" : [ 49, 60 ],
      "id_str" : "284225770",
      "id" : 284225770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/ct3G1L09zr",
      "expanded_url" : "http:\/\/ow.ly\/Dw6YQ",
      "display_url" : "ow.ly\/Dw6YQ"
    } ]
  },
  "geo" : { },
  "id_str" : "527820329817628672",
  "text" : "RT @meaganewaller: ICYMI: I was on an episode of @rubyrogues to talk about Accountability and Diversity, check it out: http:\/\/t.co\/ct3G1L09\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ruby Rogues",
        "screen_name" : "rubyrogues",
        "indices" : [ 30, 41 ],
        "id_str" : "284225770",
        "id" : 284225770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ct3G1L09zr",
        "expanded_url" : "http:\/\/ow.ly\/Dw6YQ",
        "display_url" : "ow.ly\/Dw6YQ"
      } ]
    },
    "geo" : { },
    "id_str" : "527529027268263936",
    "text" : "ICYMI: I was on an episode of @rubyrogues to talk about Accountability and Diversity, check it out: http:\/\/t.co\/ct3G1L09zr",
    "id" : 527529027268263936,
    "created_at" : "2014-10-29 18:34:55 +0000",
    "user" : {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "protected" : false,
      "id_str" : "369585978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559117803043950592\/Dxshutmf_normal.jpeg",
      "id" : 369585978,
      "verified" : false
    }
  },
  "id" : 527820329817628672,
  "created_at" : "2014-10-30 13:52:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527765217493921792",
  "geo" : { },
  "id_str" : "527819642861940736",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour share and share alike! Most tapers will outright refuse money. It's such a different culture.",
  "id" : 527819642861940736,
  "in_reply_to_status_id" : 527765217493921792,
  "created_at" : "2014-10-30 13:49:43 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blind Chow",
      "screen_name" : "BlindChow",
      "indices" : [ 3, 13 ],
      "id_str" : "469628753",
      "id" : 469628753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527652800809820160",
  "text" : "RT @BlindChow: singer at concert: *says name of city we're in*\n\nme: that's the name of the city we're in!\n\nfriend: it is good to hear the n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525859127516340224",
    "text" : "singer at concert: *says name of city we're in*\n\nme: that's the name of the city we're in!\n\nfriend: it is good to hear the name of our city!",
    "id" : 525859127516340224,
    "created_at" : "2014-10-25 03:59:20 +0000",
    "user" : {
      "name" : "Blind Chow",
      "screen_name" : "BlindChow",
      "protected" : false,
      "id_str" : "469628753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567407333081231360\/KPaYOpQ8_normal.jpeg",
      "id" : 469628753,
      "verified" : false
    }
  },
  "id" : 527652800809820160,
  "created_at" : "2014-10-30 02:46:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527652623562719232",
  "text" : "Really hate the days where you push the rock uphill and you just get nowhere.",
  "id" : 527652623562719232,
  "created_at" : "2014-10-30 02:46:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527635272838963200",
  "geo" : { },
  "id_str" : "527635346385678336",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky ahhhh yes! have a great show",
  "id" : 527635346385678336,
  "in_reply_to_status_id" : 527635272838963200,
  "created_at" : "2014-10-30 01:37:24 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527634877454491648",
  "geo" : { },
  "id_str" : "527634983125385216",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky seriously. Hit any of the shows this week?",
  "id" : 527634983125385216,
  "in_reply_to_status_id" : 527634877454491648,
  "created_at" : "2014-10-30 01:35:57 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/527632863789715458\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/B1oJvnWfYI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1KHSvhCQAAlU9c.png",
      "id_str" : "527632862418190336",
      "id" : 527632862418190336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1KHSvhCQAAlU9c.png",
      "sizes" : [ {
        "h" : 107,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 1246
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/B1oJvnWfYI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527632863789715458",
  "text" : "Here's a user story:\n\nGiven I am a user of Twitter\nWhen I look at my timeline\nThen I should see my fucking tweets http:\/\/t.co\/B1oJvnWfYI",
  "id" : 527632863789715458,
  "created_at" : "2014-10-30 01:27:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 95, 103 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/527631360156913664\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GwgDtgdhr6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1KF7L2CYAEQML9.png",
      "id_str" : "527631358193983489",
      "id" : 527631358193983489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1KF7L2CYAEQML9.png",
      "sizes" : [ {
        "h" : 107,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 1246
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GwgDtgdhr6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527631360156913664",
  "text" : "Twitter is literally failing at showing tweets. How much worse can their web interface get? cc @haacked http:\/\/t.co\/GwgDtgdhr6",
  "id" : 527631360156913664,
  "created_at" : "2014-10-30 01:21:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527630668319047680",
  "geo" : { },
  "id_str" : "527631061841244162",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns mohu leaf is pretty great for just the networks.",
  "id" : 527631061841244162,
  "in_reply_to_status_id" : 527630668319047680,
  "created_at" : "2014-10-30 01:20:22 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 0, 11 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/B8GF2jxof4",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aNHIFM0Y87c",
      "display_url" : "youtube.com\/watch?v=aNHIFM\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "527628185937002497",
  "geo" : { },
  "id_str" : "527628642361176064",
  "in_reply_to_user_id" : 47509268,
  "text" : "@sarahjeong you ate my fractal! https:\/\/t.co\/B8GF2jxof4",
  "id" : 527628642361176064,
  "in_reply_to_status_id" : 527628185937002497,
  "created_at" : "2014-10-30 01:10:45 +0000",
  "in_reply_to_screen_name" : "sarahjeong",
  "in_reply_to_user_id_str" : "47509268",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527623098036936704",
  "geo" : { },
  "id_str" : "527628336399269888",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog what variant? There's a million",
  "id" : 527628336399269888,
  "in_reply_to_status_id" : 527623098036936704,
  "created_at" : "2014-10-30 01:09:32 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527621374441824256",
  "text" : "Menlo\/Mensch doesn't feel like Yosemite's style to me. Anyone using something better?",
  "id" : 527621374441824256,
  "created_at" : "2014-10-30 00:41:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/527612729155391488\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bUXE1K6Vs5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1J096HIQAAJvrT.jpg",
      "id_str" : "527612713275768832",
      "id" : 527612713275768832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1J096HIQAAJvrT.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bUXE1K6Vs5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/X1XyAWj6QT",
      "expanded_url" : "http:\/\/www.publicespresso.com\/products\/the-coffee-nerd-starter-kit",
      "display_url" : "publicespresso.com\/products\/the-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527613358199930880",
  "text" : "RT @PublicEspresso: The Coffee Nerd Starter Kit is available for pre-order through our website. Act quickly http:\/\/t.co\/X1XyAWj6QT http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/527612729155391488\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/bUXE1K6Vs5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1J096HIQAAJvrT.jpg",
        "id_str" : "527612713275768832",
        "id" : 527612713275768832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1J096HIQAAJvrT.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bUXE1K6Vs5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/X1XyAWj6QT",
        "expanded_url" : "http:\/\/www.publicespresso.com\/products\/the-coffee-nerd-starter-kit",
        "display_url" : "publicespresso.com\/products\/the-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527612729155391488",
    "text" : "The Coffee Nerd Starter Kit is available for pre-order through our website. Act quickly http:\/\/t.co\/X1XyAWj6QT http:\/\/t.co\/bUXE1K6Vs5",
    "id" : 527612729155391488,
    "created_at" : "2014-10-30 00:07:31 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 527613358199930880,
  "created_at" : "2014-10-30 00:10:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/fptRaYXMrK",
      "expanded_url" : "http:\/\/n.pr\/1teRr2s",
      "display_url" : "n.pr\/1teRr2s"
    } ]
  },
  "geo" : { },
  "id_str" : "527605184499691521",
  "text" : "T-Pain sans autotune can sing! Damn. http:\/\/t.co\/fptRaYXMrK",
  "id" : 527605184499691521,
  "created_at" : "2014-10-29 23:37:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/senjthGQeT",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/",
      "display_url" : "coworkbuffalo.com\/newsletter\/"
    } ]
  },
  "geo" : { },
  "id_str" : "527523984313569281",
  "text" : "RT @coworkbuffalo: Subscribing is a painless way to keep up on such things as FREE FRIDAY. We are not even monthly! http:\/\/t.co\/senjthGQeT \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/senjthGQeT",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/newsletter\/",
        "display_url" : "coworkbuffalo.com\/newsletter\/"
      } ]
    },
    "geo" : { },
    "id_str" : "527521584752623616",
    "text" : "Subscribing is a painless way to keep up on such things as FREE FRIDAY. We are not even monthly! http:\/\/t.co\/senjthGQeT (sigh?)",
    "id" : 527521584752623616,
    "created_at" : "2014-10-29 18:05:21 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 527523984313569281,
  "created_at" : "2014-10-29 18:14:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527523973332881408",
  "text" : "RT @coworkbuffalo: So, Free Friday is this: you show up at our space Friday (Oct. 31, Halloween), and we don't charge you. Spread the word?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527522729252372480",
    "text" : "So, Free Friday is this: you show up at our space Friday (Oct. 31, Halloween), and we don't charge you. Spread the word?",
    "id" : 527522729252372480,
    "created_at" : "2014-10-29 18:09:54 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 527523973332881408,
  "created_at" : "2014-10-29 18:14:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 0, 10 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/1cQZiwMMOF",
      "expanded_url" : "https:\/\/shinyplasticbag.com\/dragondrop\/",
      "display_url" : "shinyplasticbag.com\/dragondrop\/"
    } ]
  },
  "in_reply_to_status_id_str" : "527489418593312769",
  "geo" : { },
  "id_str" : "527492258438717440",
  "in_reply_to_user_id" : 14620798,
  "text" : "@zachwaugh how is it different from https:\/\/t.co\/1cQZiwMMOF ?",
  "id" : 527492258438717440,
  "in_reply_to_status_id" : 527489418593312769,
  "created_at" : "2014-10-29 16:08:49 +0000",
  "in_reply_to_screen_name" : "zachwaugh",
  "in_reply_to_user_id_str" : "14620798",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527485500383584256",
  "geo" : { },
  "id_str" : "527488468880850945",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan because sometimes they are really shameful?",
  "id" : 527488468880850945,
  "in_reply_to_status_id" : 527485500383584256,
  "created_at" : "2014-10-29 15:53:45 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 0, 12 ],
      "id_str" : "15387091",
      "id" : 15387091
    }, {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 13, 27 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527485891825373185",
  "geo" : { },
  "id_str" : "527486517434781697",
  "in_reply_to_user_id" : 15387091,
  "text" : "@levineuland @buffalopundit recent BN article that focused on her nails. It's a thing where they print yesterday's news on dead trees",
  "id" : 527486517434781697,
  "in_reply_to_status_id" : 527485891825373185,
  "created_at" : "2014-10-29 15:46:00 +0000",
  "in_reply_to_screen_name" : "levineuland",
  "in_reply_to_user_id_str" : "15387091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 3, 11 ],
      "id_str" : "14587814",
      "id" : 14587814
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 23, 29 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/yK0FHEc6bD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mFGBPzjpvBg&list=RDcSGv-yl1tdE&index=3",
      "display_url" : "youtube.com\/watch?v=mFGBPz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527483723919273984",
  "text" : "RT @jlecour: Thanks to @qrush I've discovered Phish, an awesome rock band : https:\/\/t.co\/yK0FHEc6bD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 10, 16 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/yK0FHEc6bD",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mFGBPzjpvBg&list=RDcSGv-yl1tdE&index=3",
        "display_url" : "youtube.com\/watch?v=mFGBPz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527483479748272131",
    "text" : "Thanks to @qrush I've discovered Phish, an awesome rock band : https:\/\/t.co\/yK0FHEc6bD",
    "id" : 527483479748272131,
    "created_at" : "2014-10-29 15:33:56 +0000",
    "user" : {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "protected" : false,
      "id_str" : "14587814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458872265837273088\/RVAuWqsh_normal.jpeg",
      "id" : 14587814,
      "verified" : false
    }
  },
  "id" : 527483723919273984,
  "created_at" : "2014-10-29 15:34:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/rSccPvb0ri",
      "expanded_url" : "http:\/\/www.marco.org\/2011\/05\/26\/geek-intro-to-phish",
      "display_url" : "marco.org\/2011\/05\/26\/gee\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "527483479748272131",
  "geo" : { },
  "id_str" : "527483702243102720",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour i am unbelievably happy for you. good intro post: http:\/\/t.co\/rSccPvb0ri if you want a Dropbox full of shows let me know :)",
  "id" : 527483702243102720,
  "in_reply_to_status_id" : 527483479748272131,
  "created_at" : "2014-10-29 15:34:49 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 25, 37 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Yrc32gqKRs",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/4662-nickelcityruby2014-aesthetics-and-the-evolution-of-code",
      "display_url" : "confreaks.com\/videos\/4662-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527481479635275778",
  "text" : "Was really happy to have @CoralineAda back in Buffalo this year. One of the best talks last year and this year too: http:\/\/t.co\/Yrc32gqKRs",
  "id" : 527481479635275778,
  "created_at" : "2014-10-29 15:25:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Bedenko",
      "screen_name" : "buffalopundit",
      "indices" : [ 0, 14 ],
      "id_str" : "5795572",
      "id" : 5795572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527478076687794176",
  "geo" : { },
  "id_str" : "527478927384522752",
  "in_reply_to_user_id" : 5795572,
  "text" : "@buffalopundit dear god her site immediately starts by playing her voice",
  "id" : 527478927384522752,
  "in_reply_to_status_id" : 527478076687794176,
  "created_at" : "2014-10-29 15:15:51 +0000",
  "in_reply_to_screen_name" : "buffalopundit",
  "in_reply_to_user_id_str" : "5795572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 12, 27 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527477068549095424",
  "geo" : { },
  "id_str" : "527477339098062848",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns @UnclePhilsBlog trying out the livephish subscription? quite tempted so I can hear this.",
  "id" : 527477339098062848,
  "in_reply_to_status_id" : 527477068549095424,
  "created_at" : "2014-10-29 15:09:32 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ochonicki",
      "screen_name" : "fromonesrc",
      "indices" : [ 0, 11 ],
      "id_str" : "14420513",
      "id" : 14420513
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 54, 67 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527473947357761536",
  "geo" : { },
  "id_str" : "527474135471902721",
  "in_reply_to_user_id" : 14420513,
  "text" : "@fromonesrc I can't take credit for this, but I think @ferventcoder sure deserves some MS $$$",
  "id" : 527474135471902721,
  "in_reply_to_status_id" : 527473947357761536,
  "created_at" : "2014-10-29 14:56:48 +0000",
  "in_reply_to_screen_name" : "fromonesrc",
  "in_reply_to_user_id_str" : "14420513",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/tiBaDERSzt",
      "expanded_url" : "http:\/\/www.extremetech.com\/computing\/192950-windows-10-will-come-with-a-command-line-package-manager-much-to-the-lament-of-linux-users",
      "display_url" : "extremetech.com\/computing\/1929\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527472917097885697",
  "text" : "Ruby\/RubyGems's influence on Windows (from NuGet\/Chocolatey) finally is coming to every Windows install. Wow! http:\/\/t.co\/tiBaDERSzt",
  "id" : 527472917097885697,
  "created_at" : "2014-10-29 14:51:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 7, 17 ],
      "id_str" : "816041347",
      "id" : 816041347
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 22, 37 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/527449318706274305\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/lB35dimMFE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1HgW6YCYAAW3zL.jpg",
      "id_str" : "527449315610877952",
      "id" : 527449315610877952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1HgW6YCYAAW3zL.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lB35dimMFE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527449318706274305",
  "text" : "Proper @BreadHive and @PublicEspresso storage http:\/\/t.co\/lB35dimMFE",
  "id" : 527449318706274305,
  "created_at" : "2014-10-29 13:18:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    }, {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 9, 25 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/oRaDdmgKLW",
      "expanded_url" : "http:\/\/www.relix.com\/articles\/detail\/10-classic-albums-that-are-shorter-than-tahoe-tweezer",
      "display_url" : "relix.com\/articles\/detai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "527354820416782336",
  "geo" : { },
  "id_str" : "527420701343371265",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour @somethingconcon http:\/\/t.co\/oRaDdmgKLW",
  "id" : 527420701343371265,
  "in_reply_to_status_id" : 527354820416782336,
  "created_at" : "2014-10-29 11:24:28 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tim jon taffer mee",
      "screen_name" : "timmeehan666",
      "indices" : [ 0, 13 ],
      "id_str" : "15171903",
      "id" : 15171903
    }, {
      "name" : "Cliff",
      "screen_name" : "moonpolysoft",
      "indices" : [ 14, 27 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527289840174637056",
  "geo" : { },
  "id_str" : "527290434762981376",
  "in_reply_to_user_id" : 15171903,
  "text" : "@timmeehan666 @moonpolysoft that is too classy to be Nick Tahou\u2019s",
  "id" : 527290434762981376,
  "in_reply_to_status_id" : 527289840174637056,
  "created_at" : "2014-10-29 02:46:50 +0000",
  "in_reply_to_screen_name" : "timmeehan666",
  "in_reply_to_user_id_str" : "15171903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527286716416425984",
  "geo" : { },
  "id_str" : "527287379875213312",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV can I pay for this not to happen",
  "id" : 527287379875213312,
  "in_reply_to_status_id" : 527286716416425984,
  "created_at" : "2014-10-29 02:34:42 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/527286440883810304\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ZlVBnXonS1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1FMOMgCcAIt9Qg.jpg",
      "id_str" : "527286438136541186",
      "id" : 527286438136541186,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1FMOMgCcAIt9Qg.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZlVBnXonS1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526883969275793409",
  "geo" : { },
  "id_str" : "527286440883810304",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents fixed http:\/\/t.co\/ZlVBnXonS1",
  "id" : 527286440883810304,
  "in_reply_to_status_id" : 526883969275793409,
  "created_at" : "2014-10-29 02:30:58 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JorDan\u00E9e Key",
      "screen_name" : "JorDaneeKey",
      "indices" : [ 0, 12 ],
      "id_str" : "258063176",
      "id" : 258063176
    }, {
      "name" : "Chase Clemons",
      "screen_name" : "chaseclemons",
      "indices" : [ 13, 26 ],
      "id_str" : "16159121",
      "id" : 16159121
    }, {
      "name" : "Mike Key \u30C4",
      "screen_name" : "mike_key",
      "indices" : [ 27, 36 ],
      "id_str" : "242170995",
      "id" : 242170995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527263535471271937",
  "geo" : { },
  "id_str" : "527264494980845568",
  "in_reply_to_user_id" : 258063176,
  "text" : "@JorDaneeKey @chaseclemons @mike_key User is not in the sudoers file. This incident will be reported.",
  "id" : 527264494980845568,
  "in_reply_to_status_id" : 527263535471271937,
  "created_at" : "2014-10-29 01:03:46 +0000",
  "in_reply_to_screen_name" : "JorDaneeKey",
  "in_reply_to_user_id_str" : "258063176",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527259194433732608",
  "geo" : { },
  "id_str" : "527259420493750272",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 Dug out a keyboard for the little monster to play with. Getting an upright soon as well. It's hard. Nothing good is easy.",
  "id" : 527259420493750272,
  "in_reply_to_status_id" : 527259194433732608,
  "created_at" : "2014-10-29 00:43:36 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/3aOLMsMGKa",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=zxBJBAFcmSY#t=1428",
      "display_url" : "youtube.com\/watch?v=zxBJBA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527259120592621568",
  "text" : "Incredible. Still hard to believe this was all improv'd live - https:\/\/t.co\/3aOLMsMGKa",
  "id" : 527259120592621568,
  "created_at" : "2014-10-29 00:42:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527257997689761792",
  "geo" : { },
  "id_str" : "527258834092310528",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 i'm more amazed someone transcribed this entire song",
  "id" : 527258834092310528,
  "in_reply_to_status_id" : 527257997689761792,
  "created_at" : "2014-10-29 00:41:16 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "friendly catduck\u2122",
      "screen_name" : "duckinator",
      "indices" : [ 0, 11 ],
      "id_str" : "28650670",
      "id" : 28650670
    }, {
      "name" : "Trynity Mirell",
      "screen_name" : "mirell",
      "indices" : [ 12, 19 ],
      "id_str" : "2998829503",
      "id" : 2998829503
    }, {
      "name" : "Katrina Owen",
      "screen_name" : "kytrinyx",
      "indices" : [ 20, 29 ],
      "id_str" : "103086746",
      "id" : 103086746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527236896418979840",
  "geo" : { },
  "id_str" : "527237624201633792",
  "in_reply_to_user_id" : 28650670,
  "text" : "@duckinator @mirell @kytrinyx you can use emoji too \uD83D\uDE31",
  "id" : 527237624201633792,
  "in_reply_to_status_id" : 527236896418979840,
  "created_at" : "2014-10-28 23:16:59 +0000",
  "in_reply_to_screen_name" : "duckinator",
  "in_reply_to_user_id_str" : "28650670",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/6eaUfxuYo3",
      "expanded_url" : "http:\/\/rooms.me\/t\/FU24x3flsc\/gifs\/-",
      "display_url" : "rooms.me\/t\/FU24x3flsc\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527232595344384000",
  "text" : "Posted this GIF earlier this evening in some strange sense of premonition http:\/\/t.co\/6eaUfxuYo3",
  "id" : 527232595344384000,
  "created_at" : "2014-10-28 22:57:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 31, 41 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527231947559292930",
  "text" : "Taking bets on what color hair @aquaranto is coming to come home with. Any takers?",
  "id" : 527231947559292930,
  "created_at" : "2014-10-28 22:54:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "social justice mage",
      "screen_name" : "haley",
      "indices" : [ 0, 6 ],
      "id_str" : "21937199",
      "id" : 21937199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527194784792735744",
  "geo" : { },
  "id_str" : "527213865365667842",
  "in_reply_to_user_id" : 21937199,
  "text" : "@haley is it cool to email you? (found via github)",
  "id" : 527213865365667842,
  "in_reply_to_status_id" : 527194784792735744,
  "created_at" : "2014-10-28 21:42:35 +0000",
  "in_reply_to_screen_name" : "haley",
  "in_reply_to_user_id_str" : "21937199",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527208841977819136",
  "geo" : { },
  "id_str" : "527211203463221249",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody for sure. given i probably spend &gt; $10 monthly on show mp3's, this is perfect",
  "id" : 527211203463221249,
  "in_reply_to_status_id" : 527208841977819136,
  "created_at" : "2014-10-28 21:32:00 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    }, {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 14, 24 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527208154569125888",
  "geo" : { },
  "id_str" : "527208645025861633",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody @LivePhish oof, I hope so!",
  "id" : 527208645025861633,
  "in_reply_to_status_id" : 527208154569125888,
  "created_at" : "2014-10-28 21:21:50 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivePhish",
      "screen_name" : "LivePhish",
      "indices" : [ 18, 28 ],
      "id_str" : "232312841",
      "id" : 232312841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/TsIMvkD1V2",
      "expanded_url" : "http:\/\/plus.livephish.com\/",
      "display_url" : "plus.livephish.com"
    } ]
  },
  "geo" : { },
  "id_str" : "527207784711204864",
  "text" : "Oh wow, unlimited @LivePhish for $10\/mo or $100\/year. Fantastic model. http:\/\/t.co\/TsIMvkD1V2",
  "id" : 527207784711204864,
  "created_at" : "2014-10-28 21:18:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527173071023505408",
  "geo" : { },
  "id_str" : "527173235755192320",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek yeah, i know. my recent concert goings have definitely impacted something.",
  "id" : 527173235755192320,
  "in_reply_to_status_id" : 527173071023505408,
  "created_at" : "2014-10-28 19:01:08 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527168822806343681",
  "geo" : { },
  "id_str" : "527169004201603072",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer it was a great show, but on a more serious note - I think it's time to invest in some actual earplugs",
  "id" : 527169004201603072,
  "in_reply_to_status_id" : 527168822806343681,
  "created_at" : "2014-10-28 18:44:19 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/rJbS1fpEn9",
      "expanded_url" : "https:\/\/theroasty.squarespace.com\/archive\/2014\/10\/27\/aqueous-cd-release-party-102514",
      "display_url" : "theroasty.squarespace.com\/archive\/2014\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527168752312676352",
  "text" : "\"Aqueous blew out my ear drums.\" - mine are still ringing https:\/\/t.co\/rJbS1fpEn9",
  "id" : 527168752312676352,
  "created_at" : "2014-10-28 18:43:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 0, 16 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    }, {
      "name" : "Emily BreadHive",
      "screen_name" : "EmilyBreadHive",
      "indices" : [ 17, 32 ],
      "id_str" : "1945584020",
      "id" : 1945584020
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 33, 47 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527137993363320832",
  "geo" : { },
  "id_str" : "527138336922951680",
  "in_reply_to_user_id" : 1945604605,
  "text" : "@AlisonBreadHive @EmilyBreadHive @coworkbuffalo we do have a pretty large basement. Not much on ventilation though.",
  "id" : 527138336922951680,
  "in_reply_to_status_id" : 527137993363320832,
  "created_at" : "2014-10-28 16:42:27 +0000",
  "in_reply_to_screen_name" : "AlisonBreadHive",
  "in_reply_to_user_id_str" : "1945604605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/b6TGAEfo8L",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/10\/29\/opinion\/anita-sarkeesian-on-video-games-great-future.html?_r=2",
      "display_url" : "nytimes.com\/2014\/10\/29\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527134844208578560",
  "text" : "Good bye, and good riddance, \"gamers\" - http:\/\/t.co\/b6TGAEfo8L",
  "id" : 527134844208578560,
  "created_at" : "2014-10-28 16:28:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "emptywheel",
      "screen_name" : "emptywheel",
      "indices" : [ 3, 14 ],
      "id_str" : "15985111",
      "id" : 15985111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Cwn2lOCnkT",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/europe\/pope-francis-declares-evolution-and-big-bang-theory-are-right-and-god-isnt-a-magician-with-a-magic-wand-9822514.html",
      "display_url" : "independent.co.uk\/news\/world\/eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527119239975817219",
  "text" : "RT @emptywheel: Infallible Pope endorses evolution.\nhttp:\/\/t.co\/Cwn2lOCnkT\nHe really is Jesuit plot to ruin perfectly good reactionary inst\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/Cwn2lOCnkT",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/europe\/pope-francis-declares-evolution-and-big-bang-theory-are-right-and-god-isnt-a-magician-with-a-magic-wand-9822514.html",
        "display_url" : "independent.co.uk\/news\/world\/eur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527073805077082112",
    "text" : "Infallible Pope endorses evolution.\nhttp:\/\/t.co\/Cwn2lOCnkT\nHe really is Jesuit plot to ruin perfectly good reactionary institution, isn't he",
    "id" : 527073805077082112,
    "created_at" : "2014-10-28 12:26:02 +0000",
    "user" : {
      "name" : "emptywheel",
      "screen_name" : "emptywheel",
      "protected" : false,
      "id_str" : "15985111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1773870183\/image1327265832_normal.png",
      "id" : 15985111,
      "verified" : false
    }
  },
  "id" : 527119239975817219,
  "created_at" : "2014-10-28 15:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527113995183214593",
  "geo" : { },
  "id_str" : "527114423031169026",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos definitely",
  "id" : 527114423031169026,
  "in_reply_to_status_id" : 527113995183214593,
  "created_at" : "2014-10-28 15:07:26 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily BreadHive",
      "screen_name" : "EmilyBreadHive",
      "indices" : [ 0, 15 ],
      "id_str" : "1945584020",
      "id" : 1945584020
    }, {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 16, 32 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 58, 72 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527113756447625217",
  "geo" : { },
  "id_str" : "527114049159303168",
  "in_reply_to_user_id" : 1945584020,
  "text" : "@EmilyBreadHive @AlisonBreadHive well, we do have windows @coworkbuffalo",
  "id" : 527114049159303168,
  "in_reply_to_status_id" : 527113756447625217,
  "created_at" : "2014-10-28 15:05:57 +0000",
  "in_reply_to_screen_name" : "EmilyBreadHive",
  "in_reply_to_user_id_str" : "1945584020",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527113844070424576",
  "text" : "Yosemite feels much more \"Mac\" than any Mac I've used since original iMac\/Apple II.",
  "id" : 527113844070424576,
  "created_at" : "2014-10-28 15:05:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527076443797618688",
  "geo" : { },
  "id_str" : "527076688534839296",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I\u2019ve been wondering what is worse: safe act yard signs or confederate flags in your window\/displayed anywhere on property",
  "id" : 527076688534839296,
  "in_reply_to_status_id" : 527076443797618688,
  "created_at" : "2014-10-28 12:37:29 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 3, 15 ],
      "id_str" : "158098704",
      "id" : 158098704
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffaloForReal",
      "indices" : [ 88, 103 ]
    }, {
      "text" : "woopwoop",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "faygo",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527068022180032512",
  "text" : "RT @mikemikemac: ICP meetup in front of @coworkbuffalo for the Twizdit concert tonight. #BuffaloForReal #woopwoop #faygo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 23, 37 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffaloForReal",
        "indices" : [ 71, 86 ]
      }, {
        "text" : "woopwoop",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "faygo",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526831766875557889",
    "text" : "ICP meetup in front of @coworkbuffalo for the Twizdit concert tonight. #BuffaloForReal #woopwoop #faygo",
    "id" : 526831766875557889,
    "created_at" : "2014-10-27 20:24:15 +0000",
    "user" : {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "protected" : false,
      "id_str" : "158098704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1797045056\/mikemac_normal.png",
      "id" : 158098704,
      "verified" : false
    }
  },
  "id" : 527068022180032512,
  "created_at" : "2014-10-28 12:03:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rohorzka",
      "screen_name" : "paulroho",
      "indices" : [ 0, 9 ],
      "id_str" : "848310080",
      "id" : 848310080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527035679575146496",
  "geo" : { },
  "id_str" : "527065378443120640",
  "in_reply_to_user_id" : 848310080,
  "text" : "@paulroho woo! Glad it\u2019s still so helpful after all these years",
  "id" : 527065378443120640,
  "in_reply_to_status_id" : 527035679575146496,
  "created_at" : "2014-10-28 11:52:33 +0000",
  "in_reply_to_screen_name" : "paulroho",
  "in_reply_to_user_id_str" : "848310080",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sLCWeabIPW",
      "expanded_url" : "http:\/\/walfredo.com\/",
      "display_url" : "walfredo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "526938850447212544",
  "text" : "Phish bootleg on a Monday, and their opener paid tribute to a fan who passed away. His site, a throwback in itself - http:\/\/t.co\/sLCWeabIPW",
  "id" : 526938850447212544,
  "created_at" : "2014-10-28 03:29:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/24uwA8GmXO",
      "expanded_url" : "http:\/\/buffalo.craigslist.org\/grd\/4709892912.html",
      "display_url" : "buffalo.craigslist.org\/grd\/4709892912\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526934962751033344",
  "text" : "Yeah, I guess if I ever had a TJ Maxx sign in my backyard I'd want to get rid of it too. http:\/\/t.co\/24uwA8GmXO",
  "id" : 526934962751033344,
  "created_at" : "2014-10-28 03:14:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526931062354505728",
  "geo" : { },
  "id_str" : "526932891561762816",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam i think the word you're looking for is \"good taste\"",
  "id" : 526932891561762816,
  "in_reply_to_status_id" : 526931062354505728,
  "created_at" : "2014-10-28 03:06:05 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526899748809093120",
  "text" : "RT @themcgruff: \"One sad result when we try to do everything ourselves is we overlook the talents of others.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526891836884152320",
    "text" : "\"One sad result when we try to do everything ourselves is we overlook the talents of others.\"",
    "id" : 526891836884152320,
    "created_at" : "2014-10-28 00:22:57 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 526899748809093120,
  "created_at" : "2014-10-28 00:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I Am Devloper",
      "screen_name" : "iamdevloper",
      "indices" : [ 3, 15 ],
      "id_str" : "564919357",
      "id" : 564919357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526893235038617601",
  "text" : "RT @iamdevloper: 'bundle install'\n\n* 5 minutes pass *\n\n\"Thank you for your request, a Ruby representative will be in touch with you in 24-4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526875864597004289",
    "text" : "'bundle install'\n\n* 5 minutes pass *\n\n\"Thank you for your request, a Ruby representative will be in touch with you in 24-48 hours.\"",
    "id" : 526875864597004289,
    "created_at" : "2014-10-27 23:19:29 +0000",
    "user" : {
      "name" : "I Am Devloper",
      "screen_name" : "iamdevloper",
      "protected" : false,
      "id_str" : "564919357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477397164453527552\/uh2w1u1o_normal.jpeg",
      "id" : 564919357,
      "verified" : false
    }
  },
  "id" : 526893235038617601,
  "created_at" : "2014-10-28 00:28:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526863540301602816",
  "geo" : { },
  "id_str" : "526874483630419968",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents zero :(",
  "id" : 526874483630419968,
  "in_reply_to_status_id" : 526863540301602816,
  "created_at" : "2014-10-27 23:14:00 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 0, 10 ],
      "id_str" : "25103",
      "id" : 25103
    }, {
      "name" : "tobinharris",
      "screen_name" : "tobinharris",
      "indices" : [ 11, 23 ],
      "id_str" : "14184621",
      "id" : 14184621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526836121196838912",
  "geo" : { },
  "id_str" : "526836220899647488",
  "in_reply_to_user_id" : 25103,
  "text" : "@jessitron @tobinharris do you think it's any easier there for testing? and yes, any\/all laughter is deserved.",
  "id" : 526836220899647488,
  "in_reply_to_status_id" : 526836121196838912,
  "created_at" : "2014-10-27 20:41:57 +0000",
  "in_reply_to_screen_name" : "jessitron",
  "in_reply_to_user_id_str" : "25103",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tobinharris",
      "screen_name" : "tobinharris",
      "indices" : [ 3, 15 ],
      "id_str" : "14184621",
      "id" : 14184621
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tobinharris\/status\/526835483805241344\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/j1Fjwa5CbN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0-yFJwIYAI35vf.png",
      "id_str" : "526835483012521986",
      "id" : 526835483012521986,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0-yFJwIYAI35vf.png",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 178
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 178
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 178
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 178
      } ],
      "display_url" : "pic.twitter.com\/j1Fjwa5CbN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526835885468557312",
  "text" : "RT @tobinharris: This is one reason why testing iOS apps is getting more expensive http:\/\/t.co\/j1Fjwa5CbN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tobinharris\/status\/526835483805241344\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/j1Fjwa5CbN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0-yFJwIYAI35vf.png",
        "id_str" : "526835483012521986",
        "id" : 526835483012521986,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0-yFJwIYAI35vf.png",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 178
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 178
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 178
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 178
        } ],
        "display_url" : "pic.twitter.com\/j1Fjwa5CbN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526835483805241344",
    "text" : "This is one reason why testing iOS apps is getting more expensive http:\/\/t.co\/j1Fjwa5CbN",
    "id" : 526835483805241344,
    "created_at" : "2014-10-27 20:39:02 +0000",
    "user" : {
      "name" : "tobinharris",
      "screen_name" : "tobinharris",
      "protected" : false,
      "id_str" : "14184621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000811936339\/64a291435ad7561da23d114a86ccb451_normal.jpeg",
      "id" : 14184621,
      "verified" : false
    }
  },
  "id" : 526835885468557312,
  "created_at" : "2014-10-27 20:40:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 15, 25 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526798979636264960",
  "geo" : { },
  "id_str" : "526799108246614016",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden cc @aquaranto",
  "id" : 526799108246614016,
  "in_reply_to_status_id" : 526798979636264960,
  "created_at" : "2014-10-27 18:14:29 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Street Studio",
      "screen_name" : "AnnStreetStudio",
      "indices" : [ 0, 16 ],
      "id_str" : "25283065",
      "id" : 25283065
    }, {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 17, 27 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526775276110626817",
  "geo" : { },
  "id_str" : "526776106662518787",
  "in_reply_to_user_id" : 25283065,
  "text" : "@AnnStreetStudio @kevinburg i think it's \"Dutchess\" county",
  "id" : 526776106662518787,
  "in_reply_to_status_id" : 526775276110626817,
  "created_at" : "2014-10-27 16:43:05 +0000",
  "in_reply_to_screen_name" : "AnnStreetStudio",
  "in_reply_to_user_id_str" : "25283065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Julian Cheal",
      "screen_name" : "juliancheal",
      "indices" : [ 30, 42 ],
      "id_str" : "951511",
      "id" : 951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qXwsdFaWWU",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/4660-nickelcityruby2014-dancing-with-robots",
      "display_url" : "confreaks.com\/videos\/4660-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526774760592932865",
  "text" : "Another from @nickelcityruby, @juliancheal dances to Gangham Style with a quadcopter in this one and kills it -  http:\/\/t.co\/qXwsdFaWWU",
  "id" : 526774760592932865,
  "created_at" : "2014-10-27 16:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526773674586947584",
  "geo" : { },
  "id_str" : "526773893978419200",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine I just took a bucket of wings to Chicago last week.",
  "id" : 526773893978419200,
  "in_reply_to_status_id" : 526773674586947584,
  "created_at" : "2014-10-27 16:34:17 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 32, 42 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/MnUgLNt7QQ",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3792-basecamp-meetup-october-2014",
      "display_url" : "signalvnoise.com\/posts\/3792-bas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526764185091584000",
  "text" : "Awesome little timelapse of our @37signals meetup last week - https:\/\/t.co\/MnUgLNt7QQ",
  "id" : 526764185091584000,
  "created_at" : "2014-10-27 15:55:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ghouls, buddy!",
      "screen_name" : "AaronM",
      "indices" : [ 0, 7 ],
      "id_str" : "9194742",
      "id" : 9194742
    }, {
      "name" : "Aanand Prasad",
      "screen_name" : "aanand",
      "indices" : [ 8, 15 ],
      "id_str" : "14149919",
      "id" : 14149919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526757320223494144",
  "geo" : { },
  "id_str" : "526758153153945600",
  "in_reply_to_user_id" : 9194742,
  "text" : "@AaronM @aanand wat??",
  "id" : 526758153153945600,
  "in_reply_to_status_id" : 526757320223494144,
  "created_at" : "2014-10-27 15:31:45 +0000",
  "in_reply_to_screen_name" : "AaronM",
  "in_reply_to_user_id_str" : "9194742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 3, 13 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 47, 59 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/a1MMcZVoTj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gRuhavOpFVg",
      "display_url" : "youtube.com\/watch?v=gRuhav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526757114010943489",
  "text" : "RT @chumprock: Apparently you can re-watch the @AqueousBand stream from Saturday night:  https:\/\/t.co\/a1MMcZVoTj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 32, 44 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/a1MMcZVoTj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gRuhavOpFVg",
        "display_url" : "youtube.com\/watch?v=gRuhav\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526743215945179137",
    "text" : "Apparently you can re-watch the @AqueousBand stream from Saturday night:  https:\/\/t.co\/a1MMcZVoTj",
    "id" : 526743215945179137,
    "created_at" : "2014-10-27 14:32:23 +0000",
    "user" : {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "protected" : true,
      "id_str" : "2850371250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561217552286629888\/VitUuRpa_normal.png",
      "id" : 2850371250,
      "verified" : false
    }
  },
  "id" : 526757114010943489,
  "created_at" : "2014-10-27 15:27:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/TxukwBvMCr",
      "expanded_url" : "http:\/\/www.theskimm.com\/?r=4EEAR",
      "display_url" : "theskimm.com\/?r=4EEAR"
    } ]
  },
  "geo" : { },
  "id_str" : "526755346564800513",
  "text" : "Signed up for theSkimm the other week and I've read every single one end to end. Worth it: http:\/\/t.co\/TxukwBvMCr",
  "id" : 526755346564800513,
  "created_at" : "2014-10-27 15:20:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Caleb Thompson",
      "screen_name" : "calebthompson",
      "indices" : [ 15, 29 ],
      "id_str" : "290866979",
      "id" : 290866979
    }, {
      "name" : "Tim Tyrrell",
      "screen_name" : "timtyrrell",
      "indices" : [ 30, 41 ],
      "id_str" : "15012484",
      "id" : 15012484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526727323962179586",
  "geo" : { },
  "id_str" : "526732368640364545",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @calebthompson @timtyrrell I would give a talk about this",
  "id" : 526732368640364545,
  "in_reply_to_status_id" : 526727323962179586,
  "created_at" : "2014-10-27 13:49:17 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hunt",
      "screen_name" : "chrishunt",
      "indices" : [ 3, 13 ],
      "id_str" : "14851597",
      "id" : 14851597
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 91, 96 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 100, 115 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sYKf5kEmfS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=rOE9ydzHQ88",
      "display_url" : "youtube.com\/watch?v=rOE9yd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526720055849910272",
  "text" : "RT @chrishunt: I agree with everything in this video - \u201CYou should take a codecation\u201D - by @r00k at @nickelcityruby. http:\/\/t.co\/sYKf5kEmfS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Orenstein",
        "screen_name" : "r00k",
        "indices" : [ 76, 81 ],
        "id_str" : "11280212",
        "id" : 11280212
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 85, 100 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/sYKf5kEmfS",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=rOE9ydzHQ88",
        "display_url" : "youtube.com\/watch?v=rOE9yd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526363941731979265",
    "text" : "I agree with everything in this video - \u201CYou should take a codecation\u201D - by @r00k at @nickelcityruby. http:\/\/t.co\/sYKf5kEmfS",
    "id" : 526363941731979265,
    "created_at" : "2014-10-26 13:25:17 +0000",
    "user" : {
      "name" : "Chris Hunt",
      "screen_name" : "chrishunt",
      "protected" : false,
      "id_str" : "14851597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560457831929769984\/iTPEFX3C_normal.jpeg",
      "id" : 14851597,
      "verified" : false
    }
  },
  "id" : 526720055849910272,
  "created_at" : "2014-10-27 13:00:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 3, 17 ],
      "id_str" : "369585978",
      "id" : 369585978
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 32, 47 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 61, 71 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/BvUFloKi1z",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/4657-nickelcityruby2014-learning-from-failure",
      "display_url" : "confreaks.com\/videos\/4657-ni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526720044005195776",
  "text" : "RT @meaganewaller: my talk from @nickelcityruby is up now on @confreaks check it out! http:\/\/t.co\/BvUFloKi1z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Confreaks, LLC",
        "screen_name" : "confreaks",
        "indices" : [ 42, 52 ],
        "id_str" : "14182110",
        "id" : 14182110
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/BvUFloKi1z",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/4657-nickelcityruby2014-learning-from-failure",
        "display_url" : "confreaks.com\/videos\/4657-ni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "525782587005218816",
    "text" : "my talk from @nickelcityruby is up now on @confreaks check it out! http:\/\/t.co\/BvUFloKi1z",
    "id" : 525782587005218816,
    "created_at" : "2014-10-24 22:55:12 +0000",
    "user" : {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "protected" : false,
      "id_str" : "369585978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559117803043950592\/Dxshutmf_normal.jpeg",
      "id" : 369585978,
      "verified" : false
    }
  },
  "id" : 526720044005195776,
  "created_at" : "2014-10-27 13:00:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526551520129863680",
  "geo" : { },
  "id_str" : "526552451235586048",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler it\u2019s not an jerk thing to ask for help. It\u2019s worse to ignore and not care.",
  "id" : 526552451235586048,
  "in_reply_to_status_id" : 526551520129863680,
  "created_at" : "2014-10-27 01:54:21 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526552133248618497",
  "geo" : { },
  "id_str" : "526552262257037313",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat wow! Safe travels \uD83D\uDE01",
  "id" : 526552262257037313,
  "in_reply_to_status_id" : 526552133248618497,
  "created_at" : "2014-10-27 01:53:36 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521802050469101571",
  "geo" : { },
  "id_str" : "526545320788770817",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw alright I\u2019ll bite finally, haven\u2019t thought of a good one yet",
  "id" : 526545320788770817,
  "in_reply_to_status_id" : 521802050469101571,
  "created_at" : "2014-10-27 01:26:01 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoo boy, its vrunt! ",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 15, 23 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526533269144469504",
  "geo" : { },
  "id_str" : "526543146440609792",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt I heard @dmansen is good",
  "id" : 526543146440609792,
  "in_reply_to_status_id" : 526533269144469504,
  "created_at" : "2014-10-27 01:17:23 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 0, 8 ],
      "id_str" : "15048829",
      "id" : 15048829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526526700629139456",
  "geo" : { },
  "id_str" : "526528315973058560",
  "in_reply_to_user_id" : 15048829,
  "text" : "@greggyb one out of 5 S's",
  "id" : 526528315973058560,
  "in_reply_to_status_id" : 526526700629139456,
  "created_at" : "2014-10-27 00:18:27 +0000",
  "in_reply_to_screen_name" : "greggyb",
  "in_reply_to_user_id_str" : "15048829",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526524237113090049",
  "text" : "Nintendo has been doing a lot of \"pre-order\" DLC. That kind of thing would never fly on iOS (or anywhere else)",
  "id" : 526524237113090049,
  "created_at" : "2014-10-27 00:02:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Buffalo Iron Works",
      "screen_name" : "IronWorksBflo",
      "indices" : [ 36, 50 ],
      "id_str" : "1671288846",
      "id" : 1671288846
    }, {
      "name" : "The Mantras",
      "screen_name" : "TheMantras",
      "indices" : [ 51, 62 ],
      "id_str" : "59912154",
      "id" : 59912154
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/526488931064639488\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/xqRJQTMfvB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0525G0IYAA0BC9.jpg",
      "id_str" : "526488929902813184",
      "id" : 526488929902813184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0525G0IYAA0BC9.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 552
      } ],
      "display_url" : "pic.twitter.com\/xqRJQTMfvB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526494723045736448",
  "text" : "RT @AqueousBand: Thank you BUFFALO! @IronWorksBflo @TheMantras http:\/\/t.co\/xqRJQTMfvB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Iron Works",
        "screen_name" : "IronWorksBflo",
        "indices" : [ 19, 33 ],
        "id_str" : "1671288846",
        "id" : 1671288846
      }, {
        "name" : "The Mantras",
        "screen_name" : "TheMantras",
        "indices" : [ 34, 45 ],
        "id_str" : "59912154",
        "id" : 59912154
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AqueousBand\/status\/526488931064639488\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/xqRJQTMfvB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0525G0IYAA0BC9.jpg",
        "id_str" : "526488929902813184",
        "id" : 526488929902813184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0525G0IYAA0BC9.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 552
        } ],
        "display_url" : "pic.twitter.com\/xqRJQTMfvB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526488931064639488",
    "text" : "Thank you BUFFALO! @IronWorksBflo @TheMantras http:\/\/t.co\/xqRJQTMfvB",
    "id" : 526488931064639488,
    "created_at" : "2014-10-26 21:41:57 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 526494723045736448,
  "created_at" : "2014-10-26 22:04:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526473386998775808",
  "text" : "Hey cool it took one GamerGate tweet to get a random twitter account started this month to bring up Nazis to me",
  "id" : 526473386998775808,
  "created_at" : "2014-10-26 20:40:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 6, 13 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526450684838047744",
  "geo" : { },
  "id_str" : "526451070222888961",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k @cpytel the real friction is Swift is this - interacting with Cocoa. I have a feeling more Swift APIs will be coming soon.",
  "id" : 526451070222888961,
  "in_reply_to_status_id" : 526450684838047744,
  "created_at" : "2014-10-26 19:11:30 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526447356988751875",
  "geo" : { },
  "id_str" : "526448249859620864",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine It's dangerous to go alone!",
  "id" : 526448249859620864,
  "in_reply_to_status_id" : 526447356988751875,
  "created_at" : "2014-10-26 19:00:18 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/1gHLwgFDph",
      "expanded_url" : "http:\/\/www.doctornerdlove.com\/2014\/10\/when-we-talk-about-gamergate\/",
      "display_url" : "doctornerdlove.com\/2014\/10\/when-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526377800844853249",
  "text" : "\u201CGamerGate is poison, from root to fruit.\u201D http:\/\/t.co\/1gHLwgFDph",
  "id" : 526377800844853249,
  "created_at" : "2014-10-26 14:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristoffer Mikkeljon",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526284140652810240",
  "geo" : { },
  "id_str" : "526341592236302336",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik every band that plays there signs the ceiling. Sadly their sig is blocked by some new vent ducts that were installed since then",
  "id" : 526341592236302336,
  "in_reply_to_status_id" : 526284140652810240,
  "created_at" : "2014-10-26 11:56:29 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/blGdKgQ0F7",
      "expanded_url" : "http:\/\/youtu.be\/gRuhavOpFVg",
      "display_url" : "youtu.be\/gRuhavOpFVg"
    } ]
  },
  "geo" : { },
  "id_str" : "526217069772406784",
  "text" : "Live stream here is up! Or should be. http:\/\/t.co\/blGdKgQ0F7",
  "id" : 526217069772406784,
  "created_at" : "2014-10-26 03:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Iron Works",
      "screen_name" : "IronWorksBflo",
      "indices" : [ 25, 39 ],
      "id_str" : "1671288846",
      "id" : 1671288846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/jsYjtlnBoz",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/3JQMUkzjBTk",
      "display_url" : "swarmapp.com\/c\/3JQMUkzjBTk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8746949223, -78.8746912989 ]
  },
  "id_str" : "526214831612108800",
  "text" : "Aqueous time. (@ Buffalo @IronWorksBflo for The Mantras and Aqueous in Buffalo, NY) https:\/\/t.co\/jsYjtlnBoz",
  "id" : 526214831612108800,
  "created_at" : "2014-10-26 03:32:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Iron Works",
      "screen_name" : "IronWorksBflo",
      "indices" : [ 25, 39 ],
      "id_str" : "1671288846",
      "id" : 1671288846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AF3NwX1Mnh",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/hzQ1pVslIxW",
      "display_url" : "swarmapp.com\/c\/hzQ1pVslIxW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8746949223, -78.8746912989 ]
  },
  "id_str" : "526209472843493377",
  "text" : "Aqueous time. (@ Buffalo @IronWorksBflo for The Mantras and Aqueous in Buffalo, NY) https:\/\/t.co\/AF3NwX1Mnh",
  "id" : 526209472843493377,
  "created_at" : "2014-10-26 03:11:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526193749098242048",
  "geo" : { },
  "id_str" : "526194914191626240",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer starting at 11 still? Headed down soon",
  "id" : 526194914191626240,
  "in_reply_to_status_id" : 526193749098242048,
  "created_at" : "2014-10-26 02:13:38 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Couch Tours",
      "screen_name" : "CouchTours",
      "indices" : [ 24, 35 ],
      "id_str" : "351630989",
      "id" : 351630989
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 38, 50 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "The Mantras",
      "screen_name" : "TheMantras",
      "indices" : [ 55, 66 ],
      "id_str" : "59912154",
      "id" : 59912154
    }, {
      "name" : "WNYmedia Network",
      "screen_name" : "wnymedia",
      "indices" : [ 89, 98 ],
      "id_str" : "9106882",
      "id" : 9106882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/vSo6eWCS7v",
      "expanded_url" : "http:\/\/youtu.be\/gRuhavOpFVg",
      "display_url" : "youtu.be\/gRuhavOpFVg"
    } ]
  },
  "geo" : { },
  "id_str" : "526155682202918912",
  "text" : "RT @UnclePhilsBlog: Hey @CouchTours , @AqueousBand and @TheMantras FREE HQ web cast from @wnymedia 9pm tonight. http:\/\/t.co\/vSo6eWCS7v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Couch Tours",
        "screen_name" : "CouchTours",
        "indices" : [ 4, 15 ],
        "id_str" : "351630989",
        "id" : 351630989
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 18, 30 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "The Mantras",
        "screen_name" : "TheMantras",
        "indices" : [ 35, 46 ],
        "id_str" : "59912154",
        "id" : 59912154
      }, {
        "name" : "WNYmedia Network",
        "screen_name" : "wnymedia",
        "indices" : [ 69, 78 ],
        "id_str" : "9106882",
        "id" : 9106882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/vSo6eWCS7v",
        "expanded_url" : "http:\/\/youtu.be\/gRuhavOpFVg",
        "display_url" : "youtu.be\/gRuhavOpFVg"
      } ]
    },
    "geo" : { },
    "id_str" : "526077907484295168",
    "text" : "Hey @CouchTours , @AqueousBand and @TheMantras FREE HQ web cast from @wnymedia 9pm tonight. http:\/\/t.co\/vSo6eWCS7v",
    "id" : 526077907484295168,
    "created_at" : "2014-10-25 18:28:41 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 526155682202918912,
  "created_at" : "2014-10-25 23:37:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo.FM",
      "screen_name" : "Buffalo_FM",
      "indices" : [ 3, 14 ],
      "id_str" : "2745781080",
      "id" : 2745781080
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 75, 87 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "The Mantras",
      "screen_name" : "TheMantras",
      "indices" : [ 93, 104 ],
      "id_str" : "59912154",
      "id" : 59912154
    }, {
      "name" : "Buffalo Iron Works",
      "screen_name" : "IronWorksBflo",
      "indices" : [ 115, 129 ],
      "id_str" : "1671288846",
      "id" : 1671288846
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Buffalo_FM\/status\/526148754341392384\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dsJvvV32sd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B01BgCNIYAAcF6N.jpg",
      "id_str" : "526148750075781120",
      "id" : 526148750075781120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B01BgCNIYAAcF6N.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/dsJvvV32sd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526155625986658304",
  "text" : "RT @Buffalo_FM: Sound checked stream tested and ready to roll! Join us for @AqueousBand with @TheMantras live from @IronWorksBflo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 59, 71 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "The Mantras",
        "screen_name" : "TheMantras",
        "indices" : [ 77, 88 ],
        "id_str" : "59912154",
        "id" : 59912154
      }, {
        "name" : "Buffalo Iron Works",
        "screen_name" : "IronWorksBflo",
        "indices" : [ 99, 113 ],
        "id_str" : "1671288846",
        "id" : 1671288846
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Buffalo_FM\/status\/526148754341392384\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/dsJvvV32sd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B01BgCNIYAAcF6N.jpg",
        "id_str" : "526148750075781120",
        "id" : 526148750075781120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B01BgCNIYAAcF6N.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/dsJvvV32sd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526148754341392384",
    "text" : "Sound checked stream tested and ready to roll! Join us for @AqueousBand with @TheMantras live from @IronWorksBflo http:\/\/t.co\/dsJvvV32sd",
    "id" : 526148754341392384,
    "created_at" : "2014-10-25 23:10:13 +0000",
    "user" : {
      "name" : "Buffalo.FM",
      "screen_name" : "Buffalo_FM",
      "protected" : false,
      "id_str" : "2745781080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501802944916750336\/rxlGb5pU_normal.png",
      "id" : 2745781080,
      "verified" : false
    }
  },
  "id" : 526155625986658304,
  "created_at" : "2014-10-25 23:37:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "Philip",
      "screen_name" : "parndt",
      "indices" : [ 8, 15 ],
      "id_str" : "15346781",
      "id" : 15346781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526085309407457282",
  "geo" : { },
  "id_str" : "526100646089342976",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh @parndt just got a backyard for the first time in almost 3 years of dog ownership and it\u2019s made us a lot more lazy",
  "id" : 526100646089342976,
  "in_reply_to_status_id" : 526085309407457282,
  "created_at" : "2014-10-25 19:59:03 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark S. Luckie \u2591\u2592",
      "screen_name" : "marksluckie",
      "indices" : [ 3, 15 ],
      "id_str" : "27261369",
      "id" : 27261369
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marksluckie\/status\/526020925842812928\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/yxbHcPmmqq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0zNOqjCcAAIlKi.jpg",
      "id_str" : "526020908318617600",
      "id" : 526020908318617600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0zNOqjCcAAIlKi.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yxbHcPmmqq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526033123109113857",
  "text" : "RT @marksluckie: Scary. http:\/\/t.co\/yxbHcPmmqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marksluckie\/status\/526020925842812928\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/yxbHcPmmqq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0zNOqjCcAAIlKi.jpg",
        "id_str" : "526020908318617600",
        "id" : 526020908318617600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0zNOqjCcAAIlKi.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 613
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 613
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/yxbHcPmmqq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526020925842812928",
    "text" : "Scary. http:\/\/t.co\/yxbHcPmmqq",
    "id" : 526020925842812928,
    "created_at" : "2014-10-25 14:42:16 +0000",
    "user" : {
      "name" : "Mark S. Luckie \u2591\u2592",
      "screen_name" : "marksluckie",
      "protected" : false,
      "id_str" : "27261369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565962099940012032\/cIFnfF4j_normal.png",
      "id" : 27261369,
      "verified" : false
    }
  },
  "id" : 526033123109113857,
  "created_at" : "2014-10-25 15:30:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 0, 15 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526031336310857728",
  "geo" : { },
  "id_str" : "526032827289059328",
  "in_reply_to_user_id" : 1472209542,
  "text" : "@PublicEspresso You can just say you\u2019re going to IKEA. No shame.",
  "id" : 526032827289059328,
  "in_reply_to_status_id" : 526031336310857728,
  "created_at" : "2014-10-25 15:29:33 +0000",
  "in_reply_to_screen_name" : "PublicEspresso",
  "in_reply_to_user_id_str" : "1472209542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525855020374188032",
  "geo" : { },
  "id_str" : "525855643849072640",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN horrifying",
  "id" : 525855643849072640,
  "in_reply_to_status_id" : 525855020374188032,
  "created_at" : "2014-10-25 03:45:30 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gordon",
      "screen_name" : "mike_gordon",
      "indices" : [ 3, 15 ],
      "id_str" : "15641394",
      "id" : 15641394
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mike_gordon\/status\/525832019670876160\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/5FvgIAQ4Qj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0wha53CIAEHEbm.jpg",
      "id_str" : "525832002587467777",
      "id" : 525832002587467777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0wha53CIAEHEbm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5FvgIAQ4Qj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/7zIcxjzyFV",
      "expanded_url" : "http:\/\/instagram.com\/p\/ujuUt3varh\/",
      "display_url" : "instagram.com\/p\/ujuUt3varh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525842246881402880",
  "text" : "RT @mike_gordon: Moves like jagger http:\/\/t.co\/7zIcxjzyFV http:\/\/t.co\/5FvgIAQ4Qj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mike_gordon\/status\/525832019670876160\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/5FvgIAQ4Qj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0wha53CIAEHEbm.jpg",
        "id_str" : "525832002587467777",
        "id" : 525832002587467777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0wha53CIAEHEbm.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5FvgIAQ4Qj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/7zIcxjzyFV",
        "expanded_url" : "http:\/\/instagram.com\/p\/ujuUt3varh\/",
        "display_url" : "instagram.com\/p\/ujuUt3varh\/"
      } ]
    },
    "geo" : { },
    "id_str" : "525832019670876160",
    "text" : "Moves like jagger http:\/\/t.co\/7zIcxjzyFV http:\/\/t.co\/5FvgIAQ4Qj",
    "id" : 525832019670876160,
    "created_at" : "2014-10-25 02:11:37 +0000",
    "user" : {
      "name" : "Mike Gordon",
      "screen_name" : "mike_gordon",
      "protected" : false,
      "id_str" : "15641394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558327920549056512\/A_Ea4p_e_normal.jpeg",
      "id" : 15641394,
      "verified" : true
    }
  },
  "id" : 525842246881402880,
  "created_at" : "2014-10-25 02:52:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525838898061008897",
  "geo" : { },
  "id_str" : "525841298607992832",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @kevinpurdy my world will never be the same",
  "id" : 525841298607992832,
  "in_reply_to_status_id" : 525838898061008897,
  "created_at" : "2014-10-25 02:48:29 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 14, 27 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525840617704665088",
  "geo" : { },
  "id_str" : "525841232950349824",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester @antelopeezer definitely not, but sounds good",
  "id" : 525841232950349824,
  "in_reply_to_status_id" : 525840617704665088,
  "created_at" : "2014-10-25 02:48:14 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarr\u2B55\uFE0Fd Krieger",
      "screen_name" : "Jmkrochester",
      "indices" : [ 0, 13 ],
      "id_str" : "121941652",
      "id" : 121941652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525833639473315841",
  "geo" : { },
  "id_str" : "525836629177417728",
  "in_reply_to_user_id" : 121941652,
  "text" : "@Jmkrochester coming to Buffalo tomorrow?",
  "id" : 525836629177417728,
  "in_reply_to_status_id" : 525833639473315841,
  "created_at" : "2014-10-25 02:29:56 +0000",
  "in_reply_to_screen_name" : "Jmkrochester",
  "in_reply_to_user_id_str" : "121941652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 88, 94 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525836423148998656",
  "text" : "RT @kevinpurdy: Which is the \"more Chicago\" film: Wayne's World or Blues Brothers? (per @qrush disagreement)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 72, 78 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525835759022923776",
    "text" : "Which is the \"more Chicago\" film: Wayne's World or Blues Brothers? (per @qrush disagreement)",
    "id" : 525835759022923776,
    "created_at" : "2014-10-25 02:26:29 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 525836423148998656,
  "created_at" : "2014-10-25 02:29:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 3, 13 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Phish_FTR\/status\/525782130643972098\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/RXiO64rpEY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0v0CnjCAAAwc5s.jpg",
      "id_str" : "525782107331624960",
      "id" : 525782107331624960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0v0CnjCAAAwc5s.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/RXiO64rpEY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/JDXSZkbutp",
      "expanded_url" : "http:\/\/instagram.com\/p\/ujXwQbNL7y\/",
      "display_url" : "instagram.com\/p\/ujXwQbNL7y\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525784553743347712",
  "text" : "RT @Phish_FTR: Trey takes The Forum for a test drive alone http:\/\/t.co\/JDXSZkbutp http:\/\/t.co\/RXiO64rpEY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Phish_FTR\/status\/525782130643972098\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/RXiO64rpEY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0v0CnjCAAAwc5s.jpg",
        "id_str" : "525782107331624960",
        "id" : 525782107331624960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0v0CnjCAAAwc5s.jpg",
        "sizes" : [ {
          "h" : 364,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/RXiO64rpEY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/JDXSZkbutp",
        "expanded_url" : "http:\/\/instagram.com\/p\/ujXwQbNL7y\/",
        "display_url" : "instagram.com\/p\/ujXwQbNL7y\/"
      } ]
    },
    "geo" : { },
    "id_str" : "525782130643972098",
    "text" : "Trey takes The Forum for a test drive alone http:\/\/t.co\/JDXSZkbutp http:\/\/t.co\/RXiO64rpEY",
    "id" : 525782130643972098,
    "created_at" : "2014-10-24 22:53:23 +0000",
    "user" : {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "protected" : false,
      "id_str" : "153850397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000065818163\/de7aca9d2eb0c2005f7df69ad86aafa4_normal.jpeg",
      "id" : 153850397,
      "verified" : false
    }
  },
  "id" : 525784553743347712,
  "created_at" : "2014-10-24 23:03:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525780308637917184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242894892, -78.8792217058 ]
  },
  "id_str" : "525780465802702848",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg words are hard",
  "id" : 525780465802702848,
  "in_reply_to_status_id" : 525780308637917184,
  "created_at" : "2014-10-24 22:46:46 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eileen M. Uchitelle",
      "screen_name" : "eileencodes",
      "indices" : [ 0, 12 ],
      "id_str" : "390287545",
      "id" : 390287545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525769397508784128",
  "geo" : { },
  "id_str" : "525770056471285760",
  "in_reply_to_user_id" : 390287545,
  "text" : "@eileencodes have you tried turning it off and back on again?",
  "id" : 525770056471285760,
  "in_reply_to_status_id" : 525769397508784128,
  "created_at" : "2014-10-24 22:05:24 +0000",
  "in_reply_to_screen_name" : "eileencodes",
  "in_reply_to_user_id_str" : "390287545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/MWJ3qli1QV",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3791-basecampy",
      "display_url" : "signalvnoise.com\/posts\/3791-bas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525763194254405634",
  "text" : "Basecampy is genderless and reproduces via binary fission. https:\/\/t.co\/MWJ3qli1QV",
  "id" : 525763194254405634,
  "created_at" : "2014-10-24 21:38:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "indices" : [ 3, 14 ],
      "id_str" : "33743565",
      "id" : 33743565
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 30, 34 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Keep Ruby Weird",
      "screen_name" : "keeprubyweird",
      "indices" : [ 40, 54 ],
      "id_str" : "2568409631",
      "id" : 2568409631
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/scottefein\/status\/525724192897921024\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/cznJKgTbfF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0u_XRaCEAAW6Qn.jpg",
      "id_str" : "525724188049281024",
      "id" : 525724188049281024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0u_XRaCEAAW6Qn.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/cznJKgTbfF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525736630444126210",
  "text" : "RT @scottefein: Omg, they got @dhh too! @keeprubyweird http:\/\/t.co\/cznJKgTbfF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHH",
        "screen_name" : "dhh",
        "indices" : [ 14, 18 ],
        "id_str" : "14561327",
        "id" : 14561327
      }, {
        "name" : "Keep Ruby Weird",
        "screen_name" : "keeprubyweird",
        "indices" : [ 24, 38 ],
        "id_str" : "2568409631",
        "id" : 2568409631
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scottefein\/status\/525724192897921024\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/cznJKgTbfF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0u_XRaCEAAW6Qn.jpg",
        "id_str" : "525724188049281024",
        "id" : 525724188049281024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0u_XRaCEAAW6Qn.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/cznJKgTbfF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 30.2679636, -97.739239 ]
    },
    "id_str" : "525724192897921024",
    "text" : "Omg, they got @dhh too! @keeprubyweird http:\/\/t.co\/cznJKgTbfF",
    "id" : 525724192897921024,
    "created_at" : "2014-10-24 19:03:09 +0000",
    "user" : {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "protected" : false,
      "id_str" : "33743565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564951584535085056\/EZwSDHBZ_normal.jpeg",
      "id" : 33743565,
      "verified" : false
    }
  },
  "id" : 525736630444126210,
  "created_at" : "2014-10-24 19:52:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Hsieh",
      "screen_name" : "ankey",
      "indices" : [ 3, 9 ],
      "id_str" : "3092491",
      "id" : 3092491
    }, {
      "name" : "why the lucky stiff",
      "screen_name" : "_why",
      "indices" : [ 33, 38 ],
      "id_str" : "275198114",
      "id" : 275198114
    }, {
      "name" : "Keep Ruby Weird",
      "screen_name" : "keeprubyweird",
      "indices" : [ 61, 75 ],
      "id_str" : "2568409631",
      "id" : 2568409631
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ankey\/status\/525728370609651712\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9IGqRVY1vm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0vDKmhCEAEskBy.jpg",
      "id_str" : "525728368423997441",
      "id" : 525728368423997441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0vDKmhCEAEskBy.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/9IGqRVY1vm"
    } ],
    "hashtags" : [ {
      "text" : "hashtag",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525736502538809345",
  "text" : "RT @ankey: The puppet version of @_why made an appearance at @keeprubyweird #hashtag http:\/\/t.co\/9IGqRVY1vm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "why the lucky stiff",
        "screen_name" : "_why",
        "indices" : [ 22, 27 ],
        "id_str" : "275198114",
        "id" : 275198114
      }, {
        "name" : "Keep Ruby Weird",
        "screen_name" : "keeprubyweird",
        "indices" : [ 50, 64 ],
        "id_str" : "2568409631",
        "id" : 2568409631
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ankey\/status\/525728370609651712\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/9IGqRVY1vm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0vDKmhCEAEskBy.jpg",
        "id_str" : "525728368423997441",
        "id" : 525728368423997441,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0vDKmhCEAEskBy.jpg",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/9IGqRVY1vm"
      } ],
      "hashtags" : [ {
        "text" : "hashtag",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525728370609651712",
    "text" : "The puppet version of @_why made an appearance at @keeprubyweird #hashtag http:\/\/t.co\/9IGqRVY1vm",
    "id" : 525728370609651712,
    "created_at" : "2014-10-24 19:19:45 +0000",
    "user" : {
      "name" : "Annie Hsieh",
      "screen_name" : "ankey",
      "protected" : false,
      "id_str" : "3092491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3642895492\/e62f786d23d9fab566b7fe17ba925993_normal.jpeg",
      "id" : 3092491,
      "verified" : false
    }
  },
  "id" : 525736502538809345,
  "created_at" : "2014-10-24 19:52:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicholas mcdonnough",
      "screen_name" : "nickmcdonnough",
      "indices" : [ 3, 18 ],
      "id_str" : "31080726",
      "id" : 31080726
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 27, 38 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Keep Ruby Weird",
      "screen_name" : "keeprubyweird",
      "indices" : [ 39, 53 ],
      "id_str" : "2568409631",
      "id" : 2568409631
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickmcdonnough\/status\/525728973959876610\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/guDIpN6iAB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0vDtsoCUAAvcUK.jpg",
      "id_str" : "525728971359408128",
      "id" : 525728971359408128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0vDtsoCUAAvcUK.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/guDIpN6iAB"
    } ],
    "hashtags" : [ {
      "text" : "hashtag",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525736467268915200",
  "text" : "RT @nickmcdonnough: Puppet @jimweirich @keeprubyweird #hashtag http:\/\/t.co\/guDIpN6iAB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Weirich",
        "screen_name" : "jimweirich",
        "indices" : [ 7, 18 ],
        "id_str" : "9070452",
        "id" : 9070452
      }, {
        "name" : "Keep Ruby Weird",
        "screen_name" : "keeprubyweird",
        "indices" : [ 19, 33 ],
        "id_str" : "2568409631",
        "id" : 2568409631
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickmcdonnough\/status\/525728973959876610\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/guDIpN6iAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0vDtsoCUAAvcUK.jpg",
        "id_str" : "525728971359408128",
        "id" : 525728971359408128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0vDtsoCUAAvcUK.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/guDIpN6iAB"
      } ],
      "hashtags" : [ {
        "text" : "hashtag",
        "indices" : [ 34, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525728973959876610",
    "text" : "Puppet @jimweirich @keeprubyweird #hashtag http:\/\/t.co\/guDIpN6iAB",
    "id" : 525728973959876610,
    "created_at" : "2014-10-24 19:22:09 +0000",
    "user" : {
      "name" : "nicholas mcdonnough",
      "screen_name" : "nickmcdonnough",
      "protected" : false,
      "id_str" : "31080726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3573168849\/c5a0ed8fe2f2ba497c7826163ce786b9_normal.jpeg",
      "id" : 31080726,
      "verified" : false
    }
  },
  "id" : 525736467268915200,
  "created_at" : "2014-10-24 19:51:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 29, 35 ],
      "id_str" : "15265916",
      "id" : 15265916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ATLsShC5ZW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=CuKQ--FzGmk",
      "display_url" : "youtube.com\/watch?v=CuKQ--\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525718039858122752",
  "text" : "Some people give tech talks. @dabit throws down a DJ set instead and teaches you how it works. https:\/\/t.co\/ATLsShC5ZW",
  "id" : 525718039858122752,
  "created_at" : "2014-10-24 18:38:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eron Nicholson",
      "screen_name" : "VinzClortho",
      "indices" : [ 0, 12 ],
      "id_str" : "15759219",
      "id" : 15759219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525715462890741760",
  "geo" : { },
  "id_str" : "525715725025964032",
  "in_reply_to_user_id" : 15759219,
  "text" : "@VinzClortho FLAWLESS VICTORY",
  "id" : 525715725025964032,
  "in_reply_to_status_id" : 525715462890741760,
  "created_at" : "2014-10-24 18:29:30 +0000",
  "in_reply_to_screen_name" : "VinzClortho",
  "in_reply_to_user_id_str" : "15759219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525703941971902464",
  "geo" : { },
  "id_str" : "525704337855504384",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies yeah, they asked me if it was OK. Been fun so far.",
  "id" : 525704337855504384,
  "in_reply_to_status_id" : 525703941971902464,
  "created_at" : "2014-10-24 17:44:15 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525699027095269376",
  "geo" : { },
  "id_str" : "525700727839424512",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j No thanks",
  "id" : 525700727839424512,
  "in_reply_to_status_id" : 525699027095269376,
  "created_at" : "2014-10-24 17:29:55 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525698783158349824\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/2vr5hw3cHH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0uoQYTCQAI5Wpt.png",
      "id_str" : "525698780872458242",
      "id" : 525698780872458242,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0uoQYTCQAI5Wpt.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2vr5hw3cHH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525698783158349824",
  "text" : "desperation.jpg http:\/\/t.co\/2vr5hw3cHH",
  "id" : 525698783158349824,
  "created_at" : "2014-10-24 17:22:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thought Catalog",
      "screen_name" : "ThoughtCatalog",
      "indices" : [ 3, 18 ],
      "id_str" : "67719573",
      "id" : 67719573
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ThoughtCatalog\/status\/525681299772948481\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OJb16xT7i2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0uYW1oIQAEaGPc.jpg",
      "id_str" : "525681299638730753",
      "id" : 525681299638730753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0uYW1oIQAEaGPc.jpg",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 125,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OJb16xT7i2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/OZP3NIpttB",
      "expanded_url" : "http:\/\/tcat.tc\/1vZbKn5",
      "display_url" : "tcat.tc\/1vZbKn5"
    } ]
  },
  "geo" : { },
  "id_str" : "525698482053468160",
  "text" : "RT @ThoughtCatalog: My uncle sends me a box of trash every year for my birthday. Here's what I got this year: http:\/\/t.co\/OZP3NIpttB http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ThoughtCatalog\/status\/525681299772948481\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/OJb16xT7i2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0uYW1oIQAEaGPc.jpg",
        "id_str" : "525681299638730753",
        "id" : 525681299638730753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0uYW1oIQAEaGPc.jpg",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 786
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 786
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 125,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OJb16xT7i2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/OZP3NIpttB",
        "expanded_url" : "http:\/\/tcat.tc\/1vZbKn5",
        "display_url" : "tcat.tc\/1vZbKn5"
      } ]
    },
    "geo" : { },
    "id_str" : "525681299772948481",
    "text" : "My uncle sends me a box of trash every year for my birthday. Here's what I got this year: http:\/\/t.co\/OZP3NIpttB http:\/\/t.co\/OJb16xT7i2",
    "id" : 525681299772948481,
    "created_at" : "2014-10-24 16:12:43 +0000",
    "user" : {
      "name" : "Thought Catalog",
      "screen_name" : "ThoughtCatalog",
      "protected" : false,
      "id_str" : "67719573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2908067261\/8dfbb91f3096a8dc66f95b0679cc0b71_normal.jpeg",
      "id" : 67719573,
      "verified" : true
    }
  },
  "id" : 525698482053468160,
  "created_at" : "2014-10-24 17:20:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525693301039443969\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/bvdXbET04y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ujRP7CAAAq813.png",
      "id_str" : "525693298246025216",
      "id" : 525693298246025216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ujRP7CAAAq813.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bvdXbET04y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/emRBhg3UXs",
      "expanded_url" : "http:\/\/rooms.me\/t\/7GUF6iHTG5\/gifs\/bees-bombs-httpbeesandbombstumblrcompost94895417939dribbblepopularspherewavefollowmeo",
      "display_url" : "rooms.me\/t\/7GUF6iHTG5\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525693301039443969",
  "text" : "Hit 5,000 members on the GIFs room. Getting a little crazy. http:\/\/t.co\/emRBhg3UXs http:\/\/t.co\/bvdXbET04y",
  "id" : 525693301039443969,
  "created_at" : "2014-10-24 17:00:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ALlXt9vCB7",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/725",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525674484410224640",
  "text" : "Workflow for adopting someone else's gem (or putting one up for adoption) - https:\/\/t.co\/ALlXt9vCB7 Would you use this?",
  "id" : 525674484410224640,
  "created_at" : "2014-10-24 15:45:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison House",
      "screen_name" : "house",
      "indices" : [ 0, 6 ],
      "id_str" : "19130153",
      "id" : 19130153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525668997988372480",
  "geo" : { },
  "id_str" : "525669267966930944",
  "in_reply_to_user_id" : 19130153,
  "text" : "@house ah yeah, I\u2019m trying to keep the instructions for iOS only",
  "id" : 525669267966930944,
  "in_reply_to_status_id" : 525668997988372480,
  "created_at" : "2014-10-24 15:24:54 +0000",
  "in_reply_to_screen_name" : "house",
  "in_reply_to_user_id_str" : "19130153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison House",
      "screen_name" : "house",
      "indices" : [ 0, 6 ],
      "id_str" : "19130153",
      "id" : 19130153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525667785633173505",
  "geo" : { },
  "id_str" : "525668500979740672",
  "in_reply_to_user_id" : 19130153,
  "text" : "@house actually i can\u2019t find it via their interface- have a screenshot?",
  "id" : 525668500979740672,
  "in_reply_to_status_id" : 525667785633173505,
  "created_at" : "2014-10-24 15:21:51 +0000",
  "in_reply_to_screen_name" : "house",
  "in_reply_to_user_id_str" : "19130153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison House",
      "screen_name" : "house",
      "indices" : [ 0, 6 ],
      "id_str" : "19130153",
      "id" : 19130153
    }, {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 7, 23 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525667785633173505",
  "geo" : { },
  "id_str" : "525667974951100416",
  "in_reply_to_user_id" : 19130153,
  "text" : "@house @whentheponydies oh snap. I will amend the instructions!",
  "id" : 525667974951100416,
  "in_reply_to_status_id" : 525667785633173505,
  "created_at" : "2014-10-24 15:19:46 +0000",
  "in_reply_to_screen_name" : "house",
  "in_reply_to_user_id_str" : "19130153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525630041682493441",
  "geo" : { },
  "id_str" : "525647398488383488",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies Posted! Yeah 99% of the submissions have been awful",
  "id" : 525647398488383488,
  "in_reply_to_status_id" : 525630041682493441,
  "created_at" : "2014-10-24 13:58:00 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Rutledge",
      "screen_name" : "_",
      "indices" : [ 0, 2 ],
      "id_str" : "1318181",
      "id" : 1318181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525640198491631616",
  "geo" : { },
  "id_str" : "525644268400959488",
  "in_reply_to_user_id" : 1318181,
  "text" : "@_ I pronounce it both ways but I just like the trolling aspect of it",
  "id" : 525644268400959488,
  "in_reply_to_status_id" : 525640198491631616,
  "created_at" : "2014-10-24 13:45:34 +0000",
  "in_reply_to_screen_name" : "_",
  "in_reply_to_user_id_str" : "1318181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525629699767021569",
  "geo" : { },
  "id_str" : "525629841450610689",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies oh oops it\u2019s Video Downloader Free",
  "id" : 525629841450610689,
  "in_reply_to_status_id" : 525629699767021569,
  "created_at" : "2014-10-24 12:48:14 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525478573482971136",
  "geo" : { },
  "id_str" : "525504189447667713",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm time until porn was posted pending review: less than 2 hours",
  "id" : 525504189447667713,
  "in_reply_to_status_id" : 525478573482971136,
  "created_at" : "2014-10-24 04:28:56 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison House",
      "screen_name" : "house",
      "indices" : [ 0, 6 ],
      "id_str" : "19130153",
      "id" : 19130153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235812454, -78.8792914409 ]
  },
  "id_str" : "525499548823601152",
  "in_reply_to_user_id" : 19130153,
  "text" : "@house amazing work.",
  "id" : 525499548823601152,
  "created_at" : "2014-10-24 04:10:30 +0000",
  "in_reply_to_screen_name" : "house",
  "in_reply_to_user_id_str" : "19130153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rooms",
      "screen_name" : "tryrooms",
      "indices" : [ 3, 12 ],
      "id_str" : "2821797851",
      "id" : 2821797851
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 52, 58 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525492220757946368",
  "text" : "RT @tryrooms: We just added a new Recommended Room: @qrush's GIFs Room. Create a great room, share it publicly, and we might feature it in \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 38, 44 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525485122506989568",
    "text" : "We just added a new Recommended Room: @qrush's GIFs Room. Create a great room, share it publicly, and we might feature it in the app!",
    "id" : 525485122506989568,
    "created_at" : "2014-10-24 03:13:10 +0000",
    "user" : {
      "name" : "Rooms",
      "screen_name" : "tryrooms",
      "protected" : false,
      "id_str" : "2821797851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525322086638555138\/IORqXehL_normal.png",
      "id" : 2821797851,
      "verified" : false
    }
  },
  "id" : 525492220757946368,
  "created_at" : "2014-10-24 03:41:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 7, 21 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525479115001188352",
  "geo" : { },
  "id_str" : "525481578982408192",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm @libbybrittain haha thanks \uD83D\uDC3B",
  "id" : 525481578982408192,
  "in_reply_to_status_id" : 525479115001188352,
  "created_at" : "2014-10-24 02:59:06 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525477571350528002",
  "geo" : { },
  "id_str" : "525478032425754625",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm anyway this is pretty neat. The invite system is fantastic.",
  "id" : 525478032425754625,
  "in_reply_to_status_id" : 525477571350528002,
  "created_at" : "2014-10-24 02:45:00 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525477571350528002",
  "geo" : { },
  "id_str" : "525477715663523840",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm it\u2019s on, I don\u2019t want horrible images up. Sounds fun, bring it!",
  "id" : 525477715663523840,
  "in_reply_to_status_id" : 525477571350528002,
  "created_at" : "2014-10-24 02:43:44 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 3, 13 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 85, 97 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/qwfFHgr8Sx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nfyp-aRHjxQ",
      "display_url" : "youtube.com\/watch?v=nfyp-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525477464001089536",
  "text" : "RT @chumprock: I made a fan video for the song 20\/20 off the new \"Cycles\" album from @AqueousBand. Enjoy!\nhttps:\/\/t.co\/qwfFHgr8Sx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 70, 82 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/qwfFHgr8Sx",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nfyp-aRHjxQ",
        "display_url" : "youtube.com\/watch?v=nfyp-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "525320773808832512",
    "text" : "I made a fan video for the song 20\/20 off the new \"Cycles\" album from @AqueousBand. Enjoy!\nhttps:\/\/t.co\/qwfFHgr8Sx",
    "id" : 525320773808832512,
    "created_at" : "2014-10-23 16:20:07 +0000",
    "user" : {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "protected" : true,
      "id_str" : "2850371250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561217552286629888\/VitUuRpa_normal.png",
      "id" : 2850371250,
      "verified" : false
    }
  },
  "id" : 525477464001089536,
  "created_at" : "2014-10-24 02:42:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525475055216492544\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/PWG2uo3wgH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0rcxpcCAAEWCZt.png",
      "id_str" : "525475052037210113",
      "id" : 525475052037210113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0rcxpcCAAEWCZt.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PWG2uo3wgH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/dBnlRMd9AI",
      "expanded_url" : "http:\/\/rooms.me\/t\/tjGAnsoRCK\/gifs\/submission",
      "display_url" : "rooms.me\/t\/tjGAnsoRCK\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525475055216492544",
  "text" : "First GIF room moderator approval successful. http:\/\/t.co\/dBnlRMd9AI http:\/\/t.co\/PWG2uo3wgH",
  "id" : 525475055216492544,
  "created_at" : "2014-10-24 02:33:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "indices" : [ 3, 14 ],
      "id_str" : "312426579",
      "id" : 312426579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525474190359420928",
  "text" : "RT @mcclure111: Which of the following sequences of letters do you suppose you have typed more times, in your life\n\n\"I love you\"\n\n\"grep\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525423243059294209",
    "text" : "Which of the following sequences of letters do you suppose you have typed more times, in your life\n\n\"I love you\"\n\n\"grep\"",
    "id" : 525423243059294209,
    "created_at" : "2014-10-23 23:07:17 +0000",
    "user" : {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "protected" : false,
      "id_str" : "312426579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563051319007510528\/6mdkYASo_normal.png",
      "id" : 312426579,
      "verified" : false
    }
  },
  "id" : 525474190359420928,
  "created_at" : "2014-10-24 02:29:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/a8C9Agvck3",
      "expanded_url" : "http:\/\/rooms.me\/t\/A3fb8ylOea\/gifs\/submission",
      "display_url" : "rooms.me\/t\/A3fb8ylOea\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525462023174647808",
  "text" : "The video\/gif line is getting blurry. http:\/\/t.co\/a8C9Agvck3",
  "id" : 525462023174647808,
  "created_at" : "2014-10-24 01:41:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525455114296102913\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/blmVuK6bk9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0rKojIIEAE2c6H.png",
      "id_str" : "525455104514985985",
      "id" : 525455104514985985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0rKojIIEAE2c6H.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/blmVuK6bk9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525455114296102913",
  "text" : "This Rooms app is a little too much fun. http:\/\/t.co\/blmVuK6bk9",
  "id" : 525455114296102913,
  "created_at" : "2014-10-24 01:13:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525453060798021632\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xdgO2Q2qeY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0rIxkzCMAAHZTX.jpg",
      "id_str" : "525453060558958592",
      "id" : 525453060558958592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0rIxkzCMAAHZTX.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xdgO2Q2qeY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/OAMqoipI1z",
      "expanded_url" : "http:\/\/rooms.me",
      "display_url" : "rooms.me"
    } ]
  },
  "geo" : { },
  "id_str" : "525453060798021632",
  "text" : "Use this invite in Rooms to see GIFs. Don't have Rooms? Get it at http:\/\/t.co\/OAMqoipI1z. http:\/\/t.co\/xdgO2Q2qeY",
  "id" : 525453060798021632,
  "created_at" : "2014-10-24 01:05:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525423910834413568\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hXQA83o9rb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0quQtiIYAALsSe.png",
      "id_str" : "525423908665974784",
      "id" : 525423908665974784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0quQtiIYAALsSe.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hXQA83o9rb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525423910834413568",
  "text" : "Trying out Rooms. Any programming\/tech\/etc ones there are neat? Here\u2019s one for Phish. http:\/\/t.co\/hXQA83o9rb",
  "id" : 525423910834413568,
  "created_at" : "2014-10-23 23:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525399010291757056",
  "text" : "It\u2019s not a Chicago trip without sprinting through ORD",
  "id" : 525399010291757056,
  "created_at" : "2014-10-23 21:31:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525378330439462913",
  "geo" : { },
  "id_str" : "525378491249065986",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock that has never been easy but cmon",
  "id" : 525378491249065986,
  "in_reply_to_status_id" : 525378330439462913,
  "created_at" : "2014-10-23 20:09:28 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525378110150410240",
  "geo" : { },
  "id_str" : "525378230409510913",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock with what?",
  "id" : 525378230409510913,
  "in_reply_to_status_id" : 525378110150410240,
  "created_at" : "2014-10-23 20:08:25 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/LXYePRyDLL",
      "expanded_url" : "http:\/\/blog.dustinkirkland.com\/2013\/10\/fingerprints-are-user-names-not.html",
      "display_url" : "blog.dustinkirkland.com\/2013\/10\/finger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525317879445872640",
  "text" : "A good reminder on why TouchID should be avoided http:\/\/t.co\/LXYePRyDLL",
  "id" : 525317879445872640,
  "created_at" : "2014-10-23 16:08:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525304794727333888\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/JTo0O5Oeez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0pB7RgIYAAnW_I.jpg",
      "id_str" : "525304793108340736",
      "id" : 525304793108340736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0pB7RgIYAAnW_I.jpg",
      "sizes" : [ {
        "h" : 247,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/JTo0O5Oeez"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525304794727333888",
  "text" : "Range#cover? http:\/\/t.co\/JTo0O5Oeez",
  "id" : 525304794727333888,
  "created_at" : "2014-10-23 15:16:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 6, 15 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3WHZZqgV4H",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3297-a-case-for-clarity-in-feedback",
      "display_url" : "signalvnoise.com\/posts\/3297-a-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525286342922870784",
  "text" : "A one @migreyes reminded me of some not pleasing feedback I gave a few years back - try to be a little less awful :) https:\/\/t.co\/3WHZZqgV4H",
  "id" : 525286342922870784,
  "created_at" : "2014-10-23 14:03:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Movie Reviews",
      "screen_name" : "AmznMovieRevws",
      "indices" : [ 3, 18 ],
      "id_str" : "2723713757",
      "id" : 2723713757
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AmznMovieRevws\/status\/525049988280496128\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/TNCZ0sENRS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0laLq7IQAA7UVg.png",
      "id_str" : "525049988112728064",
      "id" : 525049988112728064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0laLq7IQAA7UVg.png",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TNCZ0sENRS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525278839212367872",
  "text" : "RT @AmznMovieRevws: Star Trek (2009). http:\/\/t.co\/TNCZ0sENRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AmznMovieRevws\/status\/525049988280496128\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/TNCZ0sENRS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0laLq7IQAA7UVg.png",
        "id_str" : "525049988112728064",
        "id" : 525049988112728064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0laLq7IQAA7UVg.png",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TNCZ0sENRS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525049988280496128",
    "text" : "Star Trek (2009). http:\/\/t.co\/TNCZ0sENRS",
    "id" : 525049988280496128,
    "created_at" : "2014-10-22 22:24:06 +0000",
    "user" : {
      "name" : "Amazon Movie Reviews",
      "screen_name" : "AmznMovieRevws",
      "protected" : false,
      "id_str" : "2723713757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559114116229382144\/iSbq4HZK_normal.jpeg",
      "id" : 2723713757,
      "verified" : false
    }
  },
  "id" : 525278839212367872,
  "created_at" : "2014-10-23 13:33:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/525049127911317507\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/IoxNlym8Lm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0lZZLbCYAA0x-U.jpg",
      "id_str" : "525049120663166976",
      "id" : 525049120663166976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0lZZLbCYAA0x-U.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IoxNlym8Lm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525049127911317507",
  "text" : "Yaaaaaaay! http:\/\/t.co\/IoxNlym8Lm",
  "id" : 525049127911317507,
  "created_at" : "2014-10-22 22:20:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/eJ5klUgaup",
      "expanded_url" : "http:\/\/butt.holdings",
      "display_url" : "butt.holdings"
    } ]
  },
  "geo" : { },
  "id_str" : "524968879723139072",
  "text" : "brew install mysql http:\/\/t.co\/eJ5klUgaup",
  "id" : 524968879723139072,
  "created_at" : "2014-10-22 17:01:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/524225971998564353\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/LtrlqLyJN8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZsvbVCAAAjuoS.jpg",
      "id_str" : "524225968680861696",
      "id" : 524225968680861696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZsvbVCAAAjuoS.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LtrlqLyJN8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524966242332205056",
  "text" : "RT @coworkbuffalo: Our phone booths are transitioning from politely quiet to Seriously Soundproof. (Also? Kinda Tron-like) http:\/\/t.co\/Ltrl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/524225971998564353\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/LtrlqLyJN8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZsvbVCAAAjuoS.jpg",
        "id_str" : "524225968680861696",
        "id" : 524225968680861696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZsvbVCAAAjuoS.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LtrlqLyJN8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524225971998564353",
    "text" : "Our phone booths are transitioning from politely quiet to Seriously Soundproof. (Also? Kinda Tron-like) http:\/\/t.co\/LtrlqLyJN8",
    "id" : 524225971998564353,
    "created_at" : "2014-10-20 15:49:46 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 524966242332205056,
  "created_at" : "2014-10-22 16:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/Z8gMb74KvL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bgxycSKCL2U",
      "display_url" : "youtube.com\/watch?v=bgxycS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524905638673936384",
  "text" : "ENUMERATE! ENUMERATE! https:\/\/t.co\/Z8gMb74KvL",
  "id" : 524905638673936384,
  "created_at" : "2014-10-22 12:50:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524896323548770304",
  "geo" : { },
  "id_str" : "524896555799556096",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos TMI",
  "id" : 524896555799556096,
  "in_reply_to_status_id" : 524896323548770304,
  "created_at" : "2014-10-22 12:14:25 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524895377346932737",
  "text" : "Try holding down on the camera or microphone buttons in Messages.",
  "id" : 524895377346932737,
  "created_at" : "2014-10-22 12:09:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Cantor",
      "screen_name" : "robcantor",
      "indices" : [ 3, 13 ],
      "id_str" : "24596136",
      "id" : 24596136
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "actualcannibal",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7CuQTgtq5T",
      "expanded_url" : "http:\/\/youtu.be\/o0u4M6vppCI",
      "display_url" : "youtu.be\/o0u4M6vppCI"
    } ]
  },
  "geo" : { },
  "id_str" : "524783388373164032",
  "text" : "RT @robcantor: NEW MUSIC VIDEO: \u201CShia LaBeouf\u201D feat. The Gay Men\u2019s Chorus of Los Angeles. http:\/\/t.co\/7CuQTgtq5T #actualcannibal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "actualcannibal",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/7CuQTgtq5T",
        "expanded_url" : "http:\/\/youtu.be\/o0u4M6vppCI",
        "display_url" : "youtu.be\/o0u4M6vppCI"
      } ]
    },
    "geo" : { },
    "id_str" : "524585034468950017",
    "text" : "NEW MUSIC VIDEO: \u201CShia LaBeouf\u201D feat. The Gay Men\u2019s Chorus of Los Angeles. http:\/\/t.co\/7CuQTgtq5T #actualcannibal",
    "id" : 524585034468950017,
    "created_at" : "2014-10-21 15:36:33 +0000",
    "user" : {
      "name" : "Rob Cantor",
      "screen_name" : "robcantor",
      "protected" : false,
      "id_str" : "24596136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506845991622807552\/4-lq7QJ7_normal.jpeg",
      "id" : 24596136,
      "verified" : true
    }
  },
  "id" : 524783388373164032,
  "created_at" : "2014-10-22 04:44:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524781997097746433",
  "geo" : { },
  "id_str" : "524782219764568064",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns I miss Energy.",
  "id" : 524782219764568064,
  "in_reply_to_status_id" : 524781997097746433,
  "created_at" : "2014-10-22 04:40:05 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524733843799281665",
  "geo" : { },
  "id_str" : "524781432292388864",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik I have a Dropbox folder for you when you are ready",
  "id" : 524781432292388864,
  "in_reply_to_status_id" : 524733843799281665,
  "created_at" : "2014-10-22 04:36:58 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524781185369919488",
  "geo" : { },
  "id_str" : "524781346263011328",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo was at Links Taproom in Chicago for a while.",
  "id" : 524781346263011328,
  "in_reply_to_status_id" : 524781185369919488,
  "created_at" : "2014-10-22 04:36:37 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524779725609529344",
  "geo" : { },
  "id_str" : "524781127232258049",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo glad I left. It was fantastic seeing a bar stream the show on 10 TVs though",
  "id" : 524781127232258049,
  "in_reply_to_status_id" : 524779725609529344,
  "created_at" : "2014-10-22 04:35:45 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 11, 18 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524630652222967808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.9099260591, -87.6766357182 ]
  },
  "id_str" : "524767864746938368",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @will_j I don\u2019t",
  "id" : 524767864746938368,
  "in_reply_to_status_id" : 524630652222967808,
  "created_at" : "2014-10-22 03:43:03 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 10, 21 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524765273552060416",
  "geo" : { },
  "id_str" : "524766204721111041",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @Dianna_2Ns I still listen to the Mansfield Ghost weekly.",
  "id" : 524766204721111041,
  "in_reply_to_status_id" : 524765273552060416,
  "created_at" : "2014-10-22 03:36:27 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524758294028902400",
  "geo" : { },
  "id_str" : "524758941637820416",
  "in_reply_to_user_id" : 6981492,
  "text" : "@ftrain Combo Meal",
  "id" : 524758941637820416,
  "in_reply_to_status_id" : 524758294028902400,
  "created_at" : "2014-10-22 03:07:35 +0000",
  "in_reply_to_screen_name" : "ftrain",
  "in_reply_to_user_id_str" : "6981492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 3, 13 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/phishmaps\/status\/524755627478753280\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/BbOvuz8J81",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0hOdLlCEAAci7J.jpg",
      "id_str" : "524755619819950080",
      "id" : 524755619819950080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0hOdLlCEAAci7J.jpg",
      "sizes" : [ {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 96,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BbOvuz8J81"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524755727660105728",
  "text" : "RT @phishmaps: #phish 10\/21\/14, Set 1. http:\/\/t.co\/BbOvuz8J81",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/phishmaps\/status\/524755627478753280\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/BbOvuz8J81",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0hOdLlCEAAci7J.jpg",
        "id_str" : "524755619819950080",
        "id" : 524755619819950080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0hOdLlCEAAci7J.jpg",
        "sizes" : [ {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 96,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BbOvuz8J81"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524755627478753280",
    "text" : "#phish 10\/21\/14, Set 1. http:\/\/t.co\/BbOvuz8J81",
    "id" : 524755627478753280,
    "created_at" : "2014-10-22 02:54:25 +0000",
    "user" : {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "protected" : false,
      "id_str" : "1649136702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417641270300135425\/6-hRtSQz_normal.jpeg",
      "id" : 1649136702,
      "verified" : false
    }
  },
  "id" : 524755727660105728,
  "created_at" : "2014-10-22 02:54:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 56, 62 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524735788983287808",
  "text" : "Need to find (or cajole) a bar into live streaming some @phish in Buffalo.",
  "id" : 524735788983287808,
  "created_at" : "2014-10-22 01:35:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524733066133385217",
  "geo" : { },
  "id_str" : "524733799067058176",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik shows on live now. You watching?",
  "id" : 524733799067058176,
  "in_reply_to_status_id" : 524733066133385217,
  "created_at" : "2014-10-22 01:27:41 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 11, 26 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524600060596609024",
  "geo" : { },
  "id_str" : "524600186770034688",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock @UnclePhilsBlog oops! Duh. Thanks so much!",
  "id" : 524600186770034688,
  "in_reply_to_status_id" : 524600060596609024,
  "created_at" : "2014-10-21 16:36:45 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 11, 26 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524599116139991042",
  "geo" : { },
  "id_str" : "524599736855457792",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock @UnclePhilsBlog what URL are you seeing that on?",
  "id" : 524599736855457792,
  "in_reply_to_status_id" : 524599116139991042,
  "created_at" : "2014-10-21 16:34:58 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524598622193995776",
  "geo" : { },
  "id_str" : "524598933570719744",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss what.",
  "id" : 524598933570719744,
  "in_reply_to_status_id" : 524598622193995776,
  "created_at" : "2014-10-21 16:31:47 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chumprock",
      "screen_name" : "chumprock",
      "indices" : [ 0, 10 ],
      "id_str" : "2850371250",
      "id" : 2850371250
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 11, 26 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524596907402731520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.8824513361, -87.6627791542 ]
  },
  "id_str" : "524598732588081152",
  "in_reply_to_user_id" : 2850371250,
  "text" : "@chumprock @UnclePhilsBlog huh?",
  "id" : 524598732588081152,
  "in_reply_to_status_id" : 524596907402731520,
  "created_at" : "2014-10-21 16:30:59 +0000",
  "in_reply_to_screen_name" : "chumprock",
  "in_reply_to_user_id_str" : "2850371250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/moonpolysoft\/status\/524587737760792576\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/LlllRguso6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0e1xEZCIAEo3VT.jpg",
      "id_str" : "524587736208908289",
      "id" : 524587736208908289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0e1xEZCIAEo3VT.jpg",
      "sizes" : [ {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LlllRguso6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524589747168366592",
  "text" : "RT @moonpolysoft: I too recommend against typing like this http:\/\/t.co\/LlllRguso6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/moonpolysoft\/status\/524587737760792576\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/LlllRguso6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0e1xEZCIAEo3VT.jpg",
        "id_str" : "524587736208908289",
        "id" : 524587736208908289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0e1xEZCIAEo3VT.jpg",
        "sizes" : [ {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LlllRguso6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524587737760792576",
    "text" : "I too recommend against typing like this http:\/\/t.co\/LlllRguso6",
    "id" : 524587737760792576,
    "created_at" : "2014-10-21 15:47:17 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 524589747168366592,
  "created_at" : "2014-10-21 15:55:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 1, 13 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ZonnR65gvq",
      "expanded_url" : "http:\/\/aqueous1.bandcamp.com\/track\/staring-into-the-sun-2",
      "display_url" : "aqueous1.bandcamp.com\/track\/staring-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524584606813917184",
  "text" : ".@AqueousBand's new album is out!! Dive in, the horns\/strings on this track are great: http:\/\/t.co\/ZonnR65gvq",
  "id" : 524584606813917184,
  "created_at" : "2014-10-21 15:34:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 44, 54 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/524551282477264896\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/OuV7r9e8KM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0eUnC3CQAIVs1s.jpg",
      "id_str" : "524551280115466242",
      "id" : 524551280115466242,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0eUnC3CQAIVs1s.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/OuV7r9e8KM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524551282477264896",
  "text" : "There\u2019s a board game store a block from the @37signals office!! \uD83D\uDE24 http:\/\/t.co\/OuV7r9e8KM",
  "id" : 524551282477264896,
  "created_at" : "2014-10-21 13:22:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 0, 15 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524538115969810432",
  "geo" : { },
  "id_str" : "524548441859313664",
  "in_reply_to_user_id" : 1472209542,
  "text" : "@PublicEspresso a thousand times yes",
  "id" : 524548441859313664,
  "in_reply_to_status_id" : 524538115969810432,
  "created_at" : "2014-10-21 13:11:08 +0000",
  "in_reply_to_screen_name" : "PublicEspresso",
  "in_reply_to_user_id_str" : "1472209542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524548366353461249",
  "text" : "Nothing like waking up to hearing of a murder-suicide on your bike route :(",
  "id" : 524548366353461249,
  "created_at" : "2014-10-21 13:10:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 19, 29 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/524208692431187968\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/BfJY439eMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZdBrmCAAA4qjl.jpg",
      "id_str" : "524208690098733056",
      "id" : 524208690098733056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZdBrmCAAA4qjl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BfJY439eMR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524208692431187968",
  "text" : "North by northeast @37signals http:\/\/t.co\/BfJY439eMR",
  "id" : 524208692431187968,
  "created_at" : "2014-10-20 14:41:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Fox-Solomon",
      "screen_name" : "efoxsolomon",
      "indices" : [ 3, 15 ],
      "id_str" : "234873497",
      "id" : 234873497
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 29, 37 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JJ62HmOllp",
      "expanded_url" : "http:\/\/nyti.ms\/1CK9tfm",
      "display_url" : "nyti.ms\/1CK9tfm"
    } ]
  },
  "geo" : { },
  "id_str" : "524169617825333248",
  "text" : "RT @efoxsolomon: Buffalo! RT @nytimes: Urban Renewal: Where Young College Graduates Are Choosing to Live http:\/\/t.co\/JJ62HmOllp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 12, 20 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/JJ62HmOllp",
        "expanded_url" : "http:\/\/nyti.ms\/1CK9tfm",
        "display_url" : "nyti.ms\/1CK9tfm"
      } ]
    },
    "in_reply_to_status_id_str" : "524147769687416832",
    "geo" : { },
    "id_str" : "524158325324525568",
    "in_reply_to_user_id" : 807095,
    "text" : "Buffalo! RT @nytimes: Urban Renewal: Where Young College Graduates Are Choosing to Live http:\/\/t.co\/JJ62HmOllp",
    "id" : 524158325324525568,
    "in_reply_to_status_id" : 524147769687416832,
    "created_at" : "2014-10-20 11:20:57 +0000",
    "in_reply_to_screen_name" : "nytimes",
    "in_reply_to_user_id_str" : "807095",
    "user" : {
      "name" : "Liz Fox-Solomon",
      "screen_name" : "efoxsolomon",
      "protected" : false,
      "id_str" : "234873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1276836669\/liz_dancing_bubbles_normal.jpg",
      "id" : 234873497,
      "verified" : false
    }
  },
  "id" : 524169617825333248,
  "created_at" : "2014-10-20 12:05:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Fritzy",
      "screen_name" : "fritzy",
      "indices" : [ 9, 16 ],
      "id_str" : "14498374",
      "id" : 14498374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524063852967645184",
  "geo" : { },
  "id_str" : "524064065334034432",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @fritzy sold",
  "id" : 524064065334034432,
  "in_reply_to_status_id" : 524063852967645184,
  "created_at" : "2014-10-20 05:06:24 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524009578988449794",
  "geo" : { },
  "id_str" : "524058609303298048",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety are you fucking kidding me",
  "id" : 524058609303298048,
  "in_reply_to_status_id" : 524009578988449794,
  "created_at" : "2014-10-20 04:44:43 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEIL cicierega",
      "screen_name" : "neilyourself",
      "indices" : [ 3, 16 ],
      "id_str" : "15360428",
      "id" : 15360428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524055715955347456",
  "text" : "RT @neilyourself: Most anime titles are also strong passwords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524052751802990592",
    "text" : "Most anime titles are also strong passwords",
    "id" : 524052751802990592,
    "created_at" : "2014-10-20 04:21:27 +0000",
    "user" : {
      "name" : "NEIL cicierega",
      "screen_name" : "neilyourself",
      "protected" : false,
      "id_str" : "15360428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572578402897371136\/jwqh-fxu_normal.jpeg",
      "id" : 15360428,
      "verified" : true
    }
  },
  "id" : 524055715955347456,
  "created_at" : "2014-10-20 04:33:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 46, 61 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/524030754771443713\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/suXMxO1Gj9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0W7MQcIUAAeQk0.jpg",
      "id_str" : "524030750904307712",
      "id" : 524030750904307712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0W7MQcIUAAeQk0.jpg",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/suXMxO1Gj9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524053619973574656",
  "text" : "RT @kevinpurdy: That's some nice juxtaposin', @washingtonpost. http:\/\/t.co\/suXMxO1Gj9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 30, 45 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/524030754771443713\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/suXMxO1Gj9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0W7MQcIUAAeQk0.jpg",
        "id_str" : "524030750904307712",
        "id" : 524030750904307712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0W7MQcIUAAeQk0.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/suXMxO1Gj9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524030754771443713",
    "text" : "That's some nice juxtaposin', @washingtonpost. http:\/\/t.co\/suXMxO1Gj9",
    "id" : 524030754771443713,
    "created_at" : "2014-10-20 02:54:02 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 524053619973574656,
  "created_at" : "2014-10-20 04:24:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Glazebrook",
      "screen_name" : "mostlikely_to",
      "indices" : [ 0, 14 ],
      "id_str" : "73204959",
      "id" : 73204959
    }, {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 15, 22 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "indices" : [ 23, 31 ],
      "id_str" : "806464",
      "id" : 806464
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 32, 39 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 90, 100 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524016884866240512",
  "geo" : { },
  "id_str" : "524018027730595842",
  "in_reply_to_user_id" : 73204959,
  "text" : "@mostlikely_to @will_j @tomafro @sylvzc I am going just for people mostly. Also any other @37signals folks?",
  "id" : 524018027730595842,
  "in_reply_to_status_id" : 524016884866240512,
  "created_at" : "2014-10-20 02:03:28 +0000",
  "in_reply_to_screen_name" : "mostlikely_to",
  "in_reply_to_user_id_str" : "73204959",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "Tom Ward",
      "screen_name" : "tomafro",
      "indices" : [ 8, 16 ],
      "id_str" : "806464",
      "id" : 806464
    }, {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 17, 24 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    }, {
      "name" : "James Glazebrook",
      "screen_name" : "mostlikely_to",
      "indices" : [ 25, 39 ],
      "id_str" : "73204959",
      "id" : 73204959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523902252478889984",
  "geo" : { },
  "id_str" : "524016751680700416",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @tomafro @sylvzc @mostlikely_to pizza? Now?",
  "id" : 524016751680700416,
  "in_reply_to_status_id" : 523902252478889984,
  "created_at" : "2014-10-20 01:58:24 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523919421849759744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9339925597, -78.7345671258 ]
  },
  "id_str" : "523920090602143744",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt OH GREAT",
  "id" : 523920090602143744,
  "in_reply_to_status_id" : 523919421849759744,
  "created_at" : "2014-10-19 19:34:18 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 7, 15 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523918861792735232",
  "geo" : { },
  "id_str" : "523919104265428993",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @rubiety in case you are in the air, my curse continues",
  "id" : 523919104265428993,
  "in_reply_to_status_id" : 523918861792735232,
  "created_at" : "2014-10-19 19:30:23 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523918861792735232",
  "text" : "Pilot says we have to fly lower than normal and swap out fuel. I really hate airplanes.",
  "id" : 523918861792735232,
  "created_at" : "2014-10-19 19:29:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eileen M. Uchitelle",
      "screen_name" : "eileencodes",
      "indices" : [ 0, 12 ],
      "id_str" : "390287545",
      "id" : 390287545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523915243802869760",
  "geo" : { },
  "id_str" : "523915402758610944",
  "in_reply_to_user_id" : 390287545,
  "text" : "@eileencodes yes, but this is normal flying luck for me",
  "id" : 523915402758610944,
  "in_reply_to_status_id" : 523915243802869760,
  "created_at" : "2014-10-19 19:15:40 +0000",
  "in_reply_to_screen_name" : "eileencodes",
  "in_reply_to_user_id_str" : "390287545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523915262962434048",
  "text" : "Stuck on the ground with some kind of unknown maintenance issue. I cannot go to an airport without some kind of problem happening.",
  "id" : 523915262962434048,
  "created_at" : "2014-10-19 19:15:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523914432380821504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9359805354, -78.7460017791 ]
  },
  "id_str" : "523915063745605632",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil had a feeling this would happen. Glad I stopped.",
  "id" : 523915063745605632,
  "in_reply_to_status_id" : 523914432380821504,
  "created_at" : "2014-10-19 19:14:19 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/JOqZAyRllw",
      "expanded_url" : "http:\/\/imgur.com\/a\/uQxlB",
      "display_url" : "imgur.com\/a\/uQxlB"
    } ]
  },
  "geo" : { },
  "id_str" : "523905587177070592",
  "text" : "The Dwarven Baby blocks and strikes the Shadow Beast in the head [...] bruising the brain! http:\/\/t.co\/JOqZAyRllw",
  "id" : 523905587177070592,
  "created_at" : "2014-10-19 18:36:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tildenethack",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523903970692325376",
  "text" : "\"Killed by a mastodon\" - after discovering a wand was a wand of polymorph. #tildenethack",
  "id" : 523903970692325376,
  "created_at" : "2014-10-19 18:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523899163072020480",
  "text" : "Time it took while sitting waiting for a delayed flight for someone to bring up the E-word: 2 hours",
  "id" : 523899163072020480,
  "created_at" : "2014-10-19 18:11:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 0, 8 ],
      "id_str" : "14408469",
      "id" : 14408469
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523878543215067136",
  "geo" : { },
  "id_str" : "523880213575639040",
  "in_reply_to_user_id" : 14408469,
  "text" : "@uptonic @37signals oh crap i forgot to bring coffee. oops.",
  "id" : 523880213575639040,
  "in_reply_to_status_id" : 523878543215067136,
  "created_at" : "2014-10-19 16:55:50 +0000",
  "in_reply_to_screen_name" : "uptonic",
  "in_reply_to_user_id_str" : "14408469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/3UFG2vaWWW",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/society\/why-the-apology-is-a-friend-of-the-powerful\/",
      "display_url" : "aeon.co\/magazine\/socie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523877075368038400",
  "text" : "TIL there are \"apology consultants\" http:\/\/t.co\/3UFG2vaWWW",
  "id" : 523877075368038400,
  "created_at" : "2014-10-19 16:43:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Brewster",
      "screen_name" : "kentbrew",
      "indices" : [ 52, 61 ],
      "id_str" : "2622731",
      "id" : 2622731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/siPPZhz0DP",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "523874787173871616",
  "text" : "Updated guestbook on http:\/\/t.co\/siPPZhz0DP, and no @kentbrew it's not",
  "id" : 523874787173871616,
  "created_at" : "2014-10-19 16:34:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/qlTh5MivXN",
      "expanded_url" : "https:\/\/medium.com\/re-form\/simcity-that-i-used-to-know-d5d8c49e3e1d",
      "display_url" : "medium.com\/re-form\/simcit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523874378946478081",
  "text" : "I miss the original SimCity. https:\/\/t.co\/qlTh5MivXN",
  "id" : 523874378946478081,
  "created_at" : "2014-10-19 16:32:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Dingus",
      "screen_name" : "dingusj1",
      "indices" : [ 0, 9 ],
      "id_str" : "192768127",
      "id" : 192768127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523870655901888514",
  "geo" : { },
  "id_str" : "523874326551207936",
  "in_reply_to_user_id" : 192768127,
  "text" : "@dingusj1 I think he had a potion.",
  "id" : 523874326551207936,
  "in_reply_to_status_id" : 523870655901888514,
  "created_at" : "2014-10-19 16:32:27 +0000",
  "in_reply_to_screen_name" : "dingusj1",
  "in_reply_to_user_id_str" : "192768127",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 12, 21 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/523856911347638273\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/oFQl9nfxTo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0UdFSUCcAAUfnA.jpg",
      "id_str" : "523856908310966272",
      "id" : 523856908310966272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0UdFSUCcAAUfnA.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oFQl9nfxTo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523856911347638273",
  "text" : "Coming to a @shildner meat up near you http:\/\/t.co\/oFQl9nfxTo",
  "id" : 523856911347638273,
  "created_at" : "2014-10-19 15:23:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR's Planet Money",
      "screen_name" : "planetmoney",
      "indices" : [ 3, 15 ],
      "id_str" : "15905103",
      "id" : 15905103
    }, {
      "name" : "Stephen Henn",
      "screen_name" : "HennsEggs",
      "indices" : [ 83, 93 ],
      "id_str" : "133826235",
      "id" : 133826235
    }, {
      "name" : "catek",
      "screen_name" : "catek",
      "indices" : [ 100, 106 ],
      "id_str" : "15582236",
      "id" : 15582236
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/planetmoney\/status\/523509966120816640\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/pDg2VO3HXr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0PhijkCYAA8v8F.png",
      "id_str" : "523509965483302912",
      "id" : 523509965483302912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0PhijkCYAA8v8F.png",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pDg2VO3HXr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/VmQTl5XNas",
      "expanded_url" : "http:\/\/n.pr\/1sA0cUy",
      "display_url" : "n.pr\/1sA0cUy"
    } ]
  },
  "geo" : { },
  "id_str" : "523834738595725312",
  "text" : "RT @planetmoney: Computer sci hasn't always been so male-dominated. What happened? @hennseggs &amp; @catek explain  http:\/\/t.co\/VmQTl5XNas http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Henn",
        "screen_name" : "HennsEggs",
        "indices" : [ 66, 76 ],
        "id_str" : "133826235",
        "id" : 133826235
      }, {
        "name" : "catek",
        "screen_name" : "catek",
        "indices" : [ 83, 89 ],
        "id_str" : "15582236",
        "id" : 15582236
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/planetmoney\/status\/523509966120816640\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/pDg2VO3HXr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0PhijkCYAA8v8F.png",
        "id_str" : "523509965483302912",
        "id" : 523509965483302912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0PhijkCYAA8v8F.png",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/pDg2VO3HXr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/VmQTl5XNas",
        "expanded_url" : "http:\/\/n.pr\/1sA0cUy",
        "display_url" : "n.pr\/1sA0cUy"
      } ]
    },
    "geo" : { },
    "id_str" : "523509966120816640",
    "text" : "Computer sci hasn't always been so male-dominated. What happened? @hennseggs &amp; @catek explain  http:\/\/t.co\/VmQTl5XNas http:\/\/t.co\/pDg2VO3HXr",
    "id" : 523509966120816640,
    "created_at" : "2014-10-18 16:24:36 +0000",
    "user" : {
      "name" : "NPR's Planet Money",
      "screen_name" : "planetmoney",
      "protected" : false,
      "id_str" : "15905103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473888336449269761\/vIurMh9f_normal.png",
      "id" : 15905103,
      "verified" : true
    }
  },
  "id" : 523834738595725312,
  "created_at" : "2014-10-19 13:55:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tildenethack",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523711190745116672",
  "text" : "\"Killed by an invisible dwarf king\" Oh cmon. #tildenethack",
  "id" : 523711190745116672,
  "created_at" : "2014-10-19 05:44:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fluffhead Was A Man",
      "screen_name" : "fluffhead67",
      "indices" : [ 0, 12 ],
      "id_str" : "253374465",
      "id" : 253374465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523690554970755074",
  "in_reply_to_user_id" : 253374465,
  "text" : "@fluffhead67 it's a joke",
  "id" : 523690554970755074,
  "created_at" : "2014-10-19 04:22:12 +0000",
  "in_reply_to_screen_name" : "fluffhead67",
  "in_reply_to_user_id_str" : "253374465",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "lia bulaong",
      "screen_name" : "lia",
      "indices" : [ 14, 18 ],
      "id_str" : "15484730",
      "id" : 15484730
    }, {
      "name" : "rachel",
      "screen_name" : "ohhoe",
      "indices" : [ 19, 25 ],
      "id_str" : "2141321",
      "id" : 2141321
    }, {
      "name" : "Dannel Jurado",
      "screen_name" : "DeMarko",
      "indices" : [ 26, 34 ],
      "id_str" : "809399",
      "id" : 809399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523690192432267264",
  "geo" : { },
  "id_str" : "523690465086828544",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @lia @ohhoe @DeMarko please tell me you played some boss music when fighting the boss",
  "id" : 523690465086828544,
  "in_reply_to_status_id" : 523690192432267264,
  "created_at" : "2014-10-19 04:21:51 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523675016844431360",
  "text" : "Phish, Fall Tour Round 2. FIGHT!!",
  "id" : 523675016844431360,
  "created_at" : "2014-10-19 03:20:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Kbf7uPa7ci",
      "expanded_url" : "http:\/\/twitpic.com\/135xa",
      "display_url" : "twitpic.com\/135xa"
    } ]
  },
  "geo" : { },
  "id_str" : "523595106088411136",
  "text" : "RT @waxpancake: TwitPic is destroying seven years of digital history, and already shut off public access to photos. Historic example: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Kbf7uPa7ci",
        "expanded_url" : "http:\/\/twitpic.com\/135xa",
        "display_url" : "twitpic.com\/135xa"
      } ]
    },
    "geo" : { },
    "id_str" : "523593166566338560",
    "text" : "TwitPic is destroying seven years of digital history, and already shut off public access to photos. Historic example: http:\/\/t.co\/Kbf7uPa7ci",
    "id" : 523593166566338560,
    "created_at" : "2014-10-18 21:55:13 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539845905889775616\/_tilXA5z_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 523595106088411136,
  "created_at" : "2014-10-18 22:02:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523502435071836161",
  "geo" : { },
  "id_str" : "523573890631876608",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom \u201810 here \uD83D\uDC4D",
  "id" : 523573890631876608,
  "in_reply_to_status_id" : 523502435071836161,
  "created_at" : "2014-10-18 20:38:37 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 13, 26 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523573043864797184",
  "geo" : { },
  "id_str" : "523573802144632832",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude @davidmoffitt I think they are trying to call them \u201CHall\u201D now, but a lot of old signs were up still",
  "id" : 523573802144632832,
  "in_reply_to_status_id" : 523573043864797184,
  "created_at" : "2014-10-18 20:38:16 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Woe0u5BH14",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/dXG6LPuHrQ2",
      "display_url" : "swarmapp.com\/c\/dXG6LPuHrQ2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0911156706, -77.6362033652 ]
  },
  "id_str" : "523540008276590593",
  "text" : "I'm at Millennium Games &amp; Hobbies in Rochester, NY https:\/\/t.co\/Woe0u5BH14",
  "id" : 523540008276590593,
  "created_at" : "2014-10-18 18:23:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/523533324766433280\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/wSHo1sN0vZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0P2yIMIUAMqVDL.jpg",
      "id_str" : "523533322757361667",
      "id" : 523533322757361667,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0P2yIMIUAMqVDL.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wSHo1sN0vZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523533324766433280",
  "text" : "It\u2019s so new the holes for the net aren\u2019t drilled yet http:\/\/t.co\/wSHo1sN0vZ",
  "id" : 523533324766433280,
  "created_at" : "2014-10-18 17:57:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/523531566069612544\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/5VcgRh4oVS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0P1LXsIQAE2K4S.jpg",
      "id_str" : "523531557391581185",
      "id" : 523531557391581185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0P1LXsIQAE2K4S.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5VcgRh4oVS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523531566069612544",
  "text" : "This new arena is really nice. The Ritter\u2019s obseleted. http:\/\/t.co\/5VcgRh4oVS",
  "id" : 523531566069612544,
  "created_at" : "2014-10-18 17:50:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/523504033420812288\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Z31AApGF88",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0PcI8CCMAAf2w7.jpg",
      "id_str" : "523504027816833024",
      "id" : 523504027816833024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0PcI8CCMAAf2w7.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Z31AApGF88"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523504033420812288",
  "text" : "Holy crap the new arena is huge http:\/\/t.co\/Z31AApGF88",
  "id" : 523504033420812288,
  "created_at" : "2014-10-18 16:01:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523480763204116481",
  "geo" : { },
  "id_str" : "523497813913927680",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock that said it seems OK",
  "id" : 523497813913927680,
  "in_reply_to_status_id" : 523480763204116481,
  "created_at" : "2014-10-18 15:36:19 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523480763204116481",
  "geo" : { },
  "id_str" : "523497618903941120",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock RG really needs a new lead maintainer, I am too busy with other projects and family stuff",
  "id" : 523497618903941120,
  "in_reply_to_status_id" : 523480763204116481,
  "created_at" : "2014-10-18 15:35:33 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523497418583986176",
  "text" : "At RIT for Brick City. Kind of surreal to be at post-building number scheme, semester system (I think?) RIT.",
  "id" : 523497418583986176,
  "created_at" : "2014-10-18 15:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/RlGVzB2Nzc",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/7scVNSYsbZr",
      "display_url" : "swarmapp.com\/c\/7scVNSYsbZr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.084819681, -77.6679823514 ]
  },
  "id_str" : "523496788649857024",
  "text" : "I'm at RIT https:\/\/t.co\/RlGVzB2Nzc",
  "id" : 523496788649857024,
  "created_at" : "2014-10-18 15:32:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 0, 15 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523470716155731968",
  "geo" : { },
  "id_str" : "523473397653970944",
  "in_reply_to_user_id" : 1472209542,
  "text" : "@PublicEspresso this is a thing?! Hours?",
  "id" : 523473397653970944,
  "in_reply_to_status_id" : 523470716155731968,
  "created_at" : "2014-10-18 13:59:18 +0000",
  "in_reply_to_screen_name" : "PublicEspresso",
  "in_reply_to_user_id_str" : "1472209542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tildenethack",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523347385015996416",
  "text" : "\"Killed by a magic missile.\" (after Stormbringer attacked a watch captain) #tildenethack",
  "id" : 523347385015996416,
  "created_at" : "2014-10-18 05:38:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 10, 20 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523342894078246912",
  "geo" : { },
  "id_str" : "523343015134244865",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo @Phish_FTR well I guessed an all new cover for my five, close enough right?",
  "id" : 523343015134244865,
  "in_reply_to_status_id" : 523342894078246912,
  "created_at" : "2014-10-18 05:21:12 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tildenethack",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523342875677831168",
  "text" : "\"Killed by a kraken.\" Whelp. #tildenethack",
  "id" : 523342875677831168,
  "created_at" : "2014-10-18 05:20:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 3, 13 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/phishmaps\/status\/523332858841423872\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/i06VpuekOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0NAdkbIMAAogIK.jpg",
      "id_str" : "523332858442952704",
      "id" : 523332858442952704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0NAdkbIMAAogIK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 112,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i06VpuekOk"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523341885142605826",
  "text" : "RT @phishmaps: #phish 10\/17\/14 set 1 http:\/\/t.co\/i06VpuekOk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/phishmaps\/status\/523332858841423872\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/i06VpuekOk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0NAdkbIMAAogIK.jpg",
        "id_str" : "523332858442952704",
        "id" : 523332858442952704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0NAdkbIMAAogIK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 112,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/i06VpuekOk"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523332858841423872",
    "text" : "#phish 10\/17\/14 set 1 http:\/\/t.co\/i06VpuekOk",
    "id" : 523332858841423872,
    "created_at" : "2014-10-18 04:40:51 +0000",
    "user" : {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "protected" : false,
      "id_str" : "1649136702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417641270300135425\/6-hRtSQz_normal.jpeg",
      "id" : 1649136702,
      "verified" : false
    }
  },
  "id" : 523341885142605826,
  "created_at" : "2014-10-18 05:16:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523330715694276608",
  "text" : "Page is on fire.",
  "id" : 523330715694276608,
  "created_at" : "2014-10-18 04:32:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna_2Ns",
      "screen_name" : "Dianna_2Ns",
      "indices" : [ 0, 11 ],
      "id_str" : "67117740",
      "id" : 67117740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523314484396703745",
  "geo" : { },
  "id_str" : "523314705608101888",
  "in_reply_to_user_id" : 67117740,
  "text" : "@Dianna_2Ns oh nooooo",
  "id" : 523314705608101888,
  "in_reply_to_status_id" : 523314484396703745,
  "created_at" : "2014-10-18 03:28:43 +0000",
  "in_reply_to_screen_name" : "Dianna_2Ns",
  "in_reply_to_user_id_str" : "67117740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 0, 10 ],
      "id_str" : "153850397",
      "id" : 153850397
    }, {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 21, 32 ],
      "id_str" : "76750013",
      "id" : 76750013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523314126823493634",
  "geo" : { },
  "id_str" : "523314175615856640",
  "in_reply_to_user_id" : 153850397,
  "text" : "@Phish_FTR CALLED IT @ashstarr88",
  "id" : 523314175615856640,
  "in_reply_to_status_id" : 523314126823493634,
  "created_at" : "2014-10-18 03:26:36 +0000",
  "in_reply_to_screen_name" : "Phish_FTR",
  "in_reply_to_user_id_str" : "153850397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tildenethack",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523314100906909696",
  "text" : "\"Killed by an invisible winged gargoyle\" oh cmon #tildenethack",
  "id" : 523314100906909696,
  "created_at" : "2014-10-18 03:26:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yas-Arakawa",
      "screen_name" : "YasunobuArakawa",
      "indices" : [ 1, 17 ],
      "id_str" : "72196441",
      "id" : 72196441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523313657443139584",
  "text" : ".@YasunobuArakawa thanks for the stream!",
  "id" : 523313657443139584,
  "created_at" : "2014-10-18 03:24:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "indices" : [ 3, 13 ],
      "id_str" : "153850397",
      "id" : 153850397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523311902768627712",
  "text" : "RT @Phish_FTR: Free",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.phish.com\/\" rel=\"nofollow\"\u003EPhish From the Road\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523311770337697793",
    "text" : "Free",
    "id" : 523311770337697793,
    "created_at" : "2014-10-18 03:17:03 +0000",
    "user" : {
      "name" : "Phish: From The Road",
      "screen_name" : "Phish_FTR",
      "protected" : false,
      "id_str" : "153850397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000065818163\/de7aca9d2eb0c2005f7df69ad86aafa4_normal.jpeg",
      "id" : 153850397,
      "verified" : false
    }
  },
  "id" : 523311902768627712,
  "created_at" : "2014-10-18 03:17:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/xdylYlZ56V",
      "expanded_url" : "https:\/\/basecamp.com\/team",
      "display_url" : "basecamp.com\/team"
    } ]
  },
  "geo" : { },
  "id_str" : "523260419234746368",
  "text" : "Excited to see these 44 (!!) folks next week. https:\/\/t.co\/xdylYlZ56V",
  "id" : 523260419234746368,
  "created_at" : "2014-10-17 23:53:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 0, 11 ],
      "id_str" : "76750013",
      "id" : 76750013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523243079382233088",
  "geo" : { },
  "id_str" : "523243524355936256",
  "in_reply_to_user_id" : 76750013,
  "text" : "@ashstarr88 2001, Mike\u2019s, Wingsuit, Sample, a new cover",
  "id" : 523243524355936256,
  "in_reply_to_status_id" : 523243079382233088,
  "created_at" : "2014-10-17 22:45:52 +0000",
  "in_reply_to_screen_name" : "ashstarr88",
  "in_reply_to_user_id_str" : "76750013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 0, 11 ],
      "id_str" : "3621751",
      "id" : 3621751
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 12, 19 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523120703768653824",
  "geo" : { },
  "id_str" : "523242448600842240",
  "in_reply_to_user_id" : 3621751,
  "text" : "@abackstrom @ftrain next up: nethack stats",
  "id" : 523242448600842240,
  "in_reply_to_status_id" : 523120703768653824,
  "created_at" : "2014-10-17 22:41:35 +0000",
  "in_reply_to_screen_name" : "abackstrom",
  "in_reply_to_user_id_str" : "3621751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "indices" : [ 3, 16 ],
      "id_str" : "896641",
      "id" : 896641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/fx1Mk881BO",
      "expanded_url" : "https:\/\/basecamp.com\/announcements\/46",
      "display_url" : "basecamp.com\/announcements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523237805988646913",
  "text" : "RT @jasonzimdars: Basecamp for iPad 1.1 is here with a slew of new iOS 8 features: https:\/\/t.co\/fx1Mk881BO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/fx1Mk881BO",
        "expanded_url" : "https:\/\/basecamp.com\/announcements\/46",
        "display_url" : "basecamp.com\/announcements\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523232695003123712",
    "text" : "Basecamp for iPad 1.1 is here with a slew of new iOS 8 features: https:\/\/t.co\/fx1Mk881BO",
    "id" : 523232695003123712,
    "created_at" : "2014-10-17 22:02:50 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 523237805988646913,
  "created_at" : "2014-10-17 22:23:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523223810879672320",
  "geo" : { },
  "id_str" : "523224626671779840",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo 21st Amendment is nice. Get coffee at Sightglass or Blue Bottle.",
  "id" : 523224626671779840,
  "in_reply_to_status_id" : 523223810879672320,
  "created_at" : "2014-10-17 21:30:46 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 12, 18 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523214823417323521",
  "text" : "6 nights of @phish webcasts now happening in the next 3 weeks. WEBCAST ALL THE SHOWS!",
  "id" : 523214823417323521,
  "created_at" : "2014-10-17 20:51:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/33aYAoRhje",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/1QlTVQtU1D",
      "expanded_url" : "https:\/\/trello.com\/c\/gdXmu9EU\/4-ssl-configuration-is-rated-c",
      "display_url" : "trello.com\/c\/gdXmu9EU\/4-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523148730510630913",
  "text" : "Fantastic news that http:\/\/t.co\/33aYAoRhje's SSL ranking is finally A! Big ups to our ops team. https:\/\/t.co\/1QlTVQtU1D",
  "id" : 523148730510630913,
  "created_at" : "2014-10-17 16:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 3, 14 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcity\/status\/523094915639934978\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/q9r8lXgotI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JoDboIYAAnHsi.png",
      "id_str" : "523094914893373440",
      "id" : 523094914893373440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JoDboIYAAnHsi.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1420,
        "resize" : "fit",
        "w" : 1520
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q9r8lXgotI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523136388812664834",
  "text" : "RT @nickelcity: I'm selling my house this morning, you guys. http:\/\/t.co\/q9r8lXgotI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcity\/status\/523094915639934978\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/q9r8lXgotI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JoDboIYAAnHsi.png",
        "id_str" : "523094914893373440",
        "id" : 523094914893373440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JoDboIYAAnHsi.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1420,
          "resize" : "fit",
          "w" : 1520
        }, {
          "h" : 956,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 317,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q9r8lXgotI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523094915639934978",
    "text" : "I'm selling my house this morning, you guys. http:\/\/t.co\/q9r8lXgotI",
    "id" : 523094915639934978,
    "created_at" : "2014-10-17 12:55:21 +0000",
    "user" : {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "protected" : false,
      "id_str" : "137891464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541312075570491395\/PrAOKda4_normal.jpeg",
      "id" : 137891464,
      "verified" : false
    }
  },
  "id" : 523136388812664834,
  "created_at" : "2014-10-17 15:40:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523134805009911809",
  "text" : "My favorite part of cool WebFonts is how they show up totally blank at first!",
  "id" : 523134805009911809,
  "created_at" : "2014-10-17 15:33:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523105324199591936",
  "geo" : { },
  "id_str" : "523105692949823488",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr population density does not make sense for that",
  "id" : 523105692949823488,
  "in_reply_to_status_id" : 523105324199591936,
  "created_at" : "2014-10-17 13:38:10 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "indices" : [ 3, 14 ],
      "id_str" : "3621751",
      "id" : 3621751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/qOWUsT0IEM",
      "expanded_url" : "https:\/\/vine.co\/v\/Om79QbvTjLv",
      "display_url" : "vine.co\/v\/Om79QbvTjLv"
    } ]
  },
  "geo" : { },
  "id_str" : "523103694330417152",
  "text" : "RT @abackstrom: God this is perfect. https:\/\/t.co\/qOWUsT0IEM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/qOWUsT0IEM",
        "expanded_url" : "https:\/\/vine.co\/v\/Om79QbvTjLv",
        "display_url" : "vine.co\/v\/Om79QbvTjLv"
      } ]
    },
    "geo" : { },
    "id_str" : "523102124163727360",
    "text" : "God this is perfect. https:\/\/t.co\/qOWUsT0IEM",
    "id" : 523102124163727360,
    "created_at" : "2014-10-17 13:23:59 +0000",
    "user" : {
      "name" : "Annika Backstrom",
      "screen_name" : "abackstrom",
      "protected" : false,
      "id_str" : "3621751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570804205688111104\/zqFjQ3HQ_normal.jpeg",
      "id" : 3621751,
      "verified" : false
    }
  },
  "id" : 523103694330417152,
  "created_at" : "2014-10-17 13:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523103006276222976",
  "geo" : { },
  "id_str" : "523103388452409344",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc also it\u2019s a fun history lesson: a lot of Amherst residents at the time didn\u2019t want those \u201Ccity people\u201D in their areas",
  "id" : 523103388452409344,
  "in_reply_to_status_id" : 523103006276222976,
  "created_at" : "2014-10-17 13:29:01 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523093371595018240",
  "geo" : { },
  "id_str" : "523094354903060480",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc most people who live and grew up here have never taken a bus or subway.",
  "id" : 523094354903060480,
  "in_reply_to_status_id" : 523093371595018240,
  "created_at" : "2014-10-17 12:53:07 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/swy1WscczV",
      "expanded_url" : "http:\/\/metro.nfta.com\/to\/documents\/finalboards.pdf",
      "display_url" : "metro.nfta.com\/to\/documents\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523092039957635072",
  "text" : "It\u2019s fantastic to see the NFTA seriously consider subway\/light rail routes to Amherst: http:\/\/t.co\/swy1WscczV",
  "id" : 523092039957635072,
  "created_at" : "2014-10-17 12:43:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/JPRUNSzMfQ",
      "expanded_url" : "http:\/\/www.introducingcarrot.com\/",
      "display_url" : "introducingcarrot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "522946080481103872",
  "text" : "Introducing Carrot: http:\/\/t.co\/JPRUNSzMfQ",
  "id" : 522946080481103872,
  "created_at" : "2014-10-17 03:03:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522922771202854912",
  "text" : "That's a new one: \"Killed by a boiling potion\"",
  "id" : 522922771202854912,
  "created_at" : "2014-10-17 01:31:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Dale",
      "screen_name" : "tomdale",
      "indices" : [ 0, 8 ],
      "id_str" : "668863",
      "id" : 668863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522903814177701888",
  "geo" : { },
  "id_str" : "522903949423022081",
  "in_reply_to_user_id" : 668863,
  "text" : "@tomdale JINX",
  "id" : 522903949423022081,
  "in_reply_to_status_id" : 522903814177701888,
  "created_at" : "2014-10-17 00:16:31 +0000",
  "in_reply_to_screen_name" : "tomdale",
  "in_reply_to_user_id_str" : "668863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/DBTCd8u2Km",
      "expanded_url" : "https:\/\/github.com\/basecamp\/pow\/issues\/452#issuecomment-59448995",
      "display_url" : "github.com\/basecamp\/pow\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522900194015195136",
  "text" : "\"building reliable and maintainable software is rarely a matter of just merging pull requests\" https:\/\/t.co\/DBTCd8u2Km",
  "id" : 522900194015195136,
  "created_at" : "2014-10-17 00:01:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "522900025576148992",
  "text" : "Published quite a few more guestbook entries on http:\/\/t.co\/7i4fuWxpir",
  "id" : 522900025576148992,
  "created_at" : "2014-10-17 00:00:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522850774397624321",
  "geo" : { },
  "id_str" : "522899120688619520",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick this is great",
  "id" : 522899120688619520,
  "in_reply_to_status_id" : 522850774397624321,
  "created_at" : "2014-10-16 23:57:20 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522842835847233536",
  "geo" : { },
  "id_str" : "522842965639577601",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler burner phone",
  "id" : 522842965639577601,
  "in_reply_to_status_id" : 522842835847233536,
  "created_at" : "2014-10-16 20:14:11 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 14, 22 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/6byRHe944E",
      "expanded_url" : "https:\/\/twitter.com\/rubygems_status\/status\/522816121804558336",
      "display_url" : "twitter.com\/rubygems_statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "522839030119927808",
  "geo" : { },
  "id_str" : "522839418680250368",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder @drbrain looks like it - https:\/\/t.co\/6byRHe944E",
  "id" : 522839418680250368,
  "in_reply_to_status_id" : 522839030119927808,
  "created_at" : "2014-10-16 20:00:05 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sturdy",
      "screen_name" : "OBX2fedex",
      "indices" : [ 0, 10 ],
      "id_str" : "182989805",
      "id" : 182989805
    }, {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 11, 22 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522828014753570816",
  "geo" : { },
  "id_str" : "522833594243231745",
  "in_reply_to_user_id" : 182989805,
  "text" : "@OBX2fedex @bizarchive You won't regret it.",
  "id" : 522833594243231745,
  "in_reply_to_status_id" : 522828014753570816,
  "created_at" : "2014-10-16 19:36:57 +0000",
  "in_reply_to_screen_name" : "OBX2fedex",
  "in_reply_to_user_id_str" : "182989805",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/g2eSiG4glE",
      "expanded_url" : "http:\/\/aqueousband.com",
      "display_url" : "aqueousband.com"
    } ]
  },
  "in_reply_to_status_id_str" : "522823330681081857",
  "geo" : { },
  "id_str" : "522823551741480960",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive excited to tune in! btw have you seen the new http:\/\/t.co\/g2eSiG4glE yet? Check out the setlists page :)",
  "id" : 522823551741480960,
  "in_reply_to_status_id" : 522823330681081857,
  "created_at" : "2014-10-16 18:57:02 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/yhxLrScItm",
      "expanded_url" : "http:\/\/www.buffalonews.com\/gusto\/restaurants\/gene-at-chefs-hes-a-regular-regular-and-has-been-for-at-least-20-years-20141016",
      "display_url" : "buffalonews.com\/gusto\/restaura\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522822331370971136",
  "text" : "Local octogenarian undergoes new treatment where all blood is replaced with parmesan cheese http:\/\/t.co\/yhxLrScItm",
  "id" : 522822331370971136,
  "created_at" : "2014-10-16 18:52:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522816147867971584",
  "text" : "RT @rubygems_status: We're rolling out changes to our SSL configuration today. Please let us know if you have any issues.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522816121804558336",
    "text" : "We're rolling out changes to our SSL configuration today. Please let us know if you have any issues.",
    "id" : 522816121804558336,
    "created_at" : "2014-10-16 18:27:31 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 522816147867971584,
  "created_at" : "2014-10-16 18:27:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522808325193207808",
  "text" : "TIL that Repair is a thing in Pixelmator",
  "id" : 522808325193207808,
  "created_at" : "2014-10-16 17:56:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522803082292252672",
  "text" : "I bet Craig is really good at dad jokes.",
  "id" : 522803082292252672,
  "created_at" : "2014-10-16 17:35:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522800940945268736",
  "text" : "RT @Pinboard: There has been no announcement so far that U2 is not waiting right behind that projection screen and it is frankly making me \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522797111826710528",
    "text" : "There has been no announcement so far that U2 is not waiting right behind that projection screen and it is frankly making me nervous",
    "id" : 522797111826710528,
    "created_at" : "2014-10-16 17:11:59 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 522800940945268736,
  "created_at" : "2014-10-16 17:27:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522796753611808768",
  "text" : "Lots of strange inside jokes in this Apple event.",
  "id" : 522796753611808768,
  "created_at" : "2014-10-16 17:10:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522779609583321088",
  "geo" : { },
  "id_str" : "522779841213382656",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick For functions w\/o a return type you can ignore, but if it has one you have to return.",
  "id" : 522779841213382656,
  "in_reply_to_status_id" : 522779609583321088,
  "created_at" : "2014-10-16 16:03:21 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522779148050513920",
  "geo" : { },
  "id_str" : "522779262147764224",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick it's explicit",
  "id" : 522779262147764224,
  "in_reply_to_status_id" : 522779148050513920,
  "created_at" : "2014-10-16 16:01:03 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522775192183918594",
  "text" : "If colleges replaced Calculus with Time Zone Math, no one would ever graduate",
  "id" : 522775192183918594,
  "created_at" : "2014-10-16 15:44:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Jeremy Horwitz",
      "screen_name" : "horwitz",
      "indices" : [ 12, 20 ],
      "id_str" : "1720771",
      "id" : 1720771
    }, {
      "name" : "Arno Appenzeller",
      "screen_name" : "arno_app",
      "indices" : [ 21, 30 ],
      "id_str" : "49077777",
      "id" : 49077777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522763384282836994",
  "geo" : { },
  "id_str" : "522763858910253056",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @horwitz @arno_app no, they don't.",
  "id" : 522763858910253056,
  "in_reply_to_status_id" : 522763384282836994,
  "created_at" : "2014-10-16 14:59:51 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522760388388339712",
  "geo" : { },
  "id_str" : "522762180421111808",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella oh that's a good enough hack.",
  "id" : 522762180421111808,
  "in_reply_to_status_id" : 522760388388339712,
  "created_at" : "2014-10-16 14:53:10 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522759419826671616",
  "text" : "&lt;BLINK&gt; tags don't seem to work anywhere, people.",
  "id" : 522759419826671616,
  "created_at" : "2014-10-16 14:42:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "522756346517540864",
  "text" : "Added some more guestbook entries on http:\/\/t.co\/7i4fuWxpir",
  "id" : 522756346517540864,
  "created_at" : "2014-10-16 14:30:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522620577299705857",
  "geo" : { },
  "id_str" : "522712780139270144",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits nope",
  "id" : 522712780139270144,
  "in_reply_to_status_id" : 522620577299705857,
  "created_at" : "2014-10-16 11:36:52 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/522603345731530752\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/J7cA1emdCk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Co-R6CMAACv8T.jpg",
      "id_str" : "522603344687149056",
      "id" : 522603344687149056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Co-R6CMAACv8T.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 811,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/J7cA1emdCk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522603345731530752",
  "text" : "Not a good start. http:\/\/t.co\/J7cA1emdCk",
  "id" : 522603345731530752,
  "created_at" : "2014-10-16 04:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 11, 18 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522603086666153984",
  "text" : "Holy crap, @ftrain (or someone) installed NetHack and now it's all over",
  "id" : 522603086666153984,
  "created_at" : "2014-10-16 04:21:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "harper",
      "screen_name" : "harper",
      "indices" : [ 22, 29 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522591173764849664",
  "geo" : { },
  "id_str" : "522601052751671297",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe actually @harper already made one. DONE.",
  "id" : 522601052751671297,
  "in_reply_to_status_id" : 522591173764849664,
  "created_at" : "2014-10-16 04:12:55 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/GkxOdV8aGC",
      "expanded_url" : "http:\/\/tilde.club\/~harper",
      "display_url" : "tilde.club\/~harper"
    } ]
  },
  "geo" : { },
  "id_str" : "522599951134498817",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn http:\/\/t.co\/GkxOdV8aGC",
  "id" : 522599951134498817,
  "created_at" : "2014-10-16 04:08:32 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522591173764849664",
  "geo" : { },
  "id_str" : "522596501571112960",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe Frantically wracking my brain for a bespoke way to do that",
  "id" : 522596501571112960,
  "in_reply_to_status_id" : 522591173764849664,
  "created_at" : "2014-10-16 03:54:50 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FormKeep",
      "screen_name" : "formkeep",
      "indices" : [ 90, 99 ],
      "id_str" : "2724551760",
      "id" : 2724551760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "522595296786673665",
  "text" : "Put 4 guestbook entries up so far on http:\/\/t.co\/7i4fuWxpir. This is a valid use case for @formkeep right?",
  "id" : 522595296786673665,
  "created_at" : "2014-10-16 03:50:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "522589600758251520",
  "text" : "Put a guestbook on http:\/\/t.co\/7i4fuWxpir because why not",
  "id" : 522589600758251520,
  "created_at" : "2014-10-16 03:27:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DigitalOcean",
      "screen_name" : "digitalocean",
      "indices" : [ 29, 42 ],
      "id_str" : "457033547",
      "id" : 457033547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/d8JLRe1uix",
      "expanded_url" : "https:\/\/www.digitalocean.com\/?refcode=2d1532006d25",
      "display_url" : "digitalocean.com\/?refcode=2d153\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522582516394237952",
  "text" : "Can't stress enough how nice @digitalocean has been to work with. Super fast support too. https:\/\/t.co\/d8JLRe1uix",
  "id" : 522582516394237952,
  "created_at" : "2014-10-16 02:59:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Wailin Wong",
      "screen_name" : "VelocityWong",
      "indices" : [ 13, 26 ],
      "id_str" : "15222743",
      "id" : 15222743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522578812836405248",
  "geo" : { },
  "id_str" : "522580011186806784",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide @VelocityWong dohhhhh hohoohohooho",
  "id" : 522580011186806784,
  "in_reply_to_status_id" : 522578812836405248,
  "created_at" : "2014-10-16 02:49:18 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 0, 8 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 9, 20 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 57, 67 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522544403311652864",
  "geo" : { },
  "id_str" : "522544675161272320",
  "in_reply_to_user_id" : 670283,
  "text" : "@drbrain @joshsusser this is a problem in our household. @aquaranto has the soap gene. I do not. put it on everything!",
  "id" : 522544675161272320,
  "in_reply_to_status_id" : 522544403311652864,
  "created_at" : "2014-10-16 00:28:53 +0000",
  "in_reply_to_screen_name" : "drbrain",
  "in_reply_to_user_id_str" : "670283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 0, 10 ],
      "id_str" : "14807622",
      "id" : 14807622
    }, {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 11, 25 ],
      "id_str" : "543918403",
      "id" : 543918403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522501513017851905",
  "geo" : { },
  "id_str" : "522502141500334080",
  "in_reply_to_user_id" : 14807622,
  "text" : "@chazadams @TheDefenseman My bet: Neither.",
  "id" : 522502141500334080,
  "in_reply_to_status_id" : 522501513017851905,
  "created_at" : "2014-10-15 21:39:52 +0000",
  "in_reply_to_screen_name" : "chazadams",
  "in_reply_to_user_id_str" : "14807622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "based kortney \u270A",
      "screen_name" : "fakerapper",
      "indices" : [ 0, 11 ],
      "id_str" : "14256353",
      "id" : 14256353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522498623800492032",
  "geo" : { },
  "id_str" : "522499366452338688",
  "in_reply_to_user_id" : 14256353,
  "text" : "@fakerapper Stickermule. They're the best.",
  "id" : 522499366452338688,
  "in_reply_to_status_id" : 522498623800492032,
  "created_at" : "2014-10-15 21:28:51 +0000",
  "in_reply_to_screen_name" : "fakerapper",
  "in_reply_to_user_id_str" : "14256353",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/g2eSiG4glE",
      "expanded_url" : "http:\/\/aqueousband.com",
      "display_url" : "aqueousband.com"
    } ]
  },
  "in_reply_to_status_id_str" : "522494288114888704",
  "geo" : { },
  "id_str" : "522494599902683136",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky thinking of caching http:\/\/t.co\/g2eSiG4glE out this way. just using CF for assets right now",
  "id" : 522494599902683136,
  "in_reply_to_status_id" : 522494288114888704,
  "created_at" : "2014-10-15 21:09:54 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522493439661707264",
  "geo" : { },
  "id_str" : "522493692855459840",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky how do you handle invalidation on URLs that don't change? like, \/index.html, \/posts\/1, etc",
  "id" : 522493692855459840,
  "in_reply_to_status_id" : 522493439661707264,
  "created_at" : "2014-10-15 21:06:18 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 3, 8 ],
      "id_str" : "23818581",
      "id" : 23818581
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/522488801147772928\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/8RDzjw5CWQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0BAy69CcAEjyXg.jpg",
      "id_str" : "522488800337883137",
      "id" : 522488800337883137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0BAy69CcAEjyXg.jpg",
      "sizes" : [ {
        "h" : 592,
        "resize" : "fit",
        "w" : 1131
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8RDzjw5CWQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/AI4YVskU2K",
      "expanded_url" : "http:\/\/bit.ly\/1tulu9L",
      "display_url" : "bit.ly\/1tulu9L"
    } ]
  },
  "geo" : { },
  "id_str" : "522490756473577472",
  "text" : "RT @VICE: We Interviewed the Filmmaker Behind 'The Whiteness Project' \nhttp:\/\/t.co\/AI4YVskU2K http:\/\/t.co\/8RDzjw5CWQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/522488801147772928\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/8RDzjw5CWQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0BAy69CcAEjyXg.jpg",
        "id_str" : "522488800337883137",
        "id" : 522488800337883137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0BAy69CcAEjyXg.jpg",
        "sizes" : [ {
          "h" : 592,
          "resize" : "fit",
          "w" : 1131
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8RDzjw5CWQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/AI4YVskU2K",
        "expanded_url" : "http:\/\/bit.ly\/1tulu9L",
        "display_url" : "bit.ly\/1tulu9L"
      } ]
    },
    "geo" : { },
    "id_str" : "522488801147772928",
    "text" : "We Interviewed the Filmmaker Behind 'The Whiteness Project' \nhttp:\/\/t.co\/AI4YVskU2K http:\/\/t.co\/8RDzjw5CWQ",
    "id" : 522488801147772928,
    "created_at" : "2014-10-15 20:46:52 +0000",
    "user" : {
      "name" : "VICE",
      "screen_name" : "VICE",
      "protected" : false,
      "id_str" : "23818581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3060284671\/15e9fc92457c5b7633b5378a77b80c26_normal.jpeg",
      "id" : 23818581,
      "verified" : true
    }
  },
  "id" : 522490756473577472,
  "created_at" : "2014-10-15 20:54:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 1, 8 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/3yT2nEs6I3",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/dns-cdn-origin",
      "display_url" : "robots.thoughtbot.com\/dns-cdn-origin"
    } ]
  },
  "geo" : { },
  "id_str" : "522489713840898048",
  "text" : ".@Croaky are you caching entire rails responses or just index.html \/ marketing pages? http:\/\/t.co\/3yT2nEs6I3",
  "id" : 522489713840898048,
  "created_at" : "2014-10-15 20:50:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian Cities",
      "screen_name" : "guardiancities",
      "indices" : [ 3, 18 ],
      "id_str" : "2308445042",
      "id" : 2308445042
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/guardiancities\/status\/522039974695567360\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/rRsab5lLpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ol0OIYAA0tvm.jpg",
      "id_str" : "522039974448095232",
      "id" : 522039974448095232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ol0OIYAA0tvm.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 585,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 585,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/rRsab5lLpf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KF87jB0tcQ",
      "expanded_url" : "http:\/\/gu.com\/p\/4xt37\/tw",
      "display_url" : "gu.com\/p\/4xt37\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "522465714515767296",
  "text" : "RT @guardiancities: The Tour de Neglect: a cycle ride through Buffalo's deprived East Side http:\/\/t.co\/KF87jB0tcQ http:\/\/t.co\/rRsab5lLpf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/guardiancities\/status\/522039974695567360\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/rRsab5lLpf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ol0OIYAA0tvm.jpg",
        "id_str" : "522039974448095232",
        "id" : 522039974448095232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ol0OIYAA0tvm.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 860
        } ],
        "display_url" : "pic.twitter.com\/rRsab5lLpf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/KF87jB0tcQ",
        "expanded_url" : "http:\/\/gu.com\/p\/4xt37\/tw",
        "display_url" : "gu.com\/p\/4xt37\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "522039974695567360",
    "text" : "The Tour de Neglect: a cycle ride through Buffalo's deprived East Side http:\/\/t.co\/KF87jB0tcQ http:\/\/t.co\/rRsab5lLpf",
    "id" : 522039974695567360,
    "created_at" : "2014-10-14 15:03:23 +0000",
    "user" : {
      "name" : "Guardian Cities",
      "screen_name" : "guardiancities",
      "protected" : false,
      "id_str" : "2308445042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564787381216092161\/tWlwk7G8_normal.png",
      "id" : 2308445042,
      "verified" : false
    }
  },
  "id" : 522465714515767296,
  "created_at" : "2014-10-15 19:15:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 4, 10 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/OITJl8ZhYd",
      "expanded_url" : "http:\/\/phish.com\/news\/seattle-santa-barbara-webcasts-announced\/",
      "display_url" : "phish.com\/news\/seattle-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522457204864348160",
  "text" : "The @phish couch tour resumes once again this weekend! http:\/\/t.co\/OITJl8ZhYd",
  "id" : 522457204864348160,
  "created_at" : "2014-10-15 18:41:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "indices" : [ 0, 8 ],
      "id_str" : "20079975",
      "id" : 20079975
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 9, 18 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522454098915131394",
  "geo" : { },
  "id_str" : "522454304347934720",
  "in_reply_to_user_id" : 20079975,
  "text" : "@polotek @anildash it is cringeworthy and makes me embarrassed to live in the same city as these people",
  "id" : 522454304347934720,
  "in_reply_to_status_id" : 522454098915131394,
  "created_at" : "2014-10-15 18:29:47 +0000",
  "in_reply_to_screen_name" : "polotek",
  "in_reply_to_user_id_str" : "20079975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "indices" : [ 10, 18 ],
      "id_str" : "20079975",
      "id" : 20079975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/YTEijhcl3V",
      "expanded_url" : "http:\/\/whitenessproject.org",
      "display_url" : "whitenessproject.org"
    } ]
  },
  "in_reply_to_status_id_str" : "522453076356386816",
  "geo" : { },
  "id_str" : "522453958229368832",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @polotek did you see http:\/\/t.co\/YTEijhcl3V yet?",
  "id" : 522453958229368832,
  "in_reply_to_status_id" : 522453076356386816,
  "created_at" : "2014-10-15 18:28:25 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522450820864831488",
  "text" : "My only superpower is the ability to remember 3 numbers less than or equal to 255 for 5 seconds",
  "id" : 522450820864831488,
  "created_at" : "2014-10-15 18:15:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522450560575086592",
  "geo" : { },
  "id_str" : "522450718918078465",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Pretty sure they have an iOS app! Brown Paper Tickets is good too.",
  "id" : 522450718918078465,
  "in_reply_to_status_id" : 522450560575086592,
  "created_at" : "2014-10-15 18:15:32 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522450356148920320",
  "geo" : { },
  "id_str" : "522450470300696576",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Tito is pretty great.",
  "id" : 522450470300696576,
  "in_reply_to_status_id" : 522450356148920320,
  "created_at" : "2014-10-15 18:14:33 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522442481326362625",
  "geo" : { },
  "id_str" : "522446814507569152",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN hey! No worries. Ship it!",
  "id" : 522446814507569152,
  "in_reply_to_status_id" : 522442481326362625,
  "created_at" : "2014-10-15 18:00:01 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 13, 25 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/FIzMUa0aXM",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ud-ELt558Cg",
      "display_url" : "youtube.com\/watch?v=ud-ELt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522439185349627904",
  "text" : "2nd cut from @AqueousBand's newest - builds and builds until it explodes into a million tiny awesome fragments https:\/\/t.co\/FIzMUa0aXM",
  "id" : 522439185349627904,
  "created_at" : "2014-10-15 17:29:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/QLXjSKz4qd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iTVLJeRQS5c",
      "display_url" : "youtube.com\/watch?v=iTVLJe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522423683151699969",
  "text" : "RT @themcgruff: The U.S. Town with No Cell Towers or Public Wifi:  https:\/\/t.co\/QLXjSKz4qd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QLXjSKz4qd",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iTVLJeRQS5c",
        "display_url" : "youtube.com\/watch?v=iTVLJe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522422989393248256",
    "text" : "The U.S. Town with No Cell Towers or Public Wifi:  https:\/\/t.co\/QLXjSKz4qd",
    "id" : 522422989393248256,
    "created_at" : "2014-10-15 16:25:21 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 522423683151699969,
  "created_at" : "2014-10-15 16:28:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    }, {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 13, 25 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522393884672806913",
  "geo" : { },
  "id_str" : "522394055175467010",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe @kylebragger Yup, check that \"Ops\" section. Listed all the plugins I used and just did the \"Rebuild\" the other night.",
  "id" : 522394055175467010,
  "in_reply_to_status_id" : 522393884672806913,
  "created_at" : "2014-10-15 14:30:23 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 11, 18 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522369756587122688",
  "geo" : { },
  "id_str" : "522377290714324992",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier @bryanl no but \uD83D\uDE29",
  "id" : 522377290714324992,
  "in_reply_to_status_id" : 522369756587122688,
  "created_at" : "2014-10-15 13:23:46 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Beckler",
      "screen_name" : "mbeckler",
      "indices" : [ 0, 9 ],
      "id_str" : "29802591",
      "id" : 29802591
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 10, 23 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522377063748358145",
  "geo" : { },
  "id_str" : "522377218370973696",
  "in_reply_to_user_id" : 29802591,
  "text" : "@mbeckler @steveklabnik you haven\u2019t been following it close enough- they are part of the problem and feeding it.",
  "id" : 522377218370973696,
  "in_reply_to_status_id" : 522377063748358145,
  "created_at" : "2014-10-15 13:23:28 +0000",
  "in_reply_to_screen_name" : "mbeckler",
  "in_reply_to_user_id_str" : "29802591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 25, 35 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/522371353542807553\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/eFYXPDZliO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz_V-dBCQAAG_0V.jpg",
      "id_str" : "522371350715842560",
      "id" : 522371350715842560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz_V-dBCQAAG_0V.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eFYXPDZliO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522371353542807553",
  "text" : "Can confirm the infamous @BreadHive flaming hot Cheetos bagel is as good as it sounds. Tingly! http:\/\/t.co\/eFYXPDZliO",
  "id" : 522371353542807553,
  "created_at" : "2014-10-15 13:00:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/TThBJAmLk1",
      "expanded_url" : "http:\/\/deadspin.com\/the-future-of-the-culture-wars-is-here-and-its-gamerga-1646145844",
      "display_url" : "deadspin.com\/the-future-of-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522364354805510145",
  "text" : "Does this make anyone else not want to play *any* video games for a long time? http:\/\/t.co\/TThBJAmLk1",
  "id" : 522364354805510145,
  "created_at" : "2014-10-15 12:32:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/9AYO09Ugkh",
      "expanded_url" : "http:\/\/www.slideshare.net\/mobile\/RyanMichela\/kicking-the-bukkit-anatomy-of-an-open-source-meltdown",
      "display_url" : "slideshare.net\/mobile\/RyanMic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522353284724834305",
  "text" : "Great deck of why Bukkit failed. Can you imagine this happening to a project in the Ruby or JS ecosystem? http:\/\/t.co\/9AYO09Ugkh",
  "id" : 522353284724834305,
  "created_at" : "2014-10-15 11:48:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli",
      "screen_name" : "EliLanger",
      "indices" : [ 3, 13 ],
      "id_str" : "27388221",
      "id" : 27388221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/CVKpPzi3ud",
      "expanded_url" : "https:\/\/vine.co\/v\/OqO6ppzVDJ9",
      "display_url" : "vine.co\/v\/OqO6ppzVDJ9"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/eJzdfXimTf",
      "expanded_url" : "https:\/\/vine.co\/v\/OqJKZVQami9",
      "display_url" : "vine.co\/v\/OqJKZVQami9"
    } ]
  },
  "geo" : { },
  "id_str" : "522222463204073472",
  "text" : "RT @EliLanger: Vine is an amazing place.\n\n\u2022 Obama impersonator challenges first lady: https:\/\/t.co\/CVKpPzi3ud\n\n\u2022 She responds: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/CVKpPzi3ud",
        "expanded_url" : "https:\/\/vine.co\/v\/OqO6ppzVDJ9",
        "display_url" : "vine.co\/v\/OqO6ppzVDJ9"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/eJzdfXimTf",
        "expanded_url" : "https:\/\/vine.co\/v\/OqJKZVQami9",
        "display_url" : "vine.co\/v\/OqJKZVQami9"
      } ]
    },
    "geo" : { },
    "id_str" : "522197584761614337",
    "text" : "Vine is an amazing place.\n\n\u2022 Obama impersonator challenges first lady: https:\/\/t.co\/CVKpPzi3ud\n\n\u2022 She responds: https:\/\/t.co\/eJzdfXimTf",
    "id" : 522197584761614337,
    "created_at" : "2014-10-15 01:29:40 +0000",
    "user" : {
      "name" : "Eli",
      "screen_name" : "EliLanger",
      "protected" : false,
      "id_str" : "27388221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551036928355995649\/za6xRIrp_normal.jpeg",
      "id" : 27388221,
      "verified" : true
    }
  },
  "id" : 522222463204073472,
  "created_at" : "2014-10-15 03:08:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522134879316627456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9270146348, -78.8770244666 ]
  },
  "id_str" : "522193022600364032",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson what\u2019s next?",
  "id" : 522193022600364032,
  "in_reply_to_status_id" : 522134879316627456,
  "created_at" : "2014-10-15 01:11:33 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 3, 15 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 92, 98 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 99, 114 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/tdHf8U8lTq",
      "expanded_url" : "http:\/\/aqueousband.com",
      "display_url" : "aqueousband.com"
    } ]
  },
  "geo" : { },
  "id_str" : "522107167692709888",
  "text" : "RT @AqueousBand: Check out the new http:\/\/t.co\/tdHf8U8lTq! More updates coming soon! Thanks @qrush @UnclePhilsBlog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 75, 81 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Uncle Phils Blog",
        "screen_name" : "UnclePhilsBlog",
        "indices" : [ 82, 97 ],
        "id_str" : "570452845",
        "id" : 570452845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/tdHf8U8lTq",
        "expanded_url" : "http:\/\/aqueousband.com",
        "display_url" : "aqueousband.com"
      } ]
    },
    "geo" : { },
    "id_str" : "522105840166522881",
    "text" : "Check out the new http:\/\/t.co\/tdHf8U8lTq! More updates coming soon! Thanks @qrush @UnclePhilsBlog",
    "id" : 522105840166522881,
    "created_at" : "2014-10-14 19:25:07 +0000",
    "user" : {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "protected" : false,
      "id_str" : "26904582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567748496355516416\/9YUfd46g_normal.jpeg",
      "id" : 26904582,
      "verified" : false
    }
  },
  "id" : 522107167692709888,
  "created_at" : "2014-10-14 19:30:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 0, 16 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522097906900553728",
  "geo" : { },
  "id_str" : "522099190357180416",
  "in_reply_to_user_id" : 1945604605,
  "text" : "@AlisonBreadHive are any left!!?",
  "id" : 522099190357180416,
  "in_reply_to_status_id" : 522097906900553728,
  "created_at" : "2014-10-14 18:58:41 +0000",
  "in_reply_to_screen_name" : "AlisonBreadHive",
  "in_reply_to_user_id_str" : "1945604605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 3, 13 ],
      "id_str" : "816041347",
      "id" : 816041347
    }, {
      "name" : "Buffalo News Food",
      "screen_name" : "BuffaloFood",
      "indices" : [ 108, 120 ],
      "id_str" : "173551074",
      "id" : 173551074
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/522023074372550656\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/qwU5c0vAjH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ZM8OCUAAOJY_.jpg",
      "id_str" : "522023054424035328",
      "id" : 522023054424035328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ZM8OCUAAOJY_.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qwU5c0vAjH"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/522023074372550656\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/qwU5c0vAjH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ZNrxCUAEszsh.jpg",
      "id_str" : "522023067187302401",
      "id" : 522023067187302401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ZNrxCUAEszsh.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qwU5c0vAjH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522096589049835520",
  "text" : "RT @BreadHive: Also! Today our Flamin' Hot bagel makes its formal debut. 10-6 at 123 Baynes. Looking at you @BuffaloFood http:\/\/t.co\/qwU5c0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo News Food",
        "screen_name" : "BuffaloFood",
        "indices" : [ 93, 105 ],
        "id_str" : "173551074",
        "id" : 173551074
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/522023074372550656\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/qwU5c0vAjH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ZM8OCUAAOJY_.jpg",
        "id_str" : "522023054424035328",
        "id" : 522023054424035328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ZM8OCUAAOJY_.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qwU5c0vAjH"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/BreadHive\/status\/522023074372550656\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/qwU5c0vAjH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz6ZNrxCUAEszsh.jpg",
        "id_str" : "522023067187302401",
        "id" : 522023067187302401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz6ZNrxCUAEszsh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qwU5c0vAjH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "522020308044509184",
    "geo" : { },
    "id_str" : "522023074372550656",
    "in_reply_to_user_id" : 816041347,
    "text" : "Also! Today our Flamin' Hot bagel makes its formal debut. 10-6 at 123 Baynes. Looking at you @BuffaloFood http:\/\/t.co\/qwU5c0vAjH",
    "id" : 522023074372550656,
    "in_reply_to_status_id" : 522020308044509184,
    "created_at" : "2014-10-14 13:56:14 +0000",
    "in_reply_to_screen_name" : "BreadHive",
    "in_reply_to_user_id_str" : "816041347",
    "user" : {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "protected" : false,
      "id_str" : "816041347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459318201117974529\/Pzr0U68v_normal.png",
      "id" : 816041347,
      "verified" : false
    }
  },
  "id" : 522096589049835520,
  "created_at" : "2014-10-14 18:48:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison BreadHive",
      "screen_name" : "AlisonBreadHive",
      "indices" : [ 0, 16 ],
      "id_str" : "1945604605",
      "id" : 1945604605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522094791191191552",
  "geo" : { },
  "id_str" : "522095273162452992",
  "in_reply_to_user_id" : 1945604605,
  "text" : "@AlisonBreadHive it just appeared in my work chat without me pasting it there, so bravo!!! (Is it actually good?)",
  "id" : 522095273162452992,
  "in_reply_to_status_id" : 522094791191191552,
  "created_at" : "2014-10-14 18:43:07 +0000",
  "in_reply_to_screen_name" : "AlisonBreadHive",
  "in_reply_to_user_id_str" : "1945604605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 71, 82 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/59knxdXo6h",
      "expanded_url" : "http:\/\/blog.highrisehq.com\/post\/100000570276\/better-filters-simpler-collaboration-and-a-whole-lot",
      "display_url" : "blog.highrisehq.com\/post\/100000570\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522072656485826562",
  "text" : "RT @jasonfried: Highrise cranking back into high gear. Great work from @natekontny and team \u2014&gt; http:\/\/t.co\/59knxdXo6h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Kontny",
        "screen_name" : "natekontny",
        "indices" : [ 55, 66 ],
        "id_str" : "17386551",
        "id" : 17386551
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/59knxdXo6h",
        "expanded_url" : "http:\/\/blog.highrisehq.com\/post\/100000570276\/better-filters-simpler-collaboration-and-a-whole-lot",
        "display_url" : "blog.highrisehq.com\/post\/100000570\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522066826931748865",
    "text" : "Highrise cranking back into high gear. Great work from @natekontny and team \u2014&gt; http:\/\/t.co\/59knxdXo6h",
    "id" : 522066826931748865,
    "created_at" : "2014-10-14 16:50:05 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 522072656485826562,
  "created_at" : "2014-10-14 17:13:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/1czmVUoue4",
      "expanded_url" : "http:\/\/aqueousband.com\/",
      "display_url" : "aqueousband.com"
    } ]
  },
  "geo" : { },
  "id_str" : "522067544685821952",
  "text" : "Well it's official now, http:\/\/t.co\/1czmVUoue4 has been merged in. Powered on Rails 4, DigitalOcean, and lots of love.",
  "id" : 522067544685821952,
  "created_at" : "2014-10-14 16:52:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 44, 56 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522029252917477377",
  "text" : "So I still have no idea what happened to my @ProductHunt post. :\\",
  "id" : 522029252917477377,
  "created_at" : "2014-10-14 14:20:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521890159105957888",
  "text" : "When can I buy Soylent for sleep?",
  "id" : 521890159105957888,
  "created_at" : "2014-10-14 05:08:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 0, 16 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521831814844133376",
  "geo" : { },
  "id_str" : "521889726543196160",
  "in_reply_to_user_id" : 37885397,
  "text" : "@somethingconcon added an FAQ. Woo!",
  "id" : 521889726543196160,
  "in_reply_to_status_id" : 521831814844133376,
  "created_at" : "2014-10-14 05:06:21 +0000",
  "in_reply_to_screen_name" : "somethingconcon",
  "in_reply_to_user_id_str" : "37885397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521886976258375680",
  "geo" : { },
  "id_str" : "521888664952266752",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Edward of Green Gables",
  "id" : 521888664952266752,
  "in_reply_to_status_id" : 521886976258375680,
  "created_at" : "2014-10-14 05:02:08 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 4, 18 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "521868523522379779",
  "text" : "Put @Carols10cents and one of Pittsburgh's bridges at the center of http:\/\/t.co\/UdW2wpKEjc, because why not!",
  "id" : 521868523522379779,
  "created_at" : "2014-10-14 03:42:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/akAMxTrNqT",
      "expanded_url" : "http:\/\/lparchive.org\/Animal-Crossing\/Update%201\/",
      "display_url" : "lparchive.org\/Animal-Crossin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "521843614385598464",
  "geo" : { },
  "id_str" : "521843825556213760",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove Prepare yourself a heaping bowl of Creepypasta - http:\/\/t.co\/akAMxTrNqT",
  "id" : 521843825556213760,
  "in_reply_to_status_id" : 521843614385598464,
  "created_at" : "2014-10-14 02:03:58 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 97, 104 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 105, 116 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 117, 130 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521843592382279680",
  "text" : "It would be nice if DO would warn droplet owners of security packages that should be updated \/cc @bryanl @samkottler @markimbriaco",
  "id" : 521843592382279680,
  "created_at" : "2014-10-14 02:03:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521837964167774208",
  "geo" : { },
  "id_str" : "521838822431014914",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller whoa wtf! I just started looking this up for the little guy too.",
  "id" : 521838822431014914,
  "in_reply_to_status_id" : 521837964167774208,
  "created_at" : "2014-10-14 01:44:05 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 0, 16 ],
      "id_str" : "37885397",
      "id" : 37885397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/GHfKFSCTcj",
      "expanded_url" : "http:\/\/milliondollarhomepage.com",
      "display_url" : "milliondollarhomepage.com"
    } ]
  },
  "in_reply_to_status_id_str" : "521830915530825728",
  "geo" : { },
  "id_str" : "521831333929037826",
  "in_reply_to_user_id" : 37885397,
  "text" : "@somethingconcon Curious - have you seen http:\/\/t.co\/GHfKFSCTcj before? maybe lacking the nostalgia factor creates doubt",
  "id" : 521831333929037826,
  "in_reply_to_status_id" : 521830915530825728,
  "created_at" : "2014-10-14 01:14:19 +0000",
  "in_reply_to_screen_name" : "somethingconcon",
  "in_reply_to_user_id_str" : "37885397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 0, 16 ],
      "id_str" : "37885397",
      "id" : 37885397
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 17, 24 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521830474713669632",
  "geo" : { },
  "id_str" : "521830725578805248",
  "in_reply_to_user_id" : 37885397,
  "text" : "@somethingconcon @zobar2 That's kind of not the point though. The point is that people find their own causes to donate to.",
  "id" : 521830725578805248,
  "in_reply_to_status_id" : 521830474713669632,
  "created_at" : "2014-10-14 01:11:54 +0000",
  "in_reply_to_screen_name" : "somethingconcon",
  "in_reply_to_user_id_str" : "37885397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521830044830670848",
  "text" : "Also, if a project I threw together in a night or two crashes and burns, that's an acceptable outcome. It's just kind of sad.",
  "id" : 521830044830670848,
  "created_at" : "2014-10-14 01:09:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 0, 16 ],
      "id_str" : "37885397",
      "id" : 37885397
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 17, 24 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521829346680770560",
  "geo" : { },
  "id_str" : "521829891214299136",
  "in_reply_to_user_id" : 37885397,
  "text" : "@somethingconcon @zobar2 Noted, removed the bad links. The latter is intentional.",
  "id" : 521829891214299136,
  "in_reply_to_status_id" : 521829346680770560,
  "created_at" : "2014-10-14 01:08:35 +0000",
  "in_reply_to_screen_name" : "somethingconcon",
  "in_reply_to_user_id_str" : "37885397",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$1M Give Page",
      "screen_name" : "milliongivepage",
      "indices" : [ 11, 27 ],
      "id_str" : "2849337349",
      "id" : 2849337349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521828706877050880",
  "text" : "Ok, posted @milliongivepage to Product Hunt and I have no idea how to find it now that it's posted.",
  "id" : 521828706877050880,
  "created_at" : "2014-10-14 01:03:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellington Cordeiro",
      "screen_name" : "wldcordeiro",
      "indices" : [ 0, 12 ],
      "id_str" : "7244302",
      "id" : 7244302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521817106111672320",
  "geo" : { },
  "id_str" : "521818204302090240",
  "in_reply_to_user_id" : 7244302,
  "text" : "@wldcordeiro Got to maybe #27 and it dropped off.",
  "id" : 521818204302090240,
  "in_reply_to_status_id" : 521817106111672320,
  "created_at" : "2014-10-14 00:22:09 +0000",
  "in_reply_to_screen_name" : "wldcordeiro",
  "in_reply_to_user_id_str" : "7244302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521818016770957312",
  "geo" : { },
  "id_str" : "521818158995222528",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv Yeah, I tried programming and web_design, figured both may have seen it before.",
  "id" : 521818158995222528,
  "in_reply_to_status_id" : 521818016770957312,
  "created_at" : "2014-10-14 00:21:58 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521814525457481728",
  "geo" : { },
  "id_str" : "521815660607725568",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos I was actually thinking about this and doing a hilariously low goal, like $100",
  "id" : 521815660607725568,
  "in_reply_to_status_id" : 521814525457481728,
  "created_at" : "2014-10-14 00:12:03 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/bpemIxxdv4",
      "expanded_url" : "http:\/\/i.imgur.com\/PUka4Cn.gif",
      "display_url" : "i.imgur.com\/PUka4Cn.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "521813689666904064",
  "geo" : { },
  "id_str" : "521814184841846784",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls http:\/\/t.co\/bpemIxxdv4",
  "id" : 521814184841846784,
  "in_reply_to_status_id" : 521813689666904064,
  "created_at" : "2014-10-14 00:06:11 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Defenseman",
      "screen_name" : "TheDefenseman",
      "indices" : [ 0, 14 ],
      "id_str" : "543918403",
      "id" : 543918403
    }, {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 15, 27 ],
      "id_str" : "21283898",
      "id" : 21283898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521812952765435904",
  "geo" : { },
  "id_str" : "521813284224135168",
  "in_reply_to_user_id" : 543918403,
  "text" : "@TheDefenseman @goosesroost ever wanted 2\" of cheese on top of 3 lbs of noodles then be rocked to sleep by Happy Birthday looping forever?",
  "id" : 521813284224135168,
  "in_reply_to_status_id" : 521812952765435904,
  "created_at" : "2014-10-14 00:02:36 +0000",
  "in_reply_to_screen_name" : "TheDefenseman",
  "in_reply_to_user_id_str" : "543918403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521812990769647616",
  "text" : "Biggest complaints from Reddit: 1) Wrong subreddit 2) It looks awful 3) You're just self-promoting. ....:(",
  "id" : 521812990769647616,
  "created_at" : "2014-10-14 00:01:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "521812835177742336",
  "text" : "So http:\/\/t.co\/UdW2wpKEjc seems to have stalled a bit. Reddit just hated on it. Any ideas on how to promote it further?",
  "id" : 521812835177742336,
  "created_at" : "2014-10-14 00:00:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "based kortney \u270A",
      "screen_name" : "fakerapper",
      "indices" : [ 0, 11 ],
      "id_str" : "14256353",
      "id" : 14256353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521808414079332352",
  "geo" : { },
  "id_str" : "521812568369668096",
  "in_reply_to_user_id" : 14256353,
  "text" : "@fakerapper AirBNB helps immensely here.",
  "id" : 521812568369668096,
  "in_reply_to_status_id" : 521808414079332352,
  "created_at" : "2014-10-13 23:59:45 +0000",
  "in_reply_to_screen_name" : "fakerapper",
  "in_reply_to_user_id_str" : "14256353",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    }, {
      "name" : "Trek Glowacki",
      "screen_name" : "trek",
      "indices" : [ 7, 12 ],
      "id_str" : "1291711",
      "id" : 1291711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/HsNhGlTez1",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "521307496078909440",
  "geo" : { },
  "id_str" : "521731451004260352",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan @trek hey, open up an issue on http:\/\/t.co\/HsNhGlTez1 please! All ownership disputes, etc are handled there.",
  "id" : 521731451004260352,
  "in_reply_to_status_id" : 521307496078909440,
  "created_at" : "2014-10-13 18:37:25 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cso2RG8Rrx",
      "expanded_url" : "https:\/\/github.com\/qrush\/LookInside",
      "display_url" : "github.com\/qrush\/LookInsi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521731147785453568",
  "text" : "Reading through the LICENSE.txt leads me to believe I can republish an actual, compiling sample repo from Apple: https:\/\/t.co\/cso2RG8Rrx",
  "id" : 521731147785453568,
  "created_at" : "2014-10-13 18:36:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521730395453554689",
  "geo" : { },
  "id_str" : "521730530983686144",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone Sweet.",
  "id" : 521730530983686144,
  "in_reply_to_status_id" : 521730395453554689,
  "created_at" : "2014-10-13 18:33:46 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521721673192865793",
  "geo" : { },
  "id_str" : "521727578374017024",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone Still confused about this - so it's a web interface to S3 upload?",
  "id" : 521727578374017024,
  "in_reply_to_status_id" : 521721673192865793,
  "created_at" : "2014-10-13 18:22:02 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521718929010745344",
  "geo" : { },
  "id_str" : "521719631476559872",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone what is this?",
  "id" : 521719631476559872,
  "in_reply_to_status_id" : 521718929010745344,
  "created_at" : "2014-10-13 17:50:27 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Frappier",
      "screen_name" : "robfrappier",
      "indices" : [ 0, 12 ],
      "id_str" : "15022686",
      "id" : 15022686
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 13, 22 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521454204565848064",
  "geo" : { },
  "id_str" : "521457240759230464",
  "in_reply_to_user_id" : 15022686,
  "text" : "@robfrappier @shildner in a terrible twist of fate this will end up in my Dropbox tonight due to my IFTTT rules",
  "id" : 521457240759230464,
  "in_reply_to_status_id" : 521454204565848064,
  "created_at" : "2014-10-13 00:27:49 +0000",
  "in_reply_to_screen_name" : "robfrappier",
  "in_reply_to_user_id_str" : "15022686",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 0, 6 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521420163582013442",
  "geo" : { },
  "id_str" : "521421142809001984",
  "in_reply_to_user_id" : 920539489,
  "text" : "@_zzak wtf??",
  "id" : 521421142809001984,
  "in_reply_to_status_id" : 521420163582013442,
  "created_at" : "2014-10-12 22:04:22 +0000",
  "in_reply_to_screen_name" : "_zzak",
  "in_reply_to_user_id_str" : "920539489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 26, 32 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/521273756354760704\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/FzYcuNECio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzvvt6FCEAAUDxo.png",
      "id_str" : "521273753854939136",
      "id" : 521273753854939136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzvvt6FCEAAUDxo.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FzYcuNECio"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521273756354760704",
  "text" : "Now Siri is definitely in @drnic mode with an Australian Male accent. http:\/\/t.co\/FzYcuNECio",
  "id" : 521273756354760704,
  "created_at" : "2014-10-12 12:18:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iRoller",
      "screen_name" : "iroller",
      "indices" : [ 0, 8 ],
      "id_str" : "185605018",
      "id" : 185605018
    }, {
      "name" : "James Daniels",
      "screen_name" : "jamesuriah",
      "indices" : [ 9, 20 ],
      "id_str" : "21390942",
      "id" : 21390942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521173520135372800",
  "geo" : { },
  "id_str" : "521273474375897088",
  "in_reply_to_user_id" : 185605018,
  "text" : "@iroller @jamesuriah I hate you both and add quaranto on Game Center",
  "id" : 521273474375897088,
  "in_reply_to_status_id" : 521173520135372800,
  "created_at" : "2014-10-12 12:17:35 +0000",
  "in_reply_to_screen_name" : "iroller",
  "in_reply_to_user_id_str" : "185605018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/oI2dcxeaOX",
      "expanded_url" : "https:\/\/everyplay.com\/videos\/10250884",
      "display_url" : "everyplay.com\/videos\/10250884"
    } ]
  },
  "geo" : { },
  "id_str" : "521162451849469953",
  "text" : "46.58m, I cannot express how difficult this game is https:\/\/t.co\/oI2dcxeaOX",
  "id" : 521162451849469953,
  "created_at" : "2014-10-12 04:56:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 11, 16 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 37, 53 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521033681562247170",
  "geo" : { },
  "id_str" : "521130618210357248",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @popo yeah sorry, spotted @whentheponydies nearby and the little ones played.",
  "id" : 521130618210357248,
  "in_reply_to_status_id" : 521033681562247170,
  "created_at" : "2014-10-12 02:49:56 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/OwJAbcCTUj",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/10\/11\/opinion\/what-i-saw-as-an-nfl-ball-boy.html",
      "display_url" : "nytimes.com\/2014\/10\/11\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521075143909445632",
  "text" : "I can\u2019t wait until I am old and football is regarded as a savage spectacle http:\/\/t.co\/OwJAbcCTUj",
  "id" : 521075143909445632,
  "created_at" : "2014-10-11 23:09:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clinton Hodnett",
      "screen_name" : "ClintonHodnett",
      "indices" : [ 0, 15 ],
      "id_str" : "2284550997",
      "id" : 2284550997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521065514861596672",
  "geo" : { },
  "id_str" : "521065954831122433",
  "in_reply_to_user_id" : 2284550997,
  "text" : "@ClintonHodnett oh, I think you made a cup of Brazil for me while swatting hornets away. Thanks! \uD83D\uDE01",
  "id" : 521065954831122433,
  "in_reply_to_status_id" : 521065514861596672,
  "created_at" : "2014-10-11 22:32:59 +0000",
  "in_reply_to_screen_name" : "ClintonHodnett",
  "in_reply_to_user_id_str" : "2284550997",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/521044441688055808\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/H0fEB5yEAx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzsfKDVCQAAlUmk.png",
      "id_str" : "521044439444111360",
      "id" : 521044439444111360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzsfKDVCQAAlUmk.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1242,
        "resize" : "fit",
        "w" : 2208
      } ],
      "display_url" : "pic.twitter.com\/H0fEB5yEAx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521044441688055808",
  "text" : "Daddy Long Legs is ridiculous(ly difficult) http:\/\/t.co\/H0fEB5yEAx",
  "id" : 521044441688055808,
  "created_at" : "2014-10-11 21:07:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521010356802830336",
  "geo" : { },
  "id_str" : "521010537921253376",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy huh. The festival is a block down on Allen.",
  "id" : 521010537921253376,
  "in_reply_to_status_id" : 521010356802830336,
  "created_at" : "2014-10-11 18:52:46 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521009772058148864",
  "geo" : { },
  "id_str" : "521010192906211328",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy I didn\u2019t see one but I will keep an eye out",
  "id" : 521010192906211328,
  "in_reply_to_status_id" : 521009772058148864,
  "created_at" : "2014-10-11 18:51:24 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521010073456623617",
  "text" : "Reddit is such an awful place for everything now.",
  "id" : 521010073456623617,
  "created_at" : "2014-10-11 18:50:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 14, 23 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 24, 39 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521007477627052032",
  "geo" : { },
  "id_str" : "521008753785966593",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @LawnMemo @UnclePhilsBlog guitarist from Brown Sugar and forgot who else",
  "id" : 521008753785966593,
  "in_reply_to_status_id" : 521007477627052032,
  "created_at" : "2014-10-11 18:45:41 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 10, 25 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 30, 43 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521006013299048448",
  "geo" : { },
  "id_str" : "521006099844329472",
  "in_reply_to_user_id" : 5743852,
  "text" : "@LawnMemo @UnclePhilsBlog oh, @antelopeezer too. What is this I don\u2019t even",
  "id" : 521006099844329472,
  "in_reply_to_status_id" : 521006013299048448,
  "created_at" : "2014-10-11 18:35:08 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 68, 77 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 78, 93 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521006013299048448",
  "text" : "Funky Bitch &gt; 2001. How did this even happen? Is this real life? @LawnMemo @UnclePhilsBlog why aren\u2019t you here?",
  "id" : 521006013299048448,
  "created_at" : "2014-10-11 18:34:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 21, 36 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521004602251288578",
  "text" : "Allentown Fall Fest, @PublicEspresso brewed fresh, and Phish covers blasted live. \uD83D\uDCAF",
  "id" : 521004602251288578,
  "created_at" : "2014-10-11 18:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/jodbe6Ae9F",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/7VzkhZDEwX1",
      "display_url" : "swarmapp.com\/c\/7VzkhZDEwX1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.899439, -78.872891 ]
  },
  "id_str" : "521000100555149313",
  "text" : "I'm at Allentown Fall Festival in Buffalo, NY https:\/\/t.co\/jodbe6Ae9F",
  "id" : 521000100555149313,
  "created_at" : "2014-10-11 18:11:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Claghorn",
      "screen_name" : "georgeclaghorn",
      "indices" : [ 0, 15 ],
      "id_str" : "35202006",
      "id" : 35202006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520985144619192320",
  "geo" : { },
  "id_str" : "520990971253645312",
  "in_reply_to_user_id" : 35202006,
  "text" : "@georgeclaghorn the real shame is that there aren\u2019t more viable OS options",
  "id" : 520990971253645312,
  "in_reply_to_status_id" : 520985144619192320,
  "created_at" : "2014-10-11 17:35:01 +0000",
  "in_reply_to_screen_name" : "georgeclaghorn",
  "in_reply_to_user_id_str" : "35202006",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 14, 24 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520983029167058944",
  "geo" : { },
  "id_str" : "520986689150279680",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @listrophy knit SJW on it and mail it to him",
  "id" : 520986689150279680,
  "in_reply_to_status_id" : 520983029167058944,
  "created_at" : "2014-10-11 17:18:00 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Arciszewski",
      "screen_name" : "voodooKobra",
      "indices" : [ 0, 12 ],
      "id_str" : "3072959307",
      "id" : 3072959307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520953931653197824",
  "geo" : { },
  "id_str" : "520959256896352257",
  "in_reply_to_user_id" : 340518676,
  "text" : "@voodooKobra because there aren\u2019t any yet!",
  "id" : 520959256896352257,
  "in_reply_to_status_id" : 520953931653197824,
  "created_at" : "2014-10-11 15:29:00 +0000",
  "in_reply_to_screen_name" : "snarkahol",
  "in_reply_to_user_id_str" : "340518676",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FabulousAniyyah",
      "screen_name" : "hnycombinator",
      "indices" : [ 3, 17 ],
      "id_str" : "2560186998",
      "id" : 2560186998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/hKsHo81s0t",
      "expanded_url" : "http:\/\/Tilde.club",
      "display_url" : "Tilde.club"
    }, {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/lbC94g9Dyw",
      "expanded_url" : "http:\/\/bit.ly\/1vfRjmA",
      "display_url" : "bit.ly\/1vfRjmA"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AjeAijdhf9",
      "expanded_url" : "http:\/\/bit.ly\/1qEsmcY",
      "display_url" : "bit.ly\/1qEsmcY"
    } ]
  },
  "geo" : { },
  "id_str" : "520952406348410880",
  "text" : "RT @hnycombinator: Split Off from http:\/\/t.co\/hKsHo81s0t: The Million Dollar Give Page http:\/\/t.co\/lbC94g9Dyw (cmts http:\/\/t.co\/AjeAijdhf9)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/hKsHo81s0t",
        "expanded_url" : "http:\/\/Tilde.club",
        "display_url" : "Tilde.club"
      }, {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/lbC94g9Dyw",
        "expanded_url" : "http:\/\/bit.ly\/1vfRjmA",
        "display_url" : "bit.ly\/1vfRjmA"
      }, {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/AjeAijdhf9",
        "expanded_url" : "http:\/\/bit.ly\/1qEsmcY",
        "display_url" : "bit.ly\/1qEsmcY"
      } ]
    },
    "geo" : { },
    "id_str" : "520949876465881089",
    "text" : "Split Off from http:\/\/t.co\/hKsHo81s0t: The Million Dollar Give Page http:\/\/t.co\/lbC94g9Dyw (cmts http:\/\/t.co\/AjeAijdhf9)",
    "id" : 520949876465881089,
    "created_at" : "2014-10-11 14:51:43 +0000",
    "user" : {
      "name" : "Hacker News YC",
      "screen_name" : "newsycbot",
      "protected" : false,
      "id_str" : "15042473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526110783822774272\/_WLdrxCb_normal.png",
      "id" : 15042473,
      "verified" : false
    }
  },
  "id" : 520952406348410880,
  "created_at" : "2014-10-11 15:01:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Espen Antonsen",
      "screen_name" : "Espen_Antonsen",
      "indices" : [ 0, 15 ],
      "id_str" : "31425464",
      "id" : 31425464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520944033388969984",
  "geo" : { },
  "id_str" : "520952232322547712",
  "in_reply_to_user_id" : 31425464,
  "text" : "@Espen_Antonsen negative to? Confused.",
  "id" : 520952232322547712,
  "in_reply_to_status_id" : 520944033388969984,
  "created_at" : "2014-10-11 15:01:05 +0000",
  "in_reply_to_screen_name" : "Espen_Antonsen",
  "in_reply_to_user_id_str" : "31425464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Espen Antonsen",
      "screen_name" : "Espen_Antonsen",
      "indices" : [ 0, 15 ],
      "id_str" : "31425464",
      "id" : 31425464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520942683041181698",
  "geo" : { },
  "id_str" : "520942888792756224",
  "in_reply_to_user_id" : 31425464,
  "text" : "@Espen_Antonsen quite sure there will be! Sounds great and thanks",
  "id" : 520942888792756224,
  "in_reply_to_status_id" : 520942683041181698,
  "created_at" : "2014-10-11 14:23:58 +0000",
  "in_reply_to_screen_name" : "Espen_Antonsen",
  "in_reply_to_user_id_str" : "31425464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$1M Give Page",
      "screen_name" : "milliongivepage",
      "indices" : [ 10, 26 ],
      "id_str" : "2849337349",
      "id" : 2849337349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520937930144350210",
  "text" : "Submitted @milliongivepage to HN, go upboat on \/newest please! \uD83C\uDD99",
  "id" : 520937930144350210,
  "created_at" : "2014-10-11 14:04:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dimitrios Arethas",
      "screen_name" : "darethas",
      "indices" : [ 0, 9 ],
      "id_str" : "33354539",
      "id" : 33354539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520780354328985600",
  "geo" : { },
  "id_str" : "520780895398014977",
  "in_reply_to_user_id" : 33354539,
  "text" : "@darethas thanks!",
  "id" : 520780895398014977,
  "in_reply_to_status_id" : 520780354328985600,
  "created_at" : "2014-10-11 03:40:15 +0000",
  "in_reply_to_screen_name" : "darethas",
  "in_reply_to_user_id_str" : "33354539",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael F.",
      "screen_name" : "mafellows",
      "indices" : [ 0, 10 ],
      "id_str" : "125434293",
      "id" : 125434293
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 11, 18 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520780386050134016",
  "geo" : { },
  "id_str" : "520780639147024386",
  "in_reply_to_user_id" : 125434293,
  "text" : "@mafellows @soffes nice. Yeah. Basics like implement a Swift UIVC in your app. Focus on the hang ups and errors.",
  "id" : 520780639147024386,
  "in_reply_to_status_id" : 520780386050134016,
  "created_at" : "2014-10-11 03:39:14 +0000",
  "in_reply_to_screen_name" : "mafellows",
  "in_reply_to_user_id_str" : "125434293",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520779715628761088",
  "geo" : { },
  "id_str" : "520780058630164480",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes railscasts did so so many free ones to start though. Not sure. But there is a huge hole for using Swift in real apps",
  "id" : 520780058630164480,
  "in_reply_to_status_id" : 520779715628761088,
  "created_at" : "2014-10-11 03:36:56 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520778795444625408",
  "geo" : { },
  "id_str" : "520779609575403521",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes do this instead.",
  "id" : 520779609575403521,
  "in_reply_to_status_id" : 520778795444625408,
  "created_at" : "2014-10-11 03:35:09 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520772494588780544",
  "geo" : { },
  "id_str" : "520773964885291009",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 it\u2019s still pretty early. Arrived just in time. Check out dokku.",
  "id" : 520773964885291009,
  "in_reply_to_status_id" : 520772494588780544,
  "created_at" : "2014-10-11 03:12:43 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$1M Give Page",
      "screen_name" : "milliongivepage",
      "indices" : [ 3, 19 ],
      "id_str" : "2849337349",
      "id" : 2849337349
    }, {
      "name" : "Dave Rutledge",
      "screen_name" : "_",
      "indices" : [ 48, 50 ],
      "id_str" : "1318181",
      "id" : 1318181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KkqY6gikVP",
      "expanded_url" : "http:\/\/meh.com",
      "display_url" : "meh.com"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/BdHcCMLtQF",
      "expanded_url" : "http:\/\/milliondollargivepage.com",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520762637676597249",
  "text" : "RT @milliongivepage: 1.49% there! Big thanks to @_ and the http:\/\/t.co\/KkqY6gikVP crew for pushing us over 1% http:\/\/t.co\/BdHcCMLtQF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Rutledge",
        "screen_name" : "_",
        "indices" : [ 27, 29 ],
        "id_str" : "1318181",
        "id" : 1318181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/KkqY6gikVP",
        "expanded_url" : "http:\/\/meh.com",
        "display_url" : "meh.com"
      }, {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BdHcCMLtQF",
        "expanded_url" : "http:\/\/milliondollargivepage.com",
        "display_url" : "milliondollargivepage.com"
      } ]
    },
    "geo" : { },
    "id_str" : "520762572681666562",
    "text" : "1.49% there! Big thanks to @_ and the http:\/\/t.co\/KkqY6gikVP crew for pushing us over 1% http:\/\/t.co\/BdHcCMLtQF",
    "id" : 520762572681666562,
    "created_at" : "2014-10-11 02:27:27 +0000",
    "user" : {
      "name" : "$1M Give Page",
      "screen_name" : "milliongivepage",
      "protected" : false,
      "id_str" : "2849337349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520366286396616704\/y661dH83_normal.png",
      "id" : 2849337349,
      "verified" : false
    }
  },
  "id" : 520762637676597249,
  "created_at" : "2014-10-11 02:27:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/gdQRoLcLX8",
      "expanded_url" : "http:\/\/meh.com",
      "display_url" : "meh.com"
    }, {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520755877251264513",
  "text" : "Finally got all of http:\/\/t.co\/gdQRoLcLX8's amazing donations up. Nearing $15,000! http:\/\/t.co\/UdW2wpKEjc",
  "id" : 520755877251264513,
  "created_at" : "2014-10-11 02:00:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RainnWilson",
      "screen_name" : "rainnwilson",
      "indices" : [ 1, 13 ],
      "id_str" : "19637934",
      "id" : 19637934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520748765402001408",
  "text" : ".@rainnwilson is in Galaxy Quest and I can't get over him not being Dwight.",
  "id" : 520748765402001408,
  "created_at" : "2014-10-11 01:32:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 0, 8 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520724277478555648",
  "geo" : { },
  "id_str" : "520724637525614592",
  "in_reply_to_user_id" : 304067888,
  "text" : "@ag_dubs protip: use hair clips instead of the crappy things they give you for stats",
  "id" : 520724637525614592,
  "in_reply_to_status_id" : 520724277478555648,
  "created_at" : "2014-10-10 23:56:42 +0000",
  "in_reply_to_screen_name" : "ag_dubs",
  "in_reply_to_user_id_str" : "304067888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 3, 11 ],
      "id_str" : "33588043",
      "id" : 33588043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Pete716\/status\/520688061706158080\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/qw1ICkWOqZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznbAZLCIAAkBgs.jpg",
      "id_str" : "520688031741648896",
      "id" : 520688031741648896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznbAZLCIAAkBgs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qw1ICkWOqZ"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520688444574429184",
  "text" : "RT @Pete716: #Buffalo http:\/\/t.co\/qw1ICkWOqZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Pete716\/status\/520688061706158080\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/qw1ICkWOqZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BznbAZLCIAAkBgs.jpg",
        "id_str" : "520688031741648896",
        "id" : 520688031741648896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznbAZLCIAAkBgs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qw1ICkWOqZ"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520688061706158080",
    "text" : "#Buffalo http:\/\/t.co\/qw1ICkWOqZ",
    "id" : 520688061706158080,
    "created_at" : "2014-10-10 21:31:22 +0000",
    "user" : {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "protected" : false,
      "id_str" : "33588043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000782125521\/f1b72793d6108a4f03e744730e365811_normal.jpeg",
      "id" : 33588043,
      "verified" : false
    }
  },
  "id" : 520688444574429184,
  "created_at" : "2014-10-10 21:32:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Maguire",
      "screen_name" : "kevmaguire",
      "indices" : [ 3, 14 ],
      "id_str" : "22391203",
      "id" : 22391203
    }, {
      "name" : "Chris Applegate",
      "screen_name" : "qwghlm",
      "indices" : [ 16, 23 ],
      "id_str" : "80363",
      "id" : 80363
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevmaguire\/status\/520534887418560512\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Yebou3hLRv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzlPuLLCQAE_Tx5.png",
      "id_str" : "520534886629654529",
      "id" : 520534886629654529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzlPuLLCQAE_Tx5.png",
      "sizes" : [ {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 814,
        "resize" : "fit",
        "w" : 1426
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Yebou3hLRv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520641468210241536",
  "text" : "RT @kevmaguire: @qwghlm http:\/\/t.co\/Yebou3hLRv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Applegate",
        "screen_name" : "qwghlm",
        "indices" : [ 0, 7 ],
        "id_str" : "80363",
        "id" : 80363
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevmaguire\/status\/520534887418560512\/photo\/1",
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/Yebou3hLRv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzlPuLLCQAE_Tx5.png",
        "id_str" : "520534886629654529",
        "id" : 520534886629654529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzlPuLLCQAE_Tx5.png",
        "sizes" : [ {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 814,
          "resize" : "fit",
          "w" : 1426
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Yebou3hLRv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "520532365287124993",
    "geo" : { },
    "id_str" : "520534887418560512",
    "in_reply_to_user_id" : 80363,
    "text" : "@qwghlm http:\/\/t.co\/Yebou3hLRv",
    "id" : 520534887418560512,
    "in_reply_to_status_id" : 520532365287124993,
    "created_at" : "2014-10-10 11:22:42 +0000",
    "in_reply_to_screen_name" : "qwghlm",
    "in_reply_to_user_id_str" : "80363",
    "user" : {
      "name" : "Kevin Maguire",
      "screen_name" : "kevmaguire",
      "protected" : false,
      "id_str" : "22391203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465512277794648065\/fQD0RXdv_normal.jpeg",
      "id" : 22391203,
      "verified" : false
    }
  },
  "id" : 520641468210241536,
  "created_at" : "2014-10-10 18:26:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya",
      "screen_name" : "divya",
      "indices" : [ 0, 6 ],
      "id_str" : "2954398231",
      "id" : 2954398231
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 7, 18 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520626324260401152",
  "text" : "@divya @ellenchisa first I've heard of the \"levels\" ...*blink*",
  "id" : 520626324260401152,
  "created_at" : "2014-10-10 17:26:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/iN9MobMVJY",
      "expanded_url" : "http:\/\/tilde.club\/~ford\/index.html",
      "display_url" : "tilde.club\/~ford\/index.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520625922563530752",
  "text" : "\"I have some serious obligations to provide for my family and a tendency to prioritize things incorrectly.\" http:\/\/t.co\/iN9MobMVJY Me too.",
  "id" : 520625922563530752,
  "created_at" : "2014-10-10 17:24:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Poland",
      "screen_name" : "tylerpoland",
      "indices" : [ 0, 12 ],
      "id_str" : "56105138",
      "id" : 56105138
    }, {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 13, 20 ],
      "id_str" : "10696812",
      "id" : 10696812
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520616944698142720",
  "geo" : { },
  "id_str" : "520617755520032768",
  "in_reply_to_user_id" : 56105138,
  "text" : "@tylerpoland @kevdog if you worked from @coworkbuffalo on Fridays all these would be possible and more",
  "id" : 520617755520032768,
  "in_reply_to_status_id" : 520616944698142720,
  "created_at" : "2014-10-10 16:52:00 +0000",
  "in_reply_to_screen_name" : "tylerpoland",
  "in_reply_to_user_id_str" : "56105138",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 1, 15 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520615712193544192\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/FsCHarxf1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzmZOtRIIAA-c9u.png",
      "id_str" : "520615709886652416",
      "id" : 520615709886652416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzmZOtRIIAA-c9u.png",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/FsCHarxf1F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520615712193544192",
  "text" : ".@PhilDarnowsky answering those hard hitting questions http:\/\/t.co\/FsCHarxf1F",
  "id" : 520615712193544192,
  "created_at" : "2014-10-10 16:43:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Richter",
      "screen_name" : "kylerichter",
      "indices" : [ 3, 15 ],
      "id_str" : "16410852",
      "id" : 16410852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kylerichter\/status\/520582263306993665\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Gdh83ripAp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzl6z02CQAEp5Ma.png",
      "id_str" : "520582262715203585",
      "id" : 520582262715203585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzl6z02CQAEp5Ma.png",
      "sizes" : [ {
        "h" : 1348,
        "resize" : "fit",
        "w" : 949
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1348,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Gdh83ripAp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520615297389461504",
  "text" : "RT @kylerichter: Apple really has made tremendous leaps forward in job security lately. http:\/\/t.co\/Gdh83ripAp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kylerichter\/status\/520582263306993665\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/Gdh83ripAp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzl6z02CQAEp5Ma.png",
        "id_str" : "520582262715203585",
        "id" : 520582262715203585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzl6z02CQAEp5Ma.png",
        "sizes" : [ {
          "h" : 1348,
          "resize" : "fit",
          "w" : 949
        }, {
          "h" : 851,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1348,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Gdh83ripAp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520582263306993665",
    "text" : "Apple really has made tremendous leaps forward in job security lately. http:\/\/t.co\/Gdh83ripAp",
    "id" : 520582263306993665,
    "created_at" : "2014-10-10 14:30:58 +0000",
    "user" : {
      "name" : "Kyle Richter",
      "screen_name" : "kylerichter",
      "protected" : false,
      "id_str" : "16410852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000665162587\/a700ea2df2d332a183fd9ba964f34719_normal.jpeg",
      "id" : 16410852,
      "verified" : false
    }
  },
  "id" : 520615297389461504,
  "created_at" : "2014-10-10 16:42:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 26, 38 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/NFa0adLGCu",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/62lqWWuAGZx",
      "display_url" : "swarmapp.com\/c\/62lqWWuAGZx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.883906392, -78.8746857711 ]
  },
  "id_str" : "520614824825606144",
  "text" : "I'm at Lloyd Taco Truck - @whereslloyd in Buffalo, NY https:\/\/t.co\/NFa0adLGCu",
  "id" : 520614824825606144,
  "created_at" : "2014-10-10 16:40:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 1, 13 ],
      "id_str" : "588743",
      "id" : 588743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/w3zNxLwkZi",
      "expanded_url" : "http:\/\/www.boredpanda.com\/cat-ear-heaphones-axent-wear\/",
      "display_url" : "boredpanda.com\/cat-ear-heapho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520602862686978048",
  "text" : ".@antiheroine your next purchase? http:\/\/t.co\/w3zNxLwkZi",
  "id" : 520602862686978048,
  "created_at" : "2014-10-10 15:52:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 143, 144 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 144 ],
      "url" : "http:\/\/t.co\/xxdCnX4iNm",
      "expanded_url" : "http:\/\/www.whitenessproject.org\/",
      "display_url" : "whitenessproject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "520597804087926784",
  "text" : "RT @ChristineLSloc: A very naked look at how white people (in Buffalo!) view being white and race relations. Watch &amp; cringe http:\/\/t.co\/xxd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 135, 141 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/xxdCnX4iNm",
        "expanded_url" : "http:\/\/www.whitenessproject.org\/",
        "display_url" : "whitenessproject.org"
      } ]
    },
    "geo" : { },
    "id_str" : "520594783648382977",
    "text" : "A very naked look at how white people (in Buffalo!) view being white and race relations. Watch &amp; cringe http:\/\/t.co\/xxdCnX4iNm h\/t @qrush",
    "id" : 520594783648382977,
    "created_at" : "2014-10-10 15:20:43 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 520597804087926784,
  "created_at" : "2014-10-10 15:32:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 25, 34 ],
      "id_str" : "1051521",
      "id" : 1051521
    }, {
      "name" : "Michael Berger",
      "screen_name" : "bergatron",
      "indices" : [ 35, 45 ],
      "id_str" : "15517749",
      "id" : 15517749
    }, {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 46, 55 ],
      "id_str" : "16225196",
      "id" : 16225196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520584436027756544",
  "geo" : { },
  "id_str" : "520591663110963200",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier go say hi to @migreyes @bergatron @shildner",
  "id" : 520591663110963200,
  "in_reply_to_status_id" : 520584436027756544,
  "created_at" : "2014-10-10 15:08:19 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 3, 10 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520590738526969857",
  "text" : "RT @nathos: @qrush I am both appalled and completely unsurprised by all of these videos.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "520585960241655808",
    "geo" : { },
    "id_str" : "520590650044338176",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush I am both appalled and completely unsurprised by all of these videos.",
    "id" : 520590650044338176,
    "in_reply_to_status_id" : 520585960241655808,
    "created_at" : "2014-10-10 15:04:17 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "protected" : false,
      "id_str" : "34953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570421723984429056\/SiXp3XlU_normal.jpeg",
      "id" : 34953,
      "verified" : false
    }
  },
  "id" : 520590738526969857,
  "created_at" : "2014-10-10 15:04:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520588869134077953",
  "geo" : { },
  "id_str" : "520590521358495744",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck agreed",
  "id" : 520590521358495744,
  "in_reply_to_status_id" : 520588869134077953,
  "created_at" : "2014-10-10 15:03:47 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/93wxM0x59m",
      "expanded_url" : "http:\/\/www.whitenessproject.org",
      "display_url" : "whitenessproject.org"
    }, {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/j6dHIEoBWb",
      "expanded_url" : "http:\/\/www.two-toneproductions.com\/about-us\/",
      "display_url" : "two-toneproductions.com\/about-us\/"
    } ]
  },
  "geo" : { },
  "id_str" : "520587631780851712",
  "text" : "So http:\/\/t.co\/93wxM0x59m is a project of http:\/\/t.co\/j6dHIEoBWb, but the videos are still horrifying. :(",
  "id" : 520587631780851712,
  "created_at" : "2014-10-10 14:52:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520587394496876546",
  "geo" : { },
  "id_str" : "520587441221013504",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc It's that.",
  "id" : 520587441221013504,
  "in_reply_to_status_id" : 520587394496876546,
  "created_at" : "2014-10-10 14:51:32 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520587312468873216",
  "geo" : { },
  "id_str" : "520587386699255808",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc glad to hear, but these videos are cringeworthy",
  "id" : 520587386699255808,
  "in_reply_to_status_id" : 520587312468873216,
  "created_at" : "2014-10-10 14:51:19 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellington Cordeiro",
      "screen_name" : "wldcordeiro",
      "indices" : [ 3, 15 ],
      "id_str" : "7244302",
      "id" : 7244302
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/TT5DOCjTl3",
      "expanded_url" : "http:\/\/www.two-toneproductions.com\/about-us\/",
      "display_url" : "two-toneproductions.com\/about-us\/"
    } ]
  },
  "geo" : { },
  "id_str" : "520586563621646337",
  "text" : "RT @wldcordeiro: @qrush Looking up the creators of this project I found http:\/\/t.co\/TT5DOCjTl3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/TT5DOCjTl3",
        "expanded_url" : "http:\/\/www.two-toneproductions.com\/about-us\/",
        "display_url" : "two-toneproductions.com\/about-us\/"
      } ]
    },
    "in_reply_to_status_id_str" : "520583549615742976",
    "geo" : { },
    "id_str" : "520586356943110144",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Looking up the creators of this project I found http:\/\/t.co\/TT5DOCjTl3",
    "id" : 520586356943110144,
    "in_reply_to_status_id" : 520583549615742976,
    "created_at" : "2014-10-10 14:47:14 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Wellington Cordeiro",
      "screen_name" : "wldcordeiro",
      "protected" : false,
      "id_str" : "7244302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572255170022653952\/BkwrrnPc_normal.jpeg",
      "id" : 7244302,
      "verified" : false
    }
  },
  "id" : 520586563621646337,
  "created_at" : "2014-10-10 14:48:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520585960241655808",
  "text" : "I can't even finish one of these videos. Holy crap. Why is this even a thing?",
  "id" : 520585960241655808,
  "created_at" : "2014-10-10 14:45:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/QEDMMssHs9",
      "expanded_url" : "http:\/\/www.whitenessproject.org\/",
      "display_url" : "whitenessproject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "520583549615742976",
  "text" : "What. In. The. Fuck? http:\/\/t.co\/QEDMMssHs9",
  "id" : 520583549615742976,
  "created_at" : "2014-10-10 14:36:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "indices" : [ 3, 14 ],
      "id_str" : "272230417",
      "id" : 272230417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/gXAI3a13Re",
      "expanded_url" : "http:\/\/www.whitenessproject.org",
      "display_url" : "whitenessproject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "520583473262628864",
  "text" : "RT @phildzikiy: http:\/\/t.co\/gXAI3a13Re\n\n\"White people in Buffalo, NY, talk about race.\"\n\nGuys help me I don't know if this is real it seems\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/gXAI3a13Re",
        "expanded_url" : "http:\/\/www.whitenessproject.org",
        "display_url" : "whitenessproject.org"
      } ]
    },
    "geo" : { },
    "id_str" : "520583078100889600",
    "text" : "http:\/\/t.co\/gXAI3a13Re\n\n\"White people in Buffalo, NY, talk about race.\"\n\nGuys help me I don't know if this is real it seems like it is",
    "id" : 520583078100889600,
    "created_at" : "2014-10-10 14:34:12 +0000",
    "user" : {
      "name" : "Phil Dzikiy",
      "screen_name" : "phildzikiy",
      "protected" : false,
      "id_str" : "272230417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541986164820164608\/DPmTqylp_normal.jpeg",
      "id" : 272230417,
      "verified" : false
    }
  },
  "id" : 520583473262628864,
  "created_at" : "2014-10-10 14:35:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Hill-Ries",
      "screen_name" : "evanhr",
      "indices" : [ 3, 10 ],
      "id_str" : "9366062",
      "id" : 9366062
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 115, 122 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/EROZRMa5Yo",
      "expanded_url" : "https:\/\/medium.com\/@ftrain\/a8904f0a2ebf?source=tw-lo_f0fba59abbf6-1412949178104",
      "display_url" : "medium.com\/@ftrain\/a8904f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520577697349513218",
  "text" : "RT @evanhr: \u201CThe modern social web is a miracle of progress but also a status-driven guilt-spewing shit volcano.\u201D \u2014@ftrain https:\/\/t.co\/ERO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Ford",
        "screen_name" : "ftrain",
        "indices" : [ 103, 110 ],
        "id_str" : "6981492",
        "id" : 6981492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/EROZRMa5Yo",
        "expanded_url" : "https:\/\/medium.com\/@ftrain\/a8904f0a2ebf?source=tw-lo_f0fba59abbf6-1412949178104",
        "display_url" : "medium.com\/@ftrain\/a8904f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520572790819155968",
    "text" : "\u201CThe modern social web is a miracle of progress but also a status-driven guilt-spewing shit volcano.\u201D \u2014@ftrain https:\/\/t.co\/EROZRMa5Yo",
    "id" : 520572790819155968,
    "created_at" : "2014-10-10 13:53:19 +0000",
    "user" : {
      "name" : "Evan Hill-Ries",
      "screen_name" : "evanhr",
      "protected" : false,
      "id_str" : "9366062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000478445150\/306f5bbbab1554f49a688aae5ebbbb25_normal.jpeg",
      "id" : 9366062,
      "verified" : false
    }
  },
  "id" : 520577697349513218,
  "created_at" : "2014-10-10 14:12:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520422830588973056",
  "geo" : { },
  "id_str" : "520423245762154496",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove Bar special: Spirit J\u00E4gerbombs",
  "id" : 520423245762154496,
  "in_reply_to_status_id" : 520422830588973056,
  "created_at" : "2014-10-10 03:59:05 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Snow",
      "screen_name" : "kwsnow",
      "indices" : [ 0, 7 ],
      "id_str" : "24898553",
      "id" : 24898553
    }, {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 8, 15 ],
      "id_str" : "15964196",
      "id" : 15964196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520420760842563585",
  "geo" : { },
  "id_str" : "520421107296247808",
  "in_reply_to_user_id" : 5743852,
  "text" : "@kwsnow @ckanal then again this could just be me \uD83D\uDE01\uD83D\uDCF6",
  "id" : 520421107296247808,
  "in_reply_to_status_id" : 520420760842563585,
  "created_at" : "2014-10-10 03:50:35 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Snow",
      "screen_name" : "kwsnow",
      "indices" : [ 0, 7 ],
      "id_str" : "24898553",
      "id" : 24898553
    }, {
      "name" : "Craig Kanalley",
      "screen_name" : "ckanal",
      "indices" : [ 8, 15 ],
      "id_str" : "15964196",
      "id" : 15964196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/AgXzKXk7W8",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Chartjunk",
      "display_url" : "en.wikipedia.org\/wiki\/Chartjunk"
    } ]
  },
  "in_reply_to_status_id_str" : "520418958621806592",
  "geo" : { },
  "id_str" : "520420760842563585",
  "in_reply_to_user_id" : 24898553,
  "text" : "@kwsnow @ckanal more info. Data to ink ratio is way, way low.  https:\/\/t.co\/AgXzKXk7W8",
  "id" : 520420760842563585,
  "in_reply_to_status_id" : 520418958621806592,
  "created_at" : "2014-10-10 03:49:12 +0000",
  "in_reply_to_screen_name" : "kwsnow",
  "in_reply_to_user_id_str" : "24898553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/MuIC7SOxqX",
      "expanded_url" : "https:\/\/medium.com\/message\/tilde-club-i-had-a-couple-drinks-and-woke-up-with-1-000-nerds-a8904f0a2ebf",
      "display_url" : "medium.com\/message\/tilde-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "520412119146463232",
  "geo" : { },
  "id_str" : "520412756999032833",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle jokes are hard. See https:\/\/t.co\/MuIC7SOxqX",
  "id" : 520412756999032833,
  "in_reply_to_status_id" : 520412119146463232,
  "created_at" : "2014-10-10 03:17:24 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "520407727009316865",
  "text" : "&lt;FRAMESET&gt; still works great. Why do we use CSS anyway? http:\/\/t.co\/7i4fuWxpir",
  "id" : 520407727009316865,
  "created_at" : "2014-10-10 02:57:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 3, 10 ],
      "id_str" : "765548",
      "id" : 765548
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hmason\/status\/520367337925390337\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/v8iVq6Hjar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzi3VbvCUAEy7vF.jpg",
      "id_str" : "520367335811469313",
      "id" : 520367335811469313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzi3VbvCUAEy7vF.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/v8iVq6Hjar"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520403236730048512",
  "text" : "RT @hmason: TIL that the phrase software \"patch\" is from a physical patch applied to Mark 1 paper tape to modify the program. http:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hmason\/status\/520367337925390337\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/v8iVq6Hjar",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzi3VbvCUAEy7vF.jpg",
        "id_str" : "520367335811469313",
        "id" : 520367335811469313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzi3VbvCUAEy7vF.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/v8iVq6Hjar"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520367337925390337",
    "text" : "TIL that the phrase software \"patch\" is from a physical patch applied to Mark 1 paper tape to modify the program. http:\/\/t.co\/v8iVq6Hjar",
    "id" : 520367337925390337,
    "created_at" : "2014-10-10 00:16:55 +0000",
    "user" : {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "protected" : false,
      "id_str" : "765548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290564266\/me_square_normal.jpg",
      "id" : 765548,
      "verified" : false
    }
  },
  "id" : 520403236730048512,
  "created_at" : "2014-10-10 02:39:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/GbH8mf2eHD",
      "expanded_url" : "http:\/\/roarmag.org\/2014\/10\/loukanikos-riot-dog-dies\/",
      "display_url" : "roarmag.org\/2014\/10\/loukan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520401679749898240",
  "text" : "RT @steveklabnik: Nooooooo Loukanikos \uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D http:\/\/t.co\/GbH8mf2eHD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/GbH8mf2eHD",
        "expanded_url" : "http:\/\/roarmag.org\/2014\/10\/loukanikos-riot-dog-dies\/",
        "display_url" : "roarmag.org\/2014\/10\/loukan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520401392109092864",
    "text" : "Nooooooo Loukanikos \uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D http:\/\/t.co\/GbH8mf2eHD",
    "id" : 520401392109092864,
    "created_at" : "2014-10-10 02:32:15 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 520401679749898240,
  "created_at" : "2014-10-10 02:33:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520376775222640641",
  "geo" : { },
  "id_str" : "520376860333457413",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Just do the same thing and have a sign \"Me in less than 9 months\"",
  "id" : 520376860333457413,
  "in_reply_to_status_id" : 520376775222640641,
  "created_at" : "2014-10-10 00:54:46 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520374705841532928",
  "geo" : { },
  "id_str" : "520374996938420224",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik it's been pretty fun :)",
  "id" : 520374996938420224,
  "in_reply_to_status_id" : 520374705841532928,
  "created_at" : "2014-10-10 00:47:22 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "$1M Give Page",
      "screen_name" : "milliongivepage",
      "indices" : [ 46, 62 ],
      "id_str" : "2849337349",
      "id" : 2849337349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/JI0mYd1CRX",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520367465776168962",
  "text" : "Set up a Twitter for http:\/\/t.co\/JI0mYd1CRX - @milliongivepage",
  "id" : 520367465776168962,
  "created_at" : "2014-10-10 00:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 76, 82 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520364621408903168",
  "text" : "Change your Siri voice settings to English (Australian) Male, and it's like @drnic is reading all of my email to me",
  "id" : 520364621408903168,
  "created_at" : "2014-10-10 00:06:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520346057344286720",
  "text" : "RT @rubygems_status: We're having some server issues at the moment. Working to restore the website and api.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520340547513229312",
    "text" : "We're having some server issues at the moment. Working to restore the website and api.",
    "id" : 520340547513229312,
    "created_at" : "2014-10-09 22:30:28 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 520346057344286720,
  "created_at" : "2014-10-09 22:52:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/ZQa7P6BMsX",
      "expanded_url" : "http:\/\/milliondollargivepage.com",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "in_reply_to_status_id_str" : "520330207694454784",
  "geo" : { },
  "id_str" : "520332977473994753",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos it\u2019s for http:\/\/t.co\/ZQa7P6BMsX I need to make another account for this",
  "id" : 520332977473994753,
  "in_reply_to_status_id" : 520330207694454784,
  "created_at" : "2014-10-09 22:00:23 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520328399995559936",
  "geo" : { },
  "id_str" : "520328503284486144",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard POGS?",
  "id" : 520328503284486144,
  "in_reply_to_status_id" : 520328399995559936,
  "created_at" : "2014-10-09 21:42:37 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ZQa7P6BMsX",
      "expanded_url" : "http:\/\/milliondollargivepage.com",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "in_reply_to_status_id_str" : "520328115890163713",
  "geo" : { },
  "id_str" : "520328221410086912",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard http:\/\/t.co\/ZQa7P6BMsX",
  "id" : 520328221410086912,
  "in_reply_to_status_id" : 520328115890163713,
  "created_at" : "2014-10-09 21:41:29 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520325588507443202",
  "text" : "Just had nearly $10,000 come in. Holy wow.",
  "id" : 520325588507443202,
  "created_at" : "2014-10-09 21:31:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Williams",
      "screen_name" : "j_m_williams",
      "indices" : [ 0, 13 ],
      "id_str" : "16210953",
      "id" : 16210953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520303218962624513",
  "geo" : { },
  "id_str" : "520303359601815553",
  "in_reply_to_user_id" : 16210953,
  "text" : "@j_m_williams maybe we can do a sort eventually. Say no to features :P",
  "id" : 520303359601815553,
  "in_reply_to_status_id" : 520303218962624513,
  "created_at" : "2014-10-09 20:02:42 +0000",
  "in_reply_to_screen_name" : "j_m_williams",
  "in_reply_to_user_id_str" : "16210953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anonymous man #3",
      "screen_name" : "beaugunderson",
      "indices" : [ 49, 63 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "David Janke",
      "screen_name" : "numberMumbler",
      "indices" : [ 64, 78 ],
      "id_str" : "21229689",
      "id" : 21229689
    }, {
      "name" : "Dave Rutledge",
      "screen_name" : "_",
      "indices" : [ 79, 81 ],
      "id_str" : "1318181",
      "id" : 1318181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/6kKr3UMmeT",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/pixellist.html",
      "display_url" : "milliondollargivepage.com\/pixellist.html"
    } ]
  },
  "geo" : { },
  "id_str" : "520302878410276864",
  "text" : "Donation list up - http:\/\/t.co\/6kKr3UMmeT thanks @beaugunderson @numberMumbler @_ for being early adopters!",
  "id" : 520302878410276864,
  "created_at" : "2014-10-09 20:00:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federico Reiven",
      "screen_name" : "ravenio",
      "indices" : [ 0, 8 ],
      "id_str" : "111408685",
      "id" : 111408685
    }, {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 9, 18 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520285685010661376",
  "geo" : { },
  "id_str" : "520286235349483520",
  "in_reply_to_user_id" : 111408685,
  "text" : "@ravenio @ralphbod Our third donation was BTC. Really it can be in anything. Will clarify.",
  "id" : 520286235349483520,
  "in_reply_to_status_id" : 520285685010661376,
  "created_at" : "2014-10-09 18:54:39 +0000",
  "in_reply_to_screen_name" : "ravenio",
  "in_reply_to_user_id_str" : "111408685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 24, 36 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/TvU6Ki7r0Y",
      "expanded_url" : "http:\/\/liveforlivemusic.com\/album-reviews\/aqueous-cycles-album-review\/",
      "display_url" : "liveforlivemusic.com\/album-reviews\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520284387746013185",
  "text" : "Great review of the new @AqueousBand album: http:\/\/t.co\/TvU6Ki7r0Y",
  "id" : 520284387746013185,
  "created_at" : "2014-10-09 18:47:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520263454825779200",
  "text" : "Ok, so we're 0.53% into http:\/\/t.co\/UdW2wpKEjc Much higher than I thought this would go. Who's next?",
  "id" : 520263454825779200,
  "created_at" : "2014-10-09 17:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520243771032629249",
  "text" : "Just a $5000 donation come across, working on getting a list of orgs donated to next. Whoa! http:\/\/t.co\/UdW2wpKEjc",
  "id" : 520243771032629249,
  "created_at" : "2014-10-09 16:05:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/MuIC7SOxqX",
      "expanded_url" : "https:\/\/medium.com\/message\/tilde-club-i-had-a-couple-drinks-and-woke-up-with-1-000-nerds-a8904f0a2ebf",
      "display_url" : "medium.com\/message\/tilde-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520216116124061697",
  "text" : "\"Honestly, though, for something like this\u200A\u2014\u200Adoes it matter?\" https:\/\/t.co\/MuIC7SOxqX (Should be asking this about everything)",
  "id" : 520216116124061697,
  "created_at" : "2014-10-09 14:16:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 20, 27 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UdW2wpKEjc",
      "expanded_url" : "http:\/\/milliondollargivepage.com\/",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520213643581849600",
  "text" : "Also, big thanks to @ftrain for just saying \"yes\" to mostly crazy ideas, including http:\/\/t.co\/UdW2wpKEjc",
  "id" : 520213643581849600,
  "created_at" : "2014-10-09 14:06:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Staudt",
      "screen_name" : "k0raktor",
      "indices" : [ 0, 9 ],
      "id_str" : "35310474",
      "id" : 35310474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520143058663665664",
  "geo" : { },
  "id_str" : "520213112318738432",
  "in_reply_to_user_id" : 35310474,
  "text" : "@k0raktor it's Caverna",
  "id" : 520213112318738432,
  "in_reply_to_status_id" : 520143058663665664,
  "created_at" : "2014-10-09 14:04:05 +0000",
  "in_reply_to_screen_name" : "k0raktor",
  "in_reply_to_user_id_str" : "35310474",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/PoyxiYSKuD",
      "expanded_url" : "http:\/\/milliondollargivepage.com",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520205369646530560",
  "text" : "Striking out to its own domain: http:\/\/t.co\/PoyxiYSKuD (now with less tildes!) Who\u2019s next to give?",
  "id" : 520205369646530560,
  "created_at" : "2014-10-09 13:33:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520077178893922304",
  "text" : "In the meantime ~qrush 3.0 will have to wait.",
  "id" : 520077178893922304,
  "created_at" : "2014-10-09 05:03:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 10, 16 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/d2CaUdyqZo",
      "expanded_url" : "http:\/\/tilde.club",
      "display_url" : "tilde.club"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ZQa7P5KZ4L",
      "expanded_url" : "http:\/\/milliondollargivepage.com",
      "display_url" : "milliondollargivepage.com"
    } ]
  },
  "geo" : { },
  "id_str" : "520077062392918016",
  "text" : "Thanks to @jfine for a domain, let\u2019s see if this goes anywhere now it\u2019s graduated from http:\/\/t.co\/d2CaUdyqZo: http:\/\/t.co\/ZQa7P5KZ4L",
  "id" : 520077062392918016,
  "created_at" : "2014-10-09 05:03:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 3, 7 ],
      "id_str" : "5523",
      "id" : 5523
    }, {
      "name" : "Adria Richards",
      "screen_name" : "adriarichards",
      "indices" : [ 22, 36 ],
      "id_str" : "14268164",
      "id" : 14268164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/69CrSTI8Qi",
      "expanded_url" : "https:\/\/storify.com\/adriarichards\/telling-my-troll-story-because-kathy-sierra-left-t",
      "display_url" : "storify.com\/adriarichards\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520075606151540736",
  "text" : "RT @pat: Appreciating @adriarichards' bravery in sharing her story (and not backing down!): https:\/\/t.co\/69CrSTI8Qi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adria Richards",
        "screen_name" : "adriarichards",
        "indices" : [ 13, 27 ],
        "id_str" : "14268164",
        "id" : 14268164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/69CrSTI8Qi",
        "expanded_url" : "https:\/\/storify.com\/adriarichards\/telling-my-troll-story-because-kathy-sierra-left-t",
        "display_url" : "storify.com\/adriarichards\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520073103041634304",
    "text" : "Appreciating @adriarichards' bravery in sharing her story (and not backing down!): https:\/\/t.co\/69CrSTI8Qi",
    "id" : 520073103041634304,
    "created_at" : "2014-10-09 04:47:44 +0000",
    "user" : {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "protected" : false,
      "id_str" : "5523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475943177833050112\/KVAIzJUb_normal.png",
      "id" : 5523,
      "verified" : false
    }
  },
  "id" : 520075606151540736,
  "created_at" : "2014-10-09 04:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520071937842634752",
  "text" : "To everyone wondering: it\u2019s Caverna.",
  "id" : 520071937842634752,
  "created_at" : "2014-10-09 04:43:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520056562027888641",
  "geo" : { },
  "id_str" : "520071688956829696",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig it\u2019s more a mix of Ora and Agricola. Really enjoyed it, the amount of pieces is staggering though",
  "id" : 520071688956829696,
  "in_reply_to_status_id" : 520056562027888641,
  "created_at" : "2014-10-09 04:42:07 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520064309468987392\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Qa3Z3LNM6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzeju0YCcAEU3_g.jpg",
      "id_str" : "520064306713358337",
      "id" : 520064306713358337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzeju0YCcAEU3_g.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Qa3Z3LNM6K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520064309468987392",
  "text" : "Ended up with 2 ruby mines \uD83D\uDC8E\uD83D\uDC8E http:\/\/t.co\/Qa3Z3LNM6K",
  "id" : 520064309468987392,
  "created_at" : "2014-10-09 04:12:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520055837646004225\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/CmGVIZ78iR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzecAkBCIAAZqu1.jpg",
      "id_str" : "520055815466524672",
      "id" : 520055815466524672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzecAkBCIAAZqu1.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CmGVIZ78iR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520055837646004225",
  "text" : "Warrior children running amok http:\/\/t.co\/CmGVIZ78iR",
  "id" : 520055837646004225,
  "created_at" : "2014-10-09 03:39:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520051131289178112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244873537, -78.8790715466 ]
  },
  "id_str" : "520055834139578369",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig it\u2019s like Agricola 2.0",
  "id" : 520055834139578369,
  "in_reply_to_status_id" : 520051131289178112,
  "created_at" : "2014-10-09 03:39:07 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520047221190828032\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/H2LexxXSp2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzeUMINCAAAiMoR.jpg",
      "id_str" : "520047218066063360",
      "id" : 520047218066063360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzeUMINCAAAiMoR.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/H2LexxXSp2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520047221190828032",
  "text" : "The cave grows http:\/\/t.co\/H2LexxXSp2",
  "id" : 520047221190828032,
  "created_at" : "2014-10-09 03:04:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520030545799958528\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Kry3Hrpxbc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzeFBhjCEAEMVjV.jpg",
      "id_str" : "520030543216250881",
      "id" : 520030543216250881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzeFBhjCEAEMVjV.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Kry3Hrpxbc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520030545799958528",
  "text" : "Mined an actual Ruby gem http:\/\/t.co\/Kry3Hrpxbc",
  "id" : 520030545799958528,
  "created_at" : "2014-10-09 01:58:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#techismaterial",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Garrett Heinlen",
      "screen_name" : "GoGoGarrett",
      "indices" : [ 14, 26 ],
      "id_str" : "51353886",
      "id" : 51353886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520018209077219330",
  "geo" : { },
  "id_str" : "520018590993362945",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @GoGoGarrett it\u2019s basically Agricola with dwarves. And Rubies. And battles.",
  "id" : 520018590993362945,
  "in_reply_to_status_id" : 520018209077219330,
  "created_at" : "2014-10-09 01:11:08 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Garrett Heinlen",
      "screen_name" : "GoGoGarrett",
      "indices" : [ 14, 26 ],
      "id_str" : "51353886",
      "id" : 51353886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520017821007634432",
  "geo" : { },
  "id_str" : "520018058815873024",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @GoGoGarrett its Caverna",
  "id" : 520018058815873024,
  "in_reply_to_status_id" : 520017821007634432,
  "created_at" : "2014-10-09 01:09:01 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 8, 16 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/520012774529699840\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/6xNHGt5ovL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzd03E2CMAE2ROT.jpg",
      "id_str" : "520012771526586369",
      "id" : 520012771526586369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzd03E2CMAE2ROT.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/6xNHGt5ovL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520012774529699840",
  "text" : "I blame @godfoca for this madness http:\/\/t.co\/6xNHGt5ovL",
  "id" : 520012774529699840,
  "created_at" : "2014-10-09 00:48:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Beaton",
      "screen_name" : "beatonna",
      "indices" : [ 3, 12 ],
      "id_str" : "36735522",
      "id" : 36735522
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/beatonna\/status\/519633612988088320\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/3MU7aEvR98",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzYcA9ACcAIfwsx.png",
      "id_str" : "519633609708171266",
      "id" : 519633609708171266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzYcA9ACcAIfwsx.png",
      "sizes" : [ {
        "h" : 373,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 671
      } ],
      "display_url" : "pic.twitter.com\/3MU7aEvR98"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519983656220106752",
  "text" : "RT @beatonna: these hands belong not to you anymore http:\/\/t.co\/3MU7aEvR98",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/beatonna\/status\/519633612988088320\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/3MU7aEvR98",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzYcA9ACcAIfwsx.png",
        "id_str" : "519633609708171266",
        "id" : 519633609708171266,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzYcA9ACcAIfwsx.png",
        "sizes" : [ {
          "h" : 373,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com\/3MU7aEvR98"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519633612988088320",
    "text" : "these hands belong not to you anymore http:\/\/t.co\/3MU7aEvR98",
    "id" : 519633612988088320,
    "created_at" : "2014-10-07 23:41:22 +0000",
    "user" : {
      "name" : "Kate Beaton",
      "screen_name" : "beatonna",
      "protected" : false,
      "id_str" : "36735522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539913013109596160\/YZmuS1Y4_normal.jpeg",
      "id" : 36735522,
      "verified" : true
    }
  },
  "id" : 519983656220106752,
  "created_at" : "2014-10-08 22:52:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/d2CaUdyqZo",
      "expanded_url" : "http:\/\/tilde.club",
      "display_url" : "tilde.club"
    } ]
  },
  "in_reply_to_status_id_str" : "519975695867719680",
  "geo" : { },
  "id_str" : "519976002613567488",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine if it had its own domain? it's kind of in the spirit of http:\/\/t.co\/d2CaUdyqZo though. Scary == any gTLD?",
  "id" : 519976002613567488,
  "in_reply_to_status_id" : 519975695867719680,
  "created_at" : "2014-10-08 22:21:54 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/a3gs1eaRCi",
      "expanded_url" : "http:\/\/www.themeaningofpie.com\/wp-content\/uploads\/2011\/01\/popover-lead.jpg",
      "display_url" : "themeaningofpie.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519936367158366208",
  "text" : "UIPopoverPresentationController http:\/\/t.co\/a3gs1eaRCi",
  "id" : 519936367158366208,
  "created_at" : "2014-10-08 19:44:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519933859946037249",
  "geo" : { },
  "id_str" : "519933922051112961",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents yup!!",
  "id" : 519933922051112961,
  "in_reply_to_status_id" : 519933859946037249,
  "created_at" : "2014-10-08 19:34:41 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 3, 12 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519930668399464448",
  "text" : "RT @codemash: 15,000 hits in 15 minutes. 2 minutes since sale opened, 189 left",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519929266755338240",
    "text" : "15,000 hits in 15 minutes. 2 minutes since sale opened, 189 left",
    "id" : 519929266755338240,
    "created_at" : "2014-10-08 19:16:11 +0000",
    "user" : {
      "name" : "codemash",
      "screen_name" : "codemash",
      "protected" : false,
      "id_str" : "7469772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575897195\/CodeMashLogoSquare_normal.png",
      "id" : 7469772,
      "verified" : false
    }
  },
  "id" : 519930668399464448,
  "created_at" : "2014-10-08 19:21:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519925415172145153",
  "geo" : { },
  "id_str" : "519930608567734272",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents If I didn't see this tweet we would have missed it",
  "id" : 519930608567734272,
  "in_reply_to_status_id" : 519925415172145153,
  "created_at" : "2014-10-08 19:21:31 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 1, 10 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519929119774375936",
  "text" : ".@codemash 2015 tickets secured. Woot!",
  "id" : 519929119774375936,
  "created_at" : "2014-10-08 19:15:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519922246412804096",
  "geo" : { },
  "id_str" : "519922362905800704",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek if i ever get another one, it'll be white and then i'll do green Yoshi spots on it.",
  "id" : 519922362905800704,
  "in_reply_to_status_id" : 519922246412804096,
  "created_at" : "2014-10-08 18:48:45 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519917145690349568",
  "geo" : { },
  "id_str" : "519922147452792832",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek I saw a White Yaris with a \"DINO EGG\" license plate here so you should do that",
  "id" : 519922147452792832,
  "in_reply_to_status_id" : 519917145690349568,
  "created_at" : "2014-10-08 18:47:54 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 1, 13 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/qHRyKySckr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qYhZPv5Vxbs",
      "display_url" : "youtube.com\/watch?v=qYhZPv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519907568253014016",
  "text" : ".@AqueousBand killing it in gorgeous HD: https:\/\/t.co\/qHRyKySckr",
  "id" : 519907568253014016,
  "created_at" : "2014-10-08 17:49:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "indices" : [ 3, 10 ],
      "id_str" : "8315692",
      "id" : 8315692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519904959605665793",
  "text" : "RT @GlennF: And, related, The Magazine will publish its last regular issue December 17. It\u2019s been a good run and thank you all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519899191582023681",
    "text" : "And, related, The Magazine will publish its last regular issue December 17. It\u2019s been a good run and thank you all.",
    "id" : 519899191582023681,
    "created_at" : "2014-10-08 17:16:41 +0000",
    "user" : {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "protected" : false,
      "id_str" : "8315692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553651457820356608\/j-szzxwZ_normal.jpeg",
      "id" : 8315692,
      "verified" : true
    }
  },
  "id" : 519904959605665793,
  "created_at" : "2014-10-08 17:39:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 12, 26 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/EfdsF1lQ51",
      "expanded_url" : "http:\/\/cow.org\/csi\/",
      "display_url" : "cow.org\/csi\/"
    } ]
  },
  "in_reply_to_status_id_str" : "519903831958642688",
  "geo" : { },
  "id_str" : "519904245969997824",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @coworkbuffalo http:\/\/t.co\/EfdsF1lQ51",
  "id" : 519904245969997824,
  "in_reply_to_status_id" : 519903831958642688,
  "created_at" : "2014-10-08 17:36:46 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "indices" : [ 0, 7 ],
      "id_str" : "8315692",
      "id" : 8315692
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 8, 15 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519718470070444032",
  "geo" : { },
  "id_str" : "519903622386028544",
  "in_reply_to_user_id" : 8315692,
  "text" : "@GlennF @ftrain Oops. Math is hard.",
  "id" : 519903622386028544,
  "in_reply_to_status_id" : 519718470070444032,
  "created_at" : "2014-10-08 17:34:17 +0000",
  "in_reply_to_screen_name" : "GlennF",
  "in_reply_to_user_id_str" : "8315692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/8SCqotLX3Q",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519903300896829440",
  "text" : "RT @ftrain: the million dollar givepage is already 1\/500th on its way to its goal http:\/\/t.co\/8SCqotLX3Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/8SCqotLX3Q",
        "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
        "display_url" : "tilde.club\/~qrush\/"
      } ]
    },
    "geo" : { },
    "id_str" : "519718219041341441",
    "text" : "the million dollar givepage is already 1\/500th on its way to its goal http:\/\/t.co\/8SCqotLX3Q",
    "id" : 519718219041341441,
    "created_at" : "2014-10-08 05:17:33 +0000",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3363818792\/c90e33ccf22e3146d5cd871ce561795a_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 519903300896829440,
  "created_at" : "2014-10-08 17:33:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 17, 23 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/LYGFj3UPG7",
      "expanded_url" : "https:\/\/ginatrapani.thinkup.com\/?u=ginatrapani&n=twitter&d=2014-10-07&s=bio_tracker",
      "display_url" : "ginatrapani.thinkup.com\/?u=ginatrapani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519881809908101120",
  "text" : "RT @ginatrapani: @qrush good diff https:\/\/t.co\/LYGFj3UPG7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/LYGFj3UPG7",
        "expanded_url" : "https:\/\/ginatrapani.thinkup.com\/?u=ginatrapani&n=twitter&d=2014-10-07&s=bio_tracker",
        "display_url" : "ginatrapani.thinkup.com\/?u=ginatrapani\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519881677498093570",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush good diff https:\/\/t.co\/LYGFj3UPG7",
    "id" : 519881677498093570,
    "created_at" : "2014-10-08 16:07:05 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550825678673682432\/YRqb4FJE_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 519881809908101120,
  "created_at" : "2014-10-08 16:07:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519879146088845312",
  "text" : "Also it only took 3 donations to get a BTC donation.",
  "id" : 519879146088845312,
  "created_at" : "2014-10-08 15:57:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khan Academy",
      "screen_name" : "khanacademy",
      "indices" : [ 29, 41 ],
      "id_str" : "16689804",
      "id" : 16689804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519879068255137792",
  "text" : "Our third donation is up, to @khanacademy. Let's fill in some more! http:\/\/t.co\/7i4fuWxpir",
  "id" : 519879068255137792,
  "created_at" : "2014-10-08 15:56:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/JPms1aFRLn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nw-_LQJ6e8E",
      "display_url" : "youtube.com\/watch?v=nw-_LQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519855825003634688",
  "text" : "All of this new music is great, but if you haven't seen Freddie control a crowd of 200,000 you need to. https:\/\/t.co\/JPms1aFRLn",
  "id" : 519855825003634688,
  "created_at" : "2014-10-08 14:24:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519854881801531392",
  "geo" : { },
  "id_str" : "519855003519836160",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic i think you're lost",
  "id" : 519855003519836160,
  "in_reply_to_status_id" : 519854881801531392,
  "created_at" : "2014-10-08 14:21:05 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Siracusa",
      "screen_name" : "siracusa",
      "indices" : [ 3, 12 ],
      "id_str" : "636923",
      "id" : 636923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Roj8dKdCvO",
      "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
      "display_url" : "seriouspony.com\/trouble-at-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519841201973755904",
  "text" : "RT @siracusa: Troll culture is poison. It takes amazing mental gymnastics for these people to see themselves as the good guys. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Roj8dKdCvO",
        "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
        "display_url" : "seriouspony.com\/trouble-at-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519823452719828992",
    "text" : "Troll culture is poison. It takes amazing mental gymnastics for these people to see themselves as the good guys. http:\/\/t.co\/Roj8dKdCvO",
    "id" : 519823452719828992,
    "created_at" : "2014-10-08 12:15:43 +0000",
    "user" : {
      "name" : "John Siracusa",
      "screen_name" : "siracusa",
      "protected" : false,
      "id_str" : "636923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1501070030\/John_2011_1_500x500_normal.png",
      "id" : 636923,
      "verified" : false
    }
  },
  "id" : 519841201973755904,
  "created_at" : "2014-10-08 13:26:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/XAcW6yFAhe",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/give.html",
      "display_url" : "tilde.club\/~qrush\/give.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519831934432604160",
  "text" : "Some simple rules for submitting: any donations in 2014 count. http:\/\/t.co\/XAcW6yFAhe",
  "id" : 519831934432604160,
  "created_at" : "2014-10-08 12:49:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519831196684288000",
  "geo" : { },
  "id_str" : "519831577069490176",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard I think you\u2019ll feel differently if you actually looked at it",
  "id" : 519831577069490176,
  "in_reply_to_status_id" : 519831196684288000,
  "created_at" : "2014-10-08 12:48:00 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bouchard",
      "screen_name" : "timbouchard",
      "indices" : [ 0, 12 ],
      "id_str" : "48160411",
      "id" : 48160411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519830995621912577",
  "geo" : { },
  "id_str" : "519831078329012225",
  "in_reply_to_user_id" : 48160411,
  "text" : "@timbouchard did you read it?",
  "id" : 519831078329012225,
  "in_reply_to_status_id" : 519830995621912577,
  "created_at" : "2014-10-08 12:46:01 +0000",
  "in_reply_to_screen_name" : "timbouchard",
  "in_reply_to_user_id_str" : "48160411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/uWNW0cRvuT",
      "expanded_url" : "http:\/\/tilde.club\/~qrush",
      "display_url" : "tilde.club\/~qrush"
    } ]
  },
  "geo" : { },
  "id_str" : "519830864465645568",
  "text" : "For the morning crowd: $200 into $1000000. Who\u2019s next? http:\/\/t.co\/uWNW0cRvuT",
  "id" : 519830864465645568,
  "created_at" : "2014-10-08 12:45:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/8SCqotLX3Q",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519815584528080896",
  "text" : "RT @ftrain: omg i want to high five the sunshine http:\/\/t.co\/8SCqotLX3Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/8SCqotLX3Q",
        "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
        "display_url" : "tilde.club\/~qrush\/"
      } ]
    },
    "geo" : { },
    "id_str" : "519700416603250689",
    "text" : "omg i want to high five the sunshine http:\/\/t.co\/8SCqotLX3Q",
    "id" : 519700416603250689,
    "created_at" : "2014-10-08 04:06:49 +0000",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3363818792\/c90e33ccf22e3146d5cd871ce561795a_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 519815584528080896,
  "created_at" : "2014-10-08 11:44:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anonymous man #3",
      "screen_name" : "beaugunderson",
      "indices" : [ 7, 21 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    }, {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/rw4kEpMVaU",
      "expanded_url" : "http:\/\/i.kinja-img.com\/gawker-media\/image\/upload\/s--TcL0dXVr--\/885773055862802833.gif",
      "display_url" : "i.kinja-img.com\/gawker-media\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519716916881940481",
  "text" : "Put up @beaugunderson as our second donor on http:\/\/t.co\/7i4fuWxpir. http:\/\/t.co\/rw4kEpMVaU",
  "id" : 519716916881940481,
  "created_at" : "2014-10-08 05:12:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Pepper",
      "screen_name" : "reppep",
      "indices" : [ 0, 7 ],
      "id_str" : "9100032",
      "id" : 9100032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519701383964930048",
  "geo" : { },
  "id_str" : "519710478205857792",
  "in_reply_to_user_id" : 9100032,
  "text" : "@reppep fixed ;)",
  "id" : 519710478205857792,
  "in_reply_to_status_id" : 519701383964930048,
  "created_at" : "2014-10-08 04:46:48 +0000",
  "in_reply_to_screen_name" : "reppep",
  "in_reply_to_user_id_str" : "9100032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NotThatKindaDr.Kline",
      "screen_name" : "MichelleAKline",
      "indices" : [ 0, 15 ],
      "id_str" : "356407124",
      "id" : 356407124
    }, {
      "name" : "christopher ryan",
      "screen_name" : "topherjryan",
      "indices" : [ 16, 28 ],
      "id_str" : "98528194",
      "id" : 98528194
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 29, 36 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519705629267468289",
  "geo" : { },
  "id_str" : "519708528013893633",
  "in_reply_to_user_id" : 356407124,
  "text" : "@MichelleAKline @TopherJRyan @ftrain just a crazy idea, mostly. we'll see if it works :)",
  "id" : 519708528013893633,
  "in_reply_to_status_id" : 519705629267468289,
  "created_at" : "2014-10-08 04:39:03 +0000",
  "in_reply_to_screen_name" : "MichelleAKline",
  "in_reply_to_user_id_str" : "356407124",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Pepper",
      "screen_name" : "reppep",
      "indices" : [ 0, 7 ],
      "id_str" : "9100032",
      "id" : 9100032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519701383964930048",
  "geo" : { },
  "id_str" : "519701616090292225",
  "in_reply_to_user_id" : 9100032,
  "text" : "@reppep yeah this is probably due to me pasting the obfuscated JS over and hoping it works. will take a look",
  "id" : 519701616090292225,
  "in_reply_to_status_id" : 519701383964930048,
  "created_at" : "2014-10-08 04:11:35 +0000",
  "in_reply_to_screen_name" : "reppep",
  "in_reply_to_user_id_str" : "9100032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519692349476073472",
  "text" : "I just donated $100 to kick off the Million Dollar Givepage. Who's next? http:\/\/t.co\/7i4fuWxpir",
  "id" : 519692349476073472,
  "created_at" : "2014-10-08 03:34:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ozKpMFvAbW",
      "expanded_url" : "http:\/\/i.lvme.me\/cz1xdkx.jpg",
      "display_url" : "i.lvme.me\/cz1xdkx.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "519671268719611906",
  "text" : "Listening to a Strong Bad song on repeat and messing with HTML 4.01 http:\/\/t.co\/ozKpMFvAbW",
  "id" : 519671268719611906,
  "created_at" : "2014-10-08 02:11:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 8, 17 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519661642053713920",
  "geo" : { },
  "id_str" : "519661736400404480",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @sabiddle thanks!",
  "id" : 519661736400404480,
  "in_reply_to_status_id" : 519661642053713920,
  "created_at" : "2014-10-08 01:33:07 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/evv8yBnWMl",
      "expanded_url" : "http:\/\/www.milliondollarhomepage.com\/img-site\/logo-tm.gif",
      "display_url" : "milliondollarhomepage.com\/img-site\/logo-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519659353205243904",
  "text" : "Anyone know what font this is? http:\/\/t.co\/evv8yBnWMl",
  "id" : 519659353205243904,
  "created_at" : "2014-10-08 01:23:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519652870652588032",
  "text" : "@juliepagano amazing",
  "id" : 519652870652588032,
  "created_at" : "2014-10-08 00:57:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519637953182572544",
  "text" : "Last 2 RTs are baby's first toots",
  "id" : 519637953182572544,
  "created_at" : "2014-10-07 23:58:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519637886786732032",
  "text" : "RT @aquaranto: Fun'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519625662189957120",
    "text" : "Fun'",
    "id" : 519625662189957120,
    "created_at" : "2014-10-07 23:09:46 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 519637886786732032,
  "created_at" : "2014-10-07 23:58:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519637881166376960",
  "text" : "RT @aquaranto: Ob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519625559878295552",
    "text" : "Ob",
    "id" : 519625559878295552,
    "created_at" : "2014-10-07 23:09:22 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 519637881166376960,
  "created_at" : "2014-10-07 23:58:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519625909779697664",
  "geo" : { },
  "id_str" : "519628492699222017",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej with great paella pan comes great responsibility",
  "id" : 519628492699222017,
  "in_reply_to_status_id" : 519625909779697664,
  "created_at" : "2014-10-07 23:21:01 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lindseybieda\/status\/519536475235315712\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/BiDSTBMBwA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzXDqrACEAAoqDf.png",
      "id_str" : "519536469895942144",
      "id" : 519536469895942144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzXDqrACEAAoqDf.png",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 1697
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BiDSTBMBwA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519624968028426243",
  "text" : "RT @lindseybieda: \"GoDaddy CEO: Why women are so turned off by the tech industry\" *coughs loudly* http:\/\/t.co\/BiDSTBMBwA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lindseybieda\/status\/519536475235315712\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/BiDSTBMBwA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzXDqrACEAAoqDf.png",
        "id_str" : "519536469895942144",
        "id" : 519536469895942144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzXDqrACEAAoqDf.png",
        "sizes" : [ {
          "h" : 275,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 1697
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BiDSTBMBwA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519536475235315712",
    "text" : "\"GoDaddy CEO: Why women are so turned off by the tech industry\" *coughs loudly* http:\/\/t.co\/BiDSTBMBwA",
    "id" : 519536475235315712,
    "created_at" : "2014-10-07 17:15:22 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 519624968028426243,
  "created_at" : "2014-10-07 23:07:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/74Petdouw4",
      "expanded_url" : "http:\/\/youtu.be\/rbvxlvSIIww",
      "display_url" : "youtu.be\/rbvxlvSIIww"
    } ]
  },
  "geo" : { },
  "id_str" : "519606042494111744",
  "text" : "Things are about to get bulbous http:\/\/t.co\/74Petdouw4",
  "id" : 519606042494111744,
  "created_at" : "2014-10-07 21:51:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Aimonetti",
      "screen_name" : "mattetti",
      "indices" : [ 0, 9 ],
      "id_str" : "16476741",
      "id" : 16476741
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 10, 18 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519558294084415491",
  "geo" : { },
  "id_str" : "519558442629877762",
  "in_reply_to_user_id" : 16476741,
  "text" : "@mattetti @evanphx whats in your ~\/.gemrc",
  "id" : 519558442629877762,
  "in_reply_to_status_id" : 519558294084415491,
  "created_at" : "2014-10-07 18:42:40 +0000",
  "in_reply_to_screen_name" : "mattetti",
  "in_reply_to_user_id_str" : "16476741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 9, 19 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 20, 29 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519526246229635072",
  "geo" : { },
  "id_str" : "519526425053777921",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca @aspleenic @poteland Shot you an email at hi@, btw. I know Holly Farms has it on Pearl, Washington St Market might too.",
  "id" : 519526425053777921,
  "in_reply_to_status_id" : 519526246229635072,
  "created_at" : "2014-10-07 16:35:26 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/519512329927401473\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/IriGZTdLoc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWttaWCQAAWTMW.jpg",
      "id_str" : "519512327708622848",
      "id" : 519512327708622848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWttaWCQAAWTMW.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/IriGZTdLoc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519512329927401473",
  "text" : "\"Open Source\" is a great window title for this dialog http:\/\/t.co\/IriGZTdLoc",
  "id" : 519512329927401473,
  "created_at" : "2014-10-07 15:39:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 12, 19 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518048330098937858",
  "geo" : { },
  "id_str" : "519511044817817600",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @hiteak hey! email me your address, we have a few spares",
  "id" : 519511044817817600,
  "in_reply_to_status_id" : 518048330098937858,
  "created_at" : "2014-10-07 15:34:19 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519509381730160641",
  "text" : "I need an App Store category\/search for Landscape support.",
  "id" : 519509381730160641,
  "created_at" : "2014-10-07 15:27:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519502905179930625",
  "geo" : { },
  "id_str" : "519509029035335682",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi Always afraid glassware would break in transit. And $$$",
  "id" : 519509029035335682,
  "in_reply_to_status_id" : 519502905179930625,
  "created_at" : "2014-10-07 15:26:19 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/RXxY0MEPYY",
      "expanded_url" : "http:\/\/tilde.club",
      "display_url" : "tilde.club"
    } ]
  },
  "geo" : { },
  "id_str" : "519496441186639874",
  "text" : "RT @ftrain: wow http:\/\/t.co\/RXxY0MEPYY is very dead in a way that is new to me. i offer full amnesty to anyone who admits what they did. fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 4, 26 ],
        "url" : "http:\/\/t.co\/RXxY0MEPYY",
        "expanded_url" : "http:\/\/tilde.club",
        "display_url" : "tilde.club"
      } ]
    },
    "geo" : { },
    "id_str" : "519459060509605888",
    "text" : "wow http:\/\/t.co\/RXxY0MEPYY is very dead in a way that is new to me. i offer full amnesty to anyone who admits what they did. ford@ftrain.com",
    "id" : 519459060509605888,
    "created_at" : "2014-10-07 12:07:45 +0000",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3363818792\/c90e33ccf22e3146d5cd871ce561795a_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 519496441186639874,
  "created_at" : "2014-10-07 14:36:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519466033498058752",
  "text" : "Totally forgot about the slow motion camera on the iPhone for my Niagara Falls trip this weekend. \uD83D\uDE10",
  "id" : 519466033498058752,
  "created_at" : "2014-10-07 12:35:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/cdSvEWGGqK",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Paris_syndrome",
      "display_url" : "en.m.wikipedia.org\/wiki\/Paris_syn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519333658889818112",
  "geo" : { },
  "id_str" : "519450621686980609",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik http:\/\/t.co\/cdSvEWGGqK",
  "id" : 519450621686980609,
  "in_reply_to_status_id" : 519333658889818112,
  "created_at" : "2014-10-07 11:34:13 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Lenhart",
      "screen_name" : "SeanLenhart",
      "indices" : [ 0, 12 ],
      "id_str" : "253849166",
      "id" : 253849166
    }, {
      "name" : "Feminiraptor ",
      "screen_name" : "maryloulenhart",
      "indices" : [ 13, 28 ],
      "id_str" : "73231837",
      "id" : 73231837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519307593261780993",
  "geo" : { },
  "id_str" : "519450457396092929",
  "in_reply_to_user_id" : 253849166,
  "text" : "@SeanLenhart @maryloulenhart What!!!?",
  "id" : 519450457396092929,
  "in_reply_to_status_id" : 519307593261780993,
  "created_at" : "2014-10-07 11:33:34 +0000",
  "in_reply_to_screen_name" : "SeanLenhart",
  "in_reply_to_user_id_str" : "253849166",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519333442040107008",
  "geo" : { },
  "id_str" : "519334222851354624",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer ahem not always possible. Anyway, commencing stasis",
  "id" : 519334222851354624,
  "in_reply_to_status_id" : 519333442040107008,
  "created_at" : "2014-10-07 03:51:42 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519333442040107008",
  "geo" : { },
  "id_str" : "519333864833970176",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer not possible due to life and job",
  "id" : 519333864833970176,
  "in_reply_to_status_id" : 519333442040107008,
  "created_at" : "2014-10-07 03:50:16 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519331392262385664",
  "text" : "The worst thing is having a great idea right before your feeble carbon husk needs to lay still for several hours in a dark, quiet place",
  "id" : 519331392262385664,
  "created_at" : "2014-10-07 03:40:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 1, 12 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/uMhbbvWwO0",
      "expanded_url" : "http:\/\/tilde.club\/~waxpancake\/",
      "display_url" : "tilde.club\/~waxpancake\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519321127038881793",
  "text" : ".@waxpancake is taking the cake http:\/\/t.co\/uMhbbvWwO0",
  "id" : 519321127038881793,
  "created_at" : "2014-10-07 02:59:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Nowalk",
      "screen_name" : "bnowalk",
      "indices" : [ 0, 8 ],
      "id_str" : "210312678",
      "id" : 210312678
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 9, 18 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/519319286813179904\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/rA3wwjhHCQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzT-I4fCMAAGqFb.png",
      "id_str" : "519319285609410560",
      "id" : 519319285609410560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzT-I4fCMAAGqFb.png",
      "sizes" : [ {
        "h" : 756,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rA3wwjhHCQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519306862861094913",
  "geo" : { },
  "id_str" : "519319286813179904",
  "in_reply_to_user_id" : 210312678,
  "text" : "@bnowalk @konklone Across the street, people live on \"Cripple Creek Lane\" http:\/\/t.co\/rA3wwjhHCQ",
  "id" : 519319286813179904,
  "in_reply_to_status_id" : 519306862861094913,
  "created_at" : "2014-10-07 02:52:21 +0000",
  "in_reply_to_screen_name" : "bnowalk",
  "in_reply_to_user_id_str" : "210312678",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNYmedia Network",
      "screen_name" : "wnymedia",
      "indices" : [ 3, 12 ],
      "id_str" : "9106882",
      "id" : 9106882
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 47, 59 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/N9SUC6OPLO",
      "expanded_url" : "http:\/\/buffalofm.wnymedia.net\/listen-new-single-release-aqueous-2020\/",
      "display_url" : "buffalofm.wnymedia.net\/listen-new-sin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519202937248415744",
  "text" : "RT @wnymedia: LISTEN:  New Single Release from @Aqueousband 20\/20 - http:\/\/t.co\/N9SUC6OPLO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 33, 45 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/N9SUC6OPLO",
        "expanded_url" : "http:\/\/buffalofm.wnymedia.net\/listen-new-single-release-aqueous-2020\/",
        "display_url" : "buffalofm.wnymedia.net\/listen-new-sin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519183638403878912",
    "text" : "LISTEN:  New Single Release from @Aqueousband 20\/20 - http:\/\/t.co\/N9SUC6OPLO",
    "id" : 519183638403878912,
    "created_at" : "2014-10-06 17:53:20 +0000",
    "user" : {
      "name" : "WNYmedia Network",
      "screen_name" : "wnymedia",
      "protected" : false,
      "id_str" : "9106882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522539886780645376\/5XGVsPob_normal.jpeg",
      "id" : 9106882,
      "verified" : false
    }
  },
  "id" : 519202937248415744,
  "created_at" : "2014-10-06 19:10:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 3, 9 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519180101154402304",
  "text" : "RT @_zzak: Will DMCA anyone that RTs this",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519179721708302336",
    "text" : "Will DMCA anyone that RTs this",
    "id" : 519179721708302336,
    "created_at" : "2014-10-06 17:37:46 +0000",
    "user" : {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "protected" : false,
      "id_str" : "920539489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760450458\/1d14e04afe654ee43abccfce2040558e_normal.jpeg",
      "id" : 920539489,
      "verified" : false
    }
  },
  "id" : 519180101154402304,
  "created_at" : "2014-10-06 17:39:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519164488105594880",
  "geo" : { },
  "id_str" : "519166324597997568",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss That doesn't always guarantee the app goes through the state preservation\/restoration process, does it?",
  "id" : 519166324597997568,
  "in_reply_to_status_id" : 519164488105594880,
  "created_at" : "2014-10-06 16:44:32 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519148864511565824",
  "text" : "Is there any way to test iOS app restoring other than launching a ton of resource heavy apps\/games?",
  "id" : 519148864511565824,
  "created_at" : "2014-10-06 15:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 11, 23 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/b5uAKHLMwK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8kUapstQu_4",
      "display_url" : "youtube.com\/watch?v=8kUaps\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519140776056328192",
  "text" : "20\/20 from @AqueousBand, and a small sapling of the awesomeness bottled in Cycles: https:\/\/t.co\/b5uAKHLMwK",
  "id" : 519140776056328192,
  "created_at" : "2014-10-06 15:03:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JamBase",
      "screen_name" : "JamBase",
      "indices" : [ 3, 11 ],
      "id_str" : "14156684",
      "id" : 14156684
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 41, 53 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kc6w4OKAf8",
      "expanded_url" : "http:\/\/bit.ly\/1s1j6F0",
      "display_url" : "bit.ly\/1s1j6F0"
    } ]
  },
  "geo" : { },
  "id_str" : "519139228211347459",
  "text" : "RT @JamBase: Upstate NY jam act Aqueous (@AqueousBand) have announced upcoming release of a new album. Stream the first single: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 28, 40 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kc6w4OKAf8",
        "expanded_url" : "http:\/\/bit.ly\/1s1j6F0",
        "display_url" : "bit.ly\/1s1j6F0"
      } ]
    },
    "geo" : { },
    "id_str" : "519138422825701376",
    "text" : "Upstate NY jam act Aqueous (@AqueousBand) have announced upcoming release of a new album. Stream the first single: http:\/\/t.co\/kc6w4OKAf8",
    "id" : 519138422825701376,
    "created_at" : "2014-10-06 14:53:39 +0000",
    "user" : {
      "name" : "JamBase",
      "screen_name" : "JamBase",
      "protected" : false,
      "id_str" : "14156684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458780708844994560\/4yhJ1bzT_normal.png",
      "id" : 14156684,
      "verified" : false
    }
  },
  "id" : 519139228211347459,
  "created_at" : "2014-10-06 14:56:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Cressman",
      "screen_name" : "natcressman",
      "indices" : [ 30, 42 ],
      "id_str" : "352636759",
      "id" : 352636759
    }, {
      "name" : "Jennifer Hartswick",
      "screen_name" : "Jhartswick",
      "indices" : [ 47, 58 ],
      "id_str" : "42144193",
      "id" : 42144193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/wbrZOFPKvW",
      "expanded_url" : "http:\/\/www.bostonglobe.com\/arts\/music\/2014\/10\/05\/trombonist-cressman-lures-jam-band-fans-jazz\/rclFPRI2IbAoyoFOcR8BHP\/story.html",
      "display_url" : "bostonglobe.com\/arts\/music\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519130010095845377",
  "text" : "You owe it to yourself to see @natcressman and @Jhartswick wherever they're playing. Come back to Buffalo soon! http:\/\/t.co\/wbrZOFPKvW",
  "id" : 519130010095845377,
  "created_at" : "2014-10-06 14:20:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn",
      "screen_name" : "jennschiffer",
      "indices" : [ 0, 13 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519105799474655233",
  "geo" : { },
  "id_str" : "519107463732150273",
  "in_reply_to_user_id" : 12524622,
  "text" : "@jennschiffer all right",
  "id" : 519107463732150273,
  "in_reply_to_status_id" : 519105799474655233,
  "created_at" : "2014-10-06 12:50:38 +0000",
  "in_reply_to_screen_name" : "jennschiffer",
  "in_reply_to_user_id_str" : "12524622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 4, 16 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519104687098699777",
  "text" : "New @AqueousBand single today and more good things to come!",
  "id" : 519104687098699777,
  "created_at" : "2014-10-06 12:39:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518948663641391105",
  "geo" : { },
  "id_str" : "518949077795360768",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza is that literally a thirsty rando?",
  "id" : 518949077795360768,
  "in_reply_to_status_id" : 518948663641391105,
  "created_at" : "2014-10-06 02:21:16 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518945828686151680",
  "text" : "Very grateful for Ruby (and non? un?-Ruby) friends near and far this evening. Good night!",
  "id" : 518945828686151680,
  "created_at" : "2014-10-06 02:08:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Chong",
      "screen_name" : "sylvzc",
      "indices" : [ 0, 7 ],
      "id_str" : "2544124698",
      "id" : 2544124698
    }, {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 8, 16 ],
      "id_str" : "270917610",
      "id" : 270917610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518943664341389313",
  "geo" : { },
  "id_str" : "518945521008783361",
  "in_reply_to_user_id" : 2544124698,
  "text" : "@sylvzc @alarowe there are seasons here",
  "id" : 518945521008783361,
  "in_reply_to_status_id" : 518943664341389313,
  "created_at" : "2014-10-06 02:07:08 +0000",
  "in_reply_to_screen_name" : "sylvzc",
  "in_reply_to_user_id_str" : "2544124698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 0, 9 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "Avi Flombaum",
      "screen_name" : "aviflombaum",
      "indices" : [ 10, 22 ],
      "id_str" : "2085091",
      "id" : 2085091
    }, {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 50, 58 ],
      "id_str" : "1696",
      "id" : 1696
    }, {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 59, 67 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518943771971424257",
  "geo" : { },
  "id_str" : "518945287574786048",
  "in_reply_to_user_id" : 41438974,
  "text" : "@sebasoga @aviflombaum phew. Sounds good. \uD83D\uDE05\uD83D\uDE4F\uD83D\uDCA4 \/cc @ktheory @brynary",
  "id" : 518945287574786048,
  "in_reply_to_status_id" : 518943771971424257,
  "created_at" : "2014-10-06 02:06:12 +0000",
  "in_reply_to_screen_name" : "sebasoga",
  "in_reply_to_user_id_str" : "41438974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 0, 9 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "Avi Flombaum",
      "screen_name" : "aviflombaum",
      "indices" : [ 69, 81 ],
      "id_str" : "2085091",
      "id" : 2085091
    }, {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 82, 90 ],
      "id_str" : "1696",
      "id" : 1696
    }, {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 91, 99 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518891108232081409",
  "geo" : { },
  "id_str" : "518941848874651651",
  "in_reply_to_user_id" : 41438974,
  "text" : "@sebasoga i am fading fast due to exhaustion but have DM\u2019d you info. @aviflombaum @ktheory @brynary should be able to help too.",
  "id" : 518941848874651651,
  "in_reply_to_status_id" : 518891108232081409,
  "created_at" : "2014-10-06 01:52:32 +0000",
  "in_reply_to_screen_name" : "sebasoga",
  "in_reply_to_user_id_str" : "41438974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518930607884484609",
  "geo" : { },
  "id_str" : "518930859886256128",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda every time you tweet I try to fav your name",
  "id" : 518930859886256128,
  "in_reply_to_status_id" : 518930607884484609,
  "created_at" : "2014-10-06 01:08:52 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 8, 15 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518765256643194880",
  "geo" : { },
  "id_str" : "518929838334554112",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos @bryanl you can set a directory(ies) to always be available too for fast switching. I have my ~\/Dev folder setup this way.",
  "id" : 518929838334554112,
  "in_reply_to_status_id" : 518765256643194880,
  "created_at" : "2014-10-06 01:04:49 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518905177869271041",
  "text" : "If you live in NYC and can help me out with something really urgent, can you DM me please?",
  "id" : 518905177869271041,
  "created_at" : "2014-10-05 23:26:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/nRxNbtRCfj",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=1cyjkunnrHE",
      "display_url" : "m.youtube.com\/watch?v=1cyjku\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518882517277892608",
  "text" : "Current status https:\/\/t.co\/nRxNbtRCfj",
  "id" : 518882517277892608,
  "created_at" : "2014-10-05 21:56:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crypto Cuttlefish",
      "screen_name" : "cuttlefish_btc",
      "indices" : [ 3, 18 ],
      "id_str" : "2319314552",
      "id" : 2319314552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GamerGate",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Woa42JX3lg",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/9\/12\/4693710\/the-end-of-kindness-weev-and-the-cult-of-the-angry-young-man",
      "display_url" : "theverge.com\/2013\/9\/12\/4693\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518805276544102401",
  "text" : "RT @cuttlefish_btc: Weev's attack on Kathy Sierra was the blueprint for #GamerGate, laid down 7 years ago: destroy women who speak up. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GamerGate",
        "indices" : [ 52, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Woa42JX3lg",
        "expanded_url" : "http:\/\/www.theverge.com\/2013\/9\/12\/4693710\/the-end-of-kindness-weev-and-the-cult-of-the-angry-young-man",
        "display_url" : "theverge.com\/2013\/9\/12\/4693\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518422743901937664",
    "text" : "Weev's attack on Kathy Sierra was the blueprint for #GamerGate, laid down 7 years ago: destroy women who speak up. http:\/\/t.co\/Woa42JX3lg",
    "id" : 518422743901937664,
    "created_at" : "2014-10-04 15:29:48 +0000",
    "user" : {
      "name" : "Crypto Cuttlefish",
      "screen_name" : "cuttlefish_btc",
      "protected" : false,
      "id_str" : "2319314552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428950132604686337\/0Nuj6XAt_normal.jpeg",
      "id" : 2319314552,
      "verified" : false
    }
  },
  "id" : 518805276544102401,
  "created_at" : "2014-10-05 16:49:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/518801949596979200\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xGPyecRRca",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzMnnygCIAAjsRt.png",
      "id_str" : "518801946602250240",
      "id" : 518801946602250240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzMnnygCIAAjsRt.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2208,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xGPyecRRca"
    } ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518801949596979200",
  "text" : "Hoping these bands stay south. Heading to the Falls soon if anyone else wants a ride #ncrc14 http:\/\/t.co\/xGPyecRRca",
  "id" : 518801949596979200,
  "created_at" : "2014-10-05 16:36:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 0, 9 ],
      "id_str" : "41438974",
      "id" : 41438974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518767205916217346",
  "geo" : { },
  "id_str" : "518782170693775360",
  "in_reply_to_user_id" : 41438974,
  "text" : "@sebasoga check your DM, delayed",
  "id" : 518782170693775360,
  "in_reply_to_status_id" : 518767205916217346,
  "created_at" : "2014-10-05 15:18:02 +0000",
  "in_reply_to_screen_name" : "sebasoga",
  "in_reply_to_user_id_str" : "41438974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 0, 9 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 16, 24 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 29, 38 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518747533179224064",
  "geo" : { },
  "id_str" : "518767021514035201",
  "in_reply_to_user_id" : 41438974,
  "text" : "@sebasoga cool. @godfoca and @poteland up yet!?",
  "id" : 518767021514035201,
  "in_reply_to_status_id" : 518747533179224064,
  "created_at" : "2014-10-05 14:17:50 +0000",
  "in_reply_to_screen_name" : "sebasoga",
  "in_reply_to_user_id_str" : "41438974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 0, 9 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518741501204267008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242760197, -78.8802008793 ]
  },
  "id_str" : "518742206169903104",
  "in_reply_to_user_id" : 14164724,
  "text" : "@sarahmei that\u2019s a thing!!!?!",
  "id" : 518742206169903104,
  "in_reply_to_status_id" : 518741501204267008,
  "created_at" : "2014-10-05 12:39:14 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518723229742292992",
  "geo" : { },
  "id_str" : "518724491950575616",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt bespoke screencasts",
  "id" : 518724491950575616,
  "in_reply_to_status_id" : 518723229742292992,
  "created_at" : "2014-10-05 11:28:50 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/Lagmy3ClBA",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view6\/3609801\/clumsy-big-bird-o.gif",
      "display_url" : "stream1.gifsoup.com\/view6\/3609801\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518638524069736448",
  "text" : "Current status http:\/\/t.co\/Lagmy3ClBA",
  "id" : 518638524069736448,
  "created_at" : "2014-10-05 05:47:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 17, 29 ],
      "id_str" : "122932694",
      "id" : 122932694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518634573605781504",
  "text" : "Got a reply from @seriouspony this week and felt elated. Beyond sad she\u2019s gone once again. The Internet is terrible.",
  "id" : 518634573605781504,
  "created_at" : "2014-10-05 05:31:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518600486677524480",
  "geo" : { },
  "id_str" : "518600896738246656",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal if anyone has permission they can add\/remove anyone",
  "id" : 518600896738246656,
  "in_reply_to_status_id" : 518600486677524480,
  "created_at" : "2014-10-05 03:17:43 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518600044090359809",
  "geo" : { },
  "id_str" : "518600311955787776",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal eh?",
  "id" : 518600311955787776,
  "in_reply_to_status_id" : 518600044090359809,
  "created_at" : "2014-10-05 03:15:24 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518562293194719233",
  "text" : "Lots of kind #ncrc14 tweets popping up this evening. \uD83D\uDE01",
  "id" : 518562293194719233,
  "created_at" : "2014-10-05 00:44:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beardo",
      "screen_name" : "Mechaphil",
      "indices" : [ 0, 10 ],
      "id_str" : "250785234",
      "id" : 250785234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518560533428318208",
  "geo" : { },
  "id_str" : "518561589914783744",
  "in_reply_to_user_id" : 250785234,
  "text" : "@Mechaphil there\u2019s been some talk on BOCC of this",
  "id" : 518561589914783744,
  "in_reply_to_status_id" : 518560533428318208,
  "created_at" : "2014-10-05 00:41:32 +0000",
  "in_reply_to_screen_name" : "Mechaphil",
  "in_reply_to_user_id_str" : "250785234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518561439456706562",
  "text" : "On my way down to DBGB\u2019s!",
  "id" : 518561439456706562,
  "created_at" : "2014-10-05 00:40:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518553020070522880",
  "text" : "It\u2019s hailing out in downtown Buffalo right now. Our reputation precedes us:",
  "id" : 518553020070522880,
  "created_at" : "2014-10-05 00:07:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/qZFU9g0B0S",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/dukes-bohemian-grove-bar-buffalo",
      "display_url" : "yelp.com\/biz\/dukes-bohe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "518538833865228289",
  "geo" : { },
  "id_str" : "518539209175355392",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda http:\/\/t.co\/qZFU9g0B0S",
  "id" : 518539209175355392,
  "in_reply_to_status_id" : 518538833865228289,
  "created_at" : "2014-10-04 23:12:36 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518535288814313472",
  "geo" : { },
  "id_str" : "518535937865682944",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda for real.",
  "id" : 518535937865682944,
  "in_reply_to_status_id" : 518535288814313472,
  "created_at" : "2014-10-04 22:59:36 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "indices" : [ 0, 12 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518515832071393280",
  "geo" : { },
  "id_str" : "518525412595355648",
  "in_reply_to_user_id" : 9526722,
  "text" : "@CoralineAda for real?",
  "id" : 518525412595355648,
  "in_reply_to_status_id" : 518515832071393280,
  "created_at" : "2014-10-04 22:17:46 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@pplcallmejam",
      "screen_name" : "Justjamonit",
      "indices" : [ 0, 12 ],
      "id_str" : "2863047410",
      "id" : 2863047410
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 13, 28 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518513924799750144",
  "geo" : { },
  "id_str" : "518516754625331201",
  "in_reply_to_user_id" : 1547239940,
  "text" : "@justjamonit @nickelcityruby the group is holding at main and Lafayette for you!",
  "id" : 518516754625331201,
  "in_reply_to_status_id" : 518513924799750144,
  "created_at" : "2014-10-04 21:43:22 +0000",
  "in_reply_to_screen_name" : "pplcallmejam",
  "in_reply_to_user_id_str" : "1547239940",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@pplcallmejam",
      "screen_name" : "Justjamonit",
      "indices" : [ 0, 12 ],
      "id_str" : "2863047410",
      "id" : 2863047410
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 25, 39 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Lady Ivan Grey",
      "screen_name" : "LadyIvanGrey",
      "indices" : [ 55, 68 ],
      "id_str" : "2469964320",
      "id" : 2469964320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518513924799750144",
  "geo" : { },
  "id_str" : "518515442416353280",
  "in_reply_to_user_id" : 1547239940,
  "text" : "@justjamonit oh no! Ping @Carols10cents for arch tour, @LadyIvanGrey for mobster",
  "id" : 518515442416353280,
  "in_reply_to_status_id" : 518513924799750144,
  "created_at" : "2014-10-04 21:38:09 +0000",
  "in_reply_to_screen_name" : "pplcallmejam",
  "in_reply_to_user_id_str" : "1547239940",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 0, 6 ],
      "id_str" : "15265916",
      "id" : 15265916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518508984060628992",
  "geo" : { },
  "id_str" : "518510371020484608",
  "in_reply_to_user_id" : 15265916,
  "text" : "@dabit DM\u2019d",
  "id" : 518510371020484608,
  "in_reply_to_status_id" : 518508984060628992,
  "created_at" : "2014-10-04 21:18:00 +0000",
  "in_reply_to_screen_name" : "dabit",
  "in_reply_to_user_id_str" : "15265916",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 0, 6 ],
      "id_str" : "15265916",
      "id" : 15265916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518507432193306625",
  "in_reply_to_user_id" : 15265916,
  "text" : "@dabit need to DM you, follow back plz?",
  "id" : 518507432193306625,
  "created_at" : "2014-10-04 21:06:19 +0000",
  "in_reply_to_screen_name" : "dabit",
  "in_reply_to_user_id_str" : "15265916",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 13, 25 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 26, 36 ],
      "id_str" : "355473809",
      "id" : 355473809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518480323064393729",
  "geo" : { },
  "id_str" : "518480467746910209",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide @sstephenson @kikiaards dump it all out and replace with Malort",
  "id" : 518480467746910209,
  "in_reply_to_status_id" : 518480323064393729,
  "created_at" : "2014-10-04 19:19:11 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518479382894362626",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8856532102, -78.8725023106 ]
  },
  "id_str" : "518480078209314816",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide that\u2019s a lot",
  "id" : 518480078209314816,
  "in_reply_to_status_id" : 518479382894362626,
  "created_at" : "2014-10-04 19:17:38 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "knguyen ebooks",
      "screen_name" : "knguyen_ebooks",
      "indices" : [ 3, 18 ],
      "id_str" : "2325685268",
      "id" : 2325685268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518407291310456832",
  "text" : "RT @knguyen_ebooks: Is fried ravioli a good Basecamp client for iPhone?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/negatendo.net\" rel=\"nofollow\"\u003Enegatendo_ebooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516703954986885121",
    "text" : "Is fried ravioli a good Basecamp client for iPhone?",
    "id" : 516703954986885121,
    "created_at" : "2014-09-29 21:39:57 +0000",
    "user" : {
      "name" : "knguyen ebooks",
      "screen_name" : "knguyen_ebooks",
      "protected" : false,
      "id_str" : "2325685268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430371166163726336\/2poF7wQj_normal.png",
      "id" : 2325685268,
      "verified" : false
    }
  },
  "id" : 518407291310456832,
  "created_at" : "2014-10-04 14:28:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 34, 49 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518405869810487297",
  "geo" : { },
  "id_str" : "518406010416152576",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora haha :) breakfast for @nickelcityruby.",
  "id" : 518406010416152576,
  "in_reply_to_status_id" : 518405869810487297,
  "created_at" : "2014-10-04 14:23:19 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/518380579948363776\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/BEeYMBOzAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzGoY4wCMAA7KlW.jpg",
      "id_str" : "518380577628499968",
      "id" : 518380577628499968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzGoY4wCMAA7KlW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/BEeYMBOzAD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518380579948363776",
  "text" : "Errno::ETOOMANYDONUTS http:\/\/t.co\/BEeYMBOzAD",
  "id" : 518380579948363776,
  "created_at" : "2014-10-04 12:42:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 0, 15 ],
      "id_str" : "18210275",
      "id" : 18210275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518373754054131712",
  "geo" : { },
  "id_str" : "518374611789312001",
  "in_reply_to_user_id" : 18210275,
  "text" : "@SaltineJustine dang. if you are close to the library stop by for some take out",
  "id" : 518374611789312001,
  "in_reply_to_status_id" : 518373754054131712,
  "created_at" : "2014-10-04 12:18:33 +0000",
  "in_reply_to_screen_name" : "SaltineJustine",
  "in_reply_to_user_id_str" : "18210275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 0, 15 ],
      "id_str" : "18210275",
      "id" : 18210275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518363297662656512",
  "geo" : { },
  "id_str" : "518364423002411008",
  "in_reply_to_user_id" : 18210275,
  "text" : "@SaltineJustine welcome to Buffalo! Staying for the weekend?",
  "id" : 518364423002411008,
  "in_reply_to_status_id" : 518363297662656512,
  "created_at" : "2014-10-04 11:38:03 +0000",
  "in_reply_to_screen_name" : "SaltineJustine",
  "in_reply_to_user_id_str" : "18210275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "now at @bravemule",
      "screen_name" : "starguarded",
      "indices" : [ 0, 12 ],
      "id_str" : "2945589083",
      "id" : 2945589083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518223437308129280",
  "geo" : { },
  "id_str" : "518223687095300096",
  "in_reply_to_user_id" : 18947075,
  "text" : "@starguarded ugh just had to do that stage when you ignore 2 Ghomas to kill 400. This game ain\u2019t easy",
  "id" : 518223687095300096,
  "in_reply_to_status_id" : 518223437308129280,
  "created_at" : "2014-10-04 02:18:49 +0000",
  "in_reply_to_screen_name" : "bravemule",
  "in_reply_to_user_id_str" : "18947075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518215941033705472",
  "geo" : { },
  "id_str" : "518220647235735552",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft oh hell yeah pimp",
  "id" : 518220647235735552,
  "in_reply_to_status_id" : 518215941033705472,
  "created_at" : "2014-10-04 02:06:45 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 35, 42 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "John Yerhot",
      "screen_name" : "yerhot",
      "indices" : [ 47, 54 ],
      "id_str" : "12341642",
      "id" : 12341642
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCRC14",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518191749139689472",
  "text" : "RT @nickelcityruby: Huge thanks to @github and @yerhot for hosting the drink-up tonight! #NCRC14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 15, 22 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "John Yerhot",
        "screen_name" : "yerhot",
        "indices" : [ 27, 34 ],
        "id_str" : "12341642",
        "id" : 12341642
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCRC14",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518191593531387904",
    "text" : "Huge thanks to @github and @yerhot for hosting the drink-up tonight! #NCRC14",
    "id" : 518191593531387904,
    "created_at" : "2014-10-04 00:11:18 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 518191749139689472,
  "created_at" : "2014-10-04 00:11:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518145094487400448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8856447632, -78.8749892804 ]
  },
  "id_str" : "518146296583319552",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic wrong photo!",
  "id" : 518146296583319552,
  "in_reply_to_status_id" : 518145094487400448,
  "created_at" : "2014-10-03 21:11:18 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yzudH3jXky",
      "expanded_url" : "http:\/\/bit.ly\/ncrc14code",
      "display_url" : "bit.ly\/ncrc14code"
    } ]
  },
  "geo" : { },
  "id_str" : "518136784199630848",
  "text" : "RT @nickelcityruby: Just a reminder that we have a Code of Conduct and we take it seriously. http:\/\/t.co\/yzudH3jXky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/yzudH3jXky",
        "expanded_url" : "http:\/\/bit.ly\/ncrc14code",
        "display_url" : "bit.ly\/ncrc14code"
      } ]
    },
    "geo" : { },
    "id_str" : "518131937719095296",
    "text" : "Just a reminder that we have a Code of Conduct and we take it seriously. http:\/\/t.co\/yzudH3jXky",
    "id" : 518131937719095296,
    "created_at" : "2014-10-03 20:14:15 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 518136784199630848,
  "created_at" : "2014-10-03 20:33:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Trailmix",
      "screen_name" : "trailmixlife",
      "indices" : [ 52, 65 ],
      "id_str" : "2825268222",
      "id" : 2825268222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/atvG131x9Q",
      "expanded_url" : "https:\/\/github.com\/codecation\/trailmix",
      "display_url" : "github.com\/codecation\/tra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518136719842234368",
  "text" : "RT @r00k: We decided to open source the code behind @trailmixlife. https:\/\/t.co\/atvG131x9Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trailmix",
        "screen_name" : "trailmixlife",
        "indices" : [ 42, 55 ],
        "id_str" : "2825268222",
        "id" : 2825268222
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/atvG131x9Q",
        "expanded_url" : "https:\/\/github.com\/codecation\/trailmix",
        "display_url" : "github.com\/codecation\/tra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518136337506242560",
    "text" : "We decided to open source the code behind @trailmixlife. https:\/\/t.co\/atvG131x9Q",
    "id" : 518136337506242560,
    "created_at" : "2014-10-03 20:31:44 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 518136719842234368,
  "created_at" : "2014-10-03 20:33:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "emo",
      "screen_name" : "bish134",
      "indices" : [ 11, 19 ],
      "id_str" : "38076141",
      "id" : 38076141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/TNPxEgB1dx",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "518108436509519872",
  "geo" : { },
  "id_str" : "518108726419816448",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking @bish134 yes! Come down anytime today or tomorrow http:\/\/t.co\/TNPxEgB1dx",
  "id" : 518108726419816448,
  "in_reply_to_status_id" : 518108436509519872,
  "created_at" : "2014-10-03 18:42:01 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518108552494600193",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden you aren\u2019t following me, so email perchance?",
  "id" : 518108552494600193,
  "created_at" : "2014-10-03 18:41:19 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 37, 47 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soakupthesun",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/FBR4X45Rg9",
      "expanded_url" : "http:\/\/instagram.com\/p\/ts1gTJkgc0\/",
      "display_url" : "instagram.com\/p\/ts1gTJkgc0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8848674871, -78.8738115193 ]
  },
  "id_str" : "518107361933029376",
  "text" : "Yay for waiting until after lunch!! \u201C@BillybobN: No no no no no. #soakupthesun http:\/\/t.co\/FBR4X45Rg9\u201D",
  "id" : 518107361933029376,
  "created_at" : "2014-10-03 18:36:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 30, 42 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/518080513119354880\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QbVCViIR2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCXeynIMAAOk8h.jpg",
      "id_str" : "518080512385363968",
      "id" : 518080512385363968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCXeynIMAAOk8h.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 922
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 922
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QbVCViIR2i"
    } ],
    "hashtags" : [ {
      "text" : "AQband",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518085006900854784",
  "text" : "RT @UnclePhilsBlog: BREAKING: @AqueousBand announces new album name will be CYCLES, new single coming Monday, and cover art! #AQband http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 10, 22 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UnclePhilsBlog\/status\/518080513119354880\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/QbVCViIR2i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCXeynIMAAOk8h.jpg",
        "id_str" : "518080512385363968",
        "id" : 518080512385363968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCXeynIMAAOk8h.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 922
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 922
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QbVCViIR2i"
      } ],
      "hashtags" : [ {
        "text" : "AQband",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518080513119354880",
    "text" : "BREAKING: @AqueousBand announces new album name will be CYCLES, new single coming Monday, and cover art! #AQband http:\/\/t.co\/QbVCViIR2i",
    "id" : 518080513119354880,
    "created_at" : "2014-10-03 16:49:54 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 518085006900854784,
  "created_at" : "2014-10-03 17:07:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 47, 62 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/518081585456111616\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/TfEuqGgJTy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCYdJCIQAAzZRC.jpg",
      "id_str" : "518081583556083712",
      "id" : 518081583556083712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCYdJCIQAAzZRC.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/TfEuqGgJTy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518081585456111616",
  "text" : "Big thanks to Basecamp for sponsoring some fun @nickelcityruby! http:\/\/t.co\/TfEuqGgJTy",
  "id" : 518081585456111616,
  "created_at" : "2014-10-03 16:54:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 3, 9 ],
      "id_str" : "15265916",
      "id" : 15265916
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8748932001, -78.8697357208 ]
  },
  "id_str" : "518062716700065793",
  "text" : "So @dabit just threw down the first live coding DJ intro I\u2019ve seen. Crazy. #ncrc14",
  "id" : 518062716700065793,
  "created_at" : "2014-10-03 15:39:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Johnny Winn",
      "screen_name" : "johnny_rugger",
      "indices" : [ 11, 25 ],
      "id_str" : "463158848",
      "id" : 463158848
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 102, 113 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518056482798338049",
  "geo" : { },
  "id_str" : "518057097716854784",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @johnny_rugger @nickelcityruby if I was in charge it would be a lot more mellow and jammy. @kevinpurdy helped with some Songzas",
  "id" : 518057097716854784,
  "in_reply_to_status_id" : 518056482798338049,
  "created_at" : "2014-10-03 15:16:51 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518055271650705408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8860570634, -78.8727358089 ]
  },
  "id_str" : "518056413323886593",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo pretty sure I do at home! Will check this weekend",
  "id" : 518056413323886593,
  "in_reply_to_status_id" : 518055271650705408,
  "created_at" : "2014-10-03 15:14:08 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Mackenzie",
      "screen_name" : "mackesque",
      "indices" : [ 0, 10 ],
      "id_str" : "21399337",
      "id" : 21399337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518035437571821568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8854506449, -78.8725282134 ]
  },
  "id_str" : "518055105351135232",
  "in_reply_to_user_id" : 21399337,
  "text" : "@mackesque thanks!",
  "id" : 518055105351135232,
  "in_reply_to_status_id" : 518035437571821568,
  "created_at" : "2014-10-03 15:08:56 +0000",
  "in_reply_to_screen_name" : "mackesque",
  "in_reply_to_user_id_str" : "21399337",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518054618908327936",
  "text" : "Weirdest thing about #ncrc14: it\u2019s been a year since the last one",
  "id" : 518054618908327936,
  "created_at" : "2014-10-03 15:07:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gosselin",
      "screen_name" : "skinicide",
      "indices" : [ 0, 10 ],
      "id_str" : "306547983",
      "id" : 306547983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518052721254215680",
  "geo" : { },
  "id_str" : "518054295938551809",
  "in_reply_to_user_id" : 306547983,
  "text" : "@skinicide despite recent events they did help us out a lot this year and last with sponsorship",
  "id" : 518054295938551809,
  "in_reply_to_status_id" : 518052721254215680,
  "created_at" : "2014-10-03 15:05:43 +0000",
  "in_reply_to_screen_name" : "skinicide",
  "in_reply_to_user_id_str" : "306547983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/518030151356264448\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/4RZuQA0BtS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzBprTJIAAAUqWw.jpg",
      "id_str" : "518030149741445120",
      "id" : 518030149741445120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzBprTJIAAAUqWw.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4RZuQA0BtS"
    } ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518034833021612032",
  "text" : "RT @nickelcityruby: All set up! #ncrc14 http:\/\/t.co\/4RZuQA0BtS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/518030151356264448\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/4RZuQA0BtS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzBprTJIAAAUqWw.jpg",
        "id_str" : "518030149741445120",
        "id" : 518030149741445120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzBprTJIAAAUqWw.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4RZuQA0BtS"
      } ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518030151356264448",
    "text" : "All set up! #ncrc14 http:\/\/t.co\/4RZuQA0BtS",
    "id" : 518030151356264448,
    "created_at" : "2014-10-03 13:29:47 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 518034833021612032,
  "created_at" : "2014-10-03 13:48:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/vi2pPIbZX1",
      "expanded_url" : "http:\/\/instagram.com\/p\/tsNtpGMOe0\/",
      "display_url" : "instagram.com\/p\/tsNtpGMOe0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "518034804252897281",
  "text" : "RT @PublicEspresso: We're serving pour-overs at the @nickelcityruby conference at the Buffalo &amp; Erie County Library!\u2026 http:\/\/t.co\/vi2pPIbZX1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/vi2pPIbZX1",
        "expanded_url" : "http:\/\/instagram.com\/p\/tsNtpGMOe0\/",
        "display_url" : "instagram.com\/p\/tsNtpGMOe0\/"
      } ]
    },
    "geo" : { },
    "id_str" : "518019177765167104",
    "text" : "We're serving pour-overs at the @nickelcityruby conference at the Buffalo &amp; Erie County Library!\u2026 http:\/\/t.co\/vi2pPIbZX1",
    "id" : 518019177765167104,
    "created_at" : "2014-10-03 12:46:10 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 518034804252897281,
  "created_at" : "2014-10-03 13:48:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stuart",
      "screen_name" : "tomstuart",
      "indices" : [ 3, 13 ],
      "id_str" : "793725",
      "id" : 793725
    }, {
      "name" : "David Burrows",
      "screen_name" : "dburrows",
      "indices" : [ 139, 140 ],
      "id_str" : "3307761",
      "id" : 3307761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/YpB2QcjbSx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FAprpyGdgYk",
      "display_url" : "youtube.com\/watch?v=FAprpy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518000573300211712",
  "text" : "RT @tomstuart: Turns out that a drum kit is a great user interface, even when you take away the actual drums: https:\/\/t.co\/YpB2QcjbSx \/via \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Burrows",
        "screen_name" : "dburrows",
        "indices" : [ 124, 133 ],
        "id_str" : "3307761",
        "id" : 3307761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/YpB2QcjbSx",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FAprpyGdgYk",
        "display_url" : "youtube.com\/watch?v=FAprpy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517980313239437312",
    "text" : "Turns out that a drum kit is a great user interface, even when you take away the actual drums: https:\/\/t.co\/YpB2QcjbSx \/via @dburrows",
    "id" : 517980313239437312,
    "created_at" : "2014-10-03 10:11:44 +0000",
    "user" : {
      "name" : "Tom Stuart",
      "screen_name" : "tomstuart",
      "protected" : false,
      "id_str" : "793725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/44025482\/Photo_3_normal.jpg",
      "id" : 793725,
      "verified" : false
    }
  },
  "id" : 518000573300211712,
  "created_at" : "2014-10-03 11:32:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Mandrill",
      "screen_name" : "mandrillapp",
      "indices" : [ 22, 34 ],
      "id_str" : "540239057",
      "id" : 540239057
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 80, 95 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517830599994667008",
  "text" : "RT @aspleenic: Thanks @mandrillapp for sponsoring an awesome speaker dinner for @nickelcityruby #ncrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mandrill",
        "screen_name" : "mandrillapp",
        "indices" : [ 7, 19 ],
        "id_str" : "540239057",
        "id" : 540239057
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 65, 80 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517830303482912769",
    "text" : "Thanks @mandrillapp for sponsoring an awesome speaker dinner for @nickelcityruby #ncrc14",
    "id" : 517830303482912769,
    "created_at" : "2014-10-03 00:15:39 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 517830599994667008,
  "created_at" : "2014-10-03 00:16:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Sogamoso",
      "screen_name" : "sebasoga",
      "indices" : [ 0, 9 ],
      "id_str" : "41438974",
      "id" : 41438974
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 31, 45 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517807983297048576",
  "geo" : { },
  "id_str" : "517820261182087168",
  "in_reply_to_user_id" : 41438974,
  "text" : "@sebasoga feel free to drop by @coworkbuffalo",
  "id" : 517820261182087168,
  "in_reply_to_status_id" : 517807983297048576,
  "created_at" : "2014-10-02 23:35:45 +0000",
  "in_reply_to_screen_name" : "sebasoga",
  "in_reply_to_user_id_str" : "41438974",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517769073451868160",
  "text" : "Downtown Buffalo smells like Cherrios this evening.",
  "id" : 517769073451868160,
  "created_at" : "2014-10-02 20:12:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/a5XZFLrBE7",
      "expanded_url" : "https:\/\/basecamp.com\/terms",
      "display_url" : "basecamp.com\/terms"
    } ]
  },
  "in_reply_to_status_id_str" : "517721766727151617",
  "geo" : { },
  "id_str" : "517722530933530624",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 Basecamp has this under Cancellation and Termination - https:\/\/t.co\/a5XZFLrBE7",
  "id" : 517722530933530624,
  "in_reply_to_status_id" : 517721766727151617,
  "created_at" : "2014-10-02 17:07:24 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517653956915654656",
  "text" : "RT @nickelcityruby: CodeRetreat folks: the main entrance to the library is now open, head straight in and the West Room is to the right of \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517653855132471296",
    "text" : "CodeRetreat folks: the main entrance to the library is now open, head straight in and the West Room is to the right of Fables Cafe",
    "id" : 517653855132471296,
    "created_at" : "2014-10-02 12:34:31 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 517653956915654656,
  "created_at" : "2014-10-02 12:34:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517645915126259712",
  "text" : "CodeRetreat entrance is on Ellicott st not Clinton. Will be down in a few to help guide!",
  "id" : 517645915126259712,
  "created_at" : "2014-10-02 12:02:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric S",
      "screen_name" : "MutualArising",
      "indices" : [ 0, 14 ],
      "id_str" : "15913837",
      "id" : 15913837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517473319726370816",
  "geo" : { },
  "id_str" : "517499035171577856",
  "in_reply_to_user_id" : 15913837,
  "text" : "@MutualArising if you need a pickup anywhere let us know.",
  "id" : 517499035171577856,
  "in_reply_to_status_id" : 517473319726370816,
  "created_at" : "2014-10-02 02:19:19 +0000",
  "in_reply_to_screen_name" : "MutualArising",
  "in_reply_to_user_id_str" : "15913837",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517495595888439297",
  "text" : "RT @dhh: Wanting to hire the very best and insisting they all live in San Francesco is simply delusional. Far more great people outside SF \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517481377487671296",
    "text" : "Wanting to hire the very best and insisting they all live in San Francesco is simply delusional. Far more great people outside SF than in it",
    "id" : 517481377487671296,
    "created_at" : "2014-10-02 01:09:09 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 517495595888439297,
  "created_at" : "2014-10-02 02:05:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/lt4GWCZvWY",
      "expanded_url" : "https:\/\/github.com\/reddit\/reddit\/",
      "display_url" : "github.com\/reddit\/reddit\/"
    } ]
  },
  "in_reply_to_status_id_str" : "517485725479362560",
  "geo" : { },
  "id_str" : "517491754992291840",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh The entire platform is OSS https:\/\/t.co\/lt4GWCZvWY",
  "id" : 517491754992291840,
  "in_reply_to_status_id" : 517485725479362560,
  "created_at" : "2014-10-02 01:50:23 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stevens",
      "screen_name" : "kevdog",
      "indices" : [ 0, 7 ],
      "id_str" : "10696812",
      "id" : 10696812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517486234835636224",
  "geo" : { },
  "id_str" : "517488700674961408",
  "in_reply_to_user_id" : 10696812,
  "text" : "@kevdog Just confirmed with their registration this is OK",
  "id" : 517488700674961408,
  "in_reply_to_status_id" : 517486234835636224,
  "created_at" : "2014-10-02 01:38:15 +0000",
  "in_reply_to_screen_name" : "kevdog",
  "in_reply_to_user_id_str" : "10696812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 4, 13 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517484741147115520",
  "text" : "Any @CodeMash alumni not using their codes? &gt;_&gt; &lt;_&lt;",
  "id" : 517484741147115520,
  "created_at" : "2014-10-02 01:22:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 9, 18 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517483073227587585",
  "geo" : { },
  "id_str" : "517483742424616961",
  "in_reply_to_user_id" : 5743852,
  "text" : "@godfoca @poteland if you can make it up to Elmwood Village, highly recommend Blue Monk.",
  "id" : 517483742424616961,
  "in_reply_to_status_id" : 517483073227587585,
  "created_at" : "2014-10-02 01:18:33 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 9, 18 ],
      "id_str" : "49102992",
      "id" : 49102992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517481921757323264",
  "geo" : { },
  "id_str" : "517483073227587585",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca @poteland plenty of bars up on Allen St, but will be a little slower given it's Wednesday. Cantina Loco, DBGB's, Gabriel's Gate",
  "id" : 517483073227587585,
  "in_reply_to_status_id" : 517481921757323264,
  "created_at" : "2014-10-02 01:15:53 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pote",
      "screen_name" : "poteland",
      "indices" : [ 0, 9 ],
      "id_str" : "49102992",
      "id" : 49102992
    }, {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 10, 18 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517471860448301056",
  "geo" : { },
  "id_str" : "517479528881340416",
  "in_reply_to_user_id" : 49102992,
  "text" : "@poteland @godfoca headed northward?",
  "id" : 517479528881340416,
  "in_reply_to_status_id" : 517471860448301056,
  "created_at" : "2014-10-02 01:01:48 +0000",
  "in_reply_to_screen_name" : "poteland",
  "in_reply_to_user_id_str" : "49102992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meagan",
      "screen_name" : "meaganewaller",
      "indices" : [ 0, 14 ],
      "id_str" : "369585978",
      "id" : 369585978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517453818981007360",
  "geo" : { },
  "id_str" : "517454036027469824",
  "in_reply_to_user_id" : 369585978,
  "text" : "@meaganewaller we have seasons here! :P",
  "id" : 517454036027469824,
  "in_reply_to_status_id" : 517453818981007360,
  "created_at" : "2014-10-01 23:20:30 +0000",
  "in_reply_to_screen_name" : "meaganewaller",
  "in_reply_to_user_id_str" : "369585978",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#tblife",
      "screen_name" : "timbickerton",
      "indices" : [ 3, 16 ],
      "id_str" : "67096109",
      "id" : 67096109
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 42, 57 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 63, 77 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "indices" : [ 82, 95 ],
      "id_str" : "197769225",
      "id" : 197769225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517453876534845440",
  "text" : "RT @timbickerton: Excited to be attending @nickelcityruby with @Carols10cents and @JakeGoulding !!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 24, 39 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Carol&lt;'a&gt;",
        "screen_name" : "Carols10cents",
        "indices" : [ 45, 59 ],
        "id_str" : "194688433",
        "id" : 194688433
      }, {
        "name" : "Jake Goulding",
        "screen_name" : "JakeGoulding",
        "indices" : [ 64, 77 ],
        "id_str" : "197769225",
        "id" : 197769225
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517452181071757313",
    "text" : "Excited to be attending @nickelcityruby with @Carols10cents and @JakeGoulding !!",
    "id" : 517452181071757313,
    "created_at" : "2014-10-01 23:13:08 +0000",
    "user" : {
      "name" : "#tblife",
      "screen_name" : "timbickerton",
      "protected" : false,
      "id_str" : "67096109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518472772511879168\/ZXfGvbbh_normal.jpeg",
      "id" : 67096109,
      "verified" : false
    }
  },
  "id" : 517453876534845440,
  "created_at" : "2014-10-01 23:19:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "indices" : [ 3, 19 ],
      "id_str" : "37885397",
      "id" : 37885397
    }, {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 21, 27 ],
      "id_str" : "15477591",
      "id" : 15477591
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 28, 43 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517453856129966080",
  "text" : "RT @somethingconcon: @Braxo @nickelcityruby cya there homie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Thomson",
        "screen_name" : "Braxo",
        "indices" : [ 0, 6 ],
        "id_str" : "15477591",
        "id" : 15477591
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 7, 22 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "517428512957804544",
    "geo" : { },
    "id_str" : "517445994355896320",
    "in_reply_to_user_id" : 15477591,
    "text" : "@Braxo @nickelcityruby cya there homie",
    "id" : 517445994355896320,
    "in_reply_to_status_id" : 517428512957804544,
    "created_at" : "2014-10-01 22:48:33 +0000",
    "in_reply_to_screen_name" : "Braxo",
    "in_reply_to_user_id_str" : "15477591",
    "user" : {
      "name" : "Con-Wan Kanobi",
      "screen_name" : "somethingconcon",
      "protected" : false,
      "id_str" : "37885397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2486106537\/image_normal.jpg",
      "id" : 37885397,
      "verified" : false
    }
  },
  "id" : 517453856129966080,
  "created_at" : "2014-10-01 23:19:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "indices" : [ 3, 9 ],
      "id_str" : "15477591",
      "id" : 15477591
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 21, 36 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517453837011939329",
  "text" : "RT @Braxo: Excited w @nickelcityruby conference this Fri\/Sat in Buffalo.\n\nAfter events yesterday\/today, I\u2019m bringing a few copies of my res\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 10, 25 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517428512957804544",
    "text" : "Excited w @nickelcityruby conference this Fri\/Sat in Buffalo.\n\nAfter events yesterday\/today, I\u2019m bringing a few copies of my resume as well.",
    "id" : 517428512957804544,
    "created_at" : "2014-10-01 21:39:05 +0000",
    "user" : {
      "name" : "Jesse Thomson",
      "screen_name" : "Braxo",
      "protected" : false,
      "id_str" : "15477591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2929946571\/9ff8217b64a06a9ce2e6ea3373ed1f0a_normal.jpeg",
      "id" : 15477591,
      "verified" : false
    }
  },
  "id" : 517453837011939329,
  "created_at" : "2014-10-01 23:19:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Imbert",
      "screen_name" : "courtneyimbert",
      "indices" : [ 3, 18 ],
      "id_str" : "16041590",
      "id" : 16041590
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/courtneyimbert\/status\/517426623080316928\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JmPXB4dc9g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By5ExGGIcAAd2I5.jpg",
      "id_str" : "517426617434796032",
      "id" : 517426617434796032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By5ExGGIcAAd2I5.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JmPXB4dc9g"
    } ],
    "hashtags" : [ {
      "text" : "Ubuffalodc",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517432632809103360",
  "text" : "RT @courtneyimbert: Police visually searched my vehicle while I was visiting for #Ubuffalodc. Not OK, SUNY Buffalo, even \"for safety\". http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/courtneyimbert\/status\/517426623080316928\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/JmPXB4dc9g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By5ExGGIcAAd2I5.jpg",
        "id_str" : "517426617434796032",
        "id" : 517426617434796032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By5ExGGIcAAd2I5.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JmPXB4dc9g"
      } ],
      "hashtags" : [ {
        "text" : "Ubuffalodc",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517426623080316928",
    "text" : "Police visually searched my vehicle while I was visiting for #Ubuffalodc. Not OK, SUNY Buffalo, even \"for safety\". http:\/\/t.co\/JmPXB4dc9g",
    "id" : 517426623080316928,
    "created_at" : "2014-10-01 21:31:34 +0000",
    "user" : {
      "name" : "Courtney Imbert",
      "screen_name" : "courtneyimbert",
      "protected" : false,
      "id_str" : "16041590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527005646411943936\/WRp5IWAT_normal.jpeg",
      "id" : 16041590,
      "verified" : false
    }
  },
  "id" : 517432632809103360,
  "created_at" : "2014-10-01 21:55:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@pplcallmejam",
      "screen_name" : "Justjamonit",
      "indices" : [ 0, 12 ],
      "id_str" : "2863047410",
      "id" : 2863047410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517419457766244353",
  "geo" : { },
  "id_str" : "517421106248953856",
  "in_reply_to_user_id" : 1547239940,
  "text" : "@justjamonit awesome, welcome! Highly recommend exploring Allentown and Elmwood Village this evening, or head down to Canalside",
  "id" : 517421106248953856,
  "in_reply_to_status_id" : 517419457766244353,
  "created_at" : "2014-10-01 21:09:39 +0000",
  "in_reply_to_screen_name" : "pplcallmejam",
  "in_reply_to_user_id_str" : "1547239940",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon hendren",
      "screen_name" : "fart",
      "indices" : [ 0, 5 ],
      "id_str" : "14166714",
      "id" : 14166714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517418190972792832",
  "geo" : { },
  "id_str" : "517419375620788224",
  "in_reply_to_user_id" : 14166714,
  "text" : "@fart are you selling these?",
  "id" : 517419375620788224,
  "in_reply_to_status_id" : 517418190972792832,
  "created_at" : "2014-10-01 21:02:46 +0000",
  "in_reply_to_screen_name" : "fart",
  "in_reply_to_user_id_str" : "14166714",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/517414804001001472\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/zRKl73AJgX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By46BUcCUAA7Zz9.jpg",
      "id_str" : "517414801534767104",
      "id" : 517414801534767104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By46BUcCUAA7Zz9.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zRKl73AJgX"
    } ],
    "hashtags" : [ {
      "text" : "ncrc14",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517415128195543041",
  "text" : "RT @nickelcityruby: Beta testing our name tags\u2026 #ncrc14 http:\/\/t.co\/zRKl73AJgX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/517414804001001472\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/zRKl73AJgX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By46BUcCUAA7Zz9.jpg",
        "id_str" : "517414801534767104",
        "id" : 517414801534767104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By46BUcCUAA7Zz9.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zRKl73AJgX"
      } ],
      "hashtags" : [ {
        "text" : "ncrc14",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517414804001001472",
    "text" : "Beta testing our name tags\u2026 #ncrc14 http:\/\/t.co\/zRKl73AJgX",
    "id" : 517414804001001472,
    "created_at" : "2014-10-01 20:44:37 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 517415128195543041,
  "created_at" : "2014-10-01 20:45:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pourmecoffee\/status\/517072894825070593\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KC8ylpPcZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0DDsSIYAAjSKr.jpg",
      "id_str" : "517072894179172352",
      "id" : 517072894179172352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0DDsSIYAAjSKr.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KC8ylpPcZT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/x77bOc9gHE",
      "expanded_url" : "http:\/\/www.nnvl.noaa.gov\/MediaDetail2.php?MediaID=1620&MediaTypeID=1",
      "display_url" : "nnvl.noaa.gov\/MediaDetail2.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517388662326050816",
  "text" : "RT @pourmecoffee: NOAA's new high resolution weather model appears to show southern US engulfed in horrorflames http:\/\/t.co\/x77bOc9gHE http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pourmecoffee\/status\/517072894825070593\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KC8ylpPcZT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By0DDsSIYAAjSKr.jpg",
        "id_str" : "517072894179172352",
        "id" : 517072894179172352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0DDsSIYAAjSKr.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KC8ylpPcZT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/x77bOc9gHE",
        "expanded_url" : "http:\/\/www.nnvl.noaa.gov\/MediaDetail2.php?MediaID=1620&MediaTypeID=1",
        "display_url" : "nnvl.noaa.gov\/MediaDetail2.p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517072894825070593",
    "text" : "NOAA's new high resolution weather model appears to show southern US engulfed in horrorflames http:\/\/t.co\/x77bOc9gHE http:\/\/t.co\/KC8ylpPcZT",
    "id" : 517072894825070593,
    "created_at" : "2014-09-30 22:05:59 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528514130257657856\/Ki8MgmBV_normal.jpeg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 517388662326050816,
  "created_at" : "2014-10-01 19:00:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Wunsch",
      "screen_name" : "markwunsch",
      "indices" : [ 3, 14 ],
      "id_str" : "15108584",
      "id" : 15108584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/KYCEqeHV2x",
      "expanded_url" : "http:\/\/tilde.club",
      "display_url" : "tilde.club"
    } ]
  },
  "geo" : { },
  "id_str" : "517381317487779840",
  "text" : "RT @markwunsch: My favorite thing about http:\/\/t.co\/KYCEqeHV2x? The API is just `scp` and `rsync`. Incredible how much obfuscation exists i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/KYCEqeHV2x",
        "expanded_url" : "http:\/\/tilde.club",
        "display_url" : "tilde.club"
      } ]
    },
    "geo" : { },
    "id_str" : "517380756713521152",
    "text" : "My favorite thing about http:\/\/t.co\/KYCEqeHV2x? The API is just `scp` and `rsync`. Incredible how much obfuscation exists in web publishing.",
    "id" : 517380756713521152,
    "created_at" : "2014-10-01 18:29:19 +0000",
    "user" : {
      "name" : "Mark Wunsch",
      "screen_name" : "markwunsch",
      "protected" : false,
      "id_str" : "15108584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1802551048\/headshot_normal.jpg",
      "id" : 15108584,
      "verified" : false
    }
  },
  "id" : 517381317487779840,
  "created_at" : "2014-10-01 18:31:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/517375012810928128\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/E2kgbjbn4c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By4V1KVCMAAb2zC.jpg",
      "id_str" : "517375010244014080",
      "id" : 517375010244014080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By4V1KVCMAAb2zC.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E2kgbjbn4c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517375034671644672",
  "text" : "RT @nickelcityruby: We just got a fun swag shipment in\u2026 http:\/\/t.co\/E2kgbjbn4c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nickelcityruby\/status\/517375012810928128\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/E2kgbjbn4c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By4V1KVCMAAb2zC.jpg",
        "id_str" : "517375010244014080",
        "id" : 517375010244014080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By4V1KVCMAAb2zC.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E2kgbjbn4c"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517375012810928128",
    "text" : "We just got a fun swag shipment in\u2026 http:\/\/t.co\/E2kgbjbn4c",
    "id" : 517375012810928128,
    "created_at" : "2014-10-01 18:06:30 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 517375034671644672,
  "created_at" : "2014-10-01 18:06:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 3, 11 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/k43gg5heMN",
      "expanded_url" : "https:\/\/itunes.apple.com\/gb\/app\/pokemon-tcg-online\/id841098932?mt=8",
      "display_url" : "itunes.apple.com\/gb\/app\/pokemon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517374786352070656",
  "text" : "RT @ag_dubs: PSA: pokemon the trading card game, now available for iOS https:\/\/t.co\/k43gg5heMN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/k43gg5heMN",
        "expanded_url" : "https:\/\/itunes.apple.com\/gb\/app\/pokemon-tcg-online\/id841098932?mt=8",
        "display_url" : "itunes.apple.com\/gb\/app\/pokemon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517372567624359936",
    "text" : "PSA: pokemon the trading card game, now available for iOS https:\/\/t.co\/k43gg5heMN",
    "id" : 517372567624359936,
    "created_at" : "2014-10-01 17:56:47 +0000",
    "user" : {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "protected" : false,
      "id_str" : "304067888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545742985921826816\/26ordwAe_normal.jpeg",
      "id" : 304067888,
      "verified" : false
    }
  },
  "id" : 517374786352070656,
  "created_at" : "2014-10-01 18:05:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sweet michael",
      "screen_name" : "michaeljhudson",
      "indices" : [ 3, 18 ],
      "id_str" : "35050151",
      "id" : 35050151
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/michaeljhudson\/status\/517348390238453761\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/OVgS1PpfwR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By39nnlIgAAQcBW.jpg",
      "id_str" : "517348389298929664",
      "id" : 517348389298929664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By39nnlIgAAQcBW.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/OVgS1PpfwR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517352198364069888",
  "text" : "RT @michaeljhudson: Cool, my county sheriff has a mobile diving platform http:\/\/t.co\/OVgS1PpfwR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/michaeljhudson\/status\/517348390238453761\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/OVgS1PpfwR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By39nnlIgAAQcBW.jpg",
        "id_str" : "517348389298929664",
        "id" : 517348389298929664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By39nnlIgAAQcBW.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/OVgS1PpfwR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517348390238453761",
    "text" : "Cool, my county sheriff has a mobile diving platform http:\/\/t.co\/OVgS1PpfwR",
    "id" : 517348390238453761,
    "created_at" : "2014-10-01 16:20:42 +0000",
    "user" : {
      "name" : "sweet michael",
      "screen_name" : "michaeljhudson",
      "protected" : false,
      "id_str" : "35050151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563975041579106304\/xkgFn3yT_normal.jpeg",
      "id" : 35050151,
      "verified" : false
    }
  },
  "id" : 517352198364069888,
  "created_at" : "2014-10-01 16:35:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517350841683300352",
  "geo" : { },
  "id_str" : "517352059746525184",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh well, how else are they going to develop an alt-cryptocurrency if they can't keep an eye on all of their workers",
  "id" : 517352059746525184,
  "in_reply_to_status_id" : 517350841683300352,
  "created_at" : "2014-10-01 16:35:17 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/7ZkGst0Cbh",
      "expanded_url" : "http:\/\/www.oreilly.com\/pub\/e\/3102",
      "display_url" : "oreilly.com\/pub\/e\/3102"
    } ]
  },
  "geo" : { },
  "id_str" : "517346150567796736",
  "text" : "\"It's not you. It's Git. Promise.\" - Truest words I've seen today http:\/\/t.co\/7ZkGst0Cbh",
  "id" : 517346150567796736,
  "created_at" : "2014-10-01 16:11:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 9, 16 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 17, 27 ],
      "id_str" : "59341538",
      "id" : 59341538
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 49, 63 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517341735606046720",
  "geo" : { },
  "id_str" : "517341875213045760",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca @bryanl @tehviking feel free to drop by @coworkbuffalo. :)",
  "id" : 517341875213045760,
  "in_reply_to_status_id" : 517341735606046720,
  "created_at" : "2014-10-01 15:54:49 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 65, 72 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/7i4fuWxpir",
      "expanded_url" : "http:\/\/tilde.club\/~qrush\/",
      "display_url" : "tilde.club\/~qrush\/"
    } ]
  },
  "geo" : { },
  "id_str" : "517333320724537344",
  "text" : "Moved the gifs to http:\/\/t.co\/7i4fuWxpir because why not. Thanks @ftrain!",
  "id" : 517333320724537344,
  "created_at" : "2014-10-01 15:20:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Kevin Collette",
      "screen_name" : "collettiquette",
      "indices" : [ 8, 23 ],
      "id_str" : "131198567",
      "id" : 131198567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517304792985907200",
  "geo" : { },
  "id_str" : "517304976456970241",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @collettiquette Sold",
  "id" : 517304976456970241,
  "in_reply_to_status_id" : 517304792985907200,
  "created_at" : "2014-10-01 13:28:12 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Collette",
      "screen_name" : "collettiquette",
      "indices" : [ 3, 18 ],
      "id_str" : "131198567",
      "id" : 131198567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nickelcityruby",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517303079218061312",
  "text" : "RT @collettiquette: Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo. #nickelcityruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nickelcityruby",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517289203164790784",
    "text" : "Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo. #nickelcityruby",
    "id" : 517289203164790784,
    "created_at" : "2014-10-01 12:25:31 +0000",
    "user" : {
      "name" : "Kevin Collette",
      "screen_name" : "collettiquette",
      "protected" : false,
      "id_str" : "131198567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552965824383037442\/MbV67a67_normal.jpeg",
      "id" : 131198567,
      "verified" : false
    }
  },
  "id" : 517303079218061312,
  "created_at" : "2014-10-01 13:20:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 3, 12 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 46, 56 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/h40kRcORt0",
      "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3779-apple-has-quite-a-few-more-rules-than-the#add_comment",
      "display_url" : "signalvnoise.com\/posts\/3779-app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517303019247919106",
  "text" : "RT @shildner: I made an App Store preview for @37signals.  It was fun.  https:\/\/t.co\/h40kRcORt0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 32, 42 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/h40kRcORt0",
        "expanded_url" : "https:\/\/signalvnoise.com\/posts\/3779-apple-has-quite-a-few-more-rules-than-the#add_comment",
        "display_url" : "signalvnoise.com\/posts\/3779-app\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517073292457680896",
    "text" : "I made an App Store preview for @37signals.  It was fun.  https:\/\/t.co\/h40kRcORt0",
    "id" : 517073292457680896,
    "created_at" : "2014-09-30 22:07:34 +0000",
    "user" : {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "protected" : false,
      "id_str" : "16225196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440887180529897472\/Hp3eZzzI_normal.jpeg",
      "id" : 16225196,
      "verified" : false
    }
  },
  "id" : 517303019247919106,
  "created_at" : "2014-10-01 13:20:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 11, 15 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/i2hK5klAGg",
      "expanded_url" : "http:\/\/io9.com\/abandoned-space-observatories-are-monuments-to-science-1479519920",
      "display_url" : "io9.com\/abandoned-spac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517302382607101953",
  "text" : "So I found @lrz\u2019s evil super villain lair http:\/\/t.co\/i2hK5klAGg",
  "id" : 517302382607101953,
  "created_at" : "2014-10-01 13:17:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "calebthompson",
      "indices" : [ 0, 14 ],
      "id_str" : "290866979",
      "id" : 290866979
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517160978480648192",
  "geo" : { },
  "id_str" : "517300046853730307",
  "in_reply_to_user_id" : 290866979,
  "text" : "@calebthompson @steveklabnik I think the only way this would work is by donating, a deposit, and a very limited set of games to start",
  "id" : 517300046853730307,
  "in_reply_to_status_id" : 517160978480648192,
  "created_at" : "2014-10-01 13:08:36 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
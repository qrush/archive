Grailbird.data.tweets_2009_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Sargent",
      "screen_name" : "will_sargent",
      "indices" : [ 0, 13 ],
      "id_str" : "5748162",
      "id" : 5748162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1165989306",
  "geo" : { },
  "id_str" : "1165995173",
  "in_reply_to_user_id" : 5748162,
  "text" : "@will_sargent Using REST really gets rid of the need for a service layer. If you haven't looked into the routing system, check it out.",
  "id" : 1165995173,
  "in_reply_to_status_id" : 1165989306,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "will_sargent",
  "in_reply_to_user_id_str" : "5748162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 89, 96 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166064754",
  "text" : "Latest and greatest rdocs for your favorite gems: http:\/\/rdocul.us\/ Thanks for the link, @Croaky!",
  "id" : 1166064754,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1166912665",
  "text" : "It seems that going to bed before 4am actually produces decent sleep results.",
  "id" : 1166912665,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Dumont",
      "screen_name" : "mdumont",
      "indices" : [ 0, 8 ],
      "id_str" : "16463562",
      "id" : 16463562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167315450",
  "in_reply_to_user_id" : 16463562,
  "text" : "@mdumont Want me to bring Rock Band again for BarCampRoc? Turned out to be a lot of fun last year.",
  "id" : 1167315450,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdumont",
  "in_reply_to_user_id_str" : "16463562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167758945",
  "text" : "Wondering what team is going to go home without a shiny Lombardi trophy tonight, and wondering if they can do it 4 times in a row.",
  "id" : 1167758945,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Rowse",
      "screen_name" : "problogger",
      "indices" : [ 0, 11 ],
      "id_str" : "1143031",
      "id" : 1143031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1167782805",
  "geo" : { },
  "id_str" : "1167785746",
  "in_reply_to_user_id" : 1143031,
  "text" : "@problogger I heard something about a football game...:P",
  "id" : 1167785746,
  "in_reply_to_status_id" : 1167782805,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "problogger",
  "in_reply_to_user_id_str" : "1143031",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167848260",
  "text" : "Registering for RailsConf! 65% student discount FTW.",
  "id" : 1167848260,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167886316",
  "text" : "Great discussion on getting your first programming job: http:\/\/is.gd\/i1Er",
  "id" : 1167886316,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1167945332",
  "text" : "10 Windows 7 editions? For serious? http:\/\/tinyurl.com\/bdlmgh",
  "id" : 1167945332,
  "created_at" : "2009-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1163997124",
  "text" : "Ok, where did January go? I want it back.",
  "id" : 1163997124,
  "created_at" : "2009-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1160583654",
  "text" : "I actually like the Songsmithed version of Tom Sawyer. Maybe I'm biased. http:\/\/tinyurl.com\/cdlw55",
  "id" : 1160583654,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oscar Bonilla",
      "screen_name" : "obonilla",
      "indices" : [ 0, 9 ],
      "id_str" : "3683211",
      "id" : 3683211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1160709871",
  "in_reply_to_user_id" : 3683211,
  "text" : "@obonilla What happened to the RSS feed?",
  "id" : 1160709871,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "obonilla",
  "in_reply_to_user_id_str" : "3683211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disqus",
      "screen_name" : "disqus",
      "indices" : [ 30, 37 ],
      "id_str" : "14130628",
      "id" : 14130628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1160862334",
  "text" : "Added some redirects and BAM! @disqus fixed the broken comments. Awesome service and great support A++++++++ will buy again",
  "id" : 1160862334,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1160955929",
  "text" : "Doing some late night server upgrades. Updating Ubuntu, compiling\/installing latest REE + Passenger",
  "id" : 1160955929,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oscar Bonilla",
      "screen_name" : "obonilla",
      "indices" : [ 0, 9 ],
      "id_str" : "3683211",
      "id" : 3683211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1160950066",
  "geo" : { },
  "id_str" : "1160958663",
  "in_reply_to_user_id" : 3683211,
  "text" : "@obonilla I was in the process of changing permalinks for the blog, perhaps it was related. In any case thanks, and keep me posted!",
  "id" : 1160958663,
  "in_reply_to_status_id" : 1160950066,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "obonilla",
  "in_reply_to_user_id_str" : "3683211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter Magazine",
      "screen_name" : "reportermag",
      "indices" : [ 31, 43 ],
      "id_str" : "18381853",
      "id" : 18381853
    }, {
      "name" : "BarCamp Rochester",
      "screen_name" : "BarCampRoc",
      "indices" : [ 80, 91 ],
      "id_str" : "20751318",
      "id" : 20751318
    }, {
      "name" : "The College Driver",
      "screen_name" : "theCD",
      "indices" : [ 121, 127 ],
      "id_str" : "16686408",
      "id" : 16686408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1162288939",
  "text" : "I seem to have appeared in the @reportermag twice this week...in a picture from @barcamproc and mentioned as working for @TheCD",
  "id" : 1162288939,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1162709364",
  "text" : "Five Guys on Fridays = DELICIOUS.",
  "id" : 1162709364,
  "created_at" : "2009-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1157465600",
  "text" : "Google Apps got an upgrade, but still no themes. :[",
  "id" : 1157465600,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1157711745",
  "text" : "RT @gitready zsh git status: You could have status shown in your bash prompt but that\u2019s not your only option... http:\/\/tinyurl.com\/adhswx",
  "id" : 1157711745,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1158701035",
  "text" : "Is there any way to vendor\/gem or otherwise package up diff-lcs-1.1.2? I can't seem to make it happy.",
  "id" : 1158701035,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1158759033",
  "text" : "I think I should give up hope trying to vendor\/gem everything. There's some wicked, stupid cross gem dependencies in this project.",
  "id" : 1158759033,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1158999327",
  "text" : "Google Maps Van hits a deer, and catches it on camera just south of here in Rush, NY: http:\/\/is.gd\/hGTS",
  "id" : 1158999327,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1159500473",
  "text" : "Language presentations in PLC are turning into pissing contests by those who know the language in the audience. Wonderful.",
  "id" : 1159500473,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1159619261",
  "text" : "7 day Roguelike challenge, Mar 7-15: http:\/\/is.gd\/hIU4 Perhaps I'll try my hand at it!",
  "id" : 1159619261,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1159904676",
  "text" : "I really wish the wifi wouldn't disconnect me every 5 minutes. Starting to get really annoying.",
  "id" : 1159904676,
  "created_at" : "2009-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1153953359",
  "text" : "Gonna try out zsh for a while, see how it differs from fish.",
  "id" : 1153953359,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "why the lucky stiff",
      "screen_name" : "_why",
      "indices" : [ 78, 83 ],
      "id_str" : "275198114",
      "id" : 275198114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1153977555",
  "text" : "If anyone has suggestions for zsh configurations, let me know! I'm trying out @_why's from here: http:\/\/dotfiles.org\/~_why\/.zshrc",
  "id" : 1153977555,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1153986261",
  "text" : "Perhaps I've been spoiled by fish's autocomplete and firefox awesome bar style partial searching...",
  "id" : 1153986261,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1154603065",
  "text" : "Comparing Hello World executable sizes: http:\/\/is.gd\/huQE Winner: ASM at 432 bytes. Failure: Common Lisp, 35 megs.",
  "id" : 1154603065,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1154641510",
  "text" : "GitHub Rebase #12 pushed out before I collapse for the evening\/morning: http:\/\/is.gd\/huWB Ioke is pretty damn cool.",
  "id" : 1154641510,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 0, 13 ],
      "id_str" : "1341781",
      "id" : 1341781
    }, {
      "name" : "Kevin Rose",
      "screen_name" : "kevinrose",
      "indices" : [ 104, 114 ],
      "id_str" : "657863",
      "id" : 657863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sheep",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "more",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1154652035",
  "geo" : { },
  "id_str" : "1154658632",
  "in_reply_to_user_id" : 1341781,
  "text" : "@gilesgoatboy RT how to be a twitter trendwhore 101 #sheep RT RT RT #more hashtags not enough links for @kevinrose",
  "id" : 1154658632,
  "in_reply_to_status_id" : 1154652035,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "gilesgoatboy",
  "in_reply_to_user_id_str" : "1341781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1156399368",
  "text" : "6 inches? Bah! I want to see SIX FEET OF SNOW.",
  "id" : 1156399368,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo DiNardi",
      "screen_name" : "adinardi",
      "indices" : [ 0, 9 ],
      "id_str" : "781929",
      "id" : 781929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1156915008",
  "in_reply_to_user_id" : 781929,
  "text" : "@adinardi Big Drink featured on GitHub's blog: http:\/\/tinyurl.com\/akbysu",
  "id" : 1156915008,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "adinardi",
  "in_reply_to_user_id_str" : "781929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 13, 20 ],
      "id_str" : "814306",
      "id" : 814306
    }, {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 21, 31 ],
      "id_str" : "8161622",
      "id" : 8161622
    }, {
      "name" : "GarrettAtreides",
      "screen_name" : "GarrettAtreides",
      "indices" : [ 32, 48 ],
      "id_str" : "8091602",
      "id" : 8091602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1156922969",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza @Shella @backslash @GarrettAtreides zomg, big drink on github's blog: http:\/\/is.gd\/hBol",
  "id" : 1156922969,
  "created_at" : "2009-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arwen",
      "screen_name" : "shinynu",
      "indices" : [ 0, 8 ],
      "id_str" : "14444722",
      "id" : 14444722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1153070404",
  "geo" : { },
  "id_str" : "1153074925",
  "in_reply_to_user_id" : 14444722,
  "text" : "@shinynu That's a fine form of classroom argumentation. i'm talking about boasting or blabbing about fine points that no one cares about.",
  "id" : 1153074925,
  "in_reply_to_status_id" : 1153070404,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "shinynu",
  "in_reply_to_user_id_str" : "14444722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1153448786",
  "text" : "There is something really wrong with gnome-terminal. It's not updating the screen for vim properly even. Argh!",
  "id" : 1153448786,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1150954387",
  "text" : "RT @gitready text-based graph: Just a short and interesting tip today about git log --graph http:\/\/twurl.nl\/nn36qn",
  "id" : 1150954387,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1151027918",
  "text" : "Getting motivated to write my paper due at 8am should be easy, but it's hard to come by at the moment.",
  "id" : 1151027918,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1151300863",
  "text" : "Freenode is netsplitting pretty hardcore right now.",
  "id" : 1151300863,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1151430164",
  "text" : "Infinite Canvas is really cool. I would love to see Watchmen cut up into this format. http:\/\/infinitecanvas.appjet.net",
  "id" : 1151430164,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1152281858",
  "text" : "irssi hates me. gnome-terminal is eating its text and xterm's font is too tiny, and advwindow is broken. I don't like Pidgin either. Ugh.",
  "id" : 1152281858,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Nijhof",
      "screen_name" : "MarkNijhof",
      "indices" : [ 0, 11 ],
      "id_str" : "18054983",
      "id" : 18054983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1152287812",
  "in_reply_to_user_id" : 18054983,
  "text" : "@MarkNijhof thanks for the gitready shoutout! :)",
  "id" : 1152287812,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarkNijhof",
  "in_reply_to_user_id_str" : "18054983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomas Restrepo",
      "screen_name" : "tomasrestrepo",
      "indices" : [ 0, 14 ],
      "id_str" : "13725232",
      "id" : 13725232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1152291934",
  "geo" : { },
  "id_str" : "1152299286",
  "in_reply_to_user_id" : 13725232,
  "text" : "@tomasrestrepo I've tried setting some options in ~\/.Xresources but they're just not picking up. Shouldn't be this hard though :\/",
  "id" : 1152299286,
  "in_reply_to_status_id" : 1152291934,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "tomasrestrepo",
  "in_reply_to_user_id_str" : "13725232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1153063826",
  "text" : "Attention students: arguing with the professor to prove your own knowledge only proves that you are a dolt.",
  "id" : 1153063826,
  "created_at" : "2009-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1147984047",
  "text" : "I'm sick of all the atheist links on Reddit. It's cool that they're talking about what they don't believe in, but I'd rather not see it.",
  "id" : 1147984047,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1147985321",
  "geo" : { },
  "id_str" : "1147992125",
  "in_reply_to_user_id" : 7365032,
  "text" : "@tmofee I guess I haven't noticed many pro-religion links on the site. I go there for funny\/interesting stuff, not religious discussion.",
  "id" : 1147992125,
  "in_reply_to_status_id" : 1147985321,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "terrymarc",
  "in_reply_to_user_id_str" : "7365032",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148043328",
  "text" : "Do homework, blog, or code? Way too much to do :(",
  "id" : 1148043328,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 18, 30 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148067898",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal and @singheyjude like wedding shows a little TOO much.",
  "id" : 1148067898,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148316963",
  "text" : "\"programming has become a normal human activity, and programmers are reverting to the mean of human behavior\" http:\/\/is.gd\/heks",
  "id" : 1148316963,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 0, 14 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1148177521",
  "geo" : { },
  "id_str" : "1148325564",
  "in_reply_to_user_id" : 5889062,
  "text" : "@thetorpedodog Probably making up for centuries of getting burned at the stake\/weighted and tossed in the river\/tortured\/etc. Meh.",
  "id" : 1148325564,
  "in_reply_to_status_id" : 1148177521,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "thetorpedodog",
  "in_reply_to_user_id_str" : "5889062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyonrails",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148381052",
  "text" : "from #rubyonrails on freenode: is there any plug-in for creating blogs for individual members of the site? *whump*",
  "id" : 1148381052,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1148383580",
  "geo" : { },
  "id_str" : "1148384436",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo Any hints about what they look like? More octocat?",
  "id" : 1148384436,
  "in_reply_to_status_id" : 1148383580,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148476395",
  "text" : "Rebase is going to be late again this week folks. Just too much homework and outside work to do :(",
  "id" : 1148476395,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1148486471",
  "text" : "Since when did Pandora integrate audio ads?",
  "id" : 1148486471,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1148509439",
  "geo" : { },
  "id_str" : "1148546521",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan I didn't even know you could pay for Pandora. Does it remove the ads?",
  "id" : 1148546521,
  "in_reply_to_status_id" : 1148509439,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1149235327",
  "text" : "We shouldn't have Mondays. Let's skip right to Tuesday.",
  "id" : 1149235327,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1150136783",
  "text" : "Simply stunning digital paintings: http:\/\/tinyurl.com\/594ybd Wow.",
  "id" : 1150136783,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1150154189",
  "geo" : { },
  "id_str" : "1150159681",
  "in_reply_to_user_id" : 14336720,
  "text" : "@designnewb Time to not care until it's released.",
  "id" : 1150159681,
  "in_reply_to_status_id" : 1150154189,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "douglinley",
  "in_reply_to_user_id_str" : "14336720",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Parker",
      "screen_name" : "developernotes",
      "indices" : [ 0, 15 ],
      "id_str" : "5978772",
      "id" : 5978772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1150160218",
  "geo" : { },
  "id_str" : "1150185381",
  "in_reply_to_user_id" : 5978772,
  "text" : "@developernotes No buttons, no clicking, no menus, no checkboxes, no text fields, no images, no dropdowns, no graphs, no tooltips...",
  "id" : 1150185381,
  "in_reply_to_status_id" : 1150160218,
  "created_at" : "2009-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "developernotes",
  "in_reply_to_user_id_str" : "5978772",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1145798080",
  "text" : "Scheme continues to kick my ass. Luckily, I'm one small algorithm and filling out the feedback document away from being done.",
  "id" : 1145798080,
  "created_at" : "2009-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1145988793",
  "text" : "Finished my Scheme lab, after 12+ hours of learning the language and doing the exercises. Feeling a bit drained.",
  "id" : 1145988793,
  "created_at" : "2009-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1146311214",
  "text" : "Just finished up watching FLCL with the roommate. Such a fantastic and hilarious anime.",
  "id" : 1146311214,
  "created_at" : "2009-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1147193554",
  "text" : "My nerd merit badge just arrived. Octocat is now going on my timbuk2 bag.",
  "id" : 1147193554,
  "created_at" : "2009-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1147403012",
  "text" : "I think my head just exploded with cuteness. http:\/\/tinyurl.com\/8kcjgd",
  "id" : 1147403012,
  "created_at" : "2009-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1144096521",
  "text" : "RT @gitready: status in your prompt: Yeah, we all know about the git status command but that\u2019s just way too ma... http:\/\/tinyurl.com\/atm8f4",
  "id" : 1144096521,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1144103883",
  "geo" : { },
  "id_str" : "1144176542",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck thanks :) I actually haven't tried it out myself yet, I use fish mostly. Tab completion ftw.",
  "id" : 1144176542,
  "in_reply_to_status_id" : 1144103883,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1144438764",
  "geo" : { },
  "id_str" : "1144746056",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick Seriously, I should give a talk at CUSEC? I wanted to go but couldn't afford missing 2 days of classes this year :\/",
  "id" : 1144746056,
  "in_reply_to_status_id" : 1144438764,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1144751796",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick Although I'm sure I could work things out with profs, I just didn't get a chance to this year. :( Enjoy the talks today!",
  "id" : 1144751796,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1144753528",
  "text" : "Time to get back in the swing of learning Scheme. So many more lab exercises to complete...",
  "id" : 1144753528,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 20, 29 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1144773330",
  "text" : "1429 subscribers to @gitready today. Holy crap! I think FeedBurner finally caught up after the past few days. Thanks everyone :)",
  "id" : 1144773330,
  "created_at" : "2009-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1141273876",
  "text" : "Turning on Word, and disabling Spaces. Really the only way to deal with how stupid it is on OSX.",
  "id" : 1141273876,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1141436425",
  "text" : "RT @gitready Some awesome comments about hardcore sed action and generating changelogs with graphs on today's post: http:\/\/is.gd\/gVHL",
  "id" : 1141436425,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "hasmanyjosh",
      "indices" : [ 3, 15 ],
      "id_str" : "5600242",
      "id" : 5600242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1141453284",
  "text" : "RT @hasmanyjosh: Dr Manhattan! http:\/\/tinyurl.com\/9bzukw I cannot WAIT for Watchmen to come out!",
  "id" : 1141453284,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1141475614",
  "text" : "Is WWR working for anyone else? http:\/\/downforeveryoneorjustme.com\/workingwithrails",
  "id" : 1141475614,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aslak Helles\u00F8y",
      "screen_name" : "aslak_hellesoy",
      "indices" : [ 0, 15 ],
      "id_str" : "4994591",
      "id" : 4994591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1141533418",
  "geo" : { },
  "id_str" : "1141549324",
  "in_reply_to_user_id" : 4994591,
  "text" : "@aslak_hellesoy your twitter background burns my retinas.",
  "id" : 1141549324,
  "in_reply_to_status_id" : 1141533418,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "aslak_hellesoy",
  "in_reply_to_user_id_str" : "4994591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1141824205",
  "text" : "3 hours of sleep is not enough. Why did I opt for 8am classes again?",
  "id" : 1141824205,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1142049828",
  "geo" : { },
  "id_str" : "1142141488",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy Classes: night classes suck. Beer: Yuengling, Blue Point Toasted Lager ftw! Girls: say hi to @ablissfulgal and I'm a 4th year.",
  "id" : 1142141488,
  "in_reply_to_status_id" : 1142049828,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1142007099",
  "geo" : { },
  "id_str" : "1142143192",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Saw it yesterday. What a showoff.",
  "id" : 1142143192,
  "in_reply_to_status_id" : 1142007099,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yardboy",
      "screen_name" : "Yardboy",
      "indices" : [ 0, 8 ],
      "id_str" : "7939892",
      "id" : 7939892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1142196859",
  "geo" : { },
  "id_str" : "1142232135",
  "in_reply_to_user_id" : 7939892,
  "text" : "@Yardboy I guess not :[",
  "id" : 1142232135,
  "in_reply_to_status_id" : 1142196859,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Yardboy",
  "in_reply_to_user_id_str" : "7939892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1142346063",
  "text" : "Whoever put Git on holly.cs.rit.edu is awesome.",
  "id" : 1142346063,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1142569454",
  "text" : "Sweet, got my 4 bit adder working for my EE lab. I forsee a basement workshop filled with wires and electrical junk in my future.",
  "id" : 1142569454,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco ruiz",
      "screen_name" : "Paco36",
      "indices" : [ 0, 7 ],
      "id_str" : "2460224676",
      "id" : 2460224676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1142557054",
  "geo" : { },
  "id_str" : "1142571429",
  "in_reply_to_user_id" : 15198826,
  "text" : "@paco36 The MS borg assimilated you too? What team are you working for?",
  "id" : 1142571429,
  "in_reply_to_status_id" : 1142557054,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazyweb",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1142856776",
  "text" : "ANNOUNCEMENT: Feedburner sucks. Can anyone suggest a similar service? #lazyweb",
  "id" : 1142856776,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1142917651",
  "text" : "Why do you use Working With Rails? Is it because you've gotten job leads? You're in the Top 100? I'm thinking of developing an alternative.",
  "id" : 1142917651,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1142953925",
  "text" : "It just seems that WWR has turned into a high school popularity contest. I think that the ranking system is flawed at its core",
  "id" : 1142953925,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1143219653",
  "text" : "Just wrote my first Scheme recursive function. WRYYYYYYYYYYYY",
  "id" : 1143219653,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1140706173",
  "text" : "Every time I drive into Rochester I get lost. wtf.",
  "id" : 1140706173,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1140798712",
  "text" : "At the Rochester.rb meeting, gave a little demo about Cucumber. woot!",
  "id" : 1140798712,
  "created_at" : "2009-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "peter",
      "screen_name" : "badkungfu",
      "indices" : [ 0, 10 ],
      "id_str" : "258644188",
      "id" : 258644188
    }, {
      "name" : "Jeremy Stashewsky",
      "screen_name" : "jstash",
      "indices" : [ 11, 18 ],
      "id_str" : "14996401",
      "id" : 14996401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137903133",
  "geo" : { },
  "id_str" : "1138267400",
  "in_reply_to_user_id" : 14996401,
  "text" : "@badkungfu @jstash thanks for the shoutouts, I appreciate it :)",
  "id" : 1138267400,
  "in_reply_to_status_id" : 1137903133,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jstash",
  "in_reply_to_user_id_str" : "14996401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1138932999",
  "text" : "Either FeedBurner is broken, or RubyInside has zero readers. http:\/\/tinyurl.com\/attkze",
  "id" : 1138932999,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Senior",
      "screen_name" : "damnpenguins",
      "indices" : [ 0, 13 ],
      "id_str" : "14828773",
      "id" : 14828773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1138856300",
  "geo" : { },
  "id_str" : "1138941937",
  "in_reply_to_user_id" : 14828773,
  "text" : "@damnpenguins Thanks for the shoutout! If you have any of your own tips please feel free to submit them :)",
  "id" : 1138941937,
  "in_reply_to_status_id" : 1138856300,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "damnpenguins",
  "in_reply_to_user_id_str" : "14828773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "majorfail",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1138962354",
  "text" : "Realizing that I have a major project due in less than a week #majorfail",
  "id" : 1138962354,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1139006199",
  "text" : "TweetDeck is a memory hog. 350 megs and counting for all friends, replies, DMs, and one search.",
  "id" : 1139006199,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1139666536",
  "text" : "MY LAPTOP LIVES! (With a little tape.)",
  "id" : 1139666536,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1140174064",
  "text" : "Very unhappy with my Dell XPS laptop which just got back from support. HDD supposedly broken, front panel covering LEDs has fallen off. wtf.",
  "id" : 1140174064,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1140177397",
  "geo" : { },
  "id_str" : "1140186211",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca Sure, want my paypal account to deposit the $1300?",
  "id" : 1140186211,
  "in_reply_to_status_id" : 1140177397,
  "created_at" : "2009-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1134897863",
  "text" : "I'm sure it's been said, but http:\/\/hasmygembuiltyet.org is awesome.",
  "id" : 1134897863,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1134599281",
  "geo" : { },
  "id_str" : "1135011646",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates included your log tip in the latest post on all sorts of fun logging options: http:\/\/is.gd\/gDUR",
  "id" : 1135011646,
  "in_reply_to_status_id" : 1134599281,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1135445321",
  "text" : "I've done way too much blogging today. GitHub Rebase #11: http:\/\/tinyurl.com\/7o9m8z",
  "id" : 1135445321,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle O'Neill",
      "screen_name" : "arky305",
      "indices" : [ 0, 8 ],
      "id_str" : "90296824",
      "id" : 90296824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1135508861",
  "geo" : { },
  "id_str" : "1135515469",
  "in_reply_to_user_id" : 15338525,
  "text" : "@arky305 For when? We actually need one for spring and summer.",
  "id" : 1135515469,
  "in_reply_to_status_id" : 1135508861,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "imkyleoneill",
  "in_reply_to_user_id_str" : "15338525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1135542168",
  "text" : "Figure out really how many calories you're eating your favorite fast food place: http:\/\/fatburgr.com\/restaurants",
  "id" : 1135542168,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inzader Vim",
      "screen_name" : "gilesgoatboy",
      "indices" : [ 12, 25 ],
      "id_str" : "1341781",
      "id" : 1341781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1135643085",
  "text" : "images from @gilesgoatboy's posts crack me up. reminds me of maddox. http:\/\/tinyurl.com\/8rhz3f",
  "id" : 1135643085,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1135643746",
  "geo" : { },
  "id_str" : "1135646831",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge No, you don't. Go back there and you'll remember all of the atrocities, annoying people, and fire alarms at 4am.",
  "id" : 1135646831,
  "in_reply_to_status_id" : 1135643746,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1135649917",
  "text" : "rake spec hates me, but script\/spec spec\/ works fine. Why? Who knows. Do my tests pass now? Yes.",
  "id" : 1135649917,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Clay Shafer",
      "screen_name" : "littleidea",
      "indices" : [ 0, 11 ],
      "id_str" : "14079705",
      "id" : 14079705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1135649929",
  "geo" : { },
  "id_str" : "1135650621",
  "in_reply_to_user_id" : 14079705,
  "text" : "@littleidea I actually just checked his site, he has a post about Quantum of Solace up: http:\/\/is.gd\/e7pV",
  "id" : 1135650621,
  "in_reply_to_status_id" : 1135649929,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "littleidea",
  "in_reply_to_user_id_str" : "14079705",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1136272997",
  "text" : "This makes me want to hurl. X#, the XML oriented programming language. http:\/\/www.xsharp.org\/samples\/",
  "id" : 1136272997,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1136418610",
  "text" : "People are loving the http:\/\/gitready.com tips: http:\/\/tinyurl.com\/8y5ack I should probably get started on today's!",
  "id" : 1136418610,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1136702658",
  "text" : "Probably the sickest part of the X# page: their stupid mascot and slogan: \"CODE IS POETRY\". What tools.",
  "id" : 1136702658,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "wastedbrains",
      "indices" : [ 0, 13 ],
      "id_str" : "20495424",
      "id" : 20495424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1136737104",
  "geo" : { },
  "id_str" : "1136785403",
  "in_reply_to_user_id" : 14630648,
  "text" : "@wastedbrains Ooh, definitely a good idea...an advanced one for sure. I'll ask around.",
  "id" : 1136785403,
  "in_reply_to_status_id" : 1136737104,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1136874307",
  "text" : "Feedburner's graphs just aren't loading for me today. Fail.",
  "id" : 1136874307,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 30, 39 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1136955664",
  "text" : "Set up a separate account for @gitready! Hopefully this will reduce my noise about the blog a bit.",
  "id" : 1136955664,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1136988618",
  "geo" : { },
  "id_str" : "1136998214",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida They just use git commit --signoff iirc: http:\/\/tinyurl.com\/2x5rrp",
  "id" : 1136998214,
  "in_reply_to_status_id" : 1136988618,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1137009685",
  "text" : "What mail client do you use for OSX? I want to wean myself off of GMail's web mail but I can't get the hang of Mail.app.",
  "id" : 1137009685,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137018311",
  "geo" : { },
  "id_str" : "1137020138",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida I was a few months ago, updated it 2.1 but haven't touched it since. I will again soon probably.",
  "id" : 1137020138,
  "in_reply_to_status_id" : 1137018311,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1137027962",
  "text" : "Gizmodo has a hardon for the Windows 7 'superbar'. I need to find some nerd at RIT who's got installed and try it out. http:\/\/is.gd\/gJNR",
  "id" : 1137027962,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williams",
      "screen_name" : "mwilliams",
      "indices" : [ 0, 10 ],
      "id_str" : "1259861",
      "id" : 1259861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137024921",
  "geo" : { },
  "id_str" : "1137032833",
  "in_reply_to_user_id" : 1259861,
  "text" : "@mwilliams Constantly checking the browser for new messages kills my productivity, and I'm slightly addicted to that so I want to reduce it.",
  "id" : 1137032833,
  "in_reply_to_status_id" : 1137024921,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mwilliams",
  "in_reply_to_user_id_str" : "1259861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1137063638",
  "text" : "Thanks for the replies, but the point is that I want to get away from using a browser. Less chance for distraction and random browsing.",
  "id" : 1137063638,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137096756",
  "geo" : { },
  "id_str" : "1137100615",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida Not sure. Perhaps make sure you have the right copy or back up a few rev's until it works.",
  "id" : 1137100615,
  "in_reply_to_status_id" : 1137096756,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik Nyh",
      "screen_name" : "henrik",
      "indices" : [ 0, 7 ],
      "id_str" : "14208392",
      "id" : 14208392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137092613",
  "geo" : { },
  "id_str" : "1137101117",
  "in_reply_to_user_id" : 14208392,
  "text" : "@henrik Thanks, downloaded Mailplane and gonna try it out.",
  "id" : 1137101117,
  "in_reply_to_status_id" : 1137092613,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "henrik",
  "in_reply_to_user_id_str" : "14208392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1137140112",
  "text" : "Just made sure I'm on the list to graduate from RIT next year. Sort of scary that it's coming that fast.",
  "id" : 1137140112,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1137206713",
  "text" : "Dell finally shipped my laptop back, but supposedly there's a problem with the hard drive. BSOD when booting. Well, I can take care of that!",
  "id" : 1137206713,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1137227455",
  "geo" : { },
  "id_str" : "1137229596",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold You're taking senior project next year? I thought you were a year behind me, or did you jump forward a bit?",
  "id" : 1137229596,
  "in_reply_to_status_id" : 1137227455,
  "created_at" : "2009-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1132140220",
  "text" : "Rebase is getting pushed back another day. 8am midterm means studying is more important than blogging.",
  "id" : 1132140220,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1131779363",
  "geo" : { },
  "id_str" : "1132152013",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates thanks for the plug! :) if you have any suggestions for some tips let me know.",
  "id" : 1132152013,
  "in_reply_to_status_id" : 1131779363,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Dumont",
      "screen_name" : "mdumont",
      "indices" : [ 0, 8 ],
      "id_str" : "16463562",
      "id" : 16463562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1132497081",
  "geo" : { },
  "id_str" : "1132954055",
  "in_reply_to_user_id" : 16463562,
  "text" : "@mdumont Thanks, I'll use that for an upcoming tip. As for barcamp, we'll see...I'll be cooping in Boston for spring\/summer so idk yet",
  "id" : 1132954055,
  "in_reply_to_status_id" : 1132497081,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdumont",
  "in_reply_to_user_id_str" : "16463562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1132954398",
  "text" : "OBAMARAMA DAY!",
  "id" : 1132954398,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1133263102",
  "text" : "I'm excited about President Obama, but I'd rather have him get to work than party all day.",
  "id" : 1133263102,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1133322545",
  "text" : "Anyone know of a windows media stream of the inauguration? Trying to watch from my crappy phone.",
  "id" : 1133322545,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1133679569",
  "text" : "Got video for the inaug but no sound on the EE comps. Lame.",
  "id" : 1133679569,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1133790940",
  "text" : "Change has come to http:\/\/whitehouse.gov There's even an RSS feed!",
  "id" : 1133790940,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1133566500",
  "geo" : { },
  "id_str" : "1133797786",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig JQuery is being used on http:\/\/whitehouse.gov ! (And ASP.NET too)",
  "id" : 1133797786,
  "in_reply_to_status_id" : 1133566500,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1133825328",
  "text" : "Looks as if our former President's site had RSS feeds too. archive.org ftw! But still, I'm glad they had new site up at noon.",
  "id" : 1133825328,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1134239292",
  "text" : "Professor keeps pointing out things in Scheme we can't use. Whats the point if we cant use the whole language?",
  "id" : 1134239292,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1134331154",
  "text" : "Bills are playing another game in Toronto next season WTF! Keep them in Buffalo!",
  "id" : 1134331154,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1134810399",
  "text" : "Italian food is always better the second day.",
  "id" : 1134810399,
  "created_at" : "2009-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1131764043",
  "text" : "Things.app is really helping me get a handle on what needs to get done. It's SUPER EFFECTIVE! http:\/\/culturedcode.com\/things\/",
  "id" : 1131764043,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1129237255",
  "text" : "Git's staging area, explained: http:\/\/tinyurl.com\/8kkrq3",
  "id" : 1129237255,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1129366739",
  "text" : "I really love Cucumber. Helps me get on the same page with my business guy like nothing else.",
  "id" : 1129366739,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1129370159",
  "geo" : { },
  "id_str" : "1129403533",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens Just RSpec at the moment. Helps a ridiculous amount with synthesizing requirements into implementation.",
  "id" : 1129403533,
  "in_reply_to_status_id" : 1129370159,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lockfort",
      "screen_name" : "clockfort",
      "indices" : [ 0, 10 ],
      "id_str" : "16381663",
      "id" : 16381663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1129135454",
  "geo" : { },
  "id_str" : "1129419223",
  "in_reply_to_user_id" : 16381663,
  "text" : "@clockfort I HERD YOU CAN HAZ PLAN 9 ACCOUNT",
  "id" : 1129419223,
  "in_reply_to_status_id" : 1129135454,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "clockfort",
  "in_reply_to_user_id_str" : "16381663",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1129779326",
  "text" : "Realizing that I have homework due for my 10am class at 12am: FAIL.",
  "id" : 1129779326,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1129817699",
  "text" : "Trying out NatsuLion, reminds me of Witty. A lot less busy than TweetDeck.",
  "id" : 1129817699,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1130366453",
  "text" : "8 year old passes MSCE exam, wants to grow up and create \"new operational system\" http:\/\/is.gd\/gedk",
  "id" : 1130366453,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1130581215",
  "text" : "I'm glad I woke up at 7 to finish my homework that just got pushed back a day by lazy, whining freshmen.",
  "id" : 1130581215,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1130577172",
  "geo" : { },
  "id_str" : "1130591134",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash I'm considering setting up a filter to trash the grad emails because I'm sick of it too.",
  "id" : 1130591134,
  "in_reply_to_status_id" : 1130577172,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1131070724",
  "text" : "I CAN HAS INTERNSHIP.",
  "id" : 1131070724,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 31, 38 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 75, 83 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1131188868",
  "text" : "Gitready got a shoutout on the @github blog: http:\/\/github.com\/blog Thanks @defunkt!",
  "id" : 1131188868,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik F. Kastner",
      "screen_name" : "kastner",
      "indices" : [ 0, 8 ],
      "id_str" : "627303",
      "id" : 627303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1130649712",
  "geo" : { },
  "id_str" : "1131265893",
  "in_reply_to_user_id" : 627303,
  "text" : "@kastner if you have ideas for new tips or would like to write one, I'd gladly accept it.",
  "id" : 1131265893,
  "in_reply_to_status_id" : 1130649712,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "kastner",
  "in_reply_to_user_id_str" : "627303",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1131461806",
  "geo" : { },
  "id_str" : "1131466212",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza ZOOMBINIS!!!!! HOLY CRAP",
  "id" : 1131466212,
  "in_reply_to_status_id" : 1131461806,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1131468503",
  "text" : "Today's git tip: ignoring files. Didn't know you could add exceptions, or per-user settings: http:\/\/is.gd\/guKo",
  "id" : 1131468503,
  "created_at" : "2009-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 2, 11 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1127276344",
  "text" : "A @mittense inspired post: restoring lost commits. http:\/\/tinyurl.com\/aybgq8",
  "id" : 1127276344,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1127423803",
  "text" : "Rock Band + friends = awesome Saturday night.",
  "id" : 1127423803,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1128462786",
  "text" : "Dreading doing laundry, but then again, who doesn't?",
  "id" : 1128462786,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1128540029",
  "text" : "Whenever I submit a story to Digg, the final part of the process always finds unrelated stories. Digg gitready up plzkthx: http:\/\/is.gd\/glVg",
  "id" : 1128540029,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1128710175",
  "text" : "Just ran into President Destler's posse as he moves into the dorms. Definitely the most progressive action I've seen from RIT in a long time",
  "id" : 1128710175,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1128985940",
  "text" : "Why git is better than X, LOLCAT version: http:\/\/lol.whygitisbetterthanx.com\/",
  "id" : 1128985940,
  "created_at" : "2009-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1125087412",
  "text" : "Very neat, crowdsourcing an upcoming issue of RIT's Reporter Magazine. Vote for stories that will be included: http:\/\/is.gd\/gaYD",
  "id" : 1125087412,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1125356125",
  "text" : "New gitready post on git clean and a better layout for the site! Much wider and front page is sexier. http:\/\/gitready.com\/",
  "id" : 1125356125,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1125548795",
  "text" : "DESTINATION: HENRIETTA HOTS. OBJECTIVE: OBTAIN GARBAGE PLATE. COMMENCE ARTERY CLOGGING.",
  "id" : 1125548795,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1126375606",
  "text" : "Probably the best resume for an administrative assistant, ever. http:\/\/www.craigslist.org\/about\/best\/chi\/942873935.html",
  "id" : 1126375606,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wilson",
      "screen_name" : "bradwilson",
      "indices" : [ 0, 11 ],
      "id_str" : "988341",
      "id" : 988341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1126370806",
  "geo" : { },
  "id_str" : "1126377351",
  "in_reply_to_user_id" : 988341,
  "text" : "@bradwilson Just make it 0 characters on all realms and gain your soul back. I don't enjoy looking back at the 70 days I wasted playing WoW.",
  "id" : 1126377351,
  "in_reply_to_status_id" : 1126370806,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "bradwilson",
  "in_reply_to_user_id_str" : "988341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1126693229",
  "text" : "Cucumber's site looks pretty awesome: http:\/\/cukes.info\/ Definitely a great tool to learn if you're on the Ruby boat.",
  "id" : 1126693229,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1126907831",
  "text" : "cap production deploy:rollback, how i love thee",
  "id" : 1126907831,
  "created_at" : "2009-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122608907",
  "text" : "Plan 9 talk was fantastic. I'm toying with writing a raytracer for it.",
  "id" : 1122608907,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122713002",
  "text" : "Followup to yesterday's comments to learn about git add -p: http:\/\/tinyurl.com\/9v28nv",
  "id" : 1122713002,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 68, 81 ],
      "id_str" : "6082492",
      "id" : 6082492
    }, {
      "name" : "Jason Seifer",
      "screen_name" : "jseifer",
      "indices" : [ 86, 94 ],
      "id_str" : "1714531",
      "id" : 1714531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122756284",
  "text" : "Just heard the gitready plug on railsenvy. Sad trombone ftw. Thanks @greggpollack and @jseifer!",
  "id" : 1122756284,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1122759129",
  "geo" : { },
  "id_str" : "1122779776",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens thanks, i appreciate it. it would be nice! I'm just excited that people are participating.",
  "id" : 1122779776,
  "in_reply_to_status_id" : 1122759129,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122823249",
  "text" : "I find it pathetic that RIT's Student Information System website warns you to make sure that YOU LOG OFF THIS TERMINAL WHEN DONE!!!!!!!!!!!!",
  "id" : 1122823249,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122831815",
  "text" : "Stunning pictures of Michigan's landscape and wilderness: http:\/\/tinyurl.com\/656a8k",
  "id" : 1122831815,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1122864344",
  "geo" : { },
  "id_str" : "1123006547",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 They could call it something else than 'Terminal'. The whole site is hopelessly outdated and crufty for a tech school imho.",
  "id" : 1123006547,
  "in_reply_to_status_id" : 1122864344,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Placeholder",
      "screen_name" : "_evan",
      "indices" : [ 0, 6 ],
      "id_str" : "20731037",
      "id" : 20731037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1123019355",
  "geo" : { },
  "id_str" : "1123021532",
  "in_reply_to_user_id" : 761613,
  "text" : "@_evan You are a fish.",
  "id" : 1123021532,
  "in_reply_to_status_id" : 1123019355,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "evan",
  "in_reply_to_user_id_str" : "761613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1123046886",
  "text" : "Great, missed a giant portion of the lab I'm supposed to turn in at 8am tomorrow. Can't even fake it. Augh.",
  "id" : 1123046886,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1123056371",
  "geo" : { },
  "id_str" : "1123060095",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Reading about this method...I may propose it as something to do for the next Rochester.rb meeting. Sounds like fun! :)",
  "id" : 1123060095,
  "in_reply_to_status_id" : 1123056371,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Hockenberry",
      "screen_name" : "chockenberry",
      "indices" : [ 0, 13 ],
      "id_str" : "36183",
      "id" : 36183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1122511195",
  "geo" : { },
  "id_str" : "1123062325",
  "in_reply_to_user_id" : 36183,
  "text" : "@chockenberry Why is that every time I look at your twitter feed you're talking about head massages?",
  "id" : 1123062325,
  "in_reply_to_status_id" : 1122511195,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "chockenberry",
  "in_reply_to_user_id_str" : "36183",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1123535060",
  "text" : "MORNINGS SUCK.",
  "id" : 1123535060,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1123617391",
  "text" : "The EE lab computers really suck. Altera browser. Spybot yelling about registry changes. Ball mice. It's like the lab is trapped in 2001.",
  "id" : 1123617391,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1124061748",
  "text" : "I've been spiking too long. Time to get specs passing again.",
  "id" : 1124061748,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1124591060",
  "text" : "Cons wedding: http:\/\/tinyurl.com\/79twk7",
  "id" : 1124591060,
  "created_at" : "2009-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1121086994",
  "geo" : { },
  "id_str" : "1121126052",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf I ended up brushing the frost off with my scraper at a red light. I'll keep that in mind next time.",
  "id" : 1121126052,
  "in_reply_to_status_id" : 1121086994,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1121467043",
  "text" : "An illustrated guide to Git on Windows. Definitely going up as a resource on gitready: http:\/\/nathanj.github.com\/gitguide\/tour.html",
  "id" : 1121467043,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1121477155",
  "geo" : { },
  "id_str" : "1121531684",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob yeah: http:\/\/code.google.com\/p\/msysgit\/ I doubt that will ever change.",
  "id" : 1121531684,
  "in_reply_to_status_id" : 1121477155,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1121822308",
  "text" : "Either twitter is ridiculously slow today, or RIT's internet blows. Not sure which to blame, but it sucks.",
  "id" : 1121822308,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreakingNewsOn",
      "screen_name" : "BreakingNewsOn",
      "indices" : [ 3, 18 ],
      "id_str" : "27867231",
      "id" : 27867231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1121937989",
  "text" : "RT @BreakingNewsOn US AIRWAYS PLANE CRASHES IN THE HUDSON RIVER - REPORTS. (BULLETIN)",
  "id" : 1121937989,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122155818",
  "text" : "I really hope everyone involved with the crash in NYC is ok. Stupid geese.",
  "id" : 1122155818,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122177080",
  "text" : "Holy crap, git add -p is pretty crazy. Definitely going to follow up yesterday's tip with an overview of this mode.",
  "id" : 1122177080,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1122204019",
  "text" : "Waiting for my roommate's presentation on Plan 9 to start. Excited to figure out wtf it is.",
  "id" : 1122204019,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1119860896",
  "text" : "Interactive adding, today's git tip: http:\/\/is.gd\/fVJo So much more that command can do but I wanted to keep it simple and concise.",
  "id" : 1119860896,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1119904835",
  "geo" : { },
  "id_str" : "1119911045",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold was your password: itried? Perhaps cskidsdontshower. Or maybe something obvious, sestudentsonlyknowjava.",
  "id" : 1119911045,
  "in_reply_to_status_id" : 1119904835,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1119952690",
  "text" : "Just got the the definition of synergy in my organizational behavior book. Ughhhh.",
  "id" : 1119952690,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1119959396",
  "geo" : { },
  "id_str" : "1119969346",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder HAHAHA I GET IT, YOU THINK THAT SE MAJORS ARE TRAINING TO BE MANAGERS OR SOMETHING. It's funnier when you explain the joke.",
  "id" : 1119969346,
  "in_reply_to_status_id" : 1119959396,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brandonp6",
      "screen_name" : "brandonp63",
      "indices" : [ 0, 11 ],
      "id_str" : "1029612800",
      "id" : 1029612800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1119969986",
  "geo" : { },
  "id_str" : "1119978122",
  "in_reply_to_user_id" : 15025043,
  "text" : "@brandonp63 I'm an SE major as well, I think I've seen you around.",
  "id" : 1119978122,
  "in_reply_to_status_id" : 1119969986,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "bon_mot",
  "in_reply_to_user_id_str" : "15025043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120211341",
  "text" : "Anyone know if I have to install the disqus WP plugin to import comments? Is there way to do it through disqus.com ?",
  "id" : 1120211341,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120228250",
  "text" : "Lazyweb update, looks like the plugin page explains it all. I can stay on 2.6.x, disable caching, THUNDERCATS ARE GO! http:\/\/is.gd\/fWDi",
  "id" : 1120228250,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120277692",
  "text" : "10 things to be aware of when moving to Ruby 1.9: http:\/\/tinyurl.com\/7psp6d",
  "id" : 1120277692,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120360373",
  "text" : "Rejected TF2 poster: http:\/\/tinyurl.com\/94kkb8",
  "id" : 1120360373,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120835224",
  "text" : "Wow, tons of comments overnight on gitready. Learning more through them than the writing the post itself, a bit scary.",
  "id" : 1120835224,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1120903246",
  "text" : "My car windows froze from the inside on the ride into RIT. It's way too cold out.",
  "id" : 1120903246,
  "created_at" : "2009-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1117430925",
  "text" : "Matt Knox wrote adware? What? http:\/\/tinyurl.com\/8sh8qh",
  "id" : 1117430925,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1117555485",
  "text" : "Today's git tip: visualizing your repo. http:\/\/is.gd\/fNZ0 Should I just bang out tomorrow's now or what?",
  "id" : 1117555485,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vii",
      "screen_name" : "veezus",
      "indices" : [ 0, 7 ],
      "id_str" : "818377692",
      "id" : 818377692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1117565761",
  "text" : "@veezus Oh, I have plenty of ideas, at least for a month! :) I have to keep awake in class somehow...It's also why there's a submit form.",
  "id" : 1117565761,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1117444361",
  "geo" : { },
  "id_str" : "1117567339",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder Yeah, makes me feel even worse for not starting the PLC Scheme lab yet.",
  "id" : 1117567339,
  "in_reply_to_status_id" : 1117444361,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1117577903",
  "text" : "Getting comments minutes after posting a new article is really refreshing. I just hope it stays this way for gitready. :)",
  "id" : 1117577903,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1117659161",
  "text" : "Giant GitHub RSS button, I'll never forget you. :'[",
  "id" : 1117659161,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1118449925",
  "text" : "New JQuery and a sexy new API browser. Woot. http:\/\/api.jquery.com\/",
  "id" : 1118449925,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1118625740",
  "text" : "This dude can fight every Mega Man 2 boss at once (Obviously with a turbo button and some ROM hacks.) CAN YOU!? http:\/\/is.gd\/fRhR",
  "id" : 1118625740,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1118632395",
  "text" : "\"Git rides a motorcycle, wears a leather jacket, makes women swoon and kicks ass and\/or jukeboxes.\" http:\/\/is.gd\/ezJp",
  "id" : 1118632395,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1118937793",
  "text" : "Viagara commericals when watching Star Trek on YouTube. Ugh.",
  "id" : 1118937793,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1119159954",
  "text" : "Inspired by today's XKCD, make this guy's mac mini say anything: http:\/\/coworkthailand.com\/say\/",
  "id" : 1119159954,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1119346300",
  "text" : "It's so cold outside I got brain freeze just from the walk to building 70 from my car.",
  "id" : 1119346300,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1119486155",
  "text" : "\"I had to drop out of college because my laptop came with Ubuntu on it.\" http:\/\/is.gd\/fSBy",
  "id" : 1119486155,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 0, 5 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1119590541",
  "geo" : { },
  "id_str" : "1119593764",
  "in_reply_to_user_id" : 734493,
  "text" : "@woot I like the redesign! Much cleaner and friendlier.",
  "id" : 1119593764,
  "in_reply_to_status_id" : 1119590541,
  "created_at" : "2009-01-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "woot",
  "in_reply_to_user_id_str" : "734493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114784295",
  "text" : "Today's daily git tip: fixing broken commit messages. http:\/\/tinyurl.com\/7upg3n",
  "id" : 1114784295,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114830543",
  "text" : "Loving the comments I'm getting on gitready. There's always more than one way to skin a cat with git. http:\/\/is.gd\/fDgC",
  "id" : 1114830543,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1114827701",
  "geo" : { },
  "id_str" : "1114845034",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Real name trend is real.",
  "id" : 1114845034,
  "in_reply_to_status_id" : 1114827701,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114893583",
  "text" : "Awesome, gitready's errcounter passed 1000!",
  "id" : 1114893583,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114921604",
  "text" : "RequestProcessorFactoryFactory.StatelessProcessorFactoryFactory http:\/\/is.gd\/fCgP",
  "id" : 1114921604,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1114916413",
  "geo" : { },
  "id_str" : "1114924320",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini Perhaps I'll make a dummy twitter account to redirect. This is technically my new handle...went by DoctorNick for years.",
  "id" : 1114924320,
  "in_reply_to_status_id" : 1114916413,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1114926857",
  "geo" : { },
  "id_str" : "1114932060",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini He's of the main reasons I switched it actually...and it was time for a change.",
  "id" : 1114932060,
  "in_reply_to_status_id" : 1114926857,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1115509391",
  "text" : "Wow, gitready's counter went up 2000 hits and it's on proggit. Tons of comments and alternative ways to do things, that's fantastic.",
  "id" : 1115509391,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Schildt",
      "screen_name" : "autiomaa",
      "indices" : [ 0, 9 ],
      "id_str" : "6202072",
      "id" : 6202072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1115515451",
  "geo" : { },
  "id_str" : "1115520210",
  "in_reply_to_user_id" : 6202072,
  "text" : "@autiomaa heh, I would barely call it a redesign...more like a \"simple design\". I'll keep that in mind, suggestions are always welcome. :)",
  "id" : 1115520210,
  "in_reply_to_status_id" : 1115515451,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "autiomaa",
  "in_reply_to_user_id_str" : "6202072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bilson",
      "screen_name" : "cbilson",
      "indices" : [ 0, 8 ],
      "id_str" : "721053",
      "id" : 721053
    }, {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 22, 30 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1115520480",
  "geo" : { },
  "id_str" : "1115521686",
  "in_reply_to_user_id" : 721053,
  "text" : "@cbilson Agreed. Tell @nkohari that.",
  "id" : 1115521686,
  "in_reply_to_status_id" : 1115520480,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "cbilson",
  "in_reply_to_user_id_str" : "721053",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1115531584",
  "text" : "Holy crap, gitready's RSS already has 100 subscribers. After 4 days of posts! I think I need to put the feedburner chicklet on the page too.",
  "id" : 1115531584,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. David Peterson",
      "screen_name" : "mdavid",
      "indices" : [ 0, 7 ],
      "id_str" : "5628592",
      "id" : 5628592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1115548794",
  "geo" : { },
  "id_str" : "1115555338",
  "in_reply_to_user_id" : 5628592,
  "text" : "@mdavid http:\/\/gitready.com my new blog\/project. daily git tips and information resource for the noob to the guru. :)",
  "id" : 1115555338,
  "in_reply_to_status_id" : 1115548794,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdavid",
  "in_reply_to_user_id_str" : "5628592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Cole",
      "screen_name" : "dougcole",
      "indices" : [ 0, 9 ],
      "id_str" : "15448196",
      "id" : 15448196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1115193725",
  "geo" : { },
  "id_str" : "1115559542",
  "in_reply_to_user_id" : 15448196,
  "text" : "@dougcole thanks for the shoutout :)",
  "id" : 1115559542,
  "in_reply_to_status_id" : 1115193725,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "dougcole",
  "in_reply_to_user_id_str" : "15448196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. David Peterson",
      "screen_name" : "mdavid",
      "indices" : [ 0, 7 ],
      "id_str" : "5628592",
      "id" : 5628592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1115573889",
  "geo" : { },
  "id_str" : "1115583210",
  "in_reply_to_user_id" : 5628592,
  "text" : "@mdavid thanks! I need to start on today's tip at some point now.",
  "id" : 1115583210,
  "in_reply_to_status_id" : 1115573889,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "mdavid",
  "in_reply_to_user_id_str" : "5628592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. Tyler Croy",
      "screen_name" : "agentdero",
      "indices" : [ 0, 10 ],
      "id_str" : "674593",
      "id" : 674593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116069843",
  "geo" : { },
  "id_str" : "1116099618",
  "in_reply_to_user_id" : 674593,
  "text" : "@agentdero If you're talking about gitready, I'm going to be updating the post with alternatives and a warning. Thanks for your concern.",
  "id" : 1116099618,
  "in_reply_to_status_id" : 1116069843,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "agentdero",
  "in_reply_to_user_id_str" : "674593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Norman",
      "screen_name" : "lorennorman",
      "indices" : [ 0, 12 ],
      "id_str" : "10410272",
      "id" : 10410272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116047310",
  "geo" : { },
  "id_str" : "1116100979",
  "in_reply_to_user_id" : 10410272,
  "text" : "@lorennorman Thanks for the shoutout, I appreciate it :)",
  "id" : 1116100979,
  "in_reply_to_status_id" : 1116047310,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "lorennorman",
  "in_reply_to_user_id_str" : "10410272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116165741",
  "geo" : { },
  "id_str" : "1116168022",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold I want new vending machines in the cafeteria and a senior's lounge.",
  "id" : 1116168022,
  "in_reply_to_status_id" : 1116165741,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116191677",
  "geo" : { },
  "id_str" : "1116193873",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold I was joking. That's just what every high school student senate\/government\/failure wants",
  "id" : 1116193873,
  "in_reply_to_status_id" : 1116191677,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1116236850",
  "text" : "Ballono = multiplayer online bomberman. AWESOME. http:\/\/iminlikewithyou.com",
  "id" : 1116236850,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1116450949",
  "text" : "Testing? In a CS class? For Scheme? sounds great. tatft!",
  "id" : 1116450949,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. Tyler Croy",
      "screen_name" : "agentdero",
      "indices" : [ 0, 10 ],
      "id_str" : "674593",
      "id" : 674593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116714105",
  "geo" : { },
  "id_str" : "1116833399",
  "in_reply_to_user_id" : 674593,
  "text" : "@agentdero Yeah, I'm going to be warning others of the dangers of that when I update tonight. Thanks for the feedback.",
  "id" : 1116833399,
  "in_reply_to_status_id" : 1116714105,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "agentdero",
  "in_reply_to_user_id_str" : "674593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1116906017",
  "text" : "http:\/\/gitready.com just broke 2000 hits for the day. I know it's a spike, but it's definitely fun to watch.",
  "id" : 1116906017,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116913509",
  "geo" : { },
  "id_str" : "1116952073",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt wtfz, fixing",
  "id" : 1116952073,
  "in_reply_to_status_id" : 1116913509,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1116913509",
  "geo" : { },
  "id_str" : "1116968834",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt Thanks for letting me know, embedded it instead: http:\/\/gitready.com\/submit.html",
  "id" : 1116968834,
  "in_reply_to_status_id" : 1116913509,
  "created_at" : "2009-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114346632",
  "text" : "WEB DATING GURU PROGRAMMER NEEDED. \"AFTER 8 HOURS PROTOTYPE...IT MAY TAKE ANOTHER 20 TO 30 HOURS TO COMPLETE PROGRAMMING.\" http:\/\/is.gd\/fA8r",
  "id" : 1114346632,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1113344401",
  "text" : "Going to turn on device updates now that I have an unlimited data plan. If only I had a better phone than a craptastic Motorola Q.",
  "id" : 1113344401,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Zawinski",
      "screen_name" : "jwz",
      "indices" : [ 59, 63 ],
      "id_str" : "7190742",
      "id" : 7190742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1113459590",
  "text" : "List of profanities removed from the Netscape code (thanks @jwz): http:\/\/www.jwz.org\/doc\/censorzilla.html?",
  "id" : 1113459590,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1113868397",
  "geo" : { },
  "id_str" : "1114030619",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Not really, there's plenty of projects on GitHub that use Objective-C (and presumably xcode), such as: http:\/\/github.com\/pieter\/gitx",
  "id" : 1114030619,
  "in_reply_to_status_id" : 1113868397,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114160145",
  "text" : "Watching the ACL is dead. Should have done so earlier. http:\/\/tinyurl.com\/9eaep8",
  "id" : 1114160145,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1112006566",
  "geo" : { },
  "id_str" : "1114259785",
  "in_reply_to_user_id" : 18230025,
  "text" : "@__aspir Read the transcript about the SE\/CS depts going under one roof. It's better for the long run, but I wonder about the consequences.",
  "id" : 1114259785,
  "in_reply_to_status_id" : 1112006566,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1114340463",
  "text" : "GitHub Rebase #10: http:\/\/tinyurl.com\/9ot3v8",
  "id" : 1114340463,
  "created_at" : "2009-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anita Kuno",
      "screen_name" : "anteaya",
      "indices" : [ 0, 8 ],
      "id_str" : "14262153",
      "id" : 14262153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1110119445",
  "geo" : { },
  "id_str" : "1110160747",
  "in_reply_to_user_id" : 14262153,
  "text" : "@anteaya http:\/\/gitready.com I think tomorrow's will be about reverting files.",
  "id" : 1110160747,
  "in_reply_to_status_id" : 1110119445,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "anteaya",
  "in_reply_to_user_id_str" : "14262153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The College Driver",
      "screen_name" : "theCD",
      "indices" : [ 0, 6 ],
      "id_str" : "16686408",
      "id" : 16686408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1110510821",
  "geo" : { },
  "id_str" : "1110576788",
  "in_reply_to_user_id" : 16686408,
  "text" : "@TheCD's ready to cover the Auto Show tomorrow! Excited to see the pictures and video on http:\/\/thecollegedriver.com\/autoshows\/detroit",
  "id" : 1110576788,
  "in_reply_to_status_id" : 1110510821,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "theCD",
  "in_reply_to_user_id_str" : "16686408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1110619867",
  "text" : "Git Tip #3: Reverting changes! I'm probably missing a lot here, but the basics are down: http:\/\/tinyurl.com\/9cp94d",
  "id" : 1110619867,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAIAS",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1110932612",
  "text" : "Excited to watch the tweets coming from the Auto Show! #NAIAS",
  "id" : 1110932612,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1111056089",
  "text" : "Colbert tells viewers to not make his interview with Lawrence Lessig into a dance remix. So of course, someone does: http:\/\/is.gd\/fdhI",
  "id" : 1111056089,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1111060345",
  "text" : "Caching is so easy in Rails it's ridiculous. I remember how hard it was in ASP.NET...this is a cakewalk.",
  "id" : 1111060345,
  "created_at" : "2009-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1108644313",
  "text" : "WTF: A Web site cannot set a cookie if the Domain attribute is in uppercase characters and has an odd number of characters in IE7",
  "id" : 1108644313,
  "created_at" : "2009-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1107963545",
  "geo" : { },
  "id_str" : "1108644763",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iEllie Much better! :)",
  "id" : 1108644763,
  "in_reply_to_status_id" : 1107963545,
  "created_at" : "2009-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1109177614",
  "text" : "Posted by second daily Git tip at http:\/\/gitready.com ! Really excited to see where this project will go.",
  "id" : 1109177614,
  "created_at" : "2009-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Martens",
      "screen_name" : "boblmartens",
      "indices" : [ 0, 12 ],
      "id_str" : "14486263",
      "id" : 14486263
    }, {
      "name" : "actsasflinn",
      "screen_name" : "actsasflinn",
      "indices" : [ 13, 25 ],
      "id_str" : "16051211",
      "id" : 16051211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1109349121",
  "geo" : { },
  "id_str" : "1109560475",
  "in_reply_to_user_id" : 14486263,
  "text" : "@boblmartens @actsasflinn thanks! :) if you have any you use, let me know. I'm gonna need the ammo.",
  "id" : 1109560475,
  "in_reply_to_status_id" : 1109349121,
  "created_at" : "2009-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "boblmartens",
  "in_reply_to_user_id_str" : "14486263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1109561986",
  "geo" : { },
  "id_str" : "1109564037",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn You need to get out more.",
  "id" : 1109564037,
  "in_reply_to_status_id" : 1109561986,
  "created_at" : "2009-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1106673363",
  "text" : "Taking my first real (electrical) engineering lab, and wondering why it took me over 3 years to do so.",
  "id" : 1106673363,
  "created_at" : "2009-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1106674173",
  "text" : "Taking my first real (electrical) engineering lab, and wondering why it took me over 3 years to do so.",
  "id" : 1106674173,
  "created_at" : "2009-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1107271386",
  "text" : "Just got this lovely google calendar phishing scam in my inbox: http:\/\/is.gd\/f15g",
  "id" : 1107271386,
  "created_at" : "2009-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1103427630",
  "text" : "SOMEONE MAKE THE BEATBOXING STOP (watching the CES keynote)",
  "id" : 1103427630,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1103482241",
  "text" : "Zuckerberg and Ballmer sitting in a tree...",
  "id" : 1103482241,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1103522215",
  "text" : "Seriously, this keynote has ADD. Can't focus on the damn content!",
  "id" : 1103522215,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Evans",
      "screen_name" : "paulecoyote",
      "indices" : [ 0, 12 ],
      "id_str" : "7065942",
      "id" : 7065942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1104338191",
  "geo" : { },
  "id_str" : "1104338435",
  "in_reply_to_user_id" : 7065942,
  "text" : "@paulecoyote Lionhead! did you work on Fable 2?  (yes i'm slow)",
  "id" : 1104338435,
  "in_reply_to_status_id" : 1104338191,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulecoyote",
  "in_reply_to_user_id_str" : "7065942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1104527862",
  "text" : "RIT's wifi is so useless it's hard to believe that I'm at a tech school.",
  "id" : 1104527862,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Doll",
      "screen_name" : "briandoll",
      "indices" : [ 0, 10 ],
      "id_str" : "7459092",
      "id" : 7459092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1104734112",
  "geo" : { },
  "id_str" : "1104757509",
  "in_reply_to_user_id" : 7459092,
  "text" : "@briandoll They've shut down the VAX for course registration, sadly. I registered via phone for this quarter. Boohiss.",
  "id" : 1104757509,
  "in_reply_to_status_id" : 1104734112,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "briandoll",
  "in_reply_to_user_id_str" : "7459092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1105068317",
  "text" : "I could count bits faster than RIT's wifi is sending them. And I'm on the CS floor! I'm trying to update my wifi driver in hopes that'll ...",
  "id" : 1105068317,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1105142215",
  "text" : "Setting up my old huge 19\" toshiba laptop with some basic dev tools. I forgot how irksome UAC is.",
  "id" : 1105142215,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF30\uFF21\uFF35\uFF2C\u3000\uFF26\uFF29\uFF33\uFF28\uFF25\uFF32",
      "screen_name" : "thetorpedodog",
      "indices" : [ 13, 27 ],
      "id_str" : "5889062",
      "id" : 5889062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1105504324",
  "text" : "Listening to @thetorpedodog talking about all of the other crap that developers should be doing and usually don't.",
  "id" : 1105504324,
  "created_at" : "2009-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1100680209",
  "text" : "A helpful Git tip: http:\/\/is.gd\/eJCB Perhaps this is what I should do with gitready...daily tips!",
  "id" : 1100680209,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100681855",
  "geo" : { },
  "id_str" : "1100686871",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iEllie Seriously, the social bookmarking icons on the top of your blog are hideous. Get some better ones: http:\/\/is.gd\/eJDa",
  "id" : 1100686871,
  "in_reply_to_status_id" : 1100681855,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Henneke",
      "screen_name" : "ihenpecked",
      "indices" : [ 0, 11 ],
      "id_str" : "11387152",
      "id" : 11387152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100700487",
  "geo" : { },
  "id_str" : "1100701935",
  "in_reply_to_user_id" : 11387152,
  "text" : "@ihenpecked http:\/\/visualcv.com\/nquaranto I haven't really bothered with LinkedIn yet.",
  "id" : 1100701935,
  "in_reply_to_status_id" : 1100700487,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ihenpecked",
  "in_reply_to_user_id_str" : "11387152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Schildt",
      "screen_name" : "autiomaa",
      "indices" : [ 0, 9 ],
      "id_str" : "6202072",
      "id" : 6202072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100709442",
  "geo" : { },
  "id_str" : "1100723065",
  "in_reply_to_user_id" : 6202072,
  "text" : "@autiomaa I already bought gitready.com though! :P",
  "id" : 1100723065,
  "in_reply_to_status_id" : 1100709442,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "autiomaa",
  "in_reply_to_user_id_str" : "6202072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Sallings",
      "screen_name" : "dlsspy",
      "indices" : [ 0, 7 ],
      "id_str" : "14117412",
      "id" : 14117412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100708871",
  "geo" : { },
  "id_str" : "1100723616",
  "in_reply_to_user_id" : 14117412,
  "text" : "@dlsspy Nice, I'll add it to the blog post. That's even easier.",
  "id" : 1100723616,
  "in_reply_to_status_id" : 1100708871,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "dlsspy",
  "in_reply_to_user_id_str" : "14117412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100706135",
  "geo" : { },
  "id_str" : "1100731480",
  "in_reply_to_user_id" : 7488582,
  "text" : "@runeinalya Ugh, I'd rather just give them my twitter username or my blog URL.",
  "id" : 1100731480,
  "in_reply_to_status_id" : 1100706135,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1100821444",
  "text" : "Sort of sad, the end of WinCustomize: http:\/\/forums.wincustomize.com\/335659 I joined it back in 2003!",
  "id" : 1100821444,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie Banks",
      "screen_name" : "iEllie",
      "indices" : [ 0, 7 ],
      "id_str" : "8111452",
      "id" : 8111452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100850487",
  "geo" : { },
  "id_str" : "1100862621",
  "in_reply_to_user_id" : 8111452,
  "text" : "@iEllie always here to help! :P",
  "id" : 1100862621,
  "in_reply_to_status_id" : 1100850487,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "iEllie",
  "in_reply_to_user_id_str" : "8111452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Schildt",
      "screen_name" : "autiomaa",
      "indices" : [ 0, 9 ],
      "id_str" : "6202072",
      "id" : 6202072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100844976",
  "geo" : { },
  "id_str" : "1100868855",
  "in_reply_to_user_id" : 6202072,
  "text" : "@autiomaa Definitely do it sooner rather than later, you can thank me later. http:\/\/book.git-scm.com http:\/\/github.com\/guides",
  "id" : 1100868855,
  "in_reply_to_status_id" : 1100844976,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "autiomaa",
  "in_reply_to_user_id_str" : "6202072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Jenson's Ego",
      "screen_name" : "stevej",
      "indices" : [ 0, 7 ],
      "id_str" : "150",
      "id" : 150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1100864033",
  "geo" : { },
  "id_str" : "1100872991",
  "in_reply_to_user_id" : 150,
  "text" : "@stevej Referring the to GNOME DVCS survey?",
  "id" : 1100872991,
  "in_reply_to_status_id" : 1100864033,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevej",
  "in_reply_to_user_id_str" : "150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1102188085",
  "text" : "Firing up TweetDeck again. Productivity levels slowly approaching zero...",
  "id" : 1102188085,
  "created_at" : "2009-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1098993298",
  "text" : "Well, I was starting on http:\/\/gitready.com but http:\/\/book.git-scm.com\/ is pretty much what I wanted to provide. Need to rethink it now. :\/",
  "id" : 1098993298,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1099451230",
  "text" : "5 hours of sleep definitely will not help with 8 hours of classes today. Ugh...",
  "id" : 1099451230,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1099883043",
  "text" : "I left my ID card in the gym and took the towel I should have returned. We need a monorail on campus. Or a peoplemover. Or flying cars.",
  "id" : 1099883043,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1099894897",
  "text" : "From MacRumorsLive, living up to its title in true fashion: 9:24 am\tSTEVE JOBS JUST DIED :",
  "id" : 1099894897,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1099993496",
  "text" : "Daily WTF: http:\/\/tinyurl.com\/78x7ce",
  "id" : 1099993496,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1100539539",
  "text" : "I really didn't need to learn about SELECT SQL statements in class today. Makes me wonder if professors care about students leaving.",
  "id" : 1100539539,
  "created_at" : "2009-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1097273803",
  "text" : "Getting back in the swing of classes. Only 7 weeks until coop...only 7 weeks...",
  "id" : 1097273803,
  "created_at" : "2009-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1094347924",
  "text" : "Finished in 0.0819660000000001 seconds. Thanks, RSpec, for some ridiculously accurate test results.",
  "id" : 1094347924,
  "created_at" : "2009-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1093513264",
  "text" : "First failwhale sighting of the new year!",
  "id" : 1093513264,
  "created_at" : "2009-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1094171194",
  "text" : "Blue Point Toasted Lager = delicious.",
  "id" : 1094171194,
  "created_at" : "2009-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1092822125",
  "text" : "Back in the Roc after a sort of week trip to Boston. Quite a long drive! :\/",
  "id" : 1092822125,
  "created_at" : "2009-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1093475754",
  "text" : "This guy is insane. Wants Nintendo to publish his game so he's locking himself in his room for 100 days. Yeah ok. http:\/\/www.bobsgame.com\/",
  "id" : 1093475754,
  "created_at" : "2009-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1093512761",
  "text" : "Hershey Kisses aren't exactly part of your balanced breakfast.",
  "id" : 1093512761,
  "created_at" : "2009-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
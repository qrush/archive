Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Marks",
      "screen_name" : "bizarchive",
      "indices" : [ 0, 11 ],
      "id_str" : "247090698",
      "id" : 247090698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/kFPjGmp3dG",
      "expanded_url" : "http:\/\/phish.net",
      "display_url" : "phish.net"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Xg1GqSXZg1",
      "expanded_url" : "http:\/\/aqueousband.net",
      "display_url" : "aqueousband.net"
    } ]
  },
  "in_reply_to_status_id_str" : "483809988486643712",
  "geo" : { },
  "id_str" : "483810163447447554",
  "in_reply_to_user_id" : 247090698,
  "text" : "@bizarchive headed to mansfield? Would love to chat about http:\/\/t.co\/kFPjGmp3dG if so (been building http:\/\/t.co\/Xg1GqSXZg1 here)",
  "id" : 483810163447447554,
  "in_reply_to_status_id" : 483809988486643712,
  "created_at" : "2014-07-01 03:11:46 +0000",
  "in_reply_to_screen_name" : "bizarchive",
  "in_reply_to_user_id_str" : "247090698",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan",
      "screen_name" : "alandipert",
      "indices" : [ 0, 11 ],
      "id_str" : "40270600",
      "id" : 40270600
    }, {
      "name" : "\u0250\u026F\u0131s u\u01DDq",
      "screen_name" : "bensima",
      "indices" : [ 12, 20 ],
      "id_str" : "16747849",
      "id" : 16747849
    }, {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 31, 40 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483794928707706880",
  "geo" : { },
  "id_str" : "483808815255928833",
  "in_reply_to_user_id" : 40270600,
  "text" : "@alandipert @bensima hmm maybe @metadave?",
  "id" : 483808815255928833,
  "in_reply_to_status_id" : 483794928707706880,
  "created_at" : "2014-07-01 03:06:24 +0000",
  "in_reply_to_screen_name" : "alandipert",
  "in_reply_to_user_id_str" : "40270600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483719764796141568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3721048795, -71.1230330542 ]
  },
  "id_str" : "483721506078224384",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo no pressure! Let me know if I can help.",
  "id" : 483721506078224384,
  "in_reply_to_status_id" : 483719764796141568,
  "created_at" : "2014-06-30 21:19:28 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483590183783518208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3723951744, -71.1220447659 ]
  },
  "id_str" : "483719665256906753",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora also might be cool to mention the free bike racks the city provides businesses (the blue buffalo ones)",
  "id" : 483719665256906753,
  "in_reply_to_status_id" : 483590183783518208,
  "created_at" : "2014-06-30 21:12:09 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483590183783518208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.372379425, -71.1221484214 ]
  },
  "id_str" : "483719560848080897",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora awesome, love seeing more bikers in town. Suggestion for another episode: how to bike commute!",
  "id" : 483719560848080897,
  "in_reply_to_status_id" : 483590183783518208,
  "created_at" : "2014-06-30 21:11:45 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 3, 14 ],
      "id_str" : "21421691",
      "id" : 21421691
    }, {
      "name" : "VisitBuffaloNiagara",
      "screen_name" : "BuffaloNiagara",
      "indices" : [ 132, 140 ],
      "id_str" : "17994784",
      "id" : 17994784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/N1n8APJqPA",
      "expanded_url" : "http:\/\/youtu.be\/NKtWXkql0DQ",
      "display_url" : "youtu.be\/NKtWXkql0DQ"
    } ]
  },
  "geo" : { },
  "id_str" : "483719303426875392",
  "text" : "RT @PatSandora: We're so excited to explore Buffalo on two wheels. Come along for the ride (via helmet cam!) http:\/\/t.co\/N1n8APJqPA @Buffal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VisitBuffaloNiagara",
        "screen_name" : "BuffaloNiagara",
        "indices" : [ 116, 131 ],
        "id_str" : "17994784",
        "id" : 17994784
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/N1n8APJqPA",
        "expanded_url" : "http:\/\/youtu.be\/NKtWXkql0DQ",
        "display_url" : "youtu.be\/NKtWXkql0DQ"
      } ]
    },
    "geo" : { },
    "id_str" : "483590183783518208",
    "text" : "We're so excited to explore Buffalo on two wheels. Come along for the ride (via helmet cam!) http:\/\/t.co\/N1n8APJqPA @BuffaloNiagara",
    "id" : 483590183783518208,
    "created_at" : "2014-06-30 12:37:39 +0000",
    "user" : {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "protected" : false,
      "id_str" : "21421691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526582938386055168\/mjgZV9io_normal.jpeg",
      "id" : 21421691,
      "verified" : false
    }
  },
  "id" : 483719303426875392,
  "created_at" : "2014-06-30 21:10:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483714655609573376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3723937458, -71.1221544363 ]
  },
  "id_str" : "483718762768502784",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo ouch dude, sorry to hear! Taping tomorrow?",
  "id" : 483718762768502784,
  "in_reply_to_status_id" : 483714655609573376,
  "created_at" : "2014-06-30 21:08:34 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 39, 49 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483698808262365184",
  "text" : "RT @noahhlo: For comparison, statsd at @37signals over time:\n\nMay 2012- 600 million measurements\/day\nJune 2014- 9 billion measurements\/day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 26, 36 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483698393407954945",
    "text" : "For comparison, statsd at @37signals over time:\n\nMay 2012- 600 million measurements\/day\nJune 2014- 9 billion measurements\/day",
    "id" : 483698393407954945,
    "created_at" : "2014-06-30 19:47:38 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 483698808262365184,
  "created_at" : "2014-06-30 19:49:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 3, 11 ],
      "id_str" : "234465384",
      "id" : 234465384
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 72, 82 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483693450437468160",
  "text" : "RT @noahhlo: 3 years ago this week we started using a variant of statsd @37signals. Yesterday we processed 9.115 billion measurements.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 59, 69 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483691806924619776",
    "text" : "3 years ago this week we started using a variant of statsd @37signals. Yesterday we processed 9.115 billion measurements.",
    "id" : 483691806924619776,
    "created_at" : "2014-06-30 19:21:27 +0000",
    "user" : {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "protected" : false,
      "id_str" : "234465384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412045673408651264\/CPEGZ-93_normal.jpeg",
      "id" : 234465384,
      "verified" : false
    }
  },
  "id" : 483693450437468160,
  "created_at" : "2014-06-30 19:27:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "foo bar boaz",
      "screen_name" : "BoazSender",
      "indices" : [ 0, 11 ],
      "id_str" : "15347596",
      "id" : 15347596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483674547057876992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.35381316, -71.0637862426 ]
  },
  "id_str" : "483680414784315392",
  "in_reply_to_user_id" : 15347596,
  "text" : "@BoazSender cool. I might steal this idea for Buffalo\u2019s meetups.",
  "id" : 483680414784315392,
  "in_reply_to_status_id" : 483674547057876992,
  "created_at" : "2014-06-30 18:36:11 +0000",
  "in_reply_to_screen_name" : "BoazSender",
  "in_reply_to_user_id_str" : "15347596",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thinking Cup",
      "screen_name" : "thinkingcup",
      "indices" : [ 15, 27 ],
      "id_str" : "158125076",
      "id" : 158125076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ZzUh59289v",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b1adee498e982a052daf63?s=aFvYyub8BTRN5iSPLrC-mL-vUiM&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3539534386, -71.0638082027 ]
  },
  "id_str" : "483680243606355968",
  "text" : "Stumptown. (at @ThinkingCup w\/ 3 others) https:\/\/t.co\/ZzUh59289v",
  "id" : 483680243606355968,
  "created_at" : "2014-06-30 18:35:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/483671242533134336\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/uzLu3noh4M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZYZRUCQAA_F_G.jpg",
      "id_str" : "483671201156317184",
      "id" : 483671201156317184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZYZRUCQAA_F_G.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/uzLu3noh4M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3575704918, -71.0578937643 ]
  },
  "id_str" : "483671242533134336",
  "text" : "Well that\u2019s a first. http:\/\/t.co\/uzLu3noh4M",
  "id" : 483671242533134336,
  "created_at" : "2014-06-30 17:59:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "foo bar boaz",
      "screen_name" : "BoazSender",
      "indices" : [ 13, 24 ],
      "id_str" : "15347596",
      "id" : 15347596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483668991496695809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3579896254, -71.05812932 ]
  },
  "id_str" : "483669401271406593",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @BoazSender ah dang, a little too late for this. Sounds awesome.",
  "id" : 483669401271406593,
  "in_reply_to_status_id" : 483668991496695809,
  "created_at" : "2014-06-30 17:52:26 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/483656728097996802\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/CNo136UPBI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZLOvxCAAAC5GL.png",
      "id_str" : "483656726701277184",
      "id" : 483656726701277184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZLOvxCAAAC5GL.png",
      "sizes" : [ {
        "h" : 824,
        "resize" : "fit",
        "w" : 1131
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CNo136UPBI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483657063273218048",
  "text" : "RT @kevinpurdy: Buffalo-area folks now have a second reason to truly dislike Hobby Lobby. http:\/\/t.co\/CNo136UPBI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kevinpurdy\/status\/483656728097996802\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/CNo136UPBI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZLOvxCAAAC5GL.png",
        "id_str" : "483656726701277184",
        "id" : 483656726701277184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZLOvxCAAAC5GL.png",
        "sizes" : [ {
          "h" : 824,
          "resize" : "fit",
          "w" : 1131
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CNo136UPBI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483656728097996802",
    "text" : "Buffalo-area folks now have a second reason to truly dislike Hobby Lobby. http:\/\/t.co\/CNo136UPBI",
    "id" : 483656728097996802,
    "created_at" : "2014-06-30 17:02:04 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 483657063273218048,
  "created_at" : "2014-06-30 17:03:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 5, 11 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 63, 74 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 75, 86 ],
      "id_str" : "76750013",
      "id" : 76750013
    }, {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 87, 94 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/483642562347941890\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KQvXbFpiVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrY-V6rCcAEGeNT.jpg",
      "id_str" : "483642556236853249",
      "id" : 483642556236853249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrY-V6rCcAEGeNT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KQvXbFpiVV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3592834586, -71.0500564629 ]
  },
  "id_str" : "483642562347941890",
  "text" : "ZOMG @phish tomorrow. Too excited so I saw some real ones. \/cc @phillapier @ashstarr88 @mkdevo http:\/\/t.co\/KQvXbFpiVV",
  "id" : 483642562347941890,
  "created_at" : "2014-06-30 16:05:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.359388664, -71.0501154541 ]
  },
  "id_str" : "483635502222815232",
  "text" : "Why does every aquarium insist on forced photo opportunities?",
  "id" : 483635502222815232,
  "created_at" : "2014-06-30 15:37:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483414824605323264",
  "text" : "RT @IAM_SHAKESPEARE: Puppies!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483414623610503168",
    "text" : "Puppies!",
    "id" : 483414623610503168,
    "created_at" : "2014-06-30 01:00:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 483414824605323264,
  "created_at" : "2014-06-30 01:00:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3725183382, -71.1216481811 ]
  },
  "id_str" : "483408155661967361",
  "text" : "It wouldn\u2019t be Boston without a trip to a small, overheated falafel joint.",
  "id" : 483408155661967361,
  "created_at" : "2014-06-30 00:34:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 0, 7 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483401135878053888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3723712113, -71.122353902 ]
  },
  "id_str" : "483402036868677633",
  "in_reply_to_user_id" : 6981492,
  "text" : "@ftrain assuming binary, so 32 tweets\/storm?",
  "id" : 483402036868677633,
  "in_reply_to_status_id" : 483401135878053888,
  "created_at" : "2014-06-30 00:10:01 +0000",
  "in_reply_to_screen_name" : "ftrain",
  "in_reply_to_user_id_str" : "6981492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483366807756349440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3658178235, -71.1058103387 ]
  },
  "id_str" : "483383404193275904",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel Definitely crawling. Will consider.",
  "id" : 483383404193275904,
  "in_reply_to_status_id" : 483366807756349440,
  "created_at" : "2014-06-29 22:55:59 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483332485791903744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3722641788, -71.1206261009 ]
  },
  "id_str" : "483332907444883457",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu maaaaybe\u2026.",
  "id" : 483332907444883457,
  "in_reply_to_status_id" : 483332485791903744,
  "created_at" : "2014-06-29 19:35:19 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483332434633969664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3722355481, -71.1206772756 ]
  },
  "id_str" : "483332875337490432",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel oooh yes! Might have to wait until next visit and the little dude is a little older though.",
  "id" : 483332875337490432,
  "in_reply_to_status_id" : 483332434633969664,
  "created_at" : "2014-06-29 19:35:12 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 0, 11 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483331055320326144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3722030724, -71.1206383205 ]
  },
  "id_str" : "483331294021963776",
  "in_reply_to_user_id" : 10774712,
  "text" : "@richdownie I wish.",
  "id" : 483331294021963776,
  "in_reply_to_status_id" : 483331055320326144,
  "created_at" : "2014-06-29 19:28:55 +0000",
  "in_reply_to_screen_name" : "richdownie",
  "in_reply_to_user_id_str" : "10774712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3722665975, -71.1206090413 ]
  },
  "id_str" : "483331239231754240",
  "text" : "Any suggestions for geeky\/nerd stuff to do in Boston besides comic book\/board game shops? Yes this is real life.",
  "id" : 483331239231754240,
  "created_at" : "2014-06-29 19:28:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/PAcCidThHF",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53b06817498ee65f271ce3db?s=OiV7iK5WKuZBBjrwpqJrDvNRvcs&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3722412981, -71.1208499962 ]
  },
  "id_str" : "483330510815768576",
  "text" : "BURGERS!!! (@ Shake Shack w\/ 8 others) https:\/\/t.co\/PAcCidThHF",
  "id" : 483330510815768576,
  "created_at" : "2014-06-29 19:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483313818521833472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3724684865, -71.1219441612 ]
  },
  "id_str" : "483314419816886273",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella all week.",
  "id" : 483314419816886273,
  "in_reply_to_status_id" : 483313818521833472,
  "created_at" : "2014-06-29 18:21:51 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3717793814, -71.1222726153 ]
  },
  "id_str" : "483311338618228736",
  "text" : "Hello Boston! I don\u2019t miss your roads. Or drivers.",
  "id" : 483311338618228736,
  "created_at" : "2014-06-29 18:09:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "indices" : [ 3, 11 ],
      "id_str" : "20079975",
      "id" : 20079975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZlhyTEMPKx",
      "expanded_url" : "http:\/\/madisonpl.us\/ruby\/",
      "display_url" : "madisonpl.us\/ruby\/"
    } ]
  },
  "geo" : { },
  "id_str" : "482973976616906753",
  "text" : "RT @polotek: The speaker list for Madison+Ruby is what diversity looks like. It's the bar we should all be setting. http:\/\/t.co\/ZlhyTEMPKx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ZlhyTEMPKx",
        "expanded_url" : "http:\/\/madisonpl.us\/ruby\/",
        "display_url" : "madisonpl.us\/ruby\/"
      } ]
    },
    "geo" : { },
    "id_str" : "482646084796174336",
    "text" : "The speaker list for Madison+Ruby is what diversity looks like. It's the bar we should all be setting. http:\/\/t.co\/ZlhyTEMPKx",
    "id" : 482646084796174336,
    "created_at" : "2014-06-27 22:06:08 +0000",
    "user" : {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "protected" : false,
      "id_str" : "20079975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3603780451\/4775e8c65a9f6f70c824a5b689e6295c_normal.jpeg",
      "id" : 20079975,
      "verified" : false
    }
  },
  "id" : 482973976616906753,
  "created_at" : "2014-06-28 19:49:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M Magnuson",
      "screen_name" : "m_magnuson",
      "indices" : [ 0, 11 ],
      "id_str" : "355041948",
      "id" : 355041948
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 34, 49 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482943576960401408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244092879, -78.8791069338 ]
  },
  "id_str" : "482945566775586816",
  "in_reply_to_user_id" : 355041948,
  "text" : "@m_magnuson much prefer Aroma. Or @PublicEspresso if possible :)",
  "id" : 482945566775586816,
  "in_reply_to_status_id" : 482943576960401408,
  "created_at" : "2014-06-28 17:56:10 +0000",
  "in_reply_to_screen_name" : "m_magnuson",
  "in_reply_to_user_id_str" : "355041948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9232260549, -78.8771456994 ]
  },
  "id_str" : "482942138548633601",
  "text" : "Currently sitting between a peace protest and a group of shouting soccer fans. Easily the most Elmwood thing I\u2019ve done all year.",
  "id" : 482942138548633601,
  "created_at" : "2014-06-28 17:42:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 10, 20 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482897619552063488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240462203, -78.8791765577 ]
  },
  "id_str" : "482918354064142336",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @asianmack All Battles",
  "id" : 482918354064142336,
  "in_reply_to_status_id" : 482897619552063488,
  "created_at" : "2014-06-28 16:08:02 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dillon",
      "screen_name" : "squarism",
      "indices" : [ 0, 9 ],
      "id_str" : "4112941",
      "id" : 4112941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/TssTsu0zFQ",
      "expanded_url" : "https:\/\/ifttt.com\/p\/qrush",
      "display_url" : "ifttt.com\/p\/qrush"
    } ]
  },
  "in_reply_to_status_id_str" : "482624829083090944",
  "geo" : { },
  "id_str" : "482625265365823488",
  "in_reply_to_user_id" : 4112941,
  "text" : "@squarism haha. really it's due to not culling the herd from https:\/\/t.co\/TssTsu0zFQ",
  "id" : 482625265365823488,
  "in_reply_to_status_id" : 482624829083090944,
  "created_at" : "2014-06-27 20:43:24 +0000",
  "in_reply_to_screen_name" : "squarism",
  "in_reply_to_user_id_str" : "4112941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aanand Prasad",
      "screen_name" : "aanand",
      "indices" : [ 0, 7 ],
      "id_str" : "14149919",
      "id" : 14149919
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/482624287153463296\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/SxJirDgSa4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrKgOvCCIAArP4o.png",
      "id_str" : "482624285085671424",
      "id" : 482624285085671424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrKgOvCCIAArP4o.png",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 766
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 766
      } ],
      "display_url" : "pic.twitter.com\/SxJirDgSa4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482623795577237504",
  "geo" : { },
  "id_str" : "482624287153463296",
  "in_reply_to_user_id" : 14149919,
  "text" : "@aanand this is my curse http:\/\/t.co\/SxJirDgSa4",
  "id" : 482624287153463296,
  "in_reply_to_status_id" : 482623795577237504,
  "created_at" : "2014-06-27 20:39:31 +0000",
  "in_reply_to_screen_name" : "aanand",
  "in_reply_to_user_id_str" : "14149919",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/482623391216570369\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/7j87RDNY5p",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BrKfaVVCEAAeYO4.png",
      "id_str" : "482623384832839680",
      "id" : 482623384832839680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BrKfaVVCEAAeYO4.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 260
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 260
      } ],
      "display_url" : "pic.twitter.com\/7j87RDNY5p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482623391216570369",
  "text" : "I've had a GMail account for 10 years. http:\/\/t.co\/7j87RDNY5p",
  "id" : 482623391216570369,
  "created_at" : "2014-06-27 20:35:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "indices" : [ 3, 8 ],
      "id_str" : "1385921",
      "id" : 1385921
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 55, 70 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Level Up Conference",
      "screen_name" : "LevelUpCon",
      "indices" : [ 100, 111 ],
      "id_str" : "2190788389",
      "id" : 2190788389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482620238953861120",
  "text" : "RT @d00n: Wow first week of Oct gonna be busy.   first @nickelcityruby  then a couple day break and @LevelUpCon .  Upstate and Western NY R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 45, 60 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Level Up Conference",
        "screen_name" : "LevelUpCon",
        "indices" : [ 90, 101 ],
        "id_str" : "2190788389",
        "id" : 2190788389
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482536304044146688",
    "text" : "Wow first week of Oct gonna be busy.   first @nickelcityruby  then a couple day break and @LevelUpCon .  Upstate and Western NY Represent!",
    "id" : 482536304044146688,
    "created_at" : "2014-06-27 14:49:54 +0000",
    "user" : {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "protected" : false,
      "id_str" : "1385921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430783022372118528\/K9pIL3o8_normal.jpeg",
      "id" : 1385921,
      "verified" : false
    }
  },
  "id" : 482620238953861120,
  "created_at" : "2014-06-27 20:23:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243561751, -78.8792104086 ]
  },
  "id_str" : "482602420191510528",
  "text" : "@juliepagano Select All &gt; Mark As Read. Fixed.",
  "id" : 482602420191510528,
  "created_at" : "2014-06-27 19:12:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482539712356179968",
  "text" : "This bed in the doctor exam room is for me to take a nap on right?",
  "id" : 482539712356179968,
  "created_at" : "2014-06-27 15:03:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/DxMF7mLUUv",
      "expanded_url" : "http:\/\/www.vocativ.com\/culture\/society\/dicks-pick-trucks-meme-rollin-coal\/",
      "display_url" : "vocativ.com\/culture\/societ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9807288995, -78.8790955149 ]
  },
  "id_str" : "482538858555260928",
  "text" : "In case you haven\u2019t lost all hope in humanity yet, ROLLIN COAL will help: http:\/\/t.co\/DxMF7mLUUv",
  "id" : 482538858555260928,
  "created_at" : "2014-06-27 15:00:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 101, 116 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/M6XhNXrq0N",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
      "display_url" : "nickelcityruby.com\/#speak"
    } ]
  },
  "geo" : { },
  "id_str" : "482537560246190080",
  "text" : "RT @aspleenic: And for those of you waiting til the last minute for CFP's - it's the last minute for @nickelcityruby - http:\/\/t.co\/M6XhNXrq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 86, 101 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/M6XhNXrq0N",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
        "display_url" : "nickelcityruby.com\/#speak"
      } ]
    },
    "geo" : { },
    "id_str" : "482533934878969856",
    "text" : "And for those of you waiting til the last minute for CFP's - it's the last minute for @nickelcityruby - http:\/\/t.co\/M6XhNXrq0N",
    "id" : 482533934878969856,
    "created_at" : "2014-06-27 14:40:29 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 482537560246190080,
  "created_at" : "2014-06-27 14:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/482364664043429889\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3pSVVjUwwl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrG0GoWCAAEJMHD.jpg",
      "id_str" : "482364661107392513",
      "id" : 482364661107392513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrG0GoWCAAEJMHD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/3pSVVjUwwl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482361855017353216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924118211, -78.8793201278 ]
  },
  "id_str" : "482364664043429889",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt haha. We have a white husky too. Lots of collie friends that he likes to chase. Also agree on derpness. http:\/\/t.co\/3pSVVjUwwl",
  "id" : 482364664043429889,
  "in_reply_to_status_id" : 482361855017353216,
  "created_at" : "2014-06-27 03:27:52 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipolar Fleece",
      "screen_name" : "porkbelt",
      "indices" : [ 0, 9 ],
      "id_str" : "614019653",
      "id" : 614019653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482360518271725571",
  "geo" : { },
  "id_str" : "482361567388778497",
  "in_reply_to_user_id" : 614019653,
  "text" : "@porkbelt is that a white husky?",
  "id" : 482361567388778497,
  "in_reply_to_status_id" : 482360518271725571,
  "created_at" : "2014-06-27 03:15:34 +0000",
  "in_reply_to_screen_name" : "porkbelt",
  "in_reply_to_user_id_str" : "614019653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482327349208182784",
  "geo" : { },
  "id_str" : "482327566854795264",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave Worth it on WiiU?",
  "id" : 482327566854795264,
  "in_reply_to_status_id" : 482327349208182784,
  "created_at" : "2014-06-27 01:00:27 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/482327173638791168\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/9yCJwCs8zY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrGSAdvCUAABVnt.jpg",
      "id_str" : "482327171784921088",
      "id" : 482327171784921088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrGSAdvCUAABVnt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/9yCJwCs8zY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482327173638791168",
  "text" : "Who else should we ask to submit to @nickelcityruby? I will find you. And I will ask you to submit a talk. http:\/\/t.co\/9yCJwCs8zY",
  "id" : 482327173638791168,
  "created_at" : "2014-06-27 00:58:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482325682094370816",
  "geo" : { },
  "id_str" : "482326118024740864",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo Ah that's it.",
  "id" : 482326118024740864,
  "in_reply_to_status_id" : 482325682094370816,
  "created_at" : "2014-06-27 00:54:42 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482325092584529920",
  "geo" : { },
  "id_str" : "482325299502125058",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits dang! We barely get a dozen, but we bought the cheapest one. Only really care about the big broadcast networks.",
  "id" : 482325299502125058,
  "in_reply_to_status_id" : 482325092584529920,
  "created_at" : "2014-06-27 00:51:27 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482324105740292097",
  "text" : "OK cool, DMs just don't work through the twitter website. Does anyone there actually use this thing?",
  "id" : 482324105740292097,
  "created_at" : "2014-06-27 00:46:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCR14",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/tH9FGL0dMu",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482322511279837184",
  "text" : "RT @nickelcityruby: #NCR14 CFP is only open for one more week! Submit today!! http:\/\/t.co\/tH9FGL0dMu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCR14",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/tH9FGL0dMu",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "482322326105501698",
    "text" : "#NCR14 CFP is only open for one more week! Submit today!! http:\/\/t.co\/tH9FGL0dMu",
    "id" : 482322326105501698,
    "created_at" : "2014-06-27 00:39:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 482322511279837184,
  "created_at" : "2014-06-27 00:40:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Aronoff",
      "screen_name" : "jaronoff",
      "indices" : [ 0, 9 ],
      "id_str" : "12881",
      "id" : 12881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482253526157254656",
  "geo" : { },
  "id_str" : "482253766616293376",
  "in_reply_to_user_id" : 12881,
  "text" : "@jaronoff ah congrats! SPAC's on webcast at least.",
  "id" : 482253766616293376,
  "in_reply_to_status_id" : 482253526157254656,
  "created_at" : "2014-06-26 20:07:12 +0000",
  "in_reply_to_screen_name" : "jaronoff",
  "in_reply_to_user_id_str" : "12881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/eUMCBNDTq1",
      "expanded_url" : "http:\/\/coinmarketcap.com\/",
      "display_url" : "coinmarketcap.com"
    } ]
  },
  "in_reply_to_status_id_str" : "482253266965647360",
  "geo" : { },
  "id_str" : "482253497174220802",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky have you been to http:\/\/t.co\/eUMCBNDTq1 lately?",
  "id" : 482253497174220802,
  "in_reply_to_status_id" : 482253266965647360,
  "created_at" : "2014-06-26 20:06:08 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 48, 59 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482253369759629312",
  "text" : "Warning: GIS for \"tenderlove\" is very NSFW. \/cc @tenderlove",
  "id" : 482253369759629312,
  "created_at" : "2014-06-26 20:05:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Aronoff",
      "screen_name" : "jaronoff",
      "indices" : [ 0, 9 ],
      "id_str" : "12881",
      "id" : 12881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482253078247505920",
  "geo" : { },
  "id_str" : "482253233302171648",
  "in_reply_to_user_id" : 12881,
  "text" : "@jaronoff yeah, been playing nonstop on drives lately. going to any shows?",
  "id" : 482253233302171648,
  "in_reply_to_status_id" : 482253078247505920,
  "created_at" : "2014-06-26 20:05:05 +0000",
  "in_reply_to_screen_name" : "jaronoff",
  "in_reply_to_user_id_str" : "12881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Aronoff",
      "screen_name" : "jaronoff",
      "indices" : [ 0, 9 ],
      "id_str" : "12881",
      "id" : 12881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482251984406581249",
  "geo" : { },
  "id_str" : "482252407737286657",
  "in_reply_to_user_id" : 12881,
  "text" : "@jaronoff Doubtful ;) Thanks man!",
  "id" : 482252407737286657,
  "in_reply_to_status_id" : 482251984406581249,
  "created_at" : "2014-06-26 20:01:48 +0000",
  "in_reply_to_screen_name" : "jaronoff",
  "in_reply_to_user_id_str" : "12881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/FhWQI8QZEc",
      "expanded_url" : "http:\/\/www.potcoin.com",
      "display_url" : "potcoin.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482252340754259969",
  "text" : "Today in \"what in the actual fuck\" http:\/\/t.co\/FhWQI8QZEc",
  "id" : 482252340754259969,
  "created_at" : "2014-06-26 20:01:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 3, 15 ],
      "id_str" : "261031908",
      "id" : 261031908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNY",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "WNY",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "Buffalo",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/GoeSUiQGx5",
      "expanded_url" : "http:\/\/buffalorising.com\/2014\/06\/look-out-below-avant-glass-hits-parked-car\/",
      "display_url" : "buffalorising.com\/2014\/06\/look-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482230367340883968",
  "text" : "RT @HeyRaChaCha: #WNY buildings, tired of being hit by #WNY vehicles, have begun to strike back: http:\/\/t.co\/GoeSUiQGx5 #Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNY",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "WNY",
        "indices" : [ 38, 42 ]
      }, {
        "text" : "Buffalo",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/GoeSUiQGx5",
        "expanded_url" : "http:\/\/buffalorising.com\/2014\/06\/look-out-below-avant-glass-hits-parked-car\/",
        "display_url" : "buffalorising.com\/2014\/06\/look-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482228607969136642",
    "text" : "#WNY buildings, tired of being hit by #WNY vehicles, have begun to strike back: http:\/\/t.co\/GoeSUiQGx5 #Buffalo",
    "id" : 482228607969136642,
    "created_at" : "2014-06-26 18:27:14 +0000",
    "user" : {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "protected" : false,
      "id_str" : "261031908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1262350601\/userpic-5725-100x100_normal.png",
      "id" : 261031908,
      "verified" : false
    }
  },
  "id" : 482230367340883968,
  "created_at" : "2014-06-26 18:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/NrMBcifcA7",
      "expanded_url" : "http:\/\/brooklyngamelab.com\/",
      "display_url" : "brooklyngamelab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482223457606701056",
  "text" : "Amazing idea: afterschool gaming program. http:\/\/t.co\/NrMBcifcA7",
  "id" : 482223457606701056,
  "created_at" : "2014-06-26 18:06:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 17, 24 ],
      "id_str" : "158371168",
      "id" : 158371168
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 35, 47 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uvRRTMdiAZ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kMB8L-ZIj1Q",
      "display_url" : "youtube.com\/watch?v=kMB8L-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482162595323846656",
  "text" : "The one and only @mkdevo has a new @AqueousBand set up: https:\/\/t.co\/uvRRTMdiAZ",
  "id" : 482162595323846656,
  "created_at" : "2014-06-26 14:04:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GVAvYt1XVl",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=fmF3UNunkLs",
      "display_url" : "m.youtube.com\/watch?v=fmF3UN\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8967652792, -78.8785408461 ]
  },
  "id_str" : "482156313586049025",
  "text" : "Finally got a Luigi death stare video up. Direct upload from the WiiU, edited with YouTube\u2019s online tools. So easy. http:\/\/t.co\/GVAvYt1XVl",
  "id" : 482156313586049025,
  "created_at" : "2014-06-26 13:39:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityLab",
      "screen_name" : "CityLab",
      "indices" : [ 3, 11 ],
      "id_str" : "331803536",
      "id" : 331803536
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CityLab\/status\/481994686681608192\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/fNRf4GJ5Y9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrBjnRVIcAAZqB_.jpg",
      "id_str" : "481994686446727168",
      "id" : 481994686446727168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrBjnRVIcAAZqB_.jpg",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fNRf4GJ5Y9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/x7Hb0AN7ld",
      "expanded_url" : "http:\/\/trib.al\/WwBHfy4",
      "display_url" : "trib.al\/WwBHfy4"
    } ]
  },
  "geo" : { },
  "id_str" : "482138889881010176",
  "text" : "RT @CityLab: The story of Rochester after Kodak's bankruptcy, told in photos http:\/\/t.co\/x7Hb0AN7ld http:\/\/t.co\/fNRf4GJ5Y9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CityLab\/status\/481994686681608192\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/fNRf4GJ5Y9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrBjnRVIcAAZqB_.jpg",
        "id_str" : "481994686446727168",
        "id" : 481994686446727168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrBjnRVIcAAZqB_.jpg",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 609,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 609,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fNRf4GJ5Y9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/x7Hb0AN7ld",
        "expanded_url" : "http:\/\/trib.al\/WwBHfy4",
        "display_url" : "trib.al\/WwBHfy4"
      } ]
    },
    "geo" : { },
    "id_str" : "481994686681608192",
    "text" : "The story of Rochester after Kodak's bankruptcy, told in photos http:\/\/t.co\/x7Hb0AN7ld http:\/\/t.co\/fNRf4GJ5Y9",
    "id" : 481994686681608192,
    "created_at" : "2014-06-26 02:57:42 +0000",
    "user" : {
      "name" : "CityLab",
      "screen_name" : "CityLab",
      "protected" : false,
      "id_str" : "331803536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467065464892301312\/5I7ayekg_normal.png",
      "id" : 331803536,
      "verified" : true
    }
  },
  "id" : 482138889881010176,
  "created_at" : "2014-06-26 12:30:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nVE86dlnS8",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "481998893467439104",
  "text" : "RT @aspleenic: We built this city. We built this city on Rock N Roll!!\n\nNow come here at Ruby rock n roll it! http:\/\/t.co\/nVE86dlnS8 CFP on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/nVE86dlnS8",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "481995081898266624",
    "text" : "We built this city. We built this city on Rock N Roll!!\n\nNow come here at Ruby rock n roll it! http:\/\/t.co\/nVE86dlnS8 CFP one more week",
    "id" : 481995081898266624,
    "created_at" : "2014-06-26 02:59:17 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 481998893467439104,
  "created_at" : "2014-06-26 03:14:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481976842086522880",
  "geo" : { },
  "id_str" : "481977881694699521",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 I can't believe that. Literally turning $10 into $15 and switching payment processors just wasn't worth it!?!",
  "id" : 481977881694699521,
  "in_reply_to_status_id" : 481976842086522880,
  "created_at" : "2014-06-26 01:50:56 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/XDXOO5NdPw",
      "expanded_url" : "http:\/\/www.kisselltalks.com\/pics\/184_8407_2_jfr_r1.jpg",
      "display_url" : "kisselltalks.com\/pics\/184_8407_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481974781051293696",
  "text" : "Current status: http:\/\/t.co\/XDXOO5NdPw",
  "id" : 481974781051293696,
  "created_at" : "2014-06-26 01:38:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481973200276819968",
  "geo" : { },
  "id_str" : "481973381344944128",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo my people will call your people.",
  "id" : 481973381344944128,
  "in_reply_to_status_id" : 481973200276819968,
  "created_at" : "2014-06-26 01:33:03 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb",
      "screen_name" : "foodgoesinmouth",
      "indices" : [ 0, 16 ],
      "id_str" : "15526814",
      "id" : 15526814
    }, {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "indices" : [ 17, 23 ],
      "id_str" : "2367111",
      "id" : 2367111
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 34, 40 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481906414542422016",
  "geo" : { },
  "id_str" : "481973290836058113",
  "in_reply_to_user_id" : 15526814,
  "text" : "@foodgoesinmouth @assaf derp. \/cc @parkr",
  "id" : 481973290836058113,
  "in_reply_to_status_id" : 481906414542422016,
  "created_at" : "2014-06-26 01:32:41 +0000",
  "in_reply_to_screen_name" : "foodgoesinmouth",
  "in_reply_to_user_id_str" : "15526814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481972309558042624",
  "geo" : { },
  "id_str" : "481972606849937408",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo when are you taking orders?",
  "id" : 481972606849937408,
  "in_reply_to_status_id" : 481972309558042624,
  "created_at" : "2014-06-26 01:29:58 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/EsxWjrCeGF",
      "expanded_url" : "http:\/\/buffalorising.com\/2014\/06\/handlebar-pub-readies-to-open\/",
      "display_url" : "buffalorising.com\/2014\/06\/handle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481970209079570432",
  "text" : "Barstools at this new bike themed pub in Buffalo look awesome. http:\/\/t.co\/EsxWjrCeGF",
  "id" : 481970209079570432,
  "created_at" : "2014-06-26 01:20:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 6, 12 ],
      "id_str" : "920539489",
      "id" : 920539489
    }, {
      "name" : "Garrett LeSage",
      "screen_name" : "garrett",
      "indices" : [ 13, 21 ],
      "id_str" : "335523",
      "id" : 335523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481915005391343617",
  "geo" : { },
  "id_str" : "481969786121748481",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo @_zzak @garrett you all need new writers",
  "id" : 481969786121748481,
  "in_reply_to_status_id" : 481915005391343617,
  "created_at" : "2014-06-26 01:18:46 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Grace",
      "screen_name" : "jewelia",
      "indices" : [ 3, 11 ],
      "id_str" : "9768582",
      "id" : 9768582
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 139, 140 ],
      "id_str" : "57203",
      "id" : 57203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481961229775159297",
  "text" : "RT @jewelia: \"Know why you have so many users in Beverly Hills\/Schenectady?\n\n90210\/12345 are great when you don't have\/want to enter zip\"\n\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Marks",
        "screen_name" : "kevinmarks",
        "indices" : [ 128, 139 ],
        "id_str" : "57203",
        "id" : 57203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481960381112270849",
    "text" : "\"Know why you have so many users in Beverly Hills\/Schenectady?\n\n90210\/12345 are great when you don't have\/want to enter zip\"\n\n- @kevinmarks",
    "id" : 481960381112270849,
    "created_at" : "2014-06-26 00:41:23 +0000",
    "user" : {
      "name" : "Julia Grace",
      "screen_name" : "jewelia",
      "protected" : false,
      "id_str" : "9768582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000852710320\/8cd6a309ae1f9df8965a8a7174167afa_normal.jpeg",
      "id" : 9768582,
      "verified" : false
    }
  },
  "id" : 481961229775159297,
  "created_at" : "2014-06-26 00:44:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8uzQTdJLnE",
      "expanded_url" : "http:\/\/onion.com\/1o3ZKvr",
      "display_url" : "onion.com\/1o3ZKvr"
    } ]
  },
  "geo" : { },
  "id_str" : "481959785311387648",
  "text" : "RT @TheOnion: Humanity Surprised It Still Hasn't Figured Out Better Alternative To Letting Power-Hungry Assholes Decide Everything http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8uzQTdJLnE",
        "expanded_url" : "http:\/\/onion.com\/1o3ZKvr",
        "display_url" : "onion.com\/1o3ZKvr"
      } ]
    },
    "geo" : { },
    "id_str" : "481946213777170432",
    "text" : "Humanity Surprised It Still Hasn't Figured Out Better Alternative To Letting Power-Hungry Assholes Decide Everything http:\/\/t.co\/8uzQTdJLnE",
    "id" : 481946213777170432,
    "created_at" : "2014-06-25 23:45:06 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3654358881\/476bd54bd9c2bc0f9a38b4e097ce6af5_normal.jpeg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 481959785311387648,
  "created_at" : "2014-06-26 00:39:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Klein",
      "screen_name" : "NaomiAKlein",
      "indices" : [ 3, 15 ],
      "id_str" : "189376144",
      "id" : 189376144
    }, {
      "name" : "Martin Lukacs",
      "screen_name" : "Martin_Lukacs",
      "indices" : [ 105, 119 ],
      "id_str" : "347445740",
      "id" : 347445740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qHR5OLaaqO",
      "expanded_url" : "http:\/\/gu.com\/p\/3qdp7\/tw",
      "display_url" : "gu.com\/p\/3qdp7\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "481958030381051905",
  "text" : "RT @NaomiAKlein: Devastating report on Detroit's wave of water shut offs and shock politics by the great @Martin_Lukacs http:\/\/t.co\/qHR5OLa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Lukacs",
        "screen_name" : "Martin_Lukacs",
        "indices" : [ 88, 102 ],
        "id_str" : "347445740",
        "id" : 347445740
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/qHR5OLaaqO",
        "expanded_url" : "http:\/\/gu.com\/p\/3qdp7\/tw",
        "display_url" : "gu.com\/p\/3qdp7\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "481955798072184832",
    "text" : "Devastating report on Detroit's wave of water shut offs and shock politics by the great @Martin_Lukacs http:\/\/t.co\/qHR5OLaaqO",
    "id" : 481955798072184832,
    "created_at" : "2014-06-26 00:23:11 +0000",
    "user" : {
      "name" : "Naomi Klein",
      "screen_name" : "NaomiAKlein",
      "protected" : false,
      "id_str" : "189376144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1121888858\/NaomiAKlein_normal.jpg",
      "id" : 189376144,
      "verified" : true
    }
  },
  "id" : 481958030381051905,
  "created_at" : "2014-06-26 00:32:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 10, 19 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/FTg4zjCoKD",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "481913877173919744",
  "geo" : { },
  "id_str" : "481914051660767232",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby @mittense lol http:\/\/t.co\/FTg4zjCoKD",
  "id" : 481914051660767232,
  "in_reply_to_status_id" : 481913877173919744,
  "created_at" : "2014-06-25 21:37:18 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 10, 19 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481913128838381568",
  "geo" : { },
  "id_str" : "481913481168318464",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense @tinybaby FWIW I am pretty excited about this game. But just saying \"space shooter\" is enough to make me buy it :)",
  "id" : 481913481168318464,
  "in_reply_to_status_id" : 481913128838381568,
  "created_at" : "2014-06-25 21:35:02 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 10, 19 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481913128838381568",
  "geo" : { },
  "id_str" : "481913334837440512",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense @tinybaby have you played nethack or rogue? or any *actual* roguelike? how is a space shooter anything like that!?",
  "id" : 481913334837440512,
  "in_reply_to_status_id" : 481913128838381568,
  "created_at" : "2014-06-25 21:34:27 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 23, 32 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/Ho0tpvpKF4",
      "expanded_url" : "https:\/\/twitter.com\/tinybaby\/status\/481832951739858944",
      "display_url" : "twitter.com\/tinybaby\/statu\u2026"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/H2Vu0QuQbS",
      "expanded_url" : "https:\/\/twitter.com\/tinybaby\/status\/481833526908968960",
      "display_url" : "twitter.com\/tinybaby\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "481912722053816320",
  "geo" : { },
  "id_str" : "481912948512669696",
  "in_reply_to_user_id" : 5743852,
  "text" : "@mittense context from @tinybaby: https:\/\/t.co\/Ho0tpvpKF4 https:\/\/t.co\/H2Vu0QuQbS",
  "id" : 481912948512669696,
  "in_reply_to_status_id" : 481912722053816320,
  "created_at" : "2014-06-25 21:32:55 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 113, 122 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481911863832096768",
  "geo" : { },
  "id_str" : "481912722053816320",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense agh a \"roguelike\"!? this is not a roguelike. Not at all. Furthest thing from it. Why call it that? \/cc @tinybaby",
  "id" : 481912722053816320,
  "in_reply_to_status_id" : 481911863832096768,
  "created_at" : "2014-06-25 21:32:01 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481912251243167744",
  "text" : "A penny for every time I try not to correct \"Co-working\" as \"Coworking\"",
  "id" : 481912251243167744,
  "created_at" : "2014-06-25 21:30:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Ayres",
      "screen_name" : "ayresphoto",
      "indices" : [ 0, 11 ],
      "id_str" : "83498704",
      "id" : 83498704
    }, {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 12, 24 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481891924974899200",
  "geo" : { },
  "id_str" : "481892355671216128",
  "in_reply_to_user_id" : 83498704,
  "text" : "@ayresphoto @mikemikemac is that you?!",
  "id" : 481892355671216128,
  "in_reply_to_status_id" : 481891924974899200,
  "created_at" : "2014-06-25 20:11:05 +0000",
  "in_reply_to_screen_name" : "ayresphoto",
  "in_reply_to_user_id_str" : "83498704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481885897747480576",
  "geo" : { },
  "id_str" : "481886271011176449",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror As Seen On PC!",
  "id" : 481886271011176449,
  "in_reply_to_status_id" : 481885897747480576,
  "created_at" : "2014-06-25 19:46:54 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "indices" : [ 3, 10 ],
      "id_str" : "107837944",
      "id" : 107837944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481863116653752320",
  "text" : "RT @_tessr: Turn all your data over to Google, and in return you can order a pizza from your wrist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "481862381924933633",
    "geo" : { },
    "id_str" : "481862738025537537",
    "in_reply_to_user_id" : 107837944,
    "text" : "Turn all your data over to Google, and in return you can order a pizza from your wrist",
    "id" : 481862738025537537,
    "in_reply_to_status_id" : 481862381924933633,
    "created_at" : "2014-06-25 18:13:23 +0000",
    "in_reply_to_screen_name" : "_tessr",
    "in_reply_to_user_id_str" : "107837944",
    "user" : {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "protected" : false,
      "id_str" : "107837944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551656553330114561\/gco5OyOI_normal.jpeg",
      "id" : 107837944,
      "verified" : false
    }
  },
  "id" : 481863116653752320,
  "created_at" : "2014-06-25 18:14:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Collaborative Fund",
      "screen_name" : "collabfund",
      "indices" : [ 126, 137 ],
      "id_str" : "150016842",
      "id" : 150016842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/hER4At8jNQ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/socialcitizens",
      "display_url" : "reddit.com\/r\/socialcitize\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481862611965718529",
  "text" : "RT @jasonfried: Today at 3pm eastern I'll be doing a Reddit AMA about entrepreneurship over here \u2014&gt; http:\/\/t.co\/hER4At8jNQ @collabfund",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Collaborative Fund",
        "screen_name" : "collabfund",
        "indices" : [ 110, 121 ],
        "id_str" : "150016842",
        "id" : 150016842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/hER4At8jNQ",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/socialcitizens",
        "display_url" : "reddit.com\/r\/socialcitize\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481787098748289026",
    "text" : "Today at 3pm eastern I'll be doing a Reddit AMA about entrepreneurship over here \u2014&gt; http:\/\/t.co\/hER4At8jNQ @collabfund",
    "id" : 481787098748289026,
    "created_at" : "2014-06-25 13:12:50 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 481862611965718529,
  "created_at" : "2014-06-25 18:12:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/23Oro7bUqX",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/B00F2J9T7O\/ref=as_li_ss_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=B00F2J9T7O&linkCode=as2&tag=dtwt2-20",
      "display_url" : "amazon.com\/gp\/product\/B00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481858960522104832",
  "text" : "Oh cmon, no Prime on this? Lame. http:\/\/t.co\/23Oro7bUqX",
  "id" : 481858960522104832,
  "created_at" : "2014-06-25 17:58:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 0, 12 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481856335097511936",
  "geo" : { },
  "id_str" : "481856601951698945",
  "in_reply_to_user_id" : 158098704,
  "text" : "@mikemikemac wasn't trying to imply that. :(",
  "id" : 481856601951698945,
  "in_reply_to_status_id" : 481856335097511936,
  "created_at" : "2014-06-25 17:49:01 +0000",
  "in_reply_to_screen_name" : "mikemikemac",
  "in_reply_to_user_id_str" : "158098704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/qZb1JvcUKN",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/the-watch\/wp\/2014\/06\/25\/scenes-from-militarized-america-brookline-mass-and-the-michigan-state-police\/",
      "display_url" : "washingtonpost.com\/news\/the-watch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481850006551269377",
  "text" : "As a former Brookline resident this is terrifying: http:\/\/t.co\/qZb1JvcUKN",
  "id" : 481850006551269377,
  "created_at" : "2014-06-25 17:22:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 0, 7 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 56, 71 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481847466581426176",
  "geo" : { },
  "id_str" : "481847756017790976",
  "in_reply_to_user_id" : 9526722,
  "text" : "@Bantik I was meaning to bug you, if I didn't already...@nickelcityruby's CFP is open until 7\/3!",
  "id" : 481847756017790976,
  "in_reply_to_status_id" : 481847466581426176,
  "created_at" : "2014-06-25 17:13:51 +0000",
  "in_reply_to_screen_name" : "CoralineAda",
  "in_reply_to_user_id_str" : "9526722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481842242618130432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8913831061, -78.8726710741 ]
  },
  "id_str" : "481843372223504385",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN I need to try this out. Have been searching for a spring drink. Summer is mojitos, fall cider\/rum, winter White Russian.",
  "id" : 481843372223504385,
  "in_reply_to_status_id" : 481842242618130432,
  "created_at" : "2014-06-25 16:56:26 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crecente",
      "screen_name" : "crecenteb",
      "indices" : [ 3, 13 ],
      "id_str" : "14155052",
      "id" : 14155052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481842731761664000",
  "text" : "RT @crecenteb: Protester at Google I\/O held up a sign that said \"Develop a conscience.\" She was walked from the building.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481842309156179970",
    "text" : "Protester at Google I\/O held up a sign that said \"Develop a conscience.\" She was walked from the building.",
    "id" : 481842309156179970,
    "created_at" : "2014-06-25 16:52:13 +0000",
    "user" : {
      "name" : "Crecente",
      "screen_name" : "crecenteb",
      "protected" : false,
      "id_str" : "14155052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555829427519516672\/eQofV6oK_normal.jpeg",
      "id" : 14155052,
      "verified" : true
    }
  },
  "id" : 481842731761664000,
  "created_at" : "2014-06-25 16:53:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481841337767952384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8912856945, -78.8727787829 ]
  },
  "id_str" : "481842197973594113",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety Really?",
  "id" : 481842197973594113,
  "in_reply_to_status_id" : 481841337767952384,
  "created_at" : "2014-06-25 16:51:46 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481842155384623106\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/8jSv4YKgxn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_Y4ofCEAAs9tL.jpg",
      "id_str" : "481842152603783168",
      "id" : 481842152603783168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_Y4ofCEAAs9tL.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/8jSv4YKgxn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8913963943, -78.8726325945 ]
  },
  "id_str" : "481842155384623106",
  "text" : "Cloud city http:\/\/t.co\/8jSv4YKgxn",
  "id" : 481842155384623106,
  "created_at" : "2014-06-25 16:51:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 0, 9 ],
      "id_str" : "2998581",
      "id" : 2998581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/EmUiG90kOd",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "481835376709890048",
  "geo" : { },
  "id_str" : "481836982335569920",
  "in_reply_to_user_id" : 2998581,
  "text" : "@kerrizor I would love to figure this out for http:\/\/t.co\/EmUiG90kOd. It's not easy at all.",
  "id" : 481836982335569920,
  "in_reply_to_status_id" : 481835376709890048,
  "created_at" : "2014-06-25 16:31:03 +0000",
  "in_reply_to_screen_name" : "kerrizor",
  "in_reply_to_user_id_str" : "2998581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kronda",
      "screen_name" : "kronda",
      "indices" : [ 3, 10 ],
      "id_str" : "11134232",
      "id" : 11134232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "osb14",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481834712525049856",
  "text" : "RT @kronda: \u201CIt never occurred to me to volunteer my non-existent free time to open source.\u201D #osb14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "osb14",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481834472493416448",
    "text" : "\u201CIt never occurred to me to volunteer my non-existent free time to open source.\u201D #osb14",
    "id" : 481834472493416448,
    "created_at" : "2014-06-25 16:21:04 +0000",
    "user" : {
      "name" : "Kronda",
      "screen_name" : "kronda",
      "protected" : false,
      "id_str" : "11134232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000378422243\/7df12eaeb40e0318b01be816cfa0c182_normal.jpeg",
      "id" : 11134232,
      "verified" : false
    }
  },
  "id" : 481834712525049856,
  "created_at" : "2014-06-25 16:22:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sreegs",
      "screen_name" : "ahuj9",
      "indices" : [ 0, 6 ],
      "id_str" : "205281746",
      "id" : 205281746
    }, {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 7, 16 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481834272538370048",
  "geo" : { },
  "id_str" : "481834534942416897",
  "in_reply_to_user_id" : 205281746,
  "text" : "@ahuj9 @tinybaby gahhh i hate this definition.",
  "id" : 481834534942416897,
  "in_reply_to_status_id" : 481834272538370048,
  "created_at" : "2014-06-25 16:21:19 +0000",
  "in_reply_to_screen_name" : "ahuj9",
  "in_reply_to_user_id_str" : "205281746",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481833625764499456",
  "geo" : { },
  "id_str" : "481834067038461953",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby I'd add turn-based and top-down\/grid\/isometric as well. It's not a roguelike if you can't just sit to think about your next action",
  "id" : 481834067038461953,
  "in_reply_to_status_id" : 481833625764499456,
  "created_at" : "2014-06-25 16:19:28 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rirug",
      "screen_name" : "rirug",
      "indices" : [ 3, 9 ],
      "id_str" : "18145307",
      "id" : 18145307
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 111, 126 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/rLppS1HuWN",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "481833506968838144",
  "text" : "RT @rirug: Nickel City Ruby is October 3-4, and the call for presentations is open until July 3. Represent RI! @nickelcityruby http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 100, 115 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/rLppS1HuWN",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "481822279060705280",
    "text" : "Nickel City Ruby is October 3-4, and the call for presentations is open until July 3. Represent RI! @nickelcityruby http:\/\/t.co\/rLppS1HuWN",
    "id" : 481822279060705280,
    "created_at" : "2014-06-25 15:32:37 +0000",
    "user" : {
      "name" : "rirug",
      "screen_name" : "rirug",
      "protected" : false,
      "id_str" : "18145307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1269125565\/RIRUG_normal.png",
      "id" : 18145307,
      "verified" : false
    }
  },
  "id" : 481833506968838144,
  "created_at" : "2014-06-25 16:17:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rubits (sponge)",
      "screen_name" : "mikerubits",
      "indices" : [ 0, 11 ],
      "id_str" : "18455656",
      "id" : 18455656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481831499080015874",
  "geo" : { },
  "id_str" : "481831913552760832",
  "in_reply_to_user_id" : 18455656,
  "text" : "@mikerubits Mohu is pretty decent for the rare times you want TV",
  "id" : 481831913552760832,
  "in_reply_to_status_id" : 481831499080015874,
  "created_at" : "2014-06-25 16:10:54 +0000",
  "in_reply_to_screen_name" : "mikerubits",
  "in_reply_to_user_id_str" : "18455656",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Griffin",
      "screen_name" : "betamatt",
      "indices" : [ 0, 9 ],
      "id_str" : "9976112",
      "id" : 9976112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481825255531745281",
  "geo" : { },
  "id_str" : "481825513460080640",
  "in_reply_to_user_id" : 9976112,
  "text" : "@betamatt AWESOME. thanks!!",
  "id" : 481825513460080640,
  "in_reply_to_status_id" : 481825255531745281,
  "created_at" : "2014-06-25 15:45:28 +0000",
  "in_reply_to_screen_name" : "betamatt",
  "in_reply_to_user_id_str" : "9976112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481824365802045440\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/1e4DBvHOul",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_ItMuCYAAvM4c.png",
      "id_str" : "481824363985920000",
      "id" : 481824363985920000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_ItMuCYAAvM4c.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1786
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1e4DBvHOul"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481824365802045440",
  "text" : "Anyone know what API allows Google to list upcoming events in searches? http:\/\/t.co\/1e4DBvHOul",
  "id" : 481824365802045440,
  "created_at" : "2014-06-25 15:40:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481823143665758209",
  "geo" : { },
  "id_str" : "481824186663325697",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv nice! i wonder what a band has to do to get on this widget.",
  "id" : 481824186663325697,
  "in_reply_to_status_id" : 481823143665758209,
  "created_at" : "2014-06-25 15:40:12 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 17, 32 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 43, 50 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 52, 58 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8913749117, -78.8724647903 ]
  },
  "id_str" : "481811356820066304",
  "text" : "More of this for @nickelcityruby please!! \u201C@searls: @qrush  just dropped everything I was doing and submitted to your CFP\u201D",
  "id" : 481811356820066304,
  "created_at" : "2014-06-25 14:49:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 45, 56 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481808775095922688",
  "text" : "Activating the Nest channels on IFTTT. Or as @kevinpurdy puts it, \"fear for my family\"",
  "id" : 481808775095922688,
  "created_at" : "2014-06-25 14:38:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89158192, -78.8715540246 ]
  },
  "id_str" : "481806820470566912",
  "text" : "Or more accurately: shaking their heads at us while ours are buried in the sand.",
  "id" : 481806820470566912,
  "created_at" : "2014-06-25 14:31:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89158192, -78.8715540246 ]
  },
  "id_str" : "481806631835930625",
  "text" : "Here\u2019s the sad thing: people in other industries are laughing at us.",
  "id" : 481806631835930625,
  "created_at" : "2014-06-25 14:30:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89158192, -78.8715540246 ]
  },
  "id_str" : "481806555596062721",
  "text" : "NPR covered the Google diversity numbers and conference line bathroom situation today. It\u2019s impossible to ignore this problem anymore.",
  "id" : 481806555596062721,
  "created_at" : "2014-06-25 14:30:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481805263440457728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916232315, -78.8722428851 ]
  },
  "id_str" : "481806323299151872",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc quite sure we will use those still.",
  "id" : 481806323299151872,
  "in_reply_to_status_id" : 481805263440457728,
  "created_at" : "2014-06-25 14:29:13 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481803636800897026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89158841, -78.872281741 ]
  },
  "id_str" : "481806259143073792",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls thanks! Maybe for @nickelcityruby ?",
  "id" : 481806259143073792,
  "in_reply_to_status_id" : 481803636800897026,
  "created_at" : "2014-06-25 14:28:58 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 15, 29 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481803151318593537\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/fot5H9LZYj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq-1aJZCQAE3LVS.jpg",
      "id_str" : "481803145954082817",
      "id" : 481803145954082817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq-1aJZCQAE3LVS.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/fot5H9LZYj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8916133102, -78.8725111541 ]
  },
  "id_str" : "481803151318593537",
  "text" : "The bike racks @coworkbuffalo have finally arrived. I predict we will need more. http:\/\/t.co\/fot5H9LZYj",
  "id" : 481803151318593537,
  "created_at" : "2014-06-25 14:16:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481669548664700928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9235439411, -78.8800401166 ]
  },
  "id_str" : "481672009705746435",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael the snideness always gets to me. \u201CShould look more urban\u201D what the fuck? It\u2019s dense housing! That\u2019s urban! Just be happy!",
  "id" : 481672009705746435,
  "in_reply_to_status_id" : 481669548664700928,
  "created_at" : "2014-06-25 05:35:30 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481664746568314881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243855039, -78.879030766 ]
  },
  "id_str" : "481667087585124352",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt I think this means human flesh lines the walls, studded with ancient gems",
  "id" : 481667087585124352,
  "in_reply_to_status_id" : 481664746568314881,
  "created_at" : "2014-06-25 05:15:57 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481662752272814080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924012674, -78.8790264112 ]
  },
  "id_str" : "481666352168464384",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone is this a new theme park attraction?",
  "id" : 481666352168464384,
  "in_reply_to_status_id" : 481662752272814080,
  "created_at" : "2014-06-25 05:13:01 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481658841520558081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9238884631, -78.881186117 ]
  },
  "id_str" : "481660454779887616",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo maybe Colbert will!",
  "id" : 481660454779887616,
  "in_reply_to_status_id" : 481658841520558081,
  "created_at" : "2014-06-25 04:49:35 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/UYpg3ZPzMq",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=M65Dx0STe2M&feature=kp",
      "display_url" : "m.youtube.com\/watch?v=M65Dx0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239035381, -78.8792557876 ]
  },
  "id_str" : "481658505959456768",
  "text" : "Nice drums! http:\/\/t.co\/UYpg3ZPzMq",
  "id" : 481658505959456768,
  "created_at" : "2014-06-25 04:41:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9220529519, -78.8797829487 ]
  },
  "id_str" : "481656742816661504",
  "text" : "No Wingsuit or Fuego on Letterman. :(",
  "id" : 481656742816661504,
  "created_at" : "2014-06-25 04:34:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481648212235665409",
  "text" : "We just watched a commerical that said \"vaginal cream\" at least 10 times over 2 minutes. This is TV.",
  "id" : 481648212235665409,
  "created_at" : "2014-06-25 04:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481637996920197120\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/CzBRyyPaUG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq8fNCwCYAAHCvH.jpg",
      "id_str" : "481637994089046016",
      "id" : 481637994089046016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq8fNCwCYAAHCvH.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CzBRyyPaUG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481637536784457728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240976439, -78.8790200773 ]
  },
  "id_str" : "481637996920197120",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc np! the city needs 100s more like him to fix the East Side. Literally is regrowing it. http:\/\/t.co\/CzBRyyPaUG",
  "id" : 481637996920197120,
  "in_reply_to_status_id" : 481637536784457728,
  "created_at" : "2014-06-25 03:20:21 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 65, 74 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481636314073137153",
  "geo" : { },
  "id_str" : "481637283435511808",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc Funny you mention No. 194. It's no longer there. @borncamp is fixing up the adjacent lots and farming in several nearby too.",
  "id" : 481637283435511808,
  "in_reply_to_status_id" : 481636314073137153,
  "created_at" : "2014-06-25 03:17:31 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481628953497833472",
  "geo" : { },
  "id_str" : "481631140046848000",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave neither. goku would spend around 8 episodes screaming, and batman would refuse to kill him.",
  "id" : 481631140046848000,
  "in_reply_to_status_id" : 481628953497833472,
  "created_at" : "2014-06-25 02:53:06 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 0, 10 ],
      "id_str" : "15735952",
      "id" : 15735952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481627957329657856",
  "geo" : { },
  "id_str" : "481629322403270656",
  "in_reply_to_user_id" : 15735952,
  "text" : "@jessabean the real truth though: there's never a \"right time\". 7 months in and wouldn't have it any other way though. :)",
  "id" : 481629322403270656,
  "in_reply_to_status_id" : 481627957329657856,
  "created_at" : "2014-06-25 02:45:53 +0000",
  "in_reply_to_screen_name" : "jessabean",
  "in_reply_to_user_id_str" : "15735952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/157gWx7H8b",
      "expanded_url" : "https:\/\/www.fourmilab.ch\/chez-nuke\/SubMarie\/figures\/Maries.jpg",
      "display_url" : "fourmilab.ch\/chez-nuke\/SubM\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "481620249435840512",
  "geo" : { },
  "id_str" : "481620503010881536",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp take it from a native: it's called a bowl with a huge helping of https:\/\/t.co\/157gWx7H8b",
  "id" : 481620503010881536,
  "in_reply_to_status_id" : 481620249435840512,
  "created_at" : "2014-06-25 02:10:50 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 0, 7 ],
      "id_str" : "39617149",
      "id" : 39617149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481605521443520512",
  "geo" : { },
  "id_str" : "481606104229494784",
  "in_reply_to_user_id" : 39617149,
  "text" : "@cczona totally agree.",
  "id" : 481606104229494784,
  "in_reply_to_status_id" : 481605521443520512,
  "created_at" : "2014-06-25 01:13:37 +0000",
  "in_reply_to_screen_name" : "cczona",
  "in_reply_to_user_id_str" : "39617149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481599493645684738",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243422952, -78.8790404052 ]
  },
  "id_str" : "481603227146670080",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes huh! That\u2019s odd given they usually don\u2019t plan set lists or much at all.",
  "id" : 481603227146670080,
  "in_reply_to_status_id" : 481599493645684738,
  "created_at" : "2014-06-25 01:02:11 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevan MacGee",
      "screen_name" : "kevanmacgee",
      "indices" : [ 0, 12 ],
      "id_str" : "263450469",
      "id" : 263450469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481602446465441793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243422952, -78.8790404052 ]
  },
  "id_str" : "481602790767091713",
  "in_reply_to_user_id" : 263450469,
  "text" : "@kevanmacgee they are doing a replay!!",
  "id" : 481602790767091713,
  "in_reply_to_status_id" : 481602446465441793,
  "created_at" : "2014-06-25 01:00:27 +0000",
  "in_reply_to_screen_name" : "kevanmacgee",
  "in_reply_to_user_id_str" : "263450469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 0, 7 ],
      "id_str" : "39617149",
      "id" : 39617149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481601446593306624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243422952, -78.8790404052 ]
  },
  "id_str" : "481602361882730496",
  "in_reply_to_user_id" : 39617149,
  "text" : "@cczona thanks!",
  "id" : 481602361882730496,
  "in_reply_to_status_id" : 481601446593306624,
  "created_at" : "2014-06-25 00:58:45 +0000",
  "in_reply_to_screen_name" : "cczona",
  "in_reply_to_user_id_str" : "39617149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CallbackWomen",
      "screen_name" : "CallbackWomen",
      "indices" : [ 0, 14 ],
      "id_str" : "1138103090",
      "id" : 1138103090
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 27, 42 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/TOR7QZJNjl",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
      "display_url" : "nickelcityruby.com\/#speak"
    } ]
  },
  "geo" : { },
  "id_str" : "481602341238341632",
  "in_reply_to_user_id" : 1138103090,
  "text" : "@CallbackWomen our CFP for @nickelcityruby closes soon! http:\/\/t.co\/TOR7QZJNjl",
  "id" : 481602341238341632,
  "created_at" : "2014-06-25 00:58:40 +0000",
  "in_reply_to_screen_name" : "CallbackWomen",
  "in_reply_to_user_id_str" : "1138103090",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243139644, -78.8789679856 ]
  },
  "id_str" : "481600606579077120",
  "text" : "Live on Letterman needs to be at least 2 hours longer.",
  "id" : 481600606579077120,
  "created_at" : "2014-06-25 00:51:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Steinberg",
      "screen_name" : "zzyzx",
      "indices" : [ 0, 6 ],
      "id_str" : "6073352",
      "id" : 6073352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481599935104577537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243139644, -78.8789679856 ]
  },
  "id_str" : "481600460554387456",
  "in_reply_to_user_id" : 6073352,
  "text" : "@zzyzx I wish! Was really hoping for it.",
  "id" : 481600460554387456,
  "in_reply_to_status_id" : 481599935104577537,
  "created_at" : "2014-06-25 00:51:12 +0000",
  "in_reply_to_screen_name" : "zzyzx",
  "in_reply_to_user_id_str" : "6073352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carina C. Zona",
      "screen_name" : "cczona",
      "indices" : [ 0, 7 ],
      "id_str" : "39617149",
      "id" : 39617149
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 69, 84 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/TOR7QZJNjl",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speak",
      "display_url" : "nickelcityruby.com\/#speak"
    } ]
  },
  "in_reply_to_status_id_str" : "481596617850494976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243139644, -78.8789679856 ]
  },
  "id_str" : "481600312604499968",
  "in_reply_to_user_id" : 39617149,
  "text" : "@cczona if you\u2019re offering\u2026would love to get the word out more about @nickelcityruby\u2019s CFP! http:\/\/t.co\/TOR7QZJNjl",
  "id" : 481600312604499968,
  "in_reply_to_status_id" : 481596617850494976,
  "created_at" : "2014-06-25 00:50:36 +0000",
  "in_reply_to_screen_name" : "cczona",
  "in_reply_to_user_id_str" : "39617149",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481599349084811264\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Qodhzc08mr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq78DLQCMAAM2tF.png",
      "id_str" : "481599341665071104",
      "id" : 481599341665071104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq78DLQCMAAM2tF.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Qodhzc08mr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243175267, -78.8789808099 ]
  },
  "id_str" : "481599349084811264",
  "text" : "Would love to know what app Page is using on his iPad. Definitely a new addition this year to his rig. http:\/\/t.co\/Qodhzc08mr",
  "id" : 481599349084811264,
  "created_at" : "2014-06-25 00:46:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239498852, -78.8792045914 ]
  },
  "id_str" : "481598014113316866",
  "text" : "BRACE FOR WOOS CAPTAIN",
  "id" : 481598014113316866,
  "created_at" : "2014-06-25 00:41:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Setlist Schematics",
      "screen_name" : "phishmaps",
      "indices" : [ 0, 10 ],
      "id_str" : "1649136702",
      "id" : 1649136702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481592858202624000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243918742, -78.8790689875 ]
  },
  "id_str" : "481594712504037377",
  "in_reply_to_user_id" : 1649136702,
  "text" : "@phishmaps I hope you are live sketching these jams",
  "id" : 481594712504037377,
  "in_reply_to_status_id" : 481592858202624000,
  "created_at" : "2014-06-25 00:28:21 +0000",
  "in_reply_to_screen_name" : "phishmaps",
  "in_reply_to_user_id_str" : "1649136702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StAshDrisc",
      "screen_name" : "ashstarr88",
      "indices" : [ 0, 11 ],
      "id_str" : "76750013",
      "id" : 76750013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481590633690189825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239217834, -78.8794260182 ]
  },
  "id_str" : "481591962424713217",
  "in_reply_to_user_id" : 76750013,
  "text" : "@ashstarr88 haha nope!",
  "id" : 481591962424713217,
  "in_reply_to_status_id" : 481590633690189825,
  "created_at" : "2014-06-25 00:17:26 +0000",
  "in_reply_to_screen_name" : "ashstarr88",
  "in_reply_to_user_id_str" : "76750013",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/lVbgniUS8g",
      "expanded_url" : "http:\/\/www.cbs.com\/shows\/liveonletterman\/artist\/221750\/phish\/",
      "display_url" : "cbs.com\/shows\/liveonle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481589345480998912",
  "text" : "Phish is streaming in HD right now. Get you some! http:\/\/t.co\/lVbgniUS8g",
  "id" : 481589345480998912,
  "created_at" : "2014-06-25 00:07:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/M3Lp0eOKMT",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/53aa01a1498e255b1c10f189?s=S-31ChrWzv54Ir55baBNO0ZiM0o&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239060783, -78.8764715195 ]
  },
  "id_str" : "481571106516926464",
  "text" : "I'm at Bidwell Summer Concert Series (Buffalo, NY) w\/ 3 others https:\/\/t.co\/M3Lp0eOKMT",
  "id" : 481571106516926464,
  "created_at" : "2014-06-24 22:54:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481567607976243202",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239971965, -78.8791389649 ]
  },
  "id_str" : "481567724615630849",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents turnp",
  "id" : 481567724615630849,
  "in_reply_to_status_id" : 481567607976243202,
  "created_at" : "2014-06-24 22:41:07 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "indices" : [ 3, 18 ],
      "id_str" : "870817116",
      "id" : 870817116
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 60, 75 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 106, 112 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481547637175246848",
  "text" : "RT @WickedGoodRuby: Another great conference to consider is @nickelcityruby organized by former Bostonian @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 40, 55 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 86, 92 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481540295830802435",
    "text" : "Another great conference to consider is @nickelcityruby organized by former Bostonian @qrush",
    "id" : 481540295830802435,
    "created_at" : "2014-06-24 20:52:07 +0000",
    "user" : {
      "name" : "WickedGoodRuby",
      "screen_name" : "WickedGoodRuby",
      "protected" : false,
      "id_str" : "870817116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447321075\/22a4737f7aa69dfd4a64874de6ed8d9c_normal.png",
      "id" : 870817116,
      "verified" : false
    }
  },
  "id" : 481547637175246848,
  "created_at" : "2014-06-24 21:21:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth Transier",
      "screen_name" : "ktransier",
      "indices" : [ 0, 10 ],
      "id_str" : "255370666",
      "id" : 255370666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481511685073543168",
  "geo" : { },
  "id_str" : "481512149013897217",
  "in_reply_to_user_id" : 255370666,
  "text" : "@ktransier at a Barnes &amp; Noble.",
  "id" : 481512149013897217,
  "in_reply_to_status_id" : 481511685073543168,
  "created_at" : "2014-06-24 19:00:17 +0000",
  "in_reply_to_screen_name" : "ktransier",
  "in_reply_to_user_id_str" : "255370666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 0, 6 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481510864659288065",
  "geo" : { },
  "id_str" : "481511644665622528",
  "in_reply_to_user_id" : 920539489,
  "text" : "@_zzak Real estate bubble.",
  "id" : 481511644665622528,
  "in_reply_to_status_id" : 481510864659288065,
  "created_at" : "2014-06-24 18:58:16 +0000",
  "in_reply_to_screen_name" : "_zzak",
  "in_reply_to_user_id_str" : "920539489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James O'Leary",
      "screen_name" : "jpohh",
      "indices" : [ 0, 6 ],
      "id_str" : "14174759",
      "id" : 14174759
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 45, 55 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481507039797968896",
  "geo" : { },
  "id_str" : "481510256258736129",
  "in_reply_to_user_id" : 14174759,
  "text" : "@jpohh Ah ha! yeah it was looking awful. \/cc @aquaranto",
  "id" : 481510256258736129,
  "in_reply_to_status_id" : 481507039797968896,
  "created_at" : "2014-06-24 18:52:45 +0000",
  "in_reply_to_screen_name" : "jpohh",
  "in_reply_to_user_id_str" : "14174759",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481505795142856705",
  "text" : "Found Puerto Rico on sale for $20 today, finally succumbed. I'd really like to get different color pieces for the colonists though :(",
  "id" : 481505795142856705,
  "created_at" : "2014-06-24 18:35:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Kevin Menard",
      "screen_name" : "nirvdrum",
      "indices" : [ 20, 29 ],
      "id_str" : "14925480",
      "id" : 14925480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481494942162771968",
  "geo" : { },
  "id_str" : "481498547510984704",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham I can hear @nirvdrum salivating from here",
  "id" : 481498547510984704,
  "in_reply_to_status_id" : 481494942162771968,
  "created_at" : "2014-06-24 18:06:14 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 70, 84 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242589618, -78.8810617994 ]
  },
  "id_str" : "481494414712250370",
  "text" : "Where did the dreamland (?) \/ huge terra cotta face go on Forest? \/cc @BuffaloRising",
  "id" : 481494414712250370,
  "created_at" : "2014-06-24 17:49:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481492882093002753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.925171674, -78.8810136176 ]
  },
  "id_str" : "481494231257591810",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik I wish it was faster.",
  "id" : 481494231257591810,
  "in_reply_to_status_id" : 481492882093002753,
  "created_at" : "2014-06-24 17:49:05 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/hpdxhcurGS",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2013-11-16",
      "display_url" : "aqueousband.net\/shows\/2013-11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481467397262426113",
  "text" : "RT @UnclePhilsBlog: #AQnet updates. Audio added to 2013-11-16 Nietzsche's http:\/\/t.co\/hpdxhcurGS w\/ Peaches debut, acoustic encore A+ All I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "AQband",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/hpdxhcurGS",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2013-11-16",
        "display_url" : "aqueousband.net\/shows\/2013-11-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481467268153745409",
    "text" : "#AQnet updates. Audio added to 2013-11-16 Nietzsche's http:\/\/t.co\/hpdxhcurGS w\/ Peaches debut, acoustic encore A+ All In &amp; Origami #AQband",
    "id" : 481467268153745409,
    "created_at" : "2014-06-24 16:01:56 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 481467397262426113,
  "created_at" : "2014-06-24 16:02:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481448540711813120",
  "geo" : { },
  "id_str" : "481449011623124992",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith Quite true.",
  "id" : 481449011623124992,
  "in_reply_to_status_id" : 481448540711813120,
  "created_at" : "2014-06-24 14:49:23 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481447746767843329",
  "geo" : { },
  "id_str" : "481448617719255042",
  "in_reply_to_user_id" : 5743852,
  "text" : "@ryandotsmith This was a bit unwarranted, sorry...just something that's been bugging me about the current culture around BTC, etc",
  "id" : 481448617719255042,
  "in_reply_to_status_id" : 481447746767843329,
  "created_at" : "2014-06-24 14:47:50 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481447351253364736",
  "geo" : { },
  "id_str" : "481447746767843329",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith how do you balance this with the greed\/corruption\/scamming\/power that plagues Bitcoin\/any cryptocurrency? It feels bankrupt.",
  "id" : 481447746767843329,
  "in_reply_to_status_id" : 481447351253364736,
  "created_at" : "2014-06-24 14:44:22 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/6yRXHdKgzU",
      "expanded_url" : "http:\/\/www.blitzortung.org\/Webpages\/index.php?lang=en&page_0=30",
      "display_url" : "blitzortung.org\/Webpages\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481269704384708608",
  "text" : "Every lightning strike in REAL TIME. Wow. http:\/\/t.co\/6yRXHdKgzU",
  "id" : 481269704384708608,
  "created_at" : "2014-06-24 02:56:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 0, 10 ],
      "id_str" : "15735952",
      "id" : 15735952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481239082056835073",
  "geo" : { },
  "id_str" : "481259747769741312",
  "in_reply_to_user_id" : 15735952,
  "text" : "@jessabean no worries! I'd appreciate spreading the word to any Shopify(ers?) folks who'd be interested",
  "id" : 481259747769741312,
  "in_reply_to_status_id" : 481239082056835073,
  "created_at" : "2014-06-24 02:17:19 +0000",
  "in_reply_to_screen_name" : "jessabean",
  "in_reply_to_user_id_str" : "15735952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sean mackey",
      "screen_name" : "1DancingCrane",
      "indices" : [ 3, 17 ],
      "id_str" : "558058097",
      "id" : 558058097
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Climate",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/xMRnuLDRd9",
      "expanded_url" : "http:\/\/thkpr.gs\/1m6aDIY",
      "display_url" : "thkpr.gs\/1m6aDIY"
    } ]
  },
  "geo" : { },
  "id_str" : "481258752826286080",
  "text" : "RT @1DancingCrane: If you are 29 years old or younger, you have never experienced a colder-than-average month in your life http:\/\/t.co\/xMRn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Climate",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/xMRnuLDRd9",
        "expanded_url" : "http:\/\/thkpr.gs\/1m6aDIY",
        "display_url" : "thkpr.gs\/1m6aDIY"
      } ]
    },
    "geo" : { },
    "id_str" : "481171402528010240",
    "text" : "If you are 29 years old or younger, you have never experienced a colder-than-average month in your life http:\/\/t.co\/xMRnuLDRd9 #Climate",
    "id" : 481171402528010240,
    "created_at" : "2014-06-23 20:26:16 +0000",
    "user" : {
      "name" : "sean mackey",
      "screen_name" : "1DancingCrane",
      "protected" : false,
      "id_str" : "558058097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2357681674\/uegf63vezgwv4sppbos0_normal.gif",
      "id" : 558058097,
      "verified" : false
    }
  },
  "id" : 481258752826286080,
  "created_at" : "2014-06-24 02:13:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 0, 10 ],
      "id_str" : "15735952",
      "id" : 15735952
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 21, 36 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481238401224818688",
  "geo" : { },
  "id_str" : "481238494161813505",
  "in_reply_to_user_id" : 15735952,
  "text" : "@jessabean how about @nickelcityruby? CFP is open! :)",
  "id" : 481238494161813505,
  "in_reply_to_status_id" : 481238401224818688,
  "created_at" : "2014-06-24 00:52:52 +0000",
  "in_reply_to_screen_name" : "jessabean",
  "in_reply_to_user_id_str" : "15735952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481227248238739457",
  "text" : "RT @dwarfort_txt: made dwarves with seriously damaged vital organs wait for rescue instead of attempting to work",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469115604612284416",
    "text" : "made dwarves with seriously damaged vital organs wait for rescue instead of attempting to work",
    "id" : 469115604612284416,
    "created_at" : "2014-05-21 14:00:50 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 481227248238739457,
  "created_at" : "2014-06-24 00:08:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481227112414576640",
  "text" : "RT @dwarfort_txt: made baby snatchers only go for intelligent children",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476363361869778944",
    "text" : "made baby snatchers only go for intelligent children",
    "id" : 476363361869778944,
    "created_at" : "2014-06-10 14:00:50 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 481227112414576640,
  "created_at" : "2014-06-24 00:07:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481227034400542720",
  "text" : "RT @dwarfort_txt: Failure to master emotional states leads to forced actions like running away",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480138442202824704",
    "text" : "Failure to master emotional states leads to forced actions like running away",
    "id" : 480138442202824704,
    "created_at" : "2014-06-21 00:01:39 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 481227034400542720,
  "created_at" : "2014-06-24 00:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "indices" : [ 3, 16 ],
      "id_str" : "2481922668",
      "id" : 2481922668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481226978733727744",
  "text" : "RT @dwarfort_txt: fix problems with dwarven brains that had developed, like how they started crawling around on the ground and so on",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473252869710172162",
    "text" : "fix problems with dwarven brains that had developed, like how they started crawling around on the ground and so on",
    "id" : 473252869710172162,
    "created_at" : "2014-06-02 00:00:51 +0000",
    "user" : {
      "name" : "dwarf fortress.txt",
      "screen_name" : "dwarfort_txt",
      "protected" : false,
      "id_str" : "2481922668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464018412838981634\/cDrF9kxo_normal.png",
      "id" : 2481922668,
      "verified" : false
    }
  },
  "id" : 481226978733727744,
  "created_at" : "2014-06-24 00:07:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iv\u00E1n Olivares Rojas",
      "screen_name" : "ivolivares",
      "indices" : [ 3, 14 ],
      "id_str" : "19507704",
      "id" : 19507704
    }, {
      "name" : "Yo App",
      "screen_name" : "YoAppStatus",
      "indices" : [ 52, 64 ],
      "id_str" : "2713276746",
      "id" : 2713276746
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ivolivares\/status\/481175814558724098\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/1oBtpwLssJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq162kTIAAAnpMs.jpg",
      "id_str" : "481175813073928192",
      "id" : 481175813073928192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq162kTIAAAnpMs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1oBtpwLssJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/opJ7E9OFzJ",
      "expanded_url" : "http:\/\/www.justyo.co",
      "display_url" : "justyo.co"
    } ]
  },
  "geo" : { },
  "id_str" : "481178332990427136",
  "text" : "RT @ivolivares: El futuro de como hablaremos, seg\u00FAn @YoAppStatus : http:\/\/t.co\/opJ7E9OFzJ http:\/\/t.co\/1oBtpwLssJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yo App",
        "screen_name" : "YoAppStatus",
        "indices" : [ 36, 48 ],
        "id_str" : "2713276746",
        "id" : 2713276746
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ivolivares\/status\/481175814558724098\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/1oBtpwLssJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq162kTIAAAnpMs.jpg",
        "id_str" : "481175813073928192",
        "id" : 481175813073928192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq162kTIAAAnpMs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1oBtpwLssJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/opJ7E9OFzJ",
        "expanded_url" : "http:\/\/www.justyo.co",
        "display_url" : "justyo.co"
      } ]
    },
    "geo" : { },
    "id_str" : "481175814558724098",
    "text" : "El futuro de como hablaremos, seg\u00FAn @YoAppStatus : http:\/\/t.co\/opJ7E9OFzJ http:\/\/t.co\/1oBtpwLssJ",
    "id" : 481175814558724098,
    "created_at" : "2014-06-23 20:43:48 +0000",
    "user" : {
      "name" : "Iv\u00E1n Olivares Rojas",
      "screen_name" : "ivolivares",
      "protected" : false,
      "id_str" : "19507704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544295479161274368\/V3wOaJOV_normal.jpeg",
      "id" : 19507704,
      "verified" : false
    }
  },
  "id" : 481178332990427136,
  "created_at" : "2014-06-23 20:53:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Rudick",
      "screen_name" : "tmrudick",
      "indices" : [ 0, 9 ],
      "id_str" : "15198826",
      "id" : 15198826
    }, {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 10, 20 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481171118657523712",
  "geo" : { },
  "id_str" : "481171516621484033",
  "in_reply_to_user_id" : 15198826,
  "text" : "@tmrudick @JeffLinse 14 Ways This Design Is All Wrong and You Could Have Prevented It Months Ago",
  "id" : 481171516621484033,
  "in_reply_to_status_id" : 481171118657523712,
  "created_at" : "2014-06-23 20:26:43 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481144742667755520\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/bxL6FcZtmg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1el-0CMAA2kkP.png",
      "id_str" : "481144741807927296",
      "id" : 481144741807927296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1el-0CMAA2kkP.png",
      "sizes" : [ {
        "h" : 136,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 136,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 85,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bxL6FcZtmg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481144742667755520",
  "text" : "AMBER alert website is also awful. Nothing like windows 95 checkboxes on the web in images. http:\/\/t.co\/bxL6FcZtmg",
  "id" : 481144742667755520,
  "created_at" : "2014-06-23 18:40:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481135504566804480",
  "geo" : { },
  "id_str" : "481135722015891457",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage Can't push here and no status update. \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 481135722015891457,
  "in_reply_to_status_id" : 481135504566804480,
  "created_at" : "2014-06-23 18:04:29 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 71, 82 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 83, 92 ],
      "id_str" : "5232171",
      "id" : 5232171
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/481133507209465857\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/voBra8Ictt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1UX_BCMAEHhNd.png",
      "id_str" : "481133506228006913",
      "id" : 481133506228006913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1UX_BCMAEHhNd.png",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 514
      } ],
      "display_url" : "pic.twitter.com\/voBra8Ictt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481133507209465857",
  "text" : "Twitter's terrible web UI is now injecting despondency everywhere. \/cc @ashedryden @konklone http:\/\/t.co\/voBra8Ictt",
  "id" : 481133507209465857,
  "created_at" : "2014-06-23 17:55:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 21, 33 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Lwu0Pqzv0E",
      "expanded_url" : "https:\/\/flic.kr\/p\/nMZ1bh",
      "display_url" : "flic.kr\/p\/nMZ1bh"
    } ]
  },
  "geo" : { },
  "id_str" : "481133146872639489",
  "text" : "Killing it as usual. @AqueousBand from this weekend. https:\/\/t.co\/Lwu0Pqzv0E",
  "id" : 481133146872639489,
  "created_at" : "2014-06-23 17:54:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 7, 17 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481129018260197376",
  "geo" : { },
  "id_str" : "481129324146204672",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik @nrrrdcore Position Absolute",
  "id" : 481129324146204672,
  "in_reply_to_status_id" : 481129018260197376,
  "created_at" : "2014-06-23 17:39:04 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481094262210056193",
  "geo" : { },
  "id_str" : "481096263199240192",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo turned out great. what do you use for video editing? FCP?",
  "id" : 481096263199240192,
  "in_reply_to_status_id" : 481094262210056193,
  "created_at" : "2014-06-23 15:27:42 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 27, 39 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Nectar's \/ Metronome",
      "screen_name" : "nectarsvt",
      "indices" : [ 73, 83 ],
      "id_str" : "54998419",
      "id" : 54998419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "queen",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "AQband",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/SdEr5BOwt7",
      "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2013-03-30",
      "display_url" : "aqueousband.net\/shows\/2013-03-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481094288973905924",
  "text" : "RT @UnclePhilsBlog: #AQnet @AqueousBand update Added audio to 2013-03-30 @nectarsvt http:\/\/t.co\/SdEr5BOwt7 #queen\/warren medly. Top notch C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 7, 19 ],
        "id_str" : "26904582",
        "id" : 26904582
      }, {
        "name" : "Nectar's \/ Metronome",
        "screen_name" : "nectarsvt",
        "indices" : [ 53, 63 ],
        "id_str" : "54998419",
        "id" : 54998419
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "queen",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "AQband",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/SdEr5BOwt7",
        "expanded_url" : "http:\/\/www.aqueousband.net\/shows\/2013-03-30",
        "display_url" : "aqueousband.net\/shows\/2013-03-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481081055878070272",
    "text" : "#AQnet @AqueousBand update Added audio to 2013-03-30 @nectarsvt http:\/\/t.co\/SdEr5BOwt7 #queen\/warren medly. Top notch Complex etc. #AQband",
    "id" : 481081055878070272,
    "created_at" : "2014-06-23 14:27:16 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 481094288973905924,
  "created_at" : "2014-06-23 15:19:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241660408, -78.8791096515 ]
  },
  "id_str" : "480902803720646656",
  "text" : "Next door neighbor is a home brewer and brewed an IPA that easily rivals Southern Tier\u2019s. I love Elmwood Village.",
  "id" : 480902803720646656,
  "created_at" : "2014-06-23 02:38:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242863041, -78.8790371363 ]
  },
  "id_str" : "480889975718686721",
  "text" : "Seeing comic artists\u2019 workspaces\/battlestations is great. Most analog still.",
  "id" : 480889975718686721,
  "created_at" : "2014-06-23 01:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924348875, -78.8789653872 ]
  },
  "id_str" : "480887572248276992",
  "text" : "Dear Mr Watterson feels more creepy\/stalkerish than endearing.",
  "id" : 480887572248276992,
  "created_at" : "2014-06-23 01:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BuffaloRising\/status\/480831771643498496\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4wsKylJ7ja",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqxB7QNCcAIH_aT.jpg",
      "id_str" : "480831746439540738",
      "id" : 480831746439540738,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqxB7QNCcAIH_aT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4wsKylJ7ja"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480832102720864257",
  "text" : "RT @BuffaloRising: A few years ago, this sort of turnout in downtown Buffalo to watch soccer on television would have been unimaginable htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BuffaloRising\/status\/480831771643498496\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/4wsKylJ7ja",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqxB7QNCcAIH_aT.jpg",
        "id_str" : "480831746439540738",
        "id" : 480831746439540738,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqxB7QNCcAIH_aT.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4wsKylJ7ja"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480831771643498496",
    "text" : "A few years ago, this sort of turnout in downtown Buffalo to watch soccer on television would have been unimaginable http:\/\/t.co\/4wsKylJ7ja",
    "id" : 480831771643498496,
    "created_at" : "2014-06-22 21:56:42 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 480832102720864257,
  "created_at" : "2014-06-22 21:58:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/mgB3w4LWHi",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2013\/07\/04\/us\/monitoring-of-snail-mail.html?pagewanted=all&_r=0",
      "display_url" : "mobile.nytimes.com\/2013\/07\/04\/us\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.5114594261, -79.2327893247 ]
  },
  "id_str" : "480550185123082240",
  "text" : "One of my neighborhood book stores. WTF http:\/\/t.co\/mgB3w4LWHi",
  "id" : 480550185123082240,
  "created_at" : "2014-06-22 03:17:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalove Music Fest",
      "screen_name" : "BuffaloveFest",
      "indices" : [ 3, 17 ],
      "id_str" : "976207790",
      "id" : 976207790
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 19, 31 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BuffaloveFest\/status\/480525643034419200\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/eHJi9Jzexx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqsrhhfCAAIRHT9.jpg",
      "id_str" : "480525640169291778",
      "id" : 480525640169291778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqsrhhfCAAIRHT9.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eHJi9Jzexx"
    } ],
    "hashtags" : [ {
      "text" : "Live",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "Buffalove",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "music",
      "indices" : [ 54, 60 ]
    }, {
      "text" : "festival",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480527330155057153",
  "text" : "RT @BuffaloveFest: @AqueousBand #Live now! #Buffalove #music #festival http:\/\/t.co\/eHJi9Jzexx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 0, 12 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BuffaloveFest\/status\/480525643034419200\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/eHJi9Jzexx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqsrhhfCAAIRHT9.jpg",
        "id_str" : "480525640169291778",
        "id" : 480525640169291778,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqsrhhfCAAIRHT9.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eHJi9Jzexx"
      } ],
      "hashtags" : [ {
        "text" : "Live",
        "indices" : [ 13, 18 ]
      }, {
        "text" : "Buffalove",
        "indices" : [ 24, 34 ]
      }, {
        "text" : "music",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "festival",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480525643034419200",
    "in_reply_to_user_id" : 26904582,
    "text" : "@AqueousBand #Live now! #Buffalove #music #festival http:\/\/t.co\/eHJi9Jzexx",
    "id" : 480525643034419200,
    "created_at" : "2014-06-22 01:40:15 +0000",
    "in_reply_to_screen_name" : "AqueousBand",
    "in_reply_to_user_id_str" : "26904582",
    "user" : {
      "name" : "Buffalove Music Fest",
      "screen_name" : "BuffaloveFest",
      "protected" : false,
      "id_str" : "976207790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573562120199094272\/MbYzRMSd_normal.jpeg",
      "id" : 976207790,
      "verified" : false
    }
  },
  "id" : 480527330155057153,
  "created_at" : "2014-06-22 01:46:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 19, 31 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/480523237898452992\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/FXNhgFl4hf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqspVWzCcAET93N.jpg",
      "id_str" : "480523232118730753",
      "id" : 480523232118730753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqspVWzCcAET93N.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FXNhgFl4hf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.5115963025, -79.2325016578 ]
  },
  "id_str" : "480523237898452992",
  "text" : "It\u2019s time for some @AqueousBand. http:\/\/t.co\/FXNhgFl4hf",
  "id" : 480523237898452992,
  "created_at" : "2014-06-22 01:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 3, 17 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/LFH4pAKh5U",
      "expanded_url" : "http:\/\/wordpress.org",
      "display_url" : "wordpress.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/57TTgbCEKj",
      "expanded_url" : "https:\/\/github.com\/WordPress\/WordPress\/blob\/fd838ccb2b1d37bda02eecdf09c324863f050812\/wp-admin\/setup-config.php#L211",
      "display_url" : "github.com\/WordPress\/Word\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480155756721733632",
  "text" : "RT @garybernhardt: TIL: Good random number generation is hard in PHP, so Wordpress HTTP GETs random salt from http:\/\/t.co\/LFH4pAKh5U. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/LFH4pAKh5U",
        "expanded_url" : "http:\/\/wordpress.org",
        "display_url" : "wordpress.org"
      }, {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/57TTgbCEKj",
        "expanded_url" : "https:\/\/github.com\/WordPress\/WordPress\/blob\/fd838ccb2b1d37bda02eecdf09c324863f050812\/wp-admin\/setup-config.php#L211",
        "display_url" : "github.com\/WordPress\/Word\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480105287689314305",
    "text" : "TIL: Good random number generation is hard in PHP, so Wordpress HTTP GETs random salt from http:\/\/t.co\/LFH4pAKh5U. https:\/\/t.co\/57TTgbCEKj",
    "id" : 480105287689314305,
    "created_at" : "2014-06-20 21:49:55 +0000",
    "user" : {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "protected" : false,
      "id_str" : "809685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170938305\/twitter_headshot_normal.png",
      "id" : 809685,
      "verified" : false
    }
  },
  "id" : 480155756721733632,
  "created_at" : "2014-06-21 01:10:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Urple Pingo ",
      "screen_name" : "UrplePingo",
      "indices" : [ 3, 14 ],
      "id_str" : "381269609",
      "id" : 381269609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480137569548529665",
  "text" : "RT @UrplePingo: Buffalo style chicken wings are just wings that are prone to lake-effect snow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480134145260388352",
    "text" : "Buffalo style chicken wings are just wings that are prone to lake-effect snow",
    "id" : 480134145260388352,
    "created_at" : "2014-06-20 23:44:35 +0000",
    "user" : {
      "name" : "Urple Pingo ",
      "screen_name" : "UrplePingo",
      "protected" : false,
      "id_str" : "381269609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528702738335412224\/f8xncgIJ_normal.png",
      "id" : 381269609,
      "verified" : false
    }
  },
  "id" : 480137569548529665,
  "created_at" : "2014-06-20 23:58:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Dinh",
      "screen_name" : "xuki",
      "indices" : [ 3, 8 ],
      "id_str" : "20143170",
      "id" : 20143170
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/xuki\/status\/479937721679347713\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/dTPiXAsfsk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqkU0J1CQAATUJL.png",
      "id_str" : "479937721515786240",
      "id" : 479937721515786240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqkU0J1CQAATUJL.png",
      "sizes" : [ {
        "h" : 219,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com\/dTPiXAsfsk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480113060195991554",
  "text" : "RT @xuki: Yes, it's possible to grab anyone's phone number on Yo. http:\/\/t.co\/dTPiXAsfsk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/xuki\/status\/479937721679347713\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dTPiXAsfsk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqkU0J1CQAATUJL.png",
        "id_str" : "479937721515786240",
        "id" : 479937721515786240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqkU0J1CQAATUJL.png",
        "sizes" : [ {
          "h" : 219,
          "resize" : "fit",
          "w" : 476
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 476
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 476
        } ],
        "display_url" : "pic.twitter.com\/dTPiXAsfsk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479937721679347713",
    "text" : "Yes, it's possible to grab anyone's phone number on Yo. http:\/\/t.co\/dTPiXAsfsk",
    "id" : 479937721679347713,
    "created_at" : "2014-06-20 10:44:04 +0000",
    "user" : {
      "name" : "Jason Dinh",
      "screen_name" : "xuki",
      "protected" : false,
      "id_str" : "20143170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2994915277\/e72df7f450890abe9f83b58b39908f10_normal.jpeg",
      "id" : 20143170,
      "verified" : false
    }
  },
  "id" : 480113060195991554,
  "created_at" : "2014-06-20 22:20:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 0, 14 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480069690799431680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244337837, -78.8792330214 ]
  },
  "id_str" : "480080007914459136",
  "in_reply_to_user_id" : 1689069979,
  "text" : "@dividedwilson pretty terrible. Oh well!",
  "id" : 480080007914459136,
  "in_reply_to_status_id" : 480069690799431680,
  "created_at" : "2014-06-20 20:09:28 +0000",
  "in_reply_to_screen_name" : "dividedwilson",
  "in_reply_to_user_id_str" : "1689069979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 3, 15 ],
      "id_str" : "156708162",
      "id" : 156708162
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 23, 29 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/ZTlOJtkGh9",
      "expanded_url" : "http:\/\/5by5.tv\/rubyonrails\/155",
      "display_url" : "5by5.tv\/rubyonrails\/155"
    } ]
  },
  "geo" : { },
  "id_str" : "480023343547314176",
  "text" : "RT @barelyknown: =&gt; @qrush reveals rubygems fantasies, ranks his noteworthiness, explains concert balloons, makes us better parents.\n\nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 6, 12 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/ZTlOJtkGh9",
        "expanded_url" : "http:\/\/5by5.tv\/rubyonrails\/155",
        "display_url" : "5by5.tv\/rubyonrails\/155"
      } ]
    },
    "geo" : { },
    "id_str" : "479966968796434432",
    "text" : "=&gt; @qrush reveals rubygems fantasies, ranks his noteworthiness, explains concert balloons, makes us better parents.\n\nhttp:\/\/t.co\/ZTlOJtkGh9",
    "id" : 479966968796434432,
    "created_at" : "2014-06-20 12:40:17 +0000",
    "user" : {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "protected" : false,
      "id_str" : "156708162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538511339040538624\/jQHVi93g_normal.jpeg",
      "id" : 156708162,
      "verified" : false
    }
  },
  "id" : 480023343547314176,
  "created_at" : "2014-06-20 16:24:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/480023296944386048\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2q5A0O2vSv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlipIRCAAAGaFm.jpg",
      "id_str" : "480023294024744960",
      "id" : 480023294024744960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlipIRCAAAGaFm.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2q5A0O2vSv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0554058822, -78.8640940469 ]
  },
  "id_str" : "480023296944386048",
  "text" : "Apparently in 1999 I had some very specific complaints about The Hobbit. http:\/\/t.co\/2q5A0O2vSv",
  "id" : 480023296944386048,
  "created_at" : "2014-06-20 16:24:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Hartman",
      "screen_name" : "devth",
      "indices" : [ 0, 6 ],
      "id_str" : "14084548",
      "id" : 14084548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480009995501572096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0554058822, -78.8640940469 ]
  },
  "id_str" : "480023066362540033",
  "in_reply_to_user_id" : 14084548,
  "text" : "@devth yep!",
  "id" : 480023066362540033,
  "in_reply_to_status_id" : 480009995501572096,
  "created_at" : "2014-06-20 16:23:12 +0000",
  "in_reply_to_screen_name" : "devth",
  "in_reply_to_user_id_str" : "14084548",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen T Watson",
      "screen_name" : "buffaloscribe",
      "indices" : [ 3, 17 ],
      "id_str" : "14904704",
      "id" : 14904704
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 23, 27 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8drWEoTGo9",
      "expanded_url" : "http:\/\/online.wsj.com\/articles\/visitors-to-buffalo-n-y-find-beauty-in-decay-1403231726",
      "display_url" : "online.wsj.com\/articles\/visit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479986517310337026",
  "text" : "RT @buffaloscribe: The @WSJ did an A1 story about #Buffalo today. We're no North Korea, they conceded. So we've got that going for us. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 4, 8 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8drWEoTGo9",
        "expanded_url" : "http:\/\/online.wsj.com\/articles\/visitors-to-buffalo-n-y-find-beauty-in-decay-1403231726",
        "display_url" : "online.wsj.com\/articles\/visit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479985330213244929",
    "text" : "The @WSJ did an A1 story about #Buffalo today. We're no North Korea, they conceded. So we've got that going for us. http:\/\/t.co\/8drWEoTGo9",
    "id" : 479985330213244929,
    "created_at" : "2014-06-20 13:53:15 +0000",
    "user" : {
      "name" : "Stephen T Watson",
      "screen_name" : "buffaloscribe",
      "protected" : false,
      "id_str" : "14904704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451725969078775808\/Ug2gcVzc_normal.jpeg",
      "id" : 14904704,
      "verified" : false
    }
  },
  "id" : 479986517310337026,
  "created_at" : "2014-06-20 13:57:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/pNfSQgmZtx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=c9YjLsuUTZE",
      "display_url" : "youtube.com\/watch?v=c9YjLs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479851363799552000",
  "text" : "Current status: https:\/\/t.co\/pNfSQgmZtx",
  "id" : 479851363799552000,
  "created_at" : "2014-06-20 05:00:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479847306255400960",
  "geo" : { },
  "id_str" : "479847634358652928",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal it's literally the point of the article!",
  "id" : 479847634358652928,
  "in_reply_to_status_id" : 479847306255400960,
  "created_at" : "2014-06-20 04:46:05 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/kFiX1c5xAt",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mullet_(haircut)",
      "display_url" : "en.wikipedia.org\/wiki\/Mullet_(h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479845083835953153",
  "text" : "Easily Buffalo's most import export: \"1992 mullet, Buffalo, NY\" http:\/\/t.co\/kFiX1c5xAt",
  "id" : 479845083835953153,
  "created_at" : "2014-06-20 04:35:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "indices" : [ 0, 3 ],
      "id_str" : "18949452",
      "id" : 18949452
    }, {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 4, 12 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/479844185466355713\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/uTjEBCHlcE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqi_vlKCcAAQSSB.png",
      "id_str" : "479844184463929344",
      "id" : 479844184463929344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqi_vlKCcAAQSSB.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1176,
        "resize" : "fit",
        "w" : 2016
      } ],
      "display_url" : "pic.twitter.com\/uTjEBCHlcE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479807579162677248",
  "geo" : { },
  "id_str" : "479844185466355713",
  "in_reply_to_user_id" : 18949452,
  "text" : "@FT @micheal this is some kind of sick joke right? http:\/\/t.co\/uTjEBCHlcE",
  "id" : 479844185466355713,
  "in_reply_to_status_id" : 479807579162677248,
  "created_at" : "2014-06-20 04:32:23 +0000",
  "in_reply_to_screen_name" : "FT",
  "in_reply_to_user_id_str" : "18949452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479835855935135744",
  "text" : "Lesson learned: the GoPro needs to be real close. Like, really, really close to whatever you want to shoot.",
  "id" : 479835855935135744,
  "created_at" : "2014-06-20 03:59:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moe.",
      "screen_name" : "moeperiod",
      "indices" : [ 6, 16 ],
      "id_str" : "60102709",
      "id" : 60102709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766482483, -78.8785269787 ]
  },
  "id_str" : "479802723093581825",
  "text" : "First @moeperiod show and they have 3 horn players out. Spoiled.",
  "id" : 479802723093581825,
  "created_at" : "2014-06-20 01:47:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/479796331066585088\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/qD8xpG4rYu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqiUN-iCIAErOGg.jpg",
      "id_str" : "479796328159911937",
      "id" : 479796328159911937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqiUN-iCIAErOGg.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qD8xpG4rYu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8759974894, -78.8784159534 ]
  },
  "id_str" : "479796331066585088",
  "text" : "Apparently this dog poop bag holder knew there would be a concert here. http:\/\/t.co\/qD8xpG4rYu",
  "id" : 479796331066585088,
  "created_at" : "2014-06-20 01:22:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@Pete716",
      "screen_name" : "Pete716",
      "indices" : [ 0, 8 ],
      "id_str" : "33588043",
      "id" : 33588043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8761922429, -78.8783970942 ]
  },
  "id_str" : "479790853775314944",
  "in_reply_to_user_id" : 33588043,
  "text" : "@Pete716 is that your drone?",
  "id" : 479790853775314944,
  "created_at" : "2014-06-20 01:00:28 +0000",
  "in_reply_to_screen_name" : "Pete716",
  "in_reply_to_user_id_str" : "33588043",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 0, 14 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    }, {
      "name" : "Lenny Stubbe",
      "screen_name" : "lastubbe",
      "indices" : [ 15, 24 ],
      "id_str" : "53466569",
      "id" : 53466569
    }, {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 25, 38 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 39, 48 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 49, 60 ],
      "id_str" : "146513248",
      "id" : 146513248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479788062764183552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766713288, -78.8785117742 ]
  },
  "id_str" : "479790785206829056",
  "in_reply_to_user_id" : 1689069979,
  "text" : "@dividedwilson @lastubbe @antelopeezer @LawnMemo @duh_nellll next to!",
  "id" : 479790785206829056,
  "in_reply_to_status_id" : 479788062764183552,
  "created_at" : "2014-06-20 01:00:11 +0000",
  "in_reply_to_screen_name" : "dividedwilson",
  "in_reply_to_user_id_str" : "1689069979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Stubbe",
      "screen_name" : "lastubbe",
      "indices" : [ 0, 9 ],
      "id_str" : "53466569",
      "id" : 53466569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479786514675924992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766495738, -78.8784727236 ]
  },
  "id_str" : "479787087877533696",
  "in_reply_to_user_id" : 53466569,
  "text" : "@lastubbe literally next to stop sign. RIT shirt.",
  "id" : 479787087877533696,
  "in_reply_to_status_id" : 479786514675924992,
  "created_at" : "2014-06-20 00:45:30 +0000",
  "in_reply_to_screen_name" : "lastubbe",
  "in_reply_to_user_id_str" : "53466569",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jules",
      "screen_name" : "jlsmp",
      "indices" : [ 0, 6 ],
      "id_str" : "1856037409",
      "id" : 1856037409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479783519770513409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766618434, -78.8785038394 ]
  },
  "id_str" : "479784282391470080",
  "in_reply_to_user_id" : 1856037409,
  "text" : "@jlsmp constantly.",
  "id" : 479784282391470080,
  "in_reply_to_status_id" : 479783519770513409,
  "created_at" : "2014-06-20 00:34:21 +0000",
  "in_reply_to_screen_name" : "jlsmp",
  "in_reply_to_user_id_str" : "1856037409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 14, 28 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 29, 38 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479776455153704960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8768673863, -78.8787686385 ]
  },
  "id_str" : "479783905923313664",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @dividedwilson @LawnMemo move up when you\u2019re done. Plenty of room! \uD83C\uDD99",
  "id" : 479783905923313664,
  "in_reply_to_status_id" : 479776455153704960,
  "created_at" : "2014-06-20 00:32:51 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/479776669054824448\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/9uJQRI8ZWW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqiCVqLIIAEc0Cp.jpg",
      "id_str" : "479776668924780545",
      "id" : 479776668924780545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqiCVqLIIAEc0Cp.jpg",
      "sizes" : [ {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      } ],
      "display_url" : "pic.twitter.com\/9uJQRI8ZWW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3asqhgLn5L",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/19\/raccoon-with-head-stuck-in-pea.html",
      "display_url" : "boingboing.net\/2014\/06\/19\/rac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479781869005705216",
  "text" : "RT @BoingBoing: Raccoon with head stuck in peanut butter jar rescued from top of hydro transformer. http:\/\/t.co\/3asqhgLn5L http:\/\/t.co\/9uJQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/479776669054824448\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/9uJQRI8ZWW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqiCVqLIIAEc0Cp.jpg",
        "id_str" : "479776668924780545",
        "id" : 479776668924780545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqiCVqLIIAEc0Cp.jpg",
        "sizes" : [ {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/9uJQRI8ZWW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/3asqhgLn5L",
        "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/19\/raccoon-with-head-stuck-in-pea.html",
        "display_url" : "boingboing.net\/2014\/06\/19\/rac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479776669054824448",
    "text" : "Raccoon with head stuck in peanut butter jar rescued from top of hydro transformer. http:\/\/t.co\/3asqhgLn5L http:\/\/t.co\/9uJQRI8ZWW",
    "id" : 479776669054824448,
    "created_at" : "2014-06-20 00:04:06 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504445056237842432\/PxYzLwez_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 479781869005705216,
  "created_at" : "2014-06-20 00:24:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 14, 28 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 29, 38 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479776455153704960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766840644, -78.8785685533 ]
  },
  "id_str" : "479777046764064769",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @dividedwilson @LawnMemo had to tape up the GoPro. Can\u2019t move!",
  "id" : 479777046764064769,
  "in_reply_to_status_id" : 479776455153704960,
  "created_at" : "2014-06-20 00:05:36 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 14, 28 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 29, 38 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 39, 50 ],
      "id_str" : "146513248",
      "id" : 146513248
    }, {
      "name" : "Lenny Stubbe",
      "screen_name" : "lastubbe",
      "indices" : [ 51, 60 ],
      "id_str" : "53466569",
      "id" : 53466569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479594772529954816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766254551, -78.8784478769 ]
  },
  "id_str" : "479775104302186496",
  "in_reply_to_user_id" : 5743852,
  "text" : "@antelopeezer @dividedwilson @LawnMemo @duh_nellll @lastubbe stop sign stage right, say hi!",
  "id" : 479775104302186496,
  "in_reply_to_status_id" : 479594772529954816,
  "created_at" : "2014-06-19 23:57:53 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/479774743411687424\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/A1W0Oe49Dy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqiAlBACYAEyGfS.jpg",
      "id_str" : "479774733727064065",
      "id" : 479774733727064065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqiAlBACYAEyGfS.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/A1W0Oe49Dy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8766305572, -78.8784639706 ]
  },
  "id_str" : "479774743411687424",
  "text" : "First taping lesson learned: bring duct tape. http:\/\/t.co\/A1W0Oe49Dy",
  "id" : 479774743411687424,
  "created_at" : "2014-06-19 23:56:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/moonpolysoft\/status\/479646573257703425\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/FWEHM5PjQq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqgMBEgCYAA5iFe.jpg",
      "id_str" : "479646572842475520",
      "id" : 479646572842475520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqgMBEgCYAA5iFe.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FWEHM5PjQq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479720070982037504",
  "text" : "RT @moonpolysoft: Unlike the cruel Leonidas, who demanded that you stand, I require only that you kneel. http:\/\/t.co\/FWEHM5PjQq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/moonpolysoft\/status\/479646573257703425\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/FWEHM5PjQq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqgMBEgCYAA5iFe.jpg",
        "id_str" : "479646572842475520",
        "id" : 479646572842475520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqgMBEgCYAA5iFe.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/FWEHM5PjQq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479646573257703425",
    "text" : "Unlike the cruel Leonidas, who demanded that you stand, I require only that you kneel. http:\/\/t.co\/FWEHM5PjQq",
    "id" : 479646573257703425,
    "created_at" : "2014-06-19 15:27:09 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 479720070982037504,
  "created_at" : "2014-06-19 20:19:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 3, 11 ],
      "id_str" : "12145232",
      "id" : 12145232
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 16, 27 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ZR8fwX9GwM",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/ouvhwwxu3rlfrcq\/2014-06-19%2010.57.55.jpg",
      "display_url" : "dropbox.com\/s\/ouvhwwxu3rlf\u2026"
    }, {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/m1saqupP9i",
      "expanded_url" : "http:\/\/alldaywiththis.com\/product+from+kevin's+spec",
      "display_url" : "alldaywiththis.com\/product+from+k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479703943874748416",
  "text" : "RT @CDMoyer: So @kevinpurdy gave me this spec: https:\/\/t.co\/ZR8fwX9GwM and I made this http:\/\/t.co\/m1saqupP9i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Purdy",
        "screen_name" : "kevinpurdy",
        "indices" : [ 3, 14 ],
        "id_str" : "14687182",
        "id" : 14687182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/ZR8fwX9GwM",
        "expanded_url" : "https:\/\/www.dropbox.com\/s\/ouvhwwxu3rlfrcq\/2014-06-19%2010.57.55.jpg",
        "display_url" : "dropbox.com\/s\/ouvhwwxu3rlf\u2026"
      }, {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/m1saqupP9i",
        "expanded_url" : "http:\/\/alldaywiththis.com\/product+from+kevin's+spec",
        "display_url" : "alldaywiththis.com\/product+from+k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479703851084165120",
    "text" : "So @kevinpurdy gave me this spec: https:\/\/t.co\/ZR8fwX9GwM and I made this http:\/\/t.co\/m1saqupP9i",
    "id" : 479703851084165120,
    "created_at" : "2014-06-19 19:14:45 +0000",
    "user" : {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "protected" : false,
      "id_str" : "12145232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421641487051272192\/IfEg0PgG_normal.jpeg",
      "id" : 12145232,
      "verified" : false
    }
  },
  "id" : 479703943874748416,
  "created_at" : "2014-06-19 19:15:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 67, 73 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "Butt Coin",
      "screen_name" : "ButtCoin",
      "indices" : [ 94, 103 ],
      "id_str" : "305854715",
      "id" : 305854715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/YD6b6RsNsd",
      "expanded_url" : "http:\/\/phish.com\/randallsisland\/",
      "display_url" : "phish.com\/randallsisland\/"
    } ]
  },
  "geo" : { },
  "id_str" : "479699345931919361",
  "text" : "\"Or 87 bitcoins for a CyberTicket 2.0.\" http:\/\/t.co\/YD6b6RsNsd \/cc @phish is getting into the @ButtCoin business.",
  "id" : 479699345931919361,
  "created_at" : "2014-06-19 18:56:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 0, 5 ],
      "id_str" : "637533",
      "id" : 637533
    }, {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 14, 20 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479685606818082816",
  "geo" : { },
  "id_str" : "479692472985985024",
  "in_reply_to_user_id" : 637533,
  "text" : "@coda you and @vrunt need to go into business here. I'll funderdog your boatercycles.",
  "id" : 479692472985985024,
  "in_reply_to_status_id" : 479685606818082816,
  "created_at" : "2014-06-19 18:29:32 +0000",
  "in_reply_to_screen_name" : "coda",
  "in_reply_to_user_id_str" : "637533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 3, 8 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479692402903363584",
  "text" : "RT @coda: What idiot called it bootstrapping instead of funderdogging.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479685606818082816",
    "text" : "What idiot called it bootstrapping instead of funderdogging.",
    "id" : 479685606818082816,
    "created_at" : "2014-06-19 18:02:15 +0000",
    "user" : {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "protected" : false,
      "id_str" : "637533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530569133880926208\/HVC_bWBj_normal.jpeg",
      "id" : 637533,
      "verified" : false
    }
  },
  "id" : 479692402903363584,
  "created_at" : "2014-06-19 18:29:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479690927662186496",
  "geo" : { },
  "id_str" : "479692319575126018",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik this is part of why i started gitready...to just try and understand it, because I didn't.",
  "id" : 479692319575126018,
  "in_reply_to_status_id" : 479690927662186496,
  "created_at" : "2014-06-19 18:28:55 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 3, 10 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alldaywiththis",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/aIHYZCcX4z",
      "expanded_url" : "http:\/\/alldaywiththis.com\/humidity+and+what+have+you",
      "display_url" : "alldaywiththis.com\/humidity+and+w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479681987934830592",
  "text" : "RT @nb3004: http:\/\/t.co\/aIHYZCcX4z #alldaywiththis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alldaywiththis",
        "indices" : [ 23, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/aIHYZCcX4z",
        "expanded_url" : "http:\/\/alldaywiththis.com\/humidity+and+what+have+you",
        "display_url" : "alldaywiththis.com\/humidity+and+w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479681952954331136",
    "text" : "http:\/\/t.co\/aIHYZCcX4z #alldaywiththis",
    "id" : 479681952954331136,
    "created_at" : "2014-06-19 17:47:44 +0000",
    "user" : {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "protected" : false,
      "id_str" : "5452072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477084296000585728\/PVswHXyq_normal.jpeg",
      "id" : 5452072,
      "verified" : false
    }
  },
  "id" : 479681987934830592,
  "created_at" : "2014-06-19 17:47:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "Tim-burrr",
      "screen_name" : "dividedwilson",
      "indices" : [ 14, 28 ],
      "id_str" : "1689069979",
      "id" : 1689069979
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 29, 38 ],
      "id_str" : "829816736",
      "id" : 829816736
    }, {
      "name" : "tow truck central",
      "screen_name" : "duh_nellll",
      "indices" : [ 39, 50 ],
      "id_str" : "146513248",
      "id" : 146513248
    }, {
      "name" : "Lenny Stubbe",
      "screen_name" : "lastubbe",
      "indices" : [ 51, 60 ],
      "id_str" : "53466569",
      "id" : 53466569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479594193032318976",
  "geo" : { },
  "id_str" : "479594772529954816",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer @dividedwilson @LawnMemo @duh_nellll @lastubbe yes!",
  "id" : 479594772529954816,
  "in_reply_to_status_id" : 479594193032318976,
  "created_at" : "2014-06-19 12:01:18 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moe.",
      "screen_name" : "moeperiod",
      "indices" : [ 4, 14 ],
      "id_str" : "60102709",
      "id" : 60102709
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 18, 30 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/479430294106144770\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/tZDG1BOuJo",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BqdHTx5CQAIXNII.png",
      "id_str" : "479430290473893890",
      "id" : 479430290473893890,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BqdHTx5CQAIXNII.png",
      "sizes" : [ {
        "h" : 206,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/tZDG1BOuJo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479430294106144770",
  "text" : "Uh, @moeperiod  + @whereslloyd tomorrow!!?! http:\/\/t.co\/tZDG1BOuJo",
  "id" : 479430294106144770,
  "created_at" : "2014-06-19 01:07:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/gsFo3qBbPK",
      "expanded_url" : "http:\/\/buffalo.craigslist.org\/med\/4526794630.html",
      "display_url" : "buffalo.craigslist.org\/med\/4526794630\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479414724509982721",
  "text" : "\"Then I begin SPROOPING. This usually takes 10 - 15 minutes.\" http:\/\/t.co\/gsFo3qBbPK",
  "id" : 479414724509982721,
  "created_at" : "2014-06-19 00:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "CWB Coffee Bot",
      "screen_name" : "CWBCoffeeBot",
      "indices" : [ 54, 67 ],
      "id_str" : "2575328137",
      "id" : 2575328137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479338489033396224",
  "text" : "RT @coworkbuffalo: Amazing it took this long, really. @CWBCoffeeBot tweets whenever there's fresh coffee in the carafe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CWB Coffee Bot",
        "screen_name" : "CWBCoffeeBot",
        "indices" : [ 35, 48 ],
        "id_str" : "2575328137",
        "id" : 2575328137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479338383861219329",
    "text" : "Amazing it took this long, really. @CWBCoffeeBot tweets whenever there's fresh coffee in the carafe.",
    "id" : 479338383861219329,
    "created_at" : "2014-06-18 19:02:31 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 479338489033396224,
  "created_at" : "2014-06-18 19:02:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/479308472475852800\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/wZ7NJoyRmU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BqbYgvWCYAEOlvu.png",
      "id_str" : "479308467337846785",
      "id" : 479308467337846785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BqbYgvWCYAEOlvu.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/wZ7NJoyRmU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479308472475852800",
  "text" : "CURRENT TWITTER GIF STATUS http:\/\/t.co\/wZ7NJoyRmU",
  "id" : 479308472475852800,
  "created_at" : "2014-06-18 17:03:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Finnigan",
      "screen_name" : "littlegemma",
      "indices" : [ 3, 15 ],
      "id_str" : "21665520",
      "id" : 21665520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/nbj35sA0wf",
      "expanded_url" : "http:\/\/pierregrassou.tumblr.com\/post\/88985005944\/collection-of-robots-saying-fuck-this-shit",
      "display_url" : "pierregrassou.tumblr.com\/post\/889850059\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479297600001036288",
  "text" : "RT @littlegemma: The future is here! And it's horrible. http:\/\/t.co\/nbj35sA0wf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/nbj35sA0wf",
        "expanded_url" : "http:\/\/pierregrassou.tumblr.com\/post\/88985005944\/collection-of-robots-saying-fuck-this-shit",
        "display_url" : "pierregrassou.tumblr.com\/post\/889850059\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479297209490751488",
    "text" : "The future is here! And it's horrible. http:\/\/t.co\/nbj35sA0wf",
    "id" : 479297209490751488,
    "created_at" : "2014-06-18 16:18:54 +0000",
    "user" : {
      "name" : "Gemma Finnigan",
      "screen_name" : "littlegemma",
      "protected" : false,
      "id_str" : "21665520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2000613543\/avatar-gem-orange_normal.jpg",
      "id" : 21665520,
      "verified" : false
    }
  },
  "id" : 479297600001036288,
  "created_at" : "2014-06-18 16:20:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479289455384096769",
  "geo" : { },
  "id_str" : "479290090191998976",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek Whatever, Jonn.",
  "id" : 479290090191998976,
  "in_reply_to_status_id" : 479289455384096769,
  "created_at" : "2014-06-18 15:50:36 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/IGXs8dsjXK",
      "expanded_url" : "http:\/\/usatftw.files.wordpress.com\/2013\/05\/frnxxym1.gif",
      "display_url" : "usatftw.files.wordpress.com\/2013\/05\/frnxxy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479288702007377920",
  "text" : "Current status: http:\/\/t.co\/IGXs8dsjXK",
  "id" : 479288702007377920,
  "created_at" : "2014-06-18 15:45:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/2t8OtGEJdr",
      "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/sets\/aqueous-2013-06-21-buffalove?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter",
      "display_url" : "soundcloud.com\/unclephilsblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479277717456564224",
  "text" : "Gearing up for this weekend... https:\/\/t.co\/2t8OtGEJdr",
  "id" : 479277717456564224,
  "created_at" : "2014-06-18 15:01:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479276995088371713",
  "text" : "Oh good, Pingdom got bought. Someone please kill them. Just plain old SMS when your site is down. No \"incidents\".",
  "id" : 479276995088371713,
  "created_at" : "2014-06-18 14:58:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479273685551824896",
  "text" : "What is simple on the web is hair-pullingly difficult on iOS. It doesn't have to be this way.",
  "id" : 479273685551824896,
  "created_at" : "2014-06-18 14:45:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 3, 12 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479272619493974016",
  "text" : "RT @KentBeck: The best person for the project may not be the person most qualified but the person least likely to quit when it turns out to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479271911902302209",
    "text" : "The best person for the project may not be the person most qualified but the person least likely to quit when it turns out to be impossible",
    "id" : 479271911902302209,
    "created_at" : "2014-06-18 14:38:22 +0000",
    "user" : {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "protected" : false,
      "id_str" : "16891384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2550670043\/xq10bqclqpsezgerjxhi_normal.jpeg",
      "id" : 16891384,
      "verified" : false
    }
  },
  "id" : 479272619493974016,
  "created_at" : "2014-06-18 14:41:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/kkY8GJh0I4",
      "expanded_url" : "http:\/\/www.aqueousband.net\/search?utf8=%E2%9C%93&query=Weezer",
      "display_url" : "aqueousband.net\/search?utf8=%E\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9245857476, -78.8797450718 ]
  },
  "id_str" : "479092105713704961",
  "text" : "Quick new feature: searching notes. http:\/\/t.co\/kkY8GJh0I4 (Postgres arrays are fun to search on!)",
  "id" : 479092105713704961,
  "created_at" : "2014-06-18 02:43:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Loudermilk",
      "screen_name" : "bloudermilk",
      "indices" : [ 0, 12 ],
      "id_str" : "21021674",
      "id" : 21021674
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 13, 17 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/x6UIAhic92",
      "expanded_url" : "http:\/\/signalvnoise.com\/posts\/3743-hybrid-sweet-spot-native-navigation-web-content",
      "display_url" : "signalvnoise.com\/posts\/3743-hyb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "479057099700199424",
  "geo" : { },
  "id_str" : "479064034012975104",
  "in_reply_to_user_id" : 21021674,
  "text" : "@bloudermilk @dhh started to: http:\/\/t.co\/x6UIAhic92",
  "id" : 479064034012975104,
  "in_reply_to_status_id" : 479057099700199424,
  "created_at" : "2014-06-18 00:52:20 +0000",
  "in_reply_to_screen_name" : "bloudermilk",
  "in_reply_to_user_id_str" : "21021674",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buffaBLOG",
      "screen_name" : "buffablog",
      "indices" : [ 3, 13 ],
      "id_str" : "127746638",
      "id" : 127746638
    }, {
      "name" : "Summer Camp Festival",
      "screen_name" : "SummerCampFest",
      "indices" : [ 30, 45 ],
      "id_str" : "95287028",
      "id" : 95287028
    }, {
      "name" : "moe.",
      "screen_name" : "moeperiod",
      "indices" : [ 78, 88 ],
      "id_str" : "60102709",
      "id" : 60102709
    }, {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 93, 105 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ombBp2rzlB",
      "expanded_url" : "http:\/\/www.buffablog.com\/a-time-of-music-the-music-of-time\/",
      "display_url" : "buffablog.com\/a-time-of-musi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479027695628455937",
  "text" : "RT @buffablog: Mathew went to @SummerCampFest and linked up with members from @moeperiod and @AqueousBand.\nhttp:\/\/t.co\/ombBp2rzlB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Summer Camp Festival",
        "screen_name" : "SummerCampFest",
        "indices" : [ 15, 30 ],
        "id_str" : "95287028",
        "id" : 95287028
      }, {
        "name" : "moe.",
        "screen_name" : "moeperiod",
        "indices" : [ 63, 73 ],
        "id_str" : "60102709",
        "id" : 60102709
      }, {
        "name" : "Aqueous",
        "screen_name" : "AqueousBand",
        "indices" : [ 78, 90 ],
        "id_str" : "26904582",
        "id" : 26904582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/ombBp2rzlB",
        "expanded_url" : "http:\/\/www.buffablog.com\/a-time-of-music-the-music-of-time\/",
        "display_url" : "buffablog.com\/a-time-of-musi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478969806658736130",
    "text" : "Mathew went to @SummerCampFest and linked up with members from @moeperiod and @AqueousBand.\nhttp:\/\/t.co\/ombBp2rzlB",
    "id" : 478969806658736130,
    "created_at" : "2014-06-17 18:37:55 +0000",
    "user" : {
      "name" : "buffaBLOG",
      "screen_name" : "buffablog",
      "protected" : false,
      "id_str" : "127746638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530392751632691200\/WYmJtrU5_normal.jpeg",
      "id" : 127746638,
      "verified" : false
    }
  },
  "id" : 479027695628455937,
  "created_at" : "2014-06-17 22:27:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Boulden",
      "screen_name" : "Spruke",
      "indices" : [ 0, 7 ],
      "id_str" : "182384817",
      "id" : 182384817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478981182470639617",
  "geo" : { },
  "id_str" : "478982821055193089",
  "in_reply_to_user_id" : 182384817,
  "text" : "@Spruke Refuse to pay for the content, and view in Incognito to avoid poorly programmed paywall. Repeat until medium is dead.",
  "id" : 478982821055193089,
  "in_reply_to_status_id" : 478981182470639617,
  "created_at" : "2014-06-17 19:29:38 +0000",
  "in_reply_to_screen_name" : "Spruke",
  "in_reply_to_user_id_str" : "182384817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478973134042062848",
  "geo" : { },
  "id_str" : "478973296017289216",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby relax.",
  "id" : 478973296017289216,
  "in_reply_to_status_id" : 478973134042062848,
  "created_at" : "2014-06-17 18:51:47 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steve corona",
      "screen_name" : "stevencorona",
      "indices" : [ 3, 16 ],
      "id_str" : "65739266",
      "id" : 65739266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/JOzamzN5RU",
      "expanded_url" : "http:\/\/google.com",
      "display_url" : "google.com"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/1eO8B1pS8z",
      "expanded_url" : "http:\/\/www.dns-sd.org\/TrailingDotsInDomainNames.html",
      "display_url" : "dns-sd.org\/TrailingDotsIn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478952467288170496",
  "text" : "RT @stevencorona: TIL a trailing dot in the domain is totally valid... i.e \"http:\/\/t.co\/JOzamzN5RU.\"\n\nhttp:\/\/t.co\/1eO8B1pS8z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/JOzamzN5RU",
        "expanded_url" : "http:\/\/google.com",
        "display_url" : "google.com"
      }, {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/1eO8B1pS8z",
        "expanded_url" : "http:\/\/www.dns-sd.org\/TrailingDotsInDomainNames.html",
        "display_url" : "dns-sd.org\/TrailingDotsIn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478951320125054976",
    "text" : "TIL a trailing dot in the domain is totally valid... i.e \"http:\/\/t.co\/JOzamzN5RU.\"\n\nhttp:\/\/t.co\/1eO8B1pS8z",
    "id" : 478951320125054976,
    "created_at" : "2014-06-17 17:24:27 +0000",
    "user" : {
      "name" : "steve corona",
      "screen_name" : "stevencorona",
      "protected" : false,
      "id_str" : "65739266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000023003710\/878430f7b11196014ca204aee4a2c9df_normal.png",
      "id" : 65739266,
      "verified" : false
    }
  },
  "id" : 478952467288170496,
  "created_at" : "2014-06-17 17:29:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/2lTL5oVLB9",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/86a3222b12dca6761bec405141c76d7b\/tumblr_n79srzxIuL1qzsyh3o1_500.gif",
      "display_url" : "31.media.tumblr.com\/86a3222b12dca6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478951013122990081",
  "text" : "BEER http:\/\/t.co\/2lTL5oVLB9",
  "id" : 478951013122990081,
  "created_at" : "2014-06-17 17:23:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick St\u00E4hler",
      "screen_name" : "business_inno",
      "indices" : [ 3, 17 ],
      "id_str" : "24961651",
      "id" : 24961651
    }, {
      "name" : "M. Colville-Andersen",
      "screen_name" : "copenhagenize",
      "indices" : [ 98, 112 ],
      "id_str" : "17815546",
      "id" : 17815546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ArqwOXcQ8i",
      "expanded_url" : "http:\/\/www.collectorsweekly.com\/articles\/murder-machines\/?src=longreads",
      "display_url" : "collectorsweekly.com\/articles\/murde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478891058806652928",
  "text" : "RT @business_inno: How the cities looked before we designed them for cars. http:\/\/t.co\/ArqwOXcQ8i @copenhagenize",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M. Colville-Andersen",
        "screen_name" : "copenhagenize",
        "indices" : [ 79, 93 ],
        "id_str" : "17815546",
        "id" : 17815546
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/ArqwOXcQ8i",
        "expanded_url" : "http:\/\/www.collectorsweekly.com\/articles\/murder-machines\/?src=longreads",
        "display_url" : "collectorsweekly.com\/articles\/murde\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478865031514578944",
    "text" : "How the cities looked before we designed them for cars. http:\/\/t.co\/ArqwOXcQ8i @copenhagenize",
    "id" : 478865031514578944,
    "created_at" : "2014-06-17 11:41:35 +0000",
    "user" : {
      "name" : "Patrick St\u00E4hler",
      "screen_name" : "business_inno",
      "protected" : false,
      "id_str" : "24961651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2144036055\/Werkzeugkasten_002_normal.jpg",
      "id" : 24961651,
      "verified" : false
    }
  },
  "id" : 478891058806652928,
  "created_at" : "2014-06-17 13:25:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478887772644601856",
  "text" : "@AlMehltretter I'm sure this could get funding.",
  "id" : 478887772644601856,
  "created_at" : "2014-06-17 13:11:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish Dry Goods",
      "screen_name" : "phishdrygoods",
      "indices" : [ 0, 14 ],
      "id_str" : "69779454",
      "id" : 69779454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478697435041390592",
  "geo" : { },
  "id_str" : "478714166992064512",
  "in_reply_to_user_id" : 69779454,
  "text" : "@phishdrygoods got a response from there. thanks!",
  "id" : 478714166992064512,
  "in_reply_to_status_id" : 478697435041390592,
  "created_at" : "2014-06-17 01:42:06 +0000",
  "in_reply_to_screen_name" : "phishdrygoods",
  "in_reply_to_user_id_str" : "69779454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    }, {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 16, 25 ],
      "id_str" : "9462972",
      "id" : 9462972
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 26, 36 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478692172284588032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9587328248, -78.85150644 ]
  },
  "id_str" : "478696768939388928",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd oh man! \/cc @bitsweat @asianmack",
  "id" : 478696768939388928,
  "in_reply_to_status_id" : 478692172284588032,
  "created_at" : "2014-06-17 00:32:58 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478681209199800320",
  "text" : "Useless online currency, a energy shake to replace food, and now a scratch and sniff machine for your iPhone. I hate my generation's tech.",
  "id" : 478681209199800320,
  "created_at" : "2014-06-16 23:31:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478636285368999938",
  "geo" : { },
  "id_str" : "478680345412247552",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown can we do this over email instead? :) nick [at] quaran.to",
  "id" : 478680345412247552,
  "in_reply_to_status_id" : 478636285368999938,
  "created_at" : "2014-06-16 23:27:42 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Devine",
      "screen_name" : "barelyknown",
      "indices" : [ 0, 12 ],
      "id_str" : "156708162",
      "id" : 156708162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478624799766622208",
  "geo" : { },
  "id_str" : "478636213503422468",
  "in_reply_to_user_id" : 156708162,
  "text" : "@barelyknown hey, sure.",
  "id" : 478636213503422468,
  "in_reply_to_status_id" : 478624799766622208,
  "created_at" : "2014-06-16 20:32:20 +0000",
  "in_reply_to_screen_name" : "barelyknown",
  "in_reply_to_user_id_str" : "156708162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish Dry Goods",
      "screen_name" : "phishdrygoods",
      "indices" : [ 0, 14 ],
      "id_str" : "69779454",
      "id" : 69779454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478613966013222912",
  "in_reply_to_user_id" : 69779454,
  "text" : "@phishdrygoods your email form is broken. do you have a real email we can just..email?",
  "id" : 478613966013222912,
  "created_at" : "2014-06-16 19:03:56 +0000",
  "in_reply_to_screen_name" : "phishdrygoods",
  "in_reply_to_user_id_str" : "69779454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/KtPtO55Kwg",
      "expanded_url" : "http:\/\/gifsound.com\/?gif=https:\/\/31.media.tumblr.com\/0336f6f87c3222d5430d1e07a5e970e8\/tumblr_n34momakSK1s7tqseo1_400.gif&v=xhrBDcQq2DM",
      "display_url" : "gifsound.com\/?gif=https:\/\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478595344909885441",
  "text" : "Current status: http:\/\/t.co\/KtPtO55Kwg",
  "id" : 478595344909885441,
  "created_at" : "2014-06-16 17:49:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gh33da",
      "screen_name" : "gh33da",
      "indices" : [ 0, 7 ],
      "id_str" : "16468950",
      "id" : 16468950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478574573102055426",
  "geo" : { },
  "id_str" : "478592672471318528",
  "in_reply_to_user_id" : 16468950,
  "text" : "@gh33da stuff ;)",
  "id" : 478592672471318528,
  "in_reply_to_status_id" : 478574573102055426,
  "created_at" : "2014-06-16 17:39:19 +0000",
  "in_reply_to_screen_name" : "gh33da",
  "in_reply_to_user_id_str" : "16468950",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 14, 26 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478575666204774400",
  "geo" : { },
  "id_str" : "478592641030815746",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @coreyhaines no.",
  "id" : 478592641030815746,
  "in_reply_to_status_id" : 478575666204774400,
  "created_at" : "2014-06-16 17:39:12 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael F.",
      "screen_name" : "mafellows",
      "indices" : [ 0, 10 ],
      "id_str" : "125434293",
      "id" : 125434293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478574569557467136",
  "geo" : { },
  "id_str" : "478580655308029953",
  "in_reply_to_user_id" : 125434293,
  "text" : "@mafellows that is not a \"feature\"",
  "id" : 478580655308029953,
  "in_reply_to_status_id" : 478574569557467136,
  "created_at" : "2014-06-16 16:51:34 +0000",
  "in_reply_to_screen_name" : "mafellows",
  "in_reply_to_user_id_str" : "125434293",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478574392549449728",
  "text" : "Is there any way to prevent Xcode from jumping to main.m on a crash? I hate losing my context.",
  "id" : 478574392549449728,
  "created_at" : "2014-06-16 16:26:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478561551855521792",
  "text" : "It's been several weeks now of duplicate tweets on the Twitter web timeline. Still convinced no one there uses the website.",
  "id" : 478561551855521792,
  "created_at" : "2014-06-16 15:35:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 33, 48 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/J5iXSz478K",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "478558849503219712",
  "text" : "In case you missed it on Friday, @nickelcityruby's CFP and registration is open! ZOMG! http:\/\/t.co\/J5iXSz478K",
  "id" : 478558849503219712,
  "created_at" : "2014-06-16 15:24:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bla\u017E Hrastnik",
      "screen_name" : "archseer",
      "indices" : [ 0, 9 ],
      "id_str" : "2241363272",
      "id" : 2241363272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478537765496586240",
  "geo" : { },
  "id_str" : "478537876431306752",
  "in_reply_to_user_id" : 2241363272,
  "text" : "@archseer I think we\u2019re all confused by it. Side effect of driving through 2 months of issues quickly.",
  "id" : 478537876431306752,
  "in_reply_to_status_id" : 478537765496586240,
  "created_at" : "2014-06-16 14:01:35 +0000",
  "in_reply_to_screen_name" : "archseer",
  "in_reply_to_user_id_str" : "2241363272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478525364738592769",
  "geo" : { },
  "id_str" : "478530431633981441",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan looks like you need a\u2026\n\n\u2026eggsactoknife safety class.\n\nYEAHHHHHHHHHHHHHHH",
  "id" : 478530431633981441,
  "in_reply_to_status_id" : 478525364738592769,
  "created_at" : "2014-06-16 13:32:00 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 3, 9 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "nprmusic",
      "screen_name" : "nprmusic",
      "indices" : [ 86, 95 ],
      "id_str" : "13784592",
      "id" : 13784592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/f1nCcEtna6",
      "expanded_url" : "http:\/\/n.pr\/1iA9pVW",
      "display_url" : "n.pr\/1iA9pVW"
    } ]
  },
  "geo" : { },
  "id_str" : "478380217459691520",
  "text" : "RT @phish: Here's your first listen to Phish's new studio album, in its entirety. RT \u201C@nprmusic: First Listen: Phish, 'Fuego' http:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nprmusic",
        "screen_name" : "nprmusic",
        "indices" : [ 75, 84 ],
        "id_str" : "13784592",
        "id" : 13784592
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/f1nCcEtna6",
        "expanded_url" : "http:\/\/n.pr\/1iA9pVW",
        "display_url" : "n.pr\/1iA9pVW"
      } ]
    },
    "in_reply_to_status_id_str" : "478377107123216385",
    "geo" : { },
    "id_str" : "478380048055943169",
    "in_reply_to_user_id" : 13784592,
    "text" : "Here's your first listen to Phish's new studio album, in its entirety. RT \u201C@nprmusic: First Listen: Phish, 'Fuego' http:\/\/t.co\/f1nCcEtna6\"",
    "id" : 478380048055943169,
    "in_reply_to_status_id" : 478377107123216385,
    "created_at" : "2014-06-16 03:34:25 +0000",
    "in_reply_to_screen_name" : "nprmusic",
    "in_reply_to_user_id_str" : "13784592",
    "user" : {
      "name" : "Phish",
      "screen_name" : "phish",
      "protected" : false,
      "id_str" : "14503997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524599876630216704\/KczioeHn_normal.jpeg",
      "id" : 14503997,
      "verified" : true
    }
  },
  "id" : 478380217459691520,
  "created_at" : "2014-06-16 03:35:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/HsNhGmbnN9",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "478371295571107840",
  "text" : "Knocked down 43 http:\/\/t.co\/HsNhGmbnN9 tickets. Would love to get to zero on a daily basis by this time next year.",
  "id" : 478371295571107840,
  "created_at" : "2014-06-16 02:59:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 49, 59 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/478184518441259009\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jbIPtlAnMN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLaSM1IYAAtpJL.jpg",
      "id_str" : "478184516671266816",
      "id" : 478184516671266816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLaSM1IYAAtpJL.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jbIPtlAnMN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478184594605637632",
  "text" : "RT @coworkbuffalo: Day 2 of setting up shop with @BlockClub at Allen West. Come get a mug or poster! Or both! http:\/\/t.co\/jbIPtlAnMN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Block Club",
        "screen_name" : "BlockClub",
        "indices" : [ 30, 40 ],
        "id_str" : "21003240",
        "id" : 21003240
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/478184518441259009\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/jbIPtlAnMN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLaSM1IYAAtpJL.jpg",
        "id_str" : "478184516671266816",
        "id" : 478184516671266816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLaSM1IYAAtpJL.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jbIPtlAnMN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478184518441259009",
    "text" : "Day 2 of setting up shop with @BlockClub at Allen West. Come get a mug or poster! Or both! http:\/\/t.co\/jbIPtlAnMN",
    "id" : 478184518441259009,
    "created_at" : "2014-06-15 14:37:28 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 478184594605637632,
  "created_at" : "2014-06-15 14:37:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477951262990671872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240710208, -78.8792511311 ]
  },
  "id_str" : "477952109497679872",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante i bought some and I didn\u2019t even need any. \uD83C\uDF7B",
  "id" : 477952109497679872,
  "in_reply_to_status_id" : 477951262990671872,
  "created_at" : "2014-06-14 23:13:57 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 3, 14 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Q8sAHH9aTn",
      "expanded_url" : "http:\/\/instagram.com\/p\/pPg7yIJ9Fr\/",
      "display_url" : "instagram.com\/p\/pPg7yIJ9Fr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477951968069971968",
  "text" : "RT @dangigante: Woohoo! Beer at the Co-op! @ Lexington Co-op http:\/\/t.co\/Q8sAHH9aTn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/Q8sAHH9aTn",
        "expanded_url" : "http:\/\/instagram.com\/p\/pPg7yIJ9Fr\/",
        "display_url" : "instagram.com\/p\/pPg7yIJ9Fr\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.919217772, -78.877005313 ]
    },
    "id_str" : "477951262990671872",
    "text" : "Woohoo! Beer at the Co-op! @ Lexington Co-op http:\/\/t.co\/Q8sAHH9aTn",
    "id" : 477951262990671872,
    "created_at" : "2014-06-14 23:10:35 +0000",
    "user" : {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "protected" : false,
      "id_str" : "43151378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482218130996232192\/bISq7rRg_normal.jpeg",
      "id" : 43151378,
      "verified" : false
    }
  },
  "id" : 477951968069971968,
  "created_at" : "2014-06-14 23:13:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/477848197885218817\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/soCTfW8YWA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqGoZrtCYAEj1JT.jpg",
      "id_str" : "477848194659803137",
      "id" : 477848194659803137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqGoZrtCYAEj1JT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/soCTfW8YWA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89870665, -78.8741696366 ]
  },
  "id_str" : "477848197885218817",
  "text" : "Printed my own coaster with letterpress. Awesome. http:\/\/t.co\/soCTfW8YWA",
  "id" : 477848197885218817,
  "created_at" : "2014-06-14 16:21:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/477838323948351488\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/TGpVF3Kyqy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqGfa3LCUAABw7I.jpg",
      "id_str" : "477838319313637376",
      "id" : 477838319313637376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqGfa3LCUAABw7I.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TGpVF3Kyqy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8995169839, -78.8792300039 ]
  },
  "id_str" : "477838323948351488",
  "text" : "Get you some @coworkbuffalo swag today at Allen West! http:\/\/t.co\/TGpVF3Kyqy",
  "id" : 477838323948351488,
  "created_at" : "2014-06-14 15:41:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 11, 23 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477715146970656768",
  "geo" : { },
  "id_str" : "477785297074151424",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @jamesgolick it was! Not a bad thing. Happy to know and have met so many awesome folks. And it\u2019s just beginning :)",
  "id" : 477785297074151424,
  "in_reply_to_status_id" : 477715146970656768,
  "created_at" : "2014-06-14 12:11:06 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 47, 55 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9241004571, -78.8793527866 ]
  },
  "id_str" : "477612769294839809",
  "text" : "Anyone else playing some MK8 this evening? \/cc @sikachu",
  "id" : 477612769294839809,
  "created_at" : "2014-06-14 00:45:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 82, 94 ],
      "id_str" : "588743",
      "id" : 588743
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 95, 102 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 103, 112 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 113, 118 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tH9FGL0dMu",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "477561830101893120",
  "text" : "RT @nickelcityruby: Good Morning! We are excited to announce our 2014 Keynoters:  @antiheroine @bryanl @sarahmei @r00k! Register now! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Myers",
        "screen_name" : "antiheroine",
        "indices" : [ 62, 74 ],
        "id_str" : "588743",
        "id" : 588743
      }, {
        "name" : "Bryan Liles",
        "screen_name" : "bryanl",
        "indices" : [ 75, 82 ],
        "id_str" : "659933",
        "id" : 659933
      }, {
        "name" : "Sarah Mei",
        "screen_name" : "sarahmei",
        "indices" : [ 83, 92 ],
        "id_str" : "14164724",
        "id" : 14164724
      }, {
        "name" : "Ben Orenstein",
        "screen_name" : "r00k",
        "indices" : [ 93, 98 ],
        "id_str" : "11280212",
        "id" : 11280212
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tH9FGL0dMu",
        "expanded_url" : "http:\/\/nickelcityruby.com",
        "display_url" : "nickelcityruby.com"
      } ]
    },
    "geo" : { },
    "id_str" : "477441711300284417",
    "text" : "Good Morning! We are excited to announce our 2014 Keynoters:  @antiheroine @bryanl @sarahmei @r00k! Register now! http:\/\/t.co\/tH9FGL0dMu",
    "id" : 477441711300284417,
    "created_at" : "2014-06-13 13:25:49 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 477561830101893120,
  "created_at" : "2014-06-13 21:23:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mai$e",
      "screen_name" : "crushingbort",
      "indices" : [ 3, 16 ],
      "id_str" : "188587219",
      "id" : 188587219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477514116454572032",
  "text" : "RT @crushingbort: VESSYL: You are drinking a beer. 93 calories\nME: Vessyl, lose 40 calories\n*VESSYL leaks beer onto table*\nTABYL: there is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477507715711791104",
    "text" : "VESSYL: You are drinking a beer. 93 calories\nME: Vessyl, lose 40 calories\n*VESSYL leaks beer onto table*\nTABYL: there is beer on the table",
    "id" : 477507715711791104,
    "created_at" : "2014-06-13 17:48:05 +0000",
    "user" : {
      "name" : "Mai$e",
      "screen_name" : "crushingbort",
      "protected" : false,
      "id_str" : "188587219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539314247767842816\/de_trD2o_normal.jpeg",
      "id" : 188587219,
      "verified" : false
    }
  },
  "id" : 477514116454572032,
  "created_at" : "2014-06-13 18:13:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/6OxU4JnFAx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4-5e51fFP0Q",
      "display_url" : "youtube.com\/watch?v=4-5e51\u2026"
    }, {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Ucev3rB7HU",
      "expanded_url" : "http:\/\/bl.ocks.org\/mbostock\/11357811",
      "display_url" : "bl.ocks.org\/mbostock\/11357\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477508735724576769",
  "text" : "Step 1: Open https:\/\/t.co\/6OxU4JnFAx Step 2: Open http:\/\/t.co\/Ucev3rB7HU",
  "id" : 477508735724576769,
  "created_at" : "2014-06-13 17:52:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477477792607531008",
  "geo" : { },
  "id_str" : "477478521799835649",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Son, you can do anything you set your mind to. Except be a video game journalist for BuzzFeed.",
  "id" : 477478521799835649,
  "in_reply_to_status_id" : 477477792607531008,
  "created_at" : "2014-06-13 15:52:05 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477476309275140097",
  "text" : "I can't wait for the first person to get kicked out of a bar in SF for requesting their drinks be poured in a Vessyl.",
  "id" : 477476309275140097,
  "created_at" : "2014-06-13 15:43:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477475255120691200",
  "text" : "RT @ftrain: in the video everyone is walking in slow motion alone in a narcissistic haze holding a cup that truly knows them and who they a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477473573171240961",
    "text" : "in the video everyone is walking in slow motion alone in a narcissistic haze holding a cup that truly knows them and who they are",
    "id" : 477473573171240961,
    "created_at" : "2014-06-13 15:32:25 +0000",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3363818792\/c90e33ccf22e3146d5cd871ce561795a_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 477475255120691200,
  "created_at" : "2014-06-13 15:39:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Henderson",
      "screen_name" : "nathos",
      "indices" : [ 0, 7 ],
      "id_str" : "34953",
      "id" : 34953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477473965598724097",
  "geo" : { },
  "id_str" : "477474116174221312",
  "in_reply_to_user_id" : 34953,
  "text" : "@nathos Our \"Drink Disapproval Look\" package is $49.99\/month with a 2 year contract.",
  "id" : 477474116174221312,
  "in_reply_to_status_id" : 477473965598724097,
  "created_at" : "2014-06-13 15:34:34 +0000",
  "in_reply_to_screen_name" : "nathos",
  "in_reply_to_user_id_str" : "34953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/S75sQLdqOp",
      "expanded_url" : "http:\/\/RubyGem.org",
      "display_url" : "RubyGem.org"
    }, {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qQIg966v0V",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/BQ9awENrzz0\/EVbKjqUg2_AJ",
      "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477473835852124160",
  "text" : "RT @samkottler: Re-architecting http:\/\/t.co\/S75sQLdqOp's infrastructure: https:\/\/t.co\/qQIg966v0V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/S75sQLdqOp",
        "expanded_url" : "http:\/\/RubyGem.org",
        "display_url" : "RubyGem.org"
      }, {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/qQIg966v0V",
        "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/rubygems-org\/BQ9awENrzz0\/EVbKjqUg2_AJ",
        "display_url" : "groups.google.com\/d\/msg\/rubygems\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477435322033537024",
    "text" : "Re-architecting http:\/\/t.co\/S75sQLdqOp's infrastructure: https:\/\/t.co\/qQIg966v0V",
    "id" : 477435322033537024,
    "created_at" : "2014-06-13 13:00:25 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 477473835852124160,
  "created_at" : "2014-06-13 15:33:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477473717719552000",
  "text" : "I'm launching a new startup: S\u00F6lo. You buy a red Solo cup from me for $99, and I tell you what's inside of it. Now accepting investors.",
  "id" : 477473717719552000,
  "created_at" : "2014-06-13 15:33:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 18, 33 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 60, 72 ],
      "id_str" : "588743",
      "id" : 588743
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 73, 80 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 81, 90 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 91, 96 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/J5iXSz478K",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "477439505092202498",
  "text" : "Happy to announce @nickelcityruby and our first 4 speakers: @antiheroine @bryanl @sarahmei @r00k Register now: http:\/\/t.co\/J5iXSz478K",
  "id" : 477439505092202498,
  "created_at" : "2014-06-13 13:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477126452115410944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8917241763, -78.8723058798 ]
  },
  "id_str" : "477127540218146817",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @evanphx it\u2019s been mirrored tons of times",
  "id" : 477127540218146817,
  "in_reply_to_status_id" : 477126452115410944,
  "created_at" : "2014-06-12 16:37:24 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 3, 11 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/gYdHwZzFOa",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/xbBDX4NA2X",
      "expanded_url" : "http:\/\/rubygems.org\/gems\/rg-phx-test",
      "display_url" : "rubygems.org\/gems\/rg-phx-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477120342788698112",
  "text" : "RT @evanphx: Why it's impossible for http:\/\/t.co\/gYdHwZzFOa to truly delete a gem: http:\/\/t.co\/xbBDX4NA2X has 6,641 downloads. It contains \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/gYdHwZzFOa",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/xbBDX4NA2X",
        "expanded_url" : "http:\/\/rubygems.org\/gems\/rg-phx-test",
        "display_url" : "rubygems.org\/gems\/rg-phx-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477120214258032640",
    "text" : "Why it's impossible for http:\/\/t.co\/gYdHwZzFOa to truly delete a gem: http:\/\/t.co\/xbBDX4NA2X has 6,641 downloads. It contains no code.",
    "id" : 477120214258032640,
    "created_at" : "2014-06-12 16:08:18 +0000",
    "user" : {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "protected" : false,
      "id_str" : "5444392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500424848519077892\/9BhPED16_normal.jpeg",
      "id" : 5444392,
      "verified" : false
    }
  },
  "id" : 477120342788698112,
  "created_at" : "2014-06-12 16:08:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477118103282024448",
  "geo" : { },
  "id_str" : "477118999273033729",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer Do you offer to-go cups!?",
  "id" : 477118999273033729,
  "in_reply_to_status_id" : 477118103282024448,
  "created_at" : "2014-06-12 16:03:28 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ykvloGXqyf",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-ZGMozD4M-7o\/T-xaWDxqjSI\/AAAAAAAA4Do\/mSZZ-_mCGIc\/s640\/floating_Sebago_Shoe.JPG",
      "display_url" : "2.bp.blogspot.com\/-ZGMozD4M-7o\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477111477032062977",
  "text" : "Current status: http:\/\/t.co\/ykvloGXqyf",
  "id" : 477111477032062977,
  "created_at" : "2014-06-12 15:33:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 24, 29 ],
      "id_str" : "2247381",
      "id" : 2247381
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 30, 41 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 42, 52 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 53, 62 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477102883780194304",
  "geo" : { },
  "id_str" : "477105431756546049",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity I'm in. \/cc @popo @kevinpurdy @sailflyer @borncamp",
  "id" : 477105431756546049,
  "in_reply_to_status_id" : 477102883780194304,
  "created_at" : "2014-06-12 15:09:33 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Chou",
      "screen_name" : "triketora",
      "indices" : [ 3, 13 ],
      "id_str" : "19556080",
      "id" : 19556080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/jaEmGhZxYf",
      "expanded_url" : "http:\/\/newyork.craigslist.org\/mnh\/lbg\/4455510062.html",
      "display_url" : "newyork.craigslist.org\/mnh\/lbg\/445551\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476946167587041281",
  "text" : "RT @triketora: Cool bro needed to break in a pair of Rainbows (TriBeCa) http:\/\/t.co\/jaEmGhZxYf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/jaEmGhZxYf",
        "expanded_url" : "http:\/\/newyork.craigslist.org\/mnh\/lbg\/4455510062.html",
        "display_url" : "newyork.craigslist.org\/mnh\/lbg\/445551\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476915336017870849",
    "text" : "Cool bro needed to break in a pair of Rainbows (TriBeCa) http:\/\/t.co\/jaEmGhZxYf",
    "id" : 476915336017870849,
    "created_at" : "2014-06-12 02:34:11 +0000",
    "user" : {
      "name" : "Tracy Chou",
      "screen_name" : "triketora",
      "protected" : false,
      "id_str" : "19556080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553307953680228352\/dn2mTBiQ_normal.jpeg",
      "id" : 19556080,
      "verified" : false
    }
  },
  "id" : 476946167587041281,
  "created_at" : "2014-06-12 04:36:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 3, 9 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/RQ7e1zw9iX",
      "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/06\/10\/2.3.0-released.html",
      "display_url" : "blog.rubygems.org\/2014\/06\/10\/2.3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476926900418650112",
  "text" : "RT @_zzak: RubyGems 2.3.0 released with many improvements and bug fixes \uD83C\uDF89\uD83C\uDF89\uD83C\uDF8A http:\/\/t.co\/RQ7e1zw9iX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/RQ7e1zw9iX",
        "expanded_url" : "http:\/\/blog.rubygems.org\/2014\/06\/10\/2.3.0-released.html",
        "display_url" : "blog.rubygems.org\/2014\/06\/10\/2.3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476926731765309441",
    "text" : "RubyGems 2.3.0 released with many improvements and bug fixes \uD83C\uDF89\uD83C\uDF89\uD83C\uDF8A http:\/\/t.co\/RQ7e1zw9iX",
    "id" : 476926731765309441,
    "created_at" : "2014-06-12 03:19:28 +0000",
    "user" : {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "protected" : false,
      "id_str" : "920539489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760450458\/1d14e04afe654ee43abccfce2040558e_normal.jpeg",
      "id" : 920539489,
      "verified" : false
    }
  },
  "id" : 476926900418650112,
  "created_at" : "2014-06-12 03:20:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476889818698244096",
  "geo" : { },
  "id_str" : "476890038106476544",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith I thought of you immediately! I would not want it to be associated with Bitcoin or require any mining.",
  "id" : 476890038106476544,
  "in_reply_to_status_id" : 476889818698244096,
  "created_at" : "2014-06-12 00:53:39 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bandit",
      "screen_name" : "UtilityLimb",
      "indices" : [ 3, 15 ],
      "id_str" : "188124096",
      "id" : 188124096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476885781672230912",
  "text" : "RT @UtilityLimb: Programming Skills: PRIMARILY RUBY AND PYTHON BUT I CAN USE ANY TYPE OF GEM TO CONTROL ANY TYPE OF SNAKE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126780301211992064",
    "text" : "Programming Skills: PRIMARILY RUBY AND PYTHON BUT I CAN USE ANY TYPE OF GEM TO CONTROL ANY TYPE OF SNAKE",
    "id" : 126780301211992064,
    "created_at" : "2011-10-19 22:02:33 +0000",
    "user" : {
      "name" : "bandit",
      "screen_name" : "UtilityLimb",
      "protected" : false,
      "id_str" : "188124096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1641418276\/tumblr_lule5ckvND1qz4yoco1_1280_normal.png",
      "id" : 188124096,
      "verified" : false
    }
  },
  "id" : 476885781672230912,
  "created_at" : "2014-06-12 00:36:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243336502, -78.8792181486 ]
  },
  "id_str" : "476884946598891521",
  "text" : "This is stupid but\u2026 Could rubygem index and ownership data be managed by a blockchain?",
  "id" : 476884946598891521,
  "created_at" : "2014-06-12 00:33:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476878698071982080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9227776357, -78.8797521022 ]
  },
  "id_str" : "476882384743178240",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky better than a new moon.",
  "id" : 476882384743178240,
  "in_reply_to_status_id" : 476878698071982080,
  "created_at" : "2014-06-12 00:23:15 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 34, 48 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476843271495221248",
  "text" : "RT @kevinpurdy: Like @qrush said: @coworkbuffalo was 13 people today, working, chatting, making coffee\u2013and none of them had met 2 years ago.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 5, 11 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 18, 32 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476839893046669313",
    "text" : "Like @qrush said: @coworkbuffalo was 13 people today, working, chatting, making coffee\u2013and none of them had met 2 years ago.",
    "id" : 476839893046669313,
    "created_at" : "2014-06-11 21:34:24 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 476843271495221248,
  "created_at" : "2014-06-11 21:47:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476785069206831105",
  "geo" : { },
  "id_str" : "476815766658875393",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella there are a ton of cool venues we considered here that we can't use due to this. Such bs.",
  "id" : 476815766658875393,
  "in_reply_to_status_id" : 476785069206831105,
  "created_at" : "2014-06-11 19:58:32 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476812786866323456",
  "geo" : { },
  "id_str" : "476813928857497601",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz alright, not cheaper- 0.026\/mo for the micros on RDS. Oh well. Will consider it if I get moretime.",
  "id" : 476813928857497601,
  "in_reply_to_status_id" : 476812786866323456,
  "created_at" : "2014-06-11 19:51:14 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476812178138607618",
  "geo" : { },
  "id_str" : "476812617734840320",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz also due to the dyno\/db split now, paying for a db doesn't keep your dyno alive. Lame.",
  "id" : 476812617734840320,
  "in_reply_to_status_id" : 476812178138607618,
  "created_at" : "2014-06-11 19:46:01 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476812178138607618",
  "geo" : { },
  "id_str" : "476812375291490304",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz seriously considering moving to RDS. Cheaper, same features.",
  "id" : 476812375291490304,
  "in_reply_to_status_id" : 476812178138607618,
  "created_at" : "2014-06-11 19:45:03 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "indices" : [ 0, 6 ],
      "id_str" : "24425454",
      "id" : 24425454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476811295602515971",
  "geo" : { },
  "id_str" : "476812018939224064",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgmnz not on hobby? :(",
  "id" : 476812018939224064,
  "in_reply_to_status_id" : 476811295602515971,
  "created_at" : "2014-06-11 19:43:38 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 0, 15 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 72, 87 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476162211132354560",
  "geo" : { },
  "id_str" : "476802993170284544",
  "in_reply_to_user_id" : 2262399740,
  "text" : "@ModelViewMedia yes! maybe an accessibility issue would be awesome. \/cc @AustinSeraphin",
  "id" : 476802993170284544,
  "in_reply_to_status_id" : 476162211132354560,
  "created_at" : "2014-06-11 19:07:46 +0000",
  "in_reply_to_screen_name" : "ModelViewMedia",
  "in_reply_to_user_id_str" : "2262399740",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 3, 18 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    }, {
      "name" : "Matt May",
      "screen_name" : "mattmay",
      "indices" : [ 76, 84 ],
      "id_str" : "2223571",
      "id" : 2223571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/PY2K9oA0fD",
      "expanded_url" : "http:\/\/modelviewculture.com\/pieces\/articulating-and-advocating-for-accessibility",
      "display_url" : "modelviewculture.com\/pieces\/articul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476802644464263169",
  "text" : "RT @ModelViewMedia: Advocating for accessibility: http:\/\/t.co\/PY2K9oA0fD by @mattmay. Includes strategies for working more effectively with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt May",
        "screen_name" : "mattmay",
        "indices" : [ 56, 64 ],
        "id_str" : "2223571",
        "id" : 2223571
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/PY2K9oA0fD",
        "expanded_url" : "http:\/\/modelviewculture.com\/pieces\/articulating-and-advocating-for-accessibility",
        "display_url" : "modelviewculture.com\/pieces\/articul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476162211132354560",
    "text" : "Advocating for accessibility: http:\/\/t.co\/PY2K9oA0fD by @mattmay. Includes strategies for working more effectively with engineering teams.",
    "id" : 476162211132354560,
    "created_at" : "2014-06-10 00:41:32 +0000",
    "user" : {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "protected" : false,
      "id_str" : "2262399740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422754620759236608\/hz-QJ1e4_normal.png",
      "id" : 2262399740,
      "verified" : false
    }
  },
  "id" : 476802644464263169,
  "created_at" : "2014-06-11 19:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 15, 29 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476785386799132672",
  "text" : "Proud of this: @coworkbuffalo is nearly full today of people we hadn't yet met when we founded the space 2 years ago. Coworking works.",
  "id" : 476785386799132672,
  "created_at" : "2014-06-11 17:57:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 3, 13 ],
      "id_str" : "21003240",
      "id" : 21003240
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 48, 58 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/4gxDmZTGDO",
      "expanded_url" : "http:\/\/tmblr.co\/ZOodfx1IPh0-M",
      "display_url" : "tmblr.co\/ZOodfx1IPh0-M"
    } ]
  },
  "geo" : { },
  "id_str" : "476744985241726976",
  "text" : "RT @BlockClub: The Distance - brought to you by @37signals tells the story of businesses that have been around 25+ years. http:\/\/t.co\/4gxDm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 33, 43 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/4gxDmZTGDO",
        "expanded_url" : "http:\/\/tmblr.co\/ZOodfx1IPh0-M",
        "display_url" : "tmblr.co\/ZOodfx1IPh0-M"
      } ]
    },
    "geo" : { },
    "id_str" : "476744655548465152",
    "text" : "The Distance - brought to you by @37signals tells the story of businesses that have been around 25+ years. http:\/\/t.co\/4gxDmZTGDO",
    "id" : 476744655548465152,
    "created_at" : "2014-06-11 15:15:58 +0000",
    "user" : {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "protected" : false,
      "id_str" : "21003240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1793193474\/bc_icon_normal.png",
      "id" : 21003240,
      "verified" : false
    }
  },
  "id" : 476744985241726976,
  "created_at" : "2014-06-11 15:17:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Ix3Icf7lzy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=a7jJnwEeiU0",
      "display_url" : "youtube.com\/watch?v=a7jJnw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "476731411022757889",
  "geo" : { },
  "id_str" : "476731534251012096",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier https:\/\/t.co\/Ix3Icf7lzy",
  "id" : 476731534251012096,
  "in_reply_to_status_id" : 476731411022757889,
  "created_at" : "2014-06-11 14:23:49 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zxqEJSDpoC",
      "expanded_url" : "http:\/\/kruggsmash.deviantart.com\/art\/The-Most-Awesome-Mayor-of-Ustomondul-428611240",
      "display_url" : "kruggsmash.deviantart.com\/art\/The-Most-A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476585537189330944",
  "text" : "Vampire mayors, giant moat traps, gruesome action. All in your typical Dwarf Fortress: http:\/\/t.co\/zxqEJSDpoC",
  "id" : 476585537189330944,
  "created_at" : "2014-06-11 04:43:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476574516890460160",
  "text" : "Relationship changing moment: realizing your partner once experimented with Dvorak and kept it secret.",
  "id" : 476574516890460160,
  "created_at" : "2014-06-11 03:59:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Run Like A Freezer",
      "screen_name" : "antelopeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "1639343491",
      "id" : 1639343491
    }, {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 42, 49 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476448659937439744",
  "geo" : { },
  "id_str" : "476449348109103104",
  "in_reply_to_user_id" : 1639343491,
  "text" : "@antelopeezer aaand stopping listening to @mkdevo's 2012 highlights and immediately needed to hear this.",
  "id" : 476449348109103104,
  "in_reply_to_status_id" : 476448659937439744,
  "created_at" : "2014-06-10 19:42:31 +0000",
  "in_reply_to_screen_name" : "antelopeezer",
  "in_reply_to_user_id_str" : "1639343491",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/gDiGbpw7Zo",
      "expanded_url" : "https:\/\/twitter.com\/NintendoAmerica\/status\/476402353172520961",
      "display_url" : "twitter.com\/NintendoAmeric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476409875161833473",
  "text" : "Mario Minecraft: https:\/\/t.co\/gDiGbpw7Zo",
  "id" : 476409875161833473,
  "created_at" : "2014-06-10 17:05:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476385768244801536",
  "geo" : { },
  "id_str" : "476387249001476096",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Gross, and a surface!?",
  "id" : 476387249001476096,
  "in_reply_to_status_id" : 476385768244801536,
  "created_at" : "2014-06-10 15:35:45 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Rusterholz",
      "screen_name" : "apeiros",
      "indices" : [ 0, 8 ],
      "id_str" : "69860704",
      "id" : 69860704
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/476382192218558468\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Pk9WiNZmd0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpxzFC_CIAAV_4m.png",
      "id_str" : "476382191132221440",
      "id" : 476382191132221440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpxzFC_CIAAV_4m.png",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1654
      } ],
      "display_url" : "pic.twitter.com\/Pk9WiNZmd0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476381862102044672",
  "geo" : { },
  "id_str" : "476382192218558468",
  "in_reply_to_user_id" : 69860704,
  "text" : "@apeiros http:\/\/t.co\/Pk9WiNZmd0",
  "id" : 476382192218558468,
  "in_reply_to_status_id" : 476381862102044672,
  "created_at" : "2014-06-10 15:15:40 +0000",
  "in_reply_to_screen_name" : "apeiros",
  "in_reply_to_user_id_str" : "69860704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/X5poVZzIR1",
      "expanded_url" : "https:\/\/www.google.com\/search?q=timer",
      "display_url" : "google.com\/search?q=timer"
    } ]
  },
  "geo" : { },
  "id_str" : "476380752859258881",
  "text" : "Neat, Google for \"timer\" and: https:\/\/t.co\/X5poVZzIR1",
  "id" : 476380752859258881,
  "created_at" : "2014-06-10 15:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/oKTnsLycJv",
      "expanded_url" : "http:\/\/mbtaviz.github.io\/",
      "display_url" : "mbtaviz.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "476377668179341313",
  "text" : "Beautiful d3 graphs and analysis of Boston's subway system. Make sure to hover over each diagram: http:\/\/t.co\/oKTnsLycJv",
  "id" : 476377668179341313,
  "created_at" : "2014-06-10 14:57:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 72, 86 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/476372528785412097\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/VR1w62j3Mm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpxqSluCQAAnIkv.jpg",
      "id_str" : "476372528189816832",
      "id" : 476372528189816832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpxqSluCQAAnIkv.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VR1w62j3Mm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915910822, -78.872418681 ]
  },
  "id_str" : "476372528785412097",
  "text" : "New sign going up on my bike ride into @coworkbuffalo this morning! \/cc @BuffaloRising http:\/\/t.co\/VR1w62j3Mm",
  "id" : 476372528785412097,
  "created_at" : "2014-06-10 14:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00E1bio Rehm",
      "screen_name" : "fgrehm",
      "indices" : [ 0, 7 ],
      "id_str" : "37705939",
      "id" : 37705939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476366892614316032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915910822, -78.872418681 ]
  },
  "id_str" : "476371999640395779",
  "in_reply_to_user_id" : 37705939,
  "text" : "@fgrehm yeah not sure, sorry",
  "id" : 476371999640395779,
  "in_reply_to_status_id" : 476366892614316032,
  "created_at" : "2014-06-10 14:35:09 +0000",
  "in_reply_to_screen_name" : "fgrehm",
  "in_reply_to_user_id_str" : "37705939",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240919394, -78.8793770878 ]
  },
  "id_str" : "476191540444819456",
  "text" : "Mario Kart 8\u2032s online multiplayer is flawless and you play people from across the world in real time. Mind\nblown.",
  "id" : 476191540444819456,
  "created_at" : "2014-06-10 02:38:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9242281756, -78.8791637868 ]
  },
  "id_str" : "476186802416386050",
  "text" : "Mario Kart and mojitos. \uD83D\uDE3E",
  "id" : 476186802416386050,
  "created_at" : "2014-06-10 02:19:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 0, 15 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 16, 30 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Samantha Nephew",
      "screen_name" : "snephew25",
      "indices" : [ 31, 41 ],
      "id_str" : "125562735",
      "id" : 125562735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476140733100212224",
  "geo" : { },
  "id_str" : "476166328902893568",
  "in_reply_to_user_id" : 73221502,
  "text" : "@ChristineLSloc @coworkbuffalo @snephew25 woot! I hope the space worked out great.",
  "id" : 476166328902893568,
  "in_reply_to_status_id" : 476140733100212224,
  "created_at" : "2014-06-10 00:57:54 +0000",
  "in_reply_to_screen_name" : "ChristineLSloc",
  "in_reply_to_user_id_str" : "73221502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/dDvOfR8SA7",
      "expanded_url" : "http:\/\/www.deadmalls.com\/stories.html",
      "display_url" : "deadmalls.com\/stories.html"
    } ]
  },
  "in_reply_to_status_id_str" : "476161914591248385",
  "geo" : { },
  "id_str" : "476162371501576193",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold Take your pick: http:\/\/t.co\/dDvOfR8SA7",
  "id" : 476162371501576193,
  "in_reply_to_status_id" : 476161914591248385,
  "created_at" : "2014-06-10 00:42:10 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476072302367371266",
  "text" : "OH \"plus it's the summer solstice so there's lots of mystical shit I gotta take care of\"",
  "id" : 476072302367371266,
  "created_at" : "2014-06-09 18:44:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476010525621768192",
  "geo" : { },
  "id_str" : "476014364307095553",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer I think I just need to squelch.",
  "id" : 476014364307095553,
  "in_reply_to_status_id" : 476010525621768192,
  "created_at" : "2014-06-09 14:54:03 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexsander Akers",
      "screen_name" : "a2",
      "indices" : [ 3, 6 ],
      "id_str" : "19876236",
      "id" : 19876236
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/a2\/status\/475644688347975680\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/KMdd9t7LzX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpnUUuaIYAA32xy.jpg",
      "id_str" : "475644688184401920",
      "id" : 475644688184401920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpnUUuaIYAA32xy.jpg",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KMdd9t7LzX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475995142151618561",
  "text" : "RT @a2: You can switch on NSIndexPaths using pattern matching. This is a beautiful thing. http:\/\/t.co\/KMdd9t7LzX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/a2\/status\/475644688347975680\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/KMdd9t7LzX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpnUUuaIYAA32xy.jpg",
        "id_str" : "475644688184401920",
        "id" : 475644688184401920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpnUUuaIYAA32xy.jpg",
        "sizes" : [ {
          "h" : 281,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KMdd9t7LzX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475644688347975680",
    "text" : "You can switch on NSIndexPaths using pattern matching. This is a beautiful thing. http:\/\/t.co\/KMdd9t7LzX",
    "id" : 475644688347975680,
    "created_at" : "2014-06-08 14:25:05 +0000",
    "user" : {
      "name" : "Alexsander Akers",
      "screen_name" : "a2",
      "protected" : false,
      "id_str" : "19876236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565467985067139073\/qA6vXNmJ_normal.png",
      "id" : 19876236,
      "verified" : false
    }
  },
  "id" : 475995142151618561,
  "created_at" : "2014-06-09 13:37:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475859921976569856",
  "geo" : { },
  "id_str" : "475862042968985601",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy it\u2019s awful. Well played not for me!",
  "id" : 475862042968985601,
  "in_reply_to_status_id" : 475859921976569856,
  "created_at" : "2014-06-09 04:48:46 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475859149272518656",
  "text" : "Worst part of Hearthstone: opponents congratulating themselves with a \u201CWell Played!\u201D emote as you are losing.",
  "id" : 475859149272518656,
  "created_at" : "2014-06-09 04:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Barnard",
      "screen_name" : "toddbarnard",
      "indices" : [ 0, 12 ],
      "id_str" : "13621",
      "id" : 13621
    }, {
      "name" : "Steve Pomeroy",
      "screen_name" : "xxv",
      "indices" : [ 13, 17 ],
      "id_str" : "7061802",
      "id" : 7061802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473613417517830144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930585094, -80.5591594151 ]
  },
  "id_str" : "475674566334099456",
  "in_reply_to_user_id" : 13621,
  "text" : "@toddbarnard @xxv how was this any different for objc?",
  "id" : 475674566334099456,
  "in_reply_to_status_id" : 473613417517830144,
  "created_at" : "2014-06-08 16:23:48 +0000",
  "in_reply_to_screen_name" : "toddbarnard",
  "in_reply_to_user_id_str" : "13621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Eldredge",
      "screen_name" : "jessabean",
      "indices" : [ 0, 10 ],
      "id_str" : "15735952",
      "id" : 15735952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475103292952182784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930727756, -80.5592485903 ]
  },
  "id_str" : "475659488989835264",
  "in_reply_to_user_id" : 15735952,
  "text" : "@jessabean don\u2019t try to pump your own gas either",
  "id" : 475659488989835264,
  "in_reply_to_status_id" : 475103292952182784,
  "created_at" : "2014-06-08 15:23:54 +0000",
  "in_reply_to_screen_name" : "jessabean",
  "in_reply_to_user_id_str" : "15735952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4yN71VyoUV",
      "expanded_url" : "http:\/\/i.imgur.com\/gUOu6ru.png",
      "display_url" : "i.imgur.com\/gUOu6ru.png"
    } ]
  },
  "geo" : { },
  "id_str" : "475649380092235776",
  "text" : "There are some awesome emoji in Facebook's set. Including some strange faces: http:\/\/t.co\/4yN71VyoUV",
  "id" : 475649380092235776,
  "created_at" : "2014-06-08 14:43:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7JzfiGPtzl",
      "expanded_url" : "http:\/\/www.rev.com\/",
      "display_url" : "rev.com"
    } ]
  },
  "geo" : { },
  "id_str" : "475647222814900224",
  "text" : "What other websites allow one to get paid for audio\/video transcription than http:\/\/t.co\/7JzfiGPtzl ?",
  "id" : 475647222814900224,
  "created_at" : "2014-06-08 14:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "indices" : [ 3, 18 ],
      "id_str" : "73221502",
      "id" : 73221502
    }, {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 79, 94 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CNU22",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/CPRSbbWGR6",
      "expanded_url" : "http:\/\/www.buffalonews.com\/columns\/colin-dabkowski\/an-open-letter-to-the-new-urbanist-movement-20140608",
      "display_url" : "buffalonews.com\/columns\/colin-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475640265014005760",
  "text" : "RT @ChristineLSloc: A very thoughtful, and urgent, critique of New Urbanism by @colindabkowski: http:\/\/t.co\/CPRSbbWGR6 #CNU22",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colindabkowski",
        "screen_name" : "colindabkowski",
        "indices" : [ 59, 74 ],
        "id_str" : "18777886",
        "id" : 18777886
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CNU22",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/CPRSbbWGR6",
        "expanded_url" : "http:\/\/www.buffalonews.com\/columns\/colin-dabkowski\/an-open-letter-to-the-new-urbanist-movement-20140608",
        "display_url" : "buffalonews.com\/columns\/colin-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "475633974350712832",
    "text" : "A very thoughtful, and urgent, critique of New Urbanism by @colindabkowski: http:\/\/t.co\/CPRSbbWGR6 #CNU22",
    "id" : 475633974350712832,
    "created_at" : "2014-06-08 13:42:30 +0000",
    "user" : {
      "name" : "Christine Slocum",
      "screen_name" : "ChristineLSloc",
      "protected" : false,
      "id_str" : "73221502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569953927438024704\/y_kM5xtD_normal.jpeg",
      "id" : 73221502,
      "verified" : false
    }
  },
  "id" : 475640265014005760,
  "created_at" : "2014-06-08 14:07:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475446859465388032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1930676803, -80.5593030073 ]
  },
  "id_str" : "475451457836417024",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy oof. We tried the Ferber book and it\u2019s worked amazing for 2+ weeks now. Didn\u2019t read it, just followed the schedule.",
  "id" : 475451457836417024,
  "in_reply_to_status_id" : 475446859465388032,
  "created_at" : "2014-06-08 01:37:15 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/egPlxPpcCK",
      "expanded_url" : "https:\/\/flic.kr\/p\/nVBYCX",
      "display_url" : "flic.kr\/p\/nVBYCX"
    } ]
  },
  "geo" : { },
  "id_str" : "475443984886554624",
  "text" : "I don't always take photos of cars. But when I do, they are awesome. https:\/\/t.co\/egPlxPpcCK",
  "id" : 475443984886554624,
  "created_at" : "2014-06-08 01:07:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 15, 24 ],
      "id_str" : "2998581",
      "id" : 2998581
    }, {
      "name" : "cheri marie ",
      "screen_name" : "cherimarie",
      "indices" : [ 25, 36 ],
      "id_str" : "783680210",
      "id" : 783680210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475051575946514432",
  "geo" : { },
  "id_str" : "475435519472857089",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @kerrizor @cherimarie well there is room for 5 in my car!",
  "id" : 475435519472857089,
  "in_reply_to_status_id" : 475051575946514432,
  "created_at" : "2014-06-08 00:33:55 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/waxpancake\/status\/475115530622222337\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/65GGtEJrtt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpfzDsJCIAAVNaG.jpg",
      "id_str" : "475115530425081856",
      "id" : 475115530425081856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpfzDsJCIAAVNaG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 906,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/65GGtEJrtt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475125550579986432",
  "text" : "RT @waxpancake: Does Banksy work for the TSA now? Spotted in line at JFK. http:\/\/t.co\/65GGtEJrtt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/waxpancake\/status\/475115530622222337\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/65GGtEJrtt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpfzDsJCIAAVNaG.jpg",
        "id_str" : "475115530425081856",
        "id" : 475115530425081856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpfzDsJCIAAVNaG.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 678
        } ],
        "display_url" : "pic.twitter.com\/65GGtEJrtt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475115530622222337",
    "text" : "Does Banksy work for the TSA now? Spotted in line at JFK. http:\/\/t.co\/65GGtEJrtt",
    "id" : 475115530622222337,
    "created_at" : "2014-06-07 03:22:24 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539845905889775616\/_tilXA5z_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 475125550579986432,
  "created_at" : "2014-06-07 04:02:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474948128827654144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9388900404, -78.8830295309 ]
  },
  "id_str" : "474949308530585600",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines honestly I miss it. Always fun to follow along with.",
  "id" : 474949308530585600,
  "in_reply_to_status_id" : 474948128827654144,
  "created_at" : "2014-06-06 16:21:53 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474945833364762624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9388900404, -78.8830295309 ]
  },
  "id_str" : "474947898384601088",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines definitely. Many classes and most events at RIT have them because of NTID. Remember lots of critiquing\/discussion.",
  "id" : 474947898384601088,
  "in_reply_to_status_id" : 474945833364762624,
  "created_at" : "2014-06-06 16:16:17 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Guy",
      "screen_name" : "thenickguy",
      "indices" : [ 0, 11 ],
      "id_str" : "12304192",
      "id" : 12304192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474935696860672000",
  "geo" : { },
  "id_str" : "474937019806670848",
  "in_reply_to_user_id" : 12304192,
  "text" : "@thenickguy It's going to help immensely.",
  "id" : 474937019806670848,
  "in_reply_to_status_id" : 474935696860672000,
  "created_at" : "2014-06-06 15:33:04 +0000",
  "in_reply_to_screen_name" : "thenickguy",
  "in_reply_to_user_id_str" : "12304192",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474935289593331712",
  "text" : "Just got tripped up on strong vs assign properties. I can't wait for Swift to not have to worry about this nonsense anymore.",
  "id" : 474935289593331712,
  "created_at" : "2014-06-06 15:26:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Y",
      "screen_name" : "andy_yarritu",
      "indices" : [ 0, 13 ],
      "id_str" : "1043384328",
      "id" : 1043384328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474929027308728320",
  "geo" : { },
  "id_str" : "474930640152825857",
  "in_reply_to_user_id" : 1043384328,
  "text" : "@andy_yarritu the whistles go WOOOO",
  "id" : 474930640152825857,
  "in_reply_to_status_id" : 474929027308728320,
  "created_at" : "2014-06-06 15:07:43 +0000",
  "in_reply_to_screen_name" : "andy_yarritu",
  "in_reply_to_user_id_str" : "1043384328",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 89, 103 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474925238481076224",
  "geo" : { },
  "id_str" : "474925876513996800",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Pretty sure that's outside of the Dinosaur BBQ in Buffalo! (Only a block from @coworkbuffalo too...)",
  "id" : 474925876513996800,
  "in_reply_to_status_id" : 474925238481076224,
  "created_at" : "2014-06-06 14:48:47 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 21, 33 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/EGsAqCSgZj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=x7YHjUm7XBI",
      "display_url" : "youtube.com\/watch?v=x7YHjU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474923173037629440",
  "text" : "Happy Friday. Here's @AqueousBand killing it on 12\/31\/13 in HD: https:\/\/t.co\/EGsAqCSgZj",
  "id" : 474923173037629440,
  "created_at" : "2014-06-06 14:38:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/474896400807755777\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eyYzaJLd4q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpcrwk_CcAAtkmF.jpg",
      "id_str" : "474896399272669184",
      "id" : 474896399272669184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpcrwk_CcAAtkmF.jpg",
      "sizes" : [ {
        "h" : 1520,
        "resize" : "fit",
        "w" : 2688
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eyYzaJLd4q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474896574900748288",
  "text" : "RT @coworkbuffalo: Happy National Doughnut Day, coworkers, from us and Mazurek's Bakery. We'll buy more if needed. http:\/\/t.co\/eyYzaJLd4q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/474896400807755777\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/eyYzaJLd4q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpcrwk_CcAAtkmF.jpg",
        "id_str" : "474896399272669184",
        "id" : 474896399272669184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpcrwk_CcAAtkmF.jpg",
        "sizes" : [ {
          "h" : 1520,
          "resize" : "fit",
          "w" : 2688
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eyYzaJLd4q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474896400807755777",
    "text" : "Happy National Doughnut Day, coworkers, from us and Mazurek's Bakery. We'll buy more if needed. http:\/\/t.co\/eyYzaJLd4q",
    "id" : 474896400807755777,
    "created_at" : "2014-06-06 12:51:39 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 474896574900748288,
  "created_at" : "2014-06-06 12:52:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240126778, -78.8790310622 ]
  },
  "id_str" : "474896514498560000",
  "text" : "New Pokemon episodes on Netflix. Not ashamed one bit.",
  "id" : 474896514498560000,
  "created_at" : "2014-06-06 12:52:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 0, 12 ],
      "id_str" : "13168222",
      "id" : 13168222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474875263596363776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9227793227, -78.8796820377 ]
  },
  "id_str" : "474878728309186560",
  "in_reply_to_user_id" : 13168222,
  "text" : "@mark_menard thankfully no.",
  "id" : 474878728309186560,
  "in_reply_to_status_id" : 474875263596363776,
  "created_at" : "2014-06-06 11:41:26 +0000",
  "in_reply_to_screen_name" : "mark_menard",
  "in_reply_to_user_id_str" : "13168222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/K0jO5SP9ri",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=LmwEIcLT35Y",
      "display_url" : "m.youtube.com\/watch?v=LmwEIc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243502999, -78.8790414111 ]
  },
  "id_str" : "474822117796491264",
  "text" : "EXTREME BRUTAL CURTAINS BEHIND MY\nEPIC DRUM KIT http:\/\/t.co\/K0jO5SP9ri",
  "id" : 474822117796491264,
  "created_at" : "2014-06-06 07:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9239253787, -78.879168595 ]
  },
  "id_str" : "474821906005512192",
  "text" : "Baby screaming goes great with death metal drumming.",
  "id" : 474821906005512192,
  "created_at" : "2014-06-06 07:55:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AQnet",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "erie",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5L5fGNvwLY",
      "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-03-15",
      "display_url" : "aqueousband.net\/shows\/2014-03-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474766421470093312",
  "text" : "RT @UnclePhilsBlog: #AQnet update: 2014-03-15 matrix for final show at crooked I #erie uploaded. A+ show, set aside 3 hours and enjoy. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AQnet",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "erie",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5L5fGNvwLY",
        "expanded_url" : "http:\/\/aqueousband.net\/shows\/2014-03-15",
        "display_url" : "aqueousband.net\/shows\/2014-03-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474631595459366912",
    "text" : "#AQnet update: 2014-03-15 matrix for final show at crooked I #erie uploaded. A+ show, set aside 3 hours and enjoy. http:\/\/t.co\/5L5fGNvwLY",
    "id" : 474631595459366912,
    "created_at" : "2014-06-05 19:19:25 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 474766421470093312,
  "created_at" : "2014-06-06 04:15:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243808255, -78.8793951576 ]
  },
  "id_str" : "474760778189258752",
  "text" : "Lesson learned: mojitos without limes do not a mojito make.",
  "id" : 474760778189258752,
  "created_at" : "2014-06-06 03:52:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 3, 10 ],
      "id_str" : "70702180",
      "id" : 70702180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U1vVGX8avv",
      "expanded_url" : "http:\/\/youtu.be\/co9BY6ZyQvA",
      "display_url" : "youtu.be\/co9BY6ZyQvA"
    } ]
  },
  "geo" : { },
  "id_str" : "474743427498659841",
  "text" : "RT @cubosh: live guitarists: its a VERY good idea to grab someone's camera while its taking video and playing your guitar with it http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/U1vVGX8avv",
        "expanded_url" : "http:\/\/youtu.be\/co9BY6ZyQvA",
        "display_url" : "youtu.be\/co9BY6ZyQvA"
      } ]
    },
    "geo" : { },
    "id_str" : "474742504567222272",
    "text" : "live guitarists: its a VERY good idea to grab someone's camera while its taking video and playing your guitar with it http:\/\/t.co\/U1vVGX8avv",
    "id" : 474742504567222272,
    "created_at" : "2014-06-06 02:40:08 +0000",
    "user" : {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "protected" : false,
      "id_str" : "70702180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2087171778\/RGB_normal.png",
      "id" : 70702180,
      "verified" : false
    }
  },
  "id" : 474743427498659841,
  "created_at" : "2014-06-06 02:43:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/474675790588944385\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/WaCEVxyqQP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZjHcNIMAElWTs.png",
      "id_str" : "474675790215655425",
      "id" : 474675790215655425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZjHcNIMAElWTs.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 993
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 993
      } ],
      "display_url" : "pic.twitter.com\/WaCEVxyqQP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ybOEDPsIKa",
      "expanded_url" : "http:\/\/vox.com\/e\/5546513",
      "display_url" : "vox.com\/e\/5546513"
    } ]
  },
  "geo" : { },
  "id_str" : "474678018326429696",
  "text" : "RT @voxdotcom: Study: Bike lanes really do increase biking http:\/\/t.co\/ybOEDPsIKa http:\/\/t.co\/WaCEVxyqQP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/474675790588944385\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/WaCEVxyqQP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZjHcNIMAElWTs.png",
        "id_str" : "474675790215655425",
        "id" : 474675790215655425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZjHcNIMAElWTs.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 993
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 993
        } ],
        "display_url" : "pic.twitter.com\/WaCEVxyqQP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/ybOEDPsIKa",
        "expanded_url" : "http:\/\/vox.com\/e\/5546513",
        "display_url" : "vox.com\/e\/5546513"
      } ]
    },
    "geo" : { },
    "id_str" : "474675790588944385",
    "text" : "Study: Bike lanes really do increase biking http:\/\/t.co\/ybOEDPsIKa http:\/\/t.co\/WaCEVxyqQP",
    "id" : 474675790588944385,
    "created_at" : "2014-06-05 22:15:02 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 474678018326429696,
  "created_at" : "2014-06-05 22:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Eichert",
      "screen_name" : "steveeichert",
      "indices" : [ 0, 13 ],
      "id_str" : "8126672",
      "id" : 8126672
    }, {
      "name" : "Lauren Orsini",
      "screen_name" : "laureninspace",
      "indices" : [ 14, 28 ],
      "id_str" : "18278364",
      "id" : 18278364
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 65, 69 ],
      "id_str" : "10452222",
      "id" : 10452222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474634740956295169",
  "geo" : { },
  "id_str" : "474636850624086016",
  "in_reply_to_user_id" : 8126672,
  "text" : "@steveeichert @laureninspace that's completely inaccurate. Maybe @lrz can help correct you this?",
  "id" : 474636850624086016,
  "in_reply_to_status_id" : 474634740956295169,
  "created_at" : "2014-06-05 19:40:18 +0000",
  "in_reply_to_screen_name" : "steveeichert",
  "in_reply_to_user_id_str" : "8126672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Connors",
      "screen_name" : "BfloBiz_SeanC",
      "indices" : [ 0, 14 ],
      "id_str" : "989238870",
      "id" : 989238870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474626557538238464",
  "geo" : { },
  "id_str" : "474627013383172096",
  "in_reply_to_user_id" : 989238870,
  "text" : "@BfloBiz_SeanC yeah...not a festival guy here either. Although I am hoping to pop into Buffalove just to see Aqueous play :)",
  "id" : 474627013383172096,
  "in_reply_to_status_id" : 474626557538238464,
  "created_at" : "2014-06-05 19:01:12 +0000",
  "in_reply_to_screen_name" : "BfloBiz_SeanC",
  "in_reply_to_user_id_str" : "989238870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/hMVTOfVWxB",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=oJRlPW7u2lA&feature=kp",
      "display_url" : "youtube.com\/watch?v=oJRlPW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474625741510828032",
  "text" : "BRB listening to every rendition of Spine of a Dog, ever, because it's downright goofy and fun. https:\/\/t.co\/hMVTOfVWxB",
  "id" : 474625741510828032,
  "created_at" : "2014-06-05 18:56:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "indices" : [ 3, 13 ],
      "id_str" : "14620798",
      "id" : 14620798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474619202980962304",
  "text" : "RT @zachwaugh: There should be a colonial Williamsburg Brooklyn, where you can you see re-enactments of how the hipsters of yore lived.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474618895945330688",
    "text" : "There should be a colonial Williamsburg Brooklyn, where you can you see re-enactments of how the hipsters of yore lived.",
    "id" : 474618895945330688,
    "created_at" : "2014-06-05 18:28:57 +0000",
    "user" : {
      "name" : "Zach Waugh",
      "screen_name" : "zachwaugh",
      "protected" : false,
      "id_str" : "14620798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549681852332535809\/TzOXTBNx_normal.jpeg",
      "id" : 14620798,
      "verified" : false
    }
  },
  "id" : 474619202980962304,
  "created_at" : "2014-06-05 18:30:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 3, 18 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    }, {
      "name" : "BreadHive",
      "screen_name" : "BreadHive",
      "indices" : [ 40, 50 ],
      "id_str" : "816041347",
      "id" : 816041347
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/474595606296793088\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rpcWbt69cY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYaMB_IYAAWWN1.png",
      "id_str" : "474595604728143872",
      "id" : 474595604728143872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYaMB_IYAAWWN1.png",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 535
      } ],
      "display_url" : "pic.twitter.com\/rpcWbt69cY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2jnyUMzVOY",
      "expanded_url" : "http:\/\/www.publicespresso.com\/products\/public-offering-coffee-share",
      "display_url" : "publicespresso.com\/products\/publi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474596307357548544",
  "text" : "RT @PublicEspresso: We have paired with @BreadHive to launch our coffee share program, Public Offering! Info here: http:\/\/t.co\/2jnyUMzVOY h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BreadHive",
        "screen_name" : "BreadHive",
        "indices" : [ 20, 30 ],
        "id_str" : "816041347",
        "id" : 816041347
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PublicEspresso\/status\/474595606296793088\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rpcWbt69cY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYaMB_IYAAWWN1.png",
        "id_str" : "474595604728143872",
        "id" : 474595604728143872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYaMB_IYAAWWN1.png",
        "sizes" : [ {
          "h" : 508,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 535
        } ],
        "display_url" : "pic.twitter.com\/rpcWbt69cY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/2jnyUMzVOY",
        "expanded_url" : "http:\/\/www.publicespresso.com\/products\/public-offering-coffee-share",
        "display_url" : "publicespresso.com\/products\/publi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474595606296793088",
    "text" : "We have paired with @BreadHive to launch our coffee share program, Public Offering! Info here: http:\/\/t.co\/2jnyUMzVOY http:\/\/t.co\/rpcWbt69cY",
    "id" : 474595606296793088,
    "created_at" : "2014-06-05 16:56:24 +0000",
    "user" : {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "protected" : false,
      "id_str" : "1472209542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550509321445191680\/PwiO5VPn_normal.jpeg",
      "id" : 1472209542,
      "verified" : false
    }
  },
  "id" : 474596307357548544,
  "created_at" : "2014-06-05 16:59:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Fox",
      "screen_name" : "pamelafox",
      "indices" : [ 3, 13 ],
      "id_str" : "10483202",
      "id" : 10483202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoScaredRightNow",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/UvvDk1p8Qr",
      "expanded_url" : "http:\/\/www.sewingandembroiderywarehouse.com\/embtrb.htm",
      "display_url" : "sewingandembroiderywarehouse.com\/embtrb.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "474399863212240896",
  "text" : "RT @pamelafox: \"Unclosed HTML tags accidentally lead to an accelerating surrealist nightmare\" http:\/\/t.co\/UvvDk1p8Qr #SoScaredRightNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoScaredRightNow",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/UvvDk1p8Qr",
        "expanded_url" : "http:\/\/www.sewingandembroiderywarehouse.com\/embtrb.htm",
        "display_url" : "sewingandembroiderywarehouse.com\/embtrb.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "448275897674907648",
    "text" : "\"Unclosed HTML tags accidentally lead to an accelerating surrealist nightmare\" http:\/\/t.co\/UvvDk1p8Qr #SoScaredRightNow",
    "id" : 448275897674907648,
    "created_at" : "2014-03-25 01:51:17 +0000",
    "user" : {
      "name" : "Pamela Fox",
      "screen_name" : "pamelafox",
      "protected" : false,
      "id_str" : "10483202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458674563044233216\/Rya_AmpS_normal.jpeg",
      "id" : 10483202,
      "verified" : false
    }
  },
  "id" : 474399863212240896,
  "created_at" : "2014-06-05 03:58:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 19, 30 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/474334838104014849\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/MkCbymPkz6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpUtBZ5IUAAQ8KT.png",
      "id_str" : "474334837911080960",
      "id" : 474334837911080960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpUtBZ5IUAAQ8KT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MkCbymPkz6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924056555, -78.8794019624 ]
  },
  "id_str" : "474334838104014849",
  "text" : "It\u2019s not every day @kevinpurdy is a push notification. http:\/\/t.co\/MkCbymPkz6",
  "id" : 474334838104014849,
  "created_at" : "2014-06-04 23:40:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/VyqP6Sft7f",
      "expanded_url" : "https:\/\/www.swarmapp.com\/qrush\/checkin\/538f9559498e342e16405b9d?s=qt_sgHcnCgbpRvaRhJR8dy5F__4&ref=tw",
      "display_url" : "swarmapp.com\/qrush\/checkin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9355740057, -78.8776541754 ]
  },
  "id_str" : "474308012094795776",
  "text" : "First 2014 rodeo! (@ Food Truck Rodeo) https:\/\/t.co\/VyqP6Sft7f",
  "id" : 474308012094795776,
  "created_at" : "2014-06-04 21:53:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/afUlw31ejh",
      "expanded_url" : "http:\/\/www.iwantcovers.com\/wp-content\/uploads\/2012\/03\/Cool-Dog.jpg",
      "display_url" : "iwantcovers.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474255231207759872",
  "text" : "Current status: http:\/\/t.co\/afUlw31ejh",
  "id" : 474255231207759872,
  "created_at" : "2014-06-04 18:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474217791491305473",
  "geo" : { },
  "id_str" : "474221639429672960",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Yep. Trying to just maintain some level of criticism when most devs just blindly accept it. Removing the NDA is a good sign.",
  "id" : 474221639429672960,
  "in_reply_to_status_id" : 474217791491305473,
  "created_at" : "2014-06-04 16:10:24 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474216351683190784",
  "geo" : { },
  "id_str" : "474217570413707267",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza this closed culture bothers me. It's only valued because it's the only way to communicate. Doesn't that feel slightly broken?",
  "id" : 474217570413707267,
  "in_reply_to_status_id" : 474216351683190784,
  "created_at" : "2014-06-04 15:54:13 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474213131527286786",
  "geo" : { },
  "id_str" : "474213494120673281",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza this right here is why I don't want to attend a WWDC. Why is this valued?",
  "id" : 474213494120673281,
  "in_reply_to_status_id" : 474213131527286786,
  "created_at" : "2014-06-04 15:38:02 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "PublicEspresso",
      "screen_name" : "PublicEspresso",
      "indices" : [ 28, 43 ],
      "id_str" : "1472209542",
      "id" : 1472209542
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/474206199299452930\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/LUjYKz4Iwb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpS4BoNIUAAGbvD.jpg",
      "id_str" : "474206198892613632",
      "id" : 474206198892613632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpS4BoNIUAAGbvD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LUjYKz4Iwb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474206332652777473",
  "text" : "RT @coworkbuffalo: Today is @PublicEspresso delivery day. Today is a good day. http:\/\/t.co\/LUjYKz4Iwb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PublicEspresso",
        "screen_name" : "PublicEspresso",
        "indices" : [ 9, 24 ],
        "id_str" : "1472209542",
        "id" : 1472209542
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/474206199299452930\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/LUjYKz4Iwb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpS4BoNIUAAGbvD.jpg",
        "id_str" : "474206198892613632",
        "id" : 474206198892613632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpS4BoNIUAAGbvD.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LUjYKz4Iwb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474206199299452930",
    "text" : "Today is @PublicEspresso delivery day. Today is a good day. http:\/\/t.co\/LUjYKz4Iwb",
    "id" : 474206199299452930,
    "created_at" : "2014-06-04 15:09:02 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 474206332652777473,
  "created_at" : "2014-06-04 15:09:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Fernandes",
      "screen_name" : "zackfern",
      "indices" : [ 0, 9 ],
      "id_str" : "261945610",
      "id" : 261945610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474203939953324032",
  "geo" : { },
  "id_str" : "474204389092376576",
  "in_reply_to_user_id" : 261945610,
  "text" : "@zackfern Weak. I did have an (unlocked) bike stolen off my porch 2 years ago. Don't think SF is the only city with crime!",
  "id" : 474204389092376576,
  "in_reply_to_status_id" : 474203939953324032,
  "created_at" : "2014-06-04 15:01:51 +0000",
  "in_reply_to_screen_name" : "zackfern",
  "in_reply_to_user_id_str" : "261945610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Fernandes",
      "screen_name" : "zackfern",
      "indices" : [ 0, 9 ],
      "id_str" : "261945610",
      "id" : 261945610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474203101918806016",
  "geo" : { },
  "id_str" : "474203285193097216",
  "in_reply_to_user_id" : 261945610,
  "text" : "@zackfern they're indoors?",
  "id" : 474203285193097216,
  "in_reply_to_status_id" : 474203101918806016,
  "created_at" : "2014-06-04 14:57:28 +0000",
  "in_reply_to_screen_name" : "zackfern",
  "in_reply_to_user_id_str" : "261945610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/IvlouKELAM",
      "expanded_url" : "https:\/\/twitter.com\/LolaSikes\/status\/473949034319581186",
      "display_url" : "twitter.com\/LolaSikes\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915883526, -78.8720314609 ]
  },
  "id_str" : "474192620889980930",
  "text" : "Some of my Rochester friends need to see BRACO. No pregnant friends though. https:\/\/t.co\/IvlouKELAM",
  "id" : 474192620889980930,
  "created_at" : "2014-06-04 14:15:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/474191349118287873\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/iyJysykCq2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpSqhO_CYAAEClv.jpg",
      "id_str" : "474191348715642880",
      "id" : 474191348715642880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpSqhO_CYAAEClv.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iyJysykCq2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8915883526, -78.8720314609 ]
  },
  "id_str" : "474191349118287873",
  "text" : "Bike commuting for most members today @coworkbuffalo! http:\/\/t.co\/iyJysykCq2",
  "id" : 474191349118287873,
  "created_at" : "2014-06-04 14:10:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 3, 14 ],
      "id_str" : "137891464",
      "id" : 137891464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474164428070350848",
  "text" : "RT @nickelcity: Alright, a video from Buffalo is the top post on Reddit! Oh dear God, no, no, no, no, no, no.....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474163834031448064",
    "text" : "Alright, a video from Buffalo is the top post on Reddit! Oh dear God, no, no, no, no, no, no.....",
    "id" : 474163834031448064,
    "created_at" : "2014-06-04 12:20:42 +0000",
    "user" : {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "protected" : false,
      "id_str" : "137891464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541312075570491395\/PrAOKda4_normal.jpeg",
      "id" : 137891464,
      "verified" : false
    }
  },
  "id" : 474164428070350848,
  "created_at" : "2014-06-04 12:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 60, 75 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/EzQBp9nJZZ",
      "expanded_url" : "http:\/\/www.designsponge.com\/2014\/06\/24-hours-in-buffalo-with-chris-hawley.html",
      "display_url" : "designsponge.com\/2014\/06\/24-hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474157291092987904",
  "text" : "A great guide to Buffalo if you're considering visiting for @nickelcityruby: http:\/\/t.co\/EzQBp9nJZZ",
  "id" : 474157291092987904,
  "created_at" : "2014-06-04 11:54:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 3, 8 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/popo\/status\/474137332350984192\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/gzQUfwWczc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpR5YwGCIAAcecB.jpg",
      "id_str" : "474137326914772992",
      "id" : 474137326914772992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpR5YwGCIAAcecB.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/gzQUfwWczc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/vvxrhdfjDC",
      "expanded_url" : "http:\/\/www.designsponge.com\/2014\/06\/24-hours-in-buffalo-with-chris-hawley.html",
      "display_url" : "designsponge.com\/2014\/06\/24-hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474148650612830209",
  "text" : "RT @popo: 24 Hours In Buffalo http:\/\/t.co\/vvxrhdfjDC http:\/\/t.co\/gzQUfwWczc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/popo\/status\/474137332350984192\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/gzQUfwWczc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpR5YwGCIAAcecB.jpg",
        "id_str" : "474137326914772992",
        "id" : 474137326914772992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpR5YwGCIAAcecB.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/gzQUfwWczc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/vvxrhdfjDC",
        "expanded_url" : "http:\/\/www.designsponge.com\/2014\/06\/24-hours-in-buffalo-with-chris-hawley.html",
        "display_url" : "designsponge.com\/2014\/06\/24-hou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474137332350984192",
    "text" : "24 Hours In Buffalo http:\/\/t.co\/vvxrhdfjDC http:\/\/t.co\/gzQUfwWczc",
    "id" : 474137332350984192,
    "created_at" : "2014-06-04 10:35:23 +0000",
    "user" : {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "protected" : false,
      "id_str" : "2247381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000130437906\/b3f515a0057bb42812f2f71048b49d26_normal.jpeg",
      "id" : 2247381,
      "verified" : false
    }
  },
  "id" : 474148650612830209,
  "created_at" : "2014-06-04 11:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lolabelle",
      "screen_name" : "LolaSikes",
      "indices" : [ 3, 13 ],
      "id_str" : "634268080",
      "id" : 634268080
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LolaSikes\/status\/473949034319581186\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/EEZSKgwBXE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpPOIoBCcAEpvi1.jpg",
      "id_str" : "473949033380081665",
      "id" : 473949033380081665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpPOIoBCcAEpvi1.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EEZSKgwBXE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474056652094586880",
  "text" : "RT @LolaSikes: If u wanna get gazed at by this guy, it'll cost you $8. No pregnant women. http:\/\/t.co\/EEZSKgwBXE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LolaSikes\/status\/473949034319581186\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/EEZSKgwBXE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpPOIoBCcAEpvi1.jpg",
        "id_str" : "473949033380081665",
        "id" : 473949033380081665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpPOIoBCcAEpvi1.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EEZSKgwBXE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473949034319581186",
    "text" : "If u wanna get gazed at by this guy, it'll cost you $8. No pregnant women. http:\/\/t.co\/EEZSKgwBXE",
    "id" : 473949034319581186,
    "created_at" : "2014-06-03 22:07:09 +0000",
    "user" : {
      "name" : "Lolabelle",
      "screen_name" : "LolaSikes",
      "protected" : false,
      "id_str" : "634268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569650290413285376\/kcFhNHeT_normal.jpeg",
      "id" : 634268080,
      "verified" : false
    }
  },
  "id" : 474056652094586880,
  "created_at" : "2014-06-04 05:14:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/474032026572435456\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/9uEYefIlX4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpQZncrCIAEChCV.png",
      "id_str" : "474032026283024385",
      "id" : 474032026283024385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpQZncrCIAEChCV.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9uEYefIlX4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/54xfGdw6ye",
      "expanded_url" : "http:\/\/fuckingblocksyntax.com",
      "display_url" : "fuckingblocksyntax.com"
    } ]
  },
  "geo" : { },
  "id_str" : "474032026572435456",
  "text" : "And finally, death to http:\/\/t.co\/54xfGdw6ye http:\/\/t.co\/9uEYefIlX4",
  "id" : 474032026572435456,
  "created_at" : "2014-06-04 03:36:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 0, 6 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/YY8iBqcpbr",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/wwdc\/id640199958?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/wwdc\/id\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "474026299120308226",
  "geo" : { },
  "id_str" : "474029999691808768",
  "in_reply_to_user_id" : 1679,
  "text" : "@javan dev center online or via the app: https:\/\/t.co\/YY8iBqcpbr",
  "id" : 474029999691808768,
  "in_reply_to_status_id" : 474026299120308226,
  "created_at" : "2014-06-04 03:28:53 +0000",
  "in_reply_to_screen_name" : "javan",
  "in_reply_to_user_id_str" : "1679",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474024334739005440",
  "text" : "@juliepagano \u201Cweb notifications\u201D in the settings",
  "id" : 474024334739005440,
  "created_at" : "2014-06-04 03:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474023796731412483",
  "text" : "Only 15 minutes into the Intro to Swift talk and been breathing huge sighs of relief. This is so, so much better.",
  "id" : 474023796731412483,
  "created_at" : "2014-06-04 03:04:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473989670536097793",
  "text" : "Basically, if you have a tiled grainy diagram of middle ages trepanning for your Twitter background, you earn my follow.",
  "id" : 473989670536097793,
  "created_at" : "2014-06-04 00:48:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinybaby",
      "screen_name" : "tinybaby",
      "indices" : [ 0, 9 ],
      "id_str" : "15946976",
      "id" : 15946976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473989189822734336",
  "geo" : { },
  "id_str" : "473989530135977984",
  "in_reply_to_user_id" : 15946976,
  "text" : "@tinybaby SOLVED",
  "id" : 473989530135977984,
  "in_reply_to_status_id" : 473989189822734336,
  "created_at" : "2014-06-04 00:48:04 +0000",
  "in_reply_to_screen_name" : "tinybaby",
  "in_reply_to_user_id_str" : "15946976",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Machell",
      "screen_name" : "ben_machell",
      "indices" : [ 3, 15 ],
      "id_str" : "336028534",
      "id" : 336028534
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ben_machell\/status\/473574054520438786\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/RIlpppJ9ua",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJ5F0eIUAEhCzK.jpg",
      "id_str" : "473574051718647809",
      "id" : 473574051718647809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJ5F0eIUAEhCzK.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RIlpppJ9ua"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473988831616593920",
  "text" : "RT @ben_machell: Text from my dad earlier on http:\/\/t.co\/RIlpppJ9ua",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ben_machell\/status\/473574054520438786\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/RIlpppJ9ua",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJ5F0eIUAEhCzK.jpg",
        "id_str" : "473574051718647809",
        "id" : 473574051718647809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJ5F0eIUAEhCzK.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/RIlpppJ9ua"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473574054520438786",
    "text" : "Text from my dad earlier on http:\/\/t.co\/RIlpppJ9ua",
    "id" : 473574054520438786,
    "created_at" : "2014-06-02 21:17:07 +0000",
    "user" : {
      "name" : "Ben Machell",
      "screen_name" : "ben_machell",
      "protected" : false,
      "id_str" : "336028534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552066088180404224\/vVVcY50s_normal.jpeg",
      "id" : 336028534,
      "verified" : true
    }
  },
  "id" : 473988831616593920,
  "created_at" : "2014-06-04 00:45:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler S Gordon",
      "screen_name" : "TylerSGordon",
      "indices" : [ 0, 13 ],
      "id_str" : "1643585485",
      "id" : 1643585485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473963635434221568",
  "geo" : { },
  "id_str" : "473970491837804545",
  "in_reply_to_user_id" : 1643585485,
  "text" : "@TylerSGordon it's a new web view.",
  "id" : 473970491837804545,
  "in_reply_to_status_id" : 473963635434221568,
  "created_at" : "2014-06-03 23:32:25 +0000",
  "in_reply_to_screen_name" : "TylerSGordon",
  "in_reply_to_user_id_str" : "1643585485",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 3, 11 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jeresig\/status\/473816578040279040\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/4Th5Hp7wux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpNVqqtIgAA_LXc.png",
      "id_str" : "473816577310490624",
      "id" : 473816577310490624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpNVqqtIgAA_LXc.png",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4Th5Hp7wux"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/h7TcjCs05V",
      "expanded_url" : "http:\/\/explore.org\/live-cams\/player\/brown-bear-salmon-cam-brooks-falls",
      "display_url" : "explore.org\/live-cams\/play\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473889300933668864",
  "text" : "RT @jeresig: Watch brown bears attempt to catch salmon in Alaska, live: http:\/\/t.co\/h7TcjCs05V http:\/\/t.co\/4Th5Hp7wux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jeresig\/status\/473816578040279040\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/4Th5Hp7wux",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpNVqqtIgAA_LXc.png",
        "id_str" : "473816577310490624",
        "id" : 473816577310490624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpNVqqtIgAA_LXc.png",
        "sizes" : [ {
          "h" : 244,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4Th5Hp7wux"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/h7TcjCs05V",
        "expanded_url" : "http:\/\/explore.org\/live-cams\/player\/brown-bear-salmon-cam-brooks-falls",
        "display_url" : "explore.org\/live-cams\/play\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473816578040279040",
    "text" : "Watch brown bears attempt to catch salmon in Alaska, live: http:\/\/t.co\/h7TcjCs05V http:\/\/t.co\/4Th5Hp7wux",
    "id" : 473816578040279040,
    "created_at" : "2014-06-03 13:20:49 +0000",
    "user" : {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "protected" : false,
      "id_str" : "752673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453551474711097345\/tXmNE9Cj_normal.jpeg",
      "id" : 752673,
      "verified" : true
    }
  },
  "id" : 473889300933668864,
  "created_at" : "2014-06-03 18:09:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 3, 10 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473879289482321920",
  "text" : "RT @mwhuss: Every single code example during presentations have been in swift.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473879012821827584",
    "text" : "Every single code example during presentations have been in swift.",
    "id" : 473879012821827584,
    "created_at" : "2014-06-03 17:28:55 +0000",
    "user" : {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "protected" : false,
      "id_str" : "4235881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489787952923295744\/8OxRFdPI_normal.jpeg",
      "id" : 4235881,
      "verified" : false
    }
  },
  "id" : 473879289482321920,
  "created_at" : "2014-06-03 17:30:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Sandora-Nastyn",
      "screen_name" : "PatSandora",
      "indices" : [ 0, 11 ],
      "id_str" : "21421691",
      "id" : 21421691
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 25, 39 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473858905291128832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8908666505, -78.8764983006 ]
  },
  "id_str" : "473865562368782336",
  "in_reply_to_user_id" : 21421691,
  "text" : "@PatSandora so what does @coworkbuffalo\u2019s Chemex make us?",
  "id" : 473865562368782336,
  "in_reply_to_status_id" : 473858905291128832,
  "created_at" : "2014-06-03 16:35:28 +0000",
  "in_reply_to_screen_name" : "PatSandora",
  "in_reply_to_user_id_str" : "21421691",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 0, 14 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473855336068415488",
  "geo" : { },
  "id_str" : "473855747004960768",
  "in_reply_to_user_id" : 45490102,
  "text" : "@markpoloncarz looks awesome! Congrats!!",
  "id" : 473855747004960768,
  "in_reply_to_status_id" : 473855336068415488,
  "created_at" : "2014-06-03 15:56:28 +0000",
  "in_reply_to_screen_name" : "markpoloncarz",
  "in_reply_to_user_id_str" : "45490102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "indices" : [ 3, 17 ],
      "id_str" : "45490102",
      "id" : 45490102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/473855336068415488\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wbdKIkNq5F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpN46qaCQAAdVe5.jpg",
      "id_str" : "473855335015268352",
      "id" : 473855335015268352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpN46qaCQAAdVe5.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wbdKIkNq5F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473855716826947584",
  "text" : "RT @markpoloncarz: Today I met the students from the Buffalo Academy of Science Robotic Team who won the Best Robot Middle School Award. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/markpoloncarz\/status\/473855336068415488\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wbdKIkNq5F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpN46qaCQAAdVe5.jpg",
        "id_str" : "473855335015268352",
        "id" : 473855335015268352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpN46qaCQAAdVe5.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wbdKIkNq5F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473855336068415488",
    "text" : "Today I met the students from the Buffalo Academy of Science Robotic Team who won the Best Robot Middle School Award. http:\/\/t.co\/wbdKIkNq5F",
    "id" : 473855336068415488,
    "created_at" : "2014-06-03 15:54:50 +0000",
    "user" : {
      "name" : "Mark Poloncarz",
      "screen_name" : "markpoloncarz",
      "protected" : false,
      "id_str" : "45490102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572114131579179008\/EAk-fMOk_normal.jpeg",
      "id" : 45490102,
      "verified" : false
    }
  },
  "id" : 473855716826947584,
  "created_at" : "2014-06-03 15:56:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Park",
      "screen_name" : "timpark",
      "indices" : [ 0, 8 ],
      "id_str" : "14382736",
      "id" : 14382736
    }, {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 9, 16 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473850627219394560",
  "geo" : { },
  "id_str" : "473852544020533248",
  "in_reply_to_user_id" : 14382736,
  "text" : "@timpark @mikeal Does the number for NPM count uniquely named packages, or versions of each?",
  "id" : 473852544020533248,
  "in_reply_to_status_id" : 473850627219394560,
  "created_at" : "2014-06-03 15:43:44 +0000",
  "in_reply_to_screen_name" : "timpark",
  "in_reply_to_user_id_str" : "14382736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 72, 81 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/XqaeacPBvR",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/16807",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473850784921026561",
  "text" : "RT @zobar2: First Tuesday of the month! When I hack, you hack, we hack. @openhack http:\/\/t.co\/XqaeacPBvR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 60, 69 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/XqaeacPBvR",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/16807",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473849730137878528",
    "text" : "First Tuesday of the month! When I hack, you hack, we hack. @openhack http:\/\/t.co\/XqaeacPBvR",
    "id" : 473849730137878528,
    "created_at" : "2014-06-03 15:32:34 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 473850784921026561,
  "created_at" : "2014-06-03 15:36:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/p1dm5bbHLv",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Wm3usxOu-yk",
      "display_url" : "youtube.com\/watch?v=Wm3usx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473837419913940992",
  "text" : "The Luigi death stare videos makes me hope Nintendo has figured it out. What if Zelda or Metroid was shareable? https:\/\/t.co\/p1dm5bbHLv",
  "id" : 473837419913940992,
  "created_at" : "2014-06-03 14:43:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/XSSmmXybiZ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/LuigiDeathStares",
      "display_url" : "reddit.com\/r\/LuigiDeathSt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473835047850491904",
  "text" : "New favorite subreddit: http:\/\/t.co\/XSSmmXybiZ",
  "id" : 473835047850491904,
  "created_at" : "2014-06-03 14:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473662264378011648",
  "geo" : { },
  "id_str" : "473662398641872896",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv no idea! Cool idea though.",
  "id" : 473662398641872896,
  "in_reply_to_status_id" : 473662264378011648,
  "created_at" : "2014-06-03 03:08:10 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Giles",
      "screen_name" : "BeauGiles",
      "indices" : [ 3, 13 ],
      "id_str" : "7636802",
      "id" : 7636802
    }, {
      "name" : "TestFlight",
      "screen_name" : "testflightapp",
      "indices" : [ 21, 35 ],
      "id_str" : "158117892",
      "id" : 158117892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/M4MPk64nZE",
      "expanded_url" : "https:\/\/developer.apple.com\/support\/appstore\/TestFlight\/index.php",
      "display_url" : "developer.apple.com\/support\/appsto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473662023297810432",
  "text" : "RT @BeauGiles: Found @testflightapp changes\/integration for iOS 8 - https:\/\/t.co\/M4MPk64nZE - 1000 testers, no UDIDs! Beta App Review doesn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TestFlight",
        "screen_name" : "testflightapp",
        "indices" : [ 6, 20 ],
        "id_str" : "158117892",
        "id" : 158117892
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/M4MPk64nZE",
        "expanded_url" : "https:\/\/developer.apple.com\/support\/appstore\/TestFlight\/index.php",
        "display_url" : "developer.apple.com\/support\/appsto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473658356352049153",
    "text" : "Found @testflightapp changes\/integration for iOS 8 - https:\/\/t.co\/M4MPk64nZE - 1000 testers, no UDIDs! Beta App Review doesn't sound great..",
    "id" : 473658356352049153,
    "created_at" : "2014-06-03 02:52:06 +0000",
    "user" : {
      "name" : "Beau Giles",
      "screen_name" : "BeauGiles",
      "protected" : false,
      "id_str" : "7636802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557154641859727360\/tTjDOCGK_normal.jpeg",
      "id" : 7636802,
      "verified" : false
    }
  },
  "id" : 473662023297810432,
  "created_at" : "2014-06-03 03:06:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "indices" : [ 3, 9 ],
      "id_str" : "35293",
      "id" : 35293
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 125, 136 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/y1WRNUnaDj",
      "expanded_url" : "http:\/\/shimage.net\/one-tap-quest\/",
      "display_url" : "shimage.net\/one-tap-quest\/"
    } ]
  },
  "geo" : { },
  "id_str" : "473660617614561280",
  "text" : "RT @mrgan: One Tap Quest, one of those games so genius I immediately hate the author so, so much http:\/\/t.co\/y1WRNUnaDj (via @waxpancake)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Baio",
        "screen_name" : "waxpancake",
        "indices" : [ 114, 125 ],
        "id_str" : "13461",
        "id" : 13461
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/y1WRNUnaDj",
        "expanded_url" : "http:\/\/shimage.net\/one-tap-quest\/",
        "display_url" : "shimage.net\/one-tap-quest\/"
      } ]
    },
    "geo" : { },
    "id_str" : "473229695756939264",
    "text" : "One Tap Quest, one of those games so genius I immediately hate the author so, so much http:\/\/t.co\/y1WRNUnaDj (via @waxpancake)",
    "id" : 473229695756939264,
    "created_at" : "2014-06-01 22:28:46 +0000",
    "user" : {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "protected" : false,
      "id_str" : "35293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564092871871959040\/b2w9o5gs_normal.png",
      "id" : 35293,
      "verified" : false
    }
  },
  "id" : 473660617614561280,
  "created_at" : "2014-06-03 03:01:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240251067, -78.8791246248 ]
  },
  "id_str" : "473634447766454273",
  "text" : "Made it to June 2 without installing an AC unit. Great success?",
  "id" : 473634447766454273,
  "created_at" : "2014-06-03 01:17:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473571726358757376",
  "geo" : { },
  "id_str" : "473573577237602304",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer Everything. Don't do it. Mavericks fucked me over.",
  "id" : 473573577237602304,
  "in_reply_to_status_id" : 473571726358757376,
  "created_at" : "2014-06-02 21:15:14 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chen",
      "screen_name" : "chenosaurus",
      "indices" : [ 3, 15 ],
      "id_str" : "15349546",
      "id" : 15349546
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chenosaurus\/status\/473572150532505600\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/LR7NDWNSkk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJ3XHKIQAAmJlJ.png",
      "id_str" : "473572149769551872",
      "id" : 473572149769551872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJ3XHKIQAAmJlJ.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 618
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 618
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LR7NDWNSkk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473573482836393984",
  "text" : "RT @chenosaurus: every javascript developer right now http:\/\/t.co\/LR7NDWNSkk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chenosaurus\/status\/473572150532505600\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/LR7NDWNSkk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJ3XHKIQAAmJlJ.png",
        "id_str" : "473572149769551872",
        "id" : 473572149769551872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJ3XHKIQAAmJlJ.png",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LR7NDWNSkk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473572150532505600",
    "text" : "every javascript developer right now http:\/\/t.co\/LR7NDWNSkk",
    "id" : 473572150532505600,
    "created_at" : "2014-06-02 21:09:33 +0000",
    "user" : {
      "name" : "David Chen",
      "screen_name" : "chenosaurus",
      "protected" : false,
      "id_str" : "15349546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432009106132455424\/NFLHeR4w_normal.jpeg",
      "id" : 15349546,
      "verified" : false
    }
  },
  "id" : 473573482836393984,
  "created_at" : "2014-06-02 21:14:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/IwPq9Vr9BM",
      "expanded_url" : "https:\/\/twitter.com\/marcote_torres\/status\/473536682353262592",
      "display_url" : "twitter.com\/marcote_torres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473567264109649920",
  "text" : "What other dev community would this even happen to? (Without a significant revolt?) https:\/\/t.co\/IwPq9Vr9BM",
  "id" : 473567264109649920,
  "created_at" : "2014-06-02 20:50:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473563776110039041",
  "geo" : { },
  "id_str" : "473564209632907265",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer I have this aliased now to `git ours` and `git theirs`",
  "id" : 473564209632907265,
  "in_reply_to_status_id" : 473563776110039041,
  "created_at" : "2014-06-02 20:38:00 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 18, 24 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/jTu4s5EOkc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6k8bXGqqr-A&list=PL5D5C609D38734C3B",
      "display_url" : "youtube.com\/watch?v=6k8bXG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473553074418491392",
  "text" : "Need some low-key @phish after that keynote and considering hours burned on ObjC. In case you need some: https:\/\/t.co\/jTu4s5EOkc",
  "id" : 473553074418491392,
  "created_at" : "2014-06-02 19:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Sandora-Nastyn",
      "screen_name" : "BillybobN",
      "indices" : [ 0, 10 ],
      "id_str" : "97221495",
      "id" : 97221495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473550102305734656",
  "geo" : { },
  "id_str" : "473550781392502784",
  "in_reply_to_user_id" : 97221495,
  "text" : "@BillybobN Gelato and Burgers next door to each other!",
  "id" : 473550781392502784,
  "in_reply_to_status_id" : 473550102305734656,
  "created_at" : "2014-06-02 19:44:39 +0000",
  "in_reply_to_screen_name" : "BillybobN",
  "in_reply_to_user_id_str" : "97221495",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473546535787954177",
  "text" : "Apple developers are put in a strange place between now and Fall. Why even write a line of ObjC if Swift exists?",
  "id" : 473546535787954177,
  "created_at" : "2014-06-02 19:27:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Menscher",
      "screen_name" : "cmenscher",
      "indices" : [ 3, 13 ],
      "id_str" : "696053",
      "id" : 696053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473538492060819456",
  "text" : "RT @cmenscher: Looks like all those years of avoiding learning Objective-C have finally paid off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473536816310919168",
    "text" : "Looks like all those years of avoiding learning Objective-C have finally paid off.",
    "id" : 473536816310919168,
    "created_at" : "2014-06-02 18:49:09 +0000",
    "user" : {
      "name" : "Corey Menscher",
      "screen_name" : "cmenscher",
      "protected" : false,
      "id_str" : "696053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456542616754999296\/ke8NovRl_normal.png",
      "id" : 696053,
      "verified" : false
    }
  },
  "id" : 473538492060819456,
  "created_at" : "2014-06-02 18:55:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473538076078141440",
  "text" : "Can I get back all of the time I've spent on ObjC please?",
  "id" : 473538076078141440,
  "created_at" : "2014-06-02 18:54:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "indices" : [ 3, 12 ],
      "id_str" : "18176030",
      "id" : 18176030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473524444388798465",
  "text" : "RT @drakkhen: Predictive typing is going to be elephant!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473524248699744256",
    "text" : "Predictive typing is going to be elephant!",
    "id" : 473524248699744256,
    "created_at" : "2014-06-02 17:59:13 +0000",
    "user" : {
      "name" : "\u1D48\u02B3\u1D43\u1D4F\u1D4F\u02B0\u1D49\u207F",
      "screen_name" : "drakkhen",
      "protected" : false,
      "id_str" : "18176030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423465534966202369\/7ULcOnPk_normal.jpeg",
      "id" : 18176030,
      "verified" : false
    }
  },
  "id" : 473524444388798465,
  "created_at" : "2014-06-02 17:59:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Margolis",
      "screen_name" : "yipe",
      "indices" : [ 3, 8 ],
      "id_str" : "14256647",
      "id" : 14256647
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/yipe\/status\/473482508227444736\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1Y8MFVFHv5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIlzbxCcAAGc5k.jpg",
      "id_str" : "473482476384317440",
      "id" : 473482476384317440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIlzbxCcAAGc5k.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/1Y8MFVFHv5"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/yipe\/status\/473482508227444736\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1Y8MFVFHv5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIlzcaCUAANX1L.jpg",
      "id_str" : "473482476556275712",
      "id" : 473482476556275712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIlzcaCUAANX1L.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/1Y8MFVFHv5"
    } ],
    "hashtags" : [ {
      "text" : "WWDC",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473487151917580288",
  "text" : "RT @yipe: Keep it classy #WWDC http:\/\/t.co\/1Y8MFVFHv5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/yipe\/status\/473482508227444736\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/1Y8MFVFHv5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIlzbxCcAAGc5k.jpg",
        "id_str" : "473482476384317440",
        "id" : 473482476384317440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIlzbxCcAAGc5k.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/1Y8MFVFHv5"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/yipe\/status\/473482508227444736\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/1Y8MFVFHv5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIlzcaCUAANX1L.jpg",
        "id_str" : "473482476556275712",
        "id" : 473482476556275712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIlzcaCUAANX1L.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/1Y8MFVFHv5"
      } ],
      "hashtags" : [ {
        "text" : "WWDC",
        "indices" : [ 15, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473482508227444736",
    "text" : "Keep it classy #WWDC http:\/\/t.co\/1Y8MFVFHv5",
    "id" : 473482508227444736,
    "created_at" : "2014-06-02 15:13:21 +0000",
    "user" : {
      "name" : "Michael Margolis",
      "screen_name" : "yipe",
      "protected" : false,
      "id_str" : "14256647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572461842677501952\/_Scdv3A0_normal.png",
      "id" : 14256647,
      "verified" : false
    }
  },
  "id" : 473487151917580288,
  "created_at" : "2014-06-02 15:31:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/nKuko5i5uq",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?feature=youtu.be&v=PpxDuNFBVj8",
      "display_url" : "m.youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473269494509363200",
  "text" : "Luigi's death stare might make me stop playing as Roy.  http:\/\/t.co\/nKuko5i5uq",
  "id" : 473269494509363200,
  "created_at" : "2014-06-02 01:06:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 3, 9 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473241826694922240",
  "text" : "RT @jamis: Never let your environment dictate what is possible. I first learned of homemade marshmallows via a magazine at a DENTIST'S OFFI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473237194895663104",
    "text" : "Never let your environment dictate what is possible. I first learned of homemade marshmallows via a magazine at a DENTIST'S OFFICE.",
    "id" : 473237194895663104,
    "created_at" : "2014-06-01 22:58:34 +0000",
    "user" : {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "protected" : false,
      "id_str" : "5877822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505028142990258177\/iGTu5mqu_normal.jpeg",
      "id" : 5877822,
      "verified" : false
    }
  },
  "id" : 473241826694922240,
  "created_at" : "2014-06-01 23:16:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 3, 8 ],
      "id_str" : "819606",
      "id" : 819606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473227602719559680",
  "text" : "RT @janl: My biggest reward as a conference organiser is people doing great things with something they learned or with someone they met at \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473226565711847424",
    "text" : "My biggest reward as a conference organiser is people doing great things with something they learned or with someone they met at the conf.",
    "id" : 473226565711847424,
    "created_at" : "2014-06-01 22:16:20 +0000",
    "user" : {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "protected" : false,
      "id_str" : "819606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2673735348\/331cefd2263bbc754979526b3fd48e4d_normal.png",
      "id" : 819606,
      "verified" : false
    }
  },
  "id" : 473227602719559680,
  "created_at" : "2014-06-01 22:20:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473227076774813696",
  "geo" : { },
  "id_str" : "473227523883429888",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle makers, pineapple juice\/vodka",
  "id" : 473227523883429888,
  "in_reply_to_status_id" : 473227076774813696,
  "created_at" : "2014-06-01 22:20:08 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/473218233663647744\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/3RmkuhfIhF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpE1eeWCQAAJfQU.jpg",
      "id_str" : "473218233508446208",
      "id" : 473218233508446208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpE1eeWCQAAJfQU.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/3RmkuhfIhF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9243267887, -78.8791227155 ]
  },
  "id_str" : "473218233663647744",
  "text" : "Classy Sunday porch drinky dranks. http:\/\/t.co\/3RmkuhfIhF",
  "id" : 473218233663647744,
  "created_at" : "2014-06-01 21:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffaloPride",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240132125, -78.8769395277 ]
  },
  "id_str" : "473158814163030016",
  "text" : "Blown away by how big #BuffaloPride is. Parade easily been going for an hour now. Crazy!",
  "id" : 473158814163030016,
  "created_at" : "2014-06-01 17:47:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9240697443, -78.8771154517 ]
  },
  "id_str" : "473152864190083072",
  "text" : "Pride parade only a block away. Love it. \uD83C\uDF08",
  "id" : 473152864190083072,
  "created_at" : "2014-06-01 17:23:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Merriman",
      "screen_name" : "jmerriman",
      "indices" : [ 3, 13 ],
      "id_str" : "14098171",
      "id" : 14098171
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jmerriman\/status\/291647075257552896\/photo\/1",
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/yvcrmvyl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAwjeEDCEAAfZgL.jpg",
      "id_str" : "291647075261747200",
      "id" : 291647075261747200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAwjeEDCEAAfZgL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 959
      } ],
      "display_url" : "pic.twitter.com\/yvcrmvyl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473147113904148481",
  "text" : "RT @jmerriman: I talked to Adobe yesterday: http:\/\/t.co\/yvcrmvyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jmerriman\/status\/291647075257552896\/photo\/1",
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/yvcrmvyl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAwjeEDCEAAfZgL.jpg",
        "id_str" : "291647075261747200",
        "id" : 291647075261747200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAwjeEDCEAAfZgL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 959
        } ],
        "display_url" : "pic.twitter.com\/yvcrmvyl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291647075257552896",
    "text" : "I talked to Adobe yesterday: http:\/\/t.co\/yvcrmvyl",
    "id" : 291647075257552896,
    "created_at" : "2013-01-16 20:44:16 +0000",
    "user" : {
      "name" : "John Merriman",
      "screen_name" : "jmerriman",
      "protected" : false,
      "id_str" : "14098171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1187024814\/Screen_shot_2010-12-10_at_2.17.11_AM_normal.png",
      "id" : 14098171,
      "verified" : false
    }
  },
  "id" : 473147113904148481,
  "created_at" : "2014-06-01 17:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 38, 52 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9244185314, -78.8789664418 ]
  },
  "id_str" : "473145327713648642",
  "text" : "Will be streaming the WWDC Keynote at @coworkbuffalo if anyone else wants to watch!",
  "id" : 473145327713648642,
  "created_at" : "2014-06-01 16:53:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
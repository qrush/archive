Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/Badrigl8",
      "expanded_url" : "https:\/\/bugzilla.mozilla.org\/show_bug.cgi?id=769972",
      "display_url" : "bugzilla.mozilla.org\/show_bug.cgi?i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219255023975149568",
  "text" : "Earth: Hey, we need to add a leap second here. Rotation and stuff. Java: OH FUCK THE WORLD IS ENDING!!!!! https:\/\/t.co\/Badrigl8",
  "id" : 219255023975149568,
  "created_at" : "2012-07-01 02:24:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/hRRrNJtU",
      "expanded_url" : "http:\/\/www.somebits.com\/weblog\/tech\/utc-vs-ut1-leap-seconds.html",
      "display_url" : "somebits.com\/weblog\/tech\/ut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219247282648911872",
  "text" : "\"I find it frightening how variable the earth\u2019s rotation speed is. That anomaly around 1998\u20132005 makes me nervous.\" http:\/\/t.co\/hRRrNJtU",
  "id" : 219247282648911872,
  "created_at" : "2012-07-01 01:53:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/gZKJ9sHk",
      "expanded_url" : "http:\/\/instagr.am\/p\/MhSvmwM6h3\/",
      "display_url" : "instagr.am\/p\/MhSvmwM6h3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "219244563196411904",
  "text" : "Post bike ride exhausted Husky. http:\/\/t.co\/gZKJ9sHk",
  "id" : 219244563196411904,
  "created_at" : "2012-07-01 01:42:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219243586523377664",
  "text" : "Biking with the husky has been so worth the difficulty level of this breed. So excited, full of energy, and now tired.",
  "id" : 219243586523377664,
  "created_at" : "2012-07-01 01:38:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/WZPKxKa8",
      "expanded_url" : "http:\/\/blade.nagaokaut.ac.jp\/cgi-bin\/scat.rb\/ruby\/ruby-core\/45474",
      "display_url" : "blade.nagaokaut.ac.jp\/cgi-bin\/scat.r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219094785733033984",
  "text" : "RT @steveklabnik: \"Consider matz as a busy angel investor, and try \"elevator pitch.\" \" http:\/\/t.co\/WZPKxKa8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/WZPKxKa8",
        "expanded_url" : "http:\/\/blade.nagaokaut.ac.jp\/cgi-bin\/scat.rb\/ruby\/ruby-core\/45474",
        "display_url" : "blade.nagaokaut.ac.jp\/cgi-bin\/scat.r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "219093750612369408",
    "text" : "\"Consider matz as a busy angel investor, and try \"elevator pitch.\" \" http:\/\/t.co\/WZPKxKa8",
    "id" : 219093750612369408,
    "created_at" : "2012-06-30 15:43:15 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 219094785733033984,
  "created_at" : "2012-06-30 15:47:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Next Feature",
      "screen_name" : "NextFeature",
      "indices" : [ 0, 12 ],
      "id_str" : "1287418447",
      "id" : 1287418447
    }, {
      "name" : "WebHost.io",
      "screen_name" : "WebHostIO",
      "indices" : [ 13, 23 ],
      "id_str" : "455102203",
      "id" : 455102203
    }, {
      "name" : "Adam Lindsay",
      "screen_name" : "adamlindsay",
      "indices" : [ 24, 36 ],
      "id_str" : "49763",
      "id" : 49763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219075507747164161",
  "text" : "@nextfeature @WebHostIO @AdamLindsay congrats!",
  "id" : 219075507747164161,
  "created_at" : "2012-06-30 14:30:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 28, 36 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218923793870098432",
  "geo" : { },
  "id_str" : "218924329386246144",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes lately it\u2019s been @evanphx keeping the boat afloat! Also, SSPullToRefresh is wonderful.",
  "id" : 218924329386246144,
  "in_reply_to_status_id" : 218923793870098432,
  "created_at" : "2012-06-30 04:30:02 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218923021728092160",
  "geo" : { },
  "id_str" : "218923553456791555",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes wooo\u2026",
  "id" : 218923553456791555,
  "in_reply_to_status_id" : 218923021728092160,
  "created_at" : "2012-06-30 04:26:57 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218899446090571778",
  "geo" : { },
  "id_str" : "218906583080501250",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg heck yes!",
  "id" : 218906583080501250,
  "in_reply_to_status_id" : 218899446090571778,
  "created_at" : "2012-06-30 03:19:31 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/zCPUaHuk",
      "expanded_url" : "http:\/\/4sq.com\/Neg1s6",
      "display_url" : "4sq.com\/Neg1s6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9912112084, -78.802050678 ]
  },
  "id_str" : "218885399672664064",
  "text" : "First visit to Building M, Buffalo edition. Missing Rochester suddenly. (@ MacGregors' Grill &amp; Tap Room) http:\/\/t.co\/zCPUaHuk",
  "id" : 218885399672664064,
  "created_at" : "2012-06-30 01:55:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mikeash",
      "screen_name" : "mikeash",
      "indices" : [ 3, 11 ],
      "id_str" : "8142952",
      "id" : 8142952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218840255548243968",
  "text" : "RT @mikeash: I love how people come out of the woodwork to defend PHP. PHP fans seem less willing to admit flaws than fans of any other  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218838768579387394",
    "text" : "I love how people come out of the woodwork to defend PHP. PHP fans seem less willing to admit flaws than fans of any other language.",
    "id" : 218838768579387394,
    "created_at" : "2012-06-29 22:50:02 +0000",
    "user" : {
      "name" : "mikeash",
      "screen_name" : "mikeash",
      "protected" : false,
      "id_str" : "8142952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568931119077523456\/At7WtWLb_normal.png",
      "id" : 8142952,
      "verified" : false
    }
  },
  "id" : 218840255548243968,
  "created_at" : "2012-06-29 22:55:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/h38SzwhS",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/askashittydoctor\/",
      "display_url" : "reddit.com\/r\/askashittydo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218805757141983233",
  "text" : "\"I creak like an old fishing boat when moving, am I made of wood?\" http:\/\/t.co\/h38SzwhS",
  "id" : 218805757141983233,
  "created_at" : "2012-06-29 20:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "GeorgeToGo",
      "indices" : [ 0, 11 ],
      "id_str" : "14627282",
      "id" : 14627282
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 12, 25 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/3eL3zn5k",
      "expanded_url" : "http:\/\/www.grannyturismo.net\/grannyturismo\/meet.html",
      "display_url" : "grannyturismo.net\/grannyturismo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218801459502907392",
  "in_reply_to_user_id" : 14627282,
  "text" : "@GeorgeToGo @moonpolysoft http:\/\/t.co\/3eL3zn5k",
  "id" : 218801459502907392,
  "created_at" : "2012-06-29 20:21:47 +0000",
  "in_reply_to_screen_name" : "GeorgeToGo",
  "in_reply_to_user_id_str" : "14627282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "GeorgeToGo",
      "indices" : [ 0, 11 ],
      "id_str" : "14627282",
      "id" : 14627282
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 12, 25 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/xhMZA2Ji",
      "expanded_url" : "http:\/\/www.grannyturismo.net\/grannyturismo\/granny_home.html",
      "display_url" : "grannyturismo.net\/grannyturismo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218801359825281025",
  "in_reply_to_user_id" : 14627282,
  "text" : "@GeorgeToGo @moonpolysoft it gets worse: http:\/\/t.co\/xhMZA2Ji",
  "id" : 218801359825281025,
  "created_at" : "2012-06-29 20:21:23 +0000",
  "in_reply_to_screen_name" : "GeorgeToGo",
  "in_reply_to_user_id_str" : "14627282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "GeorgeToGo",
      "indices" : [ 0, 11 ],
      "id_str" : "14627282",
      "id" : 14627282
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 12, 25 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/kVXIe4dF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Cqn7IZ8bvG4&feature=related",
      "display_url" : "youtube.com\/watch?v=Cqn7IZ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218797977697914880",
  "geo" : { },
  "id_str" : "218800784370966528",
  "in_reply_to_user_id" : 14627282,
  "text" : "@GeorgeToGo @moonpolysoft http:\/\/t.co\/kVXIe4dF",
  "id" : 218800784370966528,
  "in_reply_to_status_id" : 218797977697914880,
  "created_at" : "2012-06-29 20:19:06 +0000",
  "in_reply_to_screen_name" : "GeorgeToGo",
  "in_reply_to_user_id_str" : "14627282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/wcSzB7xx",
      "expanded_url" : "http:\/\/vimeo.com\/44875147",
      "display_url" : "vimeo.com\/44875147"
    } ]
  },
  "geo" : { },
  "id_str" : "218794914790641665",
  "text" : "Ridiculously hi-def zany Phish Scent of Mule jam with theremin action! http:\/\/t.co\/wcSzB7xx",
  "id" : 218794914790641665,
  "created_at" : "2012-06-29 19:55:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218794393212162048",
  "text" : "RT @rjs: Visited a startup at a Chicago incubator today. Me: \"So have any of the other mentors told you to focus the product?\" Them: \"No ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218794309527412736",
    "text" : "Visited a startup at a Chicago incubator today. Me: \"So have any of the other mentors told you to focus the product?\" Them: \"Not one.\"",
    "id" : 218794309527412736,
    "created_at" : "2012-06-29 19:53:23 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 218794393212162048,
  "created_at" : "2012-06-29 19:53:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218789289411096576",
  "geo" : { },
  "id_str" : "218789490645413888",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi omg. yes.",
  "id" : 218789490645413888,
  "in_reply_to_status_id" : 218789289411096576,
  "created_at" : "2012-06-29 19:34:14 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 13, 25 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 46, 60 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/gmxdDJJA",
      "expanded_url" : "http:\/\/instagr.am\/p\/Md4XAlM6q4\/",
      "display_url" : "instagr.am\/p\/Md4XAlM6q4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "218764493205938177",
  "text" : "Oh heck yes. @whereslloyd bringing it back to @coworkbuffalo! http:\/\/t.co\/gmxdDJJA",
  "id" : 218764493205938177,
  "created_at" : "2012-06-29 17:54:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 51, 61 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218756002416308225",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd coming down now\u2026still gonna be there? @magnachef is coming too",
  "id" : 218756002416308225,
  "created_at" : "2012-06-29 17:21:09 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/MS3nmOyI",
      "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2012\/06\/the-php-singularity.html",
      "display_url" : "codinghorror.com\/blog\/2012\/06\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218725019797307392",
  "text" : "\"You pull out the hammer, but to your dismay, it has the claw part on both sides.\"  http:\/\/t.co\/MS3nmOyI",
  "id" : 218725019797307392,
  "created_at" : "2012-06-29 15:18:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218510230122795008",
  "geo" : { },
  "id_str" : "218511436173934592",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh thanks!",
  "id" : 218511436173934592,
  "in_reply_to_status_id" : 218510230122795008,
  "created_at" : "2012-06-29 01:09:20 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218508799328260097",
  "geo" : { },
  "id_str" : "218509755558268928",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh Would appreciate some support if you're in",
  "id" : 218509755558268928,
  "in_reply_to_status_id" : 218508799328260097,
  "created_at" : "2012-06-29 01:02:40 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218508799328260097",
  "geo" : { },
  "id_str" : "218509700159901698",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh yeah getting downvoted. :\/",
  "id" : 218509700159901698,
  "in_reply_to_status_id" : 218508799328260097,
  "created_at" : "2012-06-29 01:02:26 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 106 ],
      "url" : "https:\/\/t.co\/eDGs760R",
      "expanded_url" : "https:\/\/github.com\/rubymotion\/BubbleWrap\/issues\/76",
      "display_url" : "github.com\/rubymotion\/Bub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218504793520484353",
  "text" : "Wherein I suggest to split BubbleWrap into multiple gems. Let's see how this goes... https:\/\/t.co\/eDGs760R",
  "id" : 218504793520484353,
  "created_at" : "2012-06-29 00:42:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/tqh0O8zY",
      "expanded_url" : "http:\/\/blog.jquery.com\/2012\/06\/28\/jquery-core-version-1-9-and-beyond\/",
      "display_url" : "blog.jquery.com\/2012\/06\/28\/jqu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218500253207371776",
  "text" : "RT @dhh: Great to see jQuery 2.0 scrub out all the legacy crap that was needed to deal with IE6\/7\/8: http:\/\/t.co\/tqh0O8zY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/tqh0O8zY",
        "expanded_url" : "http:\/\/blog.jquery.com\/2012\/06\/28\/jquery-core-version-1-9-and-beyond\/",
        "display_url" : "blog.jquery.com\/2012\/06\/28\/jqu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "218499902043455490",
    "text" : "Great to see jQuery 2.0 scrub out all the legacy crap that was needed to deal with IE6\/7\/8: http:\/\/t.co\/tqh0O8zY",
    "id" : 218499902043455490,
    "created_at" : "2012-06-29 00:23:30 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 218500253207371776,
  "created_at" : "2012-06-29 00:24:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218436162132508672",
  "geo" : { },
  "id_str" : "218436618313400321",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr it's definitely more than that.",
  "id" : 218436618313400321,
  "in_reply_to_status_id" : 218436162132508672,
  "created_at" : "2012-06-28 20:12:02 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/2fh3cadb",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/chrome\/id535886823?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/chrome\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218436081253744640",
  "geo" : { },
  "id_str" : "218436539468873730",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej http:\/\/t.co\/2fh3cadb",
  "id" : 218436539468873730,
  "in_reply_to_status_id" : 218436081253744640,
  "created_at" : "2012-06-28 20:11:44 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218436211558187009",
  "text" : "Bookmark syncing from desktop, swipe left\/right to switch tabs... Mobile Safari is now permanently retired.",
  "id" : 218436211558187009,
  "created_at" : "2012-06-28 20:10:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218435711655886848",
  "text" : "Absolutely LOVING Chrome for iOS. Stellar job.",
  "id" : 218435711655886848,
  "created_at" : "2012-06-28 20:08:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218399697956651010",
  "text" : "Left arm spasms all day today. Wtf arm.",
  "id" : 218399697956651010,
  "created_at" : "2012-06-28 17:45:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218334190486290434",
  "geo" : { },
  "id_str" : "218336081966415872",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham unreal tournament just got more real",
  "id" : 218336081966415872,
  "in_reply_to_status_id" : 218334190486290434,
  "created_at" : "2012-06-28 13:32:33 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/0q7Fke0f",
      "expanded_url" : "http:\/\/ianjq.tumblr.com\/post\/24690254633\/every-time-i-listen-to-npr",
      "display_url" : "ianjq.tumblr.com\/post\/246902546\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218152502925864961",
  "text" : "\"Every time I listen to NPR...\" http:\/\/t.co\/0q7Fke0f",
  "id" : 218152502925864961,
  "created_at" : "2012-06-28 01:23:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218138697189703682",
  "geo" : { },
  "id_str" : "218139258521780224",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten heck yeah!",
  "id" : 218139258521780224,
  "in_reply_to_status_id" : 218138697189703682,
  "created_at" : "2012-06-28 00:30:26 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218127426977398784",
  "geo" : { },
  "id_str" : "218128246989012992",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes \"He purchased the island at the age of 28\" ...I gotta hurry up on this.",
  "id" : 218128246989012992,
  "in_reply_to_status_id" : 218127426977398784,
  "created_at" : "2012-06-27 23:46:41 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alli Suriani ",
      "screen_name" : "AlliBuffaloEats",
      "indices" : [ 0, 16 ],
      "id_str" : "17737129",
      "id" : 17737129
    }, {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 17, 29 ],
      "id_str" : "21758029",
      "id" : 21758029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218105955584442368",
  "geo" : { },
  "id_str" : "218106496377036801",
  "in_reply_to_user_id" : 17737129,
  "text" : "@AlliBuffaloEats @BuffaloEats where!?",
  "id" : 218106496377036801,
  "in_reply_to_status_id" : 218105955584442368,
  "created_at" : "2012-06-27 22:20:15 +0000",
  "in_reply_to_screen_name" : "AlliBuffaloEats",
  "in_reply_to_user_id_str" : "17737129",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 3, 17 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/HvZHJ4aG",
      "expanded_url" : "http:\/\/imgur.com\/a\/akJCS",
      "display_url" : "imgur.com\/a\/akJCS"
    } ]
  },
  "geo" : { },
  "id_str" : "218078331483078658",
  "text" : "RT @chriseppstein: Boycotting Oreo for their support of Gay Pride? There are more companies to boycott. http:\/\/t.co\/HvZHJ4aG Enjoy your  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/HvZHJ4aG",
        "expanded_url" : "http:\/\/imgur.com\/a\/akJCS",
        "display_url" : "imgur.com\/a\/akJCS"
      } ]
    },
    "geo" : { },
    "id_str" : "218077053377970176",
    "text" : "Boycotting Oreo for their support of Gay Pride? There are more companies to boycott. http:\/\/t.co\/HvZHJ4aG Enjoy your depressing existence.",
    "id" : 218077053377970176,
    "created_at" : "2012-06-27 20:23:15 +0000",
    "user" : {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "protected" : false,
      "id_str" : "14148091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519135142552408064\/V3jQ-sNS_normal.jpeg",
      "id" : 14148091,
      "verified" : false
    }
  },
  "id" : 218078331483078658,
  "created_at" : "2012-06-27 20:28:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronan O'Malley",
      "screen_name" : "ronomal",
      "indices" : [ 0, 8 ],
      "id_str" : "38407927",
      "id" : 38407927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218017261145964544",
  "geo" : { },
  "id_str" : "218031297191358464",
  "in_reply_to_user_id" : 38407927,
  "text" : "@ronomal restart from scratch and read the apple tutorials",
  "id" : 218031297191358464,
  "in_reply_to_status_id" : 218017261145964544,
  "created_at" : "2012-06-27 17:21:26 +0000",
  "in_reply_to_screen_name" : "ronomal",
  "in_reply_to_user_id_str" : "38407927",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/jgoIIcKl",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TcMP90xT0sQ",
      "display_url" : "youtube.com\/watch?v=TcMP90\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218029751611310081",
  "text" : "\"What kind of bear has a magenta nose?\" http:\/\/t.co\/jgoIIcKl",
  "id" : 218029751611310081,
  "created_at" : "2012-06-27 17:15:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 35, 43 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218007122699485184",
  "text" : "RT @coworkbuffalo: It\u2019s Wednesday! @wnyruby folks had a good time hacking here last night, thanks if you stopped by. Who\u2019s showing up to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 16, 24 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218007061349416960",
    "text" : "It\u2019s Wednesday! @wnyruby folks had a good time hacking here last night, thanks if you stopped by. Who\u2019s showing up today to cowork?",
    "id" : 218007061349416960,
    "created_at" : "2012-06-27 15:45:08 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 218007122699485184,
  "created_at" : "2012-06-27 15:45:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 53, 67 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo OpenCoffee",
      "screen_name" : "BfloOpenCoffee",
      "indices" : [ 71, 86 ],
      "id_str" : "300394295",
      "id" : 300394295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217845633820786688",
  "geo" : { },
  "id_str" : "217997920392323072",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette \"only 30 days\" ha! you can find me at @coworkbuffalo or @bfloopencoffee",
  "id" : 217997920392323072,
  "in_reply_to_status_id" : 217845633820786688,
  "created_at" : "2012-06-27 15:08:49 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217635898697850881",
  "geo" : { },
  "id_str" : "217834401940250627",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris converted my home desk to it, I need to get a good mat first. Can\u2019t deal with it for too long.",
  "id" : 217834401940250627,
  "in_reply_to_status_id" : 217635898697850881,
  "created_at" : "2012-06-27 04:19:03 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217816674139783168",
  "text" : "Blue lambo parked outside of Cantina Loco on Elmwood. Not the best corner for that!",
  "id" : 217816674139783168,
  "created_at" : "2012-06-27 03:08:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/bSYvwMsz",
      "expanded_url" : "http:\/\/getbacktowork.herokuapp.com\/index.html",
      "display_url" : "getbacktowork.herokuapp.com\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "217774918232838144",
  "text" : "Did a ~\/.pow for some reason, apparently I made  http:\/\/t.co\/bSYvwMsz at some point?",
  "id" : 217774918232838144,
  "created_at" : "2012-06-27 00:22:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 34, 44 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217769106491969536",
  "geo" : { },
  "id_str" : "217769343067492352",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx is this the roflcon bit? @aquaranto and I got rickrolled by NPR a few weeks ago",
  "id" : 217769343067492352,
  "in_reply_to_status_id" : 217769106491969536,
  "created_at" : "2012-06-27 00:00:32 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "indices" : [ 3, 14 ],
      "id_str" : "22084427",
      "id" : 22084427
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NERD",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "NERD",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "NERD",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217724628930535426",
  "text" : "RT @robdelaney: Psyched about the Spice Girls reunion. Not as psyched as Paul Muad'Dib though. #NERD #NERD #NERD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NERD",
        "indices" : [ 79, 84 ]
      }, {
        "text" : "NERD",
        "indices" : [ 85, 90 ]
      }, {
        "text" : "NERD",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217721766137708544",
    "text" : "Psyched about the Spice Girls reunion. Not as psyched as Paul Muad'Dib though. #NERD #NERD #NERD",
    "id" : 217721766137708544,
    "created_at" : "2012-06-26 20:51:28 +0000",
    "user" : {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "protected" : false,
      "id_str" : "22084427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552880428915257344\/1NN2mDeP_normal.png",
      "id" : 22084427,
      "verified" : true
    }
  },
  "id" : 217724628930535426,
  "created_at" : "2012-06-26 21:02:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 3, 10 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 90 ],
      "url" : "https:\/\/t.co\/Xaz0M8XX",
      "expanded_url" : "https:\/\/github.com\/defunkt\/resque\/issues\/605#issuecomment-6586455",
      "display_url" : "github.com\/defunkt\/resque\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217720208159281154",
  "text" : "RT @hone02: anyone curious on the state of resque, please read this: https:\/\/t.co\/Xaz0M8XX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 78 ],
        "url" : "https:\/\/t.co\/Xaz0M8XX",
        "expanded_url" : "https:\/\/github.com\/defunkt\/resque\/issues\/605#issuecomment-6586455",
        "display_url" : "github.com\/defunkt\/resque\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217712134765821952",
    "text" : "anyone curious on the state of resque, please read this: https:\/\/t.co\/Xaz0M8XX",
    "id" : 217712134765821952,
    "created_at" : "2012-06-26 20:13:12 +0000",
    "user" : {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "protected" : false,
      "id_str" : "15317640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2928200808\/9e35a1697bb4504604356d454a86d5b9_normal.png",
      "id" : 15317640,
      "verified" : false
    }
  },
  "id" : 217720208159281154,
  "created_at" : "2012-06-26 20:45:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217674695456210944",
  "text" : "PSA: Don't git clean -dfx without committing first...gah!!!",
  "id" : 217674695456210944,
  "created_at" : "2012-06-26 17:44:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muhammed Munther",
      "screen_name" : "zertux6",
      "indices" : [ 0, 8 ],
      "id_str" : "2949116451",
      "id" : 2949116451
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 53, 63 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/Kk72014h",
      "expanded_url" : "http:\/\/pine.fm\/LearnToProgram",
      "display_url" : "pine.fm\/LearnToProgram"
    } ]
  },
  "geo" : { },
  "id_str" : "217671792213499905",
  "text" : "@zertux6 they're going through http:\/\/t.co\/Kk72014h. @aquaranto can help you with more info!",
  "id" : 217671792213499905,
  "created_at" : "2012-06-26 17:32:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 46, 60 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/KjoVUxyO",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/70820512\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217665821353312258",
  "text" : "We're going to have a Ruby Hack Night tonight @CoworkBuffalo. Come down and hack on your side projects\/open source! http:\/\/t.co\/KjoVUxyO",
  "id" : 217665821353312258,
  "created_at" : "2012-06-26 17:09:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217659186815827969",
  "geo" : { },
  "id_str" : "217659404403736576",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich uhhh....",
  "id" : 217659404403736576,
  "in_reply_to_status_id" : 217659186815827969,
  "created_at" : "2012-06-26 16:43:40 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "indices" : [ 0, 11 ],
      "id_str" : "16550758",
      "id" : 16550758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217651610225086464",
  "geo" : { },
  "id_str" : "217651921182408705",
  "in_reply_to_user_id" : 16550758,
  "text" : "@RicRoberts thanks! we need to pimp the guides site more. :(",
  "id" : 217651921182408705,
  "in_reply_to_status_id" : 217651610225086464,
  "created_at" : "2012-06-26 16:13:56 +0000",
  "in_reply_to_screen_name" : "RicRoberts",
  "in_reply_to_user_id_str" : "16550758",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "indices" : [ 3, 14 ],
      "id_str" : "16550758",
      "id" : 16550758
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 37, 43 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Xm5cFM1z",
      "expanded_url" : "http:\/\/guides.rubygems.org\/make-your-own-gem\/",
      "display_url" : "guides.rubygems.org\/make-your-own-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217651885295939586",
  "text" : "RT @RicRoberts: Nice little guide by @qrush on making your own gems. http:\/\/t.co\/Xm5cFM1z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 21, 27 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/Xm5cFM1z",
        "expanded_url" : "http:\/\/guides.rubygems.org\/make-your-own-gem\/",
        "display_url" : "guides.rubygems.org\/make-your-own-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217651610225086464",
    "text" : "Nice little guide by @qrush on making your own gems. http:\/\/t.co\/Xm5cFM1z",
    "id" : 217651610225086464,
    "created_at" : "2012-06-26 16:12:42 +0000",
    "user" : {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "protected" : false,
      "id_str" : "16550758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3116080153\/ba1477325473f2e3f061c59999a8fefb_normal.jpeg",
      "id" : 16550758,
      "verified" : false
    }
  },
  "id" : 217651885295939586,
  "created_at" : "2012-06-26 16:13:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 25, 31 ],
      "id_str" : "14503997",
      "id" : 14503997
    }, {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 81, 88 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Hyl2Zji5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=r6UlQC1STrM&feature=autoplay&list=PLEB160E0C380F3DB4&playnext=3",
      "display_url" : "youtube.com\/watch?v=r6UlQC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217649262421479424",
  "text" : "Absolutely zany set from @phish on Saturday. Page broke out the theremin! Thanks @mkdevo! http:\/\/t.co\/Hyl2Zji5",
  "id" : 217649262421479424,
  "created_at" : "2012-06-26 16:03:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ZQVukWJJ",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "217634259530297345",
  "text" : "RT @coworkbuffalo: Our site now has photos, an FAQ, and still plenty of Buffaloes. Buffalos? Buffalo buffalo buffalo. http:\/\/t.co\/ZQVukWJJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/ZQVukWJJ",
        "expanded_url" : "http:\/\/coworkbuffalo.com",
        "display_url" : "coworkbuffalo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "217634204488450048",
    "text" : "Our site now has photos, an FAQ, and still plenty of Buffaloes. Buffalos? Buffalo buffalo buffalo. http:\/\/t.co\/ZQVukWJJ",
    "id" : 217634204488450048,
    "created_at" : "2012-06-26 15:03:32 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 217634259530297345,
  "created_at" : "2012-06-26 15:03:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217458690356289537",
  "geo" : { },
  "id_str" : "217459531414896641",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv celebrities are people too and have normal habits!!? NO WAY",
  "id" : 217459531414896641,
  "in_reply_to_status_id" : 217458690356289537,
  "created_at" : "2012-06-26 03:29:27 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/qq1352ru",
      "expanded_url" : "http:\/\/www.weknowwhatyouredoing.com\/",
      "display_url" : "weknowwhatyouredoing.com"
    } ]
  },
  "geo" : { },
  "id_str" : "217456413998448643",
  "text" : "I love exploits of stupidity on the internet. This takes the cake: http:\/\/t.co\/qq1352ru",
  "id" : 217456413998448643,
  "created_at" : "2012-06-26 03:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217406857722085378",
  "geo" : { },
  "id_str" : "217407213810098176",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton congrats!",
  "id" : 217407213810098176,
  "in_reply_to_status_id" : 217406857722085378,
  "created_at" : "2012-06-26 00:01:33 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 35 ],
      "url" : "https:\/\/t.co\/q4joomnH",
      "expanded_url" : "https:\/\/gist.github.com\/2992090",
      "display_url" : "gist.github.com\/2992090"
    } ]
  },
  "in_reply_to_status_id_str" : "217401265393631232",
  "geo" : { },
  "id_str" : "217401646186102785",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie https:\/\/t.co\/q4joomnH",
  "id" : 217401646186102785,
  "in_reply_to_status_id" : 217401265393631232,
  "created_at" : "2012-06-25 23:39:26 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 30, 38 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 91 ],
      "url" : "https:\/\/t.co\/q4joomnH",
      "expanded_url" : "https:\/\/gist.github.com\/2992090",
      "display_url" : "gist.github.com\/2992090"
    } ]
  },
  "geo" : { },
  "id_str" : "217400087268171777",
  "text" : "Finally got it to load, sadly @louisck is not coming near Buffalo. :( https:\/\/t.co\/q4joomnH",
  "id" : 217400087268171777,
  "created_at" : "2012-06-25 23:33:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 19, 27 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 77, 87 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "Javan Makhmali",
      "screen_name" : "javan",
      "indices" : [ 88, 94 ],
      "id_str" : "1679",
      "id" : 1679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217397839045726209",
  "text" : "Can anyone get the @louisck tour dates to load? Wondering where he's going!! @ngauthier @javan",
  "id" : 217397839045726209,
  "created_at" : "2012-06-25 23:24:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "indices" : [ 3, 18 ],
      "id_str" : "14248784",
      "id" : 14248784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217396996657512449",
  "text" : "RT @drewtoothpaste: \"How does the defendant plead?\" says the judge. I lean forward, handcuff chain clanking, and reply \"Delicious.\" The  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217271502515613697",
    "text" : "\"How does the defendant plead?\" says the judge. I lean forward, handcuff chain clanking, and reply \"Delicious.\" The jurors  all nod.",
    "id" : 217271502515613697,
    "created_at" : "2012-06-25 15:02:17 +0000",
    "user" : {
      "name" : "drewtoothpaste",
      "screen_name" : "drewtoothpaste",
      "protected" : false,
      "id_str" : "14248784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1484619295\/drew-twit-avatar-2011_normal.jpg",
      "id" : 14248784,
      "verified" : false
    }
  },
  "id" : 217396996657512449,
  "created_at" : "2012-06-25 23:20:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poul Stevens",
      "screen_name" : "louisck",
      "indices" : [ 12, 20 ],
      "id_str" : "2218092372",
      "id" : 2218092372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217395944394723328",
  "text" : "I love when @louisck sends email.",
  "id" : 217395944394723328,
  "created_at" : "2012-06-25 23:16:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/217389297324666880\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/g2Bhmodw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwRSagVCMAAHCUM.png",
      "id_str" : "217389297328861184",
      "id" : 217389297328861184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwRSagVCMAAHCUM.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1388
      } ],
      "display_url" : "pic.twitter.com\/g2Bhmodw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 94 ],
      "url" : "https:\/\/t.co\/EmeV3QoT",
      "expanded_url" : "https:\/\/github.com\/jkbr\/httpie\/",
      "display_url" : "github.com\/jkbr\/httpie\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217389297324666880",
  "text" : "Enjoying httpie so far, it's like curl just without the terrible syntax. https:\/\/t.co\/EmeV3QoT http:\/\/t.co\/g2Bhmodw",
  "id" : 217389297324666880,
  "created_at" : "2012-06-25 22:50:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Nyman",
      "screen_name" : "tnm",
      "indices" : [ 0, 4 ],
      "id_str" : "77009486",
      "id" : 77009486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217386466408538114",
  "geo" : { },
  "id_str" : "217387201338683392",
  "in_reply_to_user_id" : 77009486,
  "text" : "@tnm Wow. installing now.",
  "id" : 217387201338683392,
  "in_reply_to_status_id" : 217386466408538114,
  "created_at" : "2012-06-25 22:42:02 +0000",
  "in_reply_to_screen_name" : "tnm",
  "in_reply_to_user_id_str" : "77009486",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/oP2xY2BZ",
      "expanded_url" : "http:\/\/developmentseed.org\/blog\/2012\/june\/25\/prose-a-content-editor-for-github\/",
      "display_url" : "developmentseed.org\/blog\/2012\/june\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217384212175667202",
  "text" : "As usual, the stuff people build on top of Jekyll amazes me. http:\/\/t.co\/oP2xY2BZ",
  "id" : 217384212175667202,
  "created_at" : "2012-06-25 22:30:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/s6wxUhM8",
      "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/events\/68784352\/",
      "display_url" : "meetup.com\/Buffalo-Learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217367871372804096",
  "text" : "RT @coworkbuffalo: Buffalo Learning to Code starts at 6:30, every Monday! http:\/\/t.co\/s6wxUhM8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/s6wxUhM8",
        "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/events\/68784352\/",
        "display_url" : "meetup.com\/Buffalo-Learni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217367643701784578",
    "text" : "Buffalo Learning to Code starts at 6:30, every Monday! http:\/\/t.co\/s6wxUhM8",
    "id" : 217367643701784578,
    "created_at" : "2012-06-25 21:24:19 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 217367871372804096,
  "created_at" : "2012-06-25 21:25:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 13, 27 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217260819593969664",
  "geo" : { },
  "id_str" : "217260984593694722",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @joshuaclayton to be honest, thats probably the most logical step, but the most work",
  "id" : 217260984593694722,
  "in_reply_to_status_id" : 217260819593969664,
  "created_at" : "2012-06-25 14:20:29 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217257196235403264",
  "geo" : { },
  "id_str" : "217259939150823424",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton still disagree. Not a fan of code change for someone\u2019s definition of \u201Ccorrectness\u201D.",
  "id" : 217259939150823424,
  "in_reply_to_status_id" : 217257196235403264,
  "created_at" : "2012-06-25 14:16:20 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lrd Vper Deth Scrpin",
      "screen_name" : "JayRWren",
      "indices" : [ 3, 12 ],
      "id_str" : "2190391",
      "id" : 2190391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Bi82IyXO",
      "expanded_url" : "http:\/\/www.linux-magazine.com\/content\/view\/full\/55727",
      "display_url" : "linux-magazine.com\/content\/view\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217257838177812481",
  "text" : "RT @JayRWren: this could be the best article ever published in Linux Magazine, I suggest everyone read it. http:\/\/t.co\/Bi82IyXO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Bi82IyXO",
        "expanded_url" : "http:\/\/www.linux-magazine.com\/content\/view\/full\/55727",
        "display_url" : "linux-magazine.com\/content\/view\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217254599290126336",
    "text" : "this could be the best article ever published in Linux Magazine, I suggest everyone read it. http:\/\/t.co\/Bi82IyXO",
    "id" : 217254599290126336,
    "created_at" : "2012-06-25 13:55:07 +0000",
    "user" : {
      "name" : "Lrd Vper Deth Scrpin",
      "screen_name" : "JayRWren",
      "protected" : false,
      "id_str" : "2190391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512222633820450816\/GRM6kAGQ_normal.jpeg",
      "id" : 2190391,
      "verified" : false
    }
  },
  "id" : 217257838177812481,
  "created_at" : "2012-06-25 14:07:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 15, 26 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217248759111888898",
  "geo" : { },
  "id_str" : "217253603428139008",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @thoughtbot this totally sucks. I\u2019ll basically just copy factory_girl_steps.rb into the projects I need now. -1",
  "id" : 217253603428139008,
  "in_reply_to_status_id" : 217248759111888898,
  "created_at" : "2012-06-25 13:51:10 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ObootMxV",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/06\/25\/opinion\/americas-shameful-human-rights-record.html?_r=1",
      "display_url" : "nytimes.com\/2012\/06\/25\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217249914860740608",
  "text" : "RT @dhh: Jimmy Carter: \"America\u2019s violation of international human rights abets our enemies and alienates our friends\" http:\/\/t.co\/Oboot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/ObootMxV",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/06\/25\/opinion\/americas-shameful-human-rights-record.html?_r=1",
        "display_url" : "nytimes.com\/2012\/06\/25\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217239973571731457",
    "text" : "Jimmy Carter: \"America\u2019s violation of international human rights abets our enemies and alienates our friends\" http:\/\/t.co\/ObootMxV Op-ed NYT",
    "id" : 217239973571731457,
    "created_at" : "2012-06-25 12:57:00 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 217249914860740608,
  "created_at" : "2012-06-25 13:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 12, 22 ],
      "id_str" : "5965482",
      "id" : 5965482
    }, {
      "name" : "emily",
      "screen_name" : "efhorton",
      "indices" : [ 23, 32 ],
      "id_str" : "6146252",
      "id" : 6146252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216962549550297088",
  "geo" : { },
  "id_str" : "217229810504695808",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @jankowski @efhorton! Congrats!",
  "id" : 217229810504695808,
  "in_reply_to_status_id" : 216962549550297088,
  "created_at" : "2012-06-25 12:16:37 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217124812160638976",
  "geo" : { },
  "id_str" : "217151955838054400",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape still fighting the war?",
  "id" : 217151955838054400,
  "in_reply_to_status_id" : 217124812160638976,
  "created_at" : "2012-06-25 07:07:15 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    }, {
      "name" : "Mandi Torrez",
      "screen_name" : "CandiMandi",
      "indices" : [ 14, 25 ],
      "id_str" : "1395782479",
      "id" : 1395782479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217151853153095681",
  "text" : "@stevenhaddox @candimandi thanks! Just going to try a Toyota dealer first\u2026hopefully it will be covered under warranty",
  "id" : 217151853153095681,
  "created_at" : "2012-06-25 07:06:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217147083566755840",
  "text" : "Crashed at a hotel in downtown Akron\u2026need to get the car fixed tomorrow. Woo road trips!",
  "id" : 217147083566755840,
  "created_at" : "2012-06-25 06:47:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217139773607903232",
  "text" : "Cop finally stopped by, was totally nice and called AAA for us. Flatbed showed up finally, on wrong side of the road. :|",
  "id" : 217139773607903232,
  "created_at" : "2012-06-25 06:18:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AAA Ohio",
      "screen_name" : "AAAOhio",
      "indices" : [ 4, 12 ],
      "id_str" : "14296442",
      "id" : 14296442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217136113771491328",
  "text" : "Hey @aaaohio, been waiting over an hour for roadside help tonight. Still stuck. :(",
  "id" : 217136113771491328,
  "created_at" : "2012-06-25 06:04:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217129375563390976",
  "geo" : { },
  "id_str" : "217129846030086145",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek we have a donut\u2026also want to make sure everything is ok before going",
  "id" : 217129846030086145,
  "in_reply_to_status_id" : 217129375563390976,
  "created_at" : "2012-06-25 05:39:24 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/xaeN90Yr",
      "expanded_url" : "http:\/\/instagr.am\/p\/MSQt4tM6h4\/",
      "display_url" : "instagr.am\/p\/MSQt4tM6h4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217129161389641728",
  "text" : "Tire busted and still waiting for help at 31337 mileage. Irony? http:\/\/t.co\/xaeN90Yr",
  "id" : 217129161389641728,
  "created_at" : "2012-06-25 05:36:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217122736105996289",
  "geo" : { },
  "id_str" : "217123411560894464",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten yeah, just tired and bummed.",
  "id" : 217123411560894464,
  "in_reply_to_status_id" : 217122736105996289,
  "created_at" : "2012-06-25 05:13:49 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217122214116474881",
  "text" : "Woo, hit a giant piece of road\/concrete on a bridge outside of Akron\u2026busted, flat tire now.",
  "id" : 217122214116474881,
  "created_at" : "2012-06-25 05:09:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jitka",
      "screen_name" : "jitka22",
      "indices" : [ 3, 11 ],
      "id_str" : "1401004621",
      "id" : 1401004621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217114002420015105",
  "text" : "RT @jitka22: why did they build a highway to the danger zone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56246511671066624",
    "text" : "why did they build a highway to the danger zone",
    "id" : 56246511671066624,
    "created_at" : "2011-04-08 06:46:28 +0000",
    "user" : {
      "name" : "jitka",
      "screen_name" : "jitka",
      "protected" : false,
      "id_str" : "60745484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453046805572231168\/9N1vLly2_normal.jpeg",
      "id" : 60745484,
      "verified" : false
    }
  },
  "id" : 217114002420015105,
  "created_at" : "2012-06-25 04:36:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    }, {
      "name" : "Adam Pumm",
      "screen_name" : "pummer",
      "indices" : [ 11, 18 ],
      "id_str" : "45489027",
      "id" : 45489027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217106125454184448",
  "geo" : { },
  "id_str" : "217108561090711552",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 @pummer about time!",
  "id" : 217108561090711552,
  "in_reply_to_status_id" : 217106125454184448,
  "created_at" : "2012-06-25 04:14:49 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ubiratan Alberton",
      "screen_name" : "mestre_bira",
      "indices" : [ 0, 12 ],
      "id_str" : "65887052",
      "id" : 65887052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217062276874764289",
  "geo" : { },
  "id_str" : "217064501990797312",
  "in_reply_to_user_id" : 65887052,
  "text" : "@mestre_bira not everything yet! Still waiting here.",
  "id" : 217064501990797312,
  "in_reply_to_status_id" : 217062276874764289,
  "created_at" : "2012-06-25 01:19:44 +0000",
  "in_reply_to_screen_name" : "mestre_bira",
  "in_reply_to_user_id_str" : "65887052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217061789991575552",
  "text" : "Phish pulled up people from the pit to dance onstage for Meatstick. Haven\u2019t seen that before!",
  "id" : 217061789991575552,
  "created_at" : "2012-06-25 01:08:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/rvaraO6M",
      "expanded_url" : "http:\/\/instagr.am\/p\/MRo-ffM6rC\/",
      "display_url" : "instagr.am\/p\/MRo-ffM6rC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217041648289452032",
  "text" : "Phish, round 2! http:\/\/t.co\/rvaraO6M",
  "id" : 217041648289452032,
  "created_at" : "2012-06-24 23:48:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217037064846327809",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo where\u2019s your setup? The folks by the mic trees didn\u2019t know where you were",
  "id" : 217037064846327809,
  "created_at" : "2012-06-24 23:30:43 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/lKkrijYu",
      "expanded_url" : "http:\/\/instagr.am\/p\/MRlsRhs6o5\/",
      "display_url" : "instagr.am\/p\/MRlsRhs6o5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217034491275919360",
  "text" : "Further back than yesterday but it will be awesome! http:\/\/t.co\/lKkrijYu",
  "id" : 217034491275919360,
  "created_at" : "2012-06-24 23:20:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryan von",
      "screen_name" : "alifeinwords",
      "indices" : [ 0, 13 ],
      "id_str" : "29196534",
      "id" : 29196534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217033231369908224",
  "geo" : { },
  "id_str" : "217033569497915392",
  "in_reply_to_user_id" : 29196534,
  "text" : "@alifeinwords cuyahoga falls OH",
  "id" : 217033569497915392,
  "in_reply_to_status_id" : 217033231369908224,
  "created_at" : "2012-06-24 23:16:49 +0000",
  "in_reply_to_screen_name" : "alifeinwords",
  "in_reply_to_user_id_str" : "29196534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/mUIMAf6i",
      "expanded_url" : "http:\/\/instagr.am\/p\/MRk_7fs6od\/",
      "display_url" : "instagr.am\/p\/MRk_7fs6od\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.1912500238, -81.5607833862 ]
  },
  "id_str" : "217033085437489152",
  "text" : "Loving the design of this place.  @ Blossom Music Center http:\/\/t.co\/mUIMAf6i",
  "id" : 217033085437489152,
  "created_at" : "2012-06-24 23:14:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 54, 66 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/217032711477542913\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/kW2YupGS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwMOGejCQAAgPCc.jpg",
      "id_str" : "217032711485931520",
      "id" : 217032711485931520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwMOGejCQAAgPCc.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kW2YupGS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217032711477542913",
  "text" : "Fahrenheit taco truck is making a killing at Blossom. @whereslloyd you need to get to some shows! http:\/\/t.co\/kW2YupGS",
  "id" : 217032711477542913,
  "created_at" : "2012-06-24 23:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216974535487008768",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo got your DM, but can't reply! would love at least to say thanks. if not...thanks, you're awesome!",
  "id" : 216974535487008768,
  "created_at" : "2012-06-24 19:22:15 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bcardarelladriving",
      "screen_name" : "bcardarelladriv",
      "indices" : [ 0, 16 ],
      "id_str" : "616463030",
      "id" : 616463030
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 17, 29 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216896115356876800",
  "geo" : { },
  "id_str" : "216896774340747265",
  "in_reply_to_user_id" : 616463030,
  "text" : "@bcardarelladriv @bcardarella what drives to railscamp stays at railscamp",
  "id" : 216896774340747265,
  "in_reply_to_status_id" : 216896115356876800,
  "created_at" : "2012-06-24 14:13:15 +0000",
  "in_reply_to_screen_name" : "bcardarelladriv",
  "in_reply_to_user_id_str" : "616463030",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 40, 46 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 47, 54 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 55, 66 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/O6Db8dpa",
      "expanded_url" : "http:\/\/i46.tinypic.com\/15yzn7k.jpg",
      "display_url" : "i46.tinypic.com\/15yzn7k.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "216896351244517377",
  "text" : "TUCK AND ROLL! http:\/\/t.co\/O6Db8dpa \/cc @cmeik @Croaky @phillapier",
  "id" : 216896351244517377,
  "created_at" : "2012-06-24 14:11:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216774439692546049",
  "text" : "Ears ringing. Neck hurting. Great concert.",
  "id" : 216774439692546049,
  "created_at" : "2012-06-24 06:07:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/Xjrsoudr",
      "expanded_url" : "http:\/\/instagr.am\/p\/MPTwTpM6ue\/",
      "display_url" : "instagr.am\/p\/MPTwTpM6ue\/"
    } ]
  },
  "geo" : { },
  "id_str" : "216713515266875392",
  "text" : "Gotta Jibboo! http:\/\/t.co\/Xjrsoudr",
  "id" : 216713515266875392,
  "created_at" : "2012-06-24 02:05:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 0, 5 ],
      "id_str" : "676573",
      "id" : 676573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216707870887120897",
  "geo" : { },
  "id_str" : "216709023230197760",
  "in_reply_to_user_id" : 676573,
  "text" : "@tobi trailer park boys!",
  "id" : 216709023230197760,
  "in_reply_to_status_id" : 216707870887120897,
  "created_at" : "2012-06-24 01:47:12 +0000",
  "in_reply_to_screen_name" : "tobi",
  "in_reply_to_user_id_str" : "676573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 49, 59 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 83, 97 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216707585393442816",
  "geo" : { },
  "id_str" : "216708615367692288",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik heading to inlaws\u2019 after up north. @aquaranto and I will be back for @SteelCityRuby",
  "id" : 216708615367692288,
  "in_reply_to_status_id" : 216707585393442816,
  "created_at" : "2012-06-24 01:45:34 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 54, 68 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216706420471640064",
  "geo" : { },
  "id_str" : "216706566823489536",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette @steveklabnik cool! You should drop by @coworkbuffalo",
  "id" : 216706566823489536,
  "in_reply_to_status_id" : 216706420471640064,
  "created_at" : "2012-06-24 01:37:26 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216698452346802176",
  "geo" : { },
  "id_str" : "216706244856127488",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik yeah for the show. Buffalo isn\u2019t that far!",
  "id" : 216706244856127488,
  "in_reply_to_status_id" : 216698452346802176,
  "created_at" : "2012-06-24 01:36:09 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/iQaeg5Vt",
      "expanded_url" : "http:\/\/instagr.am\/p\/MPMq-zM6p8\/",
      "display_url" : "instagr.am\/p\/MPMq-zM6p8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4197040373, -80.4341697693 ]
  },
  "id_str" : "216698003057160192",
  "text" : "Page hitting the theramin!  @ First Niagara Pavilion http:\/\/t.co\/iQaeg5Vt",
  "id" : 216698003057160192,
  "created_at" : "2012-06-24 01:03:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/IaKKWNRA",
      "expanded_url" : "http:\/\/instagr.am\/p\/MPG58MM6mX\/",
      "display_url" : "instagr.am\/p\/MPG58MM6mX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4197040373, -80.4341697693 ]
  },
  "id_str" : "216685261923422209",
  "text" : "Phish!  @ First Niagara Pavilion http:\/\/t.co\/IaKKWNRA",
  "id" : 216685261923422209,
  "created_at" : "2012-06-24 00:12:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216678733740916737",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo hey dude! Where\u2019s your setup?",
  "id" : 216678733740916737,
  "created_at" : "2012-06-23 23:46:50 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/y4uSR252",
      "expanded_url" : "http:\/\/instagr.am\/p\/MPDx1_M6j6\/",
      "display_url" : "instagr.am\/p\/MPDx1_M6j6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.4197040373, -80.4341697693 ]
  },
  "id_str" : "216678578677485568",
  "text" : "Closest seat ever for Phish. Woot!!!  @ First Niagara Pavilion http:\/\/t.co\/y4uSR252",
  "id" : 216678578677485568,
  "created_at" : "2012-06-23 23:46:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216525216556400642",
  "geo" : { },
  "id_str" : "216525383338700800",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy it was the magic loogie bird poop, Jerry!",
  "id" : 216525383338700800,
  "in_reply_to_status_id" : 216525216556400642,
  "created_at" : "2012-06-23 13:37:28 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216519266336374784",
  "geo" : { },
  "id_str" : "216524383127216131",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy that is the worst.",
  "id" : 216524383127216131,
  "in_reply_to_status_id" : 216519266336374784,
  "created_at" : "2012-06-23 13:33:30 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth DeLoria",
      "screen_name" : "elizabethdanger",
      "indices" : [ 3, 19 ],
      "id_str" : "25274516",
      "id" : 25274516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216417772094226434",
  "text" : "RT @elizabethdanger: Please RT this if you are or know a female programmer in the US. Proving a point here.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215886997074624512",
    "text" : "Please RT this if you are or know a female programmer in the US. Proving a point here.",
    "id" : 215886997074624512,
    "created_at" : "2012-06-21 19:20:45 +0000",
    "user" : {
      "name" : "Elizabeth DeLoria",
      "screen_name" : "elizabethdanger",
      "protected" : false,
      "id_str" : "25274516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562471542710222849\/zrimBcwA_normal.jpeg",
      "id" : 25274516,
      "verified" : false
    }
  },
  "id" : 216417772094226434,
  "created_at" : "2012-06-23 06:29:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 10, 22 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216400864309559296",
  "text" : "BREAKING: @whereslloyd tacos are delicious.",
  "id" : 216400864309559296,
  "created_at" : "2012-06-23 05:22:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 28, 33 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/1lBxlaMb",
      "expanded_url" : "http:\/\/instagr.am\/p\/MMzYRAs6pl\/",
      "display_url" : "instagr.am\/p\/MMzYRAs6pl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "216360924796293120",
  "text" : "Finally playing Smallworld! @wilw would be proud. http:\/\/t.co\/1lBxlaMb",
  "id" : 216360924796293120,
  "created_at" : "2012-06-23 02:43:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216311859198967809",
  "geo" : { },
  "id_str" : "216318923535159296",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape haha\u2026Ged destroys everything in his path toy wise that isn\u2019t hard plastic or bone.",
  "id" : 216318923535159296,
  "in_reply_to_status_id" : 216311859198967809,
  "created_at" : "2012-06-22 23:57:05 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 3, 10 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216309987859894274",
  "text" : "RT @Croaky: technicolor founder &gt; technical cofounder",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216309213952081922",
    "text" : "technicolor founder &gt; technical cofounder",
    "id" : 216309213952081922,
    "created_at" : "2012-06-22 23:18:30 +0000",
    "user" : {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "protected" : false,
      "id_str" : "787595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568676101967196160\/nP3jFRbr_normal.jpeg",
      "id" : 787595,
      "verified" : false
    }
  },
  "id" : 216309987859894274,
  "created_at" : "2012-06-22 23:21:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216309339416309760",
  "geo" : { },
  "id_str" : "216309930918023169",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape kongs and elk horns only.",
  "id" : 216309930918023169,
  "in_reply_to_status_id" : 216309339416309760,
  "created_at" : "2012-06-22 23:21:21 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216238632317620226",
  "geo" : { },
  "id_str" : "216238820952256513",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer nah, it was my fault. didn't check the date :) someday I'll get this growler refilled.",
  "id" : 216238820952256513,
  "in_reply_to_status_id" : 216238632317620226,
  "created_at" : "2012-06-22 18:38:47 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216238632317620226",
  "geo" : { },
  "id_str" : "216238720305741824",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer ah crap!",
  "id" : 216238720305741824,
  "in_reply_to_status_id" : 216238632317620226,
  "created_at" : "2012-06-22 18:38:23 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Littlelines on Rails",
      "screen_name" : "littlelines",
      "indices" : [ 0, 12 ],
      "id_str" : "22043483",
      "id" : 22043483
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 13, 27 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "Four Ambition",
      "screen_name" : "fourambition",
      "indices" : [ 28, 41 ],
      "id_str" : "60111145",
      "id" : 60111145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216238142204805121",
  "geo" : { },
  "id_str" : "216238655520509953",
  "in_reply_to_user_id" : 22043483,
  "text" : "@littlelines @SteelCityRuby @fourambition this looks awesome, and i'm glad it's not Steelers colors.",
  "id" : 216238655520509953,
  "in_reply_to_status_id" : 216238142204805121,
  "created_at" : "2012-06-22 18:38:07 +0000",
  "in_reply_to_screen_name" : "littlelines",
  "in_reply_to_user_id_str" : "22043483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215886246512300032",
  "geo" : { },
  "id_str" : "216238467045277697",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer Heck yes. Stopping by!",
  "id" : 216238467045277697,
  "in_reply_to_status_id" : 215886246512300032,
  "created_at" : "2012-06-22 18:37:22 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216220939011108864",
  "geo" : { },
  "id_str" : "216222132122824704",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh it\u2019s more of a necessity than an itch most times!",
  "id" : 216222132122824704,
  "in_reply_to_status_id" : 216220939011108864,
  "created_at" : "2012-06-22 17:32:28 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216221977759846403",
  "text" : "RT @dhh: The itch to ship software is a powerful force.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216220939011108864",
    "text" : "The itch to ship software is a powerful force.",
    "id" : 216220939011108864,
    "created_at" : "2012-06-22 17:27:43 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 216221977759846403,
  "created_at" : "2012-06-22 17:31:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216202931836436480",
  "geo" : { },
  "id_str" : "216214815495045120",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten yep!",
  "id" : 216214815495045120,
  "in_reply_to_status_id" : 216202931836436480,
  "created_at" : "2012-06-22 17:03:23 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitchell Silver",
      "screen_name" : "mitchell_silver",
      "indices" : [ 3, 19 ],
      "id_str" : "282720664",
      "id" : 282720664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cityreads",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/cQ9p7W3f",
      "expanded_url" : "http:\/\/rustwire.com\/2011\/03\/11\/michigan-business-owner-soul-crushing-sprawl-driving-us-away\/",
      "display_url" : "rustwire.com\/2011\/03\/11\/mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216194324143157248",
  "text" : "RT @mitchell_silver: Here is the link. Michigan CEO: Soul-Crushing Sprawl Killing Business http:\/\/t.co\/cQ9p7W3f #cityreads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cityreads",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/cQ9p7W3f",
        "expanded_url" : "http:\/\/rustwire.com\/2011\/03\/11\/michigan-business-owner-soul-crushing-sprawl-driving-us-away\/",
        "display_url" : "rustwire.com\/2011\/03\/11\/mic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "215651672830132226",
    "text" : "Here is the link. Michigan CEO: Soul-Crushing Sprawl Killing Business http:\/\/t.co\/cQ9p7W3f #cityreads",
    "id" : 215651672830132226,
    "created_at" : "2012-06-21 03:45:40 +0000",
    "user" : {
      "name" : "Mitchell Silver",
      "screen_name" : "mitchell_silver",
      "protected" : false,
      "id_str" : "282720664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1851798093\/mitchAPA_normal.jpg",
      "id" : 282720664,
      "verified" : false
    }
  },
  "id" : 216194324143157248,
  "created_at" : "2012-06-22 15:41:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Krause",
      "screen_name" : "EricKrause",
      "indices" : [ 0, 11 ],
      "id_str" : "16146696",
      "id" : 16146696
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 29, 39 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216178763065597954",
  "geo" : { },
  "id_str" : "216179634851680256",
  "in_reply_to_user_id" : 16146696,
  "text" : "@EricKrause still waiting on @confreaks for it\u2026thanks though!",
  "id" : 216179634851680256,
  "in_reply_to_status_id" : 216178763065597954,
  "created_at" : "2012-06-22 14:43:36 +0000",
  "in_reply_to_screen_name" : "EricKrause",
  "in_reply_to_user_id_str" : "16146696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 33, 41 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215982973617577985",
  "text" : "Maybe instead of \u201Ccascading bug\u201D @twitter could have actually admitted what went wrong. Such crap.",
  "id" : 215982973617577985,
  "created_at" : "2012-06-22 01:42:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215970516262076416",
  "text" : "I am apparently incapable of making full Instagram comments today.",
  "id" : 215970516262076416,
  "created_at" : "2012-06-22 00:52:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215965333129928704",
  "geo" : { },
  "id_str" : "215969334755987456",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything it\u2019s wonderful.",
  "id" : 215969334755987456,
  "in_reply_to_status_id" : 215965333129928704,
  "created_at" : "2012-06-22 00:47:56 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215954551088492544",
  "geo" : { },
  "id_str" : "215956027206680576",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil you can make it happen with _.extend",
  "id" : 215956027206680576,
  "in_reply_to_status_id" : 215954551088492544,
  "created_at" : "2012-06-21 23:55:03 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/pnTCT0WU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vY_Ry8J_jdw",
      "display_url" : "youtube.com\/watch?v=vY_Ry8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215891232386318336",
  "text" : "Current status: http:\/\/t.co\/pnTCT0WU",
  "id" : 215891232386318336,
  "created_at" : "2012-06-21 19:37:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215881761421410304",
  "geo" : { },
  "id_str" : "215882274003095553",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden stop tweeting and just ride your bike!",
  "id" : 215882274003095553,
  "in_reply_to_status_id" : 215881761421410304,
  "created_at" : "2012-06-21 19:01:59 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 0, 7 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/bcfHtT1G",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-FucbvoFFy0",
      "display_url" : "youtube.com\/watch?v=-Fucbv\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "215856771531673604",
  "geo" : { },
  "id_str" : "215870449043783680",
  "in_reply_to_user_id" : 14381877,
  "text" : "@gustin http:\/\/t.co\/bcfHtT1G",
  "id" : 215870449043783680,
  "in_reply_to_status_id" : 215856771531673604,
  "created_at" : "2012-06-21 18:15:00 +0000",
  "in_reply_to_screen_name" : "gustin",
  "in_reply_to_user_id_str" : "14381877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevan MacGee",
      "screen_name" : "kevanmacgee",
      "indices" : [ 0, 12 ],
      "id_str" : "263450469",
      "id" : 263450469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215858718263349248",
  "geo" : { },
  "id_str" : "215870320161198080",
  "in_reply_to_user_id" : 263450469,
  "text" : "@kevanmacgee nice dude! Yeah, was considering SPAC but it's a longer drive.",
  "id" : 215870320161198080,
  "in_reply_to_status_id" : 215858718263349248,
  "created_at" : "2012-06-21 18:14:29 +0000",
  "in_reply_to_screen_name" : "kevanmacgee",
  "in_reply_to_user_id_str" : "263450469",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215858002341806080",
  "geo" : { },
  "id_str" : "215869017947254785",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo awesome, same here! offer still stands, at least would like to say hi!",
  "id" : 215869017947254785,
  "in_reply_to_status_id" : 215858002341806080,
  "created_at" : "2012-06-21 18:09:19 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215854183339933696",
  "geo" : { },
  "id_str" : "215861811386384385",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej is this a joke?",
  "id" : 215861811386384385,
  "in_reply_to_status_id" : 215854183339933696,
  "created_at" : "2012-06-21 17:40:41 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215855057919426560",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo are you going to be at the shows this weekend? I owe you a beer for these awesome videos.",
  "id" : 215855057919426560,
  "created_at" : "2012-06-21 17:13:50 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gustin",
      "screen_name" : "gustin",
      "indices" : [ 0, 7 ],
      "id_str" : "14381877",
      "id" : 14381877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/fTX54xtT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=AqEzcoCyK-A&feature=bf_next&list=PLA90ECCCF2B6F7F78",
      "display_url" : "youtube.com\/watch?v=AqEzco\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "215854256203382785",
  "geo" : { },
  "id_str" : "215854529403564032",
  "in_reply_to_user_id" : 14381877,
  "text" : "@gustin no joke, http:\/\/t.co\/fTX54xtT comes up as you tweet this.",
  "id" : 215854529403564032,
  "in_reply_to_status_id" : 215854256203382785,
  "created_at" : "2012-06-21 17:11:44 +0000",
  "in_reply_to_screen_name" : "gustin",
  "in_reply_to_user_id_str" : "14381877",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215816713374142464",
  "text" : "Ridiculously excited for this weekend. Hitting two Phish shows in OH and PA!",
  "id" : 215816713374142464,
  "created_at" : "2012-06-21 14:41:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/EBTZmyk3",
      "expanded_url" : "http:\/\/instagr.am\/p\/MI2fMhs6vf\/",
      "display_url" : "instagr.am\/p\/MI2fMhs6vf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "215804790079365121",
  "text" : "General Bidwell looking awesome as usual. http:\/\/t.co\/EBTZmyk3",
  "id" : 215804790079365121,
  "created_at" : "2012-06-21 13:54:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215600921109995521",
  "text" : "@stevenhaddox at this point I doubt it\u2019s going to launch.",
  "id" : 215600921109995521,
  "created_at" : "2012-06-21 00:23:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215599994420477952",
  "geo" : { },
  "id_str" : "215600078126202880",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic just did a big bike ride with the dog. And Lloyd\u2019s.",
  "id" : 215600078126202880,
  "in_reply_to_status_id" : 215599994420477952,
  "created_at" : "2012-06-21 00:20:38 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryan von",
      "screen_name" : "alifeinwords",
      "indices" : [ 0, 13 ],
      "id_str" : "29196534",
      "id" : 29196534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215587322031382530",
  "geo" : { },
  "id_str" : "215591858859016194",
  "in_reply_to_user_id" : 29196534,
  "text" : "@alifeinwords just got a burrito. Up!",
  "id" : 215591858859016194,
  "in_reply_to_status_id" : 215587322031382530,
  "created_at" : "2012-06-20 23:47:59 +0000",
  "in_reply_to_screen_name" : "alifeinwords",
  "in_reply_to_user_id_str" : "29196534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/l0aGbca2",
      "expanded_url" : "http:\/\/instagr.am\/p\/MHTbCsM6o4\/",
      "display_url" : "instagr.am\/p\/MHTbCsM6o4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "215586896275972097",
  "text" : "Dos! http:\/\/t.co\/l0aGbca2",
  "id" : 215586896275972097,
  "created_at" : "2012-06-20 23:28:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/PukVOQEq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=B44LZjmeOWg",
      "display_url" : "youtube.com\/watch?v=B44LZj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215546394386243584",
  "text" : "Current status: http:\/\/t.co\/PukVOQEq",
  "id" : 215546394386243584,
  "created_at" : "2012-06-20 20:47:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 36, 49 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 54, 65 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215502229027827713",
  "text" : "Starting to feel the same rage that @steveklabnik and @ashedryden talk about constantly. Not sure what to do about it other than stew.",
  "id" : 215502229027827713,
  "created_at" : "2012-06-20 17:51:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215494389588434947",
  "geo" : { },
  "id_str" : "215494973422972928",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes wait, they remade the Heroku Garden?",
  "id" : 215494973422972928,
  "in_reply_to_status_id" : 215494389588434947,
  "created_at" : "2012-06-20 17:23:00 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215488976923009024",
  "geo" : { },
  "id_str" : "215489065552838657",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything WHAT HO!",
  "id" : 215489065552838657,
  "in_reply_to_status_id" : 215488976923009024,
  "created_at" : "2012-06-20 16:59:31 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 0, 9 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215486025345146880",
  "geo" : { },
  "id_str" : "215486257772494849",
  "in_reply_to_user_id" : 16450420,
  "text" : "@ivyhurst \"The driver was unhurt but the beer is considered a total loss.\" pretty sure it started that way",
  "id" : 215486257772494849,
  "in_reply_to_status_id" : 215486025345146880,
  "created_at" : "2012-06-20 16:48:22 +0000",
  "in_reply_to_screen_name" : "ivyhurst",
  "in_reply_to_user_id_str" : "16450420",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Ko",
      "screen_name" : "justinko",
      "indices" : [ 64, 73 ],
      "id_str" : "23165791",
      "id" : 23165791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215480952707751936",
  "text" : "I wish there was a \"silence fucking moron\" function on Twitter. @justinko wins this award today for blatant sexism and misogyny.",
  "id" : 215480952707751936,
  "created_at" : "2012-06-20 16:27:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 20, 34 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215454370857353219",
  "text" : "Really happy to see @coworkbuffalo filled with coworkers today. Been a while in the making, and it's finally come together!",
  "id" : 215454370857353219,
  "created_at" : "2012-06-20 14:41:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "215451163405991938",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Gipsy Kings: Hotel California \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 215451163405991938,
  "created_at" : "2012-06-20 14:28:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 11, 21 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 22, 33 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215437205517246467",
  "geo" : { },
  "id_str" : "215438180680339456",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @aspleenic @kevinpurdy I\u2019ll bike down now. Be there in 15",
  "id" : 215438180680339456,
  "in_reply_to_status_id" : 215437205517246467,
  "created_at" : "2012-06-20 13:37:19 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215434952848850945",
  "geo" : { },
  "id_str" : "215435840711688192",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton this hustle to the station is what I hated the most about the MBCR",
  "id" : 215435840711688192,
  "in_reply_to_status_id" : 215434952848850945,
  "created_at" : "2012-06-20 13:28:01 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215434161870209024",
  "geo" : { },
  "id_str" : "215434310226948098",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton did you miss one?",
  "id" : 215434310226948098,
  "in_reply_to_status_id" : 215434161870209024,
  "created_at" : "2012-06-20 13:21:56 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215422586081910784",
  "geo" : { },
  "id_str" : "215425797228470273",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg breakfast of champions",
  "id" : 215425797228470273,
  "in_reply_to_status_id" : 215422586081910784,
  "created_at" : "2012-06-20 12:48:07 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215271664890556418",
  "geo" : { },
  "id_str" : "215271879131402240",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten jalappennos. i'm not good at the booklearnin's and stuffs, alright? frig off.",
  "id" : 215271879131402240,
  "in_reply_to_status_id" : 215271664890556418,
  "created_at" : "2012-06-20 02:36:30 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 25, 37 ],
      "id_str" : "156689065",
      "id" : 156689065
    }, {
      "name" : "Wegmans Food Markets",
      "screen_name" : "Wegmans",
      "indices" : [ 54, 62 ],
      "id_str" : "66482863",
      "id" : 66482863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215244568902369282",
  "text" : "Picked up two bottles of @whereslloyd Rocket Sauce at @Wegmans. Woot!",
  "id" : 215244568902369282,
  "created_at" : "2012-06-20 00:47:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215215825412562946",
  "geo" : { },
  "id_str" : "215244426665132033",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant nice dude! Rework is good too.",
  "id" : 215244426665132033,
  "in_reply_to_status_id" : 215215825412562946,
  "created_at" : "2012-06-20 00:47:25 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 38 ],
      "url" : "https:\/\/t.co\/5OvfU6Ui",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/rbenv",
      "display_url" : "github.com\/sstephenson\/rb\u2026"
    }, {
      "indices" : [ 39, 60 ],
      "url" : "https:\/\/t.co\/PVK3veqM",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/ruby-build",
      "display_url" : "github.com\/sstephenson\/ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "215186598566965251",
  "geo" : { },
  "id_str" : "215192857466773504",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan use: https:\/\/t.co\/5OvfU6Ui https:\/\/t.co\/PVK3veqM. homebrew has both.",
  "id" : 215192857466773504,
  "in_reply_to_status_id" : 215186598566965251,
  "created_at" : "2012-06-19 21:22:29 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215191294228705280",
  "geo" : { },
  "id_str" : "215192282738073600",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps I don't relate to this at all. I can't be the only one in this age bracket like this.",
  "id" : 215192282738073600,
  "in_reply_to_status_id" : 215191294228705280,
  "created_at" : "2012-06-19 21:20:12 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "215111833785344000",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Men At Work: Down Under \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 215111833785344000,
  "created_at" : "2012-06-19 16:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 3, 12 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214944810354745345",
  "text" : "RT @hgimenez: In 15 years email will just be called mail.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214931849292689410",
    "text" : "In 15 years email will just be called mail.",
    "id" : 214931849292689410,
    "created_at" : "2012-06-19 04:05:20 +0000",
    "user" : {
      "name" : "Harold Gim\u00E9nez",
      "screen_name" : "hgmnz",
      "protected" : false,
      "id_str" : "24425454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491047783214747648\/6czBp_vy_normal.jpeg",
      "id" : 24425454,
      "verified" : false
    }
  },
  "id" : 214944810354745345,
  "created_at" : "2012-06-19 04:56:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214896205996634112",
  "geo" : { },
  "id_str" : "214902233899343873",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Jekyll was really just a gateway drug to OSS for me.",
  "id" : 214902233899343873,
  "in_reply_to_status_id" : 214896205996634112,
  "created_at" : "2012-06-19 02:07:39 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214894251316740097",
  "geo" : { },
  "id_str" : "214895941931634688",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten booyah!",
  "id" : 214895941931634688,
  "in_reply_to_status_id" : 214894251316740097,
  "created_at" : "2012-06-19 01:42:39 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "indices" : [ 3, 11 ],
      "id_str" : "15201409",
      "id" : 15201409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214859631418290177",
  "text" : "RT @tcollen: \"Working Effectively With Legacy Code\" should just be 300 pages of a picture of a bottle of whiskey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190251190687252480",
    "text" : "\"Working Effectively With Legacy Code\" should just be 300 pages of a picture of a bottle of whiskey",
    "id" : 190251190687252480,
    "created_at" : "2012-04-12 01:33:13 +0000",
    "user" : {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "protected" : false,
      "id_str" : "15201409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528718033217650689\/aIOVuQ4i_normal.jpeg",
      "id" : 15201409,
      "verified" : false
    }
  },
  "id" : 214859631418290177,
  "created_at" : "2012-06-18 23:18:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "214771175912509440",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Project Blue Book: Get On The Bus \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 214771175912509440,
  "created_at" : "2012-06-18 17:26:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/mqoqRJUX",
      "expanded_url" : "http:\/\/photon.attasi.com\/",
      "display_url" : "photon.attasi.com"
    } ]
  },
  "geo" : { },
  "id_str" : "214734263042584577",
  "text" : "Wow. http:\/\/t.co\/mqoqRJUX",
  "id" : 214734263042584577,
  "created_at" : "2012-06-18 15:00:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214730053039296512",
  "geo" : { },
  "id_str" : "214730282811666432",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten alias mkdir='mkdir -p'",
  "id" : 214730282811666432,
  "in_reply_to_status_id" : 214730053039296512,
  "created_at" : "2012-06-18 14:44:23 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/4om8D6d5",
      "expanded_url" : "http:\/\/www.meetup.com\/Buffalo-Learning-to-Code\/events\/68784352\/",
      "display_url" : "meetup.com\/Buffalo-Learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214729775187632129",
  "text" : "Buffalo Learning to Code is tonight at @coworkbuffalo! http:\/\/t.co\/4om8D6d5",
  "id" : 214729775187632129,
  "created_at" : "2012-06-18 14:42:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Clark",
      "screen_name" : "iamcraigclark",
      "indices" : [ 0, 14 ],
      "id_str" : "7903742",
      "id" : 7903742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/cRSDmR4h",
      "expanded_url" : "http:\/\/github.com\/37signals\/bcx-api",
      "display_url" : "github.com\/37signals\/bcx-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "214697363602800641",
  "geo" : { },
  "id_str" : "214700685680312321",
  "in_reply_to_user_id" : 7903742,
  "text" : "@iamcraigclark it\u2019s been out for a while! The docs are at http:\/\/t.co\/cRSDmR4h",
  "id" : 214700685680312321,
  "in_reply_to_status_id" : 214697363602800641,
  "created_at" : "2012-06-18 12:46:47 +0000",
  "in_reply_to_screen_name" : "iamcraigclark",
  "in_reply_to_user_id_str" : "7903742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 3, 15 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/vRcXFUcW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SBzRmWeC6Ds",
      "display_url" : "youtube.com\/watch?v=SBzRmW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214347534032846848",
  "text" : "RT @SteveStreza: And then this happened. http:\/\/t.co\/vRcXFUcW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/vRcXFUcW",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SBzRmWeC6Ds",
        "display_url" : "youtube.com\/watch?v=SBzRmW\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "214231646403178496",
    "text" : "And then this happened. http:\/\/t.co\/vRcXFUcW",
    "id" : 214231646403178496,
    "created_at" : "2012-06-17 05:42:59 +0000",
    "user" : {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "protected" : false,
      "id_str" : "658643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540811650727550976\/b7RvPDiF_normal.jpeg",
      "id" : 658643,
      "verified" : false
    }
  },
  "id" : 214347534032846848,
  "created_at" : "2012-06-17 13:23:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214165716214104064",
  "text" : "I\u2019m quaranto on iOS game center too\u2026someone must have taken qrush :(",
  "id" : 214165716214104064,
  "created_at" : "2012-06-17 01:21:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214165524962217986",
  "text" : "Starting a flight crew for Pocket planes: Ruby. Anyone else addicted to this already?",
  "id" : 214165524962217986,
  "created_at" : "2012-06-17 01:20:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/0FFMdUdw",
      "expanded_url" : "http:\/\/1940srecipes.tumblr.com\/",
      "display_url" : "1940srecipes.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "214093544091164672",
  "text" : "RT @aquaranto: I started a new project: http:\/\/t.co\/0FFMdUdw. I found an old recipe book filled with clipped recipes. I'll be posting ne ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/0FFMdUdw",
        "expanded_url" : "http:\/\/1940srecipes.tumblr.com\/",
        "display_url" : "1940srecipes.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "214093437593583617",
    "text" : "I started a new project: http:\/\/t.co\/0FFMdUdw. I found an old recipe book filled with clipped recipes. I'll be posting new recipes often!!",
    "id" : 214093437593583617,
    "created_at" : "2012-06-16 20:33:47 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 214093544091164672,
  "created_at" : "2012-06-16 20:34:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214058153153806336",
  "geo" : { },
  "id_str" : "214059608648589312",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer dang. Any retail hours early this week?",
  "id" : 214059608648589312,
  "in_reply_to_status_id" : 214058153153806336,
  "created_at" : "2012-06-16 18:19:22 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TrU8rw8X",
      "expanded_url" : "http:\/\/4sq.com\/KaHcnc",
      "display_url" : "4sq.com\/KaHcnc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8967059, -78.878431 ]
  },
  "id_str" : "214056619158405121",
  "text" : "Getting blunched! (@ Betty's Restaurant) [pic]: http:\/\/t.co\/TrU8rw8X",
  "id" : 214056619158405121,
  "created_at" : "2012-06-16 18:07:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214032986906165250",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer did you guys run out of beer? You disappeared from Bidwell before 1pm :(",
  "id" : 214032986906165250,
  "created_at" : "2012-06-16 16:33:35 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan Ensari",
      "screen_name" : "hakanensari",
      "indices" : [ 0, 12 ],
      "id_str" : "15325245",
      "id" : 15325245
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 79, 87 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213219421001494531",
  "geo" : { },
  "id_str" : "214028833559552000",
  "in_reply_to_user_id" : 15325245,
  "text" : "@hakanensari huge load problems on the server. maybe we can re-enable now? \/cc @evanphx",
  "id" : 214028833559552000,
  "in_reply_to_status_id" : 213219421001494531,
  "created_at" : "2012-06-16 16:17:05 +0000",
  "in_reply_to_screen_name" : "hakanensari",
  "in_reply_to_user_id_str" : "15325245",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 15, 24 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 43, 50 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213682265849475073",
  "geo" : { },
  "id_str" : "214028755830706177",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette @rubygems good question for @lsegal ...anything up?",
  "id" : 214028755830706177,
  "in_reply_to_status_id" : 213682265849475073,
  "created_at" : "2012-06-16 16:16:46 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 29, 43 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/eUJzFqhC",
      "expanded_url" : "https:\/\/tinyletter.com\/coworkbuffalo",
      "display_url" : "tinyletter.com\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "214028625996038145",
  "text" : "RT @kevinpurdy: Subscribe to @CoworkBuffalo's 1x\/month newsletter to hear what's happening\u2014and discover our free work days\/meetups: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 13, 27 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 137 ],
        "url" : "https:\/\/t.co\/eUJzFqhC",
        "expanded_url" : "https:\/\/tinyletter.com\/coworkbuffalo",
        "display_url" : "tinyletter.com\/coworkbuffalo"
      } ]
    },
    "geo" : { },
    "id_str" : "214014420739825664",
    "text" : "Subscribe to @CoworkBuffalo's 1x\/month newsletter to hear what's happening\u2014and discover our free work days\/meetups: https:\/\/t.co\/eUJzFqhC",
    "id" : 214014420739825664,
    "created_at" : "2012-06-16 15:19:48 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 214028625996038145,
  "created_at" : "2012-06-16 16:16:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryan von",
      "screen_name" : "alifeinwords",
      "indices" : [ 0, 13 ],
      "id_str" : "29196534",
      "id" : 29196534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/9h3Fuuyq",
      "expanded_url" : "http:\/\/amzn.com\/B006CVAW7C",
      "display_url" : "amzn.com\/B006CVAW7C"
    } ]
  },
  "in_reply_to_status_id_str" : "214026219719622657",
  "geo" : { },
  "id_str" : "214027769473011712",
  "in_reply_to_user_id" : 29196534,
  "text" : "@alifeinwords $6 carabiner + bungee cord, and a good, strong leash. http:\/\/t.co\/9h3Fuuyq",
  "id" : 214027769473011712,
  "in_reply_to_status_id" : 214026219719622657,
  "created_at" : "2012-06-16 16:12:51 +0000",
  "in_reply_to_screen_name" : "alifeinwords",
  "in_reply_to_user_id_str" : "29196534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214023460312199168",
  "text" : "Couldn\u2019t picture us biking with Ged a year ago when we got him. Such a huge difference.",
  "id" : 214023460312199168,
  "created_at" : "2012-06-16 15:55:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214023270440251393",
  "text" : "Both humans and dog did awesome!",
  "id" : 214023270440251393,
  "created_at" : "2012-06-16 15:54:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 23, 33 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214023171198816256",
  "text" : "5+ mile bike ride with @aquaranto and our now very exhausted husky.",
  "id" : 214023171198816256,
  "created_at" : "2012-06-16 15:54:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    }, {
      "name" : "Jay Tennier",
      "screen_name" : "jaytennier",
      "indices" : [ 6, 17 ],
      "id_str" : "15020118",
      "id" : 15020118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/yJG4AWGY",
      "expanded_url" : "http:\/\/groups.google.com\/group\/buffalo-opencoffee-club",
      "display_url" : "groups.google.com\/group\/buffalo-\u2026"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/OYHmmgLA",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "213985774041964545",
  "geo" : { },
  "id_str" : "213997194406133760",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y @jaytennier agreed! Maybe you can come to Buffalo Open Coffee\/Beer  or WNYRuby! http:\/\/t.co\/yJG4AWGY http:\/\/t.co\/OYHmmgLA",
  "id" : 213997194406133760,
  "in_reply_to_status_id" : 213985774041964545,
  "created_at" : "2012-06-16 14:11:21 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 62, 67 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213993577913647106",
  "text" : "Finally reinstalled Foursquare. Otherwise known in Buffalo as @popo square.",
  "id" : 213993577913647106,
  "created_at" : "2012-06-16 13:56:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/k34Pr0VS",
      "expanded_url" : "http:\/\/4sq.com\/LTJHQ5",
      "display_url" : "4sq.com\/LTJHQ5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9811907, -78.8449183 ]
  },
  "id_str" : "213846401761816576",
  "text" : "No tightrope over this Falls. (@ Adventure Landing) [pic]: http:\/\/t.co\/k34Pr0VS",
  "id" : 213846401761816576,
  "created_at" : "2012-06-16 04:12:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213824304821960704",
  "text" : "If only the border agents would force Wallenda to turn around\u2026",
  "id" : 213824304821960704,
  "created_at" : "2012-06-16 02:44:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213822956550365184",
  "text" : "Still can\u2019t believe they\u2019re talking to him on the wire. Leave the guy alone, holy shit.",
  "id" : 213822956550365184,
  "created_at" : "2012-06-16 02:39:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213815879266336768",
  "text" : "Insurance commercials right before death defying walk: ironic?",
  "id" : 213815879266336768,
  "created_at" : "2012-06-16 02:10:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 3, 12 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "WalkTheWire",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213815345478238209",
  "text" : "RT @ivyhurst: If Nick Walenda were a real daredevil, he'd walk through the east side of #Buffalo at 10pm without a harness. #WalkTheWire",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 74, 82 ]
      }, {
        "text" : "WalkTheWire",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213813480501940224",
    "text" : "If Nick Walenda were a real daredevil, he'd walk through the east side of #Buffalo at 10pm without a harness. #WalkTheWire",
    "id" : 213813480501940224,
    "created_at" : "2012-06-16 02:01:20 +0000",
    "user" : {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "protected" : false,
      "id_str" : "16450420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046828495\/faf20934e2c12bc4d6a562b38c193d0f_normal.jpeg",
      "id" : 16450420,
      "verified" : false
    }
  },
  "id" : 213815345478238209,
  "created_at" : "2012-06-16 02:08:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 3, 12 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalkTheWire",
      "indices" : [ 117, 129 ]
    }, {
      "text" : "NotKidding",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213815212816605184",
  "text" : "RT @ivyhurst: It's much more dangerous to walk alone in downtown Niagara Falls at night on the US side than it is to #WalkTheWire   #Not ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WalkTheWire",
        "indices" : [ 103, 115 ]
      }, {
        "text" : "NotKidding",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213814299141996544",
    "text" : "It's much more dangerous to walk alone in downtown Niagara Falls at night on the US side than it is to #WalkTheWire   #NotKidding",
    "id" : 213814299141996544,
    "created_at" : "2012-06-16 02:04:36 +0000",
    "user" : {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "protected" : false,
      "id_str" : "16450420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046828495\/faf20934e2c12bc4d6a562b38c193d0f_normal.jpeg",
      "id" : 16450420,
      "verified" : false
    }
  },
  "id" : 213815212816605184,
  "created_at" : "2012-06-16 02:08:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213814889922297856",
  "text" : "Full disclosure: my dad is a Niagara Falls firefighter. Staying way away from this nonsense.",
  "id" : 213814889922297856,
  "created_at" : "2012-06-16 02:06:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213814734011629568",
  "text" : "There\u2019s something sick behind watching Wallenda walk. I just hope no\nfirefighters or other emergency personnel get hurt helping him.",
  "id" : 213814734011629568,
  "created_at" : "2012-06-16 02:06:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213787935919706112",
  "geo" : { },
  "id_str" : "213800556836302848",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan The Ruby Way is a really good book too. I can lend!",
  "id" : 213800556836302848,
  "in_reply_to_status_id" : 213787935919706112,
  "created_at" : "2012-06-16 01:09:59 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/sLKAst6E",
      "expanded_url" : "http:\/\/pine.fm\/learntoprogram",
      "display_url" : "pine.fm\/learntoprogram"
    } ]
  },
  "in_reply_to_status_id_str" : "213787935919706112",
  "geo" : { },
  "id_str" : "213800450619736064",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan tons of good tutorials out there. Tryruby, Edgecase koans, http:\/\/t.co\/sLKAst6E",
  "id" : 213800450619736064,
  "in_reply_to_status_id" : 213787935919706112,
  "created_at" : "2012-06-16 01:09:34 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213794140662673408",
  "geo" : { },
  "id_str" : "213799867611480064",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten yep! Will be for a while",
  "id" : 213799867611480064,
  "in_reply_to_status_id" : 213794140662673408,
  "created_at" : "2012-06-16 01:07:15 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/H5WlVS2K",
      "expanded_url" : "http:\/\/instagr.am\/p\/L6kLmvM6lB\/",
      "display_url" : "instagr.am\/p\/L6kLmvM6lB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "213794170589032448",
  "text" : "Another ISRU beta test! http:\/\/t.co\/H5WlVS2K",
  "id" : 213794170589032448,
  "created_at" : "2012-06-16 00:44:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213787502270619649",
  "geo" : { },
  "id_str" : "213787696689192960",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan let the hate flow through you. If you have questions feel free to ask.",
  "id" : 213787696689192960,
  "in_reply_to_status_id" : 213787502270619649,
  "created_at" : "2012-06-16 00:18:53 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213782370770366464",
  "geo" : { },
  "id_str" : "213782784773341184",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten terrible idea. At the library with some friends\u2026feel free to stop by",
  "id" : 213782784773341184,
  "in_reply_to_status_id" : 213782370770366464,
  "created_at" : "2012-06-15 23:59:22 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213724237951811584",
  "geo" : { },
  "id_str" : "213777624915390464",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh gl hf!",
  "id" : 213777624915390464,
  "in_reply_to_status_id" : 213724237951811584,
  "created_at" : "2012-06-15 23:38:52 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/TOY7jq7b",
      "expanded_url" : "http:\/\/4sq.com\/MwgV6t",
      "display_url" : "4sq.com\/MwgV6t"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9923747888, -78.8041591644 ]
  },
  "id_str" : "213770454417149955",
  "text" : "Drinks and games! (@ The Library) http:\/\/t.co\/TOY7jq7b",
  "id" : 213770454417149955,
  "created_at" : "2012-06-15 23:10:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213747960578719744",
  "geo" : { },
  "id_str" : "213749540296200194",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV filling up my growler tomorrow morning!",
  "id" : 213749540296200194,
  "in_reply_to_status_id" : 213747960578719744,
  "created_at" : "2012-06-15 21:47:16 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/IjJVRIVk",
      "expanded_url" : "http:\/\/mustachify.me\/?src=http:\/\/www.buffalo.com\/images\/made\/images\/uploads\/buffalo_com\/content\/galleries\/AllentownArtsFest114_274_412_70.jpg",
      "display_url" : "mustachify.me\/?src=http:\/\/ww\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213467044857905152",
  "text" : "Alright, mustachify.me is amazing. http:\/\/t.co\/IjJVRIVk",
  "id" : 213467044857905152,
  "created_at" : "2012-06-15 03:04:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/Zx6b0CXg",
      "expanded_url" : "http:\/\/instagr.am\/p\/L4NaCJM6iY\/",
      "display_url" : "instagr.am\/p\/L4NaCJM6iY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "213463025464782849",
  "text" : "ISRU beta test! Liking it so far. http:\/\/t.co\/Zx6b0CXg",
  "id" : 213463025464782849,
  "created_at" : "2012-06-15 02:48:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 32, 39 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213449890745954304",
  "text" : "Collecting lots of feedback for @geemus' ISRU. Excited to see this game progress.",
  "id" : 213449890745954304,
  "created_at" : "2012-06-15 01:56:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Lindsay",
      "screen_name" : "ejlindsay",
      "indices" : [ 0, 10 ],
      "id_str" : "90351184",
      "id" : 90351184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213427006661066752",
  "geo" : { },
  "id_str" : "213427358835806208",
  "in_reply_to_user_id" : 90351184,
  "text" : "@ejlindsay lots of forgiveness.",
  "id" : 213427358835806208,
  "in_reply_to_status_id" : 213427006661066752,
  "created_at" : "2012-06-15 00:27:02 +0000",
  "in_reply_to_screen_name" : "ejlindsay",
  "in_reply_to_user_id_str" : "90351184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 35, 42 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213424399544627201",
  "text" : "Finally beta testing out ISRU from @geemus tonight. Pumped!",
  "id" : 213424399544627201,
  "created_at" : "2012-06-15 00:15:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 16, 27 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 28, 40 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213315166325051393",
  "geo" : { },
  "id_str" : "213315534194872320",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten @kevinpurdy @ginatrapani am i missing something? I don't see how to listen live on that page",
  "id" : 213315534194872320,
  "in_reply_to_status_id" : 213315166325051393,
  "created_at" : "2012-06-14 17:02:41 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Chung",
      "screen_name" : "iamwil",
      "indices" : [ 0, 7 ],
      "id_str" : "9162442",
      "id" : 9162442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213304688500682753",
  "geo" : { },
  "id_str" : "213314006201532417",
  "in_reply_to_user_id" : 9162442,
  "text" : "@iamwil nope.",
  "id" : 213314006201532417,
  "in_reply_to_status_id" : 213304688500682753,
  "created_at" : "2012-06-14 16:56:36 +0000",
  "in_reply_to_screen_name" : "iamwil",
  "in_reply_to_user_id_str" : "9162442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213302423547162624",
  "geo" : { },
  "id_str" : "213302835234869249",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella \"SQATTED\"",
  "id" : 213302835234869249,
  "in_reply_to_status_id" : 213302423547162624,
  "created_at" : "2012-06-14 16:12:13 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213302633769873409",
  "text" : "New recruiter email!\n\n\"Hi Nick,\n \nGreat background.\"\n\nI like my background image tiled, usually. Or at least #777.",
  "id" : 213302633769873409,
  "created_at" : "2012-06-14 16:11:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy J. Finucane",
      "screen_name" : "speljamr",
      "indices" : [ 0, 9 ],
      "id_str" : "2676261",
      "id" : 2676261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213255654276734977",
  "geo" : { },
  "id_str" : "213258109169307651",
  "in_reply_to_user_id" : 2676261,
  "text" : "@speljamr nice! I need to get it.",
  "id" : 213258109169307651,
  "in_reply_to_status_id" : 213255654276734977,
  "created_at" : "2012-06-14 13:14:30 +0000",
  "in_reply_to_screen_name" : "speljamr",
  "in_reply_to_user_id_str" : "2676261",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213054096020733953",
  "geo" : { },
  "id_str" : "213055679643131904",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark I CANNOT EXTERMINATE THE CUTENESS",
  "id" : 213055679643131904,
  "in_reply_to_status_id" : 213054096020733953,
  "created_at" : "2012-06-13 23:50:07 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/1RKJE2yb",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/fifthworldproblems",
      "display_url" : "reddit.com\/r\/fifthworldpr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213023219324698627",
  "text" : "And today is when I discovered http:\/\/t.co\/1RKJE2yb, and turned off Reddit for a while.",
  "id" : 213023219324698627,
  "created_at" : "2012-06-13 21:41:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 68 ],
      "url" : "https:\/\/t.co\/j2ilY2UY",
      "expanded_url" : "https:\/\/dl.dropbox.com\/u\/112488\/cowork_zep_comboooo.jpg",
      "display_url" : "dl.dropbox.com\/u\/112488\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213006688712802304",
  "text" : "RT @coworkbuffalo: CoworkBuffalo: Productivity https:\/\/t.co\/j2ilY2UY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 49 ],
        "url" : "https:\/\/t.co\/j2ilY2UY",
        "expanded_url" : "https:\/\/dl.dropbox.com\/u\/112488\/cowork_zep_comboooo.jpg",
        "display_url" : "dl.dropbox.com\/u\/112488\/cowor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "212987282901319682",
    "text" : "CoworkBuffalo: Productivity https:\/\/t.co\/j2ilY2UY",
    "id" : 212987282901319682,
    "created_at" : "2012-06-13 19:18:20 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 213006688712802304,
  "created_at" : "2012-06-13 20:35:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213005461031616513",
  "text" : "RT @aquaranto: Put on my old 'has_many :shoes' shirt and, after a few months of learning to program, I finally know what it means!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213004281882746880",
    "text" : "Put on my old 'has_many :shoes' shirt and, after a few months of learning to program, I finally know what it means!",
    "id" : 213004281882746880,
    "created_at" : "2012-06-13 20:25:52 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 213005461031616513,
  "created_at" : "2012-06-13 20:30:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 3, 17 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212964464352436225",
  "text" : "RT @communitybeer: Announcing RETAIL HOURS! Tomorrow and Friday, 3-7 at the brewery (15 Lafayette 14213), come get your growlers filled!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212963380519116800",
    "text" : "Announcing RETAIL HOURS! Tomorrow and Friday, 3-7 at the brewery (15 Lafayette 14213), come get your growlers filled!",
    "id" : 212963380519116800,
    "created_at" : "2012-06-13 17:43:21 +0000",
    "user" : {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "protected" : false,
      "id_str" : "145294977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477088444733071361\/g7q5sNbw_normal.jpeg",
      "id" : 145294977,
      "verified" : false
    }
  },
  "id" : 212964464352436225,
  "created_at" : "2012-06-13 17:47:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "212960286460755968",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Kenny Loggins: This Is It \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 212960286460755968,
  "created_at" : "2012-06-13 17:31:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Graham",
      "screen_name" : "lapsu",
      "indices" : [ 0, 6 ],
      "id_str" : "41036966",
      "id" : 41036966
    }, {
      "name" : "Coda Hale (cont.)",
      "screen_name" : "coda",
      "indices" : [ 7, 12 ],
      "id_str" : "637533",
      "id" : 637533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212922186296606721",
  "geo" : { },
  "id_str" : "212958527101218817",
  "in_reply_to_user_id" : 41036966,
  "text" : "@lapsu @coda this is a huge reason i applied to only co-op schools. wanted to get out there, experience it, ship things.",
  "id" : 212958527101218817,
  "in_reply_to_status_id" : 212922186296606721,
  "created_at" : "2012-06-13 17:24:04 +0000",
  "in_reply_to_screen_name" : "lapsu",
  "in_reply_to_user_id_str" : "41036966",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Dh0SQZaf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wusGIl3v044",
      "display_url" : "youtube.com\/watch?v=wusGIl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212922931540533250",
  "text" : "I can't wait to register http:\/\/PIZZA.PIZZA http:\/\/t.co\/Dh0SQZaf",
  "id" : 212922931540533250,
  "created_at" : "2012-06-13 15:02:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/BSIpa1oX",
      "expanded_url" : "http:\/\/money.cnn.com\/infographic\/technology\/new-gtld-list\/?iid=EL",
      "display_url" : "money.cnn.com\/infographic\/te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212921862752182273",
  "text" : "The proposed gTLD list is absolutely stupid. http:\/\/t.co\/BSIpa1oX",
  "id" : 212921862752182273,
  "created_at" : "2012-06-13 14:58:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 4, 13 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 37 ],
      "url" : "https:\/\/t.co\/6njuRtSq",
      "expanded_url" : "https:\/\/twitter.com\/aza\/statuses\/212746760173518848",
      "display_url" : "twitter.com\/aza\/statuses\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212747075853627393",
  "text" : "Hey @bquarant : https:\/\/t.co\/6njuRtSq",
  "id" : 212747075853627393,
  "created_at" : "2012-06-13 03:23:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 3, 7 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212746880763953154",
  "text" : "RT @aza: Prediction: The doctor of 20 years from now will be a data scientist.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212746760173518848",
    "text" : "Prediction: The doctor of 20 years from now will be a data scientist.",
    "id" : 212746760173518848,
    "created_at" : "2012-06-13 03:22:34 +0000",
    "user" : {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "protected" : false,
      "id_str" : "13370272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801298949\/Aza_Evil_normal.png",
      "id" : 13370272,
      "verified" : false
    }
  },
  "id" : 212746880763953154,
  "created_at" : "2012-06-13 03:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212739484612169728",
  "geo" : { },
  "id_str" : "212739759058067456",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr there are worse habits",
  "id" : 212739759058067456,
  "in_reply_to_status_id" : 212739484612169728,
  "created_at" : "2012-06-13 02:54:45 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Swerwer",
      "screen_name" : "simonswerwer",
      "indices" : [ 0, 13 ],
      "id_str" : "277656331",
      "id" : 277656331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212462071504322560",
  "geo" : { },
  "id_str" : "212737834816258048",
  "in_reply_to_user_id" : 277656331,
  "text" : "@simonswerwer just wanted to say, digging this stuff immensely! going to hook up a playlist. if you'd get an album together I'd pay for it!",
  "id" : 212737834816258048,
  "in_reply_to_status_id" : 212462071504322560,
  "created_at" : "2012-06-13 02:47:06 +0000",
  "in_reply_to_screen_name" : "simonswerwer",
  "in_reply_to_user_id_str" : "277656331",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 42, 53 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/qy7rZNNj",
      "expanded_url" : "http:\/\/soundcloud.com\/simonswerwer\/encounter-1",
      "display_url" : "soundcloud.com\/simonswerwer\/e\u2026"
    }, {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/gBKQqLYJ",
      "expanded_url" : "http:\/\/soundcloud.com\/simonswerwer",
      "display_url" : "soundcloud.com\/simonswerwer"
    } ]
  },
  "geo" : { },
  "id_str" : "212736453636128768",
  "text" : "There's a guy making Dwarven music too on @soundcloud. http:\/\/t.co\/qy7rZNNj http:\/\/t.co\/gBKQqLYJ",
  "id" : 212736453636128768,
  "created_at" : "2012-06-13 02:41:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212722188493651970",
  "geo" : { },
  "id_str" : "212722972501352449",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten Bubbles is the best.",
  "id" : 212722972501352449,
  "in_reply_to_status_id" : 212722188493651970,
  "created_at" : "2012-06-13 01:48:03 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/OT5NTJVJ",
      "expanded_url" : "http:\/\/www.bravemule.com\/li54",
      "display_url" : "bravemule.com\/li54"
    } ]
  },
  "geo" : { },
  "id_str" : "212720157913661440",
  "text" : "New Bravemule up! 28,000 pixel high comic  of an epic goblin raid. Dwarf Fortress just gets better. http:\/\/t.co\/OT5NTJVJ",
  "id" : 212720157913661440,
  "created_at" : "2012-06-13 01:36:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Haddox",
      "screen_name" : "stevenhaddox",
      "indices" : [ 0, 13 ],
      "id_str" : "2563828880",
      "id" : 2563828880
    }, {
      "name" : "Joshua Szmajda",
      "screen_name" : "jszmajda",
      "indices" : [ 14, 23 ],
      "id_str" : "2049811",
      "id" : 2049811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "212708954403381248",
  "text" : "@stevenhaddox @jszmajda I\u2019ve said no to categorization consistently. Too much hassle. http:\/\/t.co\/t7WATcFT\u2019s primary concern is gem hosting",
  "id" : 212708954403381248,
  "created_at" : "2012-06-13 00:52:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "212650607801155584",
  "text" : "DJing in the CoworkBuffalo room. Come hang out. Now playing Dr. Dre: What's The Difference \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 212650607801155584,
  "created_at" : "2012-06-12 21:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 77 ],
      "url" : "https:\/\/t.co\/X6TuhNym",
      "expanded_url" : "https:\/\/github.com\/libgit2\/rugged",
      "display_url" : "github.com\/libgit2\/rugged"
    } ]
  },
  "in_reply_to_status_id_str" : "212640611210244096",
  "geo" : { },
  "id_str" : "212641106255556609",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham both should be avoided now, use libgit2 \/ https:\/\/t.co\/X6TuhNym instead",
  "id" : 212641106255556609,
  "in_reply_to_status_id" : 212640611210244096,
  "created_at" : "2012-06-12 20:22:45 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Buffalo Spree ",
      "screen_name" : "BuffaloSpree",
      "indices" : [ 80, 93 ],
      "id_str" : "20270080",
      "id" : 20270080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/2PO7y85o",
      "expanded_url" : "http:\/\/www.buffalospree.com\/Buffalo-Spree\/June-2012\/The-Phantom-King-of-Buffalo\/",
      "display_url" : "buffalospree.com\/Buffalo-Spree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212515612403048449",
  "text" : "RT @kevinpurdy: \"The Phantom King of Buffalo,\" my investigative cover story for @BuffaloSpree, is now online: http:\/\/t.co\/2PO7y85o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo Spree ",
        "screen_name" : "BuffaloSpree",
        "indices" : [ 64, 77 ],
        "id_str" : "20270080",
        "id" : 20270080
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/2PO7y85o",
        "expanded_url" : "http:\/\/www.buffalospree.com\/Buffalo-Spree\/June-2012\/The-Phantom-King-of-Buffalo\/",
        "display_url" : "buffalospree.com\/Buffalo-Spree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "212512021277708288",
    "text" : "\"The Phantom King of Buffalo,\" my investigative cover story for @BuffaloSpree, is now online: http:\/\/t.co\/2PO7y85o",
    "id" : 212512021277708288,
    "created_at" : "2012-06-12 11:49:48 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 212515612403048449,
  "created_at" : "2012-06-12 12:04:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 3, 11 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 26, 36 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212371154290229248",
  "text" : "RT @paulehr: Shout out to @aquaranto for putting on an awesome meet tonight and getting hooked on ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 13, 23 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212370741012873217",
    "text" : "Shout out to @aquaranto for putting on an awesome meet tonight and getting hooked on ruby",
    "id" : 212370741012873217,
    "created_at" : "2012-06-12 02:28:24 +0000",
    "user" : {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "protected" : false,
      "id_str" : "15944824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2656131549\/349200ee787d6cf5f69dd623efd13298_normal.png",
      "id" : 15944824,
      "verified" : false
    }
  },
  "id" : 212371154290229248,
  "created_at" : "2012-06-12 02:30:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212340109910081536",
  "geo" : { },
  "id_str" : "212359511166550018",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr oh derp. Sorry I didn\u2019t say hi!",
  "id" : 212359511166550018,
  "in_reply_to_status_id" : 212340109910081536,
  "created_at" : "2012-06-12 01:43:47 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 0, 9 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212354508913774593",
  "geo" : { },
  "id_str" : "212359375845728258",
  "in_reply_to_user_id" : 9462972,
  "text" : "@bitsweat pretty sure Laurent said he\u2019s going to support the betas",
  "id" : 212359375845728258,
  "in_reply_to_status_id" : 212354508913774593,
  "created_at" : "2012-06-12 01:43:15 +0000",
  "in_reply_to_screen_name" : "bitsweat",
  "in_reply_to_user_id_str" : "9462972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212343862482567168",
  "geo" : { },
  "id_str" : "212344136450314240",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten IMO position: fixed is still fucked on iOS 5. lots of stupid edge cases that don't work, especially with z-index.",
  "id" : 212344136450314240,
  "in_reply_to_status_id" : 212343862482567168,
  "created_at" : "2012-06-12 00:42:41 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212341114034855936",
  "geo" : { },
  "id_str" : "212342817958273024",
  "in_reply_to_user_id" : 14174759,
  "text" : "@refulgentis yeah, similar issues. not sure why i get myself so worked up!",
  "id" : 212342817958273024,
  "in_reply_to_status_id" : 212341114034855936,
  "created_at" : "2012-06-12 00:37:27 +0000",
  "in_reply_to_screen_name" : "jpohh",
  "in_reply_to_user_id_str" : "14174759",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212340109910081536",
  "geo" : { },
  "id_str" : "212340430749179904",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr my head is too far into a problem. Hard to context switch.",
  "id" : 212340430749179904,
  "in_reply_to_status_id" : 212340109910081536,
  "created_at" : "2012-06-12 00:27:58 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212339850408505344",
  "text" : "Today was the battle of Nick vs position: fixed on iOS. Nick lost.",
  "id" : 212339850408505344,
  "created_at" : "2012-06-12 00:25:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212263674683990016",
  "geo" : { },
  "id_str" : "212339718023688192",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr been around!",
  "id" : 212339718023688192,
  "in_reply_to_status_id" : 212263674683990016,
  "created_at" : "2012-06-12 00:25:08 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Krause",
      "screen_name" : "EricKrause",
      "indices" : [ 0, 11 ],
      "id_str" : "16146696",
      "id" : 16146696
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 20, 24 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212276607455465474",
  "geo" : { },
  "id_str" : "212282995816673280",
  "in_reply_to_user_id" : 16146696,
  "text" : "@EricKrause I think @dhh kicked it off for the new Basecamp, but I migrated all of the existing ones. they needed some love!",
  "id" : 212282995816673280,
  "in_reply_to_status_id" : 212276607455465474,
  "created_at" : "2012-06-11 20:39:44 +0000",
  "in_reply_to_screen_name" : "EricKrause",
  "in_reply_to_user_id_str" : "16146696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/SzECTsFv",
      "expanded_url" : "http:\/\/cdn.memegenerator.net\/instances\/400x\/21868638.jpg",
      "display_url" : "cdn.memegenerator.net\/instances\/400x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212259408967770113",
  "text" : "Worldwide apple fanboy status: http:\/\/t.co\/SzECTsFv",
  "id" : 212259408967770113,
  "created_at" : "2012-06-11 19:06:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212226841078005760",
  "geo" : { },
  "id_str" : "212227310517104640",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten another win for @coworkbuffalo ! Got a link for this!?",
  "id" : 212227310517104640,
  "in_reply_to_status_id" : 212226841078005760,
  "created_at" : "2012-06-11 16:58:28 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 0, 9 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 55, 63 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 73, 83 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212225853923401731",
  "geo" : { },
  "id_str" : "212227008317501440",
  "in_reply_to_user_id" : 21431343,
  "text" : "@bostonrb this is an awesome idea. We should do it for @wnyruby too! \/cc @aspleenic",
  "id" : 212227008317501440,
  "in_reply_to_status_id" : 212225853923401731,
  "created_at" : "2012-06-11 16:57:16 +0000",
  "in_reply_to_screen_name" : "bostonrb",
  "in_reply_to_user_id_str" : "21431343",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212208946923053056",
  "geo" : { },
  "id_str" : "212210435074703360",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi i love how she takes zero % of the blame for this.",
  "id" : 212210435074703360,
  "in_reply_to_status_id" : 212208946923053056,
  "created_at" : "2012-06-11 15:51:25 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Norman \u24CB",
      "screen_name" : "keithnorm",
      "indices" : [ 0, 10 ],
      "id_str" : "14810774",
      "id" : 14810774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212000905132908544",
  "geo" : { },
  "id_str" : "212010433408794624",
  "in_reply_to_user_id" : 14810774,
  "text" : "@keithnorm oh wow, awesome quality.",
  "id" : 212010433408794624,
  "in_reply_to_status_id" : 212000905132908544,
  "created_at" : "2012-06-11 02:36:40 +0000",
  "in_reply_to_screen_name" : "keithnorm",
  "in_reply_to_user_id_str" : "14810774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/XVDX8d7B",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5axZBLvkwvY",
      "display_url" : "youtube.com\/watch?v=5axZBL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211955139458760705",
  "text" : "Updated current status: http:\/\/t.co\/XVDX8d7B",
  "id" : 211955139458760705,
  "created_at" : "2012-06-10 22:56:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/d0pWgGCt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zcG-m0MNoZw",
      "display_url" : "youtube.com\/watch?v=zcG-m0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211954645613035521",
  "text" : "Current status: http:\/\/t.co\/d0pWgGCt",
  "id" : 211954645613035521,
  "created_at" : "2012-06-10 22:55:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211948143745568770",
  "geo" : { },
  "id_str" : "211953682395308032",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten frig yes.",
  "id" : 211953682395308032,
  "in_reply_to_status_id" : 211948143745568770,
  "created_at" : "2012-06-10 22:51:10 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/QkmugnzO",
      "expanded_url" : "http:\/\/instagr.am\/p\/LtITldM6om\/",
      "display_url" : "instagr.am\/p\/LtITldM6om\/"
    } ]
  },
  "geo" : { },
  "id_str" : "211903296305242112",
  "text" : "Hunger Games poster! http:\/\/t.co\/QkmugnzO",
  "id" : 211903296305242112,
  "created_at" : "2012-06-10 19:30:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/56xYE038",
      "expanded_url" : "http:\/\/instagr.am\/p\/LtFjxYs6m-\/",
      "display_url" : "instagr.am\/p\/LtFjxYs6m-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "211897245707153409",
  "text" : "TARDIS spotting. http:\/\/t.co\/56xYE038",
  "id" : 211897245707153409,
  "created_at" : "2012-06-10 19:06:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Za7UcIK5",
      "expanded_url" : "http:\/\/instagr.am\/p\/LtDi8ds6lj\/",
      "display_url" : "instagr.am\/p\/LtDi8ds6lj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8994210314, -78.8739824295 ]
  },
  "id_str" : "211892870041452544",
  "text" : "Predator in Steel.  @ Allentown Art Festival 2012 http:\/\/t.co\/Za7UcIK5",
  "id" : 211892870041452544,
  "created_at" : "2012-06-10 18:49:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211845910479638530",
  "text" : "Luckily not a serious wound, but seeing my pup bleeding is rough.",
  "id" : 211845910479638530,
  "created_at" : "2012-06-10 15:42:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211845781538344960",
  "text" : "I read the signs wrong from both dogs, other dog was pissed off from the start. It was right as we were entering the dog park.",
  "id" : 211845781538344960,
  "created_at" : "2012-06-10 15:42:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211845571827343361",
  "text" : "Had our first dog biting incident at the park, Ged got bit on the lower leg twice by a pit mix. \/sigh",
  "id" : 211845571827343361,
  "created_at" : "2012-06-10 15:41:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211669260240556033",
  "geo" : { },
  "id_str" : "211680831612256256",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden isn\u2019t this what loveline was for? :\u2019(",
  "id" : 211680831612256256,
  "in_reply_to_status_id" : 211669260240556033,
  "created_at" : "2012-06-10 04:46:57 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211670429411196929",
  "geo" : { },
  "id_str" : "211680617484648448",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety offshore it",
  "id" : 211680617484648448,
  "in_reply_to_status_id" : 211670429411196929,
  "created_at" : "2012-06-10 04:46:06 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211659391013879808",
  "geo" : { },
  "id_str" : "211680556218462208",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents heck yes! Might be more. We will be there in force.",
  "id" : 211680556218462208,
  "in_reply_to_status_id" : 211659391013879808,
  "created_at" : "2012-06-10 04:45:52 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211546680917639168",
  "text" : "Haven\u2019t been to Allentown Art Festival in years. Still awesome.",
  "id" : 211546680917639168,
  "created_at" : "2012-06-09 19:53:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean",
      "screen_name" : "Stamathorn",
      "indices" : [ 3, 14 ],
      "id_str" : "177002475",
      "id" : 177002475
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Stamathorn\/status\/211467922684645377\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/DlFDNRMa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Au9I9I2CEAAlBlG.jpg",
      "id_str" : "211467922693033984",
      "id" : 211467922693033984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au9I9I2CEAAlBlG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/DlFDNRMa"
    } ],
    "hashtags" : [ {
      "text" : "hammers",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "pickles",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211474608363278336",
  "text" : "RT @Stamathorn: Things you can with $45 Other than see this band #hammers #pickles http:\/\/t.co\/DlFDNRMa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Stamathorn\/status\/211467922684645377\/photo\/1",
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/DlFDNRMa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Au9I9I2CEAAlBlG.jpg",
        "id_str" : "211467922693033984",
        "id" : 211467922693033984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au9I9I2CEAAlBlG.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/DlFDNRMa"
      } ],
      "hashtags" : [ {
        "text" : "hammers",
        "indices" : [ 49, 57 ]
      }, {
        "text" : "pickles",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211467922684645377",
    "text" : "Things you can with $45 Other than see this band #hammers #pickles http:\/\/t.co\/DlFDNRMa",
    "id" : 211467922684645377,
    "created_at" : "2012-06-09 14:40:57 +0000",
    "user" : {
      "name" : "Sean",
      "screen_name" : "Stamathorn",
      "protected" : false,
      "id_str" : "177002475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2718872414\/ef007ca0c5c8faefa6079107a94b0917_normal.jpeg",
      "id" : 177002475,
      "verified" : false
    }
  },
  "id" : 211474608363278336,
  "created_at" : "2012-06-09 15:07:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 22, 36 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/4yThHN5S",
      "expanded_url" : "http:\/\/instagr.am\/p\/LqELRbs6uZ\/",
      "display_url" : "instagr.am\/p\/LqELRbs6uZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "211472084369551362",
  "text" : "Brought home my first @communitybeer growler of Frank! Very proud to support this in Buffalo. http:\/\/t.co\/4yThHN5S",
  "id" : 211472084369551362,
  "created_at" : "2012-06-09 14:57:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/fnL7fzb0",
      "expanded_url" : "http:\/\/i.imgur.com\/R2HMD.png",
      "display_url" : "i.imgur.com\/R2HMD.png"
    } ]
  },
  "geo" : { },
  "id_str" : "211453900136513536",
  "text" : "Linear games vs non-linear games vs Dwarf Fortress: http:\/\/t.co\/fnL7fzb0",
  "id" : 211453900136513536,
  "created_at" : "2012-06-09 13:45:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "Drew_Baggg",
      "indices" : [ 0, 11 ],
      "id_str" : "372319943",
      "id" : 372319943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211297173101481985",
  "geo" : { },
  "id_str" : "211301542106640385",
  "in_reply_to_user_id" : 372319943,
  "text" : "@Drew_Baggg dude\u2026",
  "id" : 211301542106640385,
  "in_reply_to_status_id" : 211297173101481985,
  "created_at" : "2012-06-09 03:39:48 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211295209743589376",
  "text" : "First time at the Library. Please, someone take this bar and move it to Elmwood out of an Amherst plaza.",
  "id" : 211295209743589376,
  "created_at" : "2012-06-09 03:14:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 11, 20 ],
      "id_str" : "16450420",
      "id" : 16450420
    }, {
      "name" : "John Yerhot",
      "screen_name" : "yerhot",
      "indices" : [ 21, 28 ],
      "id_str" : "12341642",
      "id" : 12341642
    }, {
      "name" : "photomattmills",
      "screen_name" : "photomattmills",
      "indices" : [ 29, 44 ],
      "id_str" : "17553798",
      "id" : 17553798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/yc38yMpK",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "211294019223957504",
  "geo" : { },
  "id_str" : "211294544069795840",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @ivyhurst @yerhot @photomattmills there\u2019s a reason this is on http:\/\/t.co\/yc38yMpK",
  "id" : 211294544069795840,
  "in_reply_to_status_id" : 211294019223957504,
  "created_at" : "2012-06-09 03:11:59 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/P2ptVplR",
      "expanded_url" : "http:\/\/instagr.am\/p\/LoW7pzs6sl\/",
      "display_url" : "instagr.am\/p\/LoW7pzs6sl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "211231822653296640",
  "text" : "What? http:\/\/t.co\/P2ptVplR",
  "id" : 211231822653296640,
  "created_at" : "2012-06-08 23:02:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 3, 14 ],
      "id_str" : "14693115",
      "id" : 14693115
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 38, 52 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/6KdjQUy9",
      "expanded_url" : "http:\/\/steelcityrubyconf.com",
      "display_url" : "steelcityrubyconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "211208771559632898",
  "text" : "RT @rayonrails: Grab your tickets for @SteelCityRuby Conf. It's almost sold out. Aug 3rd - Aug 4th. Check it out at http:\/\/t.co\/6KdjQUy9.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 22, 36 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/6KdjQUy9",
        "expanded_url" : "http:\/\/steelcityrubyconf.com",
        "display_url" : "steelcityrubyconf.com"
      } ]
    },
    "geo" : { },
    "id_str" : "211206029407567873",
    "text" : "Grab your tickets for @SteelCityRuby Conf. It's almost sold out. Aug 3rd - Aug 4th. Check it out at http:\/\/t.co\/6KdjQUy9.",
    "id" : 211206029407567873,
    "created_at" : "2012-06-08 21:20:16 +0000",
    "user" : {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "protected" : false,
      "id_str" : "14693115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736560986\/e187009e5f3e50f26239cd009622d7c8_normal.jpeg",
      "id" : 14693115,
      "verified" : false
    }
  },
  "id" : 211208771559632898,
  "created_at" : "2012-06-08 21:31:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 11, 18 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/kxILpkCy",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLEC6767C9C76CB2D0&feature=plcp",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211195935898877952",
  "text" : "Looks like @mkdevo is back! Thanks for the awesome videos! http:\/\/t.co\/kxILpkCy",
  "id" : 211195935898877952,
  "created_at" : "2012-06-08 20:40:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 8, 14 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Greg Croak",
      "screen_name" : "GregCroak",
      "indices" : [ 15, 25 ],
      "id_str" : "2244365372",
      "id" : 2244365372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/kxILpkCy",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLEC6767C9C76CB2D0&feature=plcp",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "211191117390155776",
  "geo" : { },
  "id_str" : "211191480214237184",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @cmeik @gregcroak http:\/\/t.co\/kxILpkCy",
  "id" : 211191480214237184,
  "in_reply_to_status_id" : 211191117390155776,
  "created_at" : "2012-06-08 20:22:27 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas McDonald",
      "screen_name" : "thomasmcdonald_",
      "indices" : [ 0, 16 ],
      "id_str" : "95412100",
      "id" : 95412100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211126979074854914",
  "geo" : { },
  "id_str" : "211185575787630592",
  "in_reply_to_user_id" : 95412100,
  "text" : "@thomasmcdonald_ yeah, it's changed how i look at the game. so good!",
  "id" : 211185575787630592,
  "in_reply_to_status_id" : 211126979074854914,
  "created_at" : "2012-06-08 19:58:59 +0000",
  "in_reply_to_screen_name" : "thomasmcdonald_",
  "in_reply_to_user_id_str" : "95412100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Smithee",
      "screen_name" : "barfcaptain",
      "indices" : [ 3, 15 ],
      "id_str" : "1226873053",
      "id" : 1226873053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/IKRt5q1B",
      "expanded_url" : "http:\/\/gunshowcomic.com\/557",
      "display_url" : "gunshowcomic.com\/557"
    } ]
  },
  "geo" : { },
  "id_str" : "211164349727903744",
  "text" : "RT @barfcaptain: hello, i did this comic about corrupted puppies http:\/\/t.co\/IKRt5q1B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/IKRt5q1B",
        "expanded_url" : "http:\/\/gunshowcomic.com\/557",
        "display_url" : "gunshowcomic.com\/557"
      } ]
    },
    "geo" : { },
    "id_str" : "211163709563863041",
    "text" : "hello, i did this comic about corrupted puppies http:\/\/t.co\/IKRt5q1B",
    "id" : 211163709563863041,
    "created_at" : "2012-06-08 18:32:06 +0000",
    "user" : {
      "name" : "kc gr\u0259\u0259n",
      "screen_name" : "kcgreenn",
      "protected" : false,
      "id_str" : "16522244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573812132753620992\/Hmui3IXO_normal.jpeg",
      "id" : 16522244,
      "verified" : false
    }
  },
  "id" : 211164349727903744,
  "created_at" : "2012-06-08 18:34:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 8, 16 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211082523114094592",
  "geo" : { },
  "id_str" : "211084821273911296",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @graysky you're killing me smalls!",
  "id" : 211084821273911296,
  "in_reply_to_status_id" : 211082523114094592,
  "created_at" : "2012-06-08 13:18:37 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210974586345488384",
  "geo" : { },
  "id_str" : "211081986230595584",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes not sure, mind tossing an example\/error dump on github issues?",
  "id" : 211081986230595584,
  "in_reply_to_status_id" : 210974586345488384,
  "created_at" : "2012-06-08 13:07:21 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/osSo3MSe",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/dwarffortress\/comments\/uqx0q\/ever_have_an_awesome_fortress_design_going\/",
      "display_url" : "reddit.com\/r\/dwarffortres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210924548957274112",
  "text" : "I was building a perfectly good fortress...when... http:\/\/t.co\/osSo3MSe",
  "id" : 210924548957274112,
  "created_at" : "2012-06-08 02:41:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/XA82at7G",
      "expanded_url" : "http:\/\/www.ustream.tv\/channel\/mohawk1\/theater",
      "display_url" : "ustream.tv\/channel\/mohawk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210892502901850112",
  "text" : "Listening to some very choppy live Phish. Can't wait to see them later this month. http:\/\/t.co\/XA82at7G",
  "id" : 210892502901850112,
  "created_at" : "2012-06-08 00:34:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bertrand Fan",
      "screen_name" : "bertrandom",
      "indices" : [ 3, 14 ],
      "id_str" : "6588972",
      "id" : 6588972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/nT3dREFd",
      "expanded_url" : "http:\/\/violatetwitterbrandguidelines.com\/",
      "display_url" : "violatetwitterbrandguidelines.com"
    } ]
  },
  "geo" : { },
  "id_str" : "210891376425054209",
  "text" : "RT @bertrandom: I made this to help you violate Twitter brand guidelines. http:\/\/t.co\/nT3dREFd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/nT3dREFd",
        "expanded_url" : "http:\/\/violatetwitterbrandguidelines.com\/",
        "display_url" : "violatetwitterbrandguidelines.com"
      } ]
    },
    "geo" : { },
    "id_str" : "210885578189836288",
    "text" : "I made this to help you violate Twitter brand guidelines. http:\/\/t.co\/nT3dREFd",
    "id" : 210885578189836288,
    "created_at" : "2012-06-08 00:06:54 +0000",
    "user" : {
      "name" : "Bertrand Fan",
      "screen_name" : "bertrandom",
      "protected" : false,
      "id_str" : "6588972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1501240190\/127274426_fee10cf32e_b_normal.jpg",
      "id" : 6588972,
      "verified" : false
    }
  },
  "id" : 210891376425054209,
  "created_at" : "2012-06-08 00:29:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210876477183508480",
  "text" : "Programming's constant frustrations are worth it for the thousand tiny victories and breakthroughs.",
  "id" : 210876477183508480,
  "created_at" : "2012-06-07 23:30:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/7PK5ZRr7",
      "expanded_url" : "http:\/\/octofeed.com\/",
      "display_url" : "octofeed.com"
    } ]
  },
  "geo" : { },
  "id_str" : "210856558815481856",
  "text" : "Just...wow: http:\/\/t.co\/7PK5ZRr7",
  "id" : 210856558815481856,
  "created_at" : "2012-06-07 22:11:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/UEglmxsF",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3191-announcing-pow-040-with-xipio-support",
      "display_url" : "37signals.com\/svn\/posts\/3191\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210839548333277185",
  "text" : "RT @sstephenson: At long last, announcing Pow 0.4.0 with xip.io support: http:\/\/t.co\/UEglmxsF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/UEglmxsF",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3191-announcing-pow-040-with-xipio-support",
        "display_url" : "37signals.com\/svn\/posts\/3191\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210839492989423616",
    "text" : "At long last, announcing Pow 0.4.0 with xip.io support: http:\/\/t.co\/UEglmxsF",
    "id" : 210839492989423616,
    "created_at" : "2012-06-07 21:03:46 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 210839548333277185,
  "created_at" : "2012-06-07 21:04:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 127, 133 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "210824364034232320",
  "text" : "DJing in the CoworkBuffalo room. Now playing Dragonforce: Through The Fire And Flames \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB \/cc @mwn3d",
  "id" : 210824364034232320,
  "created_at" : "2012-06-07 20:03:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scottmotte",
      "screen_name" : "scottmotte",
      "indices" : [ 0, 11 ],
      "id_str" : "2808474884",
      "id" : 2808474884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210743047623933953",
  "geo" : { },
  "id_str" : "210753879187533825",
  "in_reply_to_user_id" : 23777689,
  "text" : "@scottmotte thanks dude!",
  "id" : 210753879187533825,
  "in_reply_to_status_id" : 210743047623933953,
  "created_at" : "2012-06-07 15:23:35 +0000",
  "in_reply_to_screen_name" : "motdotla",
  "in_reply_to_user_id_str" : "23777689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210578915306127363",
  "text" : "One day, I won\u2019t see sleep as an enemy.",
  "id" : 210578915306127363,
  "created_at" : "2012-06-07 03:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210514784003686400",
  "text" : "First bike ride alone with the dog, 2.2 miles.  Both wiped. (total of 5 miles today) I don't get how huskies get husky when exercised.",
  "id" : 210514784003686400,
  "created_at" : "2012-06-06 23:33:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/wCa2jbvf",
      "expanded_url" : "http:\/\/bit.ly\/KPV5dE",
      "display_url" : "bit.ly\/KPV5dE"
    } ]
  },
  "geo" : { },
  "id_str" : "210444263677362177",
  "text" : "RT @aquaranto: A reminder! I just started a new meetup group for Buffalonians who want to learn to program http:\/\/t.co\/wCa2jbvf. We star ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/wCa2jbvf",
        "expanded_url" : "http:\/\/bit.ly\/KPV5dE",
        "display_url" : "bit.ly\/KPV5dE"
      } ]
    },
    "geo" : { },
    "id_str" : "210442962029645824",
    "text" : "A reminder! I just started a new meetup group for Buffalonians who want to learn to program http:\/\/t.co\/wCa2jbvf. We start Jun 11 @ 630 pm.",
    "id" : 210442962029645824,
    "created_at" : "2012-06-06 18:48:06 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 210444263677362177,
  "created_at" : "2012-06-06 18:53:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/ibKhcZ3g",
      "expanded_url" : "http:\/\/entertainment.msn.com\/video\/?videoId=96bb77a5-e38e-4539-ab8f-a5ed3127b6ed",
      "display_url" : "entertainment.msn.com\/video\/?videoId\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210423214571143168",
  "text" : "Wreck-It Ralph better be good. (Flip to HD!) http:\/\/t.co\/ibKhcZ3g",
  "id" : 210423214571143168,
  "created_at" : "2012-06-06 17:29:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/VbN1YyLu",
      "expanded_url" : "http:\/\/vimeo.com\/43431035",
      "display_url" : "vimeo.com\/43431035"
    } ]
  },
  "geo" : { },
  "id_str" : "210199673154174978",
  "text" : "The buttons rising out of this touchscreen display gave me chills. The future is awesome. http:\/\/t.co\/VbN1YyLu",
  "id" : 210199673154174978,
  "created_at" : "2012-06-06 02:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210133827341926401",
  "text" : "\u201CHi Nick, I\u2019m a chill recruiter\u201D\n\nReally? This is your pitch?",
  "id" : 210133827341926401,
  "created_at" : "2012-06-05 22:19:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210122762591813632",
  "geo" : { },
  "id_str" : "210133509208158209",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel correct on both counts",
  "id" : 210133509208158209,
  "in_reply_to_status_id" : 210122762591813632,
  "created_at" : "2012-06-05 22:18:27 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209982483167576064",
  "geo" : { },
  "id_str" : "210006389374992384",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack not yet!",
  "id" : 210006389374992384,
  "in_reply_to_status_id" : 209982483167576064,
  "created_at" : "2012-06-05 13:53:19 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/SBX12gTF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=A21wxZKiao8",
      "display_url" : "youtube.com\/watch?v=A21wxZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209982106447785985",
  "text" : "Current status: http:\/\/t.co\/SBX12gTF",
  "id" : 209982106447785985,
  "created_at" : "2012-06-05 12:16:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/DlMdZ288",
      "expanded_url" : "http:\/\/www.holovaty.com\/writing\/streetview\/",
      "display_url" : "holovaty.com\/writing\/street\u2026"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/ederyhZP",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9CS7j5I6aOc",
      "display_url" : "youtube.com\/watch?v=9CS7j5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209980570690793472",
  "text" : "Google Street View is the ultimate training system for driverless cars. http:\/\/t.co\/DlMdZ288 http:\/\/t.co\/ederyhZP",
  "id" : 209980570690793472,
  "created_at" : "2012-06-05 12:10:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 33, 46 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209819991229472769",
  "geo" : { },
  "id_str" : "209820189590687745",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush oh lame it\u2019s down!!!! \/cc @technoweenie",
  "id" : 209820189590687745,
  "in_reply_to_status_id" : 209819991229472769,
  "created_at" : "2012-06-05 01:33:26 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/SsV8Qzl9",
      "expanded_url" : "http:\/\/cronwtf.heroku.com",
      "display_url" : "cronwtf.heroku.com"
    } ]
  },
  "in_reply_to_status_id_str" : "209818523684446211",
  "geo" : { },
  "id_str" : "209819991229472769",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 http:\/\/t.co\/SsV8Qzl9",
  "id" : 209819991229472769,
  "in_reply_to_status_id" : 209818523684446211,
  "created_at" : "2012-06-05 01:32:38 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/x84oTvUO",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/89-buffalo-opencoffee-club",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209806487487397888",
  "text" : "RT @magnachef: #Buffalo OpenCoffee Club is tomorrow from 8am-10am at Spot on Delaware - come stop by! http:\/\/t.co\/x84oTvUO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/x84oTvUO",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/89-buffalo-opencoffee-club",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "209805883708948480",
    "text" : "#Buffalo OpenCoffee Club is tomorrow from 8am-10am at Spot on Delaware - come stop by! http:\/\/t.co\/x84oTvUO",
    "id" : 209805883708948480,
    "created_at" : "2012-06-05 00:36:35 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 209806487487397888,
  "created_at" : "2012-06-05 00:38:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 13, 25 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209714165173063682",
  "geo" : { },
  "id_str" : "209714221187993600",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius @fredyatesiv same.",
  "id" : 209714221187993600,
  "in_reply_to_status_id" : 209714165173063682,
  "created_at" : "2012-06-04 18:32:21 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 46, 52 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 36 ],
      "url" : "https:\/\/t.co\/XCfrzLUo",
      "expanded_url" : "https:\/\/github.com\/blog\/1143-will-farrington-is-a-githubber",
      "display_url" : "github.com\/blog\/1143-will\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209704251319005187",
  "text" : "I missed this! https:\/\/t.co\/XCfrzLUo Congrats @wfarr!",
  "id" : 209704251319005187,
  "created_at" : "2012-06-04 17:52:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209662770646482944",
  "text" : "The decision process of choosing an open source project to use is a fascinating one. Too many options at the buffet table.",
  "id" : 209662770646482944,
  "created_at" : "2012-06-04 15:07:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209650983704334337",
  "geo" : { },
  "id_str" : "209651310402875395",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten woot! sorry i couldnt help more.",
  "id" : 209651310402875395,
  "in_reply_to_status_id" : 209650983704334337,
  "created_at" : "2012-06-04 14:22:22 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremiah Felt",
      "screen_name" : "jeremiahfelt",
      "indices" : [ 0, 13 ],
      "id_str" : "9154112",
      "id" : 9154112
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 14, 25 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209640851603849218",
  "geo" : { },
  "id_str" : "209641739596730368",
  "in_reply_to_user_id" : 9154112,
  "text" : "@jeremiahfelt @kevinpurdy we\u2019ve had 6-8 people in almost every day since launch",
  "id" : 209641739596730368,
  "in_reply_to_status_id" : 209640851603849218,
  "created_at" : "2012-06-04 13:44:20 +0000",
  "in_reply_to_screen_name" : "jeremiahfelt",
  "in_reply_to_user_id_str" : "9154112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209634875953774592",
  "geo" : { },
  "id_str" : "209641055820333057",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr it\u2019s 2012. Why are you putting up with this?",
  "id" : 209641055820333057,
  "in_reply_to_status_id" : 209634875953774592,
  "created_at" : "2012-06-04 13:41:37 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 26, 40 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209640602336378880",
  "text" : "RT @kevinpurdy: Opened up @coworkbuffalo for its third week today. Improving this space is my favorite to-do project. +community",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 10, 24 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209639520998670336",
    "text" : "Opened up @coworkbuffalo for its third week today. Improving this space is my favorite to-do project. +community",
    "id" : 209639520998670336,
    "created_at" : "2012-06-04 13:35:31 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 209640602336378880,
  "created_at" : "2012-06-04 13:39:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209482096408920064",
  "text" : "Shitsnares.",
  "id" : 209482096408920064,
  "created_at" : "2012-06-04 03:09:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209406429755473920",
  "text" : "Excited to start week 3 of @coworkbuffalo tomorrow. Pumped.",
  "id" : 209406429755473920,
  "created_at" : "2012-06-03 22:09:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209104142944309251",
  "geo" : { },
  "id_str" : "209112178375135232",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten that or nick@quaran.to",
  "id" : 209112178375135232,
  "in_reply_to_status_id" : 209104142944309251,
  "created_at" : "2012-06-03 02:40:03 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209090279754575872",
  "geo" : { },
  "id_str" : "209103405984129024",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten I can help out tomorrow. Shoot me an email.",
  "id" : 209103405984129024,
  "in_reply_to_status_id" : 209090279754575872,
  "created_at" : "2012-06-03 02:05:11 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/z9TYhJIk",
      "expanded_url" : "http:\/\/instagr.am\/p\/LY0VsAs6kO\/",
      "display_url" : "instagr.am\/p\/LY0VsAs6kO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "209044721996275712",
  "text" : "One day this gorgeous view will not have a highway crossing through it. http:\/\/t.co\/z9TYhJIk",
  "id" : 209044721996275712,
  "created_at" : "2012-06-02 22:12:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/MF8kEcBd",
      "expanded_url" : "http:\/\/instagr.am\/p\/LYw7K1M6iU\/",
      "display_url" : "instagr.am\/p\/LYw7K1M6iU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "209037482921177090",
  "text" : "One day Buffalo was a walking city.  http:\/\/t.co\/MF8kEcBd",
  "id" : 209037482921177090,
  "created_at" : "2012-06-02 21:43:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/GEKFQhQz",
      "expanded_url" : "http:\/\/instagr.am\/p\/LYvHnrs6hC\/",
      "display_url" : "instagr.am\/p\/LYvHnrs6hC\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9354144603, -78.8765144348 ]
  },
  "id_str" : "209033127341985793",
  "text" : "Such a classy wedding venue.  @ Buffalo &amp; Erie County Historical Society http:\/\/t.co\/GEKFQhQz",
  "id" : 209033127341985793,
  "created_at" : "2012-06-02 21:25:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/xC75SvH2",
      "expanded_url" : "http:\/\/instagr.am\/p\/LX7qUgM6i_\/",
      "display_url" : "instagr.am\/p\/LX7qUgM6i_\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8967059, -78.878431 ]
  },
  "id_str" : "208919991574204419",
  "text" : "BLUNCH  @ Betty's Restaurant http:\/\/t.co\/xC75SvH2",
  "id" : 208919991574204419,
  "created_at" : "2012-06-02 13:56:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/uvUXtX46",
      "expanded_url" : "http:\/\/bluemonkbflo.com",
      "display_url" : "bluemonkbflo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "208738194315943937",
  "geo" : { },
  "id_str" : "208739058250285058",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton http:\/\/t.co\/uvUXtX46",
  "id" : 208739058250285058,
  "in_reply_to_status_id" : 208738194315943937,
  "created_at" : "2012-06-02 01:57:24 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208737809148821504",
  "text" : "It\u2019s Blue Monk o\u2019clock.",
  "id" : 208737809148821504,
  "created_at" : "2012-06-02 01:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208688191652364289",
  "geo" : { },
  "id_str" : "208692933162053634",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic wedding! Sorry",
  "id" : 208692933162053634,
  "in_reply_to_status_id" : 208688191652364289,
  "created_at" : "2012-06-01 22:54:07 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Hsu",
      "screen_name" : "charlottehsu",
      "indices" : [ 0, 13 ],
      "id_str" : "54620630",
      "id" : 54620630
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208619937714016257",
  "geo" : { },
  "id_str" : "208622860162445313",
  "in_reply_to_user_id" : 54620630,
  "text" : "@charlottehsu @coworkbuffalo any 10!",
  "id" : 208622860162445313,
  "in_reply_to_status_id" : 208619937714016257,
  "created_at" : "2012-06-01 18:15:40 +0000",
  "in_reply_to_screen_name" : "charlottehsu",
  "in_reply_to_user_id_str" : "54620630",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
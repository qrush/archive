Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Nate Otto",
      "screen_name" : "nongallery",
      "indices" : [ 15, 26 ],
      "id_str" : "18547559",
      "id" : 18547559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429434682531270656",
  "geo" : { },
  "id_str" : "429436475676315648",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr thanks! @nongallery deserves the credit though.",
  "id" : 429436475676315648,
  "in_reply_to_status_id" : 429434682531270656,
  "created_at" : "2014-02-01 02:10:09 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Thompson",
      "screen_name" : "thompson_caleb",
      "indices" : [ 0, 15 ],
      "id_str" : "2770102409",
      "id" : 2770102409
    }, {
      "name" : "coffee dad",
      "screen_name" : "coffee_dad",
      "indices" : [ 40, 51 ],
      "id_str" : "510770821",
      "id" : 510770821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429430646919143425",
  "geo" : { },
  "id_str" : "429436057374187520",
  "in_reply_to_user_id" : 290866979,
  "text" : "@thompson_caleb let me introduce you to @coffee_dad",
  "id" : 429436057374187520,
  "in_reply_to_status_id" : 429430646919143425,
  "created_at" : "2014-02-01 02:08:29 +0000",
  "in_reply_to_screen_name" : "calebthompson",
  "in_reply_to_user_id_str" : "290866979",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim",
      "screen_name" : "kkjordan",
      "indices" : [ 3, 12 ],
      "id_str" : "336951477",
      "id" : 336951477
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kkjordan\/status\/429419493559783425\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/oICztKaGFo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWawRXCUAAtbuh.jpg",
      "id_str" : "429419493568172032",
      "id" : 429419493568172032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWawRXCUAAtbuh.jpg",
      "sizes" : [ {
        "h" : 694,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 471,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/oICztKaGFo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429428495060840448",
  "text" : "RT @kkjordan: Great poster, guys http:\/\/t.co\/oICztKaGFo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kkjordan\/status\/429419493559783425\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/oICztKaGFo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWawRXCUAAtbuh.jpg",
        "id_str" : "429419493568172032",
        "id" : 429419493568172032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWawRXCUAAtbuh.jpg",
        "sizes" : [ {
          "h" : 694,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/oICztKaGFo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429419493559783425",
    "text" : "Great poster, guys http:\/\/t.co\/oICztKaGFo",
    "id" : 429419493559783425,
    "created_at" : "2014-02-01 01:02:40 +0000",
    "user" : {
      "name" : "Kim",
      "screen_name" : "kkjordan",
      "protected" : false,
      "id_str" : "336951477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463342824725827585\/hGLzf-b2_normal.jpeg",
      "id" : 336951477,
      "verified" : false
    }
  },
  "id" : 429428495060840448,
  "created_at" : "2014-02-01 01:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429412613626138624",
  "text" : "Stare at a glowing rectangle all day, stare at a glowing rectangle all night. Too many rectangles.",
  "id" : 429412613626138624,
  "created_at" : "2014-02-01 00:35:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429400355391037441",
  "geo" : { },
  "id_str" : "429405942036574208",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin there's tons on \/r\/wheredidthesodago",
  "id" : 429405942036574208,
  "in_reply_to_status_id" : 429400355391037441,
  "created_at" : "2014-02-01 00:08:49 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Platform 302",
      "screen_name" : "Platform302",
      "indices" : [ 0, 12 ],
      "id_str" : "398298941",
      "id" : 398298941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429344103252254720",
  "geo" : { },
  "id_str" : "429353601392062465",
  "in_reply_to_user_id" : 398298941,
  "text" : "@Platform302 thanks for coming in!",
  "id" : 429353601392062465,
  "in_reply_to_status_id" : 429344103252254720,
  "created_at" : "2014-01-31 20:40:50 +0000",
  "in_reply_to_screen_name" : "Platform302",
  "in_reply_to_user_id_str" : "398298941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 57, 61 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/kXuIi02PE0",
      "expanded_url" : "http:\/\/www.politico.com\/magazine\/story\/2014\/01\/tsa-screener-confession-102912_full.html#.UuwHxnddWuo",
      "display_url" : "politico.com\/magazine\/story\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429351315173429249",
  "text" : "\"Opt out: A smart passenger.\" http:\/\/t.co\/kXuIi02PE0 \/cc @dhh",
  "id" : 429351315173429249,
  "created_at" : "2014-01-31 20:31:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429338782710501378",
  "geo" : { },
  "id_str" : "429346822096564224",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik what in the actual fuck",
  "id" : 429346822096564224,
  "in_reply_to_status_id" : 429338782710501378,
  "created_at" : "2014-01-31 20:13:53 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 77, 83 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429340330949750784",
  "geo" : { },
  "id_str" : "429340485669232643",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo well now i figured out how to back up my dropbox folder of gifs \/cc @parkr",
  "id" : 429340485669232643,
  "in_reply_to_status_id" : 429340330949750784,
  "created_at" : "2014-01-31 19:48:43 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coffee",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429335115009777665",
  "text" : "Poured some more# great #coffee",
  "id" : 429335115009777665,
  "created_at" : "2014-01-31 19:27:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 61, 68 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BoFur1abyl",
      "expanded_url" : "https:\/\/gist.github.com\/dhh\/8738842\/raw\/4ed069f472993d0f6d5b79660b1e46683cd5a7c1\/gistfile1.txt",
      "display_url" : "gist.github.com\/dhh\/8738842\/ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429314721099956224",
  "text" : "RT @dhh: They're apparently big on metrics-driven recruiting @heroku. Missing the point to five decimals, https:\/\/t.co\/BoFur1abyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heroku",
        "screen_name" : "heroku",
        "indices" : [ 52, 59 ],
        "id_str" : "10257182",
        "id" : 10257182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/BoFur1abyl",
        "expanded_url" : "https:\/\/gist.github.com\/dhh\/8738842\/raw\/4ed069f472993d0f6d5b79660b1e46683cd5a7c1\/gistfile1.txt",
        "display_url" : "gist.github.com\/dhh\/8738842\/ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429314373757440001",
    "text" : "They're apparently big on metrics-driven recruiting @heroku. Missing the point to five decimals, https:\/\/t.co\/BoFur1abyl",
    "id" : 429314373757440001,
    "created_at" : "2014-01-31 18:04:57 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 429314721099956224,
  "created_at" : "2014-01-31 18:06:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "indices" : [ 3, 12 ],
      "id_str" : "9462972",
      "id" : 9462972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429311086651666432",
  "text" : "RT @bitsweat: Marking 7 happy, rewarding years at 37signals today. 100% remote.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429310208540549120",
    "text" : "Marking 7 happy, rewarding years at 37signals today. 100% remote.",
    "id" : 429310208540549120,
    "created_at" : "2014-01-31 17:48:24 +0000",
    "user" : {
      "name" : "Jeremy Kemper",
      "screen_name" : "bitsweat",
      "protected" : false,
      "id_str" : "9462972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510089088129458177\/L_F1zcVv_normal.png",
      "id" : 9462972,
      "verified" : false
    }
  },
  "id" : 429311086651666432,
  "created_at" : "2014-01-31 17:51:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429297459789967361",
  "geo" : { },
  "id_str" : "429298804429295616",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden if you're passing on through you're welcome to!",
  "id" : 429298804429295616,
  "in_reply_to_status_id" : 429297459789967361,
  "created_at" : "2014-01-31 17:03:05 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429296352439177216",
  "geo" : { },
  "id_str" : "429297305070497792",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden GUESS WHATS CLOSE",
  "id" : 429297305070497792,
  "in_reply_to_status_id" : 429296352439177216,
  "created_at" : "2014-01-31 16:57:08 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraghAdams",
      "screen_name" : "SaraghAdams",
      "indices" : [ 3, 15 ],
      "id_str" : "249978879",
      "id" : 249978879
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TOMayorFrod\/status\/429257223827910656\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/JgcAMw2Ial",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfUHK6_IMAAjQZw.jpg",
      "id_str" : "429257223697870848",
      "id" : 429257223697870848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfUHK6_IMAAjQZw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/JgcAMw2Ial"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429296753880203264",
  "text" : "RT @SaraghAdams: WHO'S A SILLY BOY. WHO'S A BIG SILLY BOY AHKUCHEEKUCHEEKUCHEE http:\/\/t.co\/JgcAMw2Ial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TOMayorFrod\/status\/429257223827910656\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/JgcAMw2Ial",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfUHK6_IMAAjQZw.jpg",
        "id_str" : "429257223697870848",
        "id" : 429257223697870848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfUHK6_IMAAjQZw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/JgcAMw2Ial"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429285796848230401",
    "text" : "WHO'S A SILLY BOY. WHO'S A BIG SILLY BOY AHKUCHEEKUCHEEKUCHEE http:\/\/t.co\/JgcAMw2Ial",
    "id" : 429285796848230401,
    "created_at" : "2014-01-31 16:11:24 +0000",
    "user" : {
      "name" : "SaraghAdams",
      "screen_name" : "SaraghAdams",
      "protected" : false,
      "id_str" : "249978879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554170854687244288\/BfULAJK9_normal.jpeg",
      "id" : 249978879,
      "verified" : false
    }
  },
  "id" : 429296753880203264,
  "created_at" : "2014-01-31 16:54:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 56, 67 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429275093173538816",
  "geo" : { },
  "id_str" : "429275439970783232",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle lots of hard work and manual love\/labor. maybe @kevinpurdy should write a book about it :P",
  "id" : 429275439970783232,
  "in_reply_to_status_id" : 429275093173538816,
  "created_at" : "2014-01-31 15:30:15 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 20, 34 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429274810212835328",
  "text" : "15 people right now @CoworkBuffalo. Constantly impressed by how this little one-room operation has grown.",
  "id" : 429274810212835328,
  "created_at" : "2014-01-31 15:27:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/XQohKgey4W",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=AfJO7f408zk",
      "display_url" : "youtube.com\/watch?v=AfJO7f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429089527274041344",
  "text" : "MARKETING http:\/\/t.co\/XQohKgey4W",
  "id" : 429089527274041344,
  "created_at" : "2014-01-31 03:11:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Wiskus",
      "screen_name" : "dwiskus",
      "indices" : [ 3, 11 ],
      "id_str" : "2897431",
      "id" : 2897431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428925055238553600",
  "text" : "RT @dwiskus: FiftyThree announces a new iOS app for sketching faces.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428900062828457984",
    "text" : "FiftyThree announces a new iOS app for sketching faces.",
    "id" : 428900062828457984,
    "created_at" : "2014-01-30 14:38:38 +0000",
    "user" : {
      "name" : "Dave Wiskus",
      "screen_name" : "dwiskus",
      "protected" : false,
      "id_str" : "2897431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565269992212807681\/vcP_oZKZ_normal.jpeg",
      "id" : 2897431,
      "verified" : false
    }
  },
  "id" : 428925055238553600,
  "created_at" : "2014-01-30 16:17:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428921386028257281",
  "geo" : { },
  "id_str" : "428922025067823104",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending sorry man. glad you're safe.",
  "id" : 428922025067823104,
  "in_reply_to_status_id" : 428921386028257281,
  "created_at" : "2014-01-30 16:05:54 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428920938781224961",
  "geo" : { },
  "id_str" : "428921179324153856",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending ouch dude",
  "id" : 428921179324153856,
  "in_reply_to_status_id" : 428920938781224961,
  "created_at" : "2014-01-30 16:02:32 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Pzf1eYdZAr",
      "expanded_url" : "http:\/\/www.npr.org\/2014\/01\/29\/264912750\/on-the-plains-an-oil-boom-is-transforming-nearly-everything",
      "display_url" : "npr.org\/2014\/01\/29\/264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428734734026293249",
  "text" : "Love the subtle\/cinemagraph style GIF usage in this NPR article: http:\/\/t.co\/Pzf1eYdZAr",
  "id" : 428734734026293249,
  "created_at" : "2014-01-30 03:41:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Rudick",
      "screen_name" : "tmrudick",
      "indices" : [ 0, 9 ],
      "id_str" : "15198826",
      "id" : 15198826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428732990676815872",
  "geo" : { },
  "id_str" : "428733386488696832",
  "in_reply_to_user_id" : 15198826,
  "text" : "@tmrudick merge conflicts in any xcode thing are the worst :(",
  "id" : 428733386488696832,
  "in_reply_to_status_id" : 428732990676815872,
  "created_at" : "2014-01-30 03:36:19 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie",
      "screen_name" : "ntljk",
      "indices" : [ 0, 6 ],
      "id_str" : "21778760",
      "id" : 21778760
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 7, 17 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428589427196051456",
  "geo" : { },
  "id_str" : "428589512692756480",
  "in_reply_to_user_id" : 21778760,
  "text" : "@ntljk @aquaranto has been hooked lately too.",
  "id" : 428589512692756480,
  "in_reply_to_status_id" : 428589427196051456,
  "created_at" : "2014-01-29 18:04:37 +0000",
  "in_reply_to_screen_name" : "ntljk",
  "in_reply_to_user_id_str" : "21778760",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 10, 19 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 20, 26 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428582075189325824",
  "geo" : { },
  "id_str" : "428582590610554880",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @dnsimple @aeden not here, just picked up an Airport Extreme and it works.",
  "id" : 428582590610554880,
  "in_reply_to_status_id" : 428582075189325824,
  "created_at" : "2014-01-29 17:37:06 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/428549092256387072\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/vbYULctFFq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKDIP0CEAAgfOv.png",
      "id_str" : "428549092260581376",
      "id" : 428549092260581376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKDIP0CEAAgfOv.png",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vbYULctFFq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428549092256387072",
  "text" : "Oh @github giant RSS button, how the might have fallen. http:\/\/t.co\/vbYULctFFq",
  "id" : 428549092256387072,
  "created_at" : "2014-01-29 15:24:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428531060058517504",
  "text" : "Hey southern states, let's trade. You take -17\u00BA to -25\u00BAF with wind chill, we'll take the 1-2\" of snow. Deal?",
  "id" : 428531060058517504,
  "created_at" : "2014-01-29 14:12:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 29, 37 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428406129123532801",
  "geo" : { },
  "id_str" : "428435515998629888",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant this guy is great. @noahhlo have you seen these?!",
  "id" : 428435515998629888,
  "in_reply_to_status_id" : 428406129123532801,
  "created_at" : "2014-01-29 07:52:41 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428391322693554177",
  "text" : "Spent over an hour today trying to get bluepill, Sinatra, and webrick to log to a file. Failed. Already want to ditch this for Rails.",
  "id" : 428391322693554177,
  "created_at" : "2014-01-29 04:57:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 57, 65 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428337925110374401",
  "geo" : { },
  "id_str" : "428346321636847616",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden we do want to bring back tacos and talks for @wnyruby...",
  "id" : 428346321636847616,
  "in_reply_to_status_id" : 428337925110374401,
  "created_at" : "2014-01-29 01:58:16 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428337817568018432",
  "text" : "Why hasn't the internet realized the latest Mario has you play as a cat?",
  "id" : 428337817568018432,
  "created_at" : "2014-01-29 01:24:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Megan Douglas",
      "screen_name" : "megdouglas",
      "indices" : [ 4, 15 ],
      "id_str" : "6073192",
      "id" : 6073192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428331926106021888",
  "geo" : { },
  "id_str" : "428335654909386752",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 @megdouglas congrats!!",
  "id" : 428335654909386752,
  "in_reply_to_status_id" : 428331926106021888,
  "created_at" : "2014-01-29 01:15:52 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    }, {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 8, 17 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428256338356215808",
  "geo" : { },
  "id_str" : "428256730774913024",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo @LawnMemo this is so you can record every Aqueous show in February right? ;)",
  "id" : 428256730774913024,
  "in_reply_to_status_id" : 428256338356215808,
  "created_at" : "2014-01-28 20:02:15 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Mattingly",
      "screen_name" : "nickelcity",
      "indices" : [ 0, 11 ],
      "id_str" : "137891464",
      "id" : 137891464
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 12, 25 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428211759359737856",
  "geo" : { },
  "id_str" : "428211932504403968",
  "in_reply_to_user_id" : 137891464,
  "text" : "@nickelcity @ChrisSmithAV +1, print out some coupons and get their rewards card",
  "id" : 428211932504403968,
  "in_reply_to_status_id" : 428211759359737856,
  "created_at" : "2014-01-28 17:04:15 +0000",
  "in_reply_to_screen_name" : "nickelcity",
  "in_reply_to_user_id_str" : "137891464",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 4, 13 ],
      "id_str" : "148198686",
      "id" : 148198686
    }, {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 14, 20 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/DSX7NYa0u7",
      "expanded_url" : "http:\/\/dyn.com\/support\/airport-time-capsule-with-dynamic-dns\/",
      "display_url" : "dyn.com\/support\/airpor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428172118400856064",
  "text" : "Hey @dnsimple @aeden can I do airport's global hostname via DNSimple? http:\/\/t.co\/DSX7NYa0u7",
  "id" : 428172118400856064,
  "created_at" : "2014-01-28 14:26:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 4, 10 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428166557852651520",
  "text" : "Hey @IFTTT getting the dreaded \"Recipe is still initializing, try again in 1 minute.\" on recipe 7783069, any ideas whats wrong?",
  "id" : 428166557852651520,
  "created_at" : "2014-01-28 14:03:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kareem Kouddous",
      "screen_name" : "kareemk",
      "indices" : [ 0, 8 ],
      "id_str" : "8859412",
      "id" : 8859412
    }, {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 9, 19 ],
      "id_str" : "14319947",
      "id" : 14319947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428165876190547968",
  "geo" : { },
  "id_str" : "428166282123304960",
  "in_reply_to_user_id" : 8859412,
  "text" : "@kareemk @onyxraven really need tags, can't depend on smartphones.",
  "id" : 428166282123304960,
  "in_reply_to_status_id" : 428165876190547968,
  "created_at" : "2014-01-28 14:02:51 +0000",
  "in_reply_to_screen_name" : "kareemk",
  "in_reply_to_user_id_str" : "8859412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428163334194479104",
  "text" : "Should clarify: Need reader + tags. Don't want a \"DIY\" kit.",
  "id" : 428163334194479104,
  "created_at" : "2014-01-28 13:51:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Baxter",
      "screen_name" : "himay",
      "indices" : [ 0, 6 ],
      "id_str" : "10155282",
      "id" : 10155282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428162800960409600",
  "geo" : { },
  "id_str" : "428162891120779264",
  "in_reply_to_user_id" : 10155282,
  "text" : "@himay way too complex. just want a reader + tags.",
  "id" : 428162891120779264,
  "in_reply_to_status_id" : 428162800960409600,
  "created_at" : "2014-01-28 13:49:22 +0000",
  "in_reply_to_screen_name" : "himay",
  "in_reply_to_user_id_str" : "10155282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428162098988724225",
  "text" : "Need suggestions for simple RFID\/Bluetooth\/NFC tags (with an API). No hardware hacking. Anyone?",
  "id" : 428162098988724225,
  "created_at" : "2014-01-28 13:46:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428030962056695809",
  "geo" : { },
  "id_str" : "428032534295744512",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod I actually enjoy the emotes. I just say \"oops\" to nearly every move",
  "id" : 428032534295744512,
  "in_reply_to_status_id" : 428030962056695809,
  "created_at" : "2014-01-28 05:11:23 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428026009321893889",
  "text" : "Won *one* game out of six tonight in Hearthstone. Not a forgiving (or encouraging) game still.",
  "id" : 428026009321893889,
  "created_at" : "2014-01-28 04:45:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428008817264033792",
  "text" : "Installing Hearthstone again. Not sure why, but willing to give it another shot.",
  "id" : 428008817264033792,
  "created_at" : "2014-01-28 03:37:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "indices" : [ 3, 11 ],
      "id_str" : "16316447",
      "id" : 16316447
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 80, 94 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/6adv0yZJzB",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/14208-buffalo-open-data",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428007157007527936",
  "text" : "RT @watch84: Buffalo Open Data get together tomorrow at 6pm! Hosted at the warm @coworkbuffalo downtown! http:\/\/t.co\/6adv0yZJzB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 67, 81 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/6adv0yZJzB",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/14208-buffalo-open-data",
        "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428005745250942976",
    "text" : "Buffalo Open Data get together tomorrow at 6pm! Hosted at the warm @coworkbuffalo downtown! http:\/\/t.co\/6adv0yZJzB",
    "id" : 428005745250942976,
    "created_at" : "2014-01-28 03:24:56 +0000",
    "user" : {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "protected" : false,
      "id_str" : "16316447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508105131569999872\/HtraEaM5_normal.jpeg",
      "id" : 16316447,
      "verified" : false
    }
  },
  "id" : 428007157007527936,
  "created_at" : "2014-01-28 03:30:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427997376465215489",
  "geo" : { },
  "id_str" : "428002822953512960",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety in Ruby?",
  "id" : 428002822953512960,
  "in_reply_to_status_id" : 427997376465215489,
  "created_at" : "2014-01-28 03:13:19 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 3, 14 ],
      "id_str" : "11694962",
      "id" : 11694962
    }, {
      "name" : "Alexsander Akers",
      "screen_name" : "a2",
      "indices" : [ 29, 32 ],
      "id_str" : "19876236",
      "id" : 19876236
    }, {
      "name" : "Wylie Conlon",
      "screen_name" : "wylieconlon",
      "indices" : [ 37, 49 ],
      "id_str" : "7028552",
      "id" : 7028552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/vsKkiokTGY",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/lifelink-peer-to-peer-life\/id718605548?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/lifelin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427988012296073216",
  "text" : "RT @Alex_Godin: Shout out to @a2 and @wylieconlon for making a dope Magic The Gathering app: https:\/\/t.co\/vsKkiokTGY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexsander Akers",
        "screen_name" : "a2",
        "indices" : [ 13, 16 ],
        "id_str" : "19876236",
        "id" : 19876236
      }, {
        "name" : "Wylie Conlon",
        "screen_name" : "wylieconlon",
        "indices" : [ 21, 33 ],
        "id_str" : "7028552",
        "id" : 7028552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/vsKkiokTGY",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/lifelink-peer-to-peer-life\/id718605548?mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/lifelin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427985696716881920",
    "text" : "Shout out to @a2 and @wylieconlon for making a dope Magic The Gathering app: https:\/\/t.co\/vsKkiokTGY",
    "id" : 427985696716881920,
    "created_at" : "2014-01-28 02:05:16 +0000",
    "user" : {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "protected" : false,
      "id_str" : "11694962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444228256741339136\/Wz2Cm7py_normal.jpeg",
      "id" : 11694962,
      "verified" : false
    }
  },
  "id" : 427988012296073216,
  "created_at" : "2014-01-28 02:14:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/427980327840010240\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n3qxNCXIXG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfB91yKCcAA2KO-.jpg",
      "id_str" : "427980327550611456",
      "id" : 427980327550611456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfB91yKCcAA2KO-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n3qxNCXIXG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427981684181852160",
  "text" : "RT @coworkbuffalo: Schools are closed, and the weather looks like this, so we're key members only tomorrow (Tuesday). Stay warm http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/427980327840010240\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/n3qxNCXIXG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfB91yKCcAA2KO-.jpg",
        "id_str" : "427980327550611456",
        "id" : 427980327550611456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfB91yKCcAA2KO-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 956,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 956,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 317,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/n3qxNCXIXG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427980327840010240",
    "text" : "Schools are closed, and the weather looks like this, so we're key members only tomorrow (Tuesday). Stay warm http:\/\/t.co\/n3qxNCXIXG",
    "id" : 427980327840010240,
    "created_at" : "2014-01-28 01:43:56 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 427981684181852160,
  "created_at" : "2014-01-28 01:49:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 3, 14 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 108, 122 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427906970637463553",
  "text" : "RT @gdiBuffalo: Come to our meeting to learn about being a teacher\/TA\/volunteer\/or sponsor! Tonight at 6:30 @coworkbuffalo who kindly provi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 92, 106 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427862618754146304",
    "text" : "Come to our meeting to learn about being a teacher\/TA\/volunteer\/or sponsor! Tonight at 6:30 @coworkbuffalo who kindly provided their space!",
    "id" : 427862618754146304,
    "created_at" : "2014-01-27 17:56:12 +0000",
    "user" : {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "protected" : false,
      "id_str" : "1232850504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3326614365\/de10a9f13010fc569fd25c1a6392366c_normal.png",
      "id" : 1232850504,
      "verified" : false
    }
  },
  "id" : 427906970637463553,
  "created_at" : "2014-01-27 20:52:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427845090740928512",
  "geo" : { },
  "id_str" : "427848719468204032",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx I just dumped the entire folder into ImageOptim. Automating this sounds like more trouble than it's worth :)",
  "id" : 427848719468204032,
  "in_reply_to_status_id" : 427845090740928512,
  "created_at" : "2014-01-27 17:00:58 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 36, 47 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427842190958526464",
  "geo" : { },
  "id_str" : "427842435415162880",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff double dream hands! \/cc @tenderlove",
  "id" : 427842435415162880,
  "in_reply_to_status_id" : 427842190958526464,
  "created_at" : "2014-01-27 16:36:00 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427840719605084160",
  "text" : "I need an IFTTT rule to compress my gifs folder. In the meantime... Saved 6.4MB out of 295.5MB. 2.2% overall (up to 42.4% per file)",
  "id" : 427840719605084160,
  "created_at" : "2014-01-27 16:29:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427838405892792320",
  "text" : "RT @ashedryden: actually it\u2019s pronounced jithub",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427667586122145793",
    "text" : "actually it\u2019s pronounced jithub",
    "id" : 427667586122145793,
    "created_at" : "2014-01-27 05:01:12 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 427838405892792320,
  "created_at" : "2014-01-27 16:19:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427824287701938177",
  "text" : "RT @zobar2: i have had it with this monkey-fighting snow on this monday-to-friday driveway",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427823951130013696",
    "text" : "i have had it with this monkey-fighting snow on this monday-to-friday driveway",
    "id" : 427823951130013696,
    "created_at" : "2014-01-27 15:22:33 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 427824287701938177,
  "created_at" : "2014-01-27 15:23:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427639773118070785",
  "geo" : { },
  "id_str" : "427641565431873536",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 YOLOSWAG",
  "id" : 427641565431873536,
  "in_reply_to_status_id" : 427639773118070785,
  "created_at" : "2014-01-27 03:17:49 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "indices" : [ 3, 15 ],
      "id_str" : "21758029",
      "id" : 21758029
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 40, 52 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427617087045922818",
  "text" : "RT @BuffaloEats: In case you missed it, @whereslloyd now takes credit cards. Pretty sure that news just made your day. \uD83D\uDE4C\uD83D\uDC4F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lloyd Taco Trucks",
        "screen_name" : "whereslloyd",
        "indices" : [ 23, 35 ],
        "id_str" : "156689065",
        "id" : 156689065
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427460700454531072",
    "text" : "In case you missed it, @whereslloyd now takes credit cards. Pretty sure that news just made your day. \uD83D\uDE4C\uD83D\uDC4F",
    "id" : 427460700454531072,
    "created_at" : "2014-01-26 15:19:07 +0000",
    "user" : {
      "name" : "Buffalo Eats",
      "screen_name" : "BuffaloEats",
      "protected" : false,
      "id_str" : "21758029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475826391154315264\/oyy7RakP_normal.jpeg",
      "id" : 21758029,
      "verified" : false
    }
  },
  "id" : 427617087045922818,
  "created_at" : "2014-01-27 01:40:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427320517029163008",
  "geo" : { },
  "id_str" : "427321708278583297",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant slow down there, WWF donor",
  "id" : 427321708278583297,
  "in_reply_to_status_id" : 427320517029163008,
  "created_at" : "2014-01-26 06:06:49 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427320079810719744",
  "geo" : { },
  "id_str" : "427320281842352128",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant it definitely boils down to that.",
  "id" : 427320281842352128,
  "in_reply_to_status_id" : 427320079810719744,
  "created_at" : "2014-01-26 06:01:09 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427315568094363648",
  "text" : "Not sure why I thought watching Blackfish at 11PM was a good idea, but holy. shit.",
  "id" : 427315568094363648,
  "created_at" : "2014-01-26 05:42:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kim",
      "screen_name" : "dankim",
      "indices" : [ 0, 7 ],
      "id_str" : "7979212",
      "id" : 7979212
    }, {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 20, 26 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427276661373952000",
  "geo" : { },
  "id_str" : "427278301833355264",
  "in_reply_to_user_id" : 7979212,
  "text" : "@dankim it's mostly @parkr these days. Dealing with PRs of a different nature.",
  "id" : 427278301833355264,
  "in_reply_to_status_id" : 427276661373952000,
  "created_at" : "2014-01-26 03:14:20 +0000",
  "in_reply_to_screen_name" : "dankim",
  "in_reply_to_user_id_str" : "7979212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427241498615484416",
  "geo" : { },
  "id_str" : "427264421967040512",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d the association with \"brogrammers\" is the main problem imo",
  "id" : 427264421967040512,
  "in_reply_to_status_id" : 427241498615484416,
  "created_at" : "2014-01-26 02:19:11 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427261347802648576",
  "geo" : { },
  "id_str" : "427264180563877888",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba he was on stage with phish at Halloween!",
  "id" : 427264180563877888,
  "in_reply_to_status_id" : 427261347802648576,
  "created_at" : "2014-01-26 02:18:13 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427135199588020224",
  "geo" : { },
  "id_str" : "427135478190452736",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I just learned the meaning of this word last week. I had a sad.",
  "id" : 427135478190452736,
  "in_reply_to_status_id" : 427135199588020224,
  "created_at" : "2014-01-25 17:46:48 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/RmY2AjOSyQ",
      "expanded_url" : "http:\/\/bropages.org\/",
      "display_url" : "bropages.org"
    } ]
  },
  "geo" : { },
  "id_str" : "427131948708802560",
  "text" : "\"Bropages\" instead of \"Manpages\" ? Are you fucking serious? http:\/\/t.co\/RmY2AjOSyQ What would possess someone to think this is a good idea?",
  "id" : 427131948708802560,
  "created_at" : "2014-01-25 17:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427085326847606784",
  "geo" : { },
  "id_str" : "427086241289342978",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh Yep!",
  "id" : 427086241289342978,
  "in_reply_to_status_id" : 427085326847606784,
  "created_at" : "2014-01-25 14:31:09 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duncan Davidson",
      "screen_name" : "duncan",
      "indices" : [ 3, 10 ],
      "id_str" : "823098",
      "id" : 823098
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/duncan\/status\/426934971119730688\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/UobUZMc9Hf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BezHGBUIMAArpgr.png",
      "id_str" : "426934970939355136",
      "id" : 426934970939355136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BezHGBUIMAArpgr.png",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 839
      } ],
      "display_url" : "pic.twitter.com\/UobUZMc9Hf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/szVPkdMUgP",
      "expanded_url" : "http:\/\/buff.ly\/Jm92TD",
      "display_url" : "buff.ly\/Jm92TD"
    } ]
  },
  "geo" : { },
  "id_str" : "426935446560452608",
  "text" : "RT @duncan: \u201CPeople don't buy products; they buy better versions of themselves.\u201D \u2014Samuel Hulick http:\/\/t.co\/szVPkdMUgP http:\/\/t.co\/UobUZMc9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/duncan\/status\/426934971119730688\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/UobUZMc9Hf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BezHGBUIMAArpgr.png",
        "id_str" : "426934970939355136",
        "id" : 426934970939355136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BezHGBUIMAArpgr.png",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 839
        } ],
        "display_url" : "pic.twitter.com\/UobUZMc9Hf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/szVPkdMUgP",
        "expanded_url" : "http:\/\/buff.ly\/Jm92TD",
        "display_url" : "buff.ly\/Jm92TD"
      } ]
    },
    "geo" : { },
    "id_str" : "426934971119730688",
    "text" : "\u201CPeople don't buy products; they buy better versions of themselves.\u201D \u2014Samuel Hulick http:\/\/t.co\/szVPkdMUgP http:\/\/t.co\/UobUZMc9Hf",
    "id" : 426934971119730688,
    "created_at" : "2014-01-25 04:30:03 +0000",
    "user" : {
      "name" : "Duncan Davidson",
      "screen_name" : "duncan",
      "protected" : false,
      "id_str" : "823098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630897965\/6aaefdb63045ad9ac50e1bb02f606640_normal.jpeg",
      "id" : 823098,
      "verified" : false
    }
  },
  "id" : 426935446560452608,
  "created_at" : "2014-01-25 04:31:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426934538619457536",
  "text" : "Of course, after I tweet about the Keynote recording thing it hangs on exporting. :(",
  "id" : 426934538619457536,
  "created_at" : "2014-01-25 04:28:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426925635559120896",
  "text" : "Learned tonight you don't need a screencasting app to record in Keynote. Play &gt; Record Slideshow, then File &gt; Export To &gt; Quicktime. BOOM!",
  "id" : 426925635559120896,
  "created_at" : "2014-01-25 03:52:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Czarnecki",
      "screen_name" : "CzarneckiD",
      "indices" : [ 0, 11 ],
      "id_str" : "13393",
      "id" : 13393
    }, {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "indices" : [ 12, 17 ],
      "id_str" : "1385921",
      "id" : 1385921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426872432826138624",
  "geo" : { },
  "id_str" : "426894226220015616",
  "in_reply_to_user_id" : 13393,
  "text" : "@CzarneckiD @d00n you are not human",
  "id" : 426894226220015616,
  "in_reply_to_status_id" : 426872432826138624,
  "created_at" : "2014-01-25 01:48:09 +0000",
  "in_reply_to_screen_name" : "CzarneckiD",
  "in_reply_to_user_id_str" : "13393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426869195901390849",
  "geo" : { },
  "id_str" : "426869946799230976",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck pure motherfucking magic",
  "id" : 426869946799230976,
  "in_reply_to_status_id" : 426869195901390849,
  "created_at" : "2014-01-25 00:11:40 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/fPU1tmCO02",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PDZcqBgCS74",
      "display_url" : "youtube.com\/watch?v=PDZcqB\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426853047373807617",
  "geo" : { },
  "id_str" : "426853308142071808",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky http:\/\/t.co\/fPU1tmCO02",
  "id" : 426853308142071808,
  "in_reply_to_status_id" : 426853047373807617,
  "created_at" : "2014-01-24 23:05:33 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/p1MbxBE0Cq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4YBxeDN4tbk",
      "display_url" : "youtube.com\/watch?v=4YBxeD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426818761182556160",
  "text" : "LOOKS LIKE CRAP? IT IS CRAP! http:\/\/t.co\/p1MbxBE0Cq",
  "id" : 426818761182556160,
  "created_at" : "2014-01-24 20:48:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/hsTth4XuDp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JvQZC3wJRNw",
      "display_url" : "youtube.com\/watch?v=JvQZC3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426767819309469696",
  "text" : "What is Toronto http:\/\/t.co\/hsTth4XuDp",
  "id" : 426767819309469696,
  "created_at" : "2014-01-24 17:25:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/Ft7NHliyaN",
      "expanded_url" : "http:\/\/whyisthereanything.org\/",
      "display_url" : "whyisthereanything.org"
    } ]
  },
  "in_reply_to_status_id_str" : "426740640857071617",
  "geo" : { },
  "id_str" : "426741274859692032",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw http:\/\/t.co\/Ft7NHliyaN",
  "id" : 426741274859692032,
  "in_reply_to_status_id" : 426740640857071617,
  "created_at" : "2014-01-24 15:40:23 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 0, 5 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426740492962131968",
  "geo" : { },
  "id_str" : "426740612621017088",
  "in_reply_to_user_id" : 12534,
  "text" : "@beep no worries! sounds good.",
  "id" : 426740612621017088,
  "in_reply_to_status_id" : 426740492962131968,
  "created_at" : "2014-01-24 15:37:45 +0000",
  "in_reply_to_screen_name" : "beep",
  "in_reply_to_user_id_str" : "12534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 0, 5 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426737577383972864",
  "geo" : { },
  "id_str" : "426737812969230337",
  "in_reply_to_user_id" : 12534,
  "text" : "@beep looks like there's an xpath reader in Pipes...so should be pretty easy. Just getting a 403 Forbidden, I bet due to the robots.txt",
  "id" : 426737812969230337,
  "in_reply_to_status_id" : 426737577383972864,
  "created_at" : "2014-01-24 15:26:37 +0000",
  "in_reply_to_screen_name" : "beep",
  "in_reply_to_user_id_str" : "12534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426737054446129152",
  "geo" : { },
  "id_str" : "426737233530347522",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa ugh. i guess anything is &gt; 0 on average per week ;)",
  "id" : 426737233530347522,
  "in_reply_to_status_id" : 426737054446129152,
  "created_at" : "2014-01-24 15:24:19 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 0, 5 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426736010890719232",
  "in_reply_to_user_id" : 12534,
  "text" : "@beep any chance you'd let Yahoo Pipes into reading bukk.it? Trying to get an RSS feed of the latest goodies :)",
  "id" : 426736010890719232,
  "created_at" : "2014-01-24 15:19:28 +0000",
  "in_reply_to_screen_name" : "beep",
  "in_reply_to_user_id_str" : "12534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426735390750285824",
  "geo" : { },
  "id_str" : "426735698276663296",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa how many\/week was normal at MS?",
  "id" : 426735698276663296,
  "in_reply_to_status_id" : 426735390750285824,
  "created_at" : "2014-01-24 15:18:13 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 0, 6 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426735153633718274",
  "geo" : { },
  "id_str" : "426735251709100032",
  "in_reply_to_user_id" : 325866689,
  "text" : "@mwn3d you have an avatar!!!!",
  "id" : 426735251709100032,
  "in_reply_to_status_id" : 426735153633718274,
  "created_at" : "2014-01-24 15:16:27 +0000",
  "in_reply_to_screen_name" : "mwn3d",
  "in_reply_to_user_id_str" : "325866689",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 30, 39 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426731707828428800",
  "text" : "It's nice to get emails about @gitready still. Glad it helps so many people after all this time.",
  "id" : 426731707828428800,
  "created_at" : "2014-01-24 15:02:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/svmxyJMh8g",
      "expanded_url" : "http:\/\/www.dangigante.com\/2014\/01\/23\/the-restaurant-story\/",
      "display_url" : "dangigante.com\/2014\/01\/23\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426731086626824192",
  "text" : "Awesome little story about raising prices and getting to know your customers better: http:\/\/t.co\/svmxyJMh8g",
  "id" : 426731086626824192,
  "created_at" : "2014-01-24 14:59:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "indices" : [ 3, 15 ],
      "id_str" : "261031908",
      "id" : 261031908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/VKfP28H50I",
      "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/north-buffalo-hertel\/house-of-horrors-greets-family-after-dream-vacation-20140123",
      "display_url" : "buffalonews.com\/city-region\/no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426709198177837056",
  "text" : "RT @HeyRaChaCha: This horrible Parkside House of Horrors story is horrifying: http:\/\/t.co\/VKfP28H50I #Buffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/VKfP28H50I",
        "expanded_url" : "http:\/\/www.buffalonews.com\/city-region\/north-buffalo-hertel\/house-of-horrors-greets-family-after-dream-vacation-20140123",
        "display_url" : "buffalonews.com\/city-region\/no\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426693955024322561",
    "text" : "This horrible Parkside House of Horrors story is horrifying: http:\/\/t.co\/VKfP28H50I #Buffalo",
    "id" : 426693955024322561,
    "created_at" : "2014-01-24 12:32:21 +0000",
    "user" : {
      "name" : "Ra Cha Cha",
      "screen_name" : "HeyRaChaCha",
      "protected" : false,
      "id_str" : "261031908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1262350601\/userpic-5725-100x100_normal.png",
      "id" : 261031908,
      "verified" : false
    }
  },
  "id" : 426709198177837056,
  "created_at" : "2014-01-24 13:32:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 3, 14 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/DljTxhLPlG",
      "expanded_url" : "http:\/\/www.dangigante.com\/2014\/01\/23\/the-restaurant-story\/",
      "display_url" : "dangigante.com\/2014\/01\/23\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426570898196267008",
  "text" : "RT @dangigante: The famous \"Restaurant story\" that I tell everyone. now on my blog - http:\/\/t.co\/DljTxhLPlG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/DljTxhLPlG",
        "expanded_url" : "http:\/\/www.dangigante.com\/2014\/01\/23\/the-restaurant-story\/",
        "display_url" : "dangigante.com\/2014\/01\/23\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426563490975715329",
    "text" : "The famous \"Restaurant story\" that I tell everyone. now on my blog - http:\/\/t.co\/DljTxhLPlG",
    "id" : 426563490975715329,
    "created_at" : "2014-01-24 03:53:56 +0000",
    "user" : {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "protected" : false,
      "id_str" : "43151378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482218130996232192\/bISq7rRg_normal.jpeg",
      "id" : 43151378,
      "verified" : false
    }
  },
  "id" : 426570898196267008,
  "created_at" : "2014-01-24 04:23:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/s3mbY5fxaL",
      "expanded_url" : "http:\/\/cdn.iwastesomuchtime.com\/February-12-2012-18-29-49-atempt.jpg",
      "display_url" : "cdn.iwastesomuchtime.com\/February-12-20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426494700527177728",
  "geo" : { },
  "id_str" : "426494930752520192",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw http:\/\/t.co\/s3mbY5fxaL",
  "id" : 426494930752520192,
  "in_reply_to_status_id" : 426494700527177728,
  "created_at" : "2014-01-23 23:21:30 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NvVMyK8Jm8",
      "expanded_url" : "http:\/\/birdnote.s3.amazonaws.com\/Birdnote\/2007\/Oct_2007\/071010-Bird_s-Eye-View-II.mp3",
      "display_url" : "birdnote.s3.amazonaws.com\/Birdnote\/2007\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426493414184456192",
  "geo" : { },
  "id_str" : "426494143854956544",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw can you state these facts in a dulcet tone with the BirdNote theme song? http:\/\/t.co\/NvVMyK8Jm8",
  "id" : 426494143854956544,
  "in_reply_to_status_id" : 426493414184456192,
  "created_at" : "2014-01-23 23:18:22 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 5, 16 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/b7h5IduY1p",
      "expanded_url" : "http:\/\/bgr.com\/2014\/01\/23\/google-plus-unwanted-invitations-criticism\/",
      "display_url" : "bgr.com\/2014\/01\/23\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426446320916631552",
  "text" : "Man (@kevinpurdy) who wrote entire book on Google+ has no idea how to stop it from spamming him: http:\/\/t.co\/b7h5IduY1p",
  "id" : 426446320916631552,
  "created_at" : "2014-01-23 20:08:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBlackMarket",
      "screen_name" : "theBMFT",
      "indices" : [ 11, 19 ],
      "id_str" : "900882032",
      "id" : 900882032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/MNgeDXPMIm",
      "expanded_url" : "http:\/\/www.thebmft.com\/vday\/",
      "display_url" : "thebmft.com\/vday\/"
    } ]
  },
  "geo" : { },
  "id_str" : "426417292394496001",
  "text" : "Food truck @theBMFT comes to the rescue for new parents on vday: http:\/\/t.co\/MNgeDXPMIm",
  "id" : 426417292394496001,
  "created_at" : "2014-01-23 18:12:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/addmBpraMQ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/gaming\/comments\/1vyekx\/hillarys_mask_day_3\/",
      "display_url" : "reddit.com\/r\/gaming\/comme\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426397610044174336",
  "geo" : { },
  "id_str" : "426406008076767233",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex You win today, sir. Also, http:\/\/t.co\/addmBpraMQ",
  "id" : 426406008076767233,
  "in_reply_to_status_id" : 426397610044174336,
  "created_at" : "2014-01-23 17:28:09 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 3, 19 ],
      "id_str" : "63124269",
      "id" : 63124269
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 21, 27 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/robertodecurnex\/status\/426397610044174336\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/SxIkJCh8cP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BereXgBCMAAV1eL.jpg",
      "id_str" : "426397610052562944",
      "id" : 426397610052562944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BereXgBCMAAV1eL.jpg",
      "sizes" : [ {
        "h" : 670,
        "resize" : "fit",
        "w" : 1191
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SxIkJCh8cP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426405694502236163",
  "text" : "RT @robertodecurnex: @qrush last one http:\/\/t.co\/SxIkJCh8cP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/robertodecurnex\/status\/426397610044174336\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/SxIkJCh8cP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BereXgBCMAAV1eL.jpg",
        "id_str" : "426397610052562944",
        "id" : 426397610052562944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BereXgBCMAAV1eL.jpg",
        "sizes" : [ {
          "h" : 670,
          "resize" : "fit",
          "w" : 1191
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SxIkJCh8cP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "426393078350368768",
    "geo" : { },
    "id_str" : "426397610044174336",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush last one http:\/\/t.co\/SxIkJCh8cP",
    "id" : 426397610044174336,
    "in_reply_to_status_id" : 426393078350368768,
    "created_at" : "2014-01-23 16:54:47 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "protected" : false,
      "id_str" : "63124269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427905631199064064\/91pV17Xt_normal.png",
      "id" : 63124269,
      "verified" : false
    }
  },
  "id" : 426405694502236163,
  "created_at" : "2014-01-23 17:26:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426391584200876032",
  "geo" : { },
  "id_str" : "426393078350368768",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex now on Day 3!",
  "id" : 426393078350368768,
  "in_reply_to_status_id" : 426391584200876032,
  "created_at" : "2014-01-23 16:36:46 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 3, 19 ],
      "id_str" : "63124269",
      "id" : 63124269
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 27, 33 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/robertodecurnex\/status\/426391584200876032\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/dVx67rlgtv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BerY4v_CYAAhSVL.png",
      "id_str" : "426391584205070336",
      "id" : 426391584205070336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerY4v_CYAAhSVL.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/dVx67rlgtv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426391751075430401",
  "text" : "RT @robertodecurnex: C'mon @qrush ! I have a paid job you know? :P http:\/\/t.co\/dVx67rlgtv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 6, 12 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/robertodecurnex\/status\/426391584200876032\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/dVx67rlgtv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BerY4v_CYAAhSVL.png",
        "id_str" : "426391584205070336",
        "id" : 426391584205070336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerY4v_CYAAhSVL.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/dVx67rlgtv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "426386355745079298",
    "geo" : { },
    "id_str" : "426391584200876032",
    "in_reply_to_user_id" : 5743852,
    "text" : "C'mon @qrush ! I have a paid job you know? :P http:\/\/t.co\/dVx67rlgtv",
    "id" : 426391584200876032,
    "in_reply_to_status_id" : 426386355745079298,
    "created_at" : "2014-01-23 16:30:50 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "protected" : false,
      "id_str" : "63124269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427905631199064064\/91pV17Xt_normal.png",
      "id" : 63124269,
      "verified" : false
    }
  },
  "id" : 426391751075430401,
  "created_at" : "2014-01-23 16:31:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Stoddart",
      "screen_name" : "danielstoddart",
      "indices" : [ 0, 15 ],
      "id_str" : "24848851",
      "id" : 24848851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426391289639084032",
  "geo" : { },
  "id_str" : "426391609991651328",
  "in_reply_to_user_id" : 24848851,
  "text" : "@danielstoddart agreed!",
  "id" : 426391609991651328,
  "in_reply_to_status_id" : 426391289639084032,
  "created_at" : "2014-01-23 16:30:56 +0000",
  "in_reply_to_screen_name" : "danielstoddart",
  "in_reply_to_user_id_str" : "24848851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven R. Baker",
      "screen_name" : "srbaker",
      "indices" : [ 3, 11 ],
      "id_str" : "14106454",
      "id" : 14106454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426390872515547136",
  "text" : "RT @srbaker: Remember when people worked on open source and community projects because they loved it, without requiring fundraising goals b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426354200755597313",
    "text" : "Remember when people worked on open source and community projects because they loved it, without requiring fundraising goals be met first?",
    "id" : 426354200755597313,
    "created_at" : "2014-01-23 14:02:17 +0000",
    "user" : {
      "name" : "Steven R. Baker",
      "screen_name" : "srbaker",
      "protected" : false,
      "id_str" : "14106454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000675463825\/5729a6aca99acd55508b1313a01aa672_normal.jpeg",
      "id" : 14106454,
      "verified" : false
    }
  },
  "id" : 426390872515547136,
  "created_at" : "2014-01-23 16:28:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2192() \u007B Robertt \u007D",
      "screen_name" : "robertodecurnex",
      "indices" : [ 0, 16 ],
      "id_str" : "63124269",
      "id" : 63124269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426385335799398400",
  "geo" : { },
  "id_str" : "426386355745079298",
  "in_reply_to_user_id" : 63124269,
  "text" : "@robertodecurnex no, other way around!",
  "id" : 426386355745079298,
  "in_reply_to_status_id" : 426385335799398400,
  "created_at" : "2014-01-23 16:10:03 +0000",
  "in_reply_to_screen_name" : "robertodecurnex",
  "in_reply_to_user_id_str" : "63124269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/YkkzShGHP3",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/141781-save-hot-posts-in-r-gifs-to-gifs-folder-in-dropbox",
      "display_url" : "ifttt.com\/recipes\/141781\u2026"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/SM2oZ72iBJ",
      "expanded_url" : "https:\/\/ifttt.com\/recipes\/141780-save-hot-posts-in-r-wheredidthesodago-to-gifs-folder-in-dropbox",
      "display_url" : "ifttt.com\/recipes\/141780\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426386117164691456",
  "text" : "In case you want those recipes (and push notifications via the Dropbox desktop app!) https:\/\/t.co\/YkkzShGHP3 https:\/\/t.co\/SM2oZ72iBJ",
  "id" : 426386117164691456,
  "created_at" : "2014-01-23 16:09:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidjoachim\/status\/426378879985807361\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/1U45s18sgT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BerNVQeIIAA6jZi.jpg",
      "id_str" : "426378879822209024",
      "id" : 426378879822209024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerNVQeIIAA6jZi.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/1U45s18sgT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426382234958831616",
  "text" : "Someone needs to photoshop this cover into Majora's Mask  http:\/\/t.co\/1U45s18sgT",
  "id" : 426382234958831616,
  "created_at" : "2014-01-23 15:53:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 22, 28 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/426380056676409344\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/WTcqf2E36A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BerOZwnCIAAJmcn.png",
      "id_str" : "426380056680603648",
      "id" : 426380056680603648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerOZwnCIAAJmcn.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1278
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WTcqf2E36A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426380056676409344",
  "text" : "Possibly the best two @IFTTT recipes I have ever created http:\/\/t.co\/WTcqf2E36A",
  "id" : 426380056676409344,
  "created_at" : "2014-01-23 15:45:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "indices" : [ 3, 17 ],
      "id_str" : "242645565",
      "id" : 242645565
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 28, 42 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Geek Feminism blog",
      "screen_name" : "geekfeminism",
      "indices" : [ 85, 98 ],
      "id_str" : "64809827",
      "id" : 64809827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dmQ0va2ojU",
      "expanded_url" : "http:\/\/geekfeminism.wikia.com\/wiki\/Conference_anti-harassment\/Adoption#Coworking_spaces",
      "display_url" : "geekfeminism.wikia.com\/wiki\/Conferenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426370953052819456",
  "text" : "RT @adainitiative: Congrats @coworkbuffalo on being the first coworking space on the @geekfeminism anti-harassment policy adoption list! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 9, 23 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Geek Feminism blog",
        "screen_name" : "geekfeminism",
        "indices" : [ 66, 79 ],
        "id_str" : "64809827",
        "id" : 64809827
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/dmQ0va2ojU",
        "expanded_url" : "http:\/\/geekfeminism.wikia.com\/wiki\/Conference_anti-harassment\/Adoption#Coworking_spaces",
        "display_url" : "geekfeminism.wikia.com\/wiki\/Conferenc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426363754553806848",
    "text" : "Congrats @coworkbuffalo on being the first coworking space on the @geekfeminism anti-harassment policy adoption list! http:\/\/t.co\/dmQ0va2ojU",
    "id" : 426363754553806848,
    "created_at" : "2014-01-23 14:40:15 +0000",
    "user" : {
      "name" : "The Ada Initiative",
      "screen_name" : "adainitiative",
      "protected" : false,
      "id_str" : "242645565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1237659527\/avatar-adainitiative2_normal.png",
      "id" : 242645565,
      "verified" : true
    }
  },
  "id" : 426370953052819456,
  "created_at" : "2014-01-23 15:08:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/prhOQj75fc",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=Wcz_kDCBTBk",
      "display_url" : "m.youtube.com\/watch?v=Wcz_kD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426191041654718464",
  "geo" : { },
  "id_str" : "426192527931097088",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents http:\/\/t.co\/prhOQj75fc",
  "id" : 426192527931097088,
  "in_reply_to_status_id" : 426191041654718464,
  "created_at" : "2014-01-23 03:19:51 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/iGL7KXSLdq",
      "expanded_url" : "http:\/\/bit.ly\/1eCxWK0",
      "display_url" : "bit.ly\/1eCxWK0"
    } ]
  },
  "geo" : { },
  "id_str" : "426185904202338304",
  "text" : "RT @ashedryden: Really happy to see @coworkbuffalo added to the list of places with Anti-harassment Policies \u2764\u2764\u2764\u2764 http:\/\/t.co\/iGL7KXSLdq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 20, 34 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/iGL7KXSLdq",
        "expanded_url" : "http:\/\/bit.ly\/1eCxWK0",
        "display_url" : "bit.ly\/1eCxWK0"
      } ]
    },
    "geo" : { },
    "id_str" : "426183325598756864",
    "text" : "Really happy to see @coworkbuffalo added to the list of places with Anti-harassment Policies \u2764\u2764\u2764\u2764 http:\/\/t.co\/iGL7KXSLdq",
    "id" : 426183325598756864,
    "created_at" : "2014-01-23 02:43:17 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 426185904202338304,
  "created_at" : "2014-01-23 02:53:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 10, 24 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "indyhall",
      "screen_name" : "indyhall",
      "indices" : [ 47, 56 ],
      "id_str" : "7493702",
      "id" : 7493702
    }, {
      "name" : "Double Union",
      "screen_name" : "DoubleUnionSF",
      "indices" : [ 98, 112 ],
      "id_str" : "1547329232",
      "id" : 1547329232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mdxVPx70sc",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "426185802784055297",
  "text" : "Published @coworkbuffalo's agreement (based on @indyhall's) and anti-harrassment policy (based on @doubleunionsf's): http:\/\/t.co\/mdxVPx70sc",
  "id" : 426185802784055297,
  "created_at" : "2014-01-23 02:53:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426149876192542720",
  "geo" : { },
  "id_str" : "426150933937270784",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss having a debug checklist that I literally wrote down helped immensely",
  "id" : 426150933937270784,
  "in_reply_to_status_id" : 426149876192542720,
  "created_at" : "2014-01-23 00:34:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 3, 11 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gH27sS3EUe",
      "expanded_url" : "http:\/\/www.subtraction.com\/2014\/01\/21\/announcing-kidpost",
      "display_url" : "subtraction.com\/2014\/01\/21\/ann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426150673386708992",
  "text" : "RT @jkottke: Every newish parent who is also a web developer has a version of this in their head; glad Khoi et al are building it: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/gH27sS3EUe",
        "expanded_url" : "http:\/\/www.subtraction.com\/2014\/01\/21\/announcing-kidpost",
        "display_url" : "subtraction.com\/2014\/01\/21\/ann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426144733455339520",
    "text" : "Every newish parent who is also a web developer has a version of this in their head; glad Khoi et al are building it: http:\/\/t.co\/gH27sS3EUe",
    "id" : 426144733455339520,
    "created_at" : "2014-01-23 00:09:56 +0000",
    "user" : {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "protected" : false,
      "id_str" : "1305941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523901924160978944\/RmogMbgi_normal.jpeg",
      "id" : 1305941,
      "verified" : true
    }
  },
  "id" : 426150673386708992,
  "created_at" : "2014-01-23 00:33:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426110009546522625",
  "geo" : { },
  "id_str" : "426110239339859968",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy \"BECAUSE KEVIN SAYS SO\"",
  "id" : 426110239339859968,
  "in_reply_to_status_id" : 426110009546522625,
  "created_at" : "2014-01-22 21:52:52 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426096502507728896",
  "geo" : { },
  "id_str" : "426096590130909184",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden I still don't know what the Z is for",
  "id" : 426096590130909184,
  "in_reply_to_status_id" : 426096502507728896,
  "created_at" : "2014-01-22 20:58:38 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426095867234226177",
  "geo" : { },
  "id_str" : "426096434547400704",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden LOL OK ZOMG",
  "id" : 426096434547400704,
  "in_reply_to_status_id" : 426095867234226177,
  "created_at" : "2014-01-22 20:58:01 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426041387222458368",
  "text" : "HTTP Error Code 444 - Revolution In Progress: Request processing delayed due to revolution occurring.",
  "id" : 426041387222458368,
  "created_at" : "2014-01-22 17:19:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "Tiny Mountain",
      "screen_name" : "heymadeleine",
      "indices" : [ 25, 38 ],
      "id_str" : "17905569",
      "id" : 17905569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426040735800913920",
  "geo" : { },
  "id_str" : "426041059055906817",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda looks like @heymadeleine to me",
  "id" : 426041059055906817,
  "in_reply_to_status_id" : 426040735800913920,
  "created_at" : "2014-01-22 17:17:58 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lester",
      "screen_name" : "petdance",
      "indices" : [ 3, 12 ],
      "id_str" : "16843",
      "id" : 16843
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andrey_butov\/status\/426018565561401344\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/c6p187YOBN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BemFoMxCAAAabEH.png",
      "id_str" : "426018565431361536",
      "id" : 426018565431361536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BemFoMxCAAAabEH.png",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c6p187YOBN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426038587562270720",
  "text" : "RT @petdance: Sometimes open source software isn't the #1 priority in our lives. https:\/\/t.co\/c6p187YOBN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andrey_butov\/status\/426018565561401344\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/c6p187YOBN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BemFoMxCAAAabEH.png",
        "id_str" : "426018565431361536",
        "id" : 426018565431361536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BemFoMxCAAAabEH.png",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 842
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 842
        }, {
          "h" : 164,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/c6p187YOBN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426034150781353984",
    "text" : "Sometimes open source software isn't the #1 priority in our lives. https:\/\/t.co\/c6p187YOBN",
    "id" : 426034150781353984,
    "created_at" : "2014-01-22 16:50:31 +0000",
    "user" : {
      "name" : "Andy Lester",
      "screen_name" : "petdance",
      "protected" : false,
      "id_str" : "16843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2115111690\/petdance_normal.png",
      "id" : 16843,
      "verified" : false
    }
  },
  "id" : 426038587562270720,
  "created_at" : "2014-01-22 17:08:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 37, 51 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Brian Borncamp",
      "screen_name" : "borncamp",
      "indices" : [ 61, 70 ],
      "id_str" : "1002573926",
      "id" : 1002573926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mRoQNLW1Tu",
      "expanded_url" : "https:\/\/www.google.com\/fusiontables\/embedviz?q=select+col0+from+10yC7u0V597DiKBMGC2u9_Bgx2vncS5tRo27guwM&viz=MAP&h=false&lat=42.92193009396348&lng=-78.85944089709471&t=1&z=14&l=col0&y=2&tmplt=2&hml=GEOCODABLE",
      "display_url" : "google.com\/fusiontables\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426009793602412545",
  "text" : "RT @kevinpurdy: Open data mensch and @coworkbuffalo mainstay @borncamp mapped the 100 oldest houses in Buffalo: https:\/\/t.co\/mRoQNLW1Tu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 21, 35 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Brian Borncamp",
        "screen_name" : "borncamp",
        "indices" : [ 45, 54 ],
        "id_str" : "1002573926",
        "id" : 1002573926
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/mRoQNLW1Tu",
        "expanded_url" : "https:\/\/www.google.com\/fusiontables\/embedviz?q=select+col0+from+10yC7u0V597DiKBMGC2u9_Bgx2vncS5tRo27guwM&viz=MAP&h=false&lat=42.92193009396348&lng=-78.85944089709471&t=1&z=14&l=col0&y=2&tmplt=2&hml=GEOCODABLE",
        "display_url" : "google.com\/fusiontables\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426006347025350656",
    "text" : "Open data mensch and @coworkbuffalo mainstay @borncamp mapped the 100 oldest houses in Buffalo: https:\/\/t.co\/mRoQNLW1Tu",
    "id" : 426006347025350656,
    "created_at" : "2014-01-22 15:00:02 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 426009793602412545,
  "created_at" : "2014-01-22 15:13:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425849278561398784",
  "geo" : { },
  "id_str" : "425859872387657728",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick what the actual fuck? How this affects rubygems worries me :(",
  "id" : 425859872387657728,
  "in_reply_to_status_id" : 425849278561398784,
  "created_at" : "2014-01-22 05:18:00 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425802955103535106",
  "geo" : { },
  "id_str" : "425804868234641409",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant how about them pancakes?",
  "id" : 425804868234641409,
  "in_reply_to_status_id" : 425802955103535106,
  "created_at" : "2014-01-22 01:39:26 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    }, {
      "name" : "Dooley O'Rourke",
      "screen_name" : "Dooley_ORourke",
      "indices" : [ 67, 82 ],
      "id_str" : "382764044",
      "id" : 382764044
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dooley_ORourke\/status\/425734602989506560\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/MMlMsa1zJU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeiDXZwIMAA1ND7.jpg",
      "id_str" : "425734602859491328",
      "id" : 425734602859491328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeiDXZwIMAA1ND7.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/MMlMsa1zJU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425801114953347072",
  "text" : "RT @BuffaloRising: It's happening. . . http:\/\/t.co\/MMlMsa1zJU (via @Dooley_ORourke)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dooley O'Rourke",
        "screen_name" : "Dooley_ORourke",
        "indices" : [ 48, 63 ],
        "id_str" : "382764044",
        "id" : 382764044
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Dooley_ORourke\/status\/425734602989506560\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/MMlMsa1zJU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeiDXZwIMAA1ND7.jpg",
        "id_str" : "425734602859491328",
        "id" : 425734602859491328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeiDXZwIMAA1ND7.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/MMlMsa1zJU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425794967491993600",
    "text" : "It's happening. . . http:\/\/t.co\/MMlMsa1zJU (via @Dooley_ORourke)",
    "id" : 425794967491993600,
    "created_at" : "2014-01-22 01:00:05 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 425801114953347072,
  "created_at" : "2014-01-22 01:24:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 3, 10 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425783345872519168",
  "text" : "RT @bantik: They are also there to make it clear that your community has standards and that standards will be enforced.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "425768768422174721",
    "geo" : { },
    "id_str" : "425768914153271296",
    "in_reply_to_user_id" : 9526722,
    "text" : "They are also there to make it clear that your community has standards and that standards will be enforced.",
    "id" : 425768914153271296,
    "in_reply_to_status_id" : 425768768422174721,
    "created_at" : "2014-01-21 23:16:34 +0000",
    "in_reply_to_screen_name" : "CoralineAda",
    "in_reply_to_user_id_str" : "9526722",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 425783345872519168,
  "created_at" : "2014-01-22 00:13:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 3, 10 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425783331016290304",
  "text" : "RT @bantik: Codes of conduct are for people who need to know that you truly care about their personal safety and psychological well-being.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425768768422174721",
    "text" : "Codes of conduct are for people who need to know that you truly care about their personal safety and psychological well-being.",
    "id" : 425768768422174721,
    "created_at" : "2014-01-21 23:15:59 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 425783331016290304,
  "created_at" : "2014-01-22 00:13:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow @CoralineAda",
      "screen_name" : "Bantik",
      "indices" : [ 3, 10 ],
      "id_str" : "2375715212",
      "id" : 2375715212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425783227953840129",
  "text" : "RT @bantik: Codes of conduct clearly state what is and is not acceptable behavior AND what actions will be taken if someone acts inappropri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425767022681534464",
    "text" : "Codes of conduct clearly state what is and is not acceptable behavior AND what actions will be taken if someone acts inappropriately.",
    "id" : 425767022681534464,
    "created_at" : "2014-01-21 23:09:03 +0000",
    "user" : {
      "name" : "Coraline Ada Ehmke",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566343829851099137\/QzrOHV5-_normal.jpeg",
      "id" : 9526722,
      "verified" : false
    }
  },
  "id" : 425783227953840129,
  "created_at" : "2014-01-22 00:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Z6XBiQQliH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_-agl0pOQfs",
      "display_url" : "youtube.com\/watch?v=_-agl0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425710296422834176",
  "text" : "Current status: http:\/\/t.co\/Z6XBiQQliH",
  "id" : 425710296422834176,
  "created_at" : "2014-01-21 19:23:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Webber",
      "screen_name" : "franklinwebber",
      "indices" : [ 0, 15 ],
      "id_str" : "81525784",
      "id" : 81525784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425670618730622976",
  "geo" : { },
  "id_str" : "425670912789082112",
  "in_reply_to_user_id" : 81525784,
  "text" : "@franklinwebber apparently post it on twitter",
  "id" : 425670912789082112,
  "in_reply_to_status_id" : 425670618730622976,
  "created_at" : "2014-01-21 16:47:08 +0000",
  "in_reply_to_screen_name" : "franklinwebber",
  "in_reply_to_user_id_str" : "81525784",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colindabkowski",
      "screen_name" : "colindabkowski",
      "indices" : [ 0, 15 ],
      "id_str" : "18777886",
      "id" : 18777886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425661560858505216",
  "geo" : { },
  "id_str" : "425662141954138113",
  "in_reply_to_user_id" : 18777886,
  "text" : "@colindabkowski you mean they smiled too!!?",
  "id" : 425662141954138113,
  "in_reply_to_status_id" : 425661560858505216,
  "created_at" : "2014-01-21 16:12:17 +0000",
  "in_reply_to_screen_name" : "colindabkowski",
  "in_reply_to_user_id_str" : "18777886",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425660838460940288",
  "text" : "Is there a better\/cooler word than \"platform\" to describe \"a thing to build stuff upon\" ?",
  "id" : 425660838460940288,
  "created_at" : "2014-01-21 16:07:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/gDeQ5W2OIo",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/514\/thought-that-counts?act=2",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "425502557599838208",
  "geo" : { },
  "id_str" : "425507236962512896",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Also start hoarding your stuff in boxes. Don\u2019t throw anything out until you die! http:\/\/t.co\/gDeQ5W2OIo",
  "id" : 425507236962512896,
  "in_reply_to_status_id" : 425502557599838208,
  "created_at" : "2014-01-21 05:56:45 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/wBgG3TWQfT",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=eChaxl-9pvg&desktop_uri=%2Fwatch%3Fv%3DeChaxl-9pvg",
      "display_url" : "m.youtube.com\/watch?v=eChaxl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "425502557599838208",
  "geo" : { },
  "id_str" : "425504642366058496",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt you just have to eat a burger http:\/\/t.co\/wBgG3TWQfT",
  "id" : 425504642366058496,
  "in_reply_to_status_id" : 425502557599838208,
  "created_at" : "2014-01-21 05:46:26 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Czyrny",
      "screen_name" : "stevenczyrny",
      "indices" : [ 0, 13 ],
      "id_str" : "274792299",
      "id" : 274792299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425470044555214848",
  "geo" : { },
  "id_str" : "425477024832946176",
  "in_reply_to_user_id" : 274792299,
  "text" : "@stevenczyrny Thanks! Come back soon!!",
  "id" : 425477024832946176,
  "in_reply_to_status_id" : 425470044555214848,
  "created_at" : "2014-01-21 03:56:42 +0000",
  "in_reply_to_screen_name" : "stevenczyrny",
  "in_reply_to_user_id_str" : "274792299",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425422549372391424",
  "geo" : { },
  "id_str" : "425424192989712384",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents hashtag carols drunkkkkk",
  "id" : 425424192989712384,
  "in_reply_to_status_id" : 425422549372391424,
  "created_at" : "2014-01-21 00:26:46 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doober Pooberton",
      "screen_name" : "daneZie",
      "indices" : [ 3, 11 ],
      "id_str" : "374540885",
      "id" : 374540885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425424048097476610",
  "text" : "RT @daneZie: How to fall down stairs\nStep 1\nStep 6\nStep 7,8,9,11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424145336148316160",
    "text" : "How to fall down stairs\nStep 1\nStep 6\nStep 7,8,9,11",
    "id" : 424145336148316160,
    "created_at" : "2014-01-17 11:45:03 +0000",
    "user" : {
      "name" : "Doober Pooberton",
      "screen_name" : "daneZie",
      "protected" : false,
      "id_str" : "374540885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548976887658065921\/NLFrCXkL_normal.jpeg",
      "id" : 374540885,
      "verified" : false
    }
  },
  "id" : 425424048097476610,
  "created_at" : "2014-01-21 00:26:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Neves",
      "screen_name" : "arthurnn",
      "indices" : [ 0, 9 ],
      "id_str" : "213767432",
      "id" : 213767432
    }, {
      "name" : "Ash Furrow",
      "screen_name" : "ashfurrow",
      "indices" : [ 10, 20 ],
      "id_str" : "15536268",
      "id" : 15536268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425377379209740288",
  "geo" : { },
  "id_str" : "425391182005280768",
  "in_reply_to_user_id" : 213767432,
  "text" : "@arthurnn @ashfurrow FOR WHOM THE SEG FAULTS",
  "id" : 425391182005280768,
  "in_reply_to_status_id" : 425377379209740288,
  "created_at" : "2014-01-20 22:15:35 +0000",
  "in_reply_to_screen_name" : "arthurnn",
  "in_reply_to_user_id_str" : "213767432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/2DauMfCsVK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MBHOL1PcPR8",
      "display_url" : "youtube.com\/watch?v=MBHOL1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425386875247800320",
  "text" : "@juliepagano can be like http:\/\/t.co\/2DauMfCsVK ?",
  "id" : 425386875247800320,
  "created_at" : "2014-01-20 21:58:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Jansson",
      "screen_name" : "TechLexis",
      "indices" : [ 0, 10 ],
      "id_str" : "1301567203",
      "id" : 1301567203
    }, {
      "name" : "Denis M. Kitchen",
      "screen_name" : "DenisKitchen",
      "indices" : [ 11, 24 ],
      "id_str" : "14668857",
      "id" : 14668857
    }, {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "indices" : [ 25, 33 ],
      "id_str" : "16316447",
      "id" : 16316447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425330100196753409",
  "in_reply_to_user_id" : 1301567203,
  "text" : "@TechLexis @DenisKitchen @watch84 let's bring it back in February though!",
  "id" : 425330100196753409,
  "created_at" : "2014-01-20 18:12:52 +0000",
  "in_reply_to_screen_name" : "TechLexis",
  "in_reply_to_user_id_str" : "1301567203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Jansson",
      "screen_name" : "TechLexis",
      "indices" : [ 0, 10 ],
      "id_str" : "1301567203",
      "id" : 1301567203
    }, {
      "name" : "Denis M. Kitchen",
      "screen_name" : "DenisKitchen",
      "indices" : [ 11, 24 ],
      "id_str" : "14668857",
      "id" : 14668857
    }, {
      "name" : "Jonathan",
      "screen_name" : "watch84",
      "indices" : [ 25, 33 ],
      "id_str" : "16316447",
      "id" : 16316447
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 57, 66 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425329973121937408",
  "in_reply_to_user_id" : 1301567203,
  "text" : "@TechLexis @DenisKitchen @watch84 hey, I need to punt on @OpenHack this month due to a scheduling conflict. Sorry about the short notice :(",
  "id" : 425329973121937408,
  "created_at" : "2014-01-20 18:12:22 +0000",
  "in_reply_to_screen_name" : "TechLexis",
  "in_reply_to_user_id_str" : "1301567203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 0, 7 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425317671521902592",
  "geo" : { },
  "id_str" : "425319887729213441",
  "in_reply_to_user_id" : 5452072,
  "text" : "@nb3004 what about their wearable strategy?",
  "id" : 425319887729213441,
  "in_reply_to_status_id" : 425317671521902592,
  "created_at" : "2014-01-20 17:32:17 +0000",
  "in_reply_to_screen_name" : "nb3004",
  "in_reply_to_user_id_str" : "5452072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425084929165123585",
  "text" : "Actually own Pandemic tonight. Blue, Red, Black, Yellow. Yellow is always last!",
  "id" : 425084929165123585,
  "created_at" : "2014-01-20 01:58:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425001472472797184",
  "geo" : { },
  "id_str" : "425002186754756608",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic tell them as soon as possible.",
  "id" : 425002186754756608,
  "in_reply_to_status_id" : 425001472472797184,
  "created_at" : "2014-01-19 20:29:52 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425002043757953025",
  "text" : "I can't wait for the highway signs that warn \"DON'T VINE AND DRIVE. IT CAN WAIT\"",
  "id" : 425002043757953025,
  "created_at" : "2014-01-19 20:29:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooke Hammerling",
      "screen_name" : "brooke",
      "indices" : [ 3, 10 ],
      "id_str" : "7997312",
      "id" : 7997312
    }, {
      "name" : "Caleb Hannan",
      "screen_name" : "calebhannan",
      "indices" : [ 46, 58 ],
      "id_str" : "24720979",
      "id" : 24720979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tragic",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/InH92XZ6Z9",
      "expanded_url" : "http:\/\/www.shakesville.com\/2014\/01\/careless-cruel-and-unaccountable.html?m=1",
      "display_url" : "shakesville.com\/2014\/01\/carele\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424897637364797440",
  "text" : "RT @brooke: Growing controversy around writer @calebhannan &amp; his article that seems to have led to the subject's suicide. #tragic http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caleb Hannan",
        "screen_name" : "calebhannan",
        "indices" : [ 34, 46 ],
        "id_str" : "24720979",
        "id" : 24720979
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tragic",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/InH92XZ6Z9",
        "expanded_url" : "http:\/\/www.shakesville.com\/2014\/01\/careless-cruel-and-unaccountable.html?m=1",
        "display_url" : "shakesville.com\/2014\/01\/carele\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.7344503174, -73.9976289761 ]
    },
    "id_str" : "424568791214092288",
    "text" : "Growing controversy around writer @calebhannan &amp; his article that seems to have led to the subject's suicide. #tragic http:\/\/t.co\/InH92XZ6Z9",
    "id" : 424568791214092288,
    "created_at" : "2014-01-18 15:47:42 +0000",
    "user" : {
      "name" : "Brooke Hammerling",
      "screen_name" : "brooke",
      "protected" : false,
      "id_str" : "7997312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000189293907\/bc8b7c9267ccd234a007fd9b9367dda1_normal.jpeg",
      "id" : 7997312,
      "verified" : false
    }
  },
  "id" : 424897637364797440,
  "created_at" : "2014-01-19 13:34:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 13, 20 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "keiki",
      "screen_name" : "angelicism",
      "indices" : [ 21, 32 ],
      "id_str" : "26816492",
      "id" : 26816492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424762240794120192",
  "geo" : { },
  "id_str" : "424763921564577792",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @lsegal @angelicism I got 99 diapers and a poop in one. \uD83D\uDC76\uD83D\uDCA9",
  "id" : 424763921564577792,
  "in_reply_to_status_id" : 424762240794120192,
  "created_at" : "2014-01-19 04:43:05 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Willison",
      "screen_name" : "simonw",
      "indices" : [ 0, 7 ],
      "id_str" : "12497",
      "id" : 12497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424758139100344321",
  "geo" : { },
  "id_str" : "424759636747890689",
  "in_reply_to_user_id" : 12497,
  "text" : "@simonw amazon prime it. Way cheaper. and help the UPS guy move it too.",
  "id" : 424759636747890689,
  "in_reply_to_status_id" : 424758139100344321,
  "created_at" : "2014-01-19 04:26:03 +0000",
  "in_reply_to_screen_name" : "simonw",
  "in_reply_to_user_id_str" : "12497",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424757809964544000",
  "text" : "Dinner of IKEA champions: peanut butter banana sandwich, White Russian.",
  "id" : 424757809964544000,
  "created_at" : "2014-01-19 04:18:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424568543943098368",
  "text" : "Baby's first Canada trip today. \uD83D\uDC76\uD83D\uDC96\uD83C\uDF41",
  "id" : 424568543943098368,
  "created_at" : "2014-01-18 15:46:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424566423625924609",
  "geo" : { },
  "id_str" : "424568272785141760",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky yep! There's not really a division, everyone owns everything. Obviously there's \"experts\" on an area but silos are bad.",
  "id" : 424568272785141760,
  "in_reply_to_status_id" : 424566423625924609,
  "created_at" : "2014-01-18 15:45:38 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424532466087768064",
  "geo" : { },
  "id_str" : "424557207707844608",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky obviously we have small trams that work on features for a given product, but responsibility is shared for everything.",
  "id" : 424557207707844608,
  "in_reply_to_status_id" : 424532466087768064,
  "created_at" : "2014-01-18 15:01:40 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424532466087768064",
  "geo" : { },
  "id_str" : "424556515651899393",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky as for responsibility, no.",
  "id" : 424556515651899393,
  "in_reply_to_status_id" : 424532466087768064,
  "created_at" : "2014-01-18 14:58:55 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 8, 23 ],
      "id_str" : "18210275",
      "id" : 18210275
    }, {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 24, 34 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424520397909147648",
  "geo" : { },
  "id_str" : "424525739388448768",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @SaltineJustine @nrrrdcore the icons are terribly confusing, but that's another problem :) (have to rely on the tooltip always)",
  "id" : 424525739388448768,
  "in_reply_to_status_id" : 424520397909147648,
  "created_at" : "2014-01-18 12:56:38 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 8, 23 ],
      "id_str" : "18210275",
      "id" : 18210275
    }, {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 24, 34 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424511356101201920",
  "geo" : { },
  "id_str" : "424518200781332480",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @SaltineJustine @nrrrdcore sounds like white labeling, and lots of brand confusion for GH. Pages solves this problem.",
  "id" : 424518200781332480,
  "in_reply_to_status_id" : 424511356101201920,
  "created_at" : "2014-01-18 12:26:40 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/InqAJtcZvg",
      "expanded_url" : "https:\/\/37signals.com\/svn\/posts\/3706-everyone-does-everything",
      "display_url" : "37signals.com\/svn\/posts\/3706\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424517711444463616",
  "text" : "I get asked this a lot: \"What part of Basecamp do you work on?\" \"All of it!\" https:\/\/t.co\/InqAJtcZvg",
  "id" : 424517711444463616,
  "created_at" : "2014-01-18 12:24:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424271316477571072",
  "geo" : { },
  "id_str" : "424275557862232064",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella we'll be sending out info to backers soon. we have another phone booth to name too!",
  "id" : 424275557862232064,
  "in_reply_to_status_id" : 424271316477571072,
  "created_at" : "2014-01-17 20:22:30 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 7, 21 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sUrNaMVlSK",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/when-i-enter-the-office-the-imperial-march-plays",
      "display_url" : "robots.thoughtbot.com\/when-i-enter-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424269324316987392",
  "text" : "Actual @coworkbuffalo suggestion for our already complicated and finicky door system...a theme song! Reminded me of: http:\/\/t.co\/sUrNaMVlSK",
  "id" : 424269324316987392,
  "created_at" : "2014-01-17 19:57:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Sturgess",
      "screen_name" : "paulsturgess",
      "indices" : [ 0, 13 ],
      "id_str" : "7528682",
      "id" : 7528682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424177962024710144",
  "geo" : { },
  "id_str" : "424252659353153536",
  "in_reply_to_user_id" : 7528682,
  "text" : "@paulsturgess i dont have any right now. there's a lot of PRs, but i haven't had a chance to evaluate or test yet.",
  "id" : 424252659353153536,
  "in_reply_to_status_id" : 424177962024710144,
  "created_at" : "2014-01-17 18:51:30 +0000",
  "in_reply_to_screen_name" : "paulsturgess",
  "in_reply_to_user_id_str" : "7528682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424053266817642496",
  "geo" : { },
  "id_str" : "424054245088718848",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik there's a huge comic book store (and a board game one too) in midtown.",
  "id" : 424054245088718848,
  "in_reply_to_status_id" : 424053266817642496,
  "created_at" : "2014-01-17 05:43:05 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3061\u3083\u3074\u3093\u5148\u751F",
      "screen_name" : "kosaki55tea",
      "indices" : [ 0, 12 ],
      "id_str" : "42616493",
      "id" : 42616493
    }, {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 13, 24 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423971572064333824",
  "geo" : { },
  "id_str" : "423991185670017024",
  "in_reply_to_user_id" : 42616493,
  "text" : "@kosaki55tea @samkottler I would appreciate an invite then :)",
  "id" : 423991185670017024,
  "in_reply_to_status_id" : 423971572064333824,
  "created_at" : "2014-01-17 01:32:30 +0000",
  "in_reply_to_screen_name" : "kosaki55tea",
  "in_reply_to_user_id_str" : "42616493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423969553425911808",
  "geo" : { },
  "id_str" : "423986617578033152",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams I remember seeing this. Definitely was a sign.",
  "id" : 423986617578033152,
  "in_reply_to_status_id" : 423969553425911808,
  "created_at" : "2014-01-17 01:14:21 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/sxSjPuDLGL",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/117834140093816217434",
      "display_url" : "plus.google.com\/communities\/11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423976052105687040",
  "text" : "RT @JZ: Love Basecamp and Android? Then you'll love this: \n\nhttps:\/\/t.co\/sxSjPuDLGL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/sxSjPuDLGL",
        "expanded_url" : "https:\/\/plus.google.com\/communities\/117834140093816217434",
        "display_url" : "plus.google.com\/communities\/11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423971814117605376",
    "text" : "Love Basecamp and Android? Then you'll love this: \n\nhttps:\/\/t.co\/sxSjPuDLGL",
    "id" : 423971814117605376,
    "created_at" : "2014-01-17 00:15:32 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 423976052105687040,
  "created_at" : "2014-01-17 00:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423958125616828417",
  "geo" : { },
  "id_str" : "423960698373558272",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco Red Barchetta is a speed limit breaker!",
  "id" : 423960698373558272,
  "in_reply_to_status_id" : 423958125616828417,
  "created_at" : "2014-01-16 23:31:21 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423949308811943936",
  "geo" : { },
  "id_str" : "423951099960115200",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog Rent a bounce house for your front lawn in protest!",
  "id" : 423951099960115200,
  "in_reply_to_status_id" : 423949308811943936,
  "created_at" : "2014-01-16 22:53:13 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LawnMemo",
      "screen_name" : "LawnMemo",
      "indices" : [ 0, 9 ],
      "id_str" : "829816736",
      "id" : 829816736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423901658582495232",
  "geo" : { },
  "id_str" : "423943983148982272",
  "in_reply_to_user_id" : 829816736,
  "text" : "@LawnMemo Mule is a lot of fun from this show!",
  "id" : 423943983148982272,
  "in_reply_to_status_id" : 423901658582495232,
  "created_at" : "2014-01-16 22:24:56 +0000",
  "in_reply_to_screen_name" : "LawnMemo",
  "in_reply_to_user_id_str" : "829816736",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423939820306440192",
  "geo" : { },
  "id_str" : "423941650893635584",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits What about people replying to people tweeting about people blogging about shipping?",
  "id" : 423941650893635584,
  "in_reply_to_status_id" : 423939820306440192,
  "created_at" : "2014-01-16 22:15:40 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7BVyx0vkZ4",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/c04cnad",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "423935872359071745",
  "geo" : { },
  "id_str" : "423936354444001280",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan it's a balance for sure, but \"starry-eyed time-wasters\" far, far outnumber them http:\/\/t.co\/7BVyx0vkZ4",
  "id" : 423936354444001280,
  "in_reply_to_status_id" : 423935872359071745,
  "created_at" : "2014-01-16 21:54:37 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423934683739484161",
  "text" : "While everyone else is reading about \"Value is created by doing\", some people are actually shipping. Don't give up the ship.",
  "id" : 423934683739484161,
  "created_at" : "2014-01-16 21:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Bl0yMWeGB7",
      "expanded_url" : "http:\/\/blog.samaltman.com\/value-is-created-by-doing",
      "display_url" : "blog.samaltman.com\/value-is-creat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423934505506721792",
  "text" : "HN and SF tech culture summed up in one post: http:\/\/t.co\/Bl0yMWeGB7",
  "id" : 423934505506721792,
  "created_at" : "2014-01-16 21:47:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "indices" : [ 3, 11 ],
      "id_str" : "15048829",
      "id" : 15048829
    }, {
      "name" : "allan branch",
      "screen_name" : "allanbranch",
      "indices" : [ 86, 98 ],
      "id_str" : "6183972",
      "id" : 6183972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/taZ9BYoKCV",
      "expanded_url" : "https:\/\/lessaccounting.com\/health-insurance\/understanding-obamacare\/",
      "display_url" : "lessaccounting.com\/health-insuran\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423913144461701120",
  "text" : "RT @greggyb: Awesome set of articles if you're confused by your Obamacare options via @allanbranch. https:\/\/t.co\/taZ9BYoKCV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "allan branch",
        "screen_name" : "allanbranch",
        "indices" : [ 73, 85 ],
        "id_str" : "6183972",
        "id" : 6183972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/taZ9BYoKCV",
        "expanded_url" : "https:\/\/lessaccounting.com\/health-insurance\/understanding-obamacare\/",
        "display_url" : "lessaccounting.com\/health-insuran\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423912808984498178",
    "text" : "Awesome set of articles if you're confused by your Obamacare options via @allanbranch. https:\/\/t.co\/taZ9BYoKCV",
    "id" : 423912808984498178,
    "created_at" : "2014-01-16 20:21:04 +0000",
    "user" : {
      "name" : "Greg Baugues",
      "screen_name" : "greggyb",
      "protected" : false,
      "id_str" : "15048829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000581874901\/27cb63ac907106c91238a2202ad70cc6_normal.jpeg",
      "id" : 15048829,
      "verified" : false
    }
  },
  "id" : 423913144461701120,
  "created_at" : "2014-01-16 20:22:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/4zHtrJZ9YN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v5Lmkm5EF5E",
      "display_url" : "youtube.com\/watch?v=v5Lmkm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "423901894495322112",
  "geo" : { },
  "id_str" : "423902793166893056",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius http:\/\/t.co\/4zHtrJZ9YN",
  "id" : 423902793166893056,
  "in_reply_to_status_id" : 423901894495322112,
  "created_at" : "2014-01-16 19:41:16 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/SYWyipBZZT",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Buffalo_buffalo_Buffalo_buffalo_buffalo_buffalo_Buffalo_buffalo",
      "display_url" : "en.wikipedia.org\/wiki\/Buffalo_b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423902768370167808",
  "text" : "RT @headius: Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo. http:\/\/t.co\/SYWyipBZZT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/SYWyipBZZT",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Buffalo_buffalo_Buffalo_buffalo_buffalo_buffalo_Buffalo_buffalo",
        "display_url" : "en.wikipedia.org\/wiki\/Buffalo_b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423901894495322112",
    "text" : "Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo. http:\/\/t.co\/SYWyipBZZT",
    "id" : 423901894495322112,
    "created_at" : "2014-01-16 19:37:42 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460129289128509443\/XT0pCBVy_normal.png",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 423902768370167808,
  "created_at" : "2014-01-16 19:41:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 88, 98 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/E27gpOZBgg",
      "expanded_url" : "http:\/\/tinyrobots.thoughtbot.com\/post\/118622270",
      "display_url" : "tinyrobots.thoughtbot.com\/post\/118622270"
    } ]
  },
  "geo" : { },
  "id_str" : "423902095117258752",
  "text" : "Had to go back to page 64 to find the Hawkeye Award. 2009!!? http:\/\/t.co\/E27gpOZBgg \/cc @kevinburg",
  "id" : 423902095117258752,
  "created_at" : "2014-01-16 19:38:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/bB3WG4sqHf",
      "expanded_url" : "https:\/\/www.schneier.com\/blog\/archives\/2014\/01\/today_i_briefed.html",
      "display_url" : "schneier.com\/blog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423901114728079360",
  "text" : "Fucked up: \"Congress has such a difficult time getting information out of the NSA that they have to ask me.\" https:\/\/t.co\/bB3WG4sqHf",
  "id" : 423901114728079360,
  "created_at" : "2014-01-16 19:34:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/m1xIywyclR",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/117834140093816217434",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423893392255221760",
  "text" : "RT @JZ: Use Basecamp and an Android Phone? We've got something we'd like you to try. Shh... https:\/\/t.co\/m1xIywyclR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/m1xIywyclR",
        "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/117834140093816217434",
        "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423893249518874624",
    "text" : "Use Basecamp and an Android Phone? We've got something we'd like you to try. Shh... https:\/\/t.co\/m1xIywyclR",
    "id" : 423893249518874624,
    "created_at" : "2014-01-16 19:03:20 +0000",
    "user" : {
      "name" : "Jason Zimdars",
      "screen_name" : "jasonzimdars",
      "protected" : false,
      "id_str" : "896641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1849219872\/jz_monogram_blue_normal.png",
      "id" : 896641,
      "verified" : false
    }
  },
  "id" : 423893392255221760,
  "created_at" : "2014-01-16 19:03:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 43, 49 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423877736113795073",
  "text" : "Now piping favorite tweets to Campfire via @IFTTT. What could go wrong?",
  "id" : 423877736113795073,
  "created_at" : "2014-01-16 18:01:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/w1I4p6WGLr",
      "expanded_url" : "http:\/\/madewithbasecamp.tumblr.com\/",
      "display_url" : "madewithbasecamp.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "423866523468308480",
  "text" : "RT @wilderemily: What has Basecamp helped YOU make?! http:\/\/t.co\/w1I4p6WGLr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/w1I4p6WGLr",
        "expanded_url" : "http:\/\/madewithbasecamp.tumblr.com\/",
        "display_url" : "madewithbasecamp.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "423866064674365440",
    "text" : "What has Basecamp helped YOU make?! http:\/\/t.co\/w1I4p6WGLr",
    "id" : 423866064674365440,
    "created_at" : "2014-01-16 17:15:19 +0000",
    "user" : {
      "name" : "Emily Triplett Lentz",
      "screen_name" : "emilytlentz",
      "protected" : false,
      "id_str" : "55330075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442792521177894913\/2s9xRuFD_normal.jpeg",
      "id" : 55330075,
      "verified" : false
    }
  },
  "id" : 423866523468308480,
  "created_at" : "2014-01-16 17:17:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vtjJOesNN8",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/721520",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423861908043620352",
  "text" : "RT @coworkbuffalo: Kickstarter complete! We're funded, we hit a stretch goal, and man, do we have rewards to ship. http:\/\/t.co\/vtjJOesNN8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/vtjJOesNN8",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/721520",
        "display_url" : "kickstarter.com\/projects\/cowor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423861869481193472",
    "text" : "Kickstarter complete! We're funded, we hit a stretch goal, and man, do we have rewards to ship. http:\/\/t.co\/vtjJOesNN8",
    "id" : 423861869481193472,
    "created_at" : "2014-01-16 16:58:39 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 423861908043620352,
  "created_at" : "2014-01-16 16:58:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 38, 46 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 58, 65 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423830965870280706",
  "geo" : { },
  "id_str" : "423831415239606272",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler would appreciate it, yes. @evanphx too, maybe @sferik ?",
  "id" : 423831415239606272,
  "in_reply_to_status_id" : 423830965870280706,
  "created_at" : "2014-01-16 14:57:38 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423830350532317184",
  "geo" : { },
  "id_str" : "423830607680921601",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler ?? is that list public?",
  "id" : 423830607680921601,
  "in_reply_to_status_id" : 423830350532317184,
  "created_at" : "2014-01-16 14:54:25 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    }, {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 11, 16 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 17, 28 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423794837490372608",
  "geo" : { },
  "id_str" : "423800259349729280",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 @rufo @dangigante thanks!!!",
  "id" : 423800259349729280,
  "in_reply_to_status_id" : 423794837490372608,
  "created_at" : "2014-01-16 12:53:50 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 47, 61 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423800169432244224",
  "text" : "Funded!! Huge thanks to everyone who supported @coworkbuffalo. Now to ship even more!",
  "id" : 423800169432244224,
  "created_at" : "2014-01-16 12:53:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423672172796600321",
  "geo" : { },
  "id_str" : "423680320647335936",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT did a reset of the WeMo and it's happier now. so finicky! :(",
  "id" : 423680320647335936,
  "in_reply_to_status_id" : 423672172796600321,
  "created_at" : "2014-01-16 04:57:14 +0000",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423672172796600321",
  "geo" : { },
  "id_str" : "423672995203145728",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT getting \"can't generate PIN\" from the WeMo  app. kept saying \"Recipe initializing\" until I reset it. Recipe 7566774.",
  "id" : 423672995203145728,
  "in_reply_to_status_id" : 423672172796600321,
  "created_at" : "2014-01-16 04:28:08 +0000",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 4, 10 ],
      "id_str" : "75079616",
      "id" : 75079616
    }, {
      "name" : "leor stern",
      "screen_name" : "leorstern",
      "indices" : [ 11, 21 ],
      "id_str" : "20804872",
      "id" : 20804872
    }, {
      "name" : "WeMo",
      "screen_name" : "BelkinWeMo",
      "indices" : [ 22, 33 ],
      "id_str" : "1517737116",
      "id" : 1517737116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423671086329253888",
  "text" : "Hey @ifttt @leorstern @BelkinWeMo something is definitely broken with IFTTT &lt;=&gt; WeMo integration :(",
  "id" : 423671086329253888,
  "created_at" : "2014-01-16 04:20:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 15, 27 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 62, 76 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423648888382177280",
  "text" : "Huge thanks to @bcardarella for stepping up and naming one of @coworkbuffalo's phone booths! There's 2 left... http:\/\/t.co\/IKIiSJdGiK",
  "id" : 423648888382177280,
  "created_at" : "2014-01-16 02:52:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean-Philippe Boily",
      "screen_name" : "jipiboily",
      "indices" : [ 0, 10 ],
      "id_str" : "44257250",
      "id" : 44257250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423648006068396032",
  "geo" : { },
  "id_str" : "423648415029809153",
  "in_reply_to_user_id" : 44257250,
  "text" : "@jipiboily thanks!!",
  "id" : 423648415029809153,
  "in_reply_to_status_id" : 423648006068396032,
  "created_at" : "2014-01-16 02:50:27 +0000",
  "in_reply_to_screen_name" : "jipiboily",
  "in_reply_to_user_id_str" : "44257250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 44, 55 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 56, 64 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 65, 75 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 76, 86 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423641981907390464",
  "geo" : { },
  "id_str" : "423646359405613057",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella thanks from all us of here \/cc @kevinpurdy @fending @sailflyer @magnachef",
  "id" : 423646359405613057,
  "in_reply_to_status_id" : 423641981907390464,
  "created_at" : "2014-01-16 02:42:17 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423641981907390464",
  "geo" : { },
  "id_str" : "423646208410660864",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella you are a gentleman and a scholar",
  "id" : 423646208410660864,
  "in_reply_to_status_id" : 423641981907390464,
  "created_at" : "2014-01-16 02:41:41 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 17, 31 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423640844852142080",
  "text" : "2 hours left for @coworkbuffalo. $100 to $4000!! http:\/\/t.co\/IKIiSJdGiK",
  "id" : 423640844852142080,
  "created_at" : "2014-01-16 02:20:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Czarnecki",
      "screen_name" : "CzarneckiD",
      "indices" : [ 0, 11 ],
      "id_str" : "13393",
      "id" : 13393
    }, {
      "name" : "Patrick Muldoon",
      "screen_name" : "d00n",
      "indices" : [ 12, 17 ],
      "id_str" : "1385921",
      "id" : 1385921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423614686668414976",
  "geo" : { },
  "id_str" : "423631125870026752",
  "in_reply_to_user_id" : 13393,
  "text" : "@CzarneckiD @d00n unreal",
  "id" : 423631125870026752,
  "in_reply_to_status_id" : 423614686668414976,
  "created_at" : "2014-01-16 01:41:45 +0000",
  "in_reply_to_screen_name" : "CzarneckiD",
  "in_reply_to_user_id_str" : "13393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 3, 12 ],
      "id_str" : "14531472",
      "id" : 14531472
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 33, 47 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/npfboiQisL",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "423591564238008321",
  "text" : "RT @mikesusz: last few hours for @coworkbuffalo\u2019s kickstarter. http:\/\/t.co\/npfboiQisL if you live nearby, why not kick in a few bucks and g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 19, 33 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/npfboiQisL",
        "expanded_url" : "http:\/\/kck.st\/18RQYKG",
        "display_url" : "kck.st\/18RQYKG"
      } ]
    },
    "geo" : { },
    "id_str" : "423542985511284736",
    "text" : "last few hours for @coworkbuffalo\u2019s kickstarter. http:\/\/t.co\/npfboiQisL if you live nearby, why not kick in a few bucks and get a day-pass?",
    "id" : 423542985511284736,
    "created_at" : "2014-01-15 19:51:31 +0000",
    "user" : {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "protected" : false,
      "id_str" : "14531472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479668081800011776\/ZT23cqOn_normal.jpeg",
      "id" : 14531472,
      "verified" : false
    }
  },
  "id" : 423591564238008321,
  "created_at" : "2014-01-15 23:04:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423542338502135808",
  "text" : "OH @coworkbuffalo \"Would Wicked be considered fanfiction?\"",
  "id" : 423542338502135808,
  "created_at" : "2014-01-15 19:48:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Moyer",
      "screen_name" : "CDMoyer",
      "indices" : [ 0, 8 ],
      "id_str" : "12145232",
      "id" : 12145232
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 9, 21 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423468248311406592",
  "geo" : { },
  "id_str" : "423469826141466624",
  "in_reply_to_user_id" : 12145232,
  "text" : "@CDMoyer @ginatrapani 1. Check the slow queries log 2. Add indexes 3. Sleep",
  "id" : 423469826141466624,
  "in_reply_to_status_id" : 423468248311406592,
  "created_at" : "2014-01-15 15:00:48 +0000",
  "in_reply_to_screen_name" : "CDMoyer",
  "in_reply_to_user_id_str" : "12145232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423460668164276224",
  "geo" : { },
  "id_str" : "423468491778183169",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss CONGRATS!! I hope you installed some adamantium ;)",
  "id" : 423468491778183169,
  "in_reply_to_status_id" : 423460668164276224,
  "created_at" : "2014-01-15 14:55:30 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 98, 112 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Ak79Z46w4q",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "423467166407479296",
  "text" : "RT @zobar2: Come on yall- 14 hours, 1,400 bucks. Daddy needs a new poster. http:\/\/t.co\/Ak79Z46w4q @coworkbuffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 86, 100 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Ak79Z46w4q",
        "expanded_url" : "http:\/\/kck.st\/18RQYKG",
        "display_url" : "kck.st\/18RQYKG"
      } ]
    },
    "geo" : { },
    "id_str" : "423466934064005120",
    "text" : "Come on yall- 14 hours, 1,400 bucks. Daddy needs a new poster. http:\/\/t.co\/Ak79Z46w4q @coworkbuffalo",
    "id" : 423466934064005120,
    "created_at" : "2014-01-15 14:49:19 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 423467166407479296,
  "created_at" : "2014-01-15 14:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/BfV2a2ICUY",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/720292",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423465049852612608",
  "text" : "14 hours left for @coworkbuffalo's GIF-filled campaign. http:\/\/t.co\/BfV2a2ICUY",
  "id" : 423465049852612608,
  "created_at" : "2014-01-15 14:41:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423326535991296001",
  "geo" : { },
  "id_str" : "423326800786112512",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik story of my life",
  "id" : 423326800786112512,
  "in_reply_to_status_id" : 423326535991296001,
  "created_at" : "2014-01-15 05:32:28 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 3, 14 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423316112378310656",
  "text" : "RT @Alex_Godin: Net neutrality is a terrible name. We should rebrand it. Maybe \"the netflix tax\".\n\nNo one would be in favor of a Netflix ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423315466145132544",
    "text" : "Net neutrality is a terrible name. We should rebrand it. Maybe \"the netflix tax\".\n\nNo one would be in favor of a Netflix tax.",
    "id" : 423315466145132544,
    "created_at" : "2014-01-15 04:47:26 +0000",
    "user" : {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "protected" : false,
      "id_str" : "11694962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444228256741339136\/Wz2Cm7py_normal.jpeg",
      "id" : 11694962,
      "verified" : false
    }
  },
  "id" : 423316112378310656,
  "created_at" : "2014-01-15 04:50:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 21, 35 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/6Q9ttaAdzx",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/720292",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423307636717543425",
  "text" : "RT @kevinpurdy: The .@coworkbuffalo Kickstarter has just 24 hours to go. If we hit $5K, lots of folks get posters. Update: http:\/\/t.co\/6Q9t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 5, 19 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/6Q9ttaAdzx",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/720292",
        "display_url" : "kickstarter.com\/projects\/cowor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423306736053673984",
    "text" : "The .@coworkbuffalo Kickstarter has just 24 hours to go. If we hit $5K, lots of folks get posters. Update: http:\/\/t.co\/6Q9ttaAdzx",
    "id" : 423306736053673984,
    "created_at" : "2014-01-15 04:12:45 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 423307636717543425,
  "created_at" : "2014-01-15 04:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/F6Bo723pxJ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/",
      "display_url" : "coworkbuffalo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "423305805064982529",
  "text" : "Also, revamped http:\/\/t.co\/F6Bo723pxJ tonight for 2014. Someday I'll figure out why Chrome lags on scrolling sometimes, but Safari doesn't.",
  "id" : 423305805064982529,
  "created_at" : "2014-01-15 04:09:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 71, 85 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/dLIhXyhzC2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9jK-NcRmVcw",
      "display_url" : "youtube.com\/watch?v=9jK-Nc\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/9Zp3vT5g82",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "423303819376599040",
  "text" : "It's the FINAL COUNTDOWN! http:\/\/t.co\/dLIhXyhzC2 92 people have backed @coworkbuffalo so far. You have 24 hours left! http:\/\/t.co\/9Zp3vT5g82",
  "id" : 423303819376599040,
  "created_at" : "2014-01-15 04:01:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423246761595912192",
  "geo" : { },
  "id_str" : "423246843577782273",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense congrats! will give it a download tonight. what's your game center ID?",
  "id" : 423246843577782273,
  "in_reply_to_status_id" : 423246761595912192,
  "created_at" : "2014-01-15 00:14:45 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 63, 77 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423230040453971968",
  "geo" : { },
  "id_str" : "423231634905632769",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy have one for me. Next time I'll get you a cookie at @coworkbuffalo.",
  "id" : 423231634905632769,
  "in_reply_to_status_id" : 423230040453971968,
  "created_at" : "2014-01-14 23:14:19 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/lm1IbnkiqA",
      "expanded_url" : "http:\/\/www.bnblinda.com\/QuickSiteImages\/Don_t_give_up_the_ship_flag_op_640x480.jpg",
      "display_url" : "bnblinda.com\/QuickSiteImage\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423198424746319872",
  "text" : "New motto: http:\/\/t.co\/lm1IbnkiqA",
  "id" : 423198424746319872,
  "created_at" : "2014-01-14 21:02:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423180232590258177",
  "text" : "Apparently we're still doing GTA4 jokes on reddit?",
  "id" : 423180232590258177,
  "created_at" : "2014-01-14 19:50:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Arreche",
      "screen_name" : "SaltineJustine",
      "indices" : [ 0, 15 ],
      "id_str" : "18210275",
      "id" : 18210275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423178241482825728",
  "geo" : { },
  "id_str" : "423178651836743680",
  "in_reply_to_user_id" : 18210275,
  "text" : "@SaltineJustine definitely the latter",
  "id" : 423178651836743680,
  "in_reply_to_status_id" : 423178241482825728,
  "created_at" : "2014-01-14 19:43:47 +0000",
  "in_reply_to_screen_name" : "SaltineJustine",
  "in_reply_to_user_id_str" : "18210275",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 0, 4 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "Juliano M. Dasilva",
      "screen_name" : "iammrjuju",
      "indices" : [ 5, 15 ],
      "id_str" : "187629823",
      "id" : 187629823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423168728033812480",
  "geo" : { },
  "id_str" : "423176673534541824",
  "in_reply_to_user_id" : 10079052,
  "text" : "@rjs @iammrjuju @JZ Thanks!",
  "id" : 423176673534541824,
  "in_reply_to_status_id" : 423168728033812480,
  "created_at" : "2014-01-14 19:35:55 +0000",
  "in_reply_to_screen_name" : "rjs",
  "in_reply_to_user_id_str" : "10079052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 11, 15 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 35, 47 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423155718561087488",
  "geo" : { },
  "id_str" : "423156869150945280",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier @dhh i'm very sure it's @rocketslide or @wilderemily's fault",
  "id" : 423156869150945280,
  "in_reply_to_status_id" : 423155718561087488,
  "created_at" : "2014-01-14 18:17:14 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 4, 14 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/uDuPVctk93",
      "expanded_url" : "http:\/\/quaran.to\/allpets\/",
      "display_url" : "quaran.to\/allpets\/"
    } ]
  },
  "geo" : { },
  "id_str" : "423136915496239105",
  "text" : "The @37signals All Pets campfire room rules have been updated for 2014. Guess which one I caused: http:\/\/t.co\/uDuPVctk93",
  "id" : 423136915496239105,
  "created_at" : "2014-01-14 16:57:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TweetsofOld\/status\/423112924039639040\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/2MzN9bS29x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd8y9nHCcAE40E_.jpg",
      "id_str" : "423112924048027649",
      "id" : 423112924048027649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd8y9nHCcAE40E_.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 692
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 692
      } ],
      "display_url" : "pic.twitter.com\/2MzN9bS29x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423113203879796736",
  "text" : "RT @TweetsofOld: I LOVE COFFEE       --WA1915 http:\/\/t.co\/2MzN9bS29x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TweetsofOld\/status\/423112924039639040\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/2MzN9bS29x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd8y9nHCcAE40E_.jpg",
        "id_str" : "423112924048027649",
        "id" : 423112924048027649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd8y9nHCcAE40E_.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 692
        } ],
        "display_url" : "pic.twitter.com\/2MzN9bS29x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423112924039639040",
    "text" : "I LOVE COFFEE       --WA1915 http:\/\/t.co\/2MzN9bS29x",
    "id" : 423112924039639040,
    "created_at" : "2014-01-14 15:22:36 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 423113203879796736,
  "created_at" : "2014-01-14 15:23:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 3, 17 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423111439620919297",
  "text" : "RT @joshuaclayton: TSA agent checking IDs just signaled to \"the next victim\". Appropriate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423103161813839872",
    "text" : "TSA agent checking IDs just signaled to \"the next victim\". Appropriate.",
    "id" : 423103161813839872,
    "created_at" : "2014-01-14 14:43:49 +0000",
    "user" : {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "protected" : false,
      "id_str" : "10293122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156127762\/Josh-Clayton_normal.png",
      "id" : 10293122,
      "verified" : false
    }
  },
  "id" : 423111439620919297,
  "created_at" : "2014-01-14 15:16:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean-Philippe Boily",
      "screen_name" : "jipiboily",
      "indices" : [ 0, 10 ],
      "id_str" : "44257250",
      "id" : 44257250
    }, {
      "name" : "io",
      "screen_name" : "saglacio",
      "indices" : [ 11, 20 ],
      "id_str" : "2236457028",
      "id" : 2236457028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422946975030722560",
  "geo" : { },
  "id_str" : "422947231264567296",
  "in_reply_to_user_id" : 44257250,
  "text" : "@jipiboily @saglacio thanks! Just watched it or was this at some event?",
  "id" : 422947231264567296,
  "in_reply_to_status_id" : 422946975030722560,
  "created_at" : "2014-01-14 04:24:12 +0000",
  "in_reply_to_screen_name" : "jipiboily",
  "in_reply_to_user_id_str" : "44257250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 11, 16 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422906390257340416",
  "geo" : { },
  "id_str" : "422944781199609856",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris @r00k responded. so much for blog comments ;)",
  "id" : 422944781199609856,
  "in_reply_to_status_id" : 422906390257340416,
  "created_at" : "2014-01-14 04:14:28 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422833068253003776",
  "geo" : { },
  "id_str" : "422928710145019904",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending BOOOM",
  "id" : 422928710145019904,
  "in_reply_to_status_id" : 422833068253003776,
  "created_at" : "2014-01-14 03:10:36 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Jb14JDpsGV",
      "expanded_url" : "http:\/\/quaran.to\/kidsmash\/",
      "display_url" : "quaran.to\/kidsmash\/"
    } ]
  },
  "geo" : { },
  "id_str" : "422918178172178432",
  "text" : "First time using kidsmash with the Little Dude. I did the smashing. http:\/\/t.co\/Jb14JDpsGV",
  "id" : 422918178172178432,
  "created_at" : "2014-01-14 02:28:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 0, 10 ],
      "id_str" : "14575143",
      "id" : 14575143
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 11, 16 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422904935966310401",
  "geo" : { },
  "id_str" : "422905567502290944",
  "in_reply_to_user_id" : 14575143,
  "text" : "@joeferris @r00k sure, but it feels like that method is way overused. I'm all for applying patterns when necessary, but not shotgunning 7.",
  "id" : 422905567502290944,
  "in_reply_to_status_id" : 422904935966310401,
  "created_at" : "2014-01-14 01:38:39 +0000",
  "in_reply_to_screen_name" : "joeferris",
  "in_reply_to_user_id_str" : "14575143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422903213658894336",
  "geo" : { },
  "id_str" : "422903300158001152",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub playing too much dorf fort?",
  "id" : 422903300158001152,
  "in_reply_to_status_id" : 422903213658894336,
  "created_at" : "2014-01-14 01:29:38 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 12, 22 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422867206578638848",
  "geo" : { },
  "id_str" : "422901239957815296",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @joeferris do you feel that replacing _1_ if\/else statement with _7_ patterns isn't a little overkill?",
  "id" : 422901239957815296,
  "in_reply_to_status_id" : 422867206578638848,
  "created_at" : "2014-01-14 01:21:27 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/vGAzDCURgo",
      "expanded_url" : "http:\/\/modelviewculture.com\/",
      "display_url" : "modelviewculture.com"
    } ]
  },
  "geo" : { },
  "id_str" : "422851048537985024",
  "text" : "Get outside of your box. Read all of this: http:\/\/t.co\/vGAzDCURgo",
  "id" : 422851048537985024,
  "created_at" : "2014-01-13 22:02:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422843821617999872",
  "geo" : { },
  "id_str" : "422844055282655234",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes how'd you get it?",
  "id" : 422844055282655234,
  "in_reply_to_status_id" : 422843821617999872,
  "created_at" : "2014-01-13 21:34:13 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422838260079947776",
  "text" : "I can't wait for ads to appear on my Nest!",
  "id" : 422838260079947776,
  "created_at" : "2014-01-13 21:11:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422825894248345601",
  "text" : "B.R.E.A.M. - Bitcoin Rules Everything Around Me",
  "id" : 422825894248345601,
  "created_at" : "2014-01-13 20:22:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 32, 42 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 43, 51 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "Dan DeFelippi",
      "screen_name" : "ExpertDan",
      "indices" : [ 52, 62 ],
      "id_str" : "17566946",
      "id" : 17566946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422822924127834113",
  "geo" : { },
  "id_str" : "422823301732237313",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante *looks fervently at @sailflyer @fending @expertdan*",
  "id" : 422823301732237313,
  "in_reply_to_status_id" : 422822924127834113,
  "created_at" : "2014-01-13 20:11:45 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/9Zp3vT5g82",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "422766108974645248",
  "text" : "60 hours left for @coworkbuffalo's Kickstarter. Let's make some stretch goals happen! http:\/\/t.co\/9Zp3vT5g82",
  "id" : 422766108974645248,
  "created_at" : "2014-01-13 16:24:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonathon knepper",
      "screen_name" : "jonknep",
      "indices" : [ 0, 8 ],
      "id_str" : "48446180",
      "id" : 48446180
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 9, 23 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422763511064698880",
  "geo" : { },
  "id_str" : "422764778340093952",
  "in_reply_to_user_id" : 48446180,
  "text" : "@jonknep @coworkbuffalo Thanks!!",
  "id" : 422764778340093952,
  "in_reply_to_status_id" : 422763511064698880,
  "created_at" : "2014-01-13 16:19:12 +0000",
  "in_reply_to_screen_name" : "jonknep",
  "in_reply_to_user_id_str" : "48446180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422727471717289984",
  "text" : "I definitely understand some don't have a choice with where they live and work, but do we need to make \"extreme\" commutes heroic acts?",
  "id" : 422727471717289984,
  "created_at" : "2014-01-13 13:50:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422727289747431425",
  "text" : "FWIW: I commute as a remote worker on most days to provide some work\/home separation. Lucky to only have to travel 10 minutes by bus\/bike.",
  "id" : 422727289747431425,
  "created_at" : "2014-01-13 13:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JVmdxQMuA8",
      "expanded_url" : "http:\/\/m.bbc.co.uk\/news\/magazine-25551393",
      "display_url" : "m.bbc.co.uk\/news\/magazine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422723298435555328",
  "text" : "It's sad that \"extreme commutes\" are played as heroic instead of desperate and lonely, especially for IT workers: http:\/\/t.co\/JVmdxQMuA8",
  "id" : 422723298435555328,
  "created_at" : "2014-01-13 13:34:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacobstructionist",
      "screen_name" : "jacobian",
      "indices" : [ 0, 9 ],
      "id_str" : "18824526",
      "id" : 18824526
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 10, 21 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422457915480367105",
  "geo" : { },
  "id_str" : "422460162264158208",
  "in_reply_to_user_id" : 18824526,
  "text" : "@jacobian @ashedryden +1 for this. Seriously dark stuff too...even more so than HG series. Reading in grammar school definitely altered me.",
  "id" : 422460162264158208,
  "in_reply_to_status_id" : 422457915480367105,
  "created_at" : "2014-01-12 20:08:46 +0000",
  "in_reply_to_screen_name" : "jacobian",
  "in_reply_to_user_id_str" : "18824526",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422419839043772417",
  "geo" : { },
  "id_str" : "422421097644961792",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending were you a plant?",
  "id" : 422421097644961792,
  "in_reply_to_status_id" : 422419839043772417,
  "created_at" : "2014-01-12 17:33:32 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 32, 39 ],
      "id_str" : "5452072",
      "id" : 5452072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/dXrZF8tk1q",
      "expanded_url" : "http:\/\/www.buffalonews.com\/business\/in-smart-homes-internet-connected-gadgets-abound-20140111",
      "display_url" : "buffalonews.com\/business\/in-sm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422415094900084736",
  "text" : "\u201CWe\u2019ll never have flying cars\u201D \u2014@nb3004 http:\/\/t.co\/dXrZF8tk1q",
  "id" : 422415094900084736,
  "created_at" : "2014-01-12 17:09:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422408684384186368",
  "geo" : { },
  "id_str" : "422413122259800064",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh I won't deny it's obnoxious, but try beating that score :)",
  "id" : 422413122259800064,
  "in_reply_to_status_id" : 422408684384186368,
  "created_at" : "2014-01-12 17:01:51 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422408684384186368",
  "geo" : { },
  "id_str" : "422412914507538432",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh yes! Mostly as a challenge to others.",
  "id" : 422412914507538432,
  "in_reply_to_status_id" : 422408684384186368,
  "created_at" : "2014-01-12 17:01:01 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422403564917362688",
  "geo" : { },
  "id_str" : "422406181986922496",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh there's also no twitter login, or IAP. I'm kind of impressed that it made it to the top ten Free list!",
  "id" : 422406181986922496,
  "in_reply_to_status_id" : 422403564917362688,
  "created_at" : "2014-01-12 16:34:16 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422403564917362688",
  "geo" : { },
  "id_str" : "422405928156422144",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh that's not how it works at all. You have to hit the share button, and it's insanely difficult",
  "id" : 422405928156422144,
  "in_reply_to_status_id" : 422403564917362688,
  "created_at" : "2014-01-12 16:33:15 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flapflap",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/RGIRChP2Fp",
      "expanded_url" : "http:\/\/itunes.apple.com\/app\/id642099621",
      "display_url" : "itunes.apple.com\/app\/id642099621"
    } ]
  },
  "geo" : { },
  "id_str" : "422381902830391296",
  "text" : "OMG! I scored 4 pts in #flapflap!!! -&gt; http:\/\/t.co\/RGIRChP2Fp",
  "id" : 422381902830391296,
  "created_at" : "2014-01-12 14:57:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NEIL cicierega",
      "screen_name" : "neilyourself",
      "indices" : [ 0, 13 ],
      "id_str" : "15360428",
      "id" : 15360428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422144795264307200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9809646473, -78.9113463278 ]
  },
  "id_str" : "422144914517135360",
  "in_reply_to_user_id" : 15360428,
  "text" : "@neilyourself",
  "id" : 422144914517135360,
  "in_reply_to_status_id" : 422144795264307200,
  "created_at" : "2014-01-11 23:16:05 +0000",
  "in_reply_to_screen_name" : "neilyourself",
  "in_reply_to_user_id_str" : "15360428",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delisa",
      "screen_name" : "kattrali",
      "indices" : [ 0, 9 ],
      "id_str" : "40614452",
      "id" : 40614452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422030999518580736",
  "geo" : { },
  "id_str" : "422032469505089536",
  "in_reply_to_user_id" : 40614452,
  "text" : "@kattrali haha! It's in the same lot as Home Depot, so been going by it a lot. Also, it just opened.",
  "id" : 422032469505089536,
  "in_reply_to_status_id" : 422030999518580736,
  "created_at" : "2014-01-11 15:49:16 +0000",
  "in_reply_to_screen_name" : "kattrali",
  "in_reply_to_user_id_str" : "40614452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422027446414999552",
  "text" : "Popeye's line is 7 deep at 10:30AM. \uD83D\uDE10",
  "id" : 422027446414999552,
  "created_at" : "2014-01-11 15:29:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422011085667831808",
  "text" : "Does anyone actually have a WiiU? I'm quaranto if you want a friend. \uD83D\uDC96",
  "id" : 422011085667831808,
  "created_at" : "2014-01-11 14:24:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "indices" : [ 3, 13 ],
      "id_str" : "5493662",
      "id" : 5493662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bdekXHWCsJ",
      "expanded_url" : "http:\/\/railsconf.com\/program",
      "display_url" : "railsconf.com\/program"
    } ]
  },
  "geo" : { },
  "id_str" : "421851788073906176",
  "text" : "RT @railsconf: Who doesn't like good news at the end of a long week? Well, here's some for you: our CFP is now open, till Feb 21! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bdekXHWCsJ",
        "expanded_url" : "http:\/\/railsconf.com\/program",
        "display_url" : "railsconf.com\/program"
      } ]
    },
    "geo" : { },
    "id_str" : "421811993645813760",
    "text" : "Who doesn't like good news at the end of a long week? Well, here's some for you: our CFP is now open, till Feb 21! http:\/\/t.co\/bdekXHWCsJ",
    "id" : 421811993645813760,
    "created_at" : "2014-01-11 01:13:10 +0000",
    "user" : {
      "name" : "RailsConf 2015",
      "screen_name" : "railsconf",
      "protected" : false,
      "id_str" : "5493662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555794992384327680\/l6g_DE69_normal.jpeg",
      "id" : 5493662,
      "verified" : false
    }
  },
  "id" : 421851788073906176,
  "created_at" : "2014-01-11 03:51:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Chaffee",
      "screen_name" : "alexch",
      "indices" : [ 0, 7 ],
      "id_str" : "7632622",
      "id" : 7632622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421752461578104832",
  "geo" : { },
  "id_str" : "421753780720250880",
  "in_reply_to_user_id" : 7632622,
  "text" : "@alexch 301 Redirect?",
  "id" : 421753780720250880,
  "in_reply_to_status_id" : 421752461578104832,
  "created_at" : "2014-01-10 21:21:51 +0000",
  "in_reply_to_screen_name" : "alexch",
  "in_reply_to_user_id_str" : "7632622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421749592867102720",
  "text" : "Amazed that after all this time, eBay URLs still have .dll in them.",
  "id" : 421749592867102720,
  "created_at" : "2014-01-10 21:05:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421717285355536384",
  "geo" : { },
  "id_str" : "421717830707335169",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej technoviking does not dance to the music",
  "id" : 421717830707335169,
  "in_reply_to_status_id" : 421717285355536384,
  "created_at" : "2014-01-10 18:59:00 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 3, 16 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/421717616139317249\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/koelnFeb97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdo97_uCAAAxe8e.png",
      "id_str" : "421717616038641664",
      "id" : 421717616038641664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdo97_uCAAAxe8e.png",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 309
      } ],
      "display_url" : "pic.twitter.com\/koelnFeb97"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421717745982373888",
  "text" : "RT @TommyCreenan: Unfortunate Twitter Thumbnail of the day http:\/\/t.co\/koelnFeb97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/421717616139317249\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/koelnFeb97",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdo97_uCAAAxe8e.png",
        "id_str" : "421717616038641664",
        "id" : 421717616038641664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdo97_uCAAAxe8e.png",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 309
        } ],
        "display_url" : "pic.twitter.com\/koelnFeb97"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421717616139317249",
    "text" : "Unfortunate Twitter Thumbnail of the day http:\/\/t.co\/koelnFeb97",
    "id" : 421717616139317249,
    "created_at" : "2014-01-10 18:58:09 +0000",
    "user" : {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "protected" : false,
      "id_str" : "257495729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532272850242002944\/SAUXcbLf_normal.jpeg",
      "id" : 257495729,
      "verified" : false
    }
  },
  "id" : 421717745982373888,
  "created_at" : "2014-01-10 18:58:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 61, 72 ],
      "id_str" : "38408851",
      "id" : 38408851
    }, {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "indices" : [ 73, 86 ],
      "id_str" : "72991857",
      "id" : 72991857
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 87, 98 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 99, 108 ],
      "id_str" : "787975",
      "id" : 787975
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/421715400427335680\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/6s51AFex1e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdo77ApIIAEbTBE.jpg",
      "id_str" : "421715400083382273",
      "id" : 421715400083382273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdo77ApIIAEbTBE.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/6s51AFex1e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421715400427335680",
  "text" : "Ministers from Madison in 1947 aren't to be messed with. \/cc @Jonplussed @juliabwrites @ashedryden @mathiasx http:\/\/t.co\/6s51AFex1e",
  "id" : 421715400427335680,
  "created_at" : "2014-01-10 18:49:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bacigalupo",
      "screen_name" : "tonybgoode",
      "indices" : [ 0, 11 ],
      "id_str" : "2852911",
      "id" : 2852911
    }, {
      "name" : "Len Smith",
      "screen_name" : "ignu",
      "indices" : [ 12, 17 ],
      "id_str" : "6649832",
      "id" : 6649832
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 49, 63 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Silo City Rocks!",
      "screen_name" : "SiloCityRocks",
      "indices" : [ 76, 90 ],
      "id_str" : "126023850",
      "id" : 126023850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421693777884241920",
  "geo" : { },
  "id_str" : "421703602931896320",
  "in_reply_to_user_id" : 2852911,
  "text" : "@tonybgoode @ignu maybe we need to open a second @coworkbuffalo location in @SiloCityRocks!",
  "id" : 421703602931896320,
  "in_reply_to_status_id" : 421693777884241920,
  "created_at" : "2014-01-10 18:02:28 +0000",
  "in_reply_to_screen_name" : "tonybgoode",
  "in_reply_to_user_id_str" : "2852911",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Hayes",
      "screen_name" : "michaelhayes",
      "indices" : [ 3, 16 ],
      "id_str" : "7764332",
      "id" : 7764332
    }, {
      "name" : "Drew Philp",
      "screen_name" : "drewphilp",
      "indices" : [ 86, 96 ],
      "id_str" : "36222749",
      "id" : 36222749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/f7xmOspr47",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/drewphilp\/why-i-bought-a-house-in-detroit-for-500",
      "display_url" : "buzzfeed.com\/drewphilp\/why-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421663034898386944",
  "text" : "RT @michaelhayes: Why I Bought A House In Detroit For $500 http:\/\/t.co\/f7xmOspr47 via @drewphilp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Drew Philp",
        "screen_name" : "drewphilp",
        "indices" : [ 68, 78 ],
        "id_str" : "36222749",
        "id" : 36222749
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/f7xmOspr47",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/drewphilp\/why-i-bought-a-house-in-detroit-for-500",
        "display_url" : "buzzfeed.com\/drewphilp\/why-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421658180926447618",
    "text" : "Why I Bought A House In Detroit For $500 http:\/\/t.co\/f7xmOspr47 via @drewphilp",
    "id" : 421658180926447618,
    "created_at" : "2014-01-10 15:01:59 +0000",
    "user" : {
      "name" : "Mike Hayes",
      "screen_name" : "michaelhayes",
      "protected" : false,
      "id_str" : "7764332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514783246261837824\/siTbQww__normal.jpeg",
      "id" : 7764332,
      "verified" : true
    }
  },
  "id" : 421663034898386944,
  "created_at" : "2014-01-10 15:21:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/CdnTFjnWh2",
      "expanded_url" : "http:\/\/www.businessinsider.com\/google--private-ferry-2014-1",
      "display_url" : "businessinsider.com\/google--privat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421531924902211584",
  "text" : "RT @sstephenson: Must feel downright embarrassing to be a self-aware tech worker in San Francisco in 2014. http:\/\/t.co\/CdnTFjnWh2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/CdnTFjnWh2",
        "expanded_url" : "http:\/\/www.businessinsider.com\/google--private-ferry-2014-1",
        "display_url" : "businessinsider.com\/google--privat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421074201001213952",
    "text" : "Must feel downright embarrassing to be a self-aware tech worker in San Francisco in 2014. http:\/\/t.co\/CdnTFjnWh2",
    "id" : 421074201001213952,
    "created_at" : "2014-01-09 00:21:27 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 421531924902211584,
  "created_at" : "2014-01-10 06:40:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Broadbent",
      "screen_name" : "ndbroadbent",
      "indices" : [ 0, 12 ],
      "id_str" : "27366114",
      "id" : 27366114
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 27, 35 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420406739226206210",
  "geo" : { },
  "id_str" : "421411847984541696",
  "in_reply_to_user_id" : 27366114,
  "text" : "@ndbroadbent Huh. Why? \/cc @evanphx",
  "id" : 421411847984541696,
  "in_reply_to_status_id" : 420406739226206210,
  "created_at" : "2014-01-09 22:43:08 +0000",
  "in_reply_to_screen_name" : "ndbroadbent",
  "in_reply_to_user_id_str" : "27366114",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 13, 27 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421399608606986240",
  "geo" : { },
  "id_str" : "421399824538148864",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @garybernhardt throw some GIFs in there for me",
  "id" : 421399824538148864,
  "in_reply_to_status_id" : 421399608606986240,
  "created_at" : "2014-01-09 21:55:22 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 27, 41 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 139, 140 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421398307987279872",
  "text" : "RT @kevinpurdy: UPS guy to @coworkbuffalo's Amazon loyalists: \"Don't you guys have a house?\"\n\nDowntown revitalization starts with US. (h\/t \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 11, 25 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Kevin Christner",
        "screen_name" : "sailflyer",
        "indices" : [ 123, 133 ],
        "id_str" : "1711505156",
        "id" : 1711505156
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421397666170302464",
    "text" : "UPS guy to @coworkbuffalo's Amazon loyalists: \"Don't you guys have a house?\"\n\nDowntown revitalization starts with US. (h\/t @sailflyer)",
    "id" : 421397666170302464,
    "created_at" : "2014-01-09 21:46:47 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 421398307987279872,
  "created_at" : "2014-01-09 21:49:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421357412667256832",
  "geo" : { },
  "id_str" : "421357763558510592",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack whaaaaat is this!?",
  "id" : 421357763558510592,
  "in_reply_to_status_id" : 421357412667256832,
  "created_at" : "2014-01-09 19:08:13 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Roselli",
      "screen_name" : "aardrian",
      "indices" : [ 0, 9 ],
      "id_str" : "16515870",
      "id" : 16515870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421330732816949248",
  "geo" : { },
  "id_str" : "421344009210953728",
  "in_reply_to_user_id" : 16515870,
  "text" : "@aardrian I'm convinced they are going to get a C&amp;D really quickly about that name...",
  "id" : 421344009210953728,
  "in_reply_to_status_id" : 421330732816949248,
  "created_at" : "2014-01-09 18:13:34 +0000",
  "in_reply_to_screen_name" : "aardrian",
  "in_reply_to_user_id_str" : "16515870",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Aley",
      "screen_name" : "jimaley",
      "indices" : [ 3, 11 ],
      "id_str" : "6065282",
      "id" : 6065282
    }, {
      "name" : "Businessweek",
      "screen_name" : "BW",
      "indices" : [ 17, 20 ],
      "id_str" : "67358777",
      "id" : 67358777
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jimaley\/status\/421283052409876480\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Z9PsbO6bOz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdiytC_IEAAdCWH.jpg",
      "id_str" : "421283052124639232",
      "id" : 421283052124639232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdiytC_IEAAdCWH.jpg",
      "sizes" : [ {
        "h" : 756,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 567
      } ],
      "display_url" : "pic.twitter.com\/Z9PsbO6bOz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421329149882404864",
  "text" : "RT @jimaley: New @bw cover about Bitcoin. This one will delight fans of Thomas Kinkade and Trapper Keepers. http:\/\/t.co\/Z9PsbO6bOz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Businessweek",
        "screen_name" : "BW",
        "indices" : [ 4, 7 ],
        "id_str" : "67358777",
        "id" : 67358777
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jimaley\/status\/421283052409876480\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/Z9PsbO6bOz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdiytC_IEAAdCWH.jpg",
        "id_str" : "421283052124639232",
        "id" : 421283052124639232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdiytC_IEAAdCWH.jpg",
        "sizes" : [ {
          "h" : 756,
          "resize" : "fit",
          "w" : 567
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 567
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 567
        } ],
        "display_url" : "pic.twitter.com\/Z9PsbO6bOz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421283052409876480",
    "text" : "New @bw cover about Bitcoin. This one will delight fans of Thomas Kinkade and Trapper Keepers. http:\/\/t.co\/Z9PsbO6bOz",
    "id" : 421283052409876480,
    "created_at" : "2014-01-09 14:11:21 +0000",
    "user" : {
      "name" : "Jim Aley",
      "screen_name" : "jimaley",
      "protected" : false,
      "id_str" : "6065282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2928401560\/7b981209a02e8019819973226d5c07ed_normal.png",
      "id" : 6065282,
      "verified" : false
    }
  },
  "id" : 421329149882404864,
  "created_at" : "2014-01-09 17:14:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "indices" : [ 3, 15 ],
      "id_str" : "66666549",
      "id" : 66666549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421318124994965505",
  "text" : "RT @TweetsofOld: Joseph Stefunski, an anarchist cowboy of Geyser, Mont., opened fire in the Buffalo city hall yesterday causing a general p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421317989422481408",
    "text" : "Joseph Stefunski, an anarchist cowboy of Geyser, Mont., opened fire in the Buffalo city hall yesterday causing a general panic. NY1913",
    "id" : 421317989422481408,
    "created_at" : "2014-01-09 16:30:11 +0000",
    "user" : {
      "name" : "R.L. Ripples",
      "screen_name" : "TweetsofOld",
      "protected" : false,
      "id_str" : "66666549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488101282473721856\/ddsWSyyl_normal.jpeg",
      "id" : 66666549,
      "verified" : false
    }
  },
  "id" : 421318124994965505,
  "created_at" : "2014-01-09 16:30:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/awlYfFGISb",
      "expanded_url" : "https:\/\/github.com\/ggreer\/the_silver_searcher",
      "display_url" : "github.com\/ggreer\/the_sil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421309639985090560",
  "text" : "Fully off ack and on ag for zsh\/vim. Should have switched earlier. https:\/\/t.co\/awlYfFGISb",
  "id" : 421309639985090560,
  "created_at" : "2014-01-09 15:57:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Miner",
      "screen_name" : "BfloBiz_Miner",
      "indices" : [ 0, 14 ],
      "id_str" : "479610380",
      "id" : 479610380
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 15, 29 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 30, 38 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/2SpP8KNUOM",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Chair-maker",
      "display_url" : "en.wikipedia.org\/wiki\/Chair-mak\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421302496099713025",
  "geo" : { },
  "id_str" : "421302651985207297",
  "in_reply_to_user_id" : 479610380,
  "text" : "@BfloBiz_Miner @coworkbuffalo @fending It's an actual word! http:\/\/t.co\/2SpP8KNUOM",
  "id" : 421302651985207297,
  "in_reply_to_status_id" : 421302496099713025,
  "created_at" : "2014-01-09 15:29:14 +0000",
  "in_reply_to_screen_name" : "BfloBiz_Miner",
  "in_reply_to_user_id_str" : "479610380",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Business First",
      "screen_name" : "BfloBizFirst",
      "indices" : [ 3, 16 ],
      "id_str" : "25549003",
      "id" : 25549003
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 19, 33 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/BBiYLvWatT",
      "expanded_url" : "http:\/\/bizj.us\/u2kmr",
      "display_url" : "bizj.us\/u2kmr"
    } ]
  },
  "geo" : { },
  "id_str" : "421301352401092608",
  "text" : "RT @BfloBizFirst: .@coworkbuffalo striding toward financial goals http:\/\/t.co\/BBiYLvWatT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 1, 15 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/BBiYLvWatT",
        "expanded_url" : "http:\/\/bizj.us\/u2kmr",
        "display_url" : "bizj.us\/u2kmr"
      } ]
    },
    "geo" : { },
    "id_str" : "421294591006867456",
    "text" : ".@coworkbuffalo striding toward financial goals http:\/\/t.co\/BBiYLvWatT",
    "id" : 421294591006867456,
    "created_at" : "2014-01-09 14:57:12 +0000",
    "user" : {
      "name" : "Business First",
      "screen_name" : "BfloBizFirst",
      "protected" : false,
      "id_str" : "25549003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447005729484840960\/LgZho1Ho_normal.png",
      "id" : 25549003,
      "verified" : false
    }
  },
  "id" : 421301352401092608,
  "created_at" : "2014-01-09 15:24:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421036297377968128",
  "text" : "The best part about old concert videos? No one sticking phones up for photos. (I am guilty of this too, and they always come out terrible)",
  "id" : 421036297377968128,
  "created_at" : "2014-01-08 21:50:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ConsumersBeer",
      "screen_name" : "ConsumersBeer",
      "indices" : [ 3, 17 ],
      "id_str" : "18144525",
      "id" : 18144525
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ConsumersBeer\/status\/421032336994865153\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QgSD2um4u2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdfOrftIcAAEIzO.jpg",
      "id_str" : "421032336822923264",
      "id" : 421032336822923264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdfOrftIcAAEIzO.jpg",
      "sizes" : [ {
        "h" : 388,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1224
      } ],
      "display_url" : "pic.twitter.com\/QgSD2um4u2"
    } ],
    "hashtags" : [ {
      "text" : "headsup",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421035223707840512",
  "text" : "RT @ConsumersBeer: Not to be outdone by those Amazon delivery drones, we're in the early stages of developing our own system #headsup http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ConsumersBeer\/status\/421032336994865153\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/QgSD2um4u2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdfOrftIcAAEIzO.jpg",
        "id_str" : "421032336822923264",
        "id" : 421032336822923264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdfOrftIcAAEIzO.jpg",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/QgSD2um4u2"
      } ],
      "hashtags" : [ {
        "text" : "headsup",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421032336994865153",
    "text" : "Not to be outdone by those Amazon delivery drones, we're in the early stages of developing our own system #headsup http:\/\/t.co\/QgSD2um4u2",
    "id" : 421032336994865153,
    "created_at" : "2014-01-08 21:35:06 +0000",
    "user" : {
      "name" : "ConsumersBeer",
      "screen_name" : "ConsumersBeer",
      "protected" : false,
      "id_str" : "18144525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514833356517683200\/5o4VqdGv_normal.jpeg",
      "id" : 18144525,
      "verified" : false
    }
  },
  "id" : 421035223707840512,
  "created_at" : "2014-01-08 21:46:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    }, {
      "name" : "Jamon Holmgren",
      "screen_name" : "jamonholmgren",
      "indices" : [ 17, 31 ],
      "id_str" : "30273948",
      "id" : 30273948
    }, {
      "name" : "brook riggio",
      "screen_name" : "brookr",
      "indices" : [ 32, 39 ],
      "id_str" : "11136022",
      "id" : 11136022
    }, {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 49, 56 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420746938569326592",
  "geo" : { },
  "id_str" : "420750188295122944",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 @jamonholmgren @brookr @r_0b3rt @mislav we definitely use it every day at 37, all of our apps &amp; dev machines are on it.",
  "id" : 420750188295122944,
  "in_reply_to_status_id" : 420746938569326592,
  "created_at" : "2014-01-08 02:53:56 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/88PxeoFu3M",
      "expanded_url" : "https:\/\/bitbucket.org\/facebook\/hgwatchman",
      "display_url" : "bitbucket.org\/facebook\/hgwat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420748431523471360",
  "text" : "Horrifying: \"On a real-world repository with over 200,000 files...\" https:\/\/t.co\/88PxeoFu3M",
  "id" : 420748431523471360,
  "created_at" : "2014-01-08 02:46:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/420747113601826816\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xAikSf0uAg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdbLRUcCAAAwjN8.png",
      "id_str" : "420747113610215424",
      "id" : 420747113610215424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdbLRUcCAAAwjN8.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1040
      } ],
      "display_url" : "pic.twitter.com\/xAikSf0uAg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420747113601826816",
  "text" : "The Lego Carcassonne saga continues: Created a \"flat\" tileset with no \"layers\" after feedback about playability. http:\/\/t.co\/xAikSf0uAg",
  "id" : 420747113601826816,
  "created_at" : "2014-01-08 02:41:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420695746363412480",
  "geo" : { },
  "id_str" : "420698358706348033",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel what Dlvl is this!?",
  "id" : 420698358706348033,
  "in_reply_to_status_id" : 420695746363412480,
  "created_at" : "2014-01-07 23:27:59 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 3, 15 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MQMulville\/status\/420645865343053824\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/YV0rBp9ZLd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZvL5SCcAAa3U6.jpg",
      "id_str" : "420645865351442432",
      "id" : 420645865351442432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZvL5SCcAAa3U6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YV0rBp9ZLd"
    } ],
    "hashtags" : [ {
      "text" : "buffalo",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420670646306103296",
  "text" : "RT @mikemikemac: you know it's bad when they cancel a sabres game and the police are on snowmobiles #buffalo http:\/\/t.co\/YV0rBp9ZLd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MQMulville\/status\/420645865343053824\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/YV0rBp9ZLd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZvL5SCcAAa3U6.jpg",
        "id_str" : "420645865351442432",
        "id" : 420645865351442432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZvL5SCcAAa3U6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YV0rBp9ZLd"
      } ],
      "hashtags" : [ {
        "text" : "buffalo",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420649165559824384",
    "text" : "you know it's bad when they cancel a sabres game and the police are on snowmobiles #buffalo http:\/\/t.co\/YV0rBp9ZLd",
    "id" : 420649165559824384,
    "created_at" : "2014-01-07 20:12:31 +0000",
    "user" : {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "protected" : false,
      "id_str" : "158098704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1797045056\/mikemac_normal.png",
      "id" : 158098704,
      "verified" : false
    }
  },
  "id" : 420670646306103296,
  "created_at" : "2014-01-07 21:37:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420632419452981248",
  "geo" : { },
  "id_str" : "420633033872375808",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren says the goon",
  "id" : 420633033872375808,
  "in_reply_to_status_id" : 420632419452981248,
  "created_at" : "2014-01-07 19:08:24 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420631858188013568",
  "geo" : { },
  "id_str" : "420632113759535104",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren yeah, not going to repost there. to abandon the site as a whole because of one idiot mod though... meh :)",
  "id" : 420632113759535104,
  "in_reply_to_status_id" : 420631858188013568,
  "created_at" : "2014-01-07 19:04:45 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420628529286369280",
  "geo" : { },
  "id_str" : "420628726070534144",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker ah \"first\" sounds like it took since you guys started at GH :)",
  "id" : 420628726070534144,
  "in_reply_to_status_id" : 420628529286369280,
  "created_at" : "2014-01-07 18:51:17 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420628059570450432",
  "geo" : { },
  "id_str" : "420628307726462976",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker how long did it take from development =&gt; launch?",
  "id" : 420628307726462976,
  "in_reply_to_status_id" : 420628059570450432,
  "created_at" : "2014-01-07 18:49:38 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420624301411160064",
  "text" : "Subreddit-specific rules infuriate me. 67 upvotes, 20 comments, and post deleted due to a \"rule\" I didn't know about. \u0CA0_\u0CA0",
  "id" : 420624301411160064,
  "created_at" : "2014-01-07 18:33:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420623430656864256",
  "geo" : { },
  "id_str" : "420623631916339200",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman I thought you guys had no managers?!! :trollface:",
  "id" : 420623631916339200,
  "in_reply_to_status_id" : 420623430656864256,
  "created_at" : "2014-01-07 18:31:03 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 3, 12 ],
      "id_str" : "717973",
      "id" : 717973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROC",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "badhaikus",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420612932720795648",
  "text" : "RT @ceejayoz: It\u2019s really really\nreally really really god\ndamned fucking cold here\n\n#ROC #badhaikus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROC",
        "indices" : [ 70, 74 ]
      }, {
        "text" : "badhaikus",
        "indices" : [ 75, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420612764386598912",
    "text" : "It\u2019s really really\nreally really really god\ndamned fucking cold here\n\n#ROC #badhaikus",
    "id" : 420612764386598912,
    "created_at" : "2014-01-07 17:47:52 +0000",
    "user" : {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "protected" : false,
      "id_str" : "717973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509354294991011841\/q2ShY2sL_normal.jpeg",
      "id" : 717973,
      "verified" : false
    }
  },
  "id" : 420612932720795648,
  "created_at" : "2014-01-07 17:48:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420608697379717120",
  "text" : "\u0CA0_\u0CA0 &lt;Tue, 07 Jan 2014 17:31:09 +0000&gt; expected but was &lt;Tue, 07 Jan 2014 17:31:09 +0000&gt;.",
  "id" : 420608697379717120,
  "created_at" : "2014-01-07 17:31:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Howard",
      "screen_name" : "jamesc0nn3ry",
      "indices" : [ 0, 13 ],
      "id_str" : "412320096",
      "id" : 412320096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420606746210480128",
  "geo" : { },
  "id_str" : "420607226554744833",
  "in_reply_to_user_id" : 412320096,
  "text" : "@jamesc0nn3ry thanks! definitely considering submitting it. will look into it more tonight.",
  "id" : 420607226554744833,
  "in_reply_to_status_id" : 420606746210480128,
  "created_at" : "2014-01-07 17:25:51 +0000",
  "in_reply_to_screen_name" : "jamesc0nn3ry",
  "in_reply_to_user_id_str" : "412320096",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420592544930467840",
  "geo" : { },
  "id_str" : "420592646373920768",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan $1 off at Anderson's!",
  "id" : 420592646373920768,
  "in_reply_to_status_id" : 420592544930467840,
  "created_at" : "2014-01-07 16:27:55 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "indices" : [ 3, 18 ],
      "id_str" : "129537034",
      "id" : 129537034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/mrRYkOfGiE",
      "expanded_url" : "http:\/\/hackertyper.net\/",
      "display_url" : "hackertyper.net"
    } ]
  },
  "geo" : { },
  "id_str" : "420580967216996352",
  "text" : "RT @death2normalcy: an important website: http:\/\/t.co\/mrRYkOfGiE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/mrRYkOfGiE",
        "expanded_url" : "http:\/\/hackertyper.net\/",
        "display_url" : "hackertyper.net"
      } ]
    },
    "geo" : { },
    "id_str" : "420580847649976321",
    "text" : "an important website: http:\/\/t.co\/mrRYkOfGiE",
    "id" : 420580847649976321,
    "created_at" : "2014-01-07 15:41:02 +0000",
    "user" : {
      "name" : "5 Nights at Jamie's*",
      "screen_name" : "death2normalcy",
      "protected" : false,
      "id_str" : "129537034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547441738630307842\/g0CM03MX_normal.jpeg",
      "id" : 129537034,
      "verified" : false
    }
  },
  "id" : 420580967216996352,
  "created_at" : "2014-01-07 15:41:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dlugosz",
      "screen_name" : "cubosh",
      "indices" : [ 0, 7 ],
      "id_str" : "70702180",
      "id" : 70702180
    }, {
      "name" : "Danimal\/Armcannon",
      "screen_name" : "armcannon",
      "indices" : [ 8, 18 ],
      "id_str" : "86775045",
      "id" : 86775045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/nSRdcEqPnr",
      "expanded_url" : "http:\/\/www.google.org\/publicalerts\/alert?aid=179d9d4c9f6e0b85&source=pa&hl=en&gl=US",
      "display_url" : "google.org\/publicalerts\/a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420575148010242048",
  "geo" : { },
  "id_str" : "420575224011038721",
  "in_reply_to_user_id" : 70702180,
  "text" : "@cubosh @armcannon http:\/\/t.co\/nSRdcEqPnr",
  "id" : 420575224011038721,
  "in_reply_to_status_id" : 420575148010242048,
  "created_at" : "2014-01-07 15:18:41 +0000",
  "in_reply_to_screen_name" : "cubosh",
  "in_reply_to_user_id_str" : "70702180",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 26, 35 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420572969262260224",
  "text" : "RT @zobar2: Because of \u2603, @openhack is cancelled tonight. Next OpenHack is Jan 21, when we will hack on things and tell crazy blizzard stor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 14, 23 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420572546329636865",
    "text" : "Because of \u2603, @openhack is cancelled tonight. Next OpenHack is Jan 21, when we will hack on things and tell crazy blizzard stories.",
    "id" : 420572546329636865,
    "created_at" : "2014-01-07 15:08:03 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 420572969262260224,
  "created_at" : "2014-01-07 15:09:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Rudick",
      "screen_name" : "tmrudick",
      "indices" : [ 0, 9 ],
      "id_str" : "15198826",
      "id" : 15198826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/R1CToJQCeS",
      "expanded_url" : "http:\/\/quaran.to\/lego-carcassonne\/",
      "display_url" : "quaran.to\/lego-carcasson\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420557590528274432",
  "geo" : { },
  "id_str" : "420558206423674881",
  "in_reply_to_user_id" : 15198826,
  "text" : "@tmrudick it's clunky, but works! I'm surprised it's abandoned given its capability. Even the instructions are great: http:\/\/t.co\/R1CToJQCeS",
  "id" : 420558206423674881,
  "in_reply_to_status_id" : 420557590528274432,
  "created_at" : "2014-01-07 14:11:04 +0000",
  "in_reply_to_screen_name" : "tmrudick",
  "in_reply_to_user_id_str" : "15198826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0O62bLNmEo",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/420544330843963392",
      "display_url" : "twitter.com\/qrush\/status\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420553680027668480",
  "geo" : { },
  "id_str" : "420557424517328898",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss pricing out each brick is not easy: https:\/\/t.co\/0O62bLNmEo",
  "id" : 420557424517328898,
  "in_reply_to_status_id" : 420553680027668480,
  "created_at" : "2014-01-07 14:07:58 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/MHGBaQarWI",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/01\/06\/5x5-lego-carcassone\/",
      "display_url" : "quaran.to\/blog\/2014\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420556852162609152",
  "text" : "ICYMI: I made a 5x5 Lego Carcassonne set...next step: making it real! http:\/\/t.co\/MHGBaQarWI",
  "id" : 420556852162609152,
  "created_at" : "2014-01-07 14:05:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420530575061966848",
  "geo" : { },
  "id_str" : "420544330843963392",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier hard to say...I'd have to price out buying each brick part individually. Not all the colors are available either.",
  "id" : 420544330843963392,
  "in_reply_to_status_id" : 420530575061966848,
  "created_at" : "2014-01-07 13:15:56 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roy Tomeij",
      "screen_name" : "roy",
      "indices" : [ 0, 4 ],
      "id_str" : "8837982",
      "id" : 8837982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420480410406359040",
  "geo" : { },
  "id_str" : "420503864732049408",
  "in_reply_to_user_id" : 8837982,
  "text" : "@roy will fix!",
  "id" : 420503864732049408,
  "in_reply_to_status_id" : 420480410406359040,
  "created_at" : "2014-01-07 10:35:08 +0000",
  "in_reply_to_screen_name" : "roy",
  "in_reply_to_user_id_str" : "8837982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    }, {
      "name" : "Aaron Quint",
      "screen_name" : "aq",
      "indices" : [ 9, 12 ],
      "id_str" : "1178441",
      "id" : 1178441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420439535424913408",
  "geo" : { },
  "id_str" : "420439821094383616",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig @aq Thanks! It seems like there's projects on Cuusoo that obviously don't own the IP\/trademarks. Just need to submit it, I suppose!",
  "id" : 420439821094383616,
  "in_reply_to_status_id" : 420439535424913408,
  "created_at" : "2014-01-07 06:20:39 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/420433911777206272\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GFk1dStIpL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdWuakwCMAAA7vz.png",
      "id_str" : "420433911793987584",
      "id" : 420433911793987584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdWuakwCMAAA7vz.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1040
      } ],
      "display_url" : "pic.twitter.com\/GFk1dStIpL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420433424961134592",
  "geo" : { },
  "id_str" : "420433911777206272",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik seriously, want to play it. prototyped out a River xpac while GitHub Pages was down: http:\/\/t.co\/GFk1dStIpL",
  "id" : 420433911777206272,
  "in_reply_to_status_id" : 420433424961134592,
  "created_at" : "2014-01-07 05:57:10 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/MHGBaQarWI",
      "expanded_url" : "http:\/\/quaran.to\/blog\/2014\/01\/06\/5x5-lego-carcassone\/",
      "display_url" : "quaran.to\/blog\/2014\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420432653519568897",
  "text" : "5x5 Lego Carcassone: I want this to be real! http:\/\/t.co\/MHGBaQarWI",
  "id" : 420432653519568897,
  "created_at" : "2014-01-07 05:52:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420432294797529088",
  "geo" : { },
  "id_str" : "420432550205476864",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr woot! thanks.",
  "id" : 420432550205476864,
  "in_reply_to_status_id" : 420432294797529088,
  "created_at" : "2014-01-07 05:51:45 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420418257745502208",
  "geo" : { },
  "id_str" : "420421358527320065",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek any ideas if it will be fixed tonight? :(",
  "id" : 420421358527320065,
  "in_reply_to_status_id" : 420418257745502208,
  "created_at" : "2014-01-07 05:07:17 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sharpe",
      "screen_name" : "rodjek",
      "indices" : [ 0, 7 ],
      "id_str" : "14439880",
      "id" : 14439880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420418257745502208",
  "geo" : { },
  "id_str" : "420418296786083840",
  "in_reply_to_user_id" : 14439880,
  "text" : "@rodjek so, it's down :)",
  "id" : 420418296786083840,
  "in_reply_to_status_id" : 420418257745502208,
  "created_at" : "2014-01-07 04:55:07 +0000",
  "in_reply_to_screen_name" : "rodjek",
  "in_reply_to_user_id_str" : "14439880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420417702037975041",
  "text" : "Of course, the one day I write a blog post, GitHub Pages is offline :(",
  "id" : 420417702037975041,
  "created_at" : "2014-01-07 04:52:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Chalupa",
      "screen_name" : "brettchalupa",
      "indices" : [ 0, 13 ],
      "id_str" : "1209426272",
      "id" : 1209426272
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 14, 29 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 35, 40 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420281865266683904",
  "geo" : { },
  "id_str" : "420329564795985921",
  "in_reply_to_user_id" : 1209426272,
  "text" : "@brettchalupa @nickelcityruby ugh! @jhsu can you get it back?",
  "id" : 420329564795985921,
  "in_reply_to_status_id" : 420281865266683904,
  "created_at" : "2014-01-06 23:02:32 +0000",
  "in_reply_to_screen_name" : "brettchalupa",
  "in_reply_to_user_id_str" : "1209426272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/dUbKqD0mPL",
      "expanded_url" : "http:\/\/www.google.org\/publicalerts\/alert?aid=98934f15a86cbf2a&hl=en",
      "display_url" : "google.org\/publicalerts\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420326460172169216",
  "text" : "LAKE ERIE used BLIZZARD! It's SUPER EFFECTIVE! http:\/\/t.co\/dUbKqD0mPL",
  "id" : 420326460172169216,
  "created_at" : "2014-01-06 22:50:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetsOfAdventure",
      "screen_name" : "bombsfall",
      "indices" : [ 3, 13 ],
      "id_str" : "298942872",
      "id" : 298942872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420287815713554432",
  "text" : "RT @bombsfall: THE COFFEE HAS KICKED IN I AM A BEING OF PURE ENERGY AND POTENTIAL I AM A HORSE MADE OF CHAINSAWS I AM THE GOLDEN ETERNITY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419863239954923520",
    "text" : "THE COFFEE HAS KICKED IN I AM A BEING OF PURE ENERGY AND POTENTIAL I AM A HORSE MADE OF CHAINSAWS I AM THE GOLDEN ETERNITY",
    "id" : 419863239954923520,
    "created_at" : "2014-01-05 16:09:31 +0000",
    "user" : {
      "name" : "TweetsOfAdventure",
      "screen_name" : "bombsfall",
      "protected" : false,
      "id_str" : "298942872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538168596862484480\/LqfzFCRe_normal.jpeg",
      "id" : 298942872,
      "verified" : false
    }
  },
  "id" : 420287815713554432,
  "created_at" : "2014-01-06 20:16:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZmFT6XlioT",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/1ujjur\/hackernews_down_unwisely_returning_http_200_for\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420286207814144000",
  "text" : "Proggit comes through, as usual. From: http:\/\/t.co\/ZmFT6XlioT",
  "id" : 420286207814144000,
  "created_at" : "2014-01-06 20:10:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420286130668331009",
  "text" : "HN down: \"I've written a Bitcoin miner in Python 3 to buy a pair of Google Glass but now I'm worried about all three because government.\"",
  "id" : 420286130668331009,
  "created_at" : "2014-01-06 20:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "indices" : [ 3, 15 ],
      "id_str" : "15387091",
      "id" : 15387091
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 82, 96 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Ij6tykbKKt",
      "expanded_url" : "http:\/\/kck.st\/1gbX5Lq",
      "display_url" : "kck.st\/1gbX5Lq"
    } ]
  },
  "geo" : { },
  "id_str" : "420272896213147649",
  "text" : "RT @levineuland: Help support an alternative work space in downtown Buffalo. Back @CoworkBuffalo on Kickstarter: http:\/\/t.co\/Ij6tykbKKt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 65, 79 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Ij6tykbKKt",
        "expanded_url" : "http:\/\/kck.st\/1gbX5Lq",
        "display_url" : "kck.st\/1gbX5Lq"
      } ]
    },
    "geo" : { },
    "id_str" : "420264900473004032",
    "text" : "Help support an alternative work space in downtown Buffalo. Back @CoworkBuffalo on Kickstarter: http:\/\/t.co\/Ij6tykbKKt",
    "id" : 420264900473004032,
    "created_at" : "2014-01-06 18:45:35 +0000",
    "user" : {
      "name" : "Levi Neuland",
      "screen_name" : "levineuland",
      "protected" : false,
      "id_str" : "15387091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549773022270218240\/ERdLh33v_normal.jpeg",
      "id" : 15387091,
      "verified" : false
    }
  },
  "id" : 420272896213147649,
  "created_at" : "2014-01-06 19:17:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 3, 12 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/deqPEAX0PP",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "420272811102334976",
  "text" : "RT @mikesusz: i threw a couple bucks at the co-working space in buffalo. i think it\u2019s a great idea and am glad to help :) http:\/\/t.co\/deqPE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/deqPEAX0PP",
        "expanded_url" : "http:\/\/kck.st\/18RQYKG",
        "display_url" : "kck.st\/18RQYKG"
      } ]
    },
    "geo" : { },
    "id_str" : "420265392821784577",
    "text" : "i threw a couple bucks at the co-working space in buffalo. i think it\u2019s a great idea and am glad to help :) http:\/\/t.co\/deqPEAX0PP",
    "id" : 420265392821784577,
    "created_at" : "2014-01-06 18:47:32 +0000",
    "user" : {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "protected" : false,
      "id_str" : "14531472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479668081800011776\/ZT23cqOn_normal.jpeg",
      "id" : 14531472,
      "verified" : false
    }
  },
  "id" : 420272811102334976,
  "created_at" : "2014-01-06 19:17:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420264387467681792",
  "geo" : { },
  "id_str" : "420264818243678208",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier I dabble.",
  "id" : 420264818243678208,
  "in_reply_to_status_id" : 420264387467681792,
  "created_at" : "2014-01-06 18:45:15 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 20, 34 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1rEjecAMZ0",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/712726",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420263434966409218",
  "text" : "Our Kickstarter for @coworkbuffalo is still going strong. Help us reach some stretch goals! http:\/\/t.co\/1rEjecAMZ0",
  "id" : 420263434966409218,
  "created_at" : "2014-01-06 18:39:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Miner",
      "screen_name" : "BfloBiz_Miner",
      "indices" : [ 0, 14 ],
      "id_str" : "479610380",
      "id" : 479610380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/1rEjecAMZ0",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community\/posts\/712726",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420236378245312512",
  "geo" : { },
  "id_str" : "420263115729547264",
  "in_reply_to_user_id" : 479610380,
  "text" : "@BfloBiz_Miner just posted the stretch goals! http:\/\/t.co\/1rEjecAMZ0",
  "id" : 420263115729547264,
  "in_reply_to_status_id" : 420236378245312512,
  "created_at" : "2014-01-06 18:38:29 +0000",
  "in_reply_to_screen_name" : "BfloBiz_Miner",
  "in_reply_to_user_id_str" : "479610380",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 22, 26 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420224954584420353",
  "geo" : { },
  "id_str" : "420225360257495042",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette apparently @dhh forgot the chapter about bathroom selfies",
  "id" : 420225360257495042,
  "in_reply_to_status_id" : 420224954584420353,
  "created_at" : "2014-01-06 16:08:27 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 13, 27 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420220719536951297",
  "text" : "Happy to see @coworkbuffalo bustling today. Snow, ice? It's just a Monday.",
  "id" : 420220719536951297,
  "created_at" : "2014-01-06 15:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420199985859149824",
  "geo" : { },
  "id_str" : "420203298848002048",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier I haven't yet but will. Why?",
  "id" : 420203298848002048,
  "in_reply_to_status_id" : 420199985859149824,
  "created_at" : "2014-01-06 14:40:48 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420186453218693120",
  "geo" : { },
  "id_str" : "420196430477684736",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito not this year.",
  "id" : 420196430477684736,
  "in_reply_to_status_id" : 420186453218693120,
  "created_at" : "2014-01-06 14:13:30 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 3, 9 ],
      "id_str" : "920539489",
      "id" : 920539489
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 11, 17 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 18, 29 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/hHr4Ly0z1n",
      "expanded_url" : "http:\/\/blog.livedoor.jp\/goldennews\/archives\/51824161.html",
      "display_url" : "blog.livedoor.jp\/goldennews\/arc\u2026"
    }, {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/JWXwbdB4gT",
      "expanded_url" : "http:\/\/cl.ly\/image\/2z0T283V3k3f\/o",
      "display_url" : "cl.ly\/image\/2z0T283V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420067590216503297",
  "text" : "RT @_zzak: @qrush @tenderlove It is based off this japanese meme: http:\/\/t.co\/hHr4Ly0z1n and you can find translation here: http:\/\/t.co\/JWX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Aaron Patterson",
        "screen_name" : "tenderlove",
        "indices" : [ 7, 18 ],
        "id_str" : "14761655",
        "id" : 14761655
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/hHr4Ly0z1n",
        "expanded_url" : "http:\/\/blog.livedoor.jp\/goldennews\/archives\/51824161.html",
        "display_url" : "blog.livedoor.jp\/goldennews\/arc\u2026"
      }, {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/JWXwbdB4gT",
        "expanded_url" : "http:\/\/cl.ly\/image\/2z0T283V3k3f\/o",
        "display_url" : "cl.ly\/image\/2z0T283V\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "420059553527377920",
    "geo" : { },
    "id_str" : "420067367536693250",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @tenderlove It is based off this japanese meme: http:\/\/t.co\/hHr4Ly0z1n and you can find translation here: http:\/\/t.co\/JWXwbdB4gT",
    "id" : 420067367536693250,
    "in_reply_to_status_id" : 420059553527377920,
    "created_at" : "2014-01-06 05:40:39 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "protected" : false,
      "id_str" : "920539489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000760450458\/1d14e04afe654ee43abccfce2040558e_normal.jpeg",
      "id" : 920539489,
      "verified" : false
    }
  },
  "id" : 420067590216503297,
  "created_at" : "2014-01-06 05:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420066938321002496",
  "text" : "To my friends heading to #codemash: please travel safe. Lake Erie doesn't mess around.",
  "id" : 420066938321002496,
  "created_at" : "2014-01-06 05:38:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/zTZUGtxMIs",
      "expanded_url" : "http:\/\/www.iamcal.com\/lego-carcassonne\/",
      "display_url" : "iamcal.com\/lego-carcasson\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420063427466235905",
  "text" : "Two words: Lego Carcassone. http:\/\/t.co\/zTZUGtxMIs",
  "id" : 420063427466235905,
  "created_at" : "2014-01-06 05:25:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 8, 19 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "zzak\u3048\u30B6\u30C3\u30AF",
      "screen_name" : "_zzak",
      "indices" : [ 20, 26 ],
      "id_str" : "920539489",
      "id" : 920539489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ZzeSFPZkxB",
      "expanded_url" : "https:\/\/twitter.com\/TeamMOSA2\/status\/419088068537106432",
      "display_url" : "twitter.com\/TeamMOSA2\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420059553527377920",
  "text" : "Hey hey @tenderlove @_zzak would love to see a translation of this! https:\/\/t.co\/ZzeSFPZkxB",
  "id" : 420059553527377920,
  "created_at" : "2014-01-06 05:09:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 0, 7 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420044584433893376",
  "geo" : { },
  "id_str" : "420049468960940032",
  "in_reply_to_user_id" : 15507545,
  "text" : "@hiteak that issue...is much deeper. Having dealt with several roommate horrors...",
  "id" : 420049468960940032,
  "in_reply_to_status_id" : 420044584433893376,
  "created_at" : "2014-01-06 04:29:32 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Schneiderman",
      "screen_name" : "hiteak",
      "indices" : [ 0, 7 ],
      "id_str" : "15507545",
      "id" : 15507545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420041143296856064",
  "geo" : { },
  "id_str" : "420043667156389890",
  "in_reply_to_user_id" : 15507545,
  "text" : "@hiteak :( kind of wish there was a personal finance 101 instead of FYE (?) for first years.",
  "id" : 420043667156389890,
  "in_reply_to_status_id" : 420041143296856064,
  "created_at" : "2014-01-06 04:06:28 +0000",
  "in_reply_to_screen_name" : "hiteak",
  "in_reply_to_user_id_str" : "15507545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 0, 16 ],
      "id_str" : "15428948",
      "id" : 15428948
    }, {
      "name" : "Kevin Christner",
      "screen_name" : "sailflyer",
      "indices" : [ 23, 33 ],
      "id_str" : "1711505156",
      "id" : 1711505156
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 38, 43 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420042167458209792",
  "geo" : { },
  "id_str" : "420042447604166656",
  "in_reply_to_user_id" : 15428948,
  "text" : "@halogenandtoast yeah. @sailflyer and @popo both have good bases that make a huge difference. Would need a similar giant one.",
  "id" : 420042447604166656,
  "in_reply_to_status_id" : 420042167458209792,
  "created_at" : "2014-01-06 04:01:38 +0000",
  "in_reply_to_screen_name" : "halogenandtoast",
  "in_reply_to_user_id_str" : "15428948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/MCj8YFngix",
      "expanded_url" : "http:\/\/m.flickr.com\/photos\/10302709@N05\/954680468\/lightbox\/",
      "display_url" : "m.flickr.com\/photos\/1030270\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420040612163760128",
  "text" : "New crazy idea...build a giant settlers game. http:\/\/t.co\/MCj8YFngix",
  "id" : 420040612163760128,
  "created_at" : "2014-01-06 03:54:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "afgncaap",
      "screen_name" : "kleptomik",
      "indices" : [ 0, 10 ],
      "id_str" : "14330232",
      "id" : 14330232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420039089996312576",
  "geo" : { },
  "id_str" : "420040399176990720",
  "in_reply_to_user_id" : 14330232,
  "text" : "@kleptomik *gets down on floor* *blinks slowly at boyfriend hiding below bed* \"oh geez he's not returning eye contact\"",
  "id" : 420040399176990720,
  "in_reply_to_status_id" : 420039089996312576,
  "created_at" : "2014-01-06 03:53:29 +0000",
  "in_reply_to_screen_name" : "kleptomik",
  "in_reply_to_user_id_str" : "14330232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420033023602458624",
  "geo" : { },
  "id_str" : "420036605626175488",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant agreed, on both counts. Still a mistake to ignore it.",
  "id" : 420036605626175488,
  "in_reply_to_status_id" : 420033023602458624,
  "created_at" : "2014-01-06 03:38:25 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Hanover",
      "screen_name" : "zhanover",
      "indices" : [ 3, 12 ],
      "id_str" : "19783048",
      "id" : 19783048
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zhanover\/status\/420016705713106944\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/o6CBKgnVvm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdQy9-WCEAAfXay.png",
      "id_str" : "420016705541115904",
      "id" : 420016705541115904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdQy9-WCEAAfXay.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 798
      } ],
      "display_url" : "pic.twitter.com\/o6CBKgnVvm"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420023931009896449",
  "text" : "RT @zhanover: Northern dilemma,\nCall of the cold,\nThe arms of the arctic begin to unfold. #phish http:\/\/t.co\/o6CBKgnVvm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zhanover\/status\/420016705713106944\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/o6CBKgnVvm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdQy9-WCEAAfXay.png",
        "id_str" : "420016705541115904",
        "id" : 420016705541115904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdQy9-WCEAAfXay.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 798
        } ],
        "display_url" : "pic.twitter.com\/o6CBKgnVvm"
      } ],
      "hashtags" : [ {
        "text" : "phish",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420016705713106944",
    "text" : "Northern dilemma,\nCall of the cold,\nThe arms of the arctic begin to unfold. #phish http:\/\/t.co\/o6CBKgnVvm",
    "id" : 420016705713106944,
    "created_at" : "2014-01-06 02:19:20 +0000",
    "user" : {
      "name" : "Zach Hanover",
      "screen_name" : "zhanover",
      "protected" : false,
      "id_str" : "19783048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562798655338328064\/vQ0o43rC_normal.jpeg",
      "id" : 19783048,
      "verified" : false
    }
  },
  "id" : 420023931009896449,
  "created_at" : "2014-01-06 02:48:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420020556990119937",
  "geo" : { },
  "id_str" : "420021168259608576",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison not building credit or understanding the system at all.",
  "id" : 420021168259608576,
  "in_reply_to_status_id" : 420020556990119937,
  "created_at" : "2014-01-06 02:37:04 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420014689880244224",
  "geo" : { },
  "id_str" : "420014914871111680",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape whoa! NYC?",
  "id" : 420014914871111680,
  "in_reply_to_status_id" : 420014689880244224,
  "created_at" : "2014-01-06 02:12:13 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubynerd",
      "screen_name" : "rubynerd",
      "indices" : [ 0, 9 ],
      "id_str" : "207100150",
      "id" : 207100150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420014348921503744",
  "geo" : { },
  "id_str" : "420014621169184768",
  "in_reply_to_user_id" : 207100150,
  "text" : "@rubynerd yes.",
  "id" : 420014621169184768,
  "in_reply_to_status_id" : 420014348921503744,
  "created_at" : "2014-01-06 02:11:03 +0000",
  "in_reply_to_screen_name" : "rubynerd",
  "in_reply_to_user_id_str" : "207100150",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420013445866471424",
  "text" : "Arrived at the sub shop, and you had to sign up for a credit card to claim the sub. Plenty of kids were doing it. Left immediately. (2\/2).",
  "id" : 420013445866471424,
  "created_at" : "2014-01-06 02:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420013417798201344",
  "text" : "Another credit related story: I remember getting a handed-out coupon for a free sub in college while walking to class. (1\/2)",
  "id" : 420013417798201344,
  "created_at" : "2014-01-06 02:06:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420011251830251520",
  "geo" : { },
  "id_str" : "420012347139190784",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh better than little to no history, which means shitty rates or being rejected for not playing by \"their\" rules",
  "id" : 420012347139190784,
  "in_reply_to_status_id" : 420011251830251520,
  "created_at" : "2014-01-06 02:02:01 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 114, 122 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420011259598483457",
  "geo" : { },
  "id_str" : "420012143258247169",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 actually i think this was a large part of what made me ignore them. just drilled that they're bad. \/cc @rubiety",
  "id" : 420012143258247169,
  "in_reply_to_status_id" : 420011259598483457,
  "created_at" : "2014-01-06 02:01:13 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420010836808069120",
  "text" : "Biggest mistake I made through college was not understanding credit or credit cards, and completely avoiding them. Huge missed opportunity.",
  "id" : 420010836808069120,
  "created_at" : "2014-01-06 01:56:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 11, 16 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419505514792222720",
  "geo" : { },
  "id_str" : "419818512375246848",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @avdi sounds like a Coworking space to me.",
  "id" : 419818512375246848,
  "in_reply_to_status_id" : 419505514792222720,
  "created_at" : "2014-01-05 13:11:47 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neomind Labs",
      "screen_name" : "NeomindLabs",
      "indices" : [ 0, 12 ],
      "id_str" : "605670059",
      "id" : 605670059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419172436404207616",
  "geo" : { },
  "id_str" : "419219154172780544",
  "in_reply_to_user_id" : 605670059,
  "text" : "@NeomindLabs Thanks!",
  "id" : 419219154172780544,
  "in_reply_to_status_id" : 419172436404207616,
  "created_at" : "2014-01-03 21:30:09 +0000",
  "in_reply_to_screen_name" : "NeomindLabs",
  "in_reply_to_user_id_str" : "605670059",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "mike mac",
      "screen_name" : "mikemikemac",
      "indices" : [ 8, 20 ],
      "id_str" : "158098704",
      "id" : 158098704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419209827944894464",
  "geo" : { },
  "id_str" : "419210046736584704",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @mikemikemac looks like a contender for First Moron To Hit The Metro\u2122",
  "id" : 419210046736584704,
  "in_reply_to_status_id" : 419209827944894464,
  "created_at" : "2014-01-03 20:53:58 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419157852972802049",
  "text" : "`git pus origin master` ...I think I just popped a git pimple.",
  "id" : 419157852972802049,
  "created_at" : "2014-01-03 17:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 17, 29 ],
      "id_str" : "26904582",
      "id" : 26904582
    }, {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 93, 99 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IggelaRXFh",
      "expanded_url" : "https:\/\/medium.com\/the-phish-from-vermont\/dd1dcbb31710",
      "display_url" : "medium.com\/the-phish-from\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419145070659399680",
  "text" : "I can't wait for @AqueousBand to make the bar =&gt; arena transition. Been listening to this @phish set on repeat. https:\/\/t.co\/IggelaRXFh",
  "id" : 419145070659399680,
  "created_at" : "2014-01-03 16:35:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419134762628833282",
  "geo" : { },
  "id_str" : "419136986721439744",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines thanks! maybe for @nickelcityruby '14!?",
  "id" : 419136986721439744,
  "in_reply_to_status_id" : 419134762628833282,
  "created_at" : "2014-01-03 16:03:39 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAYBE coreyhaines",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Chris Buryta",
      "screen_name" : "cburyta",
      "indices" : [ 21, 29 ],
      "id_str" : "5875982",
      "id" : 5875982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419134007259824128",
  "geo" : { },
  "id_str" : "419134216433983488",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines you and @cburyta are awesome for pushing us over!",
  "id" : 419134216433983488,
  "in_reply_to_status_id" : 419134007259824128,
  "created_at" : "2014-01-03 15:52:38 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garden City RubyConf",
      "screen_name" : "GardenCityRb",
      "indices" : [ 0, 13 ],
      "id_str" : "1862216532",
      "id" : 1862216532
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 14, 25 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 26, 34 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418960264600354816",
  "geo" : { },
  "id_str" : "419127981538172928",
  "in_reply_to_user_id" : 1862216532,
  "text" : "@GardenCityRb @chadfowler @evanphx what's the context here?",
  "id" : 419127981538172928,
  "in_reply_to_status_id" : 418960264600354816,
  "created_at" : "2014-01-03 15:27:52 +0000",
  "in_reply_to_screen_name" : "GardenCityRb",
  "in_reply_to_user_id_str" : "1862216532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/IKIiSJdGiK",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/coworkbuffalo\/coworkbuffalo-2-more-space-work-and-community",
      "display_url" : "kickstarter.com\/projects\/cowor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419121569449783296",
  "text" : "Under $100 left. Who's in!? http:\/\/t.co\/IKIiSJdGiK",
  "id" : 419121569449783296,
  "created_at" : "2014-01-03 15:02:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 3, 16 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/419107729265790976\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/GgCn6xbw4n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdD4QlJCYAA_cRi.jpg",
      "id_str" : "419107729077067776",
      "id" : 419107729077067776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdD4QlJCYAA_cRi.jpg",
      "sizes" : [ {
        "h" : 476,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GgCn6xbw4n"
    } ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419108106908356609",
  "text" : "RT @TommyCreenan: #Buffalo http:\/\/t.co\/GgCn6xbw4n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TommyCreenan\/status\/419107729265790976\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/GgCn6xbw4n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdD4QlJCYAA_cRi.jpg",
        "id_str" : "419107729077067776",
        "id" : 419107729077067776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdD4QlJCYAA_cRi.jpg",
        "sizes" : [ {
          "h" : 476,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GgCn6xbw4n"
      } ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419107729265790976",
    "text" : "#Buffalo http:\/\/t.co\/GgCn6xbw4n",
    "id" : 419107729265790976,
    "created_at" : "2014-01-03 14:07:23 +0000",
    "user" : {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "protected" : false,
      "id_str" : "257495729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532272850242002944\/SAUXcbLf_normal.jpeg",
      "id" : 257495729,
      "verified" : false
    }
  },
  "id" : 419108106908356609,
  "created_at" : "2014-01-03 14:08:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joshua schachter",
      "screen_name" : "joshu",
      "indices" : [ 0, 6 ],
      "id_str" : "5017",
      "id" : 5017
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 50, 64 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418931396963356672",
  "geo" : { },
  "id_str" : "418931698366033922",
  "in_reply_to_user_id" : 5017,
  "text" : "@joshu on some nights the nightclub below the old @coworkbuffalo space would make this happen",
  "id" : 418931698366033922,
  "in_reply_to_status_id" : 418931396963356672,
  "created_at" : "2014-01-03 02:27:54 +0000",
  "in_reply_to_screen_name" : "joshu",
  "in_reply_to_user_id_str" : "5017",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joshua schachter",
      "screen_name" : "joshu",
      "indices" : [ 3, 9 ],
      "id_str" : "5017",
      "id" : 5017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418931478857531392",
  "text" : "RT @joshu: Out: coworking spaces. In: Cotwerking space.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418931396963356672",
    "text" : "Out: coworking spaces. In: Cotwerking space.",
    "id" : 418931396963356672,
    "created_at" : "2014-01-03 02:26:43 +0000",
    "user" : {
      "name" : "joshua schachter",
      "screen_name" : "joshu",
      "protected" : false,
      "id_str" : "5017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2207696262\/schachter_normal.jpeg",
      "id" : 5017,
      "verified" : false
    }
  },
  "id" : 418931478857531392,
  "created_at" : "2014-01-03 02:27:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418931219196547072",
  "text" : "Was outside for less than 10 minutes with the pup and couldn't feel hands or feet. Felt like I got back from 2 hours of skiing.",
  "id" : 418931219196547072,
  "created_at" : "2014-01-03 02:26:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/RmjVPUF7Xd",
      "expanded_url" : "http:\/\/www.thealmightyguru.com\/Pointless\/AnimalGroups.html",
      "display_url" : "thealmightyguru.com\/Pointless\/Anim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418880022183559168",
  "text" : "a herd of buffalo. a troop of buffalo. a GANG of BUFFALO. An Obstinancy Of Buffalo. http:\/\/t.co\/RmjVPUF7Xd",
  "id" : 418880022183559168,
  "created_at" : "2014-01-02 23:02:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "indices" : [ 3, 12 ],
      "id_str" : "516930319",
      "id" : 516930319
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 40, 54 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartCNY",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/4ugbpfQRQG",
      "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
      "display_url" : "buff.ly\/1fmRDF9"
    } ]
  },
  "geo" : { },
  "id_str" : "418867549208461312",
  "text" : "RT @IDEAcuse: Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 26, 40 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartCNY",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4ugbpfQRQG",
        "expanded_url" : "http:\/\/buff.ly\/1fmRDF9",
        "display_url" : "buff.ly\/1fmRDF9"
      } ]
    },
    "geo" : { },
    "id_str" : "418853487221690368",
    "text" : "Let's help our neighbors! @coworkbuffalo has a Kickstarter! Spread the word and support! http:\/\/t.co\/4ugbpfQRQG #StartCNY",
    "id" : 418853487221690368,
    "created_at" : "2014-01-02 21:17:07 +0000",
    "user" : {
      "name" : "IDEA",
      "screen_name" : "IDEAcuse",
      "protected" : false,
      "id_str" : "516930319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481275530570776576\/ayniykm7_normal.png",
      "id" : 516930319,
      "verified" : false
    }
  },
  "id" : 418867549208461312,
  "created_at" : "2014-01-02 22:13:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "gapingvoid",
      "screen_name" : "gapingvoid",
      "indices" : [ 28, 39 ],
      "id_str" : "72982024",
      "id" : 72982024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418864360102957057",
  "geo" : { },
  "id_str" : "418864614189699072",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael Looks like a @gapingvoid to me!",
  "id" : 418864614189699072,
  "in_reply_to_status_id" : 418864360102957057,
  "created_at" : "2014-01-02 22:01:20 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418844327066877953",
  "geo" : { },
  "id_str" : "418845101670944768",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents what an awesome venue. congrats again!!",
  "id" : 418845101670944768,
  "in_reply_to_status_id" : 418844327066877953,
  "created_at" : "2014-01-02 20:43:48 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 12, 16 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418836208077119489",
  "geo" : { },
  "id_str" : "418836499941961728",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried @rjs I have a ton of practice with this one. It's more like a 2.",
  "id" : 418836499941961728,
  "in_reply_to_status_id" : 418836208077119489,
  "created_at" : "2014-01-02 20:09:37 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty Crockski ",
      "screen_name" : "BettyCrockski",
      "indices" : [ 0, 14 ],
      "id_str" : "1486650266",
      "id" : 1486650266
    }, {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 15, 29 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 51, 65 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418794614078722050",
  "geo" : { },
  "id_str" : "418795165570977792",
  "in_reply_to_user_id" : 1486650266,
  "text" : "@BettyCrockski @edwardmichael will add to our list @coworkbuffalo...I also hope you don't get a C&amp;D for infringing on trademarks!",
  "id" : 418795165570977792,
  "in_reply_to_status_id" : 418794614078722050,
  "created_at" : "2014-01-02 17:25:22 +0000",
  "in_reply_to_screen_name" : "BettyCrockski",
  "in_reply_to_user_id_str" : "1486650266",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/9Zp3vT5g82",
      "expanded_url" : "http:\/\/kck.st\/18RQYKG",
      "display_url" : "kck.st\/18RQYKG"
    } ]
  },
  "geo" : { },
  "id_str" : "418784480115978240",
  "text" : "13 days, 96% there!! http:\/\/t.co\/9Zp3vT5g82",
  "id" : 418784480115978240,
  "created_at" : "2014-01-02 16:42:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Russell",
      "screen_name" : "bratschecody",
      "indices" : [ 0, 13 ],
      "id_str" : "85608393",
      "id" : 85608393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418534793689587712",
  "geo" : { },
  "id_str" : "418535056517255168",
  "in_reply_to_user_id" : 85608393,
  "text" : "@bratschecody I picked up an X100S for the SF trip...before that it's all iPhone. Quality difference is huge!",
  "id" : 418535056517255168,
  "in_reply_to_status_id" : 418534793689587712,
  "created_at" : "2014-01-02 00:11:48 +0000",
  "in_reply_to_screen_name" : "bratschecody",
  "in_reply_to_user_id_str" : "85608393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "Monads and Strife",
      "screen_name" : "Jonplussed",
      "indices" : [ 10, 21 ],
      "id_str" : "38408851",
      "id" : 38408851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418525354525855744",
  "geo" : { },
  "id_str" : "418525875106103296",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx @Jonplussed thanks! I wish I had some shots of people on top of that rock I took the shot from. 20' or so high boulders are fun :)",
  "id" : 418525875106103296,
  "in_reply_to_status_id" : 418525354525855744,
  "created_at" : "2014-01-01 23:35:19 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/mdxVPx70sc",
      "expanded_url" : "http:\/\/coworkbuffalo.com",
      "display_url" : "coworkbuffalo.com"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/tIlIaKWXRU",
      "expanded_url" : "https:\/\/qrush.exposure.so\/2013",
      "display_url" : "qrush.exposure.so\/2013"
    } ]
  },
  "geo" : { },
  "id_str" : "418524673177972737",
  "text" : "I really wish Chrome didn't suck on scrolling full-width images. http:\/\/t.co\/mdxVPx70sc, https:\/\/t.co\/tIlIaKWXRU are silky smooth in Safari.",
  "id" : 418524673177972737,
  "created_at" : "2014-01-01 23:30:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/O1yTXSZl6g",
      "expanded_url" : "http:\/\/www.nfl.com\/videos\/nfl-films-presents\/0ap2000000307714\/NFL-Films-Presents-Phish-and-Russell-Wilson",
      "display_url" : "nfl.com\/videos\/nfl-fil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418487651142885376",
  "text" : "RT @bquarant: \"I am not talking about Gamehendge on the NFL\" - http:\/\/t.co\/O1yTXSZl6g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/O1yTXSZl6g",
        "expanded_url" : "http:\/\/www.nfl.com\/videos\/nfl-films-presents\/0ap2000000307714\/NFL-Films-Presents-Phish-and-Russell-Wilson",
        "display_url" : "nfl.com\/videos\/nfl-fil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418487546234937344",
    "text" : "\"I am not talking about Gamehendge on the NFL\" - http:\/\/t.co\/O1yTXSZl6g",
    "id" : 418487546234937344,
    "created_at" : "2014-01-01 21:03:00 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 418487651142885376,
  "created_at" : "2014-01-01 21:03:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418480955901235200",
  "text" : "@juliepagano I just gave up and posted photos.",
  "id" : 418480955901235200,
  "created_at" : "2014-01-01 20:36:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/BeWedXQLrC",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kQFKtI6gn9Y",
      "display_url" : "youtube.com\/watch?v=kQFKtI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418469425981837314",
  "geo" : { },
  "id_str" : "418470953815777280",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV Chris' Argument Clinic? http:\/\/t.co\/BeWedXQLrC",
  "id" : 418470953815777280,
  "in_reply_to_status_id" : 418469425981837314,
  "created_at" : "2014-01-01 19:57:04 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418465796944187392",
  "text" : "Which has a longer line today? Colorado pot stores or the North Buffalo Popeye's?",
  "id" : 418465796944187392,
  "created_at" : "2014-01-01 19:36:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Handsome",
      "screen_name" : "Millennial_Dave",
      "indices" : [ 0, 16 ],
      "id_str" : "60185021",
      "id" : 60185021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/oRVpTv5hvC",
      "expanded_url" : "http:\/\/coffeescript.org\/",
      "display_url" : "coffeescript.org"
    } ]
  },
  "in_reply_to_status_id_str" : "418465322698412032",
  "geo" : { },
  "id_str" : "418465699112046592",
  "in_reply_to_user_id" : 60185021,
  "text" : "@Millennial_Dave CoffeeScript is much easier...need to still understand JS though. http:\/\/t.co\/oRVpTv5hvC",
  "id" : 418465699112046592,
  "in_reply_to_status_id" : 418465322698412032,
  "created_at" : "2014-01-01 19:36:12 +0000",
  "in_reply_to_screen_name" : "Millennial_Dave",
  "in_reply_to_user_id_str" : "60185021",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418408004438859776",
  "text" : "Happy \"I should probably update all of the \u00A9 notices day\" day!",
  "id" : 418408004438859776,
  "created_at" : "2014-01-01 15:46:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    }, {
      "name" : "Jake Goulding",
      "screen_name" : "JakeGoulding",
      "indices" : [ 15, 28 ],
      "id_str" : "197769225",
      "id" : 197769225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418185610722312192",
  "geo" : { },
  "id_str" : "418336989125963776",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents @JakeGoulding congrats!!!",
  "id" : 418336989125963776,
  "in_reply_to_status_id" : 418185610722312192,
  "created_at" : "2014-01-01 11:04:45 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
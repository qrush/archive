Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/WEnz9J5",
      "expanded_url" : "http:\/\/i.imgur.com\/kaLLY.gif",
      "display_url" : "i.imgur.com\/kaLLY.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "53650776886755329",
  "text" : "Current status: http:\/\/t.co\/WEnz9J5",
  "id" : 53650776886755329,
  "created_at" : "2011-04-01 02:51:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nik",
      "screen_name" : "nikz",
      "indices" : [ 0, 5 ],
      "id_str" : "4825681",
      "id" : 4825681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53586221527605248",
  "geo" : { },
  "id_str" : "53592139015262208",
  "in_reply_to_user_id" : 4825681,
  "text" : "@nikz @ra66I there's no 31st month stupid nonamericans :)",
  "id" : 53592139015262208,
  "in_reply_to_status_id" : 53586221527605248,
  "created_at" : "2011-03-31 22:58:56 +0000",
  "in_reply_to_screen_name" : "nikz",
  "in_reply_to_user_id_str" : "4825681",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mbta",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53587594897928192",
  "text" : "Crap, bought a #mbta linkpass ticket for april instead of putting it on my card. Is there any way to transfer it to the card?",
  "id" : 53587594897928192,
  "created_at" : "2011-03-31 22:40:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53461159575175168",
  "geo" : { },
  "id_str" : "53471431488581632",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius cool, i just can't let it get in the way of shipping ;)",
  "id" : 53471431488581632,
  "in_reply_to_status_id" : 53461159575175168,
  "created_at" : "2011-03-31 14:59:17 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    }, {
      "name" : "GemSummarizr",
      "screen_name" : "GemSummarizr",
      "indices" : [ 23, 36 ],
      "id_str" : "274213453",
      "id" : 274213453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53278691517677568",
  "geo" : { },
  "id_str" : "53461157461241856",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow can you turn @GemSummarizr off please?",
  "id" : 53461157461241856,
  "in_reply_to_status_id" : 53278691517677568,
  "created_at" : "2011-03-31 14:18:27 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53440987019743232",
  "geo" : { },
  "id_str" : "53448964955062272",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens include will mixin into the current module...require actually evals the file from disk. Try making your own module and see :)",
  "id" : 53448964955062272,
  "in_reply_to_status_id" : 53440987019743232,
  "created_at" : "2011-03-31 13:30:00 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53408866188275712",
  "geo" : { },
  "id_str" : "53448472447287296",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd in the emulator...are there any good guides on actually testing it?",
  "id" : 53448472447287296,
  "in_reply_to_status_id" : 53408866188275712,
  "created_at" : "2011-03-31 13:28:03 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Mullen",
      "screen_name" : "samullen",
      "indices" : [ 0, 9 ],
      "id_str" : "23062047",
      "id" : 23062047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53439237848186880",
  "geo" : { },
  "id_str" : "53448339798233088",
  "in_reply_to_user_id" : 23062047,
  "text" : "@samullen I probably just don't know the tools well enough yet, but I just want to get the game written and not waste time on other stuff",
  "id" : 53448339798233088,
  "in_reply_to_status_id" : 53439237848186880,
  "created_at" : "2011-03-31 13:27:31 +0000",
  "in_reply_to_screen_name" : "samullen",
  "in_reply_to_user_id_str" : "23062047",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Mullen",
      "screen_name" : "samullen",
      "indices" : [ 0, 9 ],
      "id_str" : "23062047",
      "id" : 23062047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53439237848186880",
  "geo" : { },
  "id_str" : "53447929582718977",
  "in_reply_to_user_id" : 23062047,
  "text" : "@samullen java. I had errors I couldn't debug btwn what mirah code I had and the .class files it produced.",
  "id" : 53447929582718977,
  "in_reply_to_status_id" : 53439237848186880,
  "created_at" : "2011-03-31 13:25:54 +0000",
  "in_reply_to_screen_name" : "samullen",
  "in_reply_to_user_id_str" : "23062047",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53322011174379520",
  "geo" : { },
  "id_str" : "53326610224517121",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike EVERYTHING YOU OWN IS NOW OUT OF FASHION",
  "id" : 53326610224517121,
  "in_reply_to_status_id" : 53322011174379520,
  "created_at" : "2011-03-31 05:23:49 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 42, 49 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53322192036958209",
  "geo" : { },
  "id_str" : "53325069333700608",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway did it by just tossing it on @heroku and using send_file :) http:\/\/sinatra.rubyforge.org\/api\/classes\/Sinatra\/Streaming.html",
  "id" : 53325069333700608,
  "in_reply_to_status_id" : 53322192036958209,
  "created_at" : "2011-03-31 05:17:41 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53324752726663168",
  "geo" : { },
  "id_str" : "53324960017547264",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub no, couldn't debug it well...just switched it to normal java. oh well, but gets the job done for this noob java dev",
  "id" : 53324960017547264,
  "in_reply_to_status_id" : 53324752726663168,
  "created_at" : "2011-03-31 05:17:15 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53324484526096384",
  "text" : "First playtest of the new android game on a real device! Went well, found some bugs but it's working!! Very excited.",
  "id" : 53324484526096384,
  "created_at" : "2011-03-31 05:15:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53322011174379520",
  "geo" : { },
  "id_str" : "53324352317435904",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike this is like dope wars...oh man",
  "id" : 53324352317435904,
  "in_reply_to_status_id" : 53322011174379520,
  "created_at" : "2011-03-31 05:14:50 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53321687005020160",
  "text" : "Got it by tossing it on my server, Content-Type: application\/vnd.android.package-archive does the trick (easy with sinatra!)",
  "id" : 53321687005020160,
  "created_at" : "2011-03-31 05:04:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53319353076158464",
  "text" : "Looks like I can transfer my .apk over bluetooth...that might work",
  "id" : 53319353076158464,
  "created_at" : "2011-03-31 04:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53319011219415040",
  "text" : "Can't get my Droid to connect to mount USB storage with OSX. Not sure if it's the off-brand USB charger I have or I'm just stupid.",
  "id" : 53319011219415040,
  "created_at" : "2011-03-31 04:53:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53209154852093952",
  "geo" : { },
  "id_str" : "53276029036400641",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow merged, thanks dude",
  "id" : 53276029036400641,
  "in_reply_to_status_id" : 53209154852093952,
  "created_at" : "2011-03-31 02:02:49 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53241495729344512",
  "geo" : { },
  "id_str" : "53257221731131393",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej seriously dude. I love nethack (6 ascensions) and DF blows my mind",
  "id" : 53257221731131393,
  "in_reply_to_status_id" : 53241495729344512,
  "created_at" : "2011-03-31 00:48:05 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53189896877256704",
  "geo" : { },
  "id_str" : "53196891265040384",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena whoa, i'm not going to yank gems willy-nilly. let's start a thread on help.rubygems.org can we can pull in Florian",
  "id" : 53196891265040384,
  "in_reply_to_status_id" : 53189896877256704,
  "created_at" : "2011-03-30 20:48:21 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Daigle",
      "screen_name" : "camerondaigle",
      "indices" : [ 0, 14 ],
      "id_str" : "14496815",
      "id" : 14496815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53186890093953024",
  "geo" : { },
  "id_str" : "53188373199855616",
  "in_reply_to_user_id" : 14496815,
  "text" : "@camerondaigle this is so much better than the `dicks` gem.",
  "id" : 53188373199855616,
  "in_reply_to_status_id" : 53186890093953024,
  "created_at" : "2011-03-30 20:14:31 +0000",
  "in_reply_to_screen_name" : "camerondaigle",
  "in_reply_to_user_id_str" : "14496815",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53115655041458176",
  "geo" : { },
  "id_str" : "53138159214661632",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow awesome, do it up!",
  "id" : 53138159214661632,
  "in_reply_to_status_id" : 53115655041458176,
  "created_at" : "2011-03-30 16:54:59 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53094738051612673",
  "geo" : { },
  "id_str" : "53103266380263424",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow ha, looks like someone has: https:\/\/github.com\/qrush\/gemwhisperer\/pull\/1\/files I need to evaluate this patch, you should too :)",
  "id" : 53103266380263424,
  "in_reply_to_status_id" : 53094738051612673,
  "created_at" : "2011-03-30 14:36:19 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52915140835819520",
  "geo" : { },
  "id_str" : "53085320022982656",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow if there anything I can do to help, bug me in #rubygems on freenode",
  "id" : 53085320022982656,
  "in_reply_to_status_id" : 52915140835819520,
  "created_at" : "2011-03-30 13:25:01 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crazy hen",
      "screen_name" : "angrysow",
      "indices" : [ 0, 9 ],
      "id_str" : "1550305392",
      "id" : 1550305392
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 31, 40 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52915140835819520",
  "geo" : { },
  "id_str" : "53085208626470912",
  "in_reply_to_user_id" : 8822042,
  "text" : "@angrysow found you! Let's fix @rubygems instead, the code is open at http:\/\/github.com\/qrush\/gemwhisperer",
  "id" : 53085208626470912,
  "in_reply_to_status_id" : 52915140835819520,
  "created_at" : "2011-03-30 13:24:34 +0000",
  "in_reply_to_screen_name" : "nerdfits",
  "in_reply_to_user_id_str" : "8822042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GemSummarizr",
      "screen_name" : "GemSummarizr",
      "indices" : [ 0, 13 ],
      "id_str" : "274213453",
      "id" : 274213453
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 68, 77 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53021189232267264",
  "geo" : { },
  "id_str" : "53074957311295488",
  "in_reply_to_user_id" : 274213453,
  "text" : "@GemSummarizr hi, who's running you? Can we just integrate into the @rubygems feed? Please dm me :)",
  "id" : 53074957311295488,
  "in_reply_to_status_id" : 53021189232267264,
  "created_at" : "2011-03-30 12:43:50 +0000",
  "in_reply_to_screen_name" : "GemSummarizr",
  "in_reply_to_user_id_str" : "274213453",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 65, 73 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52876900254752768",
  "geo" : { },
  "id_str" : "52878907086610435",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove :( have you read http:\/\/bit.ly\/hN0qdG ? We need some @evanphx optimization magic sprinkled in!",
  "id" : 52878907086610435,
  "in_reply_to_status_id" : 52876900254752768,
  "created_at" : "2011-03-29 23:44:48 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52872966123425792",
  "geo" : { },
  "id_str" : "52876773158957056",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety its gem plugin is broken :( gem plugins are dangerous. I defined a toplevel URL constant in an old gemcutter version once, lol",
  "id" : 52876773158957056,
  "in_reply_to_status_id" : 52872966123425792,
  "created_at" : "2011-03-29 23:36:19 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pusher (now @pusher)",
      "screen_name" : "pusherapp",
      "indices" : [ 92, 102 ],
      "id_str" : "444855740",
      "id" : 444855740
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 116, 123 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 124, 131 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52858606441340929",
  "text" : "Is it hard to get into the Android C2DM program? Should I not bother and use something like @pusherapp instead? \/cc @zapnap @bryanl",
  "id" : 52858606441340929,
  "created_at" : "2011-03-29 22:24:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52848446033498112",
  "geo" : { },
  "id_str" : "52848656096825344",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove jeeesus chriist",
  "id" : 52848656096825344,
  "in_reply_to_status_id" : 52848446033498112,
  "created_at" : "2011-03-29 21:44:36 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 0, 12 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52845343246794752",
  "geo" : { },
  "id_str" : "52845873415208961",
  "in_reply_to_user_id" : 6556972,
  "text" : "@techpickles I DISAGREE WITH SAID OPINIONS",
  "id" : 52845873415208961,
  "in_reply_to_status_id" : 52845343246794752,
  "created_at" : "2011-03-29 21:33:32 +0000",
  "in_reply_to_screen_name" : "techpickles",
  "in_reply_to_user_id_str" : "6556972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 7, 17 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52842781030363136",
  "geo" : { },
  "id_str" : "52843087948562432",
  "in_reply_to_user_id" : 15359408,
  "text" : "@ra66i @jbarnette can we have this discussion on the gemcutter mailing list instead?",
  "id" : 52843087948562432,
  "in_reply_to_status_id" : 52842781030363136,
  "created_at" : "2011-03-29 21:22:28 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52841227254632448",
  "geo" : { },
  "id_str" : "52841382632624128",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette seriously :(",
  "id" : 52841382632624128,
  "in_reply_to_status_id" : 52841227254632448,
  "created_at" : "2011-03-29 21:15:42 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    }, {
      "name" : "Mic Pringle",
      "screen_name" : "micpringle",
      "indices" : [ 14, 25 ],
      "id_str" : "154493778",
      "id" : 154493778
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 50, 60 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52716944062812160",
  "geo" : { },
  "id_str" : "52719229018980354",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin @micpringle is this a service using @gemcutter's webhooks? I'd love to talk to whoever's behind it",
  "id" : 52719229018980354,
  "in_reply_to_status_id" : 52716944062812160,
  "created_at" : "2011-03-29 13:10:18 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52613637063458816",
  "geo" : { },
  "id_str" : "52714690966597632",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius yes, but a ways to go. Headed back to pure java. Half of it is probably that I haven't done java out of Eclipse due to school :(",
  "id" : 52714690966597632,
  "in_reply_to_status_id" : 52613637063458816,
  "created_at" : "2011-03-29 12:52:16 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Peruzzini",
      "screen_name" : "KeightP",
      "indices" : [ 0, 8 ],
      "id_str" : "18247553",
      "id" : 18247553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52590004584718336",
  "geo" : { },
  "id_str" : "52601000527265792",
  "in_reply_to_user_id" : 18247553,
  "text" : "@KeightP did you smuggle yuengling into MA from NY? Can't find it anywhere and its my favorite :(",
  "id" : 52601000527265792,
  "in_reply_to_status_id" : 52590004584718336,
  "created_at" : "2011-03-29 05:20:30 +0000",
  "in_reply_to_screen_name" : "KeightP",
  "in_reply_to_user_id_str" : "18247553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seivan Heidari",
      "screen_name" : "Seivanheidari",
      "indices" : [ 0, 14 ],
      "id_str" : "93118049",
      "id" : 93118049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52579079395880960",
  "geo" : { },
  "id_str" : "52584733217001472",
  "in_reply_to_user_id" : 93118049,
  "text" : "@Seivanheidari not on android, bro",
  "id" : 52584733217001472,
  "in_reply_to_status_id" : 52579079395880960,
  "created_at" : "2011-03-29 04:15:52 +0000",
  "in_reply_to_screen_name" : "Seivanheidari",
  "in_reply_to_user_id_str" : "93118049",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52563400118648832",
  "geo" : { },
  "id_str" : "52565908278882305",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub also, it's not TOO bad given i don't know the APIs for shit",
  "id" : 52565908278882305,
  "in_reply_to_status_id" : 52563400118648832,
  "created_at" : "2011-03-29 03:01:03 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52563400118648832",
  "geo" : { },
  "id_str" : "52565863961862144",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub Actually, I figured it out: http:\/\/code.google.com\/p\/android\/issues\/detail?id=7850",
  "id" : 52565863961862144,
  "in_reply_to_status_id" : 52563400118648832,
  "created_at" : "2011-03-29 03:00:53 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52561208859037696",
  "text" : "Yes, Eclipse freezing on autocomplete is actually WAY BETTER. I LOVE THIS.",
  "id" : 52561208859037696,
  "created_at" : "2011-03-29 02:42:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52558497732235264",
  "text" : "Going to have to give up on Mirah. No way to debug this shit, terrible error messages. That was short.",
  "id" : 52558497732235264,
  "created_at" : "2011-03-29 02:31:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52548805878497280",
  "text" : "GNOME. CHOMPSKI. http:\/\/www.youtube.com\/watch?v=8mjky2QE9DA",
  "id" : 52548805878497280,
  "created_at" : "2011-03-29 01:53:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52519481037160448",
  "text" : "% adb lolcat droid21 (i'm so glad this works)",
  "id" : 52519481037160448,
  "created_at" : "2011-03-28 23:56:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 7, 18 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52484840980889600",
  "geo" : { },
  "id_str" : "52484939177926657",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @thoughtbot we probably need some screenshots in that readme",
  "id" : 52484939177926657,
  "in_reply_to_status_id" : 52484840980889600,
  "created_at" : "2011-03-28 21:39:19 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52484465863294978",
  "geo" : { },
  "id_str" : "52484840980889600",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft don't forget http:\/\/github.com\/thoughtbot\/flutie",
  "id" : 52484840980889600,
  "in_reply_to_status_id" : 52484465863294978,
  "created_at" : "2011-03-28 21:38:55 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52378016650764288",
  "geo" : { },
  "id_str" : "52379071899893761",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba as of late, http:\/\/dnsimple.com has been awesome.",
  "id" : 52379071899893761,
  "in_reply_to_status_id" : 52378016650764288,
  "created_at" : "2011-03-28 14:38:38 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 3, 15 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52376380318552065",
  "text" : "RT @fredyatesiv: want to be an apprentice at thoughtbot? we're looking for designers and developers http:\/\/cl.ly\/5Z75",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "52375412851998720",
    "text" : "want to be an apprentice at thoughtbot? we're looking for designers and developers http:\/\/cl.ly\/5Z75",
    "id" : 52375412851998720,
    "created_at" : "2011-03-28 14:24:06 +0000",
    "user" : {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "protected" : false,
      "id_str" : "11886642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000601269119\/e0edad3585e85a968b3840e2ccd0ace5_normal.jpeg",
      "id" : 11886642,
      "verified" : false
    }
  },
  "id" : 52376380318552065,
  "created_at" : "2011-03-28 14:27:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Conway",
      "screen_name" : "mattonrails",
      "indices" : [ 3, 15 ],
      "id_str" : "419811835",
      "id" : 419811835
    }, {
      "name" : "Cameron Daigle",
      "screen_name" : "camerondaigle",
      "indices" : [ 56, 70 ],
      "id_str" : "14496815",
      "id" : 14496815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/vv4Q6pV",
      "expanded_url" : "http:\/\/textaligncentaur.com\/",
      "display_url" : "textaligncentaur.com"
    } ]
  },
  "geo" : { },
  "id_str" : "52368605022662657",
  "text" : "RT @mattonrails: http:\/\/t.co\/vv4Q6pV\n\nBrought to you by @camerondaigle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cameron Daigle",
        "screen_name" : "camerondaigle",
        "indices" : [ 39, 53 ],
        "id_str" : "14496815",
        "id" : 14496815
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 19 ],
        "url" : "http:\/\/t.co\/vv4Q6pV",
        "expanded_url" : "http:\/\/textaligncentaur.com\/",
        "display_url" : "textaligncentaur.com"
      } ]
    },
    "geo" : { },
    "id_str" : "52367914757652480",
    "text" : "http:\/\/t.co\/vv4Q6pV\n\nBrought to you by @camerondaigle",
    "id" : 52367914757652480,
    "created_at" : "2011-03-28 13:54:18 +0000",
    "user" : {
      "name" : "Matthew Conway",
      "screen_name" : "mattreduce",
      "protected" : false,
      "id_str" : "33829595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465275543697383424\/CkDLx3Yc_normal.jpeg",
      "id" : 33829595,
      "verified" : false
    }
  },
  "id" : 52368605022662657,
  "created_at" : "2011-03-28 13:57:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52367022079746048",
  "text" : "Also, two keystokes to URL completion sucks in the URL bar. (Tab, Enter instead of just Enter) this isn't hard guys :(",
  "id" : 52367022079746048,
  "created_at" : "2011-03-28 13:50:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52366727945781248",
  "text" : "Back to Chrome from FF4 this week No fast way to private mode and the search bar hates coders (try searching for methods or modules)",
  "id" : 52366727945781248,
  "created_at" : "2011-03-28 13:49:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 0, 9 ],
      "id_str" : "717973",
      "id" : 717973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52362714886053888",
  "geo" : { },
  "id_str" : "52365620079099904",
  "in_reply_to_user_id" : 717973,
  "text" : "@ceejayoz ahh. Derp.",
  "id" : 52365620079099904,
  "in_reply_to_status_id" : 52362714886053888,
  "created_at" : "2011-03-28 13:45:11 +0000",
  "in_reply_to_screen_name" : "ceejayoz",
  "in_reply_to_user_id_str" : "717973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52342016838873088",
  "text" : "$10\/hr to run a dedicated instance on ec2? Does that seem way overpriced to anyone else?",
  "id" : 52342016838873088,
  "created_at" : "2011-03-28 12:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "history",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52227917471682560",
  "geo" : { },
  "id_str" : "52237628875079681",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej NO GUTS, NO GATORS #history",
  "id" : 52237628875079681,
  "in_reply_to_status_id" : 52227917471682560,
  "created_at" : "2011-03-28 05:16:35 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freddie Wong",
      "screen_name" : "fwong",
      "indices" : [ 76, 82 ],
      "id_str" : "18963070",
      "id" : 18963070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52233695129645056",
  "text" : "http:\/\/vimeo.com\/19037620 makes me want to play Half-Life SO BAD right now. @fwong have you seen this!?",
  "id" : 52233695129645056,
  "created_at" : "2011-03-28 05:00:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carmelo Briones",
      "screen_name" : "ryanbriones",
      "indices" : [ 0, 12 ],
      "id_str" : "6144652",
      "id" : 6144652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52230219213443072",
  "geo" : { },
  "id_str" : "52233603479908353",
  "in_reply_to_user_id" : 6144652,
  "text" : "@ryanbriones THIS IS AWESOME.",
  "id" : 52233603479908353,
  "in_reply_to_status_id" : 52230219213443072,
  "created_at" : "2011-03-28 05:00:36 +0000",
  "in_reply_to_screen_name" : "ryanbriones",
  "in_reply_to_user_id_str" : "6144652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52217898923593729",
  "geo" : { },
  "id_str" : "52218287198711809",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight yes? not sure what you're asking.",
  "id" : 52218287198711809,
  "in_reply_to_status_id" : 52217898923593729,
  "created_at" : "2011-03-28 03:59:44 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52217792505712640",
  "text" : "I can't imagine how much RIT pays for the bandwidth on http:\/\/people.rit.edu\/~bss6378\/instantCSI\/, but I hope it's a lot.",
  "id" : 52217792505712640,
  "created_at" : "2011-03-28 03:57:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 77, 85 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52202213489131520",
  "geo" : { },
  "id_str" : "52217154346565632",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd no idea yet, but it compiles to jvm bytecode so it can't be far off? \/cc @headius",
  "id" : 52217154346565632,
  "in_reply_to_status_id" : 52202213489131520,
  "created_at" : "2011-03-28 03:55:14 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52205391911714816",
  "geo" : { },
  "id_str" : "52207992527007744",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything seriously dude. going full out sinatra tonight, it's fantastic. no UI for this app, so fuck it",
  "id" : 52207992527007744,
  "in_reply_to_status_id" : 52205391911714816,
  "created_at" : "2011-03-28 03:18:50 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52203002068606977",
  "text" : "lexical error: invalid char in json text.\n                                              LOL\n                            (right here) ------^",
  "id" : 52203002068606977,
  "created_at" : "2011-03-28 02:59:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kevinconroy",
      "screen_name" : "kevinconroy",
      "indices" : [ 0, 12 ],
      "id_str" : "8474282",
      "id" : 8474282
    }, {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 13, 19 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52193620970848256",
  "geo" : { },
  "id_str" : "52195364383625216",
  "in_reply_to_user_id" : 8474282,
  "text" : "@kevinconroy @dozba it only gets harder to do that :( rubygems in 1.9+ makes it rough",
  "id" : 52195364383625216,
  "in_reply_to_status_id" : 52193620970848256,
  "created_at" : "2011-03-28 02:28:39 +0000",
  "in_reply_to_screen_name" : "kevinconroy",
  "in_reply_to_user_id_str" : "8474282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Southard",
      "screen_name" : "southard",
      "indices" : [ 0, 9 ],
      "id_str" : "9890982",
      "id" : 9890982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52187876963778560",
  "geo" : { },
  "id_str" : "52194577347649536",
  "in_reply_to_user_id" : 9890982,
  "text" : "@southard definitely not. we have several mirrors combing the site, and plenty of services that use the webhooks to suck down gems",
  "id" : 52194577347649536,
  "in_reply_to_status_id" : 52187876963778560,
  "created_at" : "2011-03-28 02:25:31 +0000",
  "in_reply_to_screen_name" : "southard",
  "in_reply_to_user_id_str" : "9890982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52158067218989056",
  "text" : "Simpsons just mega-trolled me when they played the Futurama theme song at the start of the episode :(",
  "id" : 52158067218989056,
  "created_at" : "2011-03-28 00:00:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52147231318478848",
  "text" : "Got my first button hooked up, starting to get a sense of how Mirah handles types. not so bad!",
  "id" : 52147231318478848,
  "created_at" : "2011-03-27 23:17:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52146218217906176",
  "geo" : { },
  "id_str" : "52146360895537153",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath yes, they fucked that up for sure :( google will fix itself eventually",
  "id" : 52146360895537153,
  "in_reply_to_status_id" : 52146218217906176,
  "created_at" : "2011-03-27 23:13:55 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52144744003928064",
  "geo" : { },
  "id_str" : "52145545279574018",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath what? they're way more accessible now...especially the URLs. whats the problem with them?",
  "id" : 52145545279574018,
  "in_reply_to_status_id" : 52144744003928064,
  "created_at" : "2011-03-27 23:10:41 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52141332424175617",
  "geo" : { },
  "id_str" : "52141852140380160",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon :set relativenum is awesome, in the latest vim release",
  "id" : 52141852140380160,
  "in_reply_to_status_id" : 52141332424175617,
  "created_at" : "2011-03-27 22:56:00 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tal Atlas",
      "screen_name" : "Koalemos",
      "indices" : [ 0, 9 ],
      "id_str" : "800568",
      "id" : 800568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "52133847743209472",
  "geo" : { },
  "id_str" : "52134241902931968",
  "in_reply_to_user_id" : 800568,
  "text" : "@Koalemos http:\/\/mirah.org + https:\/\/github.com\/mirah\/pindah",
  "id" : 52134241902931968,
  "in_reply_to_status_id" : 52133847743209472,
  "created_at" : "2011-03-27 22:25:46 +0000",
  "in_reply_to_screen_name" : "Koalemos",
  "in_reply_to_user_id_str" : "800568",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52133116541808640",
  "text" : "Well, that was easy. Can my app be done yet? https:\/\/img.skitch.com\/20110328-dekteppnppau8a4ihk7n5a9bsx.png",
  "id" : 52133116541808640,
  "created_at" : "2011-03-27 22:21:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52127043328032768",
  "text" : "Oh, nice! https:\/\/github.com\/mirah\/pindah",
  "id" : 52127043328032768,
  "created_at" : "2011-03-27 21:57:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52123682147016704",
  "text" : "Kind of blowing my mind that you can install Mirah with RubyGems. BOOM.",
  "id" : 52123682147016704,
  "created_at" : "2011-03-27 21:43:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 3, 13 ],
      "id_str" : "14253068",
      "id" : 14253068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52007502568624129",
  "text" : "RT @mfeathers: ALL HOPE ABANDON, YE WHO ENTER HERE http:\/\/amzn.to\/f65wx2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51995277606928384",
    "text" : "ALL HOPE ABANDON, YE WHO ENTER HERE http:\/\/amzn.to\/f65wx2",
    "id" : 51995277606928384,
    "created_at" : "2011-03-27 13:13:34 +0000",
    "user" : {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "protected" : false,
      "id_str" : "14253068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540680066460434432\/K2Jgz4OQ_normal.jpeg",
      "id" : 14253068,
      "verified" : false
    }
  },
  "id" : 52007502568624129,
  "created_at" : "2011-03-27 14:02:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "52004639972925440",
  "text" : "This was in Boston!? Bummed I missed this. http:\/\/akshat.posterous.com\/patio11-says-hello-ladies",
  "id" : 52004639972925440,
  "created_at" : "2011-03-27 13:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Rudenberg",
      "screen_name" : "titanous",
      "indices" : [ 0, 9 ],
      "id_str" : "24187338",
      "id" : 24187338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51278924658905088",
  "geo" : { },
  "id_str" : "51998261694840832",
  "in_reply_to_user_id" : 24187338,
  "text" : "@titanous what browser?",
  "id" : 51998261694840832,
  "in_reply_to_status_id" : 51278924658905088,
  "created_at" : "2011-03-27 13:25:26 +0000",
  "in_reply_to_screen_name" : "titanous",
  "in_reply_to_user_id_str" : "24187338",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51840130830434304",
  "geo" : { },
  "id_str" : "51841474832244736",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant also, lovers gonna love",
  "id" : 51841474832244736,
  "in_reply_to_status_id" : 51840130830434304,
  "created_at" : "2011-03-27 03:02:25 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51840130830434304",
  "geo" : { },
  "id_str" : "51841424244736000",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant hater? You didn't come out tonight, weak",
  "id" : 51841424244736000,
  "in_reply_to_status_id" : 51840130830434304,
  "created_at" : "2011-03-27 03:02:13 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 0, 5 ],
      "id_str" : "1465521",
      "id" : 1465521
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 6, 13 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 88, 102 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51814156629848064",
  "geo" : { },
  "id_str" : "51815160599425024",
  "in_reply_to_user_id" : 1465521,
  "text" : "@r38y @elight I've spent too much time dealing with mongoid's fucked up scopes :( Also, @joshuaclayton's faststep looks promising",
  "id" : 51815160599425024,
  "in_reply_to_status_id" : 51814156629848064,
  "created_at" : "2011-03-27 01:17:51 +0000",
  "in_reply_to_screen_name" : "R38Y",
  "in_reply_to_user_id_str" : "1465521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 8, 13 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51812172992495616",
  "geo" : { },
  "id_str" : "51813846540746752",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @r38y just use the straight up mongo ruby driver if you can. Much easier, and you'll actually learn what it's doing",
  "id" : 51813846540746752,
  "in_reply_to_status_id" : 51812172992495616,
  "created_at" : "2011-03-27 01:12:38 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51809819493015552",
  "text" : "If I had to pick between the green line arriving on time and running over college kids carrying racks of beer over the tracks, well, guess.",
  "id" : 51809819493015552,
  "created_at" : "2011-03-27 00:56:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 3, 15 ],
      "id_str" : "15294983",
      "id" : 15294983
    }, {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 17, 24 ],
      "id_str" : "623223",
      "id" : 623223
    }, {
      "name" : "Wyatt Greene",
      "screen_name" : "techiferous",
      "indices" : [ 25, 37 ],
      "id_str" : "44238666",
      "id" : 44238666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51809545890181120",
  "text" : "RT @doctorzaius: @kbrock @techiferous There may be 7x as many Java jobs as Ruby, but you have to write 7x as much code and need 7x as ma ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keenan Brock",
        "screen_name" : "kbrock",
        "indices" : [ 0, 7 ],
        "id_str" : "623223",
        "id" : 623223
      }, {
        "name" : "Wyatt Greene",
        "screen_name" : "techiferous",
        "indices" : [ 8, 20 ],
        "id_str" : "44238666",
        "id" : 44238666
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "51467966411321344",
    "geo" : { },
    "id_str" : "51789453408223232",
    "in_reply_to_user_id" : 623223,
    "text" : "@kbrock @techiferous There may be 7x as many Java jobs as Ruby, but you have to write 7x as much code and need 7x as many people to do it.",
    "id" : 51789453408223232,
    "in_reply_to_status_id" : 51467966411321344,
    "created_at" : "2011-03-26 23:35:42 +0000",
    "in_reply_to_screen_name" : "kbrock",
    "in_reply_to_user_id_str" : "623223",
    "user" : {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "protected" : false,
      "id_str" : "15294983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438349677797203968\/NC9QqBLh_normal.jpeg",
      "id" : 15294983,
      "verified" : false
    }
  },
  "id" : 51809545890181120,
  "created_at" : "2011-03-27 00:55:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51807689789026304",
  "text" : "Heading out to the http:\/\/pbb.fm show! Any boston folks up for drinks after?",
  "id" : 51807689789026304,
  "created_at" : "2011-03-27 00:48:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ridgeway",
      "screen_name" : "Ang3lFir3",
      "indices" : [ 0, 10 ],
      "id_str" : "7792122",
      "id" : 7792122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51391854196953088",
  "geo" : { },
  "id_str" : "51393306504085504",
  "in_reply_to_user_id" : 7792122,
  "text" : "@Ang3lFir3 i find that post accurate, maybe a bit overstated (and with terrible metaphors). it's fine to have opinions, ffs",
  "id" : 51393306504085504,
  "in_reply_to_status_id" : 51391854196953088,
  "created_at" : "2011-03-25 21:21:33 +0000",
  "in_reply_to_screen_name" : "Ang3lFir3",
  "in_reply_to_user_id_str" : "7792122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 19, 30 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51372183838138369",
  "text" : "Current outside-of-@thoughtbot music status: http:\/\/is.gd\/gOAeqM",
  "id" : 51372183838138369,
  "created_at" : "2011-03-25 19:57:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Problem",
      "screen_name" : "BonzoESC",
      "indices" : [ 0, 9 ],
      "id_str" : "7865582",
      "id" : 7865582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51130875605299200",
  "geo" : { },
  "id_str" : "51273645020037120",
  "in_reply_to_user_id" : 7865582,
  "text" : "@BonzoESC pretty sure none of the crew is, not sure about alums",
  "id" : 51273645020037120,
  "in_reply_to_status_id" : 51130875605299200,
  "created_at" : "2011-03-25 13:26:04 +0000",
  "in_reply_to_screen_name" : "BonzoESC",
  "in_reply_to_user_id_str" : "7865582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51122412678426624",
  "geo" : { },
  "id_str" : "51128463435894784",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej the authorization example looks terrifying. Would be fun to hook this up to cucumber though.",
  "id" : 51128463435894784,
  "in_reply_to_status_id" : 51122412678426624,
  "created_at" : "2011-03-25 03:49:10 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51112809899102208",
  "text" : "Downloading Swarm, played it at #pax and sucked at it. ROUND 2 START!",
  "id" : 51112809899102208,
  "created_at" : "2011-03-25 02:46:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 3, 10 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 35, 44 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51112471368433664",
  "text" : "RT @jyurek: Seriously impressed by @dnsimple.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DNSimple",
        "screen_name" : "dnsimple",
        "indices" : [ 23, 32 ],
        "id_str" : "148198686",
        "id" : 148198686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "51017274978598913",
    "text" : "Seriously impressed by @dnsimple.",
    "id" : 51017274978598913,
    "created_at" : "2011-03-24 20:27:20 +0000",
    "user" : {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "protected" : false,
      "id_str" : "6505422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/26559072\/498945207_94895e9527_s_normal.jpg",
      "id" : 6505422,
      "verified" : false
    }
  },
  "id" : 51112471368433664,
  "created_at" : "2011-03-25 02:45:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51104130680360960",
  "geo" : { },
  "id_str" : "51112198155677696",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith what if I build an app to share photo sharing apps?",
  "id" : 51112198155677696,
  "in_reply_to_status_id" : 51104130680360960,
  "created_at" : "2011-03-25 02:44:32 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Yoho",
      "screen_name" : "mattyoho",
      "indices" : [ 0, 9 ],
      "id_str" : "12251322",
      "id" : 12251322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51060977248108544",
  "geo" : { },
  "id_str" : "51061611347185664",
  "in_reply_to_user_id" : 12251322,
  "text" : "@mattyoho protovis, it's delightful",
  "id" : 51061611347185664,
  "in_reply_to_status_id" : 51060977248108544,
  "created_at" : "2011-03-24 23:23:31 +0000",
  "in_reply_to_screen_name" : "mattyoho",
  "in_reply_to_user_id_str" : "12251322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51055309313159168",
  "text" : "Sperm donor ads on train, egg donor ads on the platform. Not sure why I find this so amusing.",
  "id" : 51055309313159168,
  "created_at" : "2011-03-24 22:58:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pete higgins",
      "screen_name" : "pete_higgins",
      "indices" : [ 0, 13 ],
      "id_str" : "216806575",
      "id" : 216806575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50976165489422336",
  "geo" : { },
  "id_str" : "50976371832393728",
  "in_reply_to_user_id" : 216806575,
  "text" : "@pete_higgins when i launched the site, under a minute, grew to around 95-100 seconds until the patch",
  "id" : 50976371832393728,
  "in_reply_to_status_id" : 50976165489422336,
  "created_at" : "2011-03-24 17:44:48 +0000",
  "in_reply_to_screen_name" : "pete_higgins",
  "in_reply_to_user_id_str" : "216806575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50975820306583552",
  "text" : "Watching Ruby on Ales: http:\/\/www.justin.tv\/confreaks#\/w\/1001755984",
  "id" : 50975820306583552,
  "created_at" : "2011-03-24 17:42:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50674279381082112",
  "text" : "They're setting up some fancy lights in the office...reminiscing of good times w\/ @jroach128 romping around http:\/\/is.gd\/BxI3VK",
  "id" : 50674279381082112,
  "created_at" : "2011-03-23 21:44:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 12, 16 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50638446263410688",
  "geo" : { },
  "id_str" : "50641553156345856",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler @dhh this is all conjecture. as a recent grad I can say I did learn the fundamentals in school, the \"craft\" only by coding a LOT",
  "id" : 50641553156345856,
  "in_reply_to_status_id" : 50638446263410688,
  "created_at" : "2011-03-23 19:34:21 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50630750873198593",
  "geo" : { },
  "id_str" : "50631272606859264",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic check your \/etc\/hosts. I bet there's a surprise there waiting for you!",
  "id" : 50631272606859264,
  "in_reply_to_status_id" : 50630750873198593,
  "created_at" : "2011-03-23 18:53:30 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50630750873198593",
  "geo" : { },
  "id_str" : "50631085494767616",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic it's fine here, I haven't gotten any pingdom alerts",
  "id" : 50631085494767616,
  "in_reply_to_status_id" : 50630750873198593,
  "created_at" : "2011-03-23 18:52:46 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50627598790832129",
  "text" : "Current status: http:\/\/www.antilabelblog.com\/wp-content\/uploads\/2008\/05\/chessboxing4.jpg",
  "id" : 50627598790832129,
  "created_at" : "2011-03-23 18:38:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 112, 122 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50611380532948993",
  "text" : "Re: my last tweet, this means it'll take ~15 seconds for your new gem to be ready for download after pushing to @gemcutter. Woot!",
  "id" : 50611380532948993,
  "created_at" : "2011-03-23 17:34:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 5, 15 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 44, 52 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50610279209369600",
  "text" : "EPIC @gemcutter INDEX SPEED BOOST thanks to @evanphx! https:\/\/groups.google.com\/d\/msg\/gemcutter\/yCcY-NZNyxM\/hMcq8JlqBvMJ",
  "id" : 50610279209369600,
  "created_at" : "2011-03-23 17:30:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50574547744849921",
  "geo" : { },
  "id_str" : "50575571561881601",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg i...i'll do this for money",
  "id" : 50575571561881601,
  "in_reply_to_status_id" : 50574547744849921,
  "created_at" : "2011-03-23 15:12:10 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50377180009598976",
  "text" : "I may not use PHP, but this deserves some respect. http:\/\/is.gd\/jXUlDU",
  "id" : 50377180009598976,
  "created_at" : "2011-03-23 02:03:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50315044977770496",
  "geo" : { },
  "id_str" : "50324480001720320",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv maybe you shouldn't pick Easy all the time",
  "id" : 50324480001720320,
  "in_reply_to_status_id" : 50315044977770496,
  "created_at" : "2011-03-22 22:34:25 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50265554212237312",
  "geo" : { },
  "id_str" : "50266445472468992",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape projects can enable pledgie, iirc",
  "id" : 50266445472468992,
  "in_reply_to_status_id" : 50265554212237312,
  "created_at" : "2011-03-22 18:43:49 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50240333719674880",
  "text" : "Very sick of GMail being so slow :(",
  "id" : 50240333719674880,
  "created_at" : "2011-03-22 17:00:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 36, 46 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50205838853423104",
  "text" : "Posted a quick status message about @gemcutter's queue: https:\/\/groups.google.com\/forum\/?hl=en_US#!topic\/gemcutter\/yCcY-NZNyxM",
  "id" : 50205838853423104,
  "created_at" : "2011-03-22 14:42:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50194664027983872",
  "text" : "Going to try Firefox 4 again. Changing accessibility.typeaheadfind.flashBar to 1 is much better (not sure why it was zero anyway)",
  "id" : 50194664027983872,
  "created_at" : "2011-03-22 13:58:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gallagher",
      "screen_name" : "necolas",
      "indices" : [ 98, 106 ],
      "id_str" : "24974216",
      "id" : 24974216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50192710035980288",
  "text" : "The data visualization side of my brain just imploded with awesome. http:\/\/glow.mozilla.org\/ (via @necolas)",
  "id" : 50192710035980288,
  "created_at" : "2011-03-22 13:50:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "50041855651495936",
  "text" : "Oh no, I need to transfer a large file to a friend! Time to create a startup to do this, since NO ONE ELSE EVER IS DOING THIS.",
  "id" : 50041855651495936,
  "created_at" : "2011-03-22 03:51:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "50014960910213121",
  "geo" : { },
  "id_str" : "50016875681296384",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton maybe it's time to delete some tests",
  "id" : 50016875681296384,
  "in_reply_to_status_id" : 50014960910213121,
  "created_at" : "2011-03-22 02:12:07 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49930103005773824",
  "text" : "BRENNER!!!! http:\/\/www.ritathletics.com\/news\/2011\/3\/21\/MHOCKEY_0321111618.aspx",
  "id" : 49930103005773824,
  "created_at" : "2011-03-21 20:27:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RIT Sports Info",
      "screen_name" : "RITsports",
      "indices" : [ 3, 13 ],
      "id_str" : "44440509",
      "id" : 44440509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "RITNews",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49930026673651712",
  "text" : "RT @RITsports: #RIT junior forward Tyler Brenner signs professional contract with the NHL's Toronto Maple Leafs. http:\/\/bit.ly\/gnJ2fJ #R ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RIT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "RITNews",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "49928302772764673",
    "text" : "#RIT junior forward Tyler Brenner signs professional contract with the NHL's Toronto Maple Leafs. http:\/\/bit.ly\/gnJ2fJ #RITNews.",
    "id" : 49928302772764673,
    "created_at" : "2011-03-21 20:20:09 +0000",
    "user" : {
      "name" : "RIT Sports Info",
      "screen_name" : "RITsports",
      "protected" : false,
      "id_str" : "44440509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790549257\/RITEMB2L_normal.jpg",
      "id" : 44440509,
      "verified" : false
    }
  },
  "id" : 49930026673651712,
  "created_at" : "2011-03-21 20:27:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49881099165372416",
  "text" : "I'm so glad this domain exists: http:\/\/www.shitcrunch.com\/",
  "id" : 49881099165372416,
  "created_at" : "2011-03-21 17:12:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49864078478422016",
  "text" : "Does anyone hate \"Redirect notices\" ? I KNOW I'M LEAVING YOUR SITE, THAT'S HOW THE INTERNET WORKS",
  "id" : 49864078478422016,
  "created_at" : "2011-03-21 16:04:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49859192323969025",
  "text" : "Just signed up for BarCampBoston 6! Pumped! http:\/\/barcampboston6.eventbrite.com\/",
  "id" : 49859192323969025,
  "created_at" : "2011-03-21 15:45:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brown",
      "screen_name" : "jeremyb",
      "indices" : [ 0, 8 ],
      "id_str" : "4373521",
      "id" : 4373521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49825853617610752",
  "geo" : { },
  "id_str" : "49826438500724736",
  "in_reply_to_user_id" : 4373521,
  "text" : "@jeremyb also, if you can't run their projects (given any lang), isn't that their fault for not providing the right documentation\/readme?",
  "id" : 49826438500724736,
  "in_reply_to_status_id" : 49825853617610752,
  "created_at" : "2011-03-21 13:35:23 +0000",
  "in_reply_to_screen_name" : "jeremyb",
  "in_reply_to_user_id_str" : "4373521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brown",
      "screen_name" : "jeremyb",
      "indices" : [ 0, 8 ],
      "id_str" : "4373521",
      "id" : 4373521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49825132373483520",
  "geo" : { },
  "id_str" : "49825492160880640",
  "in_reply_to_user_id" : 4373521,
  "text" : "@jeremyb mostly the first. Use the best tool for the job. Fundamentals are important though ;)",
  "id" : 49825492160880640,
  "in_reply_to_status_id" : 49825132373483520,
  "created_at" : "2011-03-21 13:31:37 +0000",
  "in_reply_to_screen_name" : "jeremyb",
  "in_reply_to_user_id_str" : "4373521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "mkdir -- -rf",
      "screen_name" : "baroquebobcat",
      "indices" : [ 66, 80 ],
      "id_str" : "14247442",
      "id" : 14247442
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 84, 92 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49673725376872448",
  "geo" : { },
  "id_str" : "49825238061551616",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape mirah looks really neat, saw some demos at #mwrc. Bug @baroquebobcat or @headius if you want to know more :)",
  "id" : 49825238061551616,
  "in_reply_to_status_id" : 49673725376872448,
  "created_at" : "2011-03-21 13:30:37 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brown",
      "screen_name" : "jeremyb",
      "indices" : [ 0, 8 ],
      "id_str" : "4373521",
      "id" : 4373521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49824689245257728",
  "geo" : { },
  "id_str" : "49824959895314432",
  "in_reply_to_user_id" : 4373521,
  "text" : "@jeremyb this is why I'm so glad to be done with school.",
  "id" : 49824959895314432,
  "in_reply_to_status_id" : 49824689245257728,
  "created_at" : "2011-03-21 13:29:30 +0000",
  "in_reply_to_screen_name" : "jeremyb",
  "in_reply_to_user_id_str" : "4373521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brown",
      "screen_name" : "jeremyb",
      "indices" : [ 0, 8 ],
      "id_str" : "4373521",
      "id" : 4373521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49823309034045440",
  "geo" : { },
  "id_str" : "49824447313608704",
  "in_reply_to_user_id" : 4373521,
  "text" : "@jeremyb you should just let them pick whatever language they want. Let the smart ones do it in languages that make it easier.",
  "id" : 49824447313608704,
  "in_reply_to_status_id" : 49823309034045440,
  "created_at" : "2011-03-21 13:27:28 +0000",
  "in_reply_to_screen_name" : "jeremyb",
  "in_reply_to_user_id_str" : "4373521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brown",
      "screen_name" : "jeremyb",
      "indices" : [ 0, 8 ],
      "id_str" : "4373521",
      "id" : 4373521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49816795514810368",
  "geo" : { },
  "id_str" : "49822902505316352",
  "in_reply_to_user_id" : 4373521,
  "text" : "@jeremyb what kind of networking? Because that is definitely possible.",
  "id" : 49822902505316352,
  "in_reply_to_status_id" : 49816795514810368,
  "created_at" : "2011-03-21 13:21:20 +0000",
  "in_reply_to_screen_name" : "jeremyb",
  "in_reply_to_user_id_str" : "4373521",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49658414015594496",
  "text" : "ELF MONSTERS! http:\/\/www.youtube.com\/watch?v=BZ_bhwCgtXg",
  "id" : 49658414015594496,
  "created_at" : "2011-03-21 02:27:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIT",
      "indices" : [ 3, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49241367322427392",
  "text" : "GO #RIT HOCKEY! I wish I was there at the game :(",
  "id" : 49241367322427392,
  "created_at" : "2011-03-19 22:50:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49220231729647616",
  "geo" : { },
  "id_str" : "49224713368633344",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan TWSS",
  "id" : 49224713368633344,
  "in_reply_to_status_id" : 49220231729647616,
  "created_at" : "2011-03-19 21:44:20 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49221957664780288",
  "geo" : { },
  "id_str" : "49222484750372864",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape follow her on her way out, then home, park behind her, and rev the engine when she gets out",
  "id" : 49222484750372864,
  "in_reply_to_status_id" : 49221957664780288,
  "created_at" : "2011-03-19 21:35:29 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49204852122861569",
  "text" : "Uh, I thought we weren't gonna do this whole war halfway around the world thing again. :(",
  "id" : 49204852122861569,
  "created_at" : "2011-03-19 20:25:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49179924963147776",
  "geo" : { },
  "id_str" : "49180587025629184",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski are you leading up the Rent is Too Damn High party?",
  "id" : 49180587025629184,
  "in_reply_to_status_id" : 49179924963147776,
  "created_at" : "2011-03-19 18:49:00 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49174284094017536",
  "geo" : { },
  "id_str" : "49174997473832960",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape groupme?",
  "id" : 49174997473832960,
  "in_reply_to_status_id" : 49174284094017536,
  "created_at" : "2011-03-19 18:26:47 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 48, 57 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "49135295387541504",
  "text" : "Back to Boston from #mwrc, it was great, thanks @blowmage and everyone else who made it fun!",
  "id" : 49135295387541504,
  "created_at" : "2011-03-19 15:49:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49129257720496130",
  "geo" : { },
  "id_str" : "49135058891710464",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich we need to launch that, sounds awesome",
  "id" : 49135058891710464,
  "in_reply_to_status_id" : 49129257720496130,
  "created_at" : "2011-03-19 15:48:05 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "49116573646077952",
  "geo" : { },
  "id_str" : "49121762788655105",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv rent a uhaul van, its cheap",
  "id" : 49121762788655105,
  "in_reply_to_status_id" : 49116573646077952,
  "created_at" : "2011-03-19 14:55:15 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48895251141767168",
  "text" : "Apparently I need attr_accessible for my arguments.",
  "id" : 48895251141767168,
  "created_at" : "2011-03-18 23:55:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48893700243324928",
  "text" : "...for a TECH company. obviously if you need a PLANT of MACHINES to make stuff, you need MONEY.",
  "id" : 48893700243324928,
  "created_at" : "2011-03-18 23:49:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48891835124416512",
  "text" : "I'm probably wrong, but I feel if you have to beg someone else for money out of the gate to run your business, you failed already.",
  "id" : 48891835124416512,
  "created_at" : "2011-03-18 23:41:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48884842603085825",
  "text" : "I can't wait until I can start a lifestyle business and not make piles of money.",
  "id" : 48884842603085825,
  "created_at" : "2011-03-18 23:13:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 0, 7 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48839132235046912",
  "geo" : { },
  "id_str" : "48843883085443072",
  "in_reply_to_user_id" : 14253546,
  "text" : "@dbrady CREEPY",
  "id" : 48843883085443072,
  "in_reply_to_status_id" : 48839132235046912,
  "created_at" : "2011-03-18 20:31:03 +0000",
  "in_reply_to_screen_name" : "dbrady",
  "in_reply_to_user_id_str" : "14253546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48826185878212610",
  "text" : "STOP SAYING \"PORO\". PLEASE.",
  "id" : 48826185878212610,
  "created_at" : "2011-03-18 19:20:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 41, 51 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48800966736216065",
  "text" : "Well, having unique indexes in place for @gemcutter will help from here on out...almost 10 repeated versions and 1 duped gem :(",
  "id" : 48800966736216065,
  "created_at" : "2011-03-18 17:40:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48786974219309057",
  "geo" : { },
  "id_str" : "48787239836196864",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott BBRROOOMMMMROOMMROOMMROOMM",
  "id" : 48787239836196864,
  "in_reply_to_status_id" : 48786974219309057,
  "created_at" : "2011-03-18 16:45:59 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48784827666808832",
  "geo" : { },
  "id_str" : "48785774941978624",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik awesome talk. i need to do Go more, the type embedding system is so crazy",
  "id" : 48785774941978624,
  "in_reply_to_status_id" : 48784827666808832,
  "created_at" : "2011-03-18 16:40:09 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48765081047138304",
  "text" : "Live streaming of #mwrc still happening today! http:\/\/mtnwestrubyconf.org\/",
  "id" : 48765081047138304,
  "created_at" : "2011-03-18 15:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48763986191187968",
  "text" : "Day two of #mwrc! RUUUUUUBY!!!",
  "id" : 48763986191187968,
  "created_at" : "2011-03-18 15:13:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48619004323045376",
  "text" : "Current status: http:\/\/yfrog.com\/h833fbej",
  "id" : 48619004323045376,
  "created_at" : "2011-03-18 05:37:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48607965284012032",
  "text" : "Bartender at the hotel's nametag is \"Johnny Disco\". Really dude?",
  "id" : 48607965284012032,
  "created_at" : "2011-03-18 04:53:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48572939485978624",
  "geo" : { },
  "id_str" : "48582623542517760",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic what is this i don't even",
  "id" : 48582623542517760,
  "in_reply_to_status_id" : 48572939485978624,
  "created_at" : "2011-03-18 03:12:54 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chung as a Service",
      "screen_name" : "heisenthought",
      "indices" : [ 0, 14 ],
      "id_str" : "15913931",
      "id" : 15913931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48562856450461696",
  "geo" : { },
  "id_str" : "48580436833738752",
  "in_reply_to_user_id" : 15913931,
  "text" : "@heisenthought no problem, anytime!",
  "id" : 48580436833738752,
  "in_reply_to_status_id" : 48562856450461696,
  "created_at" : "2011-03-18 03:04:13 +0000",
  "in_reply_to_screen_name" : "heisenthought",
  "in_reply_to_user_id_str" : "15913931",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48560994984792064",
  "text" : "Free pizza and beer at the engineyard #mwrc hackfest!",
  "id" : 48560994984792064,
  "created_at" : "2011-03-18 01:46:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48538206781714432",
  "text" : "How did my father die? http:\/\/i.imgur.com\/59BRI.jpg",
  "id" : 48538206781714432,
  "created_at" : "2011-03-18 00:16:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    }, {
      "name" : "Pedro Melo",
      "screen_name" : "pedromelo",
      "indices" : [ 11, 21 ],
      "id_str" : "653873",
      "id" : 653873
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 22, 30 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48529009029545984",
  "geo" : { },
  "id_str" : "48530934575808512",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik @pedromelo @antirez it's in development, actually: http:\/\/test.rubygems.org",
  "id" : 48530934575808512,
  "in_reply_to_status_id" : 48529009029545984,
  "created_at" : "2011-03-17 23:47:31 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48522583322267648",
  "text" : "Opened up Skitch to this, I don't remember making this AT ALL https:\/\/img.skitch.com\/20110318-bdu15wjcgh6wsryuh4db9bhqaw.png",
  "id" : 48522583322267648,
  "created_at" : "2011-03-17 23:14:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48522177724694528",
  "geo" : { },
  "id_str" : "48522486261874689",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith if you want the .key let me know",
  "id" : 48522486261874689,
  "in_reply_to_status_id" : 48522177724694528,
  "created_at" : "2011-03-17 23:13:56 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48522177724694528",
  "geo" : { },
  "id_str" : "48522436932677633",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith keynote LIKE A BOSS",
  "id" : 48522436932677633,
  "in_reply_to_status_id" : 48522177724694528,
  "created_at" : "2011-03-17 23:13:45 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 21, 28 ],
      "id_str" : "33493",
      "id" : 33493
    }, {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 33, 44 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48520621285576705",
  "text" : "Also, huge thanks to @peterc and @pnoordhuis for sanity checking those slides. And @ablissfulgal for dealing with said lack of sanity.",
  "id" : 48520621285576705,
  "created_at" : "2011-03-17 23:06:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48518599563948032",
  "text" : "Also put some of the code up on github from my talk: https:\/\/github.com\/qrush\/mwrc sorry, not tested :( (SHUN THE NONTESTER!)",
  "id" : 48518599563948032,
  "created_at" : "2011-03-17 22:58:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48516575061475328",
  "text" : "Thanks for the kind comments! Get the slides for my Redis talk (and some BONUS material): http:\/\/bit.ly\/redis-behind-the-keys #mwrc",
  "id" : 48516575061475328,
  "created_at" : "2011-03-17 22:50:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 0, 10 ],
      "id_str" : "14253068",
      "id" : 14253068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48500635494125569",
  "geo" : { },
  "id_str" : "48514583400423424",
  "in_reply_to_user_id" : 14253068,
  "text" : "@mfeathers not sure if i changed your worldview of redis but let me know :)",
  "id" : 48514583400423424,
  "in_reply_to_status_id" : 48500635494125569,
  "created_at" : "2011-03-17 22:42:32 +0000",
  "in_reply_to_screen_name" : "mfeathers",
  "in_reply_to_user_id_str" : "14253068",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Neighbors",
      "screen_name" : "dneighbors",
      "indices" : [ 0, 11 ],
      "id_str" : "1308101",
      "id" : 1308101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48501298869436416",
  "geo" : { },
  "id_str" : "48514524952797185",
  "in_reply_to_user_id" : 1308101,
  "text" : "@dneighbors thanks! code on slides is tough enough even if you can read it :)",
  "id" : 48514524952797185,
  "in_reply_to_status_id" : 48501298869436416,
  "created_at" : "2011-03-17 22:42:18 +0000",
  "in_reply_to_screen_name" : "dneighbors",
  "in_reply_to_user_id_str" : "1308101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48510265406390272",
  "geo" : { },
  "id_str" : "48514082176897024",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus i didn't say i was good at programming :)",
  "id" : 48514082176897024,
  "in_reply_to_status_id" : 48510265406390272,
  "created_at" : "2011-03-17 22:40:33 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48507033233801216",
  "geo" : { },
  "id_str" : "48514044612718592",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking thanks!",
  "id" : 48514044612718592,
  "in_reply_to_status_id" : 48507033233801216,
  "created_at" : "2011-03-17 22:40:24 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Nielsen",
      "screen_name" : "xunker",
      "indices" : [ 0, 7 ],
      "id_str" : "3301611",
      "id" : 3301611
    }, {
      "name" : "Erik Hedenstr\u00F6m",
      "screen_name" : "ErikH",
      "indices" : [ 31, 37 ],
      "id_str" : "766894",
      "id" : 766894
    }, {
      "name" : "Josiah Kiehl",
      "screen_name" : "bluepojo",
      "indices" : [ 41, 50 ],
      "id_str" : "327477172",
      "id" : 327477172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48491066067914752",
  "geo" : { },
  "id_str" : "48491577831718913",
  "in_reply_to_user_id" : 3301611,
  "text" : "@xunker hey dude, have you met @erikh or @bluepojo? would be awesome to combine forces for http:\/\/test.rubygems.org",
  "id" : 48491577831718913,
  "in_reply_to_status_id" : 48491066067914752,
  "created_at" : "2011-03-17 21:11:07 +0000",
  "in_reply_to_screen_name" : "xunker",
  "in_reply_to_user_id_str" : "3301611",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 0, 9 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48478725121126400",
  "in_reply_to_user_id" : 57753,
  "text" : "@blowmage SEE YOU OUT BACK",
  "id" : 48478725121126400,
  "created_at" : "2011-03-17 20:20:03 +0000",
  "in_reply_to_screen_name" : "blowmage",
  "in_reply_to_user_id_str" : "57753",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0634\u0627\u062F\u064A \u0628\u0646 \u0645\u062D\u0645\u062F",
      "screen_name" : "BBommarito",
      "indices" : [ 0, 11 ],
      "id_str" : "3054901639",
      "id" : 3054901639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48469285928058880",
  "text" : "@bbommarito damn, figured someone would beat me to it.",
  "id" : 48469285928058880,
  "created_at" : "2011-03-17 19:42:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48464227123474432",
  "geo" : { },
  "id_str" : "48465660908544001",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez ...doesn't every community do that? what exactly are you referring to?",
  "id" : 48465660908544001,
  "in_reply_to_status_id" : 48464227123474432,
  "created_at" : "2011-03-17 19:28:08 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 21, 31 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48414758642253824",
  "text" : "Who wants to work on @gemcutter tonight at the hackfest? Come find me! #mwrc",
  "id" : 48414758642253824,
  "created_at" : "2011-03-17 16:05:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 8, 15 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48407422011846656",
  "geo" : { },
  "id_str" : "48408740298375168",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl @elight haters gonna hate, why you hatin bro",
  "id" : 48408740298375168,
  "in_reply_to_status_id" : 48407422011846656,
  "created_at" : "2011-03-17 15:41:57 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 0, 5 ],
      "id_str" : "14184324",
      "id" : 14184324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47777906994327553",
  "geo" : { },
  "id_str" : "48401689056776192",
  "in_reply_to_user_id" : 14184324,
  "text" : "@mwrc what's the wifi password?",
  "id" : 48401689056776192,
  "in_reply_to_status_id" : 47777906994327553,
  "created_at" : "2011-03-17 15:13:56 +0000",
  "in_reply_to_screen_name" : "mwrc",
  "in_reply_to_user_id_str" : "14184324",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "indices" : [ 3, 8 ],
      "id_str" : "14184324",
      "id" : 14184324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/NuCzvWB",
      "expanded_url" : "http:\/\/mtnwestrubyconf.org\/",
      "display_url" : "mtnwestrubyconf.org"
    } ]
  },
  "geo" : { },
  "id_str" : "48401130866221057",
  "text" : "RT @mwrc: ZOMG! We are streaming MountainWest RubyConf 2011 LIVE! Please RT!\nhttp:\/\/t.co\/NuCzvWB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 86 ],
        "url" : "http:\/\/t.co\/NuCzvWB",
        "expanded_url" : "http:\/\/mtnwestrubyconf.org\/",
        "display_url" : "mtnwestrubyconf.org"
      } ]
    },
    "geo" : { },
    "id_str" : "48395612084899840",
    "text" : "ZOMG! We are streaming MountainWest RubyConf 2011 LIVE! Please RT!\nhttp:\/\/t.co\/NuCzvWB",
    "id" : 48395612084899840,
    "created_at" : "2011-03-17 14:49:47 +0000",
    "user" : {
      "name" : "MtnWest RubyConf",
      "screen_name" : "mwrc",
      "protected" : false,
      "id_str" : "14184324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000721666197\/a880cf857c53daf9f0abc1b4e66ca55f_normal.png",
      "id" : 14184324,
      "verified" : false
    }
  },
  "id" : 48401130866221057,
  "created_at" : "2011-03-17 15:11:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48400238758727680",
  "text" : "Arrived at #mwrc! This is probably the nicest library ever.",
  "id" : 48400238758727680,
  "created_at" : "2011-03-17 15:08:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48396166689341440",
  "text" : "Walking to #mwrc.... MOUNTAINS. Too used to flatland.",
  "id" : 48396166689341440,
  "created_at" : "2011-03-17 14:51:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "DNSimple",
      "screen_name" : "dnsimple",
      "indices" : [ 13, 22 ],
      "id_str" : "148198686",
      "id" : 148198686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48362953493315585",
  "geo" : { },
  "id_str" : "48384817770934272",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines @dnsimple woot! It keeps getting better.",
  "id" : 48384817770934272,
  "in_reply_to_status_id" : 48362953493315585,
  "created_at" : "2011-03-17 14:06:54 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48226238556418048",
  "text" : "Any #mwrc folks out and about tonight? Rubyist needs food, badly!",
  "id" : 48226238556418048,
  "created_at" : "2011-03-17 03:36:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48225900000583680",
  "text" : "Hi SLC! #mwrc",
  "id" : 48225900000583680,
  "created_at" : "2011-03-17 03:35:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    }, {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 8, 11 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 73, 85 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48209519012089856",
  "geo" : { },
  "id_str" : "48209855311380481",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss @j3 maybe i'll just change it to an RL version of the same face. @doctorzaius my rage face brother help!!",
  "id" : 48209855311380481,
  "in_reply_to_status_id" : 48209519012089856,
  "created_at" : "2011-03-17 02:31:39 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Ezekiel Templin",
      "screen_name" : "ezkl",
      "indices" : [ 4, 9 ],
      "id_str" : "9468622",
      "id" : 9468622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48205653994504192",
  "geo" : { },
  "id_str" : "48208492158386176",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 @ezkl NOT LEAN ENOUGH. MUST ITERATE.",
  "id" : 48208492158386176,
  "in_reply_to_status_id" : 48205653994504192,
  "created_at" : "2011-03-17 02:26:14 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48205277635428354",
  "geo" : { },
  "id_str" : "48208395584544768",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 ended up alias_method_chain'ing in order to get some usage output since i have custom flags. ways to extend it would be great.",
  "id" : 48208395584544768,
  "in_reply_to_status_id" : 48205277635428354,
  "created_at" : "2011-03-17 02:25:51 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48203785637597185",
  "text" : "The daemons gem is really unextendable. Are there any other decent options?",
  "id" : 48203785637597185,
  "created_at" : "2011-03-17 02:07:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48200349516963840",
  "geo" : { },
  "id_str" : "48200506019033088",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss i am a nonstop rails rumble, LOOK OUT",
  "id" : 48200506019033088,
  "in_reply_to_status_id" : 48200349516963840,
  "created_at" : "2011-03-17 01:54:30 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48199398458540032",
  "text" : "Are there any sites to facilitate book swapping\/trading at conferences? Read on plane, trade, bring a new one home.",
  "id" : 48199398458540032,
  "created_at" : "2011-03-17 01:50:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48191159331336193",
  "text" : "Apparently there's free internet access to twitter during this flight. I need to pipe my mail into a private twitter account.",
  "id" : 48191159331336193,
  "created_at" : "2011-03-17 01:17:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48140639514275841",
  "geo" : { },
  "id_str" : "48190889788575744",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc and thanks!",
  "id" : 48190889788575744,
  "in_reply_to_status_id" : 48140639514275841,
  "created_at" : "2011-03-17 01:16:18 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48140639514275841",
  "geo" : { },
  "id_str" : "48190851435855872",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc good call, i'll repeat it",
  "id" : 48190851435855872,
  "in_reply_to_status_id" : 48140639514275841,
  "created_at" : "2011-03-17 01:16:08 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48122725633495040",
  "text" : "RT @drbrain: Wow! Less than 2% of requests to rubygems.org come from each Ruby 1.8.6 or 1.9.1 (4% total). About \u2153 are 1.9.2 and \u2154 1.8.7.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "48122031782379522",
    "text" : "Wow! Less than 2% of requests to rubygems.org come from each Ruby 1.8.6 or 1.9.1 (4% total). About \u2153 are 1.9.2 and \u2154 1.8.7.",
    "id" : 48122031782379522,
    "created_at" : "2011-03-16 20:42:41 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 48122725633495040,
  "created_at" : "2011-03-16 20:45:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Jarvis",
      "screen_name" : "lee_jarvis",
      "indices" : [ 0, 11 ],
      "id_str" : "137640366",
      "id" : 137640366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48120116642201600",
  "geo" : { },
  "id_str" : "48122601830219776",
  "in_reply_to_user_id" : 137640366,
  "text" : "@lee_jarvis this makes my day",
  "id" : 48122601830219776,
  "in_reply_to_status_id" : 48120116642201600,
  "created_at" : "2011-03-16 20:44:57 +0000",
  "in_reply_to_screen_name" : "lee_jarvis",
  "in_reply_to_user_id_str" : "137640366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48117073318117376",
  "text" : "Is there such a thing as a free\/open source SSL cert provider (that doesn't suck) ?",
  "id" : 48117073318117376,
  "created_at" : "2011-03-16 20:22:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 0, 8 ],
      "id_str" : "12495752",
      "id" : 12495752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48114295573196800",
  "geo" : { },
  "id_str" : "48114718350639104",
  "in_reply_to_user_id" : 12495752,
  "text" : "@leshill i have `git springclean` aliased to `git remote prune origin && git gc --aggressive && git clean -dfx && git stash clear`",
  "id" : 48114718350639104,
  "in_reply_to_status_id" : 48114295573196800,
  "created_at" : "2011-03-16 20:13:37 +0000",
  "in_reply_to_screen_name" : "leshill",
  "in_reply_to_user_id_str" : "12495752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48114072092278784",
  "text" : "Turned SSL on, always. Why can't we just do this by default folks? What's so hard about this?",
  "id" : 48114072092278784,
  "created_at" : "2011-03-16 20:11:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48112595126857728",
  "text" : "Even if you sign in at https:\/\/facebook.com, it redirects you to non-SSL after signing in. FAIL.",
  "id" : 48112595126857728,
  "created_at" : "2011-03-16 20:05:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "48099913241853952",
  "text" : "Starting the journey to SLC for #mwrc!",
  "id" : 48099913241853952,
  "created_at" : "2011-03-16 19:14:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48013569366827008",
  "geo" : { },
  "id_str" : "48024699782971392",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy i say \"fengtips\"",
  "id" : 48024699782971392,
  "in_reply_to_status_id" : 48013569366827008,
  "created_at" : "2011-03-16 14:15:55 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Bock",
      "screen_name" : "bnjmnbck",
      "indices" : [ 0, 9 ],
      "id_str" : "29160478",
      "id" : 29160478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48005601002926080",
  "geo" : { },
  "id_str" : "48010766951006208",
  "in_reply_to_user_id" : 29160478,
  "text" : "@bnjmnbck silly question but is that in dev or prod mode? :) that should definitely work.",
  "id" : 48010766951006208,
  "in_reply_to_status_id" : 48005601002926080,
  "created_at" : "2011-03-16 13:20:33 +0000",
  "in_reply_to_screen_name" : "bnjmnbck",
  "in_reply_to_user_id_str" : "29160478",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Bock",
      "screen_name" : "bnjmnbck",
      "indices" : [ 0, 9 ],
      "id_str" : "29160478",
      "id" : 29160478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48001137131008000",
  "geo" : { },
  "id_str" : "48002603812003841",
  "in_reply_to_user_id" : 29160478,
  "text" : "@bnjmnbck yep, we ignore those by default. http:\/\/bit.ly\/fMu263 you can configure that, check out \"Filtering\" http:\/\/bit.ly\/etn1qE",
  "id" : 48002603812003841,
  "in_reply_to_status_id" : 48001137131008000,
  "created_at" : "2011-03-16 12:48:07 +0000",
  "in_reply_to_screen_name" : "bnjmnbck",
  "in_reply_to_user_id_str" : "29160478",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47994597489647616",
  "geo" : { },
  "id_str" : "48001540153282560",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin Old school crap left over from webrick. Read that source sometime.",
  "id" : 48001540153282560,
  "in_reply_to_status_id" : 47994597489647616,
  "created_at" : "2011-03-16 12:43:53 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Bock",
      "screen_name" : "bnjmnbck",
      "indices" : [ 0, 9 ],
      "id_str" : "29160478",
      "id" : 29160478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47975351657308160",
  "geo" : { },
  "id_str" : "47999137219756032",
  "in_reply_to_user_id" : 29160478,
  "text" : "@bnjmnbck what errors exactly? The hoptoad client ignores a set of really common errors by default (i.e., ActiveRecord::NotFound)",
  "id" : 47999137219756032,
  "in_reply_to_status_id" : 47975351657308160,
  "created_at" : "2011-03-16 12:34:20 +0000",
  "in_reply_to_screen_name" : "bnjmnbck",
  "in_reply_to_user_id_str" : "29160478",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47849585581887488",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=FiARsQSlzDc",
  "id" : 47849585581887488,
  "created_at" : "2011-03-16 02:40:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47745258502627328",
  "text" : "Current status: http:\/\/www.youtube.com\/watch?v=TRBLmogRL4c",
  "id" : 47745258502627328,
  "created_at" : "2011-03-15 19:45:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47718027504001024",
  "text" : "SIGN ME UP http:\/\/download.myads.com\/00\/0b\/41\/9a0b4147ec3252d8c0d584796d00a47a.jpg",
  "id" : 47718027504001024,
  "created_at" : "2011-03-15 17:57:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47713169174568960",
  "geo" : { },
  "id_str" : "47713751440433152",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox http:\/\/www.amazon.com\/International-Playthings-First-Purse-Purple\/dp\/B00005TQI7",
  "id" : 47713751440433152,
  "in_reply_to_status_id" : 47713169174568960,
  "created_at" : "2011-03-15 17:40:19 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47698136117940224",
  "geo" : { },
  "id_str" : "47704769086767104",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman LIKE A BOSS",
  "id" : 47704769086767104,
  "in_reply_to_status_id" : 47698136117940224,
  "created_at" : "2011-03-15 17:04:37 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47668440483368960",
  "geo" : { },
  "id_str" : "47668803148070912",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines yeah, for longed lived branches sometimes it's way easier just to merge.",
  "id" : 47668803148070912,
  "in_reply_to_status_id" : 47668440483368960,
  "created_at" : "2011-03-15 14:41:42 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47668129152774144",
  "geo" : { },
  "id_str" : "47668238577975296",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines you should have rebased",
  "id" : 47668238577975296,
  "in_reply_to_status_id" : 47668129152774144,
  "created_at" : "2011-03-15 14:39:28 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47667486736392193",
  "geo" : { },
  "id_str" : "47667709051289600",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis we tend to use it for arrays\/hashes that really shouldn't change as a constant. where should it not be used?",
  "id" : 47667709051289600,
  "in_reply_to_status_id" : 47667486736392193,
  "created_at" : "2011-03-15 14:37:22 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Moore",
      "screen_name" : "blowmage",
      "indices" : [ 85, 94 ],
      "id_str" : "57753",
      "id" : 57753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47444501169573888",
  "text" : "Holy shit. http:\/\/www.alexandrosmaragos.com\/2011\/03\/hacker-in-times-square.html \/via @blowmage",
  "id" : 47444501169573888,
  "created_at" : "2011-03-14 23:50:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47396583737798656",
  "geo" : { },
  "id_str" : "47417875698434048",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv that's bash\/zsh's fault (your shell). You have to escape it: \\!",
  "id" : 47417875698434048,
  "in_reply_to_status_id" : 47396583737798656,
  "created_at" : "2011-03-14 22:04:37 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klondike Gold",
      "screen_name" : "Klondike",
      "indices" : [ 0, 9 ],
      "id_str" : "298070410",
      "id" : 298070410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47383978222682112",
  "geo" : { },
  "id_str" : "47384350395863040",
  "in_reply_to_user_id" : 5232171,
  "text" : "@Klondike still hilarious. SELECT THE PISTOL, AND THEN, SELECT YOUR HORSE.",
  "id" : 47384350395863040,
  "in_reply_to_status_id" : 47383978222682112,
  "created_at" : "2011-03-14 19:51:24 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 8, 20 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47378570758193152",
  "text" : "I meant @fredyatesiv. That one. Hire that one.",
  "id" : 47378570758193152,
  "created_at" : "2011-03-14 19:28:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47378066099548160",
  "geo" : { },
  "id_str" : "47378506396598272",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv FIX YOUR TWITTER SHEESH",
  "id" : 47378506396598272,
  "in_reply_to_status_id" : 47378066099548160,
  "created_at" : "2011-03-14 19:28:10 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyates",
      "indices" : [ 3, 13 ],
      "id_str" : "84167841",
      "id" : 84167841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47377825828847616",
  "text" : "RT @fredyates I'm [...] transitioning to freelance full time at the end of March. (A gentleman, scholar, and kickass designer. Hire him!)",
  "id" : 47377825828847616,
  "created_at" : "2011-03-14 19:25:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47373063439912960",
  "text" : "FACEPALM http:\/\/i.imgur.com\/peudc.png",
  "id" : 47373063439912960,
  "created_at" : "2011-03-14 19:06:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47361621135343616",
  "text" : "Current status: http:\/\/25.media.tumblr.com\/tumblr_li0y7nOUOx1qfy2kdo1_500.gif",
  "id" : 47361621135343616,
  "created_at" : "2011-03-14 18:21:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 94, 102 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "47294548044562432",
  "geo" : { },
  "id_str" : "47294816412901376",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey i think it should. missing a require 'thread' in your old rails code maybe? \/cc @drbrain",
  "id" : 47294816412901376,
  "in_reply_to_status_id" : 47294548044562432,
  "created_at" : "2011-03-14 13:55:37 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47036713880649728",
  "text" : "Got our new copy of Revolution! signed by Steve Jackson himself! I wish I would have brought our Munchkin box.",
  "id" : 47036713880649728,
  "created_at" : "2011-03-13 20:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47015611091529728",
  "text" : "Classic games section at #pax is awesome, and no\/short lines!",
  "id" : 47015611091529728,
  "created_at" : "2011-03-13 19:26:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46973174650388480",
  "geo" : { },
  "id_str" : "46994660576608256",
  "in_reply_to_user_id" : 96235840,
  "text" : "@freeblankets saw you in the line...no way I'm waiting!",
  "id" : 46994660576608256,
  "in_reply_to_status_id" : 46973174650388480,
  "created_at" : "2011-03-13 18:02:54 +0000",
  "in_reply_to_screen_name" : "giantrobotbee",
  "in_reply_to_user_id_str" : "96235840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46994460709634048",
  "text" : "Hustlin at the #pax QA panel. Woot!",
  "id" : 46994460709634048,
  "created_at" : "2011-03-13 18:02:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46975188692246528",
  "text" : "Too many awesome games to try out at #pax, so little patience to wait in line",
  "id" : 46975188692246528,
  "created_at" : "2011-03-13 16:45:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46952594563809280",
  "text" : "Line for the 3DS is huge! I can wait :( #pax",
  "id" : 46952594563809280,
  "created_at" : "2011-03-13 15:15:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PAX",
      "indices" : [ 3, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46948953656274946",
  "text" : "Hi #PAX!",
  "id" : 46948953656274946,
  "created_at" : "2011-03-13 15:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46927009414254592",
  "text" : "On our way to #pax, dreading the line wait",
  "id" : 46927009414254592,
  "created_at" : "2011-03-13 13:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46911103246155779",
  "geo" : { },
  "id_str" : "46926861288210433",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage YOU'LL BE SO CONCURRENT YOU'LL INVENT NEW SPORTS",
  "id" : 46926861288210433,
  "in_reply_to_status_id" : 46911103246155779,
  "created_at" : "2011-03-13 13:33:30 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46916381219880960",
  "geo" : { },
  "id_str" : "46917970940796928",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight every time i see it i yell (usually internally) RUUUBBBYYYYYYY",
  "id" : 46917970940796928,
  "in_reply_to_status_id" : 46916381219880960,
  "created_at" : "2011-03-13 12:58:10 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wayneeseguin",
      "screen_name" : "wayneeseguin",
      "indices" : [ 0, 13 ],
      "id_str" : "11587602",
      "id" : 11587602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46395312843132928",
  "geo" : { },
  "id_str" : "46417900059373568",
  "in_reply_to_user_id" : 11587602,
  "text" : "@wayneeseguin % rvm wayne implode is not a command! Glad everyone is ok!",
  "id" : 46417900059373568,
  "in_reply_to_status_id" : 46395312843132928,
  "created_at" : "2011-03-12 03:51:04 +0000",
  "in_reply_to_screen_name" : "wayneeseguin",
  "in_reply_to_user_id_str" : "11587602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 18, 30 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46223998572441601",
  "geo" : { },
  "id_str" : "46227798876102656",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape well, @tristandunn will be in SF by that point :)",
  "id" : 46227798876102656,
  "in_reply_to_status_id" : 46223998572441601,
  "created_at" : "2011-03-11 15:15:40 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46221752946278400",
  "geo" : { },
  "id_str" : "46222205515857920",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape nope, i can wait for it to come back to boston",
  "id" : 46222205515857920,
  "in_reply_to_status_id" : 46221752946278400,
  "created_at" : "2011-03-11 14:53:27 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46221784793616386",
  "text" : "Spotted a group with a nintendo hat and way too many zelda buttons at Park St, #pax is definitely arrived in Boston :)",
  "id" : 46221784793616386,
  "created_at" : "2011-03-11 14:51:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pax",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46220862235484160",
  "text" : "Watching the #pax tweets and way too excited, will have to wait until Sunday though!",
  "id" : 46220862235484160,
  "created_at" : "2011-03-11 14:48:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 103, 116 ],
      "id_str" : "15375238",
      "id" : 15375238
    }, {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 117, 122 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "Ruthie BenDor",
      "screen_name" : "unruthless",
      "indices" : [ 128, 139 ],
      "id_str" : "12668332",
      "id" : 12668332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PAX",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45838156003676160",
  "text" : "#PAX folks, blue line is replaced by buses from Maverick to Govt Center. Take silver from the airport! @codemastermm @rufo \/via @unruthless",
  "id" : 45838156003676160,
  "created_at" : "2011-03-10 13:27:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45577958089441280",
  "text" : "Still one of my favorite concert videos. http:\/\/www.youtube.com\/watch?v=hdGcX-s99Rg",
  "id" : 45577958089441280,
  "created_at" : "2011-03-09 20:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy walker",
      "screen_name" : "walkeran",
      "indices" : [ 0, 9 ],
      "id_str" : "16563342",
      "id" : 16563342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45462807600312320",
  "geo" : { },
  "id_str" : "45472284810547200",
  "in_reply_to_user_id" : 16563342,
  "text" : "@walkeran I haven't received any pingdom alerts about downtime. What's the problem?",
  "id" : 45472284810547200,
  "in_reply_to_status_id" : 45462807600312320,
  "created_at" : "2011-03-09 13:13:32 +0000",
  "in_reply_to_screen_name" : "walkeran",
  "in_reply_to_user_id_str" : "16563342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45305773978427392",
  "text" : "\"my coworker asked me why redis doesn't run on windows ... what specific functionality is there that windows is missing?\" \"posix\"",
  "id" : 45305773978427392,
  "created_at" : "2011-03-09 02:11:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45251362816143360",
  "geo" : { },
  "id_str" : "45259341208625153",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit sorry dude, in major talk prepare mode :) next month!",
  "id" : 45259341208625153,
  "in_reply_to_status_id" : 45251362816143360,
  "created_at" : "2011-03-08 23:07:22 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45219030927278081",
  "geo" : { },
  "id_str" : "45250636475936769",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yes, open a support request",
  "id" : 45250636475936769,
  "in_reply_to_status_id" : 45219030927278081,
  "created_at" : "2011-03-08 22:32:47 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45201505745240064",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier yeah it looks fun, I haven't touched my bass in months...would love to drop by.",
  "id" : 45201505745240064,
  "created_at" : "2011-03-08 19:17:33 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45183764258766848",
  "text" : "The State of Version Control, quite depressing. http:\/\/www.fogcreek.com\/blog\/post\/The-State-of-Version-Control.aspx",
  "id" : 45183764258766848,
  "created_at" : "2011-03-08 18:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robertson",
      "screen_name" : "jrobertson",
      "indices" : [ 0, 11 ],
      "id_str" : "763224",
      "id" : 763224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45125032380350464",
  "geo" : { },
  "id_str" : "45133104276439040",
  "in_reply_to_user_id" : 763224,
  "text" : "@jrobertson Also, you'll never run out of gem versions. Just yank the bad one and move on :)",
  "id" : 45133104276439040,
  "in_reply_to_status_id" : 45125032380350464,
  "created_at" : "2011-03-08 14:45:45 +0000",
  "in_reply_to_screen_name" : "jrobertson",
  "in_reply_to_user_id_str" : "763224",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robertson",
      "screen_name" : "jrobertson",
      "indices" : [ 0, 11 ],
      "id_str" : "763224",
      "id" : 763224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45125032380350464",
  "geo" : { },
  "id_str" : "45132763426324480",
  "in_reply_to_user_id" : 763224,
  "text" : "@jrobertson yep, this is to make sure mirrors don't get out of sync and others don't have conflict issues with the same gem version",
  "id" : 45132763426324480,
  "in_reply_to_status_id" : 45125032380350464,
  "created_at" : "2011-03-08 14:44:23 +0000",
  "in_reply_to_screen_name" : "jrobertson",
  "in_reply_to_user_id_str" : "763224",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44898341833814016",
  "text" : "Totally called this in 2008. \"where are the great WPF applications?\" http:\/\/www.fixwpf.org\/ (my post: http:\/\/is.gd\/m7sUVZ)",
  "id" : 44898341833814016,
  "created_at" : "2011-03-07 23:12:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keiki",
      "screen_name" : "angelicism",
      "indices" : [ 0, 11 ],
      "id_str" : "26816492",
      "id" : 26816492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44875214319910912",
  "geo" : { },
  "id_str" : "44875917549510656",
  "in_reply_to_user_id" : 26816492,
  "text" : "@angelicism http:\/\/fuckyeahnouns.com\/images\/vim",
  "id" : 44875917549510656,
  "in_reply_to_status_id" : 44875214319910912,
  "created_at" : "2011-03-07 21:43:47 +0000",
  "in_reply_to_screen_name" : "angelicism",
  "in_reply_to_user_id_str" : "26816492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Lowell",
      "screen_name" : "cowboyd",
      "indices" : [ 0, 8 ],
      "id_str" : "791224",
      "id" : 791224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44859674197102593",
  "geo" : { },
  "id_str" : "44874162015191040",
  "in_reply_to_user_id" : 791224,
  "text" : "@cowboyd :( I wrote about this here: http:\/\/robots.thoughtbot.com\/post\/2729333530\/fetching-source-index-for-http-rubygems-org",
  "id" : 44874162015191040,
  "in_reply_to_status_id" : 44859674197102593,
  "created_at" : "2011-03-07 21:36:48 +0000",
  "in_reply_to_screen_name" : "cowboyd",
  "in_reply_to_user_id_str" : "791224",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44872077328650240",
  "geo" : { },
  "id_str" : "44872254374424579",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield what's terrible is going through a list of 100+ countries. either autocomplete, a map, or both",
  "id" : 44872254374424579,
  "in_reply_to_status_id" : 44872077328650240,
  "created_at" : "2011-03-07 21:29:13 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory O'Brien",
      "screen_name" : "CoryOBrien",
      "indices" : [ 0, 11 ],
      "id_str" : "797770",
      "id" : 797770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44872000056995840",
  "geo" : { },
  "id_str" : "44872151160991744",
  "in_reply_to_user_id" : 797770,
  "text" : "@CoryOBrien filter and zoom, like any good UI should",
  "id" : 44872151160991744,
  "in_reply_to_status_id" : 44872000056995840,
  "created_at" : "2011-03-07 21:28:49 +0000",
  "in_reply_to_screen_name" : "CoryOBrien",
  "in_reply_to_user_id_str" : "797770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44871800118706177",
  "text" : "Why haven't we replaced Country dropdowns on web forms with a world map yet?",
  "id" : 44871800118706177,
  "created_at" : "2011-03-07 21:27:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 16, 26 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44783176207441920",
  "text" : "Behind again on @gemcutter support issues. It would be a lot easier if folks could remember to look at what's in a gem before pushing. :(",
  "id" : 44783176207441920,
  "created_at" : "2011-03-07 15:35:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ryall",
      "screen_name" : "mryall",
      "indices" : [ 0, 7 ],
      "id_str" : "1147341",
      "id" : 1147341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44717061863247872",
  "geo" : { },
  "id_str" : "44780856493084672",
  "in_reply_to_user_id" : 1147341,
  "text" : "@mryall yes, but it's still there for you to download. much better than the alternative, hard deleting it :)",
  "id" : 44780856493084672,
  "in_reply_to_status_id" : 44717061863247872,
  "created_at" : "2011-03-07 15:26:02 +0000",
  "in_reply_to_screen_name" : "mryall",
  "in_reply_to_user_id_str" : "1147341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Vandevelde",
      "screen_name" : "icidasset",
      "indices" : [ 0, 10 ],
      "id_str" : "14250139",
      "id" : 14250139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44763650468225025",
  "geo" : { },
  "id_str" : "44780682601439232",
  "in_reply_to_user_id" : 14250139,
  "text" : "@icidAsset yes, they are. mirrors are combing the site constantly too",
  "id" : 44780682601439232,
  "in_reply_to_status_id" : 44763650468225025,
  "created_at" : "2011-03-07 15:25:21 +0000",
  "in_reply_to_screen_name" : "icidasset",
  "in_reply_to_user_id_str" : "14250139",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44428564199772160",
  "text" : "I really hope I'm this passionate at 45. Very inspiring. http:\/\/jacquesmattheij.com\/The+need+to+code",
  "id" : 44428564199772160,
  "created_at" : "2011-03-06 16:06:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43839670425100288",
  "geo" : { },
  "id_str" : "43842283174502400",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel so? Rails does this all the time. That's why Ruby is awesome.",
  "id" : 43842283174502400,
  "in_reply_to_status_id" : 43839670425100288,
  "created_at" : "2011-03-05 01:16:29 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43771392713424896",
  "geo" : { },
  "id_str" : "43773114466840576",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh http:\/\/i.imgur.com\/CJfjM.jpg (the meme_generator gem makes this too easy)",
  "id" : 43773114466840576,
  "in_reply_to_status_id" : 43771392713424896,
  "created_at" : "2011-03-04 20:41:38 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan Ensari",
      "screen_name" : "hakanensari",
      "indices" : [ 0, 12 ],
      "id_str" : "15325245",
      "id" : 15325245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43741400965193728",
  "geo" : { },
  "id_str" : "43752365194625024",
  "in_reply_to_user_id" : 15325245,
  "text" : "@hakanensari well there's more gems now...averaging 234 new ones over the past 30 days, every day. how long did it take?",
  "id" : 43752365194625024,
  "in_reply_to_status_id" : 43741400965193728,
  "created_at" : "2011-03-04 19:19:11 +0000",
  "in_reply_to_screen_name" : "hakanensari",
  "in_reply_to_user_id_str" : "15325245",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43750513761730560",
  "text" : "Who is going to PAX East!? http:\/\/east.paxsite.com\/",
  "id" : 43750513761730560,
  "created_at" : "2011-03-04 19:11:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43674692330074113",
  "geo" : { },
  "id_str" : "43675066772357120",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss forcing everyone to use github for that isn't going to happen. We have solr search coming soon and http:\/\/gemsearch.heroku.com",
  "id" : 43675066772357120,
  "in_reply_to_status_id" : 43674692330074113,
  "created_at" : "2011-03-04 14:12:02 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43671786252025856",
  "geo" : { },
  "id_str" : "43674270265638912",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss user reviews should be separate. Even comments on a gem would turn into an informal bug tracker maintainers would have to watch",
  "id" : 43674270265638912,
  "in_reply_to_status_id" : 43671786252025856,
  "created_at" : "2011-03-04 14:08:52 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43671931949559808",
  "geo" : { },
  "id_str" : "43672486247792640",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss like mirroring and better indexing. That being said, search is getting a major overhaul soon",
  "id" : 43672486247792640,
  "in_reply_to_status_id" : 43671931949559808,
  "created_at" : "2011-03-04 14:01:46 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43671931949559808",
  "geo" : { },
  "id_str" : "43672328344846336",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss keep adding features and it turns into rubyforge. Gemcutter is about gem hosting, and there's enough unsolved problems there first",
  "id" : 43672328344846336,
  "in_reply_to_status_id" : 43671931949559808,
  "created_at" : "2011-03-04 14:01:09 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43668538162024449",
  "geo" : { },
  "id_str" : "43671097325002752",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss ....what does that even mean?",
  "id" : 43671097325002752,
  "in_reply_to_status_id" : 43668538162024449,
  "created_at" : "2011-03-04 13:56:15 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Norris",
      "screen_name" : "rsl",
      "indices" : [ 0, 4 ],
      "id_str" : "82863",
      "id" : 82863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43335306900013056",
  "geo" : { },
  "id_str" : "43502183320272896",
  "in_reply_to_user_id" : 82863,
  "text" : "@rsl it's going to get even better soon, hooking up solr and http:\/\/gemsearch.heroku.com\/",
  "id" : 43502183320272896,
  "in_reply_to_status_id" : 43335306900013056,
  "created_at" : "2011-03-04 02:45:03 +0000",
  "in_reply_to_screen_name" : "rsl",
  "in_reply_to_user_id_str" : "82863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43494733376536576",
  "geo" : { },
  "id_str" : "43494883922673664",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil not good enough either, it's just another mashup. need something *more*",
  "id" : 43494883922673664,
  "in_reply_to_status_id" : 43494733376536576,
  "created_at" : "2011-03-04 02:16:03 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43494181712314368",
  "text" : "Enough said: http:\/\/www.bostonapartments.com\/",
  "id" : 43494181712314368,
  "created_at" : "2011-03-04 02:13:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43493880003428353",
  "text" : "One of these days I'm going to hipmunk the apartment search sites. Existing ones suck, google maps + craigslist mashups aren't good enough.",
  "id" : 43493880003428353,
  "created_at" : "2011-03-04 02:12:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43475696802213888",
  "text" : "I kind of want a print version of http:\/\/goodnightdune.com. You know, for things. &gt;_&gt; @ablissfulgal",
  "id" : 43475696802213888,
  "created_at" : "2011-03-04 00:59:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43469992083193856",
  "geo" : { },
  "id_str" : "43471781922750464",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko wow, that sounds awesome. Is it even necessary for 1.9 though?",
  "id" : 43471781922750464,
  "in_reply_to_status_id" : 43469992083193856,
  "created_at" : "2011-03-04 00:44:15 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43453650475032576",
  "geo" : { },
  "id_str" : "43456844018094081",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek let's do it. Someone has to take the plunge.",
  "id" : 43456844018094081,
  "in_reply_to_status_id" : 43453650475032576,
  "created_at" : "2011-03-03 23:44:53 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43393564591398912",
  "text" : "AXE COP. THE REAL COMIC BOOK. http:\/\/www.darkhorse.com\/Comics\/Previews\/18-445?page=0",
  "id" : 43393564591398912,
  "created_at" : "2011-03-03 19:33:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43323216982323201",
  "text" : "RT @maciakl: I'm gonna use this to name all my classes from now on:  http:\/\/www.classnamer.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "43321360864391168",
    "text" : "I'm gonna use this to name all my classes from now on:  http:\/\/www.classnamer.com\/",
    "id" : 43321360864391168,
    "created_at" : "2011-03-03 14:46:31 +0000",
    "user" : {
      "name" : "Luke Maciak",
      "screen_name" : "LukeMaciak",
      "protected" : false,
      "id_str" : "810567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422606780066443264\/EweXMUJx_normal.jpeg",
      "id" : 810567,
      "verified" : false
    }
  },
  "id" : 43323216982323201,
  "created_at" : "2011-03-03 14:53:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43291086403289088",
  "text" : "Canada's pretty cool, eh http:\/\/www.youtube.com\/watch?v=bV_041oYDjg",
  "id" : 43291086403289088,
  "created_at" : "2011-03-03 12:46:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43288847186010113",
  "text" : "Anyone who's had a brother playing video games (older or younger) will appreciate this http:\/\/www.youtube.com\/watch?v=y_Ef0Cb4UYA",
  "id" : 43288847186010113,
  "created_at" : "2011-03-03 12:37:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43140154189283330",
  "geo" : { },
  "id_str" : "43142159850930176",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi haters gonna hate",
  "id" : 43142159850930176,
  "in_reply_to_status_id" : 43140154189283330,
  "created_at" : "2011-03-03 02:54:27 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    }, {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 32, 43 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43139335620526080",
  "geo" : { },
  "id_str" : "43139689967910913",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey I don't know, ask @dchelimsky :) afaik it was to help modularity and maintaibility",
  "id" : 43139689967910913,
  "in_reply_to_status_id" : 43139335620526080,
  "created_at" : "2011-03-03 02:44:38 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43137246181851136",
  "geo" : { },
  "id_str" : "43138766508007424",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey why are you depending on more than just the rspec or rspec-rails gem?",
  "id" : 43138766508007424,
  "in_reply_to_status_id" : 43137246181851136,
  "created_at" : "2011-03-03 02:40:58 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Gillane",
      "screen_name" : "hgillane",
      "indices" : [ 0, 9 ],
      "id_str" : "17432847",
      "id" : 17432847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43120875154837504",
  "geo" : { },
  "id_str" : "43132397167980544",
  "in_reply_to_user_id" : 17432847,
  "text" : "@hgillane thanks :)",
  "id" : 43132397167980544,
  "in_reply_to_status_id" : 43120875154837504,
  "created_at" : "2011-03-03 02:15:39 +0000",
  "in_reply_to_screen_name" : "hgillane",
  "in_reply_to_user_id_str" : "17432847",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43123079718776833",
  "text" : "What are some other cool real-time APIs than Twitter or large open data sources?",
  "id" : 43123079718776833,
  "created_at" : "2011-03-03 01:38:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43118558821089280",
  "geo" : { },
  "id_str" : "43119290857160704",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman what exactly is breaking? anything with the new release? can you post an issue on http:\/\/help.rubygems.org",
  "id" : 43119290857160704,
  "in_reply_to_status_id" : 43118558821089280,
  "created_at" : "2011-03-03 01:23:34 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43113033077227520",
  "geo" : { },
  "id_str" : "43116966713630720",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman ...what :(",
  "id" : 43116966713630720,
  "in_reply_to_status_id" : 43113033077227520,
  "created_at" : "2011-03-03 01:14:20 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42980922999582720",
  "geo" : { },
  "id_str" : "42984000859553792",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl can you report the bugs you're seeing? http:\/\/help.rubygems.org",
  "id" : 42984000859553792,
  "in_reply_to_status_id" : 42980922999582720,
  "created_at" : "2011-03-02 16:25:59 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42937883585290240",
  "text" : "EPIC CAMPING TIME http:\/\/i.imgur.com\/dIz5g.jpg",
  "id" : 42937883585290240,
  "created_at" : "2011-03-02 13:22:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mwrc",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42786336029147137",
  "text" : "Part one of my #mwrc demo is now cooking... just keep tweeting &gt;:)",
  "id" : 42786336029147137,
  "created_at" : "2011-03-02 03:20:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 11, 23 ],
      "id_str" : "152862026",
      "id" : 152862026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42785188736024576",
  "text" : "Pumped for @EdwardTufte's session tomorrow, ready for information overload. Er, maybe I'm missing the point :)",
  "id" : 42785188736024576,
  "created_at" : "2011-03-02 03:15:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr florian",
      "screen_name" : "herrflorian",
      "indices" : [ 0, 12 ],
      "id_str" : "397316711",
      "id" : 397316711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42690632128528385",
  "geo" : { },
  "id_str" : "42714254649987072",
  "in_reply_to_user_id" : 191109442,
  "text" : "@HerrFlorian what? What happened? timeout?",
  "id" : 42714254649987072,
  "in_reply_to_status_id" : 42690632128528385,
  "created_at" : "2011-03-01 22:34:06 +0000",
  "in_reply_to_screen_name" : "__florian",
  "in_reply_to_user_id_str" : "191109442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42702941303480320",
  "geo" : { },
  "id_str" : "42703165325459456",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius RAGETAR",
  "id" : 42703165325459456,
  "in_reply_to_status_id" : 42702941303480320,
  "created_at" : "2011-03-01 21:50:02 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42680733977939968",
  "geo" : { },
  "id_str" : "42697495490461696",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius the rage faces really make twitter so much better. i think i need a new service that just replaces everyone's face with one",
  "id" : 42697495490461696,
  "in_reply_to_status_id" : 42680733977939968,
  "created_at" : "2011-03-01 21:27:30 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42696971689005057",
  "geo" : { },
  "id_str" : "42697344210305024",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv http:\/\/img470.imageshack.us\/img470\/5901\/teeth4tl.jpg",
  "id" : 42697344210305024,
  "in_reply_to_status_id" : 42696971689005057,
  "created_at" : "2011-03-01 21:26:54 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Smith",
      "screen_name" : "orderedlist",
      "indices" : [ 0, 12 ],
      "id_str" : "12938",
      "id" : 12938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42692314153484288",
  "geo" : { },
  "id_str" : "42694475419619328",
  "in_reply_to_user_id" : 12938,
  "text" : "@orderedlist what does this offer over google analytics? why should I switch? a tiny screenshot isn't enough for me",
  "id" : 42694475419619328,
  "in_reply_to_status_id" : 42692314153484288,
  "created_at" : "2011-03-01 21:15:30 +0000",
  "in_reply_to_screen_name" : "orderedlist",
  "in_reply_to_user_id_str" : "12938",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42663527231660032",
  "geo" : { },
  "id_str" : "42671463442026496",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius i've changed mine in solidarity with you, don't change it!",
  "id" : 42671463442026496,
  "in_reply_to_status_id" : 42663527231660032,
  "created_at" : "2011-03-01 19:44:04 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elad Meidar",
      "screen_name" : "eladmeidar",
      "indices" : [ 0, 11 ],
      "id_str" : "16815376",
      "id" : 16815376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42609312983556096",
  "geo" : { },
  "id_str" : "42658135277703168",
  "in_reply_to_user_id" : 16815376,
  "text" : "@eladmeidar not that i'm aware of, you're the only one reporting them. :(",
  "id" : 42658135277703168,
  "in_reply_to_status_id" : 42609312983556096,
  "created_at" : "2011-03-01 18:51:06 +0000",
  "in_reply_to_screen_name" : "eladmeidar",
  "in_reply_to_user_id_str" : "16815376",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ingenthron",
      "screen_name" : "ingenthr",
      "indices" : [ 0, 9 ],
      "id_str" : "14696873",
      "id" : 14696873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42651921235972096",
  "geo" : { },
  "id_str" : "42652236937048064",
  "in_reply_to_user_id" : 14696873,
  "text" : "@ingenthr hey, i meant to catch up with you! I thought it was, i need to look more into membase. nice talk btw :)",
  "id" : 42652236937048064,
  "in_reply_to_status_id" : 42651921235972096,
  "created_at" : "2011-03-01 18:27:40 +0000",
  "in_reply_to_screen_name" : "ingenthr",
  "in_reply_to_user_id_str" : "14696873",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42460779332505600",
  "geo" : { },
  "id_str" : "42596219889000448",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc IMO comments would turn into a terrible bug reporting system that maintainers need to check. use mailing lists, this isn't RF!",
  "id" : 42596219889000448,
  "in_reply_to_status_id" : 42460779332505600,
  "created_at" : "2011-03-01 14:45:04 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
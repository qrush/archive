Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    }, {
      "name" : "Ricardo Mendes",
      "screen_name" : "locks",
      "indices" : [ 17, 23 ],
      "id_str" : "7492672",
      "id" : 7492672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351472895849013251",
  "geo" : { },
  "id_str" : "351486760452231170",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene @locks it was causing performance problems at some point so it got dropped.",
  "id" : 351486760452231170,
  "in_reply_to_status_id" : 351472895849013251,
  "created_at" : "2013-06-30 23:45:48 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351470446648111104",
  "geo" : { },
  "id_str" : "351486684434661377",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene GH issues is fine",
  "id" : 351486684434661377,
  "in_reply_to_status_id" : 351470446648111104,
  "created_at" : "2013-06-30 23:45:30 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 0, 13 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 14, 26 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "blez $a0, jackie",
      "screen_name" : "jackiekircher",
      "indices" : [ 27, 41 ],
      "id_str" : "30143557",
      "id" : 30143557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351371084903362560",
  "geo" : { },
  "id_str" : "351373112467652609",
  "in_reply_to_user_id" : 14928483,
  "text" : "@lindseybieda @juliepagano @jackiekircher we designed and homemade scratchoffs to give to family\/close friends, it was a lot of fun.",
  "id" : 351373112467652609,
  "in_reply_to_status_id" : 351371084903362560,
  "created_at" : "2013-06-30 16:14:12 +0000",
  "in_reply_to_screen_name" : "lindseybieda",
  "in_reply_to_user_id_str" : "14928483",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 13, 26 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "blez $a0, jackie",
      "screen_name" : "jackiekircher",
      "indices" : [ 27, 41 ],
      "id_str" : "30143557",
      "id" : 30143557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351370258617090048",
  "text" : "@juliepagano @lindseybieda @jackiekircher the gender reveal party was too much for us. Thought of a different way to \u201Creveal\u201D it.",
  "id" : 351370258617090048,
  "created_at" : "2013-06-30 16:02:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351075582420852736",
  "text" : "That last Vine is how broken my original SNES was. Booyah garage sales!",
  "id" : 351075582420852736,
  "created_at" : "2013-06-29 20:31:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/H9iXOZPxRO",
      "expanded_url" : "https:\/\/vine.co\/v\/bYvWE3uYVFq",
      "display_url" : "vine.co\/v\/bYvWE3uYVFq"
    } ]
  },
  "geo" : { },
  "id_str" : "351075366233849857",
  "text" : "My Super NES has seen better days. https:\/\/t.co\/H9iXOZPxRO",
  "id" : 351075366233849857,
  "created_at" : "2013-06-29 20:31:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannick \u2603 Schutz",
      "screen_name" : "yann_ck",
      "indices" : [ 0, 8 ],
      "id_str" : "14835545",
      "id" : 14835545
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 45, 53 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351074509731807232",
  "geo" : { },
  "id_str" : "351075202165256193",
  "in_reply_to_user_id" : 14835545,
  "text" : "@yann_ck definitely! I have a copy thanks to @jayunit, should be able to play it now",
  "id" : 351075202165256193,
  "in_reply_to_status_id" : 351074509731807232,
  "created_at" : "2013-06-29 20:30:25 +0000",
  "in_reply_to_screen_name" : "yann_ck",
  "in_reply_to_user_id_str" : "14835545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathiasx",
      "screen_name" : "mathiasx",
      "indices" : [ 0, 9 ],
      "id_str" : "787975",
      "id" : 787975
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 82, 92 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351071688793927680",
  "geo" : { },
  "id_str" : "351074145674596353",
  "in_reply_to_user_id" : 787975,
  "text" : "@mathiasx yeah originally just picked up both star wars carts and Mario Kart, and @aquaranto helped me realize I made a huge mistake",
  "id" : 351074145674596353,
  "in_reply_to_status_id" : 351071688793927680,
  "created_at" : "2013-06-29 20:26:13 +0000",
  "in_reply_to_screen_name" : "mathiasx",
  "in_reply_to_user_id_str" : "787975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351072287652450304",
  "geo" : { },
  "id_str" : "351073938295635968",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss still have mine too but it is very unreliable.",
  "id" : 351073938295635968,
  "in_reply_to_status_id" : 351072287652450304,
  "created_at" : "2013-06-29 20:25:24 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351072940760113153",
  "text" : "An actual working SNES means I can play one of my favorite games (and practice for future fatherhood): Yoshi's Island!",
  "id" : 351072940760113153,
  "created_at" : "2013-06-29 20:21:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/bGNrEaH9rA",
      "expanded_url" : "http:\/\/flic.kr\/p\/eYiCh3",
      "display_url" : "flic.kr\/p\/eYiCh3"
    } ]
  },
  "geo" : { },
  "id_str" : "351071361977946112",
  "text" : "$25 for an SNES and 12 games at a garage sale. Jackpot! http:\/\/t.co\/bGNrEaH9rA",
  "id" : 351071361977946112,
  "created_at" : "2013-06-29 20:15:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kids Ruby",
      "screen_name" : "KidsRuby",
      "indices" : [ 3, 12 ],
      "id_str" : "238055076",
      "id" : 238055076
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 92, 107 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/cwP1rNCeiV",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#katie",
      "display_url" : "nickelcityruby.com\/#katie"
    } ]
  },
  "geo" : { },
  "id_str" : "350996202784956418",
  "text" : "RT @KidsRuby: This is extremely awesome...Katie Hagerty presenting \"My KidsRuby Journey\" at @nickelcityruby! http:\/\/t.co\/cwP1rNCeiV (correc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/launchpad.net\/polly\" rel=\"nofollow\"\u003EPolly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 78, 93 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/cwP1rNCeiV",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#katie",
        "display_url" : "nickelcityruby.com\/#katie"
      } ]
    },
    "geo" : { },
    "id_str" : "350767482732167168",
    "text" : "This is extremely awesome...Katie Hagerty presenting \"My KidsRuby Journey\" at @nickelcityruby! http:\/\/t.co\/cwP1rNCeiV (corrected)",
    "id" : 350767482732167168,
    "created_at" : "2013-06-29 00:07:39 +0000",
    "user" : {
      "name" : "Kids Ruby",
      "screen_name" : "KidsRuby",
      "protected" : false,
      "id_str" : "238055076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1284444045\/kidsrubytwit_normal.png",
      "id" : 238055076,
      "verified" : false
    }
  },
  "id" : 350996202784956418,
  "created_at" : "2013-06-29 15:16:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350867520741310465",
  "text" : "Apparently Flickr crashing means an upload was successful! On a side note, don't upgrade to iOS7 on your main phone. \uD83D\uDE29",
  "id" : 350867520741310465,
  "created_at" : "2013-06-29 06:45:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350865845616001025",
  "geo" : { },
  "id_str" : "350867006750334977",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes yes Flickr crashed each time, didn't know it was going through.",
  "id" : 350867006750334977,
  "in_reply_to_status_id" : 350865845616001025,
  "created_at" : "2013-06-29 06:43:07 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Wu0xXhQWa8",
      "expanded_url" : "https:\/\/www.google.com\/search?q=robert+downey+jr+pinup&safe=off&source=lnms&tbm=isch&sa=X&ei=ExLOUc_YD7ir4AOLrYDwCg&ved=0CAkQ_AUoAQ&biw=2560&bih=1368",
      "display_url" : "google.com\/search?q=rober\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350746942067843073",
  "text" : "Current status: https:\/\/t.co\/Wu0xXhQWa8 (via @becca_waxer)",
  "id" : 350746942067843073,
  "created_at" : "2013-06-28 22:46:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350744419743436800",
  "geo" : { },
  "id_str" : "350744707351064576",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 Just after BC here. Raided MC, BWL, Ony...only one relapse too. Glad to be rid of it.",
  "id" : 350744707351064576,
  "in_reply_to_status_id" : 350744419743436800,
  "created_at" : "2013-06-28 22:37:09 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350740276190523392",
  "geo" : { },
  "id_str" : "350744142952927232",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 Didn't know you played WoW. for some reason it all makes sense now...",
  "id" : 350744142952927232,
  "in_reply_to_status_id" : 350740276190523392,
  "created_at" : "2013-06-28 22:34:54 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3UAdoKZw7Q",
      "expanded_url" : "http:\/\/nickelcityruby.com\/",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "350711629903708160",
  "text" : "Conferences are like a Kickstarter campaign. You'll get a t-shirt, an actual deliverable, and help meet our goal! http:\/\/t.co\/3UAdoKZw7Q",
  "id" : 350711629903708160,
  "created_at" : "2013-06-28 20:25:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 0, 5 ],
      "id_str" : "819606",
      "id" : 819606
    }, {
      "name" : "Gu.\u3082\u3075\u304D\u3085\u3093",
      "screen_name" : "q0rt",
      "indices" : [ 6, 11 ],
      "id_str" : "1914393516",
      "id" : 1914393516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350684140301062147",
  "geo" : { },
  "id_str" : "350689646025523201",
  "in_reply_to_user_id" : 819606,
  "text" : "@janl @q0rt yes! thanks so much :D",
  "id" : 350689646025523201,
  "in_reply_to_status_id" : 350684140301062147,
  "created_at" : "2013-06-28 18:58:21 +0000",
  "in_reply_to_screen_name" : "janl",
  "in_reply_to_user_id_str" : "819606",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350682136845627393",
  "geo" : { },
  "id_str" : "350682618599186438",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH i still am not a fan of iced coffee. :\/",
  "id" : 350682618599186438,
  "in_reply_to_status_id" : 350682136845627393,
  "created_at" : "2013-06-28 18:30:26 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 0, 8 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350681460992262144",
  "geo" : { },
  "id_str" : "350681734863523841",
  "in_reply_to_user_id" : 20844341,
  "text" : "@patio11 So there's 39 other geeks guilting into you helping get yet another incrementally better item?",
  "id" : 350681734863523841,
  "in_reply_to_status_id" : 350681460992262144,
  "created_at" : "2013-06-28 18:26:55 +0000",
  "in_reply_to_screen_name" : "patio11",
  "in_reply_to_user_id_str" : "20844341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350681390142070785",
  "geo" : { },
  "id_str" : "350681513773371393",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH ...I just got it? I messed up dumping the grounds in.",
  "id" : 350681513773371393,
  "in_reply_to_status_id" : 350681390142070785,
  "created_at" : "2013-06-28 18:26:02 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/HhhgOfjw5o",
      "expanded_url" : "http:\/\/thedailywaster.files.wordpress.com\/2011\/12\/computer-fire.jpg",
      "display_url" : "thedailywaster.files.wordpress.com\/2011\/12\/comput\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350681326896152578",
  "text" : "Tiny red mite just crawled around my keyboard went into the air vent. http:\/\/t.co\/HhhgOfjw5o",
  "id" : 350681326896152578,
  "created_at" : "2013-06-28 18:25:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Women 2.0",
      "screen_name" : "women2",
      "indices" : [ 45, 52 ],
      "id_str" : "14410280",
      "id" : 14410280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/bGp7oZeHGR",
      "expanded_url" : "http:\/\/www.women2.com\/how-to-plan-a-diverse-conference\/",
      "display_url" : "women2.com\/how-to-plan-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350680778037936128",
  "text" : "My diverse conference post got syndicated on @women2! http:\/\/t.co\/bGp7oZeHGR",
  "id" : 350680778037936128,
  "created_at" : "2013-06-28 18:23:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350677358371545088",
  "geo" : { },
  "id_str" : "350678477315387392",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy 18g came out wonderfully.",
  "id" : 350678477315387392,
  "in_reply_to_status_id" : 350677358371545088,
  "created_at" : "2013-06-28 18:13:58 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/s8pEGnxrDO",
      "expanded_url" : "https:\/\/vine.co\/v\/hazadWbvOth",
      "display_url" : "vine.co\/v\/hazadWbvOth"
    } ]
  },
  "geo" : { },
  "id_str" : "350676965646270467",
  "text" : "It's aeropress time. https:\/\/t.co\/s8pEGnxrDO",
  "id" : 350676965646270467,
  "created_at" : "2013-06-28 18:07:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    }, {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 9, 17 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350659458474573827",
  "geo" : { },
  "id_str" : "350670895746002944",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain @paulehr Don't forget DWARF FORTRESS",
  "id" : 350670895746002944,
  "in_reply_to_status_id" : 350659458474573827,
  "created_at" : "2013-06-28 17:43:51 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Shelby",
      "screen_name" : "SteveSHX",
      "indices" : [ 0, 9 ],
      "id_str" : "520674524",
      "id" : 520674524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350635408494821378",
  "geo" : { },
  "id_str" : "350669798218272770",
  "in_reply_to_user_id" : 520674524,
  "text" : "@SteveSHX Awesome! I'd love to reach out to more usergroups, etc in the Toronto area given we're so close.",
  "id" : 350669798218272770,
  "in_reply_to_status_id" : 350635408494821378,
  "created_at" : "2013-06-28 17:39:29 +0000",
  "in_reply_to_screen_name" : "SteveSHX",
  "in_reply_to_user_id_str" : "520674524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350469379642765312",
  "geo" : { },
  "id_str" : "350469647797190656",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham same with git too and I\u2019m sure many other things.",
  "id" : 350469647797190656,
  "in_reply_to_status_id" : 350469379642765312,
  "created_at" : "2013-06-28 04:24:10 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 16, 29 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350468590971006976",
  "geo" : { },
  "id_str" : "350469415466307584",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda @moonpolysoft where\u2019s the harmonica?!",
  "id" : 350469415466307584,
  "in_reply_to_status_id" : 350468590971006976,
  "created_at" : "2013-06-28 04:23:14 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Underwood",
      "screen_name" : "davefp",
      "indices" : [ 0, 7 ],
      "id_str" : "17146704",
      "id" : 17146704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350423532175503360",
  "geo" : { },
  "id_str" : "350466865090412547",
  "in_reply_to_user_id" : 17146704,
  "text" : "@davefp if you have questions let me know!",
  "id" : 350466865090412547,
  "in_reply_to_status_id" : 350423532175503360,
  "created_at" : "2013-06-28 04:13:06 +0000",
  "in_reply_to_screen_name" : "davefp",
  "in_reply_to_user_id_str" : "17146704",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick thomson",
      "screen_name" : "importantshock",
      "indices" : [ 0, 15 ],
      "id_str" : "7611992",
      "id" : 7611992
    }, {
      "name" : "Zachary Drayer",
      "screen_name" : "zadr",
      "indices" : [ 16, 21 ],
      "id_str" : "7700222",
      "id" : 7700222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350464003954323456",
  "geo" : { },
  "id_str" : "350466683351220225",
  "in_reply_to_user_id" : 7611992,
  "text" : "@importantshock @zadr the original article is 10x more painful.",
  "id" : 350466683351220225,
  "in_reply_to_status_id" : 350464003954323456,
  "created_at" : "2013-06-28 04:12:23 +0000",
  "in_reply_to_screen_name" : "importantshock",
  "in_reply_to_user_id_str" : "7611992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/2bA9BVLhWr",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/cXA2GVoMe4",
      "expanded_url" : "https:\/\/www.honeybadger.io\/blog\/2013\/06\/25\/stop-using-rubygemsorg-in-production",
      "display_url" : "honeybadger.io\/blog\/2013\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350464564732768256",
  "text" : "Some scary http:\/\/t.co\/2bA9BVLhWr social engineering: https:\/\/t.co\/cXA2GVoMe4",
  "id" : 350464564732768256,
  "created_at" : "2013-06-28 04:03:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Searls",
      "screen_name" : "searls",
      "indices" : [ 0, 7 ],
      "id_str" : "9038902",
      "id" : 9038902
    }, {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 8, 19 ],
      "id_str" : "13893562",
      "id" : 13893562
    }, {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 20, 24 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 25, 36 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350456696235241474",
  "geo" : { },
  "id_str" : "350459662375718913",
  "in_reply_to_user_id" : 9038902,
  "text" : "@searls @joefiorini @lrz @RubyMotion yes, on the google group thread about it.",
  "id" : 350459662375718913,
  "in_reply_to_status_id" : 350456696235241474,
  "created_at" : "2013-06-28 03:44:29 +0000",
  "in_reply_to_screen_name" : "searls",
  "in_reply_to_user_id_str" : "9038902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350432921632518145",
  "geo" : { },
  "id_str" : "350433773881536513",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan adventure time\/frederator\u2019s is the same way. So good!",
  "id" : 350433773881536513,
  "in_reply_to_status_id" : 350432921632518145,
  "created_at" : "2013-06-28 02:01:37 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350417456612913152",
  "geo" : { },
  "id_str" : "350417841259937792",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene Most likely a serialization\/security problem...that class is a monster already.",
  "id" : 350417841259937792,
  "in_reply_to_status_id" : 350417456612913152,
  "created_at" : "2013-06-28 00:58:18 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/YXZPdxtMtP",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems\/blob\/master\/lib\/rubygems\/specification.rb#L23-L35",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350417105478361091",
  "geo" : { },
  "id_str" : "350417297296474112",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene As of RG 2.0 there's metadata, so sure! https:\/\/t.co\/YXZPdxtMtP",
  "id" : 350417297296474112,
  "in_reply_to_status_id" : 350417105478361091,
  "created_at" : "2013-06-28 00:56:08 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/frGd7eCIXl",
      "expanded_url" : "http:\/\/guides.rubygems.org\/specification-reference\/",
      "display_url" : "guides.rubygems.org\/specification-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350413399131308033",
  "geo" : { },
  "id_str" : "350416622193872896",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene license is already a field, same with version. Huh? http:\/\/t.co\/frGd7eCIXl",
  "id" : 350416622193872896,
  "in_reply_to_status_id" : 350413399131308033,
  "created_at" : "2013-06-28 00:53:27 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Warshak",
      "screen_name" : "iwarshak",
      "indices" : [ 0, 9 ],
      "id_str" : "892371",
      "id" : 892371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350415007047090176",
  "geo" : { },
  "id_str" : "350416451364065280",
  "in_reply_to_user_id" : 892371,
  "text" : "@iwarshak yep!",
  "id" : 350416451364065280,
  "in_reply_to_status_id" : 350415007047090176,
  "created_at" : "2013-06-28 00:52:47 +0000",
  "in_reply_to_screen_name" : "iwarshak",
  "in_reply_to_user_id_str" : "892371",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350400953050083328",
  "text" : "@juliepagano demand fulfilled, the rain stopped!",
  "id" : 350400953050083328,
  "created_at" : "2013-06-27 23:51:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "husky",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/pl2gO8MYZu",
      "expanded_url" : "https:\/\/vine.co\/v\/hzEUjqIFXtY",
      "display_url" : "vine.co\/v\/hzEUjqIFXtY"
    } ]
  },
  "geo" : { },
  "id_str" : "350400289423097856",
  "text" : "Typical #husky derpness. https:\/\/t.co\/pl2gO8MYZu",
  "id" : 350400289423097856,
  "created_at" : "2013-06-27 23:48:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "husky",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/bjaRt9DlYc",
      "expanded_url" : "https:\/\/vine.co\/v\/hzEFrnW03JO",
      "display_url" : "vine.co\/v\/hzEFrnW03JO"
    } ]
  },
  "geo" : { },
  "id_str" : "350399493507780608",
  "text" : "Romping about post rain storm. #husky https:\/\/t.co\/bjaRt9DlYc",
  "id" : 350399493507780608,
  "created_at" : "2013-06-27 23:45:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/4zbTEQDSbu",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10100306158742465&set=pb.24408547.-2207520000.1372374356.&type=3&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350389823070146561",
  "text" : "@juliepagano typically ends up like so: https:\/\/t.co\/4zbTEQDSbu",
  "id" : 350389823070146561,
  "created_at" : "2013-06-27 23:06:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "corey s",
      "screen_name" : "corey_schaf",
      "indices" : [ 0, 12 ],
      "id_str" : "208497212",
      "id" : 208497212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350388513436483590",
  "geo" : { },
  "id_str" : "350388715241222144",
  "in_reply_to_user_id" : 208497212,
  "text" : "@corey_schaf if you're just learning, stick with mysql or pg.",
  "id" : 350388715241222144,
  "in_reply_to_status_id" : 350388513436483590,
  "created_at" : "2013-06-27 23:02:34 +0000",
  "in_reply_to_screen_name" : "corey_schaf",
  "in_reply_to_user_id_str" : "208497212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Sansonetti",
      "screen_name" : "lrz",
      "indices" : [ 18, 22 ],
      "id_str" : "10452222",
      "id" : 10452222
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 27, 38 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350388649914933248",
  "text" : "Big thanks to the @lrz and @RubyMotion crew for continuing to kick ass.",
  "id" : 350388649914933248,
  "created_at" : "2013-06-27 23:02:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350381699655413760",
  "text" : "When is it going to snow again? For some reason I have a husky that only wants to go outside when it's pouring rain out.",
  "id" : 350381699655413760,
  "created_at" : "2013-06-27 22:34:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "indices" : [ 0, 15 ],
      "id_str" : "415345747",
      "id" : 415345747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350367084838006784",
  "geo" : { },
  "id_str" : "350369261409144834",
  "in_reply_to_user_id" : 415345747,
  "text" : "@parkerwightman going to the CO shows?",
  "id" : 350369261409144834,
  "in_reply_to_status_id" : 350367084838006784,
  "created_at" : "2013-06-27 21:45:16 +0000",
  "in_reply_to_screen_name" : "parkerwightman",
  "in_reply_to_user_id_str" : "415345747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/350365082389184515\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Hu5kzyRTxO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNy_L6YCAAAWSUK.jpg",
      "id_str" : "350365082397573120",
      "id" : 350365082397573120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNy_L6YCAAAWSUK.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/Hu5kzyRTxO"
    } ],
    "hashtags" : [ {
      "text" : "phish",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350365082389184515",
  "text" : "Easily the best thing to have happened today. #phish http:\/\/t.co\/Hu5kzyRTxO",
  "id" : 350365082389184515,
  "created_at" : "2013-06-27 21:28:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/q7rRVAIwrb",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Wax_sculpture",
      "display_url" : "en.wikipedia.org\/wiki\/Wax_sculp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350354391078936578",
  "geo" : { },
  "id_str" : "350355743968477185",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej \"The cost of making a wax sculpture can be between USD150,000 and 300,000.\" http:\/\/t.co\/q7rRVAIwrb",
  "id" : 350355743968477185,
  "in_reply_to_status_id" : 350354391078936578,
  "created_at" : "2013-06-27 20:51:33 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/YzDgNw6mh0",
      "expanded_url" : "https:\/\/gist.github.com\/qrush\/5879715",
      "display_url" : "gist.github.com\/qrush\/5879715"
    } ]
  },
  "in_reply_to_status_id_str" : "350337831186604032",
  "geo" : { },
  "id_str" : "350339096222244865",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene looks like a borked dependency record. not sure how or why that's messed up :S https:\/\/t.co\/YzDgNw6mh0",
  "id" : 350339096222244865,
  "in_reply_to_status_id" : 350337831186604032,
  "created_at" : "2013-06-27 19:45:24 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350337831186604032",
  "geo" : { },
  "id_str" : "350338289397542912",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene actually NewRelic should have it.",
  "id" : 350338289397542912,
  "in_reply_to_status_id" : 350337831186604032,
  "created_at" : "2013-06-27 19:42:11 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350336307635036162",
  "geo" : { },
  "id_str" : "350337677083688961",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene Not sure what's up there, sorry. I don't even know if we have an exception reporter hooked up :\/",
  "id" : 350337677083688961,
  "in_reply_to_status_id" : 350336307635036162,
  "created_at" : "2013-06-27 19:39:45 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350327391853363200",
  "text" : "Absolute Xcode meltdown today. Next time I upgrade OSX, I'm doing it on a completely separate box.",
  "id" : 350327391853363200,
  "created_at" : "2013-06-27 18:58:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350311644376743936",
  "geo" : { },
  "id_str" : "350311773796175872",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky Who trusted you with employees?",
  "id" : 350311773796175872,
  "in_reply_to_status_id" : 350311644376743936,
  "created_at" : "2013-06-27 17:56:50 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hoctor",
      "screen_name" : "kevinhoctor",
      "indices" : [ 0, 12 ],
      "id_str" : "6821372",
      "id" : 6821372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350249399345094657",
  "geo" : { },
  "id_str" : "350276563767541760",
  "in_reply_to_user_id" : 6821372,
  "text" : "@kevinhoctor it's like that at my in-laws in Ohio. Not a fan, I enjoy biking\/walking, especially in Elmwood Village.",
  "id" : 350276563767541760,
  "in_reply_to_status_id" : 350249399345094657,
  "created_at" : "2013-06-27 15:36:55 +0000",
  "in_reply_to_screen_name" : "kevinhoctor",
  "in_reply_to_user_id_str" : "6821372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hoctor",
      "screen_name" : "kevinhoctor",
      "indices" : [ 0, 12 ],
      "id_str" : "6821372",
      "id" : 6821372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350016786156101633",
  "geo" : { },
  "id_str" : "350105214960939010",
  "in_reply_to_user_id" : 6821372,
  "text" : "@kevinhoctor woot! :) North Tonawanda mostly here.",
  "id" : 350105214960939010,
  "in_reply_to_status_id" : 350016786156101633,
  "created_at" : "2013-06-27 04:16:02 +0000",
  "in_reply_to_screen_name" : "kevinhoctor",
  "in_reply_to_user_id_str" : "6821372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350104249209864193",
  "geo" : { },
  "id_str" : "350104820063014915",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza definitely. Very glad I already paid that down.",
  "id" : 350104820063014915,
  "in_reply_to_status_id" : 350104249209864193,
  "created_at" : "2013-06-27 04:14:28 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350035428268720128",
  "geo" : { },
  "id_str" : "350104108658724864",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh I hope they fix it. I\u2019m not good at profiling\/debugging objc yet.",
  "id" : 350104108658724864,
  "in_reply_to_status_id" : 350035428268720128,
  "created_at" : "2013-06-27 04:11:38 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 7, 15 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349998681937813505",
  "geo" : { },
  "id_str" : "349998794462593024",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @evanphx Agreed, init works.",
  "id" : 349998794462593024,
  "in_reply_to_status_id" : 349998681937813505,
  "created_at" : "2013-06-26 21:13:09 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Lawrence",
      "screen_name" : "boblaw",
      "indices" : [ 0, 7 ],
      "id_str" : "14348618",
      "id" : 14348618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349932105880461312",
  "geo" : { },
  "id_str" : "349997080384774145",
  "in_reply_to_user_id" : 14348618,
  "text" : "@boblaw we're all set on desks, thanks!",
  "id" : 349997080384774145,
  "in_reply_to_status_id" : 349932105880461312,
  "created_at" : "2013-06-26 21:06:21 +0000",
  "in_reply_to_screen_name" : "boblaw",
  "in_reply_to_user_id_str" : "14348618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 31, 37 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 48, 63 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 146, 147 ],
      "url" : "http:\/\/t.co\/C4TBJXVij3",
      "expanded_url" : "http:\/\/bit.ly\/1afBGkf",
      "display_url" : "bit.ly\/1afBGkf"
    } ]
  },
  "geo" : { },
  "id_str" : "349993012782313472",
  "text" : "RT @ashedryden: Super proud of @qrush &amp; the @nickelcityruby crew for thinking about diversity up front. Happy to have helped &lt;3 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 15, 21 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 32, 47 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/C4TBJXVij3",
        "expanded_url" : "http:\/\/bit.ly\/1afBGkf",
        "display_url" : "bit.ly\/1afBGkf"
      } ]
    },
    "geo" : { },
    "id_str" : "349992417908375554",
    "text" : "Super proud of @qrush &amp; the @nickelcityruby crew for thinking about diversity up front. Happy to have helped &lt;3 http:\/\/t.co\/C4TBJXVij3",
    "id" : 349992417908375554,
    "created_at" : "2013-06-26 20:47:49 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 349993012782313472,
  "created_at" : "2013-06-26 20:50:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Brown",
      "screen_name" : "beerlington",
      "indices" : [ 0, 12 ],
      "id_str" : "15999449",
      "id" : 15999449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349991192743776258",
  "geo" : { },
  "id_str" : "349991454631923712",
  "in_reply_to_user_id" : 15999449,
  "text" : "@beerlington I feel it doesn't get easy, and that's why it's worth it.",
  "id" : 349991454631923712,
  "in_reply_to_status_id" : 349991192743776258,
  "created_at" : "2013-06-26 20:43:59 +0000",
  "in_reply_to_screen_name" : "beerlington",
  "in_reply_to_user_id_str" : "15999449",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Booth Simone",
      "screen_name" : "aimee_simone",
      "indices" : [ 0, 13 ],
      "id_str" : "22692146",
      "id" : 22692146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349989942665027584",
  "geo" : { },
  "id_str" : "349990551879299073",
  "in_reply_to_user_id" : 22692146,
  "text" : "@aimee_simone Thanks! And I'll get on inventing that.",
  "id" : 349990551879299073,
  "in_reply_to_status_id" : 349989942665027584,
  "created_at" : "2013-06-26 20:40:24 +0000",
  "in_reply_to_screen_name" : "aimee_simone",
  "in_reply_to_user_id_str" : "22692146",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/bfmSfKehaV",
      "expanded_url" : "http:\/\/37svn.com\/3550",
      "display_url" : "37svn.com\/3550"
    } ]
  },
  "geo" : { },
  "id_str" : "349988449333415937",
  "text" : "A diverse conference: a tough topic I've been wrestling with for a while. http:\/\/t.co\/bfmSfKehaV",
  "id" : 349988449333415937,
  "created_at" : "2013-06-26 20:32:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349985854338514945",
  "geo" : { },
  "id_str" : "349987224810569728",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler Mayor's race is already getting stupid this year, no thanks.",
  "id" : 349987224810569728,
  "in_reply_to_status_id" : 349985854338514945,
  "created_at" : "2013-06-26 20:27:11 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349984585783853056",
  "geo" : { },
  "id_str" : "349985620510248961",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler SSHHHHHHHHH",
  "id" : 349985620510248961,
  "in_reply_to_status_id" : 349984585783853056,
  "created_at" : "2013-06-26 20:20:49 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349978870390325248",
  "text" : "We are approaching full capacity today @coworkbuffalo. Wednesdays!",
  "id" : 349978870390325248,
  "created_at" : "2013-06-26 19:53:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Hildner",
      "screen_name" : "shildner",
      "indices" : [ 0, 9 ],
      "id_str" : "16225196",
      "id" : 16225196
    }, {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 10, 22 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349963152198336512",
  "geo" : { },
  "id_str" : "349967562278313984",
  "in_reply_to_user_id" : 16225196,
  "text" : "@shildner @rocketslide fun fact: Geddy's name was Zeus before we got him.",
  "id" : 349967562278313984,
  "in_reply_to_status_id" : 349963152198336512,
  "created_at" : "2013-06-26 19:09:03 +0000",
  "in_reply_to_screen_name" : "shildner",
  "in_reply_to_user_id_str" : "16225196",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 0, 12 ],
      "id_str" : "10035582",
      "id" : 10035582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349960573162778624",
  "geo" : { },
  "id_str" : "349960984594628609",
  "in_reply_to_user_id" : 10035582,
  "text" : "@rocketslide Did you get a puppy!?",
  "id" : 349960984594628609,
  "in_reply_to_status_id" : 349960573162778624,
  "created_at" : "2013-06-26 18:42:55 +0000",
  "in_reply_to_screen_name" : "rocketslide",
  "in_reply_to_user_id_str" : "10035582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349948247818780676",
  "in_reply_to_user_id" : 570452845,
  "text" : "@UnclePhilsBlog What's the Connection from Buffalove is easily the best yet. Amazed this can get even better.",
  "id" : 349948247818780676,
  "created_at" : "2013-06-26 17:52:18 +0000",
  "in_reply_to_screen_name" : "UnclePhilsBlog",
  "in_reply_to_user_id_str" : "570452845",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 0, 6 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349941286133968897",
  "geo" : { },
  "id_str" : "349941550140239872",
  "in_reply_to_user_id" : 15062828,
  "text" : "@vrunt Not enough Donald on this podcast logo.",
  "id" : 349941550140239872,
  "in_reply_to_status_id" : 349941286133968897,
  "created_at" : "2013-06-26 17:25:41 +0000",
  "in_reply_to_screen_name" : "vrunt",
  "in_reply_to_user_id_str" : "15062828",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349912490534113281",
  "geo" : { },
  "id_str" : "349928383787958272",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath yank all versions, then anyone can push (but not overwrite the yanks)",
  "id" : 349928383787958272,
  "in_reply_to_status_id" : 349912490534113281,
  "created_at" : "2013-06-26 16:33:22 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 37, 49 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/YCxHO77k1G",
      "expanded_url" : "http:\/\/archive.org\/details\/AQ2013-06-21",
      "display_url" : "archive.org\/details\/AQ2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349915100620144642",
  "text" : "Daft Punk and Pink Floyd covers from @AqueousBand in this show. Unbelievably good. http:\/\/t.co\/YCxHO77k1G",
  "id" : 349915100620144642,
  "created_at" : "2013-06-26 15:40:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 12, 20 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349900894646697984",
  "geo" : { },
  "id_str" : "349901017510453249",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried @noahhlo This is like eating pizza with a fork.",
  "id" : 349901017510453249,
  "in_reply_to_status_id" : 349900894646697984,
  "created_at" : "2013-06-26 14:44:38 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phish",
      "screen_name" : "phish",
      "indices" : [ 24, 30 ],
      "id_str" : "14503997",
      "id" : 14503997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349900008126033920",
  "text" : "Less than 2 weeks until @Phish in TO, scored Page side tickets. Pumped!",
  "id" : 349900008126033920,
  "created_at" : "2013-06-26 14:40:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349893966604410881",
  "geo" : { },
  "id_str" : "349897469548703746",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair About to take the red pill this November...",
  "id" : 349897469548703746,
  "in_reply_to_status_id" : 349893966604410881,
  "created_at" : "2013-06-26 14:30:32 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 39, 54 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349897149254873089",
  "text" : "It's hard to state how happy I am with @nickelcityruby's diverse lineup and wide range of talks. I hope you'll join us in Buffalo this Sept!",
  "id" : 349897149254873089,
  "created_at" : "2013-06-26 14:29:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/349724702358511616\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/uslnCKJmCa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNp4w42CIAAR4t6.jpg",
      "id_str" : "349724702362705920",
      "id" : 349724702362705920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNp4w42CIAAR4t6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/uslnCKJmCa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349724702358511616",
  "text" : "The translucency in iOS7 is growing on me. Hard to get a feel from screenshots, you really need to try it. http:\/\/t.co\/uslnCKJmCa",
  "id" : 349724702358511616,
  "created_at" : "2013-06-26 03:04:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "psgsteve",
      "screen_name" : "psgsteve",
      "indices" : [ 0, 9 ],
      "id_str" : "14469221",
      "id" : 14469221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349722115144036352",
  "geo" : { },
  "id_str" : "349724033815818240",
  "in_reply_to_user_id" : 14469221,
  "text" : "@psgsteve my 4S' battery was terrible before.",
  "id" : 349724033815818240,
  "in_reply_to_status_id" : 349722115144036352,
  "created_at" : "2013-06-26 03:01:21 +0000",
  "in_reply_to_screen_name" : "psgsteve",
  "in_reply_to_user_id_str" : "14469221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349721369673601024",
  "text" : "Do apps take an ungodly amount of time to start on iOS7 or is it just me?",
  "id" : 349721369673601024,
  "created_at" : "2013-06-26 02:50:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Landers",
      "screen_name" : "bradleyland",
      "indices" : [ 3, 15 ],
      "id_str" : "18256709",
      "id" : 18256709
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/IZN9iqybHI",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "349616096262881281",
  "text" : "RT @bradleyland: Big kudos to @nickelcityruby for the diversity of their speaker line up: http:\/\/t.co\/IZN9iqybHI. Thank you for being aweso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 13, 28 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/IZN9iqybHI",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "349615900774764544",
    "text" : "Big kudos to @nickelcityruby for the diversity of their speaker line up: http:\/\/t.co\/IZN9iqybHI. Thank you for being awesome!",
    "id" : 349615900774764544,
    "created_at" : "2013-06-25 19:51:40 +0000",
    "user" : {
      "name" : "Brad Landers",
      "screen_name" : "bradleyland",
      "protected" : false,
      "id_str" : "18256709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520273878900158464\/86p_jnFJ_normal.jpeg",
      "id" : 18256709,
      "verified" : false
    }
  },
  "id" : 349616096262881281,
  "created_at" : "2013-06-25 19:52:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "indices" : [ 3, 14 ],
      "id_str" : "14390268",
      "id" : 14390268
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XS2Hp67bT2",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "349585087903436801",
  "text" : "RT @rachelober: I'm super excited to be speaking at @nickelcityruby about mentorship in the Ruby community! So many excellent topics: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 36, 51 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XS2Hp67bT2",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "349583780996063232",
    "text" : "I'm super excited to be speaking at @nickelcityruby about mentorship in the Ruby community! So many excellent topics: http:\/\/t.co\/XS2Hp67bT2",
    "id" : 349583780996063232,
    "created_at" : "2013-06-25 17:44:03 +0000",
    "user" : {
      "name" : "Rachel Ober",
      "screen_name" : "rachelober",
      "protected" : false,
      "id_str" : "14390268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321996605296640\/ekU7oNFN_normal.jpeg",
      "id" : 14390268,
      "verified" : false
    }
  },
  "id" : 349585087903436801,
  "created_at" : "2013-06-25 17:49:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not A Secretary",
      "screen_name" : "AndreaJessup",
      "indices" : [ 0, 13 ],
      "id_str" : "365732435",
      "id" : 365732435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349580617094152193",
  "geo" : { },
  "id_str" : "349583103272026112",
  "in_reply_to_user_id" : 365732435,
  "text" : "@AndreaJessup Yes! Videos yes, not sure about stream.",
  "id" : 349583103272026112,
  "in_reply_to_status_id" : 349580617094152193,
  "created_at" : "2013-06-25 17:41:21 +0000",
  "in_reply_to_screen_name" : "AndreaJessup",
  "in_reply_to_user_id_str" : "365732435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 13, 26 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349570640807870464",
  "text" : "@juliepagano @lindseybieda yeah, let's do this via email",
  "id" : 349570640807870464,
  "created_at" : "2013-06-25 16:51:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 13, 26 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349569743147114496",
  "text" : "@juliepagano @lindseybieda Speakers won't - we can transfer it if you'd like.",
  "id" : 349569743147114496,
  "created_at" : "2013-06-25 16:48:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toronto Ruby Brigade",
      "screen_name" : "torontorb",
      "indices" : [ 3, 13 ],
      "id_str" : "154543290",
      "id" : 154543290
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 46, 61 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349561272460771333",
  "text" : "RT @torontorb: Any TorontoRB members going to @nickelcityruby? Tickets are still available and it is close to home.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 31, 46 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349223345625116672",
    "text" : "Any TorontoRB members going to @nickelcityruby? Tickets are still available and it is close to home.",
    "id" : 349223345625116672,
    "created_at" : "2013-06-24 17:51:48 +0000",
    "user" : {
      "name" : "Toronto Ruby Brigade",
      "screen_name" : "torontorb",
      "protected" : false,
      "id_str" : "154543290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1213779446\/toronto_rb_logo_normal.jpg",
      "id" : 154543290,
      "verified" : false
    }
  },
  "id" : 349561272460771333,
  "created_at" : "2013-06-25 16:14:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 101, 116 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Kids Ruby",
      "screen_name" : "KidsRuby",
      "indices" : [ 117, 126 ],
      "id_str" : "238055076",
      "id" : 238055076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/FlDHZFZWRa",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#katie",
      "display_url" : "nickelcityruby.com\/#katie"
    } ]
  },
  "geo" : { },
  "id_str" : "349561142382821376",
  "text" : "RT @aspleenic: That's my girl - speaking at her first Ruby conference: http:\/\/t.co\/FlDHZFZWRa :) cc: @nickelcityruby @KidsRuby :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 86, 101 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Kids Ruby",
        "screen_name" : "KidsRuby",
        "indices" : [ 102, 111 ],
        "id_str" : "238055076",
        "id" : 238055076
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/FlDHZFZWRa",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#katie",
        "display_url" : "nickelcityruby.com\/#katie"
      } ]
    },
    "geo" : { },
    "id_str" : "349556197084504064",
    "text" : "That's my girl - speaking at her first Ruby conference: http:\/\/t.co\/FlDHZFZWRa :) cc: @nickelcityruby @KidsRuby :)",
    "id" : 349556197084504064,
    "created_at" : "2013-06-25 15:54:26 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 349561142382821376,
  "created_at" : "2013-06-25 16:14:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349559826738712576",
  "geo" : { },
  "id_str" : "349560496711667713",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier Thanks! :) going to come up?",
  "id" : 349560496711667713,
  "in_reply_to_status_id" : 349559826738712576,
  "created_at" : "2013-06-25 16:11:31 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 15, 28 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KpCv7A5Bz8",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3349-open-source-guilt-passion",
      "display_url" : "37signals.com\/svn\/posts\/3349\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "349556094923845632",
  "geo" : { },
  "id_str" : "349556875508981763",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein @olivierlacan the guilt, it kills me too :( http:\/\/t.co\/KpCv7A5Bz8",
  "id" : 349556875508981763,
  "in_reply_to_status_id" : 349556094923845632,
  "created_at" : "2013-06-25 15:57:08 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 30, 45 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ll3xurKNLB",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "349555005436592128",
  "text" : "We've chosen our speakers for @nickelcityruby! Really excited with how this turned out, and I hope to see you here!  http:\/\/t.co\/ll3xurKNLB",
  "id" : 349555005436592128,
  "created_at" : "2013-06-25 15:49:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ELasYXPtMQ",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
      "display_url" : "nickelcityruby.com\/#speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "349554737097617408",
  "text" : "RT @nickelcityruby: We are excited to announce the speaker lineup for NickelCityRuby 2013!! http:\/\/t.co\/ELasYXPtMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ELasYXPtMQ",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#speakers",
        "display_url" : "nickelcityruby.com\/#speakers"
      } ]
    },
    "geo" : { },
    "id_str" : "349553496560898048",
    "text" : "We are excited to announce the speaker lineup for NickelCityRuby 2013!! http:\/\/t.co\/ELasYXPtMQ",
    "id" : 349553496560898048,
    "created_at" : "2013-06-25 15:43:42 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 349554737097617408,
  "created_at" : "2013-06-25 15:48:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349542924960276481",
  "text" : "RT @vrunt: reminder that Edward Snowden = Eddard Stark + Jon Snow and the entire thing is a false flag operation that Obama paid GRRM to wr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349542778432274435",
    "text" : "reminder that Edward Snowden = Eddard Stark + Jon Snow and the entire thing is a false flag operation that Obama paid GRRM to write.",
    "id" : 349542778432274435,
    "created_at" : "2013-06-25 15:01:07 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 349542924960276481,
  "created_at" : "2013-06-25 15:01:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349540819889422337",
  "text" : "Two hours of iTunes Radio tuned to Umphrey's McGee, all different artists, no ads, built-in to iOS up\/downvoting. See ya Pandora.",
  "id" : 349540819889422337,
  "created_at" : "2013-06-25 14:53:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/tly4y9H0RB",
      "expanded_url" : "http:\/\/bit.ly\/17YasLB",
      "display_url" : "bit.ly\/17YasLB"
    } ]
  },
  "geo" : { },
  "id_str" : "349538481204244480",
  "text" : "RT @ashedryden: Gittip is becoming sustainable: people are earning as much as $1200\/month. http:\/\/t.co\/tly4y9H0RB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/tly4y9H0RB",
        "expanded_url" : "http:\/\/bit.ly\/17YasLB",
        "display_url" : "bit.ly\/17YasLB"
      } ]
    },
    "geo" : { },
    "id_str" : "349534902229811203",
    "text" : "Gittip is becoming sustainable: people are earning as much as $1200\/month. http:\/\/t.co\/tly4y9H0RB",
    "id" : 349534902229811203,
    "created_at" : "2013-06-25 14:29:49 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 349538481204244480,
  "created_at" : "2013-06-25 14:44:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/N2ALEQu1GL",
      "expanded_url" : "http:\/\/weblog.rubyonrails.org\/2013\/6\/25\/Rails-4-0-final\/",
      "display_url" : "weblog.rubyonrails.org\/2013\/6\/25\/Rail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349538249590583297",
  "text" : "RT @dhh: Rails 4.0.0: Final version released, http:\/\/t.co\/N2ALEQu1GL -- still love this framework after 10 years of working on it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/N2ALEQu1GL",
        "expanded_url" : "http:\/\/weblog.rubyonrails.org\/2013\/6\/25\/Rails-4-0-final\/",
        "display_url" : "weblog.rubyonrails.org\/2013\/6\/25\/Rail\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349536261414977536",
    "text" : "Rails 4.0.0: Final version released, http:\/\/t.co\/N2ALEQu1GL -- still love this framework after 10 years of working on it!",
    "id" : 349536261414977536,
    "created_at" : "2013-06-25 14:35:13 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 349538249590583297,
  "created_at" : "2013-06-25 14:43:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Thompson",
      "screen_name" : "keiththomps",
      "indices" : [ 0, 12 ],
      "id_str" : "142860206",
      "id" : 142860206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349261164645064704",
  "geo" : { },
  "id_str" : "349370851491196928",
  "in_reply_to_user_id" : 142860206,
  "text" : "@keiththomps we are still working through and waiting on a few, sorry",
  "id" : 349370851491196928,
  "in_reply_to_status_id" : 349261164645064704,
  "created_at" : "2013-06-25 03:37:56 +0000",
  "in_reply_to_screen_name" : "keiththomps",
  "in_reply_to_user_id_str" : "142860206",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 5, 20 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349237027000164356",
  "text" : "Best @nickelcityruby plans I've heard so far: \"I plan to survive on wings and beer I've never had the whole time.\"",
  "id" : 349237027000164356,
  "created_at" : "2013-06-24 18:46:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aqueous",
      "screen_name" : "AqueousBand",
      "indices" : [ 28, 40 ],
      "id_str" : "26904582",
      "id" : 26904582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/D2301pkUrl",
      "expanded_url" : "https:\/\/soundcloud.com\/unclephilsblog\/aqueous-give-life-back-to",
      "display_url" : "soundcloud.com\/unclephilsblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349235757589860354",
  "text" : "R.A.M. Daft Punk cover from @AqueousBand!? Plug it into my veins! https:\/\/t.co\/D2301pkUrl",
  "id" : 349235757589860354,
  "created_at" : "2013-06-24 18:41:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sascha",
      "screen_name" : "sascha_d",
      "indices" : [ 0, 9 ],
      "id_str" : "45573701",
      "id" : 45573701
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 10, 21 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349224124427689984",
  "geo" : { },
  "id_str" : "349225340280909826",
  "in_reply_to_user_id" : 45573701,
  "text" : "@sascha_d @ashedryden What. that's a pretty popular gem too...had no idea that's what it meant. &gt;:[",
  "id" : 349225340280909826,
  "in_reply_to_status_id" : 349224124427689984,
  "created_at" : "2013-06-24 17:59:44 +0000",
  "in_reply_to_screen_name" : "sascha_d",
  "in_reply_to_user_id_str" : "45573701",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Allison",
      "screen_name" : "jrallison",
      "indices" : [ 0, 10 ],
      "id_str" : "15716398",
      "id" : 15716398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349208524263403520",
  "geo" : { },
  "id_str" : "349210468155531265",
  "in_reply_to_user_id" : 15716398,
  "text" : "@jrallison we are still working!",
  "id" : 349210468155531265,
  "in_reply_to_status_id" : 349208524263403520,
  "created_at" : "2013-06-24 17:00:38 +0000",
  "in_reply_to_screen_name" : "jrallison",
  "in_reply_to_user_id_str" : "15716398",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349194323193102337",
  "text" : "RT @rubygems_status: Botched deploy has us down, we\u2019re working on it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349194212295720961",
    "text" : "Botched deploy has us down, we\u2019re working on it!",
    "id" : 349194212295720961,
    "created_at" : "2013-06-24 15:56:02 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 349194323193102337,
  "created_at" : "2013-06-24 15:56:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flip Sasser",
      "screen_name" : "flipsasser",
      "indices" : [ 0, 11 ],
      "id_str" : "9144132",
      "id" : 9144132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349189550939181057",
  "in_reply_to_user_id" : 9144132,
  "text" : "@flipsasser Just got hit by your paternity leave responder. Congrats, and mind checking your inbox quickly? :)",
  "id" : 349189550939181057,
  "created_at" : "2013-06-24 15:37:31 +0000",
  "in_reply_to_screen_name" : "flipsasser",
  "in_reply_to_user_id_str" : "9144132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hubbs",
      "screen_name" : "andrewhubbs",
      "indices" : [ 0, 12 ],
      "id_str" : "33947300",
      "id" : 33947300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349178147641638914",
  "geo" : { },
  "id_str" : "349184519112384512",
  "in_reply_to_user_id" : 33947300,
  "text" : "@andrewhubbs Ugh! Yeah the timer sucks. Let's do another, but set it to 7 days or more.",
  "id" : 349184519112384512,
  "in_reply_to_status_id" : 349178147641638914,
  "created_at" : "2013-06-24 15:17:31 +0000",
  "in_reply_to_screen_name" : "andrewhubbs",
  "in_reply_to_user_id_str" : "33947300",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349162586899615745",
  "text" : "RT @coworkbuffalo: Just a friendly reminder that we have wifi, coffee, and AIR CONDITIONING. Kind of excited about that last one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349162425200807937",
    "text" : "Just a friendly reminder that we have wifi, coffee, and AIR CONDITIONING. Kind of excited about that last one.",
    "id" : 349162425200807937,
    "created_at" : "2013-06-24 13:49:43 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 349162586899615745,
  "created_at" : "2013-06-24 13:50:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349035403061379072",
  "geo" : { },
  "id_str" : "349035579805138945",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 ah ha! Yeah I back filled articles from other sources I\u2019ve written. Forgot about the feed.",
  "id" : 349035579805138945,
  "in_reply_to_status_id" : 349035403061379072,
  "created_at" : "2013-06-24 05:25:41 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postmodern",
      "screen_name" : "postmodern_mod3",
      "indices" : [ 0, 16 ],
      "id_str" : "46852648",
      "id" : 46852648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/vnA9ih2pQf",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3432-why-i-loved-building-basecamp-for-iphone-in-rubymotion",
      "display_url" : "37signals.com\/svn\/posts\/3432\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "349033292093329408",
  "geo" : { },
  "id_str" : "349035226187567104",
  "in_reply_to_user_id" : 46852648,
  "text" : "@postmodern_mod3 where\u2019d that link come from? The article is here: http:\/\/t.co\/vnA9ih2pQf",
  "id" : 349035226187567104,
  "in_reply_to_status_id" : 349033292093329408,
  "created_at" : "2013-06-24 05:24:17 +0000",
  "in_reply_to_screen_name" : "postmodern_mod3",
  "in_reply_to_user_id_str" : "46852648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/JjTMy8AHMM",
      "expanded_url" : "http:\/\/i.imgur.com\/6bzXYwc.png",
      "display_url" : "i.imgur.com\/6bzXYwc.png"
    } ]
  },
  "geo" : { },
  "id_str" : "349027852085231616",
  "text" : "RT @steveklabnik: It's so plainly obvious when you put it like that: http:\/\/t.co\/JjTMy8AHMM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/JjTMy8AHMM",
        "expanded_url" : "http:\/\/i.imgur.com\/6bzXYwc.png",
        "display_url" : "i.imgur.com\/6bzXYwc.png"
      } ]
    },
    "geo" : { },
    "id_str" : "343141221587357697",
    "text" : "It's so plainly obvious when you put it like that: http:\/\/t.co\/JjTMy8AHMM",
    "id" : 343141221587357697,
    "created_at" : "2013-06-07 23:03:37 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 349027852085231616,
  "created_at" : "2013-06-24 04:54:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348849131244097537",
  "geo" : { },
  "id_str" : "348852183837577217",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman also don\u2019t forget the support queue that takes an hour or two to clear every so often. At least 1 gem delete req\/day :((",
  "id" : 348852183837577217,
  "in_reply_to_status_id" : 348849131244097537,
  "created_at" : "2013-06-23 17:16:56 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348851110255136770",
  "geo" : { },
  "id_str" : "348851902433353728",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman @evanphx call me biased (and I am!) but others have gotten involved and made changes happen recently. Make it so!",
  "id" : 348851902433353728,
  "in_reply_to_status_id" : 348851110255136770,
  "created_at" : "2013-06-23 17:15:49 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 52, 67 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 131, 139 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348848132211212292",
  "geo" : { },
  "id_str" : "348850176003293184",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman someone else needs to step in as lead. @nickelcityruby in Sept and my first due in Nov, I\u2019ll have even less time. \/cc @evanphx",
  "id" : 348850176003293184,
  "in_reply_to_status_id" : 348848132211212292,
  "created_at" : "2013-06-23 17:08:57 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348848132211212292",
  "geo" : { },
  "id_str" : "348848404090195968",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman it\u2019s been this way for years: high interest, low commitment. :(",
  "id" : 348848404090195968,
  "in_reply_to_status_id" : 348848132211212292,
  "created_at" : "2013-06-23 17:01:55 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348847279026868224",
  "geo" : { },
  "id_str" : "348848240520736770",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman the issues are barely half the story. Trello has most of it. I\u2019d rather see infrastructure improvements before any code fixes.",
  "id" : 348848240520736770,
  "in_reply_to_status_id" : 348847279026868224,
  "created_at" : "2013-06-23 17:01:16 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348847279026868224",
  "geo" : { },
  "id_str" : "348847843706028034",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman I\u2019m game for most improvements (not feature additions) but I lack the time to review, maintain, deploy.",
  "id" : 348847843706028034,
  "in_reply_to_status_id" : 348847279026868224,
  "created_at" : "2013-06-23 16:59:41 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 13, 24 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348847136567345152",
  "geo" : { },
  "id_str" : "348847415513731072",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman @tenderlove most likely. I won\u2019t have time to look through this for a few days.",
  "id" : 348847415513731072,
  "in_reply_to_status_id" : 348847136567345152,
  "created_at" : "2013-06-23 16:57:59 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Campbell",
      "screen_name" : "paulca",
      "indices" : [ 0, 7 ],
      "id_str" : "815973",
      "id" : 815973
    }, {
      "name" : "codemash",
      "screen_name" : "codemash",
      "indices" : [ 58, 67 ],
      "id_str" : "7469772",
      "id" : 7469772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348843607941341184",
  "geo" : { },
  "id_str" : "348846628892979200",
  "in_reply_to_user_id" : 815973,
  "text" : "@paulca another conf that weekend?!!? Starting to see why @codemash is in the middle of the winter.",
  "id" : 348846628892979200,
  "in_reply_to_status_id" : 348843607941341184,
  "created_at" : "2013-06-23 16:54:52 +0000",
  "in_reply_to_screen_name" : "paulca",
  "in_reply_to_user_id_str" : "815973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348845859712151554",
  "text" : "Dog barf smell.",
  "id" : 348845859712151554,
  "created_at" : "2013-06-23 16:51:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Freeman",
      "screen_name" : "karlfreeman",
      "indices" : [ 0, 12 ],
      "id_str" : "18452081",
      "id" : 18452081
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 13, 24 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/hAaxyFryyu",
      "expanded_url" : "https:\/\/trello.com\/board\/rubygems-org\/513f9634a7ed906115000755",
      "display_url" : "trello.com\/board\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "348826976901005313",
  "geo" : { },
  "id_str" : "348845348648787968",
  "in_reply_to_user_id" : 18452081,
  "text" : "@karlfreeman @tenderlove trello has most of what was on my head: https:\/\/t.co\/hAaxyFryyu",
  "id" : 348845348648787968,
  "in_reply_to_status_id" : 348826976901005313,
  "created_at" : "2013-06-23 16:49:47 +0000",
  "in_reply_to_screen_name" : "karlfreeman",
  "in_reply_to_user_id_str" : "18452081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348812532821139456",
  "text" : "Disney is continually killing it on the App Store. Impressive to see new apps consistently featured.",
  "id" : 348812532821139456,
  "created_at" : "2013-06-23 14:39:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Yusuke Endoh",
      "screen_name" : "mametter",
      "indices" : [ 12, 21 ],
      "id_str" : "58427169",
      "id" : 58427169
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 22, 30 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 31, 39 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348808543849291776",
  "geo" : { },
  "id_str" : "348809271972093952",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @mametter @drbrain @evanphx family, work, my business, and a conf to organize have zeroed out my OSS time. More need to step up.",
  "id" : 348809271972093952,
  "in_reply_to_status_id" : 348808543849291776,
  "created_at" : "2013-06-23 14:26:25 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348660978998726656",
  "geo" : { },
  "id_str" : "348661123643482112",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak oh dang that\u2019s awesome.",
  "id" : 348661123643482112,
  "in_reply_to_status_id" : 348660978998726656,
  "created_at" : "2013-06-23 04:37:44 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348658066394316803",
  "geo" : { },
  "id_str" : "348660790284394497",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak kiting wraiths is one of the most time consuming things :( also the AoE fire spell is so much fun. Zoo? Nuke it.",
  "id" : 348660790284394497,
  "in_reply_to_status_id" : 348658066394316803,
  "created_at" : "2013-06-23 04:36:24 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348657247024451584",
  "geo" : { },
  "id_str" : "348657763221643264",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak sick. I love Wizards, so much destruction.",
  "id" : 348657763221643264,
  "in_reply_to_status_id" : 348657247024451584,
  "created_at" : "2013-06-23 04:24:23 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/pAw0qswkWQ",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/wyR2KRCyrl",
      "expanded_url" : "http:\/\/e-pluribusunum.com\/2013\/06\/22\/why-the-way-the-healthcare-gov-exchange-was-built-matters\/",
      "display_url" : "e-pluribusunum.com\/2013\/06\/22\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348644960318406657",
  "text" : "Very happy to hear http:\/\/t.co\/pAw0qswkWQ uses Jekyll. OSS\u2019 reach is so deep, rewards are long term and unexpected. http:\/\/t.co\/wyR2KRCyrl",
  "id" : 348644960318406657,
  "created_at" : "2013-06-23 03:33:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "indices" : [ 3, 9 ],
      "id_str" : "2367111",
      "id" : 2367111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/LOxa8e1Tu9",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/5RpulhxUwK",
      "expanded_url" : "http:\/\/zite.to\/11vwLqG",
      "display_url" : "zite.to\/11vwLqG"
    } ]
  },
  "geo" : { },
  "id_str" : "348644149525889026",
  "text" : "RT @assaf: Open by design: Why the way the new http:\/\/t.co\/LOxa8e1Tu9 was built matters http:\/\/t.co\/5RpulhxUwK GH, Jekyll, prose.io",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/zite-personalized-magazine\/id419752338?mt=8&uo=4\" rel=\"nofollow\"\u003EZite Personalized Magazine\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/LOxa8e1Tu9",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      }, {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/5RpulhxUwK",
        "expanded_url" : "http:\/\/zite.to\/11vwLqG",
        "display_url" : "zite.to\/11vwLqG"
      } ]
    },
    "geo" : { },
    "id_str" : "348643376117198849",
    "text" : "Open by design: Why the way the new http:\/\/t.co\/LOxa8e1Tu9 was built matters http:\/\/t.co\/5RpulhxUwK GH, Jekyll, prose.io",
    "id" : 348643376117198849,
    "created_at" : "2013-06-23 03:27:13 +0000",
    "user" : {
      "name" : "Assaf",
      "screen_name" : "assaf",
      "protected" : false,
      "id_str" : "2367111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000045323076\/8355e0bb4b3b27a90ee35497cf8c34e5_normal.jpeg",
      "id" : 2367111,
      "verified" : false
    }
  },
  "id" : 348644149525889026,
  "created_at" : "2013-06-23 03:30:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348608302432784385",
  "text" : "Only in Buffalo would there be chicken wing, celery, and blue cheese mascots. Two wing flavors too.",
  "id" : 348608302432784385,
  "created_at" : "2013-06-23 01:07:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Nagelhout",
      "screen_name" : "goosesroost",
      "indices" : [ 0, 12 ],
      "id_str" : "21283898",
      "id" : 21283898
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 36, 49 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348579346782507008",
  "geo" : { },
  "id_str" : "348579928125616129",
  "in_reply_to_user_id" : 21283898,
  "text" : "@goosesroost BA BA BAAAAAAAAAAA \/cc @ChrisSmithAV",
  "id" : 348579928125616129,
  "in_reply_to_status_id" : 348579346782507008,
  "created_at" : "2013-06-22 23:15:05 +0000",
  "in_reply_to_screen_name" : "goosesroost",
  "in_reply_to_user_id_str" : "21283898",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348568334465388544",
  "geo" : { },
  "id_str" : "348572951844622336",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV what Star Wars character is that?",
  "id" : 348572951844622336,
  "in_reply_to_status_id" : 348568334465388544,
  "created_at" : "2013-06-22 22:47:22 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bisons",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348563519144337409",
  "text" : "Best costume so far: couple dressed as Tusken Raiders complete with rifles. And they were in single file. #Bisons",
  "id" : 348563519144337409,
  "created_at" : "2013-06-22 22:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Bisons",
      "screen_name" : "BuffaloBisons",
      "indices" : [ 3, 17 ],
      "id_str" : "20887902",
      "id" : 20887902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bisons",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "StarWarsNight",
      "indices" : [ 119, 133 ]
    }, {
      "text" : "DarkSide",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348562385608519681",
  "text" : "RT @BuffaloBisons: A healthy mixture of cheers and boos as Darth Vader tosses out the first pitch at tonight's #Bisons #StarWarsNight #Dark\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bisons",
        "indices" : [ 92, 99 ]
      }, {
        "text" : "StarWarsNight",
        "indices" : [ 100, 114 ]
      }, {
        "text" : "DarkSide",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348559880342351872",
    "text" : "A healthy mixture of cheers and boos as Darth Vader tosses out the first pitch at tonight's #Bisons #StarWarsNight #DarkSide",
    "id" : 348559880342351872,
    "created_at" : "2013-06-22 21:55:26 +0000",
    "user" : {
      "name" : "Buffalo Bisons",
      "screen_name" : "BuffaloBisons",
      "protected" : false,
      "id_str" : "20887902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000678942719\/06462fecd9d0f289a8b9b96839ddfb2e_normal.jpeg",
      "id" : 20887902,
      "verified" : false
    }
  },
  "id" : 348562385608519681,
  "created_at" : "2013-06-22 22:05:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348521028214996992",
  "geo" : { },
  "id_str" : "348557970705113088",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark experience bij.",
  "id" : 348557970705113088,
  "in_reply_to_status_id" : 348521028214996992,
  "created_at" : "2013-06-22 21:47:50 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 0, 7 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348553694297595904",
  "geo" : { },
  "id_str" : "348553962913402880",
  "in_reply_to_user_id" : 33493,
  "text" : "@peterc *whump*",
  "id" : 348553962913402880,
  "in_reply_to_status_id" : 348553694297595904,
  "created_at" : "2013-06-22 21:31:55 +0000",
  "in_reply_to_screen_name" : "peterc",
  "in_reply_to_user_id_str" : "33493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348552610392981504",
  "geo" : { },
  "id_str" : "348553887038447616",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer I\u2019ll upload some to Flickr later! :)",
  "id" : 348553887038447616,
  "in_reply_to_status_id" : 348552610392981504,
  "created_at" : "2013-06-22 21:31:37 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348551260384940032",
  "text" : "Star Wars night at minor league baseball in Buffalo tonight. Lots of very pleased cosplayers and kids having fun.",
  "id" : 348551260384940032,
  "created_at" : "2013-06-22 21:21:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/348470508947398656\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/fQ9hlevMn3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNYEFOUCYAIZV5W.jpg",
      "id_str" : "348470508955787266",
      "id" : 348470508955787266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNYEFOUCYAIZV5W.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fQ9hlevMn3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348470508947398656",
  "text" : "Just got this ancient warning screen with Tetris Attack on SNES. Original console and cart too! http:\/\/t.co\/fQ9hlevMn3",
  "id" : 348470508947398656,
  "created_at" : "2013-06-22 16:00:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/qlTtyXl5p9",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=bQgbSXBjpz0&feature=plcp",
      "display_url" : "m.youtube.com\/#\/watch?v=bQgb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "348441290230358016",
  "geo" : { },
  "id_str" : "348441786869501953",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @steveklabnik around this many http:\/\/t.co\/qlTtyXl5p9",
  "id" : 348441786869501953,
  "in_reply_to_status_id" : 348441290230358016,
  "created_at" : "2013-06-22 14:06:10 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 12, 25 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348439253849616386",
  "geo" : { },
  "id_str" : "348441158952841216",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @steveklabnik pfft, 5-10 is best :)",
  "id" : 348441158952841216,
  "in_reply_to_status_id" : 348439253849616386,
  "created_at" : "2013-06-22 14:03:40 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348435492154531840",
  "text" : "First Aeropress mug with Tonx. Feels like cheating.",
  "id" : 348435492154531840,
  "created_at" : "2013-06-22 13:41:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348434935146758145",
  "geo" : { },
  "id_str" : "348435303830286336",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade aviators make it.",
  "id" : 348435303830286336,
  "in_reply_to_status_id" : 348434935146758145,
  "created_at" : "2013-06-22 13:40:24 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lanyrd.com Alerts",
      "screen_name" : "lanyrdalert",
      "indices" : [ 3, 15 ],
      "id_str" : "198161488",
      "id" : 198161488
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 80, 89 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scotruby",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/wbOcrVDXtw",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    }, {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ymcAAGyQYS",
      "expanded_url" : "http:\/\/lanyrd.com\/schckb",
      "display_url" : "lanyrd.com\/schckb"
    } ]
  },
  "geo" : { },
  "id_str" : "348429502717771777",
  "text" : "RT @lanyrdalert: Video from \"Deathmatch: Bundler vs. http:\/\/t.co\/wbOcrVDXtw\" by @indirect http:\/\/t.co\/ymcAAGyQYS #scotruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/lanyrd.com\/\" rel=\"nofollow\"\u003ELanyrd (full access)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "literally misandr\u00E9",
        "screen_name" : "indirect",
        "indices" : [ 63, 72 ],
        "id_str" : "5674672",
        "id" : 5674672
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scotruby",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/wbOcrVDXtw",
        "expanded_url" : "http:\/\/Rubygems.org",
        "display_url" : "Rubygems.org"
      }, {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/ymcAAGyQYS",
        "expanded_url" : "http:\/\/lanyrd.com\/schckb",
        "display_url" : "lanyrd.com\/schckb"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 56.3789905938, -3.8341150026 ]
    },
    "id_str" : "347768319060873219",
    "text" : "Video from \"Deathmatch: Bundler vs. http:\/\/t.co\/wbOcrVDXtw\" by @indirect http:\/\/t.co\/ymcAAGyQYS #scotruby",
    "id" : 347768319060873219,
    "created_at" : "2013-06-20 17:30:03 +0000",
    "user" : {
      "name" : "Lanyrd.com Alerts",
      "screen_name" : "lanyrdalert",
      "protected" : false,
      "id_str" : "198161488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000047939995\/ca60ff3dec6e2538017032ea16e9d22f_normal.png",
      "id" : 198161488,
      "verified" : false
    }
  },
  "id" : 348429502717771777,
  "created_at" : "2013-06-22 13:17:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348418984850362368",
  "text" : "Rivals for Catan and Agricola on iOS?! *head explodes*",
  "id" : 348418984850362368,
  "created_at" : "2013-06-22 12:35:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 10, 19 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0wRYCK71LV",
      "expanded_url" : "http:\/\/finalphoenix.me\/blog\/2013\/06\/trip-report-openhack-phoenix\/",
      "display_url" : "finalphoenix.me\/blog\/2013\/06\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348416395677138945",
  "text" : "Phoenix\u2019s @OpenHack sounds like it went perfectly. So glad to see this happen in more cities! http:\/\/t.co\/0wRYCK71LV",
  "id" : 348416395677138945,
  "created_at" : "2013-06-22 12:25:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FinalPhoenix",
      "screen_name" : "FinalPhoenix",
      "indices" : [ 3, 16 ],
      "id_str" : "15140704",
      "id" : 15140704
    }, {
      "name" : "FinalPhoenix",
      "screen_name" : "FinalPhoenix",
      "indices" : [ 52, 65 ],
      "id_str" : "15140704",
      "id" : 15140704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/NuVStJmzjn",
      "expanded_url" : "http:\/\/finalphoenix.me\/blog\/2013\/06\/trip-report-openhack-phoenix\/",
      "display_url" : "finalphoenix.me\/blog\/2013\/06\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348416095083966466",
  "text" : "RT @FinalPhoenix: Trip Report: OpenHack Phoenix via @FinalPhoenix http:\/\/t.co\/NuVStJmzjn #openhack",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FinalPhoenix",
        "screen_name" : "FinalPhoenix",
        "indices" : [ 34, 47 ],
        "id_str" : "15140704",
        "id" : 15140704
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/NuVStJmzjn",
        "expanded_url" : "http:\/\/finalphoenix.me\/blog\/2013\/06\/trip-report-openhack-phoenix\/",
        "display_url" : "finalphoenix.me\/blog\/2013\/06\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348113179643109376",
    "text" : "Trip Report: OpenHack Phoenix via @FinalPhoenix http:\/\/t.co\/NuVStJmzjn #openhack",
    "id" : 348113179643109376,
    "created_at" : "2013-06-21 16:20:24 +0000",
    "user" : {
      "name" : "FinalPhoenix",
      "screen_name" : "FinalPhoenix",
      "protected" : false,
      "id_str" : "15140704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558532840493551616\/uwH3D6-2_normal.png",
      "id" : 15140704,
      "verified" : false
    }
  },
  "id" : 348416095083966466,
  "created_at" : "2013-06-22 12:24:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348157173500612608",
  "text" : "RT @vrunt: I Married An Axe Deodorant",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348155011794100224",
    "text" : "I Married An Axe Deodorant",
    "id" : 348155011794100224,
    "created_at" : "2013-06-21 19:06:37 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 348157173500612608,
  "created_at" : "2013-06-21 19:15:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 0, 7 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348124806891311104",
  "geo" : { },
  "id_str" : "348148772280360960",
  "in_reply_to_user_id" : 17055675,
  "text" : "@Adkron thanks for the shout out :)",
  "id" : 348148772280360960,
  "in_reply_to_status_id" : 348124806891311104,
  "created_at" : "2013-06-21 18:41:50 +0000",
  "in_reply_to_screen_name" : "Adkron",
  "in_reply_to_user_id_str" : "17055675",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 3, 10 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NickelCityRuby",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348148698133438465",
  "text" : "RT @Adkron: Talk proposal on Pairing not accepted for #NickelCityRuby, but you should go anyway.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NickelCityRuby",
        "indices" : [ 42, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348124806891311104",
    "text" : "Talk proposal on Pairing not accepted for #NickelCityRuby, but you should go anyway.",
    "id" : 348124806891311104,
    "created_at" : "2013-06-21 17:06:36 +0000",
    "user" : {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "protected" : false,
      "id_str" : "17055675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3485440049\/a0f1a8fd26883c905443be6b17091a43_normal.jpeg",
      "id" : 17055675,
      "verified" : false
    }
  },
  "id" : 348148698133438465,
  "created_at" : "2013-06-21 18:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348135336368537600",
  "text" : "Agricola game time counter sucks. Most likely going to be forced to forfeit a game thanks to sleeping when waiting to act.",
  "id" : 348135336368537600,
  "created_at" : "2013-06-21 17:48:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348131142056157184",
  "text" : "Vintage wool blazer, summer solstice, 80\u00B0 F out. Oops.",
  "id" : 348131142056157184,
  "created_at" : "2013-06-21 17:31:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 0, 12 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 13, 26 ],
      "id_str" : "14928483",
      "id" : 14928483
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 27, 38 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348120940015677440",
  "text" : "@juliepagano @lindseybieda @ashedryden Didn't expect so many. thanks and super pumped!",
  "id" : 348120940015677440,
  "created_at" : "2013-06-21 16:51:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348117848985579520",
  "text" : "RT @gabrielgironda: @qrush \n\nDear $person,\n\nIf you're making preparations \/ I feel bad for you son \/ I got 99 proposals \/ But your talk ain\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "348116640627568642",
    "geo" : { },
    "id_str" : "348117754211078145",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush \n\nDear $person,\n\nIf you're making preparations \/ I feel bad for you son \/ I got 99 proposals \/ But your talk aint one.\n\nHIT ME,\n\nNick",
    "id" : 348117754211078145,
    "in_reply_to_status_id" : 348116640627568642,
    "created_at" : "2013-06-21 16:38:34 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 348117848985579520,
  "created_at" : "2013-06-21 16:38:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 36, 51 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348116640627568642",
  "text" : "Starting to send out rejections for @nickelcityruby. We had to make a lot of tough choices: 10 spots and 99 proposals.",
  "id" : 348116640627568642,
  "created_at" : "2013-06-21 16:34:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Creenan",
      "screen_name" : "TommyCreenan",
      "indices" : [ 0, 13 ],
      "id_str" : "257495729",
      "id" : 257495729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348100664087412737",
  "geo" : { },
  "id_str" : "348103248365891585",
  "in_reply_to_user_id" : 257495729,
  "text" : "@TommyCreenan my apartment is like that. Not bizarre.",
  "id" : 348103248365891585,
  "in_reply_to_status_id" : 348100664087412737,
  "created_at" : "2013-06-21 15:40:56 +0000",
  "in_reply_to_screen_name" : "TommyCreenan",
  "in_reply_to_user_id_str" : "257495729",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 3, 14 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 134, 140 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FnC3Y3VBdZ",
      "expanded_url" : "http:\/\/www.kickstarter.com\/blog\/we-were-wrong",
      "display_url" : "kickstarter.com\/blog\/we-were-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348103152815439873",
  "text" : "RT @ellenchisa: Hi internet. Sorry to have been so quiet this week. Please read and share this, now. http:\/\/t.co\/FnC3Y3VBdZ About the @kick\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 118, 130 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/FnC3Y3VBdZ",
        "expanded_url" : "http:\/\/www.kickstarter.com\/blog\/we-were-wrong",
        "display_url" : "kickstarter.com\/blog\/we-were-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348100832153194497",
    "text" : "Hi internet. Sorry to have been so quiet this week. Please read and share this, now. http:\/\/t.co\/FnC3Y3VBdZ About the @kickstarter situation",
    "id" : 348100832153194497,
    "created_at" : "2013-06-21 15:31:20 +0000",
    "user" : {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "protected" : false,
      "id_str" : "14620776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468872839676698624\/Q9jgyAa0_normal.jpeg",
      "id" : 14620776,
      "verified" : false
    }
  },
  "id" : 348103152815439873,
  "created_at" : "2013-06-21 15:40:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "indices" : [ 3, 13 ],
      "id_str" : "1488886736",
      "id" : 1488886736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348090829006585856",
  "text" : "RT @PRISM_NSA: #FF EVERYONE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348086898750795776",
    "text" : "#FF EVERYONE",
    "id" : 348086898750795776,
    "created_at" : "2013-06-21 14:35:58 +0000",
    "user" : {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "protected" : false,
      "id_str" : "1488886736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3773956794\/9527309c6d84203cdb76911261035337_normal.jpeg",
      "id" : 1488886736,
      "verified" : false
    }
  },
  "id" : 348090829006585856,
  "created_at" : "2013-06-21 14:51:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/347933737817878529\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/XKJE4SkU3z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNQb5CBCMAAlR7h.png",
      "id_str" : "347933737822072832",
      "id" : 347933737822072832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNQb5CBCMAAlR7h.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/XKJE4SkU3z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347933737817878529",
  "text" : "RA\uF8FF\u0394 http:\/\/t.co\/XKJE4SkU3z",
  "id" : 347933737817878529,
  "created_at" : "2013-06-21 04:27:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347829922527592448",
  "geo" : { },
  "id_str" : "347845496229994496",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato i disagree, I just wish it was possible to be constructive.",
  "id" : 347845496229994496,
  "in_reply_to_status_id" : 347829922527592448,
  "created_at" : "2013-06-20 22:36:43 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Smith",
      "screen_name" : "fullsailor",
      "indices" : [ 0, 11 ],
      "id_str" : "14310973",
      "id" : 14310973
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 12, 25 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347838272812236802",
  "geo" : { },
  "id_str" : "347839707616522240",
  "in_reply_to_user_id" : 14310973,
  "text" : "@fullsailor @olivierlacan were you using the visual format syntax?",
  "id" : 347839707616522240,
  "in_reply_to_status_id" : 347838272812236802,
  "created_at" : "2013-06-20 22:13:43 +0000",
  "in_reply_to_screen_name" : "fullsailor",
  "in_reply_to_user_id_str" : "14310973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347829372197142528",
  "geo" : { },
  "id_str" : "347829614002978817",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato YAY you found another language to hate on!!",
  "id" : 347829614002978817,
  "in_reply_to_status_id" : 347829372197142528,
  "created_at" : "2013-06-20 21:33:36 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Johnson",
      "screen_name" : "commondream",
      "indices" : [ 0, 12 ],
      "id_str" : "2703041",
      "id" : 2703041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347784285488545794",
  "geo" : { },
  "id_str" : "347784512891150336",
  "in_reply_to_user_id" : 2703041,
  "text" : "@commondream I'm qrush if you want a challenge :)",
  "id" : 347784512891150336,
  "in_reply_to_status_id" : 347784285488545794,
  "created_at" : "2013-06-20 18:34:24 +0000",
  "in_reply_to_screen_name" : "commondream",
  "in_reply_to_user_id_str" : "2703041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strange Loop Conf",
      "screen_name" : "strangeloop_stl",
      "indices" : [ 0, 16 ],
      "id_str" : "28045502",
      "id" : 28045502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347783354311122945",
  "geo" : { },
  "id_str" : "347783984429801474",
  "in_reply_to_user_id" : 28045502,
  "text" : "@strangeloop_stl good to hear. lots of demand!",
  "id" : 347783984429801474,
  "in_reply_to_status_id" : 347783354311122945,
  "created_at" : "2013-06-20 18:32:18 +0000",
  "in_reply_to_screen_name" : "strangeloop_stl",
  "in_reply_to_user_id_str" : "28045502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347782211002585090",
  "geo" : { },
  "id_str" : "347782465768796161",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh it is, we're sending out acceptances\/rejections over the next few days.",
  "id" : 347782465768796161,
  "in_reply_to_status_id" : 347782211002585090,
  "created_at" : "2013-06-20 18:26:15 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 52, 57 ],
      "id_str" : "516875194",
      "id" : 516875194
    }, {
      "name" : "Strange Loop Conf",
      "screen_name" : "strangeloop_stl",
      "indices" : [ 59, 75 ],
      "id_str" : "28045502",
      "id" : 28045502
    }, {
      "name" : "Golden Gate RubyConf",
      "screen_name" : "gogaruco",
      "indices" : [ 77, 86 ],
      "id_str" : "19278778",
      "id" : 19278778
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 88, 103 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347779932044267520",
  "text" : "4 tech conferences (so far) on the weekend of 9\/20: @xoxo, @strangeloop_stl, @gogaruco, @nickelcityruby. D:",
  "id" : 347779932044267520,
  "created_at" : "2013-06-20 18:16:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347779491168391169",
  "text" : "RT @coworkbuffalo: On launch, we were happy to have ~4-5 people. These days, 9 is a pretty average day. Thanks for working with us. More ar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347775863833640962",
    "text" : "On launch, we were happy to have ~4-5 people. These days, 9 is a pretty average day. Thanks for working with us. More are welcome.",
    "id" : 347775863833640962,
    "created_at" : "2013-06-20 18:00:01 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 347779491168391169,
  "created_at" : "2013-06-20 18:14:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Roston",
      "screen_name" : "michaelroston",
      "indices" : [ 3, 17 ],
      "id_str" : "16194566",
      "id" : 16194566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/7ng0BxkxVk",
      "expanded_url" : "http:\/\/bit.ly\/15nCIDG",
      "display_url" : "bit.ly\/15nCIDG"
    } ]
  },
  "geo" : { },
  "id_str" : "347774417817968640",
  "text" : "RT @michaelroston: Here's my first Instagram video. The \"Cinema\" feature is actually pretty cool http:\/\/t.co\/7ng0BxkxVk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/7ng0BxkxVk",
        "expanded_url" : "http:\/\/bit.ly\/15nCIDG",
        "display_url" : "bit.ly\/15nCIDG"
      } ]
    },
    "geo" : { },
    "id_str" : "347769293456420865",
    "text" : "Here's my first Instagram video. The \"Cinema\" feature is actually pretty cool http:\/\/t.co\/7ng0BxkxVk",
    "id" : 347769293456420865,
    "created_at" : "2013-06-20 17:33:55 +0000",
    "user" : {
      "name" : "Michael Roston",
      "screen_name" : "michaelroston",
      "protected" : false,
      "id_str" : "16194566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3064799729\/c875d8626828a0510e7bdea2ea2be1ed_normal.jpeg",
      "id" : 16194566,
      "verified" : true
    }
  },
  "id" : 347774417817968640,
  "created_at" : "2013-06-20 17:54:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 36, 47 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Scott Upton",
      "screen_name" : "uptonic",
      "indices" : [ 48, 56 ],
      "id_str" : "14408469",
      "id" : 14408469
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/347773449005068288\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/a7BAZ2Ps7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOKG_qCcAAandK.jpg",
      "id_str" : "347773449009262592",
      "id" : 347773449009262592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOKG_qCcAAandK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 433
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 433
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 433
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a7BAZ2Ps7G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347773728777707520",
  "text" : "RT @asianmack: Designer trolling cc @jasonfried @uptonic http:\/\/t.co\/a7BAZ2Ps7G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Fried",
        "screen_name" : "jasonfried",
        "indices" : [ 21, 32 ],
        "id_str" : "14372143",
        "id" : 14372143
      }, {
        "name" : "Scott Upton",
        "screen_name" : "uptonic",
        "indices" : [ 33, 41 ],
        "id_str" : "14408469",
        "id" : 14408469
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/asianmack\/status\/347773449005068288\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/a7BAZ2Ps7G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOKG_qCcAAandK.jpg",
        "id_str" : "347773449009262592",
        "id" : 347773449009262592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOKG_qCcAAandK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/a7BAZ2Ps7G"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347773449005068288",
    "text" : "Designer trolling cc @jasonfried @uptonic http:\/\/t.co\/a7BAZ2Ps7G",
    "id" : 347773449005068288,
    "created_at" : "2013-06-20 17:50:26 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 347773728777707520,
  "created_at" : "2013-06-20 17:51:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/wMb4Rg9KLu",
      "expanded_url" : "https:\/\/www.gov.uk\/designprinciples",
      "display_url" : "gov.uk\/designprincipl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347746472000901120",
  "text" : "I would love to see US gov't (federal, state, local!) sites held to these standards: https:\/\/t.co\/wMb4Rg9KLu",
  "id" : 347746472000901120,
  "created_at" : "2013-06-20 16:03:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 40, 52 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347565837181407233",
  "text" : "Still glad I haven\u2019t given any money to @kickstarter. Such bullshit today and they deserve it.",
  "id" : 347565837181407233,
  "created_at" : "2013-06-20 04:05:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347560060207112192",
  "geo" : { },
  "id_str" : "347563767976050689",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes yeah you need to pluck out and animate specific constraints",
  "id" : 347563767976050689,
  "in_reply_to_status_id" : 347560060207112192,
  "created_at" : "2013-06-20 03:57:14 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Assemble Arizona",
      "screen_name" : "assembleAZ",
      "indices" : [ 3, 14 ],
      "id_str" : "1104842514",
      "id" : 1104842514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phx",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/h6ehnEAwHs",
      "expanded_url" : "http:\/\/openhack.github.io\/phoenix\/",
      "display_url" : "openhack.github.io\/phoenix\/"
    } ]
  },
  "geo" : { },
  "id_str" : "347561329890041857",
  "text" : "RT @assembleAZ: Don't forget: 1st OpenHack  #phx tomorrow: http:\/\/t.co\/h6ehnEAwHs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phx",
        "indices" : [ 28, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/h6ehnEAwHs",
        "expanded_url" : "http:\/\/openhack.github.io\/phoenix\/",
        "display_url" : "openhack.github.io\/phoenix\/"
      } ]
    },
    "geo" : { },
    "id_str" : "347556586723627008",
    "text" : "Don't forget: 1st OpenHack  #phx tomorrow: http:\/\/t.co\/h6ehnEAwHs",
    "id" : 347556586723627008,
    "created_at" : "2013-06-20 03:28:42 +0000",
    "user" : {
      "name" : "Assemble Arizona",
      "screen_name" : "assembleAZ",
      "protected" : false,
      "id_str" : "1104842514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3506882180\/53c734ad075ed48b1f2ebfb0f7c82c1a_normal.png",
      "id" : 1104842514,
      "verified" : false
    }
  },
  "id" : 347561329890041857,
  "created_at" : "2013-06-20 03:47:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347559147266506753",
  "geo" : { },
  "id_str" : "347561019457024000",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes the ascii format?",
  "id" : 347561019457024000,
  "in_reply_to_status_id" : 347559147266506753,
  "created_at" : "2013-06-20 03:46:19 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/DQG2LRgbfm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=jWNSTNwClQY",
      "display_url" : "youtube.com\/watch?v=jWNSTN\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347523821517025280",
  "geo" : { },
  "id_str" : "347526765247361026",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Bubs?! http:\/\/t.co\/DQG2LRgbfm",
  "id" : 347526765247361026,
  "in_reply_to_status_id" : 347523821517025280,
  "created_at" : "2013-06-20 01:30:12 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 41, 50 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347526428239212544",
  "text" : "RT @themcgruff: Oh yeah the one and only @mr_ndrsn joined the ops team today. Very excited for him to start soon!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Anderson",
        "screen_name" : "mr_ndrsn",
        "indices" : [ 25, 34 ],
        "id_str" : "774032401",
        "id" : 774032401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347524684675440640",
    "text" : "Oh yeah the one and only @mr_ndrsn joined the ops team today. Very excited for him to start soon!",
    "id" : 347524684675440640,
    "created_at" : "2013-06-20 01:21:56 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 347526428239212544,
  "created_at" : "2013-06-20 01:28:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Neilsen",
      "screen_name" : "localshred",
      "indices" : [ 0, 11 ],
      "id_str" : "243985301",
      "id" : 243985301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347514896969256963",
  "geo" : { },
  "id_str" : "347515077366251520",
  "in_reply_to_user_id" : 243985301,
  "text" : "@localshred check my mentions, deeper discussions going on alongside. Looks like they do but not for all apps.",
  "id" : 347515077366251520,
  "in_reply_to_status_id" : 347514896969256963,
  "created_at" : "2013-06-20 00:43:45 +0000",
  "in_reply_to_screen_name" : "localshred",
  "in_reply_to_user_id_str" : "243985301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lee",
      "screen_name" : "kastiglione",
      "indices" : [ 0, 12 ],
      "id_str" : "337785394",
      "id" : 337785394
    }, {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 39, 54 ],
      "id_str" : "13639982",
      "id" : 13639982
    }, {
      "name" : "Mateus",
      "screen_name" : "seanlilmateus",
      "indices" : [ 55, 69 ],
      "id_str" : "16103797",
      "id" : 16103797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347499614364106752",
  "geo" : { },
  "id_str" : "347500308815048705",
  "in_reply_to_user_id" : 337785394,
  "text" : "@kastiglione This is great to hear \/cc @MarkVillacampa @seanlilmateus",
  "id" : 347500308815048705,
  "in_reply_to_status_id" : 347499614364106752,
  "created_at" : "2013-06-19 23:45:04 +0000",
  "in_reply_to_screen_name" : "kastiglione",
  "in_reply_to_user_id_str" : "337785394",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Ringo",
      "screen_name" : "stevenringo",
      "indices" : [ 0, 12 ],
      "id_str" : "10702602",
      "id" : 10702602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347496755471998976",
  "geo" : { },
  "id_str" : "347498323554496513",
  "in_reply_to_user_id" : 10702602,
  "text" : "@stevenringo i'd expect more from Apple. Also, they aren't quiet about that fact at MS.",
  "id" : 347498323554496513,
  "in_reply_to_status_id" : 347496755471998976,
  "created_at" : "2013-06-19 23:37:11 +0000",
  "in_reply_to_screen_name" : "stevenringo",
  "in_reply_to_user_id_str" : "10702602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radek",
      "screen_name" : "radexp",
      "indices" : [ 0, 7 ],
      "id_str" : "107770370",
      "id" : 107770370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/gAeoyWba5k",
      "expanded_url" : "https:\/\/twitter.com\/MarkVillacampa\/status\/347476246042669057",
      "display_url" : "twitter.com\/MarkVillacampa\u2026"
    }, {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/TjVWBF6G6R",
      "expanded_url" : "https:\/\/twitter.com\/seanlilmateus\/status\/347478642223349760",
      "display_url" : "twitter.com\/seanlilmateus\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347495960190001152",
  "geo" : { },
  "id_str" : "347496101563224064",
  "in_reply_to_user_id" : 107770370,
  "text" : "@radexp https:\/\/t.co\/gAeoyWba5k https:\/\/t.co\/TjVWBF6G6R",
  "id" : 347496101563224064,
  "in_reply_to_status_id" : 347495960190001152,
  "created_at" : "2013-06-19 23:28:21 +0000",
  "in_reply_to_screen_name" : "radexp",
  "in_reply_to_user_id_str" : "107770370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347495297838112769",
  "text" : "So if Apple doesn't use IB for their own apps, why do they continue to push it? Such a confusing message.",
  "id" : 347495297838112769,
  "created_at" : "2013-06-19 23:25:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347477614316892160",
  "geo" : { },
  "id_str" : "347478451197997056",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 On my way!",
  "id" : 347478451197997056,
  "in_reply_to_status_id" : 347477614316892160,
  "created_at" : "2013-06-19 22:18:13 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347476246042669057",
  "geo" : { },
  "id_str" : "347476331698728960",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa how\u2019d you find that out?",
  "id" : 347476331698728960,
  "in_reply_to_status_id" : 347476246042669057,
  "created_at" : "2013-06-19 22:09:47 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Barone",
      "screen_name" : "buffalofoodie",
      "indices" : [ 3, 17 ],
      "id_str" : "190038945",
      "id" : 190038945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buffalo",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "buftruck",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/fMUbSOeiZU",
      "expanded_url" : "http:\/\/buffalofoodie.com\/buffalo-foodie-adventures\/first-ever-food-truck-rodeo-is-tonight\/",
      "display_url" : "buffalofoodie.com\/buffalo-foodie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347441086064623618",
  "text" : "RT @buffalofoodie: Come out for the Food Truck Rodeo tonight at the Historical Museum! 5-9 PM with 9 trucks!! http:\/\/t.co\/fMUbSOeiZU #Buffa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buffalo",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "buftruck",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/fMUbSOeiZU",
        "expanded_url" : "http:\/\/buffalofoodie.com\/buffalo-foodie-adventures\/first-ever-food-truck-rodeo-is-tonight\/",
        "display_url" : "buffalofoodie.com\/buffalo-foodie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347440609738518529",
    "text" : "Come out for the Food Truck Rodeo tonight at the Historical Museum! 5-9 PM with 9 trucks!! http:\/\/t.co\/fMUbSOeiZU #Buffalo #buftruck",
    "id" : 347440609738518529,
    "created_at" : "2013-06-19 19:47:51 +0000",
    "user" : {
      "name" : "Nina Barone",
      "screen_name" : "buffalofoodie",
      "protected" : false,
      "id_str" : "190038945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2876215449\/40dcefc69beac8aa66c7c26d37c8c9e1_normal.jpeg",
      "id" : 190038945,
      "verified" : false
    }
  },
  "id" : 347441086064623618,
  "created_at" : "2013-06-19 19:49:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fraser Speirs",
      "screen_name" : "fraserspeirs",
      "indices" : [ 3, 16 ],
      "id_str" : "644603",
      "id" : 644603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347429693617737728",
  "text" : "RT @fraserspeirs: The NDA for WWDC content seems a bit pointless when literally anyone in the world can access it with a free signup. Like \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347103540826734592",
    "text" : "The NDA for WWDC content seems a bit pointless when literally anyone in the world can access it with a free signup. Like padlocking a tent.",
    "id" : 347103540826734592,
    "created_at" : "2013-06-18 21:28:27 +0000",
    "user" : {
      "name" : "Fraser Speirs",
      "screen_name" : "fraserspeirs",
      "protected" : false,
      "id_str" : "644603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2514482031\/Headshot-Square-Twitter_normal.jpeg",
      "id" : 644603,
      "verified" : false
    }
  },
  "id" : 347429693617737728,
  "created_at" : "2013-06-19 19:04:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamal White",
      "screen_name" : "tamalw",
      "indices" : [ 0, 7 ],
      "id_str" : "10715872",
      "id" : 10715872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347396148425801730",
  "geo" : { },
  "id_str" : "347421551781634048",
  "in_reply_to_user_id" : 10715872,
  "text" : "@tamalw it's not really a bug, i feel - it's just how it works.",
  "id" : 347421551781634048,
  "in_reply_to_status_id" : 347396148425801730,
  "created_at" : "2013-06-19 18:32:07 +0000",
  "in_reply_to_screen_name" : "tamalw",
  "in_reply_to_user_id_str" : "10715872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 3, 18 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 78, 89 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "accessibility",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347418092156092419",
  "text" : "RT @AustinSeraphin: The @nickelcityruby conference accepted me to speak about @RubyMotion and #accessibility. Buffalo, New York, September \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 4, 19 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 58, 69 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "accessibility",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347416750670888960",
    "text" : "The @nickelcityruby conference accepted me to speak about @RubyMotion and #accessibility. Buffalo, New York, September 20-21.",
    "id" : 347416750670888960,
    "created_at" : "2013-06-19 18:13:02 +0000",
    "user" : {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "protected" : false,
      "id_str" : "16393800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/382052821\/cib8blue_normal.jpg",
      "id" : 16393800,
      "verified" : false
    }
  },
  "id" : 347418092156092419,
  "created_at" : "2013-06-19 18:18:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 0, 3 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347417721945862144",
  "geo" : { },
  "id_str" : "347417977467047937",
  "in_reply_to_user_id" : 755241,
  "text" : "@sd Plenty of high elevation here in Buffalo :)",
  "id" : 347417977467047937,
  "in_reply_to_status_id" : 347417721945862144,
  "created_at" : "2013-06-19 18:17:55 +0000",
  "in_reply_to_screen_name" : "sd",
  "in_reply_to_user_id_str" : "755241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347388805881397248",
  "text" : "Trying to fullscreen everything on 10.9. Main problem: Dragging things into windows is impossible. :(",
  "id" : 347388805881397248,
  "created_at" : "2013-06-19 16:22:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 3, 13 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/raganwald\/status\/347387820874297344\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qfGXSIFlVh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNIrYe7CcAAXp4u.jpg",
      "id_str" : "347387820878491648",
      "id" : 347387820878491648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNIrYe7CcAAXp4u.jpg",
      "sizes" : [ {
        "h" : 355,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 473
      } ],
      "display_url" : "pic.twitter.com\/qfGXSIFlVh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347387876499144706",
  "text" : "RT @raganwald: I'm launching a kickstarter to make a game that goes beyond solo programming to encompass team dynamics. http:\/\/t.co\/qfGXSIF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/raganwald\/status\/347387820874297344\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/qfGXSIFlVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNIrYe7CcAAXp4u.jpg",
        "id_str" : "347387820878491648",
        "id" : 347387820878491648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNIrYe7CcAAXp4u.jpg",
        "sizes" : [ {
          "h" : 355,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 473
        } ],
        "display_url" : "pic.twitter.com\/qfGXSIFlVh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347387820874297344",
    "text" : "I'm launching a kickstarter to make a game that goes beyond solo programming to encompass team dynamics. http:\/\/t.co\/qfGXSIFlVh",
    "id" : 347387820874297344,
    "created_at" : "2013-06-19 16:18:05 +0000",
    "user" : {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "protected" : false,
      "id_str" : "18137723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525649735856570368\/MvtI3PJj_normal.png",
      "id" : 18137723,
      "verified" : false
    }
  },
  "id" : 347387876499144706,
  "created_at" : "2013-06-19 16:18:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347386162106732544",
  "geo" : { },
  "id_str" : "347386650143367169",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 I could drop them off tomorrow evening if you guys are going to be at the space, I need to head to NT.",
  "id" : 347386650143367169,
  "in_reply_to_status_id" : 347386162106732544,
  "created_at" : "2013-06-19 16:13:26 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347353728539557888",
  "text" : "Just biked Delaware from Allen to Chippewa on the new bike lanes. So glad the city is putting in more bike lanes!",
  "id" : 347353728539557888,
  "created_at" : "2013-06-19 14:02:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347207035210829824",
  "geo" : { },
  "id_str" : "347231316384808961",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan agreed, didn\u2019t mean to turn it into that. My bad, a stupid decision on my part.",
  "id" : 347231316384808961,
  "in_reply_to_status_id" : 347207035210829824,
  "created_at" : "2013-06-19 05:56:11 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 3, 11 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347217924253171712",
  "text" : "RT @patio11: Programming is sort of like a jigsaw puzzle, but: Pieces move.  Sometimes you need to invent new pieces. Nobody shows you fini\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347190890143559681",
    "text" : "Programming is sort of like a jigsaw puzzle, but: Pieces move.  Sometimes you need to invent new pieces. Nobody shows you finished puzzle.",
    "id" : 347190890143559681,
    "created_at" : "2013-06-19 03:15:33 +0000",
    "user" : {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "protected" : false,
      "id_str" : "20844341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476049306072276993\/s9QMnPC5_normal.jpeg",
      "id" : 20844341,
      "verified" : false
    }
  },
  "id" : 347217924253171712,
  "created_at" : "2013-06-19 05:02:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347205489584660484",
  "geo" : { },
  "id_str" : "347206356920582144",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan so yes, a bit rash on my part, and I apologize for that. I just dislike the echo chamber that is \"move to the valley\"",
  "id" : 347206356920582144,
  "in_reply_to_status_id" : 347205489584660484,
  "created_at" : "2013-06-19 04:17:00 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347205099103346688",
  "geo" : { },
  "id_str" : "347205392469729281",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan there's no \"joining\", there's just participating - there's nothing negative about it. Seems like a lost opportunity if you don't",
  "id" : 347205392469729281,
  "in_reply_to_status_id" : 347205099103346688,
  "created_at" : "2013-06-19 04:13:10 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347204539100835841",
  "geo" : { },
  "id_str" : "347205122784382977",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan totally onboard with that, but I dislike the sentiment of \"nothing else exists so move here\"",
  "id" : 347205122784382977,
  "in_reply_to_status_id" : 347204539100835841,
  "created_at" : "2013-06-19 04:12:06 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347203855408300033",
  "geo" : { },
  "id_str" : "347204303905247232",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan :(",
  "id" : 347204303905247232,
  "in_reply_to_status_id" : 347203855408300033,
  "created_at" : "2013-06-19 04:08:51 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Rohde",
      "screen_name" : "rohdesign",
      "indices" : [ 0, 10 ],
      "id_str" : "816640",
      "id" : 816640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347203032188076033",
  "geo" : { },
  "id_str" : "347203315416842240",
  "in_reply_to_user_id" : 816640,
  "text" : "@rohdesign You should do a sketch of this and frame it.",
  "id" : 347203315416842240,
  "in_reply_to_status_id" : 347203032188076033,
  "created_at" : "2013-06-19 04:04:55 +0000",
  "in_reply_to_screen_name" : "rohdesign",
  "in_reply_to_user_id_str" : "816640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "Dan O'Leary",
      "screen_name" : "danieloleary",
      "indices" : [ 12, 25 ],
      "id_str" : "15013580",
      "id" : 15013580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347201107350675457",
  "geo" : { },
  "id_str" : "347203103931658241",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan @danieloleary Agreed, the valley is bullshit. You can be happy anywhere if you MAKE IT SO!",
  "id" : 347203103931658241,
  "in_reply_to_status_id" : 347201107350675457,
  "created_at" : "2013-06-19 04:04:05 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347194340776476672",
  "geo" : { },
  "id_str" : "347194570267840513",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan sure sounds like complaining.",
  "id" : 347194570267840513,
  "in_reply_to_status_id" : 347194340776476672,
  "created_at" : "2013-06-19 03:30:10 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paddy",
      "screen_name" : "paddyforan",
      "indices" : [ 0, 11 ],
      "id_str" : "15445975",
      "id" : 15445975
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 39, 53 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347193396332486656",
  "geo" : { },
  "id_str" : "347193908947718144",
  "in_reply_to_user_id" : 15445975,
  "text" : "@paddyforan we just had ~20+ people at @coworkbuffalo for Python and OpenHack. Where were you?",
  "id" : 347193908947718144,
  "in_reply_to_status_id" : 347193396332486656,
  "created_at" : "2013-06-19 03:27:33 +0000",
  "in_reply_to_screen_name" : "paddyforan",
  "in_reply_to_user_id_str" : "15445975",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 24, 39 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347179843772899329",
  "text" : "Extremely happy how the @nickelcityruby talk selection went. Blinding works.",
  "id" : 347179843772899329,
  "created_at" : "2013-06-19 02:31:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 31, 46 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347154670143275008",
  "text" : "I see some white smoke for the @nickelcityruby conclave...",
  "id" : 347154670143275008,
  "created_at" : "2013-06-19 00:51:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wanstrath",
      "screen_name" : "defunkt",
      "indices" : [ 0, 8 ],
      "id_str" : "713263",
      "id" : 713263
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 9, 20 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347088892442320896",
  "geo" : { },
  "id_str" : "347119399574048768",
  "in_reply_to_user_id" : 713263,
  "text" : "@defunkt @trevorturk Mavericks has a sweet new special characters chooser though!",
  "id" : 347119399574048768,
  "in_reply_to_status_id" : 347088892442320896,
  "created_at" : "2013-06-18 22:31:28 +0000",
  "in_reply_to_screen_name" : "defunkt",
  "in_reply_to_user_id_str" : "713263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    }, {
      "name" : "Rebecca Murphey",
      "screen_name" : "rmurphey",
      "indices" : [ 10, 19 ],
      "id_str" : "6490602",
      "id" : 6490602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347118003193790464",
  "geo" : { },
  "id_str" : "347118281171288064",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen @rmurphey CoffeeScript has this fixed with the existential operator and ?=",
  "id" : 347118281171288064,
  "in_reply_to_status_id" : 347118003193790464,
  "created_at" : "2013-06-18 22:27:02 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 72, 81 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/YvQoeFuBaU",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/groups\/python-buffalo",
      "display_url" : "nextplex.com\/buffalo-ny\/gro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347113446288015360",
  "text" : "RT @coworkbuffalo: 15+ folks here for Python Buffalo, then rolling into @OpenHack! http:\/\/t.co\/YvQoeFuBaU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 53, 62 ],
        "id_str" : "715440464",
        "id" : 715440464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/YvQoeFuBaU",
        "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/groups\/python-buffalo",
        "display_url" : "nextplex.com\/buffalo-ny\/gro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347112925145755650",
    "text" : "15+ folks here for Python Buffalo, then rolling into @OpenHack! http:\/\/t.co\/YvQoeFuBaU",
    "id" : 347112925145755650,
    "created_at" : "2013-06-18 22:05:45 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 347113446288015360,
  "created_at" : "2013-06-18 22:07:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nagel",
      "screen_name" : "ericnagel",
      "indices" : [ 0, 10 ],
      "id_str" : "2522211",
      "id" : 2522211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/whX9pgLiHj",
      "expanded_url" : "http:\/\/gmailblog.blogspot.com\/2013\/05\/take-action-right-from-inbox.html",
      "display_url" : "gmailblog.blogspot.com\/2013\/05\/take-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347067878350139392",
  "geo" : { },
  "id_str" : "347068146215186433",
  "in_reply_to_user_id" : 2522211,
  "text" : "@ericnagel http:\/\/t.co\/whX9pgLiHj",
  "id" : 347068146215186433,
  "in_reply_to_status_id" : 347067878350139392,
  "created_at" : "2013-06-18 19:07:48 +0000",
  "in_reply_to_screen_name" : "ericnagel",
  "in_reply_to_user_id_str" : "2522211",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/rWeq8ZWi5Z",
      "expanded_url" : "http:\/\/i.imgur.com\/2MDjSCh.jpg",
      "display_url" : "i.imgur.com\/2MDjSCh.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "347065170528448512",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski did they hire you at CNN yet? http:\/\/t.co\/rWeq8ZWi5Z",
  "id" : 347065170528448512,
  "created_at" : "2013-06-18 18:55:59 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Pyxhp2GY0V",
      "expanded_url" : "http:\/\/nshipster.com\/",
      "display_url" : "nshipster.com"
    }, {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/AZB1YbPtO4",
      "expanded_url" : "http:\/\/gitready.com",
      "display_url" : "gitready.com"
    } ]
  },
  "geo" : { },
  "id_str" : "347057316719386624",
  "text" : "What are some other sites like http:\/\/t.co\/Pyxhp2GY0V and http:\/\/t.co\/AZB1YbPtO4 ? Short, informative, learning tech\/code.",
  "id" : 347057316719386624,
  "created_at" : "2013-06-18 18:24:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Nikki Lee",
      "screen_name" : "nkkl",
      "indices" : [ 12, 17 ],
      "id_str" : "22096585",
      "id" : 22096585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347039378801033216",
  "geo" : { },
  "id_str" : "347039805953167360",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa @nkkl imo programming\/software is more of a craft that needs to be practiced, not regulated - not all coding matches this though",
  "id" : 347039805953167360,
  "in_reply_to_status_id" : 347039378801033216,
  "created_at" : "2013-06-18 17:15:12 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347039071220154368",
  "text" : "The use of \"Engineer\" in software is such a joke compared to \"Real\" Engineering. (and I have a BS in Software Engineering)",
  "id" : 347039071220154368,
  "created_at" : "2013-06-18 17:12:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347038858573135872",
  "text" : "TIL there are \"Typographic Engineers\" employed at Apple.",
  "id" : 347038858573135872,
  "created_at" : "2013-06-18 17:11:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/qsR4UdimIP",
      "expanded_url" : "http:\/\/theoatmeal.com\/comics\/working_home",
      "display_url" : "theoatmeal.com\/comics\/working\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347020235548786692",
  "geo" : { },
  "id_str" : "347020414549123072",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 http:\/\/t.co\/qsR4UdimIP",
  "id" : 347020414549123072,
  "in_reply_to_status_id" : 347020235548786692,
  "created_at" : "2013-06-18 15:58:08 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Rice",
      "screen_name" : "rtphokie",
      "indices" : [ 3, 12 ],
      "id_str" : "16207462",
      "id" : 16207462
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rtphokie\/status\/346361320674824192\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6MapgujuJv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM6FyTsCEAASma0.jpg",
      "id_str" : "346361320679018496",
      "id" : 346361320679018496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM6FyTsCEAASma0.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 729
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6MapgujuJv"
    } ],
    "hashtags" : [ {
      "text" : "ISS",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346940467625213952",
  "text" : "RT @rtphokie: Beautiful daytime shot of the #ISS  transiting the moon yesterday by Maximilian Teodorescu in Romania http:\/\/t.co\/6MapgujuJv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rtphokie\/status\/346361320674824192\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/6MapgujuJv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BM6FyTsCEAASma0.jpg",
        "id_str" : "346361320679018496",
        "id" : 346361320679018496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM6FyTsCEAASma0.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 729
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6MapgujuJv"
      } ],
      "hashtags" : [ {
        "text" : "ISS",
        "indices" : [ 30, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346361320674824192",
    "text" : "Beautiful daytime shot of the #ISS  transiting the moon yesterday by Maximilian Teodorescu in Romania http:\/\/t.co\/6MapgujuJv",
    "id" : 346361320674824192,
    "created_at" : "2013-06-16 20:19:08 +0000",
    "user" : {
      "name" : "Tony Rice",
      "screen_name" : "rtphokie",
      "protected" : false,
      "id_str" : "16207462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560551321707618304\/RGly8uh1_normal.jpeg",
      "id" : 16207462,
      "verified" : false
    }
  },
  "id" : 346940467625213952,
  "created_at" : "2013-06-18 10:40:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346927635286347776",
  "text" : "Might just be me waking up at 5am, but I was completely confused with the new github repo design without the commits tab :(",
  "id" : 346927635286347776,
  "created_at" : "2013-06-18 09:49:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 60, 71 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/6Ks9F6yeTl",
      "expanded_url" : "http:\/\/gawker.com\/internet-famous-preteen-metalheads-are-being-bullied-fo-513780506",
      "display_url" : "gawker.com\/internet-famou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346844547017486336",
  "text" : "The most metal kids in America: http:\/\/t.co\/6Ks9F6yeTl (via @shellscape)",
  "id" : 346844547017486336,
  "created_at" : "2013-06-18 04:19:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/8oi1ZdcmvG",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/comments\/6nc1h\/im_in_college_and_i_want_to_contribute_to_an_oss\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "346839873145159681",
  "geo" : { },
  "id_str" : "346843047000145920",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman http:\/\/t.co\/8oi1ZdcmvG",
  "id" : 346843047000145920,
  "in_reply_to_status_id" : 346839873145159681,
  "created_at" : "2013-06-18 04:13:21 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346841721256165379",
  "geo" : { },
  "id_str" : "346842597928620034",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv him swearing is the best. More Klingons should.",
  "id" : 346842597928620034,
  "in_reply_to_status_id" : 346841721256165379,
  "created_at" : "2013-06-18 04:11:34 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "indices" : [ 3, 10 ],
      "id_str" : "38003",
      "id" : 38003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/4vb8Maf3M4",
      "expanded_url" : "http:\/\/youtu.be\/3Ckza8etIgM",
      "display_url" : "youtu.be\/3Ckza8etIgM"
    } ]
  },
  "geo" : { },
  "id_str" : "346839108305432576",
  "text" : "RT @gedeon: Star Trek Next Generation Best of Both Worlds Bloopers! http:\/\/t.co\/4vb8Maf3M4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/4vb8Maf3M4",
        "expanded_url" : "http:\/\/youtu.be\/3Ckza8etIgM",
        "display_url" : "youtu.be\/3Ckza8etIgM"
      } ]
    },
    "geo" : { },
    "id_str" : "346815794111451136",
    "text" : "Star Trek Next Generation Best of Both Worlds Bloopers! http:\/\/t.co\/4vb8Maf3M4",
    "id" : 346815794111451136,
    "created_at" : "2013-06-18 02:25:03 +0000",
    "user" : {
      "name" : "Ged Maheux",
      "screen_name" : "gedeon",
      "protected" : false,
      "id_str" : "38003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547523557995974656\/nVfp39Lu_normal.png",
      "id" : 38003,
      "verified" : false
    }
  },
  "id" : 346839108305432576,
  "created_at" : "2013-06-18 03:57:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 0, 11 ],
      "id_str" : "103914540",
      "id" : 103914540
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 23, 32 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346802503683297281",
  "geo" : { },
  "id_str" : "346803255982051328",
  "in_reply_to_user_id" : 103914540,
  "text" : "@samkottler PUNKED \/cc @indirect",
  "id" : 346803255982051328,
  "in_reply_to_status_id" : 346802503683297281,
  "created_at" : "2013-06-18 01:35:14 +0000",
  "in_reply_to_screen_name" : "samkottler",
  "in_reply_to_user_id_str" : "103914540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346796600640811009",
  "geo" : { },
  "id_str" : "346803173811429376",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 I think one turn lane, one on either side",
  "id" : 346803173811429376,
  "in_reply_to_status_id" : 346796600640811009,
  "created_at" : "2013-06-18 01:34:54 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346793688288092160",
  "text" : "Confirmed: bike lanes chalked out on Delaware Ave!!!",
  "id" : 346793688288092160,
  "created_at" : "2013-06-18 00:57:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robb Kidd",
      "screen_name" : "robbkidd",
      "indices" : [ 0, 9 ],
      "id_str" : "60212114",
      "id" : 60212114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/gQQuVoKOQp",
      "expanded_url" : "http:\/\/wnyheritagepress.org\/photos_week_2008\/erie_savings_bank\/erie_savings_bank.htm",
      "display_url" : "wnyheritagepress.org\/photos_week_20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "346744504017092608",
  "geo" : { },
  "id_str" : "346745018138103808",
  "in_reply_to_user_id" : 60212114,
  "text" : "@robbkidd :( http:\/\/t.co\/gQQuVoKOQp",
  "id" : 346745018138103808,
  "in_reply_to_status_id" : 346744504017092608,
  "created_at" : "2013-06-17 21:43:49 +0000",
  "in_reply_to_screen_name" : "robbkidd",
  "in_reply_to_user_id_str" : "60212114",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346739243202277376",
  "geo" : { },
  "id_str" : "346739610140962816",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz city looks completely different, it's sad. There's some great statues in that intersection now that make no sense now :\/",
  "id" : 346739610140962816,
  "in_reply_to_status_id" : 346739243202277376,
  "created_at" : "2013-06-17 21:22:19 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/hCHLSOOyAU",
      "expanded_url" : "http:\/\/wnyheritagepress.org\/photos_week_2004\/shelton_square\/shelton_square.htm",
      "display_url" : "wnyheritagepress.org\/photos_week_20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346738396007387137",
  "text" : "A bit of Buffalo history: What was a pedestrian square\/trolley turnaround, now a data center\/empty mall. http:\/\/t.co\/hCHLSOOyAU",
  "id" : 346738396007387137,
  "created_at" : "2013-06-17 21:17:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0z3dqXbcAs",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/technology\/2013\/06\/data-center-next-door\/5906\/",
      "display_url" : "theatlanticcities.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346737458014208000",
  "text" : "Awesome story about turning a run down mall in downtown Buffalo into a data center: http:\/\/t.co\/0z3dqXbcAs",
  "id" : 346737458014208000,
  "created_at" : "2013-06-17 21:13:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Ordonez",
      "screen_name" : "tomordonez",
      "indices" : [ 0, 11 ],
      "id_str" : "253121529",
      "id" : 253121529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346733749314134017",
  "geo" : { },
  "id_str" : "346736181532303360",
  "in_reply_to_user_id" : 253121529,
  "text" : "@tomordonez we wanted docs to work on mobile, links to actually work, and better version compares.",
  "id" : 346736181532303360,
  "in_reply_to_status_id" : 346733749314134017,
  "created_at" : "2013-06-17 21:08:42 +0000",
  "in_reply_to_screen_name" : "tomordonez",
  "in_reply_to_user_id_str" : "253121529",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346734856107077634",
  "geo" : { },
  "id_str" : "346735690144428032",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa the recent articles about the stack rankings at MS just made me extremely sad for people that have to deal with such bullshit.",
  "id" : 346735690144428032,
  "in_reply_to_status_id" : 346734856107077634,
  "created_at" : "2013-06-17 21:06:45 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346734856107077634",
  "geo" : { },
  "id_str" : "346735513136398336",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa oh, you mean like it's actually focused on improving your lot and not attempting to fill a cog in a bureaucracy?",
  "id" : 346735513136398336,
  "in_reply_to_status_id" : 346734856107077634,
  "created_at" : "2013-06-17 21:06:03 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346714745799323648",
  "geo" : { },
  "id_str" : "346723712634073090",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh It's hard to pick one! Just lots of explaining.",
  "id" : 346723712634073090,
  "in_reply_to_status_id" : 346714745799323648,
  "created_at" : "2013-06-17 20:19:09 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346722093674659842",
  "text" : "RT @dhh: I'm not ashamed to admit that Reddit is one of my favorite things on the internet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346718986811092992",
    "text" : "I'm not ashamed to admit that Reddit is one of my favorite things on the internet.",
    "id" : 346718986811092992,
    "created_at" : "2013-06-17 20:00:22 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 346722093674659842,
  "created_at" : "2013-06-17 20:12:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 29, 39 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346713330163015680",
  "text" : "It's my day on support today @37signals. I love getting into the trenches and helping our customers out directly.",
  "id" : 346713330163015680,
  "created_at" : "2013-06-17 19:37:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 0, 9 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 113, 128 ],
      "id_str" : "130242651",
      "id" : 130242651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/SJ4vggwJ9I",
      "expanded_url" : "http:\/\/www.thinkgeek.com\/product\/de7f\/",
      "display_url" : "thinkgeek.com\/product\/de7f\/"
    } ]
  },
  "in_reply_to_status_id_str" : "346699255160909826",
  "geo" : { },
  "id_str" : "346708297501536256",
  "in_reply_to_user_id" : 490897163,
  "text" : "@Futch007 Very lame. what if i threw in a set of http:\/\/t.co\/SJ4vggwJ9I (IIRC 2 of them have a small bend) ? \/cc @Chris_Langford",
  "id" : 346708297501536256,
  "in_reply_to_status_id" : 346699255160909826,
  "created_at" : "2013-06-17 19:17:54 +0000",
  "in_reply_to_screen_name" : "Futch007",
  "in_reply_to_user_id_str" : "490897163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Casey S",
      "screen_name" : "caseyinBuffalo",
      "indices" : [ 11, 26 ],
      "id_str" : "191558578",
      "id" : 191558578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346684940286574592",
  "geo" : { },
  "id_str" : "346685141944500226",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy @caseyinBuffalo Resurface went all the way to Niagara Square, so I hope so!",
  "id" : 346685141944500226,
  "in_reply_to_status_id" : 346684940286574592,
  "created_at" : "2013-06-17 17:45:53 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346675804752715776",
  "text" : "RT @theediguy: @qrush they are chalking off bike lanes on Delaware.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346674874552557570",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush they are chalking off bike lanes on Delaware.",
    "id" : 346674874552557570,
    "created_at" : "2013-06-17 17:05:05 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "protected" : false,
      "id_str" : "14122207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571262181624418304\/X5WyW-TQ_normal.jpeg",
      "id" : 14122207,
      "verified" : false
    }
  },
  "id" : 346675804752715776,
  "created_at" : "2013-06-17 17:08:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cichon",
      "screen_name" : "SteveBuffalo",
      "indices" : [ 0, 13 ],
      "id_str" : "235665553",
      "id" : 235665553
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 28, 42 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 47, 58 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346670609654243329",
  "geo" : { },
  "id_str" : "346672207621140481",
  "in_reply_to_user_id" : 235665553,
  "text" : "@SteveBuffalo the chemex at @coworkbuffalo and @kevinpurdy's coffee brewing expertise might have some ideas!",
  "id" : 346672207621140481,
  "in_reply_to_status_id" : 346670609654243329,
  "created_at" : "2013-06-17 16:54:29 +0000",
  "in_reply_to_screen_name" : "SteveBuffalo",
  "in_reply_to_user_id_str" : "235665553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/O3JCLqHTtQ",
      "expanded_url" : "https:\/\/twitter.com\/settings\/notifications",
      "display_url" : "twitter.com\/settings\/notif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346671894998683649",
  "text" : "Go to https:\/\/t.co\/O3JCLqHTtQ, uncheck everything.",
  "id" : 346671894998683649,
  "created_at" : "2013-06-17 16:53:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 3, 12 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/80o2X9y6cF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "346669151579938816",
  "text" : "68 @OpenHack cities and counting, and Buffalo's is tomorrow night. http:\/\/t.co\/80o2X9y6cF (Where's your city?)",
  "id" : 346669151579938816,
  "created_at" : "2013-06-17 16:42:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Langford",
      "screen_name" : "Chris_Langford",
      "indices" : [ 0, 15 ],
      "id_str" : "130242651",
      "id" : 130242651
    }, {
      "name" : "Futch",
      "screen_name" : "Futch007",
      "indices" : [ 16, 25 ],
      "id_str" : "490897163",
      "id" : 490897163
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 61, 70 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/80o2X9y6cF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    }, {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/kbWQAJt4YC",
      "expanded_url" : "http:\/\/nextplex.com\/buffalo-ny\/calendar\/events\/7413-openhack-june-2-0",
      "display_url" : "nextplex.com\/buffalo-ny\/cal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "346664790489432064",
  "geo" : { },
  "id_str" : "346666198114635777",
  "in_reply_to_user_id" : 130242651,
  "text" : "@Chris_Langford @Futch007 are you game space folks coming to @openhack tomorrow? http:\/\/t.co\/80o2X9y6cF http:\/\/t.co\/kbWQAJt4YC",
  "id" : 346666198114635777,
  "in_reply_to_status_id" : 346664790489432064,
  "created_at" : "2013-06-17 16:30:37 +0000",
  "in_reply_to_screen_name" : "Chris_Langford",
  "in_reply_to_user_id_str" : "130242651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346651757998374912",
  "geo" : { },
  "id_str" : "346652120323350528",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos If I wasn't on Keto, I'd still be at CBW every week :) Whisky\/Scotch has been my poison lately.",
  "id" : 346652120323350528,
  "in_reply_to_status_id" : 346651757998374912,
  "created_at" : "2013-06-17 15:34:40 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/fOqlgwrZay",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=32UGD0fV45g",
      "display_url" : "youtube.com\/watch?v=32UGD0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "346650872404664320",
  "geo" : { },
  "id_str" : "346651378120286208",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos Suburbs? Biking? http:\/\/t.co\/fOqlgwrZay",
  "id" : 346651378120286208,
  "in_reply_to_status_id" : 346650872404664320,
  "created_at" : "2013-06-17 15:31:43 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346632545313636354",
  "geo" : { },
  "id_str" : "346648571581452290",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss woot woot",
  "id" : 346648571581452290,
  "in_reply_to_status_id" : 346632545313636354,
  "created_at" : "2013-06-17 15:20:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346648359773278209",
  "text" : "Traffic pattern change warnings up on Delaware Ave! Really hoping for some bike lanes to be painted this week...",
  "id" : 346648359773278209,
  "created_at" : "2013-06-17 15:19:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346592866748997632",
  "geo" : { },
  "id_str" : "346618169672204289",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders I use vim! :P",
  "id" : 346618169672204289,
  "in_reply_to_status_id" : 346592866748997632,
  "created_at" : "2013-06-17 13:19:46 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346482029740847104",
  "text" : "Multiple ongoing Agricola games are extra challenging, the strategy is different in every one! (I\u2019m qrush there if you want to play)",
  "id" : 346482029740847104,
  "created_at" : "2013-06-17 04:18:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/A4DdbbhaLX",
      "expanded_url" : "https:\/\/vine.co\/v\/hBvYWHbm9qY",
      "display_url" : "vine.co\/v\/hBvYWHbm9qY"
    } ]
  },
  "geo" : { },
  "id_str" : "346451302429114370",
  "text" : "Cloud lightning! \u26A1#nature https:\/\/t.co\/A4DdbbhaLX",
  "id" : 346451302429114370,
  "created_at" : "2013-06-17 02:16:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/lltUCe5AxK",
      "expanded_url" : "http:\/\/flic.kr\/p\/eNWabw",
      "display_url" : "flic.kr\/p\/eNWabw"
    } ]
  },
  "geo" : { },
  "id_str" : "346436391770652673",
  "text" : "Sunset over Lake Erie and Buffalo from the south. http:\/\/t.co\/lltUCe5AxK",
  "id" : 346436391770652673,
  "created_at" : "2013-06-17 01:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 0, 9 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346431075054137344",
  "geo" : { },
  "id_str" : "346434575075000320",
  "in_reply_to_user_id" : 14531472,
  "text" : "@mikesusz yep!",
  "id" : 346434575075000320,
  "in_reply_to_status_id" : 346431075054137344,
  "created_at" : "2013-06-17 01:10:13 +0000",
  "in_reply_to_screen_name" : "mikesusz",
  "in_reply_to_user_id_str" : "14531472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/DUxUWfJHqA",
      "expanded_url" : "https:\/\/vine.co\/v\/hBvZ2ZhLwPl",
      "display_url" : "vine.co\/v\/hBvZ2ZhLwPl"
    } ]
  },
  "geo" : { },
  "id_str" : "346425343734861824",
  "text" : "Sunset over Buffalo and a big fire. https:\/\/t.co\/DUxUWfJHqA",
  "id" : 346425343734861824,
  "created_at" : "2013-06-17 00:33:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/46RDfbhLrs",
      "expanded_url" : "http:\/\/flic.kr\/p\/eNRgNy",
      "display_url" : "flic.kr\/p\/eNRgNy"
    } ]
  },
  "geo" : { },
  "id_str" : "346398110395809793",
  "text" : "Another gorgeous view from near Hamburg Beach. http:\/\/t.co\/46RDfbhLrs",
  "id" : 346398110395809793,
  "created_at" : "2013-06-16 22:45:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YJaHpcjokl",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjG6VVdg",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjG6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346273348478697472",
  "text" : "View my 7 latest photos on Flickr: http:\/\/t.co\/YJaHpcjokl",
  "id" : 346273348478697472,
  "created_at" : "2013-06-16 14:29:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Qkql63C34r",
      "expanded_url" : "http:\/\/flic.kr\/u\/tZEsU\/aHsjG6fcYv",
      "display_url" : "flic.kr\/u\/tZEsU\/aHsjG6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346256716234620930",
  "text" : "View my 3 latest photos on Flickr: http:\/\/t.co\/Qkql63C34r",
  "id" : 346256716234620930,
  "created_at" : "2013-06-16 13:23:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auston Bunsen",
      "screen_name" : "bunsen",
      "indices" : [ 0, 7 ],
      "id_str" : "11564132",
      "id" : 11564132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346234765902503936",
  "in_reply_to_user_id" : 11564132,
  "text" : "@bunsen",
  "id" : 346234765902503936,
  "created_at" : "2013-06-16 11:56:15 +0000",
  "in_reply_to_screen_name" : "bunsen",
  "in_reply_to_user_id_str" : "11564132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loop",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/9bxo0MsMmr",
      "expanded_url" : "https:\/\/vine.co\/v\/hBqIixWWaHe",
      "display_url" : "vine.co\/v\/hBqIixWWaHe"
    } ]
  },
  "geo" : { },
  "id_str" : "346077093769138176",
  "text" : "The best view of Buffalo I've seen in a long while. #loop https:\/\/t.co\/9bxo0MsMmr",
  "id" : 346077093769138176,
  "created_at" : "2013-06-16 01:29:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345885046609178624",
  "text" : "Book of Mormon was hilarious. Also, serious respect for the actual Mormon missionaries recruiting outside the theater. Free advertising!",
  "id" : 345885046609178624,
  "created_at" : "2013-06-15 12:46:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345648253884301313",
  "geo" : { },
  "id_str" : "345651074717327362",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis not your fault",
  "id" : 345651074717327362,
  "in_reply_to_status_id" : 345648253884301313,
  "created_at" : "2013-06-14 21:16:52 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/345614813835165696\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/yXHhFTLflL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMve15DCcAAvRFV.jpg",
      "id_str" : "345614813851971584",
      "id" : 345614813851971584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMve15DCcAAvRFV.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yXHhFTLflL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345614813835165696",
  "text" : "Watching WWDC videos on the parkway, and this derpy husky is loving every second outside. http:\/\/t.co\/yXHhFTLflL",
  "id" : 345614813835165696,
  "created_at" : "2013-06-14 18:52:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345570481178566657",
  "text" : "Very curious: Are WWDC presenters reading from a script?",
  "id" : 345570481178566657,
  "created_at" : "2013-06-14 15:56:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/KpCv7A5Bz8",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3349-open-source-guilt-passion",
      "display_url" : "37signals.com\/svn\/posts\/3349\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "345556306268135429",
  "geo" : { },
  "id_str" : "345556633713258497",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham my thoughts on this are driven by guilt: http:\/\/t.co\/KpCv7A5Bz8",
  "id" : 345556633713258497,
  "in_reply_to_status_id" : 345556306268135429,
  "created_at" : "2013-06-14 15:01:36 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345414688118538240",
  "geo" : { },
  "id_str" : "345415349690306562",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss sure does, offline \/online modes",
  "id" : 345415349690306562,
  "in_reply_to_status_id" : 345414688118538240,
  "created_at" : "2013-06-14 05:40:11 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345379651671191552",
  "geo" : { },
  "id_str" : "345379905690816512",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams JJJEEEAAANNNN!!!!",
  "id" : 345379905690816512,
  "in_reply_to_status_id" : 345379651671191552,
  "created_at" : "2013-06-14 03:19:21 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345377405172604928",
  "geo" : { },
  "id_str" : "345377781632348160",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza dude\u2026",
  "id" : 345377781632348160,
  "in_reply_to_status_id" : 345377405172604928,
  "created_at" : "2013-06-14 03:10:54 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345373505698799616",
  "geo" : { },
  "id_str" : "345373640935763968",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman Dude, of course.",
  "id" : 345373640935763968,
  "in_reply_to_status_id" : 345373505698799616,
  "created_at" : "2013-06-14 02:54:27 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 0, 7 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345371903818600448",
  "geo" : { },
  "id_str" : "345373240451010561",
  "in_reply_to_user_id" : 11322372,
  "text" : "@holman I believe you're suffering from YDD: Yuengling Deficiency Disorder.",
  "id" : 345373240451010561,
  "in_reply_to_status_id" : 345371903818600448,
  "created_at" : "2013-06-14 02:52:51 +0000",
  "in_reply_to_screen_name" : "holman",
  "in_reply_to_user_id_str" : "11322372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 37, 52 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345361835874217985",
  "geo" : { },
  "id_str" : "345363034472079361",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden Cutting it real close to @nickelcityruby ? :)",
  "id" : 345363034472079361,
  "in_reply_to_status_id" : 345361835874217985,
  "created_at" : "2013-06-14 02:12:18 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Desaulniers\u2400",
      "screen_name" : "LostOracle",
      "indices" : [ 0, 11 ],
      "id_str" : "28446277",
      "id" : 28446277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345361798339375105",
  "geo" : { },
  "id_str" : "345362832054956033",
  "in_reply_to_user_id" : 28446277,
  "text" : "@LostOracle Mozilla is a completely different company than that (or where I worked). Sadly most aren't that way.",
  "id" : 345362832054956033,
  "in_reply_to_status_id" : 345361798339375105,
  "created_at" : "2013-06-14 02:11:30 +0000",
  "in_reply_to_screen_name" : "LostOracle",
  "in_reply_to_user_id_str" : "28446277",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345355701851394048",
  "geo" : { },
  "id_str" : "345359834427826177",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy &gt; Use Potion",
  "id" : 345359834427826177,
  "in_reply_to_status_id" : 345355701851394048,
  "created_at" : "2013-06-14 01:59:35 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 25, 40 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345354462342307840",
  "text" : "Going over proposals for @nickelcityruby. I wish we had more time for all of these great talks!",
  "id" : 345354462342307840,
  "created_at" : "2013-06-14 01:38:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 14, 26 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345279916947947520",
  "geo" : { },
  "id_str" : "345281826794917889",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @coreyhaines well it's a good thing you can use [REDACTED] on the new [REDACTED] which features [REDACTED][REDACTED][REDACTED]",
  "id" : 345281826794917889,
  "in_reply_to_status_id" : 345279916947947520,
  "created_at" : "2013-06-13 20:49:37 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 3, 9 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345266572350332930",
  "text" : "RT @mattt: A lot to be excited about Foundation networking in iOS 7 and OS X 10.9. AFNetworking &amp; NSURL[REDACTED]  will surely be the best \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344861495680700416",
    "text" : "A lot to be excited about Foundation networking in iOS 7 and OS X 10.9. AFNetworking &amp; NSURL[REDACTED]  will surely be the best of friends.",
    "id" : 344861495680700416,
    "created_at" : "2013-06-12 16:59:22 +0000",
    "user" : {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "protected" : false,
      "id_str" : "35803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3573863306\/5333c08eae9005dd7a8cdd478202c818_normal.jpeg",
      "id" : 35803,
      "verified" : false
    }
  },
  "id" : 345266572350332930,
  "created_at" : "2013-06-13 19:49:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345266284251975682",
  "text" : "Very curious to see what happens to AFNetworking over the next few months given [REDACTED] [REDACTED] and [REDACTED]",
  "id" : 345266284251975682,
  "created_at" : "2013-06-13 19:47:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 3, 13 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 28, 34 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Keto",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/RF4rfrxHJA",
      "expanded_url" : "http:\/\/instagram.com\/p\/agcXDhPrX6\/",
      "display_url" : "instagram.com\/p\/agcXDhPrX6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "345226477169672192",
  "text" : "RT @magnachef: According to @qrush: while doing #Keto, this is called \"Bread Shame\" http:\/\/t.co\/RF4rfrxHJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 13, 19 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Keto",
        "indices" : [ 33, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/RF4rfrxHJA",
        "expanded_url" : "http:\/\/instagram.com\/p\/agcXDhPrX6\/",
        "display_url" : "instagram.com\/p\/agcXDhPrX6\/"
      } ]
    },
    "geo" : { },
    "id_str" : "345226429916655617",
    "text" : "According to @qrush: while doing #Keto, this is called \"Bread Shame\" http:\/\/t.co\/RF4rfrxHJA",
    "id" : 345226429916655617,
    "created_at" : "2013-06-13 17:09:29 +0000",
    "user" : {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "protected" : false,
      "id_str" : "23703410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557740024620261376\/4Td91096_normal.jpeg",
      "id" : 23703410,
      "verified" : false
    }
  },
  "id" : 345226477169672192,
  "created_at" : "2013-06-13 17:09:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Amram",
      "screen_name" : "meganamram",
      "indices" : [ 3, 14 ],
      "id_str" : "35206553",
      "id" : 35206553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345208857242505217",
  "text" : "RT @meganamram: I just bought the NSA's new app, Nineteen-Eighty-Foursquare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344892682742665218",
    "text" : "I just bought the NSA's new app, Nineteen-Eighty-Foursquare",
    "id" : 344892682742665218,
    "created_at" : "2013-06-12 19:03:18 +0000",
    "user" : {
      "name" : "Megan Amram",
      "screen_name" : "meganamram",
      "protected" : false,
      "id_str" : "35206553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890366092\/n31883_33925212_8870_normal.jpg",
      "id" : 35206553,
      "verified" : false
    }
  },
  "id" : 345208857242505217,
  "created_at" : "2013-06-13 15:59:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345187258279809024",
  "geo" : { },
  "id_str" : "345187430900584448",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave Looks like it's working this morning! And most definitely.",
  "id" : 345187430900584448,
  "in_reply_to_status_id" : 345187258279809024,
  "created_at" : "2013-06-13 14:34:31 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Conley",
      "screen_name" : "Sigafoos",
      "indices" : [ 0, 9 ],
      "id_str" : "815545",
      "id" : 815545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345131067235262464",
  "geo" : { },
  "id_str" : "345155416000430080",
  "in_reply_to_user_id" : 815545,
  "text" : "@Sigafoos it\u2019s a terrible copy. I would never expect someone to learn off it",
  "id" : 345155416000430080,
  "in_reply_to_status_id" : 345131067235262464,
  "created_at" : "2013-06-13 12:27:18 +0000",
  "in_reply_to_screen_name" : "Sigafoos",
  "in_reply_to_user_id_str" : "815545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345153863965351936",
  "text" : "Looks like Agricola\u2019s multiplayer is back up. I\u2019m qrush there if you want to FARMER DUEL",
  "id" : 345153863965351936,
  "created_at" : "2013-06-13 12:21:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/345036571617132544\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ciKOf5zshE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMnQ7w4CAAMpmwW.png",
      "id_str" : "345036571621326851",
      "id" : 345036571621326851,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMnQ7w4CAAMpmwW.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ciKOf5zshE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345036571617132544",
  "text" : "Correction, this is why Game Center exists. Hoping they fix this soon. http:\/\/t.co\/ciKOf5zshE",
  "id" : 345036571617132544,
  "created_at" : "2013-06-13 04:35:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345036323989639168",
  "text" : "This is literally why Game Center exists.",
  "id" : 345036323989639168,
  "created_at" : "2013-06-13 04:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345036199586590720",
  "text" : "For as polished as the offline play is, Agricola online is a nonstarter and the forgot password form asks for a new password without HTTPS.",
  "id" : 345036199586590720,
  "created_at" : "2013-06-13 04:33:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345034150081880064",
  "geo" : { },
  "id_str" : "345034525534982145",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Le Havre\u2019s buildup is intense, more so than Agricola. Plans within plans within plans.",
  "id" : 345034525534982145,
  "in_reply_to_status_id" : 345034150081880064,
  "created_at" : "2013-06-13 04:26:55 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345034222899187712",
  "geo" : { },
  "id_str" : "345034393728995328",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes scoring is the easiest part!",
  "id" : 345034393728995328,
  "in_reply_to_status_id" : 345034222899187712,
  "created_at" : "2013-06-13 04:26:24 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345032875063795713",
  "geo" : { },
  "id_str" : "345033914592677888",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes Carcassonne is a good gateway drug but less of a worker placement game, kind of in a different league.",
  "id" : 345033914592677888,
  "in_reply_to_status_id" : 345032875063795713,
  "created_at" : "2013-06-13 04:24:30 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345032875063795713",
  "geo" : { },
  "id_str" : "345033756765220864",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes tough call. Le Havre goes the deepest strategy wise but I feel Agricola is smoother and has more variation.",
  "id" : 345033756765220864,
  "in_reply_to_status_id" : 345032875063795713,
  "created_at" : "2013-06-13 04:23:52 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345031955940786176",
  "text" : "Agricola iOS puts Le Havre to shame. Not as refined as Carcassonne yet but it\u2019ll get there.",
  "id" : 345031955940786176,
  "created_at" : "2013-06-13 04:16:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Kapp",
      "screen_name" : "happymrdave",
      "indices" : [ 0, 12 ],
      "id_str" : "15399388",
      "id" : 15399388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345031155600457728",
  "geo" : { },
  "id_str" : "345031768098885632",
  "in_reply_to_user_id" : 15399388,
  "text" : "@happymrdave I can\u2019t register though for online :(",
  "id" : 345031768098885632,
  "in_reply_to_status_id" : 345031155600457728,
  "created_at" : "2013-06-13 04:15:58 +0000",
  "in_reply_to_screen_name" : "happymrdave",
  "in_reply_to_user_id_str" : "15399388",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345018777219502080",
  "geo" : { },
  "id_str" : "345019472928706560",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude go to Intelligentsia. Every cup brewed via Chemex or tossed in minutes.",
  "id" : 345019472928706560,
  "in_reply_to_status_id" : 345018777219502080,
  "created_at" : "2013-06-13 03:27:07 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345017711677554689",
  "text" : "Seems like online registration for Agricola is down, game crashes on register\/login timeout. :(",
  "id" : 345017711677554689,
  "created_at" : "2013-06-13 03:20:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/pkjY1HlHyn",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/agricola\/id561521557?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/agricol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345014545716236288",
  "text" : "Agricola! I\u2019m quaranto on Game Center. You know what to do.\n\nhttps:\/\/t.co\/pkjY1HlHyn",
  "id" : 345014545716236288,
  "created_at" : "2013-06-13 03:07:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Fiedler",
      "screen_name" : "kylefiedler",
      "indices" : [ 0, 12 ],
      "id_str" : "14838050",
      "id" : 14838050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344977366579286016",
  "geo" : { },
  "id_str" : "344977822558863360",
  "in_reply_to_user_id" : 14838050,
  "text" : "@kylefiedler whoa, congrats! staying on with the 'bot?",
  "id" : 344977822558863360,
  "in_reply_to_status_id" : 344977366579286016,
  "created_at" : "2013-06-13 00:41:36 +0000",
  "in_reply_to_screen_name" : "kylefiedler",
  "in_reply_to_user_id_str" : "14838050",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344965496254369792",
  "geo" : { },
  "id_str" : "344968532699783169",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain Yeah, includes feel like a better way to do this. Nesting 3 for loops in liquid with if's in each feels wrong.",
  "id" : 344968532699783169,
  "in_reply_to_status_id" : 344965496254369792,
  "created_at" : "2013-06-13 00:04:42 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344961410461212673",
  "geo" : { },
  "id_str" : "344962972814282752",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain There's clearly a bug here but I don't feel like this setup is a good way to use this",
  "id" : 344962972814282752,
  "in_reply_to_status_id" : 344961410461212673,
  "created_at" : "2013-06-12 23:42:36 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344961410461212673",
  "geo" : { },
  "id_str" : "344962843696832512",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain no, i think you're misusing pages and loops completely. there's 3-4 levels of nesting and it's really confusing",
  "id" : 344962843696832512,
  "in_reply_to_status_id" : 344961410461212673,
  "created_at" : "2013-06-12 23:42:05 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Kain \u262F",
      "screen_name" : "zakkain",
      "indices" : [ 0, 8 ],
      "id_str" : "15069435",
      "id" : 15069435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344956320111280130",
  "geo" : { },
  "id_str" : "344959888155361280",
  "in_reply_to_user_id" : 15069435,
  "text" : "@zakkain Example repo link doesnt work, and I feel this might not be a good fit for Jekyll already. Could be a bug too.",
  "id" : 344959888155361280,
  "in_reply_to_status_id" : 344956320111280130,
  "created_at" : "2013-06-12 23:30:21 +0000",
  "in_reply_to_screen_name" : "zakkain",
  "in_reply_to_user_id_str" : "15069435",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344952919927431169",
  "text" : "RT @bquarant: \"Keep cool, never freeze\" - profound advice from condiment bottle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344827727607644160",
    "text" : "\"Keep cool, never freeze\" - profound advice from condiment bottle",
    "id" : 344827727607644160,
    "created_at" : "2013-06-12 14:45:11 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 344952919927431169,
  "created_at" : "2013-06-12 23:02:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344930015932211200",
  "text" : "lmao @ \"I am surprised that no one I met in Windows Azure team heard about Heroku or Rackspace\"",
  "id" : 344930015932211200,
  "created_at" : "2013-06-12 21:31:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/j5bckkgmTu",
      "expanded_url" : "http:\/\/ahmetalpbalkan.com\/blog\/8-months-microsoft\/",
      "display_url" : "ahmetalpbalkan.com\/blog\/8-months-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344929978237997057",
  "text" : "This mirrors my experience in large companies: http:\/\/t.co\/j5bckkgmTu",
  "id" : 344929978237997057,
  "created_at" : "2013-06-12 21:31:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 52, 60 ],
      "id_str" : "670283",
      "id" : 670283
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 61, 72 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344899886925357056",
  "text" : "Rubygems 2.0.2 and Nokogiri 1.5.6 on Mavericks! \/cc @drbrain @tenderlove",
  "id" : 344899886925357056,
  "created_at" : "2013-06-12 19:31:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Pw5aKhOuvg",
      "expanded_url" : "http:\/\/github.com\/rubygems\/gemwhisperer",
      "display_url" : "github.com\/rubygems\/gemwh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "344862584719151105",
  "geo" : { },
  "id_str" : "344863035132878848",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham Had no idea it died. Nope! code is at http:\/\/t.co\/Pw5aKhOuvg",
  "id" : 344863035132878848,
  "in_reply_to_status_id" : 344862584719151105,
  "created_at" : "2013-06-12 17:05:29 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/RRguAXnDfs",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food\/",
      "display_url" : "coworkbuffalo.com\/food\/"
    } ]
  },
  "geo" : { },
  "id_str" : "344861237940740096",
  "text" : "Aaaand we're back! http:\/\/t.co\/RRguAXnDfs (RIP Twitter 1.0 API)",
  "id" : 344861237940740096,
  "created_at" : "2013-06-12 16:58:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 48, 56 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 57, 66 ],
      "id_str" : "51077652",
      "id" : 51077652
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 71, 82 ],
      "id_str" : "7255652",
      "id" : 7255652
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 83, 90 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Harvest",
      "screen_name" : "harvest",
      "indices" : [ 91, 99 ],
      "id_str" : "7541902",
      "id" : 7541902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344820388318031872",
  "text" : "RT @nickelcityruby: Thanks to all our sponsors: @Synacor @Chargify Db0 @engineyard @github @harvest - if you'd like to join this group: nic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Synacor",
        "screen_name" : "Synacor",
        "indices" : [ 28, 36 ],
        "id_str" : "19976046",
        "id" : 19976046
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 37, 46 ],
        "id_str" : "51077652",
        "id" : 51077652
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 51, 62 ],
        "id_str" : "7255652",
        "id" : 7255652
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 63, 70 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Harvest",
        "screen_name" : "harvest",
        "indices" : [ 71, 79 ],
        "id_str" : "7541902",
        "id" : 7541902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344819285820063745",
    "text" : "Thanks to all our sponsors: @Synacor @Chargify Db0 @engineyard @github @harvest - if you'd like to join this group: nickelcityruby@gmail.com",
    "id" : 344819285820063745,
    "created_at" : "2013-06-12 14:11:38 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 344820388318031872,
  "created_at" : "2013-06-12 14:16:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "indices" : [ 3, 6 ],
      "id_str" : "2087371",
      "id" : 2087371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xaUdijOAde",
      "expanded_url" : "http:\/\/www.marco.org\/2013\/06\/11\/fertile-ground",
      "display_url" : "marco.org\/2013\/06\/11\/fer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344807717732491265",
  "text" : "RT @iA: \"I don\u2019t think we\u2019ve ever had such an opportunity en masse on iOS.\"  http:\/\/t.co\/xaUdijOAde",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/xaUdijOAde",
        "expanded_url" : "http:\/\/www.marco.org\/2013\/06\/11\/fertile-ground",
        "display_url" : "marco.org\/2013\/06\/11\/fer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344708330863878145",
    "text" : "\"I don\u2019t think we\u2019ve ever had such an opportunity en masse on iOS.\"  http:\/\/t.co\/xaUdijOAde",
    "id" : 344708330863878145,
    "created_at" : "2013-06-12 06:50:45 +0000",
    "user" : {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "protected" : false,
      "id_str" : "2087371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510071324580909056\/PGyJp57__normal.png",
      "id" : 2087371,
      "verified" : false
    }
  },
  "id" : 344807717732491265,
  "created_at" : "2013-06-12 13:25:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 3, 14 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344796064693493760",
  "text" : "RT @RubyMotion: RubyMotion 2.2 is available, supporting iOS 7.0 and OSX 10.9. Read the release notes carefully. Enjoy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344766250607595520",
    "text" : "RubyMotion 2.2 is available, supporting iOS 7.0 and OSX 10.9. Read the release notes carefully. Enjoy!",
    "id" : 344766250607595520,
    "created_at" : "2013-06-12 10:40:54 +0000",
    "user" : {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "protected" : false,
      "id_str" : "381521407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540869126445490178\/xG24kW5B_normal.png",
      "id" : 381521407,
      "verified" : false
    }
  },
  "id" : 344796064693493760,
  "created_at" : "2013-06-12 12:39:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344688693681979392",
  "geo" : { },
  "id_str" : "344792507135193088",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck I didn\u2019t get any pingdom alerts. Also I rarely check mentions for those accounts.",
  "id" : 344792507135193088,
  "in_reply_to_status_id" : 344688693681979392,
  "created_at" : "2013-06-12 12:25:14 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344678937940619264",
  "geo" : { },
  "id_str" : "344679722812338176",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle word, just credit it. Should really CC license it. REMMMMMIX",
  "id" : 344679722812338176,
  "in_reply_to_status_id" : 344678937940619264,
  "created_at" : "2013-06-12 04:57:04 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scheirman",
      "screen_name" : "subdigital",
      "indices" : [ 0, 11 ],
      "id_str" : "14133001",
      "id" : 14133001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344678023943041026",
  "geo" : { },
  "id_str" : "344678563645124608",
  "in_reply_to_user_id" : 14133001,
  "text" : "@subdigital learning the language isn\u2019t going to change.",
  "id" : 344678563645124608,
  "in_reply_to_status_id" : 344678023943041026,
  "created_at" : "2013-06-12 04:52:28 +0000",
  "in_reply_to_screen_name" : "subdigital",
  "in_reply_to_user_id_str" : "14133001",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344677460232777728",
  "text" : "Also tried out some code katas in Objective-C tonight. It is completely non-trivial to get unit tests working in XCode.",
  "id" : 344677460232777728,
  "created_at" : "2013-06-12 04:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/344674688510857217\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4vyRO30311",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMiHzZRCEAApCpu.png",
      "id_str" : "344674688519245824",
      "id" : 344674688519245824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMiHzZRCEAApCpu.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/4vyRO30311"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344674688510857217",
  "text" : "Shedded my winter wall for summer. Hoping iOS7 lets me use my home screen more for icons, I hate covering it up. http:\/\/t.co\/4vyRO30311",
  "id" : 344674688510857217,
  "created_at" : "2013-06-12 04:37:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344671204461907969",
  "text" : "Finally finished How Will You Measure Your Life? tonight. Lots to think about for the Quarantos.",
  "id" : 344671204461907969,
  "created_at" : "2013-06-12 04:23:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 13, 28 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 29, 39 ],
      "id_str" : "14122207",
      "id" : 14122207
    }, {
      "name" : "Girl Develop It Bflo",
      "screen_name" : "gdiBuffalo",
      "indices" : [ 40, 51 ],
      "id_str" : "1232850504",
      "id" : 1232850504
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 125, 140 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344659871804821506",
  "geo" : { },
  "id_str" : "344660855805313024",
  "in_reply_to_user_id" : 23217545,
  "text" : "@StrategicIP @ChrisVanPatten @theediguy @gdiBuffalo haven\u2019t heard of most of these companies. Hopefully we can bring them to @nickelcityruby",
  "id" : 344660855805313024,
  "in_reply_to_status_id" : 344659871804821506,
  "created_at" : "2013-06-12 03:42:06 +0000",
  "in_reply_to_screen_name" : "LisaPrimerano",
  "in_reply_to_user_id_str" : "23217545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markov Twain",
      "screen_name" : "markov_twain",
      "indices" : [ 0, 13 ],
      "id_str" : "237957577",
      "id" : 237957577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344656103663091715",
  "geo" : { },
  "id_str" : "344657353825734656",
  "in_reply_to_user_id" : 237957577,
  "text" : "@markov_twain thanks! Real code stands up better than examples. It\u2019s messy and not perfect, and that\u2019s just fine.",
  "id" : 344657353825734656,
  "in_reply_to_status_id" : 344656103663091715,
  "created_at" : "2013-06-12 03:28:11 +0000",
  "in_reply_to_screen_name" : "markov_twain",
  "in_reply_to_user_id_str" : "237957577",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 36, 50 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Jason Silverstein",
      "screen_name" : "jaysunsilver",
      "indices" : [ 62, 75 ],
      "id_str" : "611919442",
      "id" : 611919442
    }, {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 79, 94 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gypSyCgL14",
      "expanded_url" : "http:\/\/www.buffalonews.com\/apps\/pbcs.dll\/article?AID=\/20130609\/CITYANDREGION\/130609339",
      "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344650618838843392",
  "text" : "RT @fending: In case you missed the @coworkbuffalo feature by @jaysunsilver in @TheBuffaloNews on Sunday: http:\/\/t.co\/gypSyCgL14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 23, 37 ],
        "id_str" : "491801330",
        "id" : 491801330
      }, {
        "name" : "Jason Silverstein",
        "screen_name" : "jaysunsilver",
        "indices" : [ 49, 62 ],
        "id_str" : "611919442",
        "id" : 611919442
      }, {
        "name" : "The Buffalo News",
        "screen_name" : "TheBuffaloNews",
        "indices" : [ 66, 81 ],
        "id_str" : "43805270",
        "id" : 43805270
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/gypSyCgL14",
        "expanded_url" : "http:\/\/www.buffalonews.com\/apps\/pbcs.dll\/article?AID=\/20130609\/CITYANDREGION\/130609339",
        "display_url" : "buffalonews.com\/apps\/pbcs.dll\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344530023316869120",
    "text" : "In case you missed the @coworkbuffalo feature by @jaysunsilver in @TheBuffaloNews on Sunday: http:\/\/t.co\/gypSyCgL14",
    "id" : 344530023316869120,
    "created_at" : "2013-06-11 19:02:13 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 344650618838843392,
  "created_at" : "2013-06-12 03:01:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344605141195968512",
  "geo" : { },
  "id_str" : "344607441159323648",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders yes?",
  "id" : 344607441159323648,
  "in_reply_to_status_id" : 344605141195968512,
  "created_at" : "2013-06-12 00:09:51 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/FRE3pvps9A",
      "expanded_url" : "http:\/\/thesnuggery.org\/rates_services.html",
      "display_url" : "thesnuggery.org\/rates_services\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344599467472875520",
  "text" : "Monthly reminder to my freelancing friends that the Double Snuggle is $120\/hour: http:\/\/t.co\/FRE3pvps9A",
  "id" : 344599467472875520,
  "created_at" : "2013-06-11 23:38:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9CGz6Q0AKr",
      "expanded_url" : "https:\/\/www.facebook.com\/Playdek\/posts\/544661965592879",
      "display_url" : "facebook.com\/Playdek\/posts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344558955332251648",
  "text" : "Agricola iOS is approved! Very surprised it's less expensive than Carcassone: https:\/\/t.co\/9CGz6Q0AKr",
  "id" : 344558955332251648,
  "created_at" : "2013-06-11 20:57:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344549247481442304",
  "geo" : { },
  "id_str" : "344549939759677440",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh None, I have a slew of very unrelated programming books to dredge through currently :)",
  "id" : 344549939759677440,
  "in_reply_to_status_id" : 344549247481442304,
  "created_at" : "2013-06-11 20:21:21 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344548230899593218",
  "geo" : { },
  "id_str" : "344548869595615233",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh Right now my answer is no. I need to learn more about Objective-C. I feel like I can read but not write it.",
  "id" : 344548869595615233,
  "in_reply_to_status_id" : 344548230899593218,
  "created_at" : "2013-06-11 20:17:06 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344537075288256514",
  "geo" : { },
  "id_str" : "344537681797193729",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh Still liking it, but I want to learn more Objective-C.",
  "id" : 344537681797193729,
  "in_reply_to_status_id" : 344537075288256514,
  "created_at" : "2013-06-11 19:32:39 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 60, 66 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hscIipJuiB",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3531-intention-revealing-methods",
      "display_url" : "37signals.com\/svn\/posts\/3531\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344532150764318721",
  "text" : "RT @jasonfried: Great lessons on code as communication from @qrush: http:\/\/t.co\/hscIipJuiB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 44, 50 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/hscIipJuiB",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3531-intention-revealing-methods",
        "display_url" : "37signals.com\/svn\/posts\/3531\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344530804740874240",
    "text" : "Great lessons on code as communication from @qrush: http:\/\/t.co\/hscIipJuiB",
    "id" : 344530804740874240,
    "created_at" : "2013-06-11 19:05:19 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 344532150764318721,
  "created_at" : "2013-06-11 19:10:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344521114053132289",
  "geo" : { },
  "id_str" : "344524242026647552",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle that\u2019s the whole point though. Check out the c2 wiki links about Identifiers Reveal Intent (and related)",
  "id" : 344524242026647552,
  "in_reply_to_status_id" : 344521114053132289,
  "created_at" : "2013-06-11 18:39:14 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 3, 11 ],
      "id_str" : "14436348",
      "id" : 14436348
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 31, 37 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/28Jtnfqs8p",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3531",
      "display_url" : "37signals.com\/svn\/posts\/3531"
    } ]
  },
  "geo" : { },
  "id_str" : "344517747469856770",
  "text" : "RT @adarshp: Excellent post by @qrush on Intention-Revealing Method Names. \n\nEvery dev should read this.\n\nhttp:\/\/t.co\/28Jtnfqs8p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 18, 24 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/28Jtnfqs8p",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3531",
        "display_url" : "37signals.com\/svn\/posts\/3531"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7771496, -122.4084983 ]
    },
    "id_str" : "344485472673865730",
    "text" : "Excellent post by @qrush on Intention-Revealing Method Names. \n\nEvery dev should read this.\n\nhttp:\/\/t.co\/28Jtnfqs8p",
    "id" : 344485472673865730,
    "created_at" : "2013-06-11 16:05:11 +0000",
    "user" : {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "protected" : false,
      "id_str" : "14436348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449407743766441984\/AfOGQ-jW_normal.jpeg",
      "id" : 14436348,
      "verified" : false
    }
  },
  "id" : 344517747469856770,
  "created_at" : "2013-06-11 18:13:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Kibbe",
      "screen_name" : "andrekibbe",
      "indices" : [ 3, 14 ],
      "id_str" : "14380609",
      "id" : 14380609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/PZDkWqyT8T",
      "expanded_url" : "http:\/\/goo.gl\/jdvGz",
      "display_url" : "goo.gl\/jdvGz"
    } ]
  },
  "geo" : { },
  "id_str" : "344517714095779840",
  "text" : "RT @andrekibbe: Intention Revealing Methods. http:\/\/t.co\/PZDkWqyT8T | More on refactoring to reduce\/eliminate comments. Love the full-word \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/PZDkWqyT8T",
        "expanded_url" : "http:\/\/goo.gl\/jdvGz",
        "display_url" : "goo.gl\/jdvGz"
      } ]
    },
    "geo" : { },
    "id_str" : "344500502115016705",
    "text" : "Intention Revealing Methods. http:\/\/t.co\/PZDkWqyT8T | More on refactoring to reduce\/eliminate comments. Love the full-word block variables.",
    "id" : 344500502115016705,
    "created_at" : "2013-06-11 17:04:54 +0000",
    "user" : {
      "name" : "Andre Kibbe",
      "screen_name" : "andrekibbe",
      "protected" : false,
      "id_str" : "14380609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606549944\/dre_gravatar_normal.jpeg",
      "id" : 14380609,
      "verified" : false
    }
  },
  "id" : 344517714095779840,
  "created_at" : "2013-06-11 18:13:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/QuwTfr8Iw7",
      "expanded_url" : "http:\/\/benyu.org\/150-days-without-videogames",
      "display_url" : "benyu.org\/150-days-witho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344515301452414976",
  "text" : "Can't take the gamer out of the game \"terrifying piece of shit\" \"shitton of transports\" \"fucking worthless\" http:\/\/t.co\/QuwTfr8Iw7",
  "id" : 344515301452414976,
  "created_at" : "2013-06-11 18:03:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 3, 13 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/N4kDcRWJZD",
      "expanded_url" : "http:\/\/asianmack.com\/selling",
      "display_url" : "asianmack.com\/selling"
    } ]
  },
  "geo" : { },
  "id_str" : "344500025495273474",
  "text" : "RT @asianmack: Selling to Yourself\u2014I made something I wanted and sold it. http:\/\/t.co\/N4kDcRWJZD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/N4kDcRWJZD",
        "expanded_url" : "http:\/\/asianmack.com\/selling",
        "display_url" : "asianmack.com\/selling"
      } ]
    },
    "geo" : { },
    "id_str" : "344498583631974400",
    "text" : "Selling to Yourself\u2014I made something I wanted and sold it. http:\/\/t.co\/N4kDcRWJZD",
    "id" : 344498583631974400,
    "created_at" : "2013-06-11 16:57:17 +0000",
    "user" : {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "protected" : false,
      "id_str" : "15045995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542325270447808512\/BgWzvXi8_normal.png",
      "id" : 15045995,
      "verified" : false
    }
  },
  "id" : 344500025495273474,
  "created_at" : "2013-06-11 17:03:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ridgeway",
      "screen_name" : "Ang3lFir3",
      "indices" : [ 0, 10 ],
      "id_str" : "7792122",
      "id" : 7792122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344482729666166784",
  "geo" : { },
  "id_str" : "344486391192895489",
  "in_reply_to_user_id" : 7792122,
  "text" : "@Ang3lFir3 that is the worst. I like one, two arguments at most rule...especially in Ruby.",
  "id" : 344486391192895489,
  "in_reply_to_status_id" : 344482729666166784,
  "created_at" : "2013-06-11 16:08:50 +0000",
  "in_reply_to_screen_name" : "Ang3lFir3",
  "in_reply_to_user_id_str" : "7792122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adarsh Pandit",
      "screen_name" : "adarshp",
      "indices" : [ 0, 8 ],
      "id_str" : "14436348",
      "id" : 14436348
    }, {
      "name" : "David Fitzgibbon",
      "screen_name" : "davidfitzgibbon",
      "indices" : [ 9, 25 ],
      "id_str" : "44585374",
      "id" : 44585374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344485472673865730",
  "geo" : { },
  "id_str" : "344486250218127360",
  "in_reply_to_user_id" : 14436348,
  "text" : "@adarshp @davidfitzgibbon thanks!!",
  "id" : 344486250218127360,
  "in_reply_to_status_id" : 344485472673865730,
  "created_at" : "2013-06-11 16:08:16 +0000",
  "in_reply_to_screen_name" : "adarshp",
  "in_reply_to_user_id_str" : "14436348",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/NUJQXRY9Qi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aX2KNyaoNV4",
      "display_url" : "youtube.com\/watch?v=aX2KNy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344486176364851200",
  "text" : "Whelp, I think this just sold me a Wii U: https:\/\/t.co\/NUJQXRY9Qi",
  "id" : 344486176364851200,
  "created_at" : "2013-06-11 16:07:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/3xXDBhDcMY",
      "expanded_url" : "http:\/\/37svn.com\/3531",
      "display_url" : "37svn.com\/3531"
    } ]
  },
  "geo" : { },
  "id_str" : "344480632983932928",
  "text" : "Refactoring isn't just about removing duplication, it's also about increasing clarity and intent: http:\/\/t.co\/3xXDBhDcMY",
  "id" : 344480632983932928,
  "created_at" : "2013-06-11 15:45:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 3, 16 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344462517101264896",
  "text" : "RT @moonpolysoft: Top post on HN is some dude who took it upon himself to redesign the prism slide deck.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344461977759907841",
    "text" : "Top post on HN is some dude who took it upon himself to redesign the prism slide deck.",
    "id" : 344461977759907841,
    "created_at" : "2013-06-11 14:31:49 +0000",
    "user" : {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "protected" : false,
      "id_str" : "14204623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535708867254956032\/9TysCR2t_normal.jpeg",
      "id" : 14204623,
      "verified" : false
    }
  },
  "id" : 344462517101264896,
  "created_at" : "2013-06-11 14:33:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Villacampa",
      "screen_name" : "MarkVillacampa",
      "indices" : [ 0, 15 ],
      "id_str" : "13639982",
      "id" : 13639982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344230821307232258",
  "geo" : { },
  "id_str" : "344231902401683457",
  "in_reply_to_user_id" : 13639982,
  "text" : "@MarkVillacampa geez is your iphone bricked?!",
  "id" : 344231902401683457,
  "in_reply_to_status_id" : 344230821307232258,
  "created_at" : "2013-06-10 23:17:35 +0000",
  "in_reply_to_screen_name" : "MarkVillacampa",
  "in_reply_to_user_id_str" : "13639982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/4xTMTENcfl",
      "expanded_url" : "http:\/\/buttcoin.org\/apple-announces-the-best-bitcoin-miner-on-the-market",
      "display_url" : "buttcoin.org\/apple-announce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344210006180233216",
  "text" : "I am now a bitcoiner! http:\/\/t.co\/4xTMTENcfl",
  "id" : 344210006180233216,
  "created_at" : "2013-06-10 21:50:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Floren",
      "screen_name" : "john_floren",
      "indices" : [ 0, 12 ],
      "id_str" : "1287042434",
      "id" : 1287042434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344207947167059968",
  "geo" : { },
  "id_str" : "344209698146369536",
  "in_reply_to_user_id" : 1287042434,
  "text" : "@john_floren Half of my investment portfolio is now bitcoins",
  "id" : 344209698146369536,
  "in_reply_to_status_id" : 344207947167059968,
  "created_at" : "2013-06-10 21:49:21 +0000",
  "in_reply_to_screen_name" : "john_floren",
  "in_reply_to_user_id_str" : "1287042434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pessimist",
      "screen_name" : "pessimism",
      "indices" : [ 3, 13 ],
      "id_str" : "14492810",
      "id" : 14492810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344189834140712960",
  "text" : "RT @pessimism: The best thing Apple did today was break Hacker News.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344188532669157377",
    "text" : "The best thing Apple did today was break Hacker News.",
    "id" : 344188532669157377,
    "created_at" : "2013-06-10 20:25:15 +0000",
    "user" : {
      "name" : "Pessimist",
      "screen_name" : "pessimism",
      "protected" : false,
      "id_str" : "14492810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1869909163\/joker_killing-joke_480_1201830092_normal.jpg",
      "id" : 14492810,
      "verified" : false
    }
  },
  "id" : 344189834140712960,
  "created_at" : "2013-06-10 20:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344168896753983489",
  "text" : "Really excited for iOS7, and to dig into the new docs for it. *furiously refreshes dev center*",
  "id" : 344168896753983489,
  "created_at" : "2013-06-10 19:07:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Layton Duncan",
      "screen_name" : "PolarBearFarm",
      "indices" : [ 3, 17 ],
      "id_str" : "14288966",
      "id" : 14288966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344158076087177217",
  "text" : "RT @PolarBearFarm: Wonder what our apps look like.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344157895488851970",
    "text" : "Wonder what our apps look like.",
    "id" : 344157895488851970,
    "created_at" : "2013-06-10 18:23:31 +0000",
    "user" : {
      "name" : "Layton Duncan",
      "screen_name" : "PolarBearFarm",
      "protected" : false,
      "id_str" : "14288966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3780771623\/ea2b46f67932b3411ddff0e4bca87c1d_normal.jpeg",
      "id" : 14288966,
      "verified" : false
    }
  },
  "id" : 344158076087177217,
  "created_at" : "2013-06-10 18:24:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344152301650448389",
  "text" : "Mac Pro: Bitcoin Edition.",
  "id" : 344152301650448389,
  "created_at" : "2013-06-10 18:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344135184825872386",
  "geo" : { },
  "id_str" : "344135353973747713",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo You can't OH yourself",
  "id" : 344135353973747713,
  "in_reply_to_status_id" : 344135184825872386,
  "created_at" : "2013-06-10 16:53:56 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 15, 22 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 83, 95 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 96, 108 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344132735109038081",
  "geo" : { },
  "id_str" : "344134026522677249",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn yeah @zobar2 suggested that. we did use it for Railscamp to test it out, @bcardarella @techpickles and others can verify :)",
  "id" : 344134026522677249,
  "in_reply_to_status_id" : 344132735109038081,
  "created_at" : "2013-06-10 16:48:40 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 5, 20 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344124781618135040",
  "text" : "Wow, @nickelcityruby CFP closed at 99 submissions. Really happy to bring some speakers to Buffalo, now we need to select some!",
  "id" : 344124781618135040,
  "created_at" : "2013-06-10 16:11:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/6aTR6YlJTs",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pcZSU40RBrg&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=pcZSU4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344115742289063936",
  "text" : "Bike storage of the future: http:\/\/t.co\/6aTR6YlJTs",
  "id" : 344115742289063936,
  "created_at" : "2013-06-10 15:36:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344110466303401985",
  "text" : "Realized today that my Mini from '09 is still named gemcutter, has all of RubyForge's gems on it from that time, and is running OSX 10.5.",
  "id" : 344110466303401985,
  "created_at" : "2013-06-10 15:15:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344099074884112385",
  "geo" : { },
  "id_str" : "344099214298591233",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt You could make it here to Buffalo if you leave now before the keynote.",
  "id" : 344099214298591233,
  "in_reply_to_status_id" : 344099074884112385,
  "created_at" : "2013-06-10 14:30:20 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344099156387835905",
  "text" : "RT @coworkbuffalo: Paula's Donuts, fresh coffee, and WWDC on the projector today, y'all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344094599540789248",
    "text" : "Paula's Donuts, fresh coffee, and WWDC on the projector today, y'all.",
    "id" : 344094599540789248,
    "created_at" : "2013-06-10 14:12:00 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 344099156387835905,
  "created_at" : "2013-06-10 14:30:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Malpass",
      "screen_name" : "indec",
      "indices" : [ 3, 9 ],
      "id_str" : "17840694",
      "id" : 17840694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344080424152215555",
  "text" : "RT @indec: Polyphasic sleep. Single source of all nutrition. Grumpy unless patted on the back regularly. Likes boobs. Baby or Hacker News C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344022352755052545",
    "text" : "Polyphasic sleep. Single source of all nutrition. Grumpy unless patted on the back regularly. Likes boobs. Baby or Hacker News Commenter?",
    "id" : 344022352755052545,
    "created_at" : "2013-06-10 09:24:55 +0000",
    "user" : {
      "name" : "Ian Malpass",
      "screen_name" : "indec",
      "protected" : false,
      "id_str" : "17840694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483088281215582209\/qo212B_y_normal.jpeg",
      "id" : 17840694,
      "verified" : false
    }
  },
  "id" : 344080424152215555,
  "created_at" : "2013-06-10 13:15:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 3, 16 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343934586251771904",
  "text" : "RT @stevenharman: Developers of closed languages (Obj-C, C#, Java, etc.) say, \"I'm really glad they gave us that.\" Developers of open langu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343884105554997248",
    "text" : "Developers of closed languages (Obj-C, C#, Java, etc.) say, \"I'm really glad they gave us that.\" Developers of open languages add \"that.\"",
    "id" : 343884105554997248,
    "created_at" : "2013-06-10 00:15:34 +0000",
    "user" : {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "protected" : false,
      "id_str" : "5875112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459360260528955392\/RKh4M2x2_normal.jpeg",
      "id" : 5875112,
      "verified" : false
    }
  },
  "id" : 343934586251771904,
  "created_at" : "2013-06-10 03:36:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/cOufYndMFz",
      "expanded_url" : "https:\/\/medium.com\/what-i-learned-today\/e748e0c82589",
      "display_url" : "medium.com\/what-i-learned\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343932459487985665",
  "text" : "Intense article about teaching a class in prison and the life there. https:\/\/t.co\/cOufYndMFz",
  "id" : 343932459487985665,
  "created_at" : "2013-06-10 03:27:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 3, 15 ],
      "id_str" : "16454301",
      "id" : 16454301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/aAVfduWtxZ",
      "expanded_url" : "http:\/\/obamaischeckingyouremail.tumblr.com",
      "display_url" : "obamaischeckingyouremail.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "343928046929190913",
  "text" : "RT @jonasdowney: 1) http:\/\/t.co\/aAVfduWtxZ\n2) Haha lol this Tumblr is so funny\n3) Moment of silence\n4) Realization of hopeless bleak despair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 25 ],
        "url" : "http:\/\/t.co\/aAVfduWtxZ",
        "expanded_url" : "http:\/\/obamaischeckingyouremail.tumblr.com",
        "display_url" : "obamaischeckingyouremail.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "343917681642196992",
    "text" : "1) http:\/\/t.co\/aAVfduWtxZ\n2) Haha lol this Tumblr is so funny\n3) Moment of silence\n4) Realization of hopeless bleak despair",
    "id" : 343917681642196992,
    "created_at" : "2013-06-10 02:28:59 +0000",
    "user" : {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "protected" : false,
      "id_str" : "16454301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153090409\/f136c60eca258e42e43b2d1760196833_normal.jpeg",
      "id" : 16454301,
      "verified" : false
    }
  },
  "id" : 343928046929190913,
  "created_at" : "2013-06-10 03:10:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Griffey",
      "screen_name" : "briangriffey",
      "indices" : [ 0, 13 ],
      "id_str" : "24887250",
      "id" : 24887250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343787924086726659",
  "geo" : { },
  "id_str" : "343835446817746944",
  "in_reply_to_user_id" : 24887250,
  "text" : "@briangriffey there\u2019s a free account",
  "id" : 343835446817746944,
  "in_reply_to_status_id" : 343787924086726659,
  "created_at" : "2013-06-09 21:02:13 +0000",
  "in_reply_to_screen_name" : "briangriffey",
  "in_reply_to_user_id_str" : "24887250",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 18, 32 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 55, 70 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/YlQxPxi76I",
      "expanded_url" : "http:\/\/tinyurl.com\/ost3jts",
      "display_url" : "tinyurl.com\/ost3jts"
    } ]
  },
  "geo" : { },
  "id_str" : "343728028330893312",
  "text" : "Very happy to see @coworkbuffalo in today\u2019s edition of @TheBuffaloNews: http:\/\/t.co\/YlQxPxi76I",
  "id" : 343728028330893312,
  "created_at" : "2013-06-09 13:55:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 3, 11 ],
      "id_str" : "77673",
      "id" : 77673
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 90, 105 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343723876028649472",
  "text" : "RT @jwright: Finally submitted the talk I have been wanting to give in quite some time to @nickelcityruby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 77, 92 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343694343632211969",
    "text" : "Finally submitted the talk I have been wanting to give in quite some time to @nickelcityruby.",
    "id" : 343694343632211969,
    "created_at" : "2013-06-09 11:41:31 +0000",
    "user" : {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "protected" : false,
      "id_str" : "77673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530926764155879424\/jWjU45VR_normal.jpeg",
      "id" : 77673,
      "verified" : false
    }
  },
  "id" : 343723876028649472,
  "created_at" : "2013-06-09 13:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343482175968141313",
  "geo" : { },
  "id_str" : "343503297027661824",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes signed up. Using RubyMotion?",
  "id" : 343503297027661824,
  "in_reply_to_status_id" : 343482175968141313,
  "created_at" : "2013-06-08 23:02:22 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "570452845",
      "id" : 570452845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/1hbjV9Hxuf",
      "expanded_url" : "http:\/\/fb.me\/EguqFeHA",
      "display_url" : "fb.me\/EguqFeHA"
    } ]
  },
  "geo" : { },
  "id_str" : "343436329306161152",
  "text" : "RT @UnclePhilsBlog: Aqueous performing the Super Mario Brothers Castle Theme at Nietzsche's 2013-05-30. I loooooove this. -DK http:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/1hbjV9Hxuf",
        "expanded_url" : "http:\/\/fb.me\/EguqFeHA",
        "display_url" : "fb.me\/EguqFeHA"
      } ]
    },
    "geo" : { },
    "id_str" : "343433923038162946",
    "text" : "Aqueous performing the Super Mario Brothers Castle Theme at Nietzsche's 2013-05-30. I loooooove this. -DK http:\/\/t.co\/1hbjV9Hxuf",
    "id" : 343433923038162946,
    "created_at" : "2013-06-08 18:26:42 +0000",
    "user" : {
      "name" : "Uncle Phils Blog",
      "screen_name" : "UnclePhilsBlog",
      "protected" : false,
      "id_str" : "570452845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568108122292486144\/QkpNRsU8_normal.jpeg",
      "id" : 570452845,
      "verified" : false
    }
  },
  "id" : 343436329306161152,
  "created_at" : "2013-06-08 18:36:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Allsopp",
      "screen_name" : "clayallsopp",
      "indices" : [ 0, 12 ],
      "id_str" : "48464282",
      "id" : 48464282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/343324117140897792\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PEXEYhpqc1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMO7dy1CAAAXL4u.png",
      "id_str" : "343324117145092096",
      "id" : 343324117145092096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMO7dy1CAAAXL4u.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/PEXEYhpqc1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343324117140897792",
  "in_reply_to_user_id" : 48464282,
  "text" : "@clayallsopp not sure if you saw the Attribution from Basecamp 1.2.0 yet, but thanks! http:\/\/t.co\/PEXEYhpqc1",
  "id" : 343324117140897792,
  "created_at" : "2013-06-08 11:10:23 +0000",
  "in_reply_to_screen_name" : "clayallsopp",
  "in_reply_to_user_id_str" : "48464282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 3, 15 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 47, 62 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343322958447652865",
  "text" : "RT @brickattack: Submitted a talk proposal for @nickelcityruby. That's a first. Feels good.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 30, 45 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341950252196167681",
    "text" : "Submitted a talk proposal for @nickelcityruby. That's a first. Feels good.",
    "id" : 341950252196167681,
    "created_at" : "2013-06-04 16:11:07 +0000",
    "user" : {
      "name" : "Erik Straub",
      "screen_name" : "brkattk",
      "protected" : false,
      "id_str" : "14789935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484774254479941632\/vyADZwQ3_normal.jpeg",
      "id" : 14789935,
      "verified" : false
    }
  },
  "id" : 343322958447652865,
  "created_at" : "2013-06-08 11:05:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom",
      "screen_name" : "tquackenbush",
      "indices" : [ 3, 16 ],
      "id_str" : "41243587",
      "id" : 41243587
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 29, 44 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Heisenbeard",
      "screen_name" : "blainsmith",
      "indices" : [ 50, 61 ],
      "id_str" : "119995231",
      "id" : 119995231
    }, {
      "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
      "screen_name" : "brickattack",
      "indices" : [ 66, 78 ],
      "id_str" : "2833581694",
      "id" : 2833581694
    }, {
      "name" : "Brian Corrigan",
      "screen_name" : "madgloryint",
      "indices" : [ 80, 92 ],
      "id_str" : "2169360690",
      "id" : 2169360690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psyched",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343322927837622274",
  "text" : "RT @tquackenbush: Heading to @NickelCityRuby with @blainsmith and @brickattack. @madgloryint represent. Looking forward to a trip out to Bu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 11, 26 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      }, {
        "name" : "Heisenbeard",
        "screen_name" : "blainsmith",
        "indices" : [ 32, 43 ],
        "id_str" : "119995231",
        "id" : 119995231
      }, {
        "name" : "\u0410\u043D\u0434\u0440\u0438\u0439\u0447\u0443\u043A \u0412\u0430\u0441\u0438\u043B\u0438\u0439",
        "screen_name" : "brickattack",
        "indices" : [ 48, 60 ],
        "id_str" : "2833581694",
        "id" : 2833581694
      }, {
        "name" : "Brian Corrigan",
        "screen_name" : "madgloryint",
        "indices" : [ 62, 74 ],
        "id_str" : "2169360690",
        "id" : 2169360690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "psyched",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342104308227117056",
    "text" : "Heading to @NickelCityRuby with @blainsmith and @brickattack. @madgloryint represent. Looking forward to a trip out to Buffalo.  #psyched",
    "id" : 342104308227117056,
    "created_at" : "2013-06-05 02:23:17 +0000",
    "user" : {
      "name" : "Tom",
      "screen_name" : "tquackenbush",
      "protected" : false,
      "id_str" : "41243587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507014085863407616\/4sULxsVG_normal.png",
      "id" : 41243587,
      "verified" : false
    }
  },
  "id" : 343322927837622274,
  "created_at" : "2013-06-08 11:05:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubydaily.org",
      "screen_name" : "rubydailyorg",
      "indices" : [ 3, 16 ],
      "id_str" : "1340198299",
      "id" : 1340198299
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 26, 41 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nTfVCWdruB",
      "expanded_url" : "http:\/\/bit.ly\/15Qh51K",
      "display_url" : "bit.ly\/15Qh51K"
    } ]
  },
  "geo" : { },
  "id_str" : "343322873907265537",
  "text" : "RT @rubydailyorg: \u2605 Conf: @NickelCityRuby last week calling for proposals http:\/\/t.co\/nTfVCWdruB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 8, 23 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/nTfVCWdruB",
        "expanded_url" : "http:\/\/bit.ly\/15Qh51K",
        "display_url" : "bit.ly\/15Qh51K"
      } ]
    },
    "geo" : { },
    "id_str" : "342840534928355329",
    "text" : "\u2605 Conf: @NickelCityRuby last week calling for proposals http:\/\/t.co\/nTfVCWdruB",
    "id" : 342840534928355329,
    "created_at" : "2013-06-07 03:08:47 +0000",
    "user" : {
      "name" : "rubydaily.org",
      "screen_name" : "rubydailyorg",
      "protected" : false,
      "id_str" : "1340198299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452004000292827136\/iClWH0_N_normal.png",
      "id" : 1340198299,
      "verified" : false
    }
  },
  "id" : 343322873907265537,
  "created_at" : "2013-06-08 11:05:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "indices" : [ 3, 15 ],
      "id_str" : "13168222",
      "id" : 13168222
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 44, 59 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343322853925597184",
  "text" : "RT @mark_menard: Doing talk submissions for @nickelcityruby today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 27, 42 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343094062267633665",
    "text" : "Doing talk submissions for @nickelcityruby today.",
    "id" : 343094062267633665,
    "created_at" : "2013-06-07 19:56:13 +0000",
    "user" : {
      "name" : "Mark Menard",
      "screen_name" : "mark_menard",
      "protected" : false,
      "id_str" : "13168222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444487338647769088\/bXO_JEA6_normal.jpeg",
      "id" : 13168222,
      "verified" : false
    }
  },
  "id" : 343322853925597184,
  "created_at" : "2013-06-08 11:05:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pettit",
      "screen_name" : "nickrp",
      "indices" : [ 3, 10 ],
      "id_str" : "15349708",
      "id" : 15349708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/nCU1o7txeg",
      "expanded_url" : "http:\/\/i.imgur.com\/ksXryF8.png",
      "display_url" : "i.imgur.com\/ksXryF8.png"
    } ]
  },
  "geo" : { },
  "id_str" : "343206700867780609",
  "text" : "RT @nickrp: Who are we? http:\/\/t.co\/nCU1o7txeg (via reddit)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/nCU1o7txeg",
        "expanded_url" : "http:\/\/i.imgur.com\/ksXryF8.png",
        "display_url" : "i.imgur.com\/ksXryF8.png"
      } ]
    },
    "geo" : { },
    "id_str" : "343206502015856640",
    "text" : "Who are we? http:\/\/t.co\/nCU1o7txeg (via reddit)",
    "id" : 343206502015856640,
    "created_at" : "2013-06-08 03:23:01 +0000",
    "user" : {
      "name" : "Nick Pettit",
      "screen_name" : "nickrp",
      "protected" : false,
      "id_str" : "15349708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523575621721415680\/o5nRO20T_normal.jpeg",
      "id" : 15349708,
      "verified" : false
    }
  },
  "id" : 343206700867780609,
  "created_at" : "2013-06-08 03:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 14, 26 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "Tony Pitale",
      "screen_name" : "tpitale",
      "indices" : [ 27, 35 ],
      "id_str" : "6291182",
      "id" : 6291182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343203505777025024",
  "geo" : { },
  "id_str" : "343203909495562240",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @juliepagano @tpitale it\u2019s kind of hard to assume people just know this stuff. :(",
  "id" : 343203909495562240,
  "in_reply_to_status_id" : 343203505777025024,
  "created_at" : "2013-06-08 03:12:43 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343202958084829184",
  "geo" : { },
  "id_str" : "343203160636133376",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @aquaranto already plenty on Etsy, but didn\u2019t think to look until today. Might post about how we made it.",
  "id" : 343203160636133376,
  "in_reply_to_status_id" : 343202958084829184,
  "created_at" : "2013-06-08 03:09:44 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Sanders",
      "screen_name" : "isaacsanders",
      "indices" : [ 0, 13 ],
      "id_str" : "31571600",
      "id" : 31571600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/yhjteaaViy",
      "expanded_url" : "http:\/\/nickelcityruby.com",
      "display_url" : "nickelcityruby.com"
    } ]
  },
  "in_reply_to_status_id_str" : "343200950107901953",
  "geo" : { },
  "id_str" : "343201951481208834",
  "in_reply_to_user_id" : 31571600,
  "text" : "@isaacsanders http:\/\/t.co\/yhjteaaViy",
  "id" : 343201951481208834,
  "in_reply_to_status_id" : 343200950107901953,
  "created_at" : "2013-06-08 03:04:56 +0000",
  "in_reply_to_screen_name" : "isaacsanders",
  "in_reply_to_user_id_str" : "31571600",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343199015522942976",
  "text" : "I fail at nearly 80% of Vines I want to take. There\u2019s no undo or import if the app paused or you canceled an upload. I can\u2019t handle it.",
  "id" : 343199015522942976,
  "created_at" : "2013-06-08 02:53:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343195645764587520",
  "geo" : { },
  "id_str" : "343198037730013185",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @aquaranto we made the ticket. I did the design, she made it scratch offable",
  "id" : 343198037730013185,
  "in_reply_to_status_id" : 343195645764587520,
  "created_at" : "2013-06-08 02:49:23 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 51, 61 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/T8HcPf4pHM",
      "expanded_url" : "http:\/\/moby.to\/fq5zgd",
      "display_url" : "moby.to\/fq5zgd"
    } ]
  },
  "geo" : { },
  "id_str" : "343193431557943296",
  "text" : "I failed at Vine but\u2026another Q boy will be joining @aquaranto and myself soon! http:\/\/t.co\/T8HcPf4pHM",
  "id" : 343193431557943296,
  "created_at" : "2013-06-08 02:31:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "indices" : [ 3, 13 ],
      "id_str" : "14848965",
      "id" : 14848965
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GFontenot\/status\/343172519802576896\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/FmEMVj0QPs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMMxlqwCIAAOPQq.png",
      "id_str" : "343172519810965504",
      "id" : 343172519810965504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMMxlqwCIAAOPQq.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FmEMVj0QPs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343182761336635392",
  "text" : "RT @GFontenot: The elegance of Vesper lies in it's simplicity. Just beautiful. http:\/\/t.co\/FmEMVj0QPs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GFontenot\/status\/343172519802576896\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/FmEMVj0QPs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMMxlqwCIAAOPQq.png",
        "id_str" : "343172519810965504",
        "id" : 343172519810965504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMMxlqwCIAAOPQq.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FmEMVj0QPs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.363686, -71.229919 ]
    },
    "id_str" : "343172519802576896",
    "text" : "The elegance of Vesper lies in it's simplicity. Just beautiful. http:\/\/t.co\/FmEMVj0QPs",
    "id" : 343172519802576896,
    "created_at" : "2013-06-08 01:07:59 +0000",
    "user" : {
      "name" : "Gordon Fontenot",
      "screen_name" : "GFontenot",
      "protected" : false,
      "id_str" : "14848965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261716039\/68df3c14b447a5604ebfe16373ed2e08_normal.jpeg",
      "id" : 14848965,
      "verified" : false
    }
  },
  "id" : 343182761336635392,
  "created_at" : "2013-06-08 01:48:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Wright",
      "screen_name" : "jwright",
      "indices" : [ 0, 8 ],
      "id_str" : "77673",
      "id" : 77673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343181555478433792",
  "geo" : { },
  "id_str" : "343182592457199616",
  "in_reply_to_user_id" : 77673,
  "text" : "@jwright wat",
  "id" : 343182592457199616,
  "in_reply_to_status_id" : 343181555478433792,
  "created_at" : "2013-06-08 01:48:00 +0000",
  "in_reply_to_screen_name" : "jwright",
  "in_reply_to_user_id_str" : "77673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/wTB7YYcqoD",
      "expanded_url" : "http:\/\/www.mosaic.io\/",
      "display_url" : "mosaic.io"
    } ]
  },
  "geo" : { },
  "id_str" : "343118896489979905",
  "text" : "Stunned: http:\/\/t.co\/wTB7YYcqoD",
  "id" : 343118896489979905,
  "created_at" : "2013-06-07 21:34:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Brian Castner",
      "screen_name" : "Brian_Castner",
      "indices" : [ 63, 77 ],
      "id_str" : "194383196",
      "id" : 194383196
    }, {
      "name" : "Fresh Air",
      "screen_name" : "nprfreshair",
      "indices" : [ 85, 97 ],
      "id_str" : "13783772",
      "id" : 13783772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/QK1DRyb2Si",
      "expanded_url" : "http:\/\/nprfreshair.tumblr.com\/post\/52397742223\/the-stakes-were-all-too-low-suddenly-whether-i",
      "display_url" : "nprfreshair.tumblr.com\/post\/523977422\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343113366790873088",
  "text" : "\"The stakes were all too low suddenly\" - @coworkbuffalo member @Brian_Castner was on @nprfreshair again today http:\/\/t.co\/QK1DRyb2Si",
  "id" : 343113366790873088,
  "created_at" : "2013-06-07 21:12:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 6, 11 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343103939002126337",
  "geo" : { },
  "id_str" : "343104337221918720",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @r00k big shoes. Literally.",
  "id" : 343104337221918720,
  "in_reply_to_status_id" : 343103939002126337,
  "created_at" : "2013-06-07 20:37:03 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan O'Sullivan",
      "screen_name" : "bos31337",
      "indices" : [ 3, 12 ],
      "id_str" : "6897142",
      "id" : 6897142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bos31337\/status\/342383227383721984\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/vE4fzNyXCT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBjuzWCMAAKf1p.jpg",
      "id_str" : "342383227387916288",
      "id" : 342383227387916288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBjuzWCMAAKf1p.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 545
      } ],
      "display_url" : "pic.twitter.com\/vE4fzNyXCT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343092264526028800",
  "text" : "RT @bos31337: This one goes out to all the Unix historians out there. http:\/\/t.co\/vE4fzNyXCT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bos31337\/status\/342383227383721984\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/vE4fzNyXCT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBjuzWCMAAKf1p.jpg",
        "id_str" : "342383227387916288",
        "id" : 342383227387916288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBjuzWCMAAKf1p.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 545
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 545
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 545
        } ],
        "display_url" : "pic.twitter.com\/vE4fzNyXCT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342383227383721984",
    "text" : "This one goes out to all the Unix historians out there. http:\/\/t.co\/vE4fzNyXCT",
    "id" : 342383227383721984,
    "created_at" : "2013-06-05 20:51:37 +0000",
    "user" : {
      "name" : "Bryan O'Sullivan",
      "screen_name" : "bos31337",
      "protected" : false,
      "id_str" : "6897142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1461434495\/bos-headshot_normal.jpg",
      "id" : 6897142,
      "verified" : false
    }
  },
  "id" : 343092264526028800,
  "created_at" : "2013-06-07 19:49:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343076003926667264",
  "geo" : { },
  "id_str" : "343076164543315969",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Nope, I'm seeing Book of Mormon instead :)",
  "id" : 343076164543315969,
  "in_reply_to_status_id" : 343076003926667264,
  "created_at" : "2013-06-07 18:45:06 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Q5ps6TMOfq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OAObCUtnJbI",
      "display_url" : "youtube.com\/watch?v=OAObCU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343075678486401024",
  "text" : "How I'm imagining the few Apple fanboys that are taking pictures of WWDC banners: http:\/\/t.co\/Q5ps6TMOfq",
  "id" : 343075678486401024,
  "created_at" : "2013-06-07 18:43:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Magazine",
      "screen_name" : "BuffMagDotCom",
      "indices" : [ 3, 17 ],
      "id_str" : "296956393",
      "id" : 296956393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U6F2Aysdmb",
      "expanded_url" : "http:\/\/bit.ly\/10K8c5r",
      "display_url" : "bit.ly\/10K8c5r"
    } ]
  },
  "geo" : { },
  "id_str" : "343071545360527360",
  "text" : "RT @BuffMagDotCom: Looking for a lunch on the go? Use this awesome Buffalo Food Truck tracker to find your favorite local food trucks! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/U6F2Aysdmb",
        "expanded_url" : "http:\/\/bit.ly\/10K8c5r",
        "display_url" : "bit.ly\/10K8c5r"
      } ]
    },
    "geo" : { },
    "id_str" : "342666214172135424",
    "text" : "Looking for a lunch on the go? Use this awesome Buffalo Food Truck tracker to find your favorite local food trucks! http:\/\/t.co\/U6F2Aysdmb",
    "id" : 342666214172135424,
    "created_at" : "2013-06-06 15:36:06 +0000",
    "user" : {
      "name" : "Buffalo Magazine",
      "screen_name" : "BuffMagDotCom",
      "protected" : false,
      "id_str" : "296956393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524203746138394625\/C12r0-vu_normal.jpeg",
      "id" : 296956393,
      "verified" : false
    }
  },
  "id" : 343071545360527360,
  "created_at" : "2013-06-07 18:26:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TWaKgn0CVg",
      "expanded_url" : "http:\/\/bit.ly\/17uNkXw",
      "display_url" : "bit.ly\/17uNkXw"
    } ]
  },
  "geo" : { },
  "id_str" : "343070616888418304",
  "text" : "RT @ashedryden: My slides (with sources for data) from last night\u2019s talk at SF Ruby\/Women Who Code\/PyLadies are available here: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/TWaKgn0CVg",
        "expanded_url" : "http:\/\/bit.ly\/17uNkXw",
        "display_url" : "bit.ly\/17uNkXw"
      } ]
    },
    "geo" : { },
    "id_str" : "343068327524061184",
    "text" : "My slides (with sources for data) from last night\u2019s talk at SF Ruby\/Women Who Code\/PyLadies are available here: http:\/\/t.co\/TWaKgn0CVg",
    "id" : 343068327524061184,
    "created_at" : "2013-06-07 18:13:57 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 343070616888418304,
  "created_at" : "2013-06-07 18:23:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 13, 19 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343051572122615808",
  "geo" : { },
  "id_str" : "343051844341354496",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude @mwn3d Time to get WEIRD",
  "id" : 343051844341354496,
  "in_reply_to_status_id" : 343051572122615808,
  "created_at" : "2013-06-07 17:08:27 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343050015196999683",
  "text" : "Someone just please give me the new iOS 7 docs and save me from the punditry and Apple blogs.",
  "id" : 343050015196999683,
  "created_at" : "2013-06-07 17:01:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarahneedleman",
      "screen_name" : "sarahneedleman",
      "indices" : [ 3, 18 ],
      "id_str" : "2484754183",
      "id" : 2484754183
    }, {
      "name" : "Alexis Ohanian",
      "screen_name" : "alexisohanian",
      "indices" : [ 117, 131 ],
      "id_str" : "811350",
      "id" : 811350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/QTzQY7ybna",
      "expanded_url" : "http:\/\/www.linkedin.com\/today\/post\/article\/20130604184748-4421225-getting-things-done-grade-point-average?trk=eml-mktg-condig-0108-p1",
      "display_url" : "linkedin.com\/today\/post\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343048264775503872",
  "text" : "RT @sarahneedleman: Listen up college grads! You don't need to wait for permission to be awesome, says the very wise @alexisohanian http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexis Ohanian",
        "screen_name" : "alexisohanian",
        "indices" : [ 97, 111 ],
        "id_str" : "811350",
        "id" : 811350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/QTzQY7ybna",
        "expanded_url" : "http:\/\/www.linkedin.com\/today\/post\/article\/20130604184748-4421225-getting-things-done-grade-point-average?trk=eml-mktg-condig-0108-p1",
        "display_url" : "linkedin.com\/today\/post\/art\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343013915527098369",
    "text" : "Listen up college grads! You don't need to wait for permission to be awesome, says the very wise @alexisohanian http:\/\/t.co\/QTzQY7ybna",
    "id" : 343013915527098369,
    "created_at" : "2013-06-07 14:37:45 +0000",
    "user" : {
      "name" : "Sarah E. Needleman",
      "screen_name" : "saraheneedleman",
      "protected" : false,
      "id_str" : "63141999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2853556626\/6899e1295b979f665d4d3d8df03b64c7_normal.jpeg",
      "id" : 63141999,
      "verified" : true
    }
  },
  "id" : 343048264775503872,
  "created_at" : "2013-06-07 16:54:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "indices" : [ 3, 13 ],
      "id_str" : "1488886736",
      "id" : 1488886736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343046334095437826",
  "text" : "RT @PRISM_NSA: Man, ever wake up and find literally a billion emails piles up overnight?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342963416220200961",
    "text" : "Man, ever wake up and find literally a billion emails piles up overnight?",
    "id" : 342963416220200961,
    "created_at" : "2013-06-07 11:17:05 +0000",
    "user" : {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "protected" : false,
      "id_str" : "1488886736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3773956794\/9527309c6d84203cdb76911261035337_normal.jpeg",
      "id" : 1488886736,
      "verified" : false
    }
  },
  "id" : 343046334095437826,
  "created_at" : "2013-06-07 16:46:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343023814227140608",
  "text" : "RT @gabrielgironda: Obama: No warrantless wiretaps if you elect me.*\n\n*\u1D0F\uA730\uA730\u1D07\u0280 \u0274\u1D0F\u1D1B \u1D20\u1D00\u029F\u026A\u1D05 \u026A\u0274 \u1D00\u029F\u1D00\uA731\u1D0B\u1D00, \u029C\u1D00\u1D21\u1D00\u026A\u026A, \u1D0F\u0280 \u1D1B\u029C\u1D07 48 \u1D04\u1D0F\u0274\u1D1B\u026A\u0262\u1D1C\u1D0F\u1D1C\uA731 \uA731\u1D1B\u1D00\u1D1B\u1D07\uA731",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343022443260170241",
    "text" : "Obama: No warrantless wiretaps if you elect me.*\n\n*\u1D0F\uA730\uA730\u1D07\u0280 \u0274\u1D0F\u1D1B \u1D20\u1D00\u029F\u026A\u1D05 \u026A\u0274 \u1D00\u029F\u1D00\uA731\u1D0B\u1D00, \u029C\u1D00\u1D21\u1D00\u026A\u026A, \u1D0F\u0280 \u1D1B\u029C\u1D07 48 \u1D04\u1D0F\u0274\u1D1B\u026A\u0262\u1D1C\u1D0F\u1D1C\uA731 \uA731\u1D1B\u1D00\u1D1B\u1D07\uA731",
    "id" : 343022443260170241,
    "created_at" : "2013-06-07 15:11:38 +0000",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 343023814227140608,
  "created_at" : "2013-06-07 15:17:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/NIXBWqjf5M",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?feature=youtu.be&t=1m33s&v=IzUX_1jaO_I&desktop_uri=%2Fwatch%3Fv%3DIzUX_1jaO_I%26feature%3Dyoutu.be%26t%3D1m33s",
      "display_url" : "m.youtube.com\/#\/watch?featur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342844466979299328",
  "text" : "Enterprise Automation has vision! http:\/\/t.co\/NIXBWqjf5M",
  "id" : 342844466979299328,
  "created_at" : "2013-06-07 03:24:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rdrc",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/GVV0ii44KT",
      "expanded_url" : "https:\/\/speakerdeck.com\/tenderlove\/americas-next-top-engineer",
      "display_url" : "speakerdeck.com\/tenderlove\/ame\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342842069921972226",
  "text" : "RT @tenderlove: America's Next Top Engineer slides. #rdrc https:\/\/t.co\/GVV0ii44KT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rdrc",
        "indices" : [ 36, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/GVV0ii44KT",
        "expanded_url" : "https:\/\/speakerdeck.com\/tenderlove\/americas-next-top-engineer",
        "display_url" : "speakerdeck.com\/tenderlove\/ame\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342835787236261888",
    "text" : "America's Next Top Engineer slides. #rdrc https:\/\/t.co\/GVV0ii44KT",
    "id" : 342835787236261888,
    "created_at" : "2013-06-07 02:49:55 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 342842069921972226,
  "created_at" : "2013-06-07 03:14:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Dobson",
      "screen_name" : "EricDobson",
      "indices" : [ 3, 14 ],
      "id_str" : "77030702",
      "id" : 77030702
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 16, 22 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342816701383053312",
  "text" : "RT @EricDobson: @qrush Having been in the military, I'll never be surprised at what people convince themselves they're doing *for* their co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "342771462068912130",
    "geo" : { },
    "id_str" : "342814993298890753",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Having been in the military, I'll never be surprised at what people convince themselves they're doing *for* their country.",
    "id" : 342814993298890753,
    "in_reply_to_status_id" : 342771462068912130,
    "created_at" : "2013-06-07 01:27:18 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Eric Dobson",
      "screen_name" : "EricDobson",
      "protected" : false,
      "id_str" : "77030702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619549512\/01_Perugia_Avatar_normal.jpg",
      "id" : 77030702,
      "verified" : false
    }
  },
  "id" : 342816701383053312,
  "created_at" : "2013-06-07 01:34:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "indices" : [ 3, 13 ],
      "id_str" : "1488886736",
      "id" : 1488886736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342789575900532736",
  "text" : "RT @PRISM_NSA: So, who else is pumped about Google Glass?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342786792845615104",
    "text" : "So, who else is pumped about Google Glass?",
    "id" : 342786792845615104,
    "created_at" : "2013-06-06 23:35:14 +0000",
    "user" : {
      "name" : "PRISM US Gov",
      "screen_name" : "PRISM_NSA",
      "protected" : false,
      "id_str" : "1488886736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3773956794\/9527309c6d84203cdb76911261035337_normal.jpeg",
      "id" : 1488886736,
      "verified" : false
    }
  },
  "id" : 342789575900532736,
  "created_at" : "2013-06-06 23:46:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342771462068912130",
  "text" : "What\u2019s sad is that I\u2019m sure many engineers, programmers, and designers got paid to work on these systems, and didn\u2019t consider it a problem.",
  "id" : 342771462068912130,
  "created_at" : "2013-06-06 22:34:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342771109344706561",
  "text" : "\uD83D\uDE21 \u201CThey quite literally can watch your ideas form as you type\u201D",
  "id" : 342771109344706561,
  "created_at" : "2013-06-06 22:32:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/HB8zSGsns2",
      "expanded_url" : "http:\/\/wapo.st\/188a7JK",
      "display_url" : "wapo.st\/188a7JK"
    } ]
  },
  "geo" : { },
  "id_str" : "342770505599827969",
  "text" : "This is sickening: http:\/\/t.co\/HB8zSGsns2",
  "id" : 342770505599827969,
  "created_at" : "2013-06-06 22:30:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Randazzo",
      "screen_name" : "Randazzoj",
      "indices" : [ 3, 13 ],
      "id_str" : "8126322",
      "id" : 8126322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/M3yxbsNOd5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vgQidVzdneE",
      "display_url" : "youtube.com\/watch?v=vgQidV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342730424876933121",
  "text" : "RT @Randazzoj: Hey guys, just a quick heads up that there's a 10-hour-long video of Riker and Picard walking to synth music: http:\/\/t.co\/M3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/M3yxbsNOd5",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vgQidVzdneE",
        "display_url" : "youtube.com\/watch?v=vgQidV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342726256573427712",
    "text" : "Hey guys, just a quick heads up that there's a 10-hour-long video of Riker and Picard walking to synth music: http:\/\/t.co\/M3yxbsNOd5",
    "id" : 342726256573427712,
    "created_at" : "2013-06-06 19:34:41 +0000",
    "user" : {
      "name" : "Joe Randazzo",
      "screen_name" : "Randazzoj",
      "protected" : false,
      "id_str" : "8126322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454598011025620992\/zXYWP8gq_normal.jpeg",
      "id" : 8126322,
      "verified" : false
    }
  },
  "id" : 342730424876933121,
  "created_at" : "2013-06-06 19:51:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    }, {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 10, 22 ],
      "id_str" : "8828952",
      "id" : 8828952
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 23, 35 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342675987298926592",
  "geo" : { },
  "id_str" : "342726457233125376",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett @codeofficer @bcardarella &lt;3",
  "id" : 342726457233125376,
  "in_reply_to_status_id" : 342675987298926592,
  "created_at" : "2013-06-06 19:35:29 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 64, 73 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342708919443005440",
  "geo" : { },
  "id_str" : "342710003926437889",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky I might throw it in, actually. that's ~50 articles from @gitready + 43 Rebases. D:",
  "id" : 342710003926437889,
  "in_reply_to_status_id" : 342708919443005440,
  "created_at" : "2013-06-06 18:30:06 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342708919443005440",
  "geo" : { },
  "id_str" : "342709209852440576",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky You crazy.",
  "id" : 342709209852440576,
  "in_reply_to_status_id" : 342708919443005440,
  "created_at" : "2013-06-06 18:26:57 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 51, 58 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/aNGUn0lWWy",
      "expanded_url" : "https:\/\/github.com\/blog\/246-github-rebase-6",
      "display_url" : "github.com\/blog\/246-githu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342708596523532288",
  "text" : "That being said, I miss seeing data like this from @github. Feels like a time machine: https:\/\/t.co\/aNGUn0lWWy",
  "id" : 342708596523532288,
  "created_at" : "2013-06-06 18:24:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 17, 27 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 33, 44 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/NUE6xhUy5E",
      "expanded_url" : "http:\/\/quaran.to\/",
      "display_url" : "quaran.to"
    } ]
  },
  "geo" : { },
  "id_str" : "342708138555883521",
  "text" : "All my personal, @37signals, and @thoughtbot writing in one place: http:\/\/t.co\/NUE6xhUy5E What a crazy trip since since 2007.",
  "id" : 342708138555883521,
  "created_at" : "2013-06-06 18:22:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342676325523390466",
  "geo" : { },
  "id_str" : "342687126510530560",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench are you actually going to refund the subscriptions?",
  "id" : 342687126510530560,
  "in_reply_to_status_id" : 342676325523390466,
  "created_at" : "2013-06-06 16:59:12 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Tichenor",
      "screen_name" : "Beercraft",
      "indices" : [ 13, 23 ],
      "id_str" : "13837402",
      "id" : 13837402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342676325523390466",
  "geo" : { },
  "id_str" : "342685226234957824",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench @Beercraft the \"wine issue\" PS note is priceless",
  "id" : 342685226234957824,
  "in_reply_to_status_id" : 342676325523390466,
  "created_at" : "2013-06-06 16:51:39 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WEOCWW3Spk",
      "expanded_url" : "http:\/\/www.buffalospree.com\/Blogs\/Random-Rants\/Annual-2013\/Two-readers-cancel-subscriptions-over-June-Proud-issue\/",
      "display_url" : "buffalospree.com\/Blogs\/Random-R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342684460485050368",
  "text" : "RT @NYWineWench: Homophobes who cancelled their Spree subscriptions after the PROUD issue cite Christianity, chastity, etc. etc. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/WEOCWW3Spk",
        "expanded_url" : "http:\/\/www.buffalospree.com\/Blogs\/Random-Rants\/Annual-2013\/Two-readers-cancel-subscriptions-over-June-Proud-issue\/",
        "display_url" : "buffalospree.com\/Blogs\/Random-R\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342679961737523200",
    "text" : "Homophobes who cancelled their Spree subscriptions after the PROUD issue cite Christianity, chastity, etc. etc. http:\/\/t.co\/WEOCWW3Spk",
    "id" : 342679961737523200,
    "created_at" : "2013-06-06 16:30:44 +0000",
    "user" : {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "protected" : false,
      "id_str" : "72991857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553240923862089728\/a60saFx7_normal.jpeg",
      "id" : 72991857,
      "verified" : false
    }
  },
  "id" : 342684460485050368,
  "created_at" : "2013-06-06 16:48:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xIW1YsdgOF",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
      "display_url" : "nickelcityruby.com\/cfp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "342664655858171906",
  "text" : "RT @jhsu: REMINDER: Nickel City Ruby Conf CFP closes this Sunday! Submit a talk and be part of Buffalo's first Ruby conference! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xIW1YsdgOF",
        "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
        "display_url" : "nickelcityruby.com\/cfp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "342664144123731969",
    "text" : "REMINDER: Nickel City Ruby Conf CFP closes this Sunday! Submit a talk and be part of Buffalo's first Ruby conference! http:\/\/t.co\/xIW1YsdgOF",
    "id" : 342664144123731969,
    "created_at" : "2013-06-06 15:27:53 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 342664655858171906,
  "created_at" : "2013-06-06 15:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342658026857181185",
  "geo" : { },
  "id_str" : "342658329195188227",
  "in_reply_to_user_id" : 72991857,
  "text" : "@NYWineWench Please publish these.",
  "id" : 342658329195188227,
  "in_reply_to_status_id" : 342658026857181185,
  "created_at" : "2013-06-06 15:04:46 +0000",
  "in_reply_to_screen_name" : "juliabwrites",
  "in_reply_to_user_id_str" : "72991857",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 26, 35 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 74, 84 ],
      "id_str" : "14182110",
      "id" : 14182110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uqsXRCj7dG",
      "expanded_url" : "http:\/\/openhack.github.io\/",
      "display_url" : "openhack.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "342654947730538496",
  "text" : "A big welcome to the 67th @OpenHack group in Phoenix, and thanks again to @confreaks for CC licensing this video! http:\/\/t.co\/uqsXRCj7dG",
  "id" : 342654947730538496,
  "created_at" : "2013-06-06 14:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik DeBill",
      "screen_name" : "edebill",
      "indices" : [ 0, 8 ],
      "id_str" : "39057894",
      "id" : 39057894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342621197814607872",
  "geo" : { },
  "id_str" : "342621639009255425",
  "in_reply_to_user_id" : 39057894,
  "text" : "@edebill Liquid means its safe to use on GH pages as a service. I don\u2019t think it would have gotten as popular without it",
  "id" : 342621639009255425,
  "in_reply_to_status_id" : 342621197814607872,
  "created_at" : "2013-06-06 12:38:59 +0000",
  "in_reply_to_screen_name" : "edebill",
  "in_reply_to_user_id_str" : "39057894",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342507714389364736",
  "text" : "Defeated in both Agricola w\/ Gamers\u2019 Deck as well as Merchants &amp; Marauders tonight, but had a lot of fun. Nothing beats Agricola.",
  "id" : 342507714389364736,
  "created_at" : "2013-06-06 05:06:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342412280698396673",
  "geo" : { },
  "id_str" : "342507296968015872",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh nope.",
  "id" : 342507296968015872,
  "in_reply_to_status_id" : 342412280698396673,
  "created_at" : "2013-06-06 05:04:37 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 18, 23 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342458700042215426",
  "geo" : { },
  "id_str" : "342507232501587969",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella it\u2019s @jhsu \u2018s",
  "id" : 342507232501587969,
  "in_reply_to_status_id" : 342458700042215426,
  "created_at" : "2013-06-06 05:04:22 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Gershman",
      "screen_name" : "ZachGersh",
      "indices" : [ 0, 10 ],
      "id_str" : "127905827",
      "id" : 127905827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342410751744565251",
  "geo" : { },
  "id_str" : "342410898708783104",
  "in_reply_to_user_id" : 127905827,
  "text" : "@ZachGersh I liked it a little better but it\u2019s still pretty tedious, and earlyx",
  "id" : 342410898708783104,
  "in_reply_to_status_id" : 342410751744565251,
  "created_at" : "2013-06-05 22:41:34 +0000",
  "in_reply_to_screen_name" : "ZachGersh",
  "in_reply_to_user_id_str" : "127905827",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "indices" : [ 3, 9 ],
      "id_str" : "15062828",
      "id" : 15062828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342389958016901122",
  "text" : "RT @vrunt: whats the deal with airplane food? why don't they make the entire plane out of the food?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342315246406475777",
    "text" : "whats the deal with airplane food? why don't they make the entire plane out of the food?",
    "id" : 342315246406475777,
    "created_at" : "2013-06-05 16:21:29 +0000",
    "user" : {
      "name" : "nate \u2615\uFE0F",
      "screen_name" : "vrunt",
      "protected" : false,
      "id_str" : "15062828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566801374143586305\/yApDWRcm_normal.jpeg",
      "id" : 15062828,
      "verified" : false
    }
  },
  "id" : 342389958016901122,
  "created_at" : "2013-06-05 21:18:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 0, 10 ],
      "id_str" : "14319947",
      "id" : 14319947
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 11, 23 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342343906706468864",
  "geo" : { },
  "id_str" : "342353892933246976",
  "in_reply_to_user_id" : 14319947,
  "text" : "@onyxraven @SteveStreza i guess i'm confused by the \"watch out\" warning. care to elaborate?",
  "id" : 342353892933246976,
  "in_reply_to_status_id" : 342343906706468864,
  "created_at" : "2013-06-05 18:55:03 +0000",
  "in_reply_to_screen_name" : "onyxraven",
  "in_reply_to_user_id_str" : "14319947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    }, {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 13, 23 ],
      "id_str" : "14319947",
      "id" : 14319947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342352164833878018",
  "geo" : { },
  "id_str" : "342352870546472960",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza @onyxraven geez that\u2019s the default service apple provides?! Seems like overkill. Any good reading on this?",
  "id" : 342352870546472960,
  "in_reply_to_status_id" : 342352164833878018,
  "created_at" : "2013-06-05 18:50:59 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Hart",
      "screen_name" : "onyxraven",
      "indices" : [ 0, 10 ],
      "id_str" : "14319947",
      "id" : 14319947
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 11, 23 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342343906706468864",
  "geo" : { },
  "id_str" : "342351650066952192",
  "in_reply_to_user_id" : 14319947,
  "text" : "@onyxraven @SteveStreza keep open persistent connections for what? not sure what that's referring to",
  "id" : 342351650066952192,
  "in_reply_to_status_id" : 342343906706468864,
  "created_at" : "2013-06-05 18:46:08 +0000",
  "in_reply_to_screen_name" : "onyxraven",
  "in_reply_to_user_id_str" : "14319947",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342336794949464064",
  "geo" : { },
  "id_str" : "342337778132082689",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt sadly that's a nonstarter for both here right now. I also dont get why a rack middleware is in charge of data\/etc...seems crazy.",
  "id" : 342337778132082689,
  "in_reply_to_status_id" : 342336794949464064,
  "created_at" : "2013-06-05 17:51:01 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 0, 6 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342334578586943488",
  "geo" : { },
  "id_str" : "342336288826994690",
  "in_reply_to_user_id" : 35803,
  "text" : "@mattt Why does it require postgres? also, not having a guide for actually *using* this in an app is hard :(",
  "id" : 342336288826994690,
  "in_reply_to_status_id" : 342334578586943488,
  "created_at" : "2013-06-05 17:45:06 +0000",
  "in_reply_to_screen_name" : "mattt",
  "in_reply_to_user_id_str" : "35803",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    }, {
      "name" : "Mattt Thompson",
      "screen_name" : "mattt",
      "indices" : [ 8, 14 ],
      "id_str" : "35803",
      "id" : 35803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342334001761116160",
  "geo" : { },
  "id_str" : "342334403327963136",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes @mattt Helios looks nice, kind of what I started spiking out. I'll give it a shot.",
  "id" : 342334403327963136,
  "in_reply_to_status_id" : 342334001761116160,
  "created_at" : "2013-06-05 17:37:36 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342332817079951361",
  "geo" : { },
  "id_str" : "342333068436193280",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes sending them seems to be easy, i'm talking about the backend integration of registering devices, keeping track of data, etc",
  "id" : 342333068436193280,
  "in_reply_to_status_id" : 342332817079951361,
  "created_at" : "2013-06-05 17:32:18 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342332408701526019",
  "text" : "Any recommendations for push notification services?",
  "id" : 342332408701526019,
  "created_at" : "2013-06-05 17:29:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 18, 28 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/aNuGQqAynv",
      "expanded_url" : "http:\/\/railsgirlssummerofcode.org\/campaign\/",
      "display_url" : "railsgirlssummerofcode.org\/campaign\/"
    } ]
  },
  "geo" : { },
  "id_str" : "342314238376804352",
  "text" : "Very happy to say @37signals is sponsoring Rails Girls' SoC! http:\/\/t.co\/aNuGQqAynv",
  "id" : 342314238376804352,
  "created_at" : "2013-06-05 16:17:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/GVwrsZUyaZ",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/4r7wHMg5Yjg",
      "display_url" : "youtube.com\/embed\/4r7wHMg5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342306094577770496",
  "text" : "Current status: https:\/\/t.co\/GVwrsZUyaZ",
  "id" : 342306094577770496,
  "created_at" : "2013-06-05 15:45:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342300788569284612",
  "geo" : { },
  "id_str" : "342301014638088192",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan we've been having similar problems here in Buffalo but this is pretty bad.",
  "id" : 342301014638088192,
  "in_reply_to_status_id" : 342300788569284612,
  "created_at" : "2013-06-05 15:24:56 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342276387073318914",
  "geo" : { },
  "id_str" : "342281222485061632",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock not sure :(",
  "id" : 342281222485061632,
  "in_reply_to_status_id" : 342276387073318914,
  "created_at" : "2013-06-05 14:06:17 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342130853423489025",
  "text" : "Starting to get the hang of Scrolls. Feels tedious though :(",
  "id" : 342130853423489025,
  "created_at" : "2013-06-05 04:08:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/rNwvKeP0VL",
      "expanded_url" : "http:\/\/rg3.github.io\/youtube-dl\/",
      "display_url" : "rg3.github.io\/youtube-dl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "342119788732092418",
  "text" : "Also if you need it, http:\/\/t.co\/rNwvKeP0VL is amazing. Ripped a 2GB, 2 hour video from youtube in an hour.",
  "id" : 342119788732092418,
  "created_at" : "2013-06-05 03:24:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confreaks, LLC",
      "screen_name" : "confreaks",
      "indices" : [ 14, 24 ],
      "id_str" : "14182110",
      "id" : 14182110
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 56, 65 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iS3r5LRnVG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=bQgbSXBjpz0",
      "display_url" : "youtube.com\/watch?v=bQgbSX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342119688223981568",
  "text" : "Big thanks to @confreaks for CC licensing their videos, @OpenHack now has a intro video: http:\/\/t.co\/iS3r5LRnVG",
  "id" : 342119688223981568,
  "created_at" : "2013-06-05 03:24:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 3, 15 ],
      "id_str" : "6556972",
      "id" : 6556972
    }, {
      "name" : "OpenHackSAV",
      "screen_name" : "OpenHackSAV",
      "indices" : [ 39, 51 ],
      "id_str" : "1375352149",
      "id" : 1375352149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackforchange",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342104910600486912",
  "text" : "RT @techpickles: Made good progress at @OpenHackSAV continuing work from #hackforchange: adapting the adopt-a-hydrant for Savannah\u2019s commun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHackSAV",
        "screen_name" : "OpenHackSAV",
        "indices" : [ 22, 34 ],
        "id_str" : "1375352149",
        "id" : 1375352149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hackforchange",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342103974817697792",
    "text" : "Made good progress at @OpenHackSAV continuing work from #hackforchange: adapting the adopt-a-hydrant for Savannah\u2019s community garden program",
    "id" : 342103974817697792,
    "created_at" : "2013-06-05 02:21:58 +0000",
    "user" : {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "protected" : false,
      "id_str" : "6556972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3557013243\/43646b13149e21c8c9b76f3d272e41e5_normal.jpeg",
      "id" : 6556972,
      "verified" : false
    }
  },
  "id" : 342104910600486912,
  "created_at" : "2013-06-05 02:25:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342077635138035712",
  "geo" : { },
  "id_str" : "342082920116260865",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle same! Did you pick Order too?",
  "id" : 342082920116260865,
  "in_reply_to_status_id" : 342077635138035712,
  "created_at" : "2013-06-05 00:58:18 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342066365450035201",
  "text" : "Oculus Rift made me seasick, but it still put a smile on my face. Hard to imagine wearing one for long stretches of time.",
  "id" : 342066365450035201,
  "created_at" : "2013-06-04 23:52:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342064405669888001",
  "text" : "OH (while wearing Oculus Rift) \"This is a bullshit tree\"",
  "id" : 342064405669888001,
  "created_at" : "2013-06-04 23:44:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 33, 42 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/342059828174270464\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/eXgAe73R08",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL89mfaCMAE_98w.jpg",
      "id_str" : "342059828178464769",
      "id" : 342059828178464769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL89mfaCMAE_98w.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eXgAe73R08"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342059828174270464",
  "text" : "Oculus Rift making an appearance @openhack Buffalo! http:\/\/t.co\/eXgAe73R08",
  "id" : 342059828174270464,
  "created_at" : "2013-06-04 23:26:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 3, 11 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/06zxDW37EV",
      "expanded_url" : "http:\/\/bit.ly\/17YHbUs",
      "display_url" : "bit.ly\/17YHbUs"
    } ]
  },
  "geo" : { },
  "id_str" : "342036743060590592",
  "text" : "RT @drbrain: I documented the Marshal format: http:\/\/t.co\/06zxDW37EV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/06zxDW37EV",
        "expanded_url" : "http:\/\/bit.ly\/17YHbUs",
        "display_url" : "bit.ly\/17YHbUs"
      } ]
    },
    "geo" : { },
    "id_str" : "342032983148097537",
    "text" : "I documented the Marshal format: http:\/\/t.co\/06zxDW37EV",
    "id" : 342032983148097537,
    "created_at" : "2013-06-04 21:39:52 +0000",
    "user" : {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "protected" : false,
      "id_str" : "670283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472446327373053952\/oJXOO4GL_normal.jpeg",
      "id" : 670283,
      "verified" : false
    }
  },
  "id" : 342036743060590592,
  "created_at" : "2013-06-04 21:54:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/RCmTZ2zdhn",
      "expanded_url" : "http:\/\/revealapp.com\/",
      "display_url" : "revealapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "342012112085856256",
  "text" : "Just hooked up http:\/\/t.co\/RCmTZ2zdhn and it's pretty neat.",
  "id" : 342012112085856256,
  "created_at" : "2013-06-04 20:16:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342005481830764545",
  "text" : "Finally updated to Mountain Lion. It's never too late, right?",
  "id" : 342005481830764545,
  "created_at" : "2013-06-04 19:50:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "indices" : [ 3, 15 ],
      "id_str" : "6927562",
      "id" : 6927562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341971179655020544",
  "text" : "RT @thomasfuchs: There\u2019s a way out of the startup madness: build sustainable, slow-growth businesses that charge money to provide real valu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341970645850132481",
    "text" : "There\u2019s a way out of the startup madness: build sustainable, slow-growth businesses that charge money to provide real value. Just sayin'",
    "id" : 341970645850132481,
    "created_at" : "2013-06-04 17:32:10 +0000",
    "user" : {
      "name" : "Thomas Fuchs",
      "screen_name" : "thomasfuchs",
      "protected" : false,
      "id_str" : "6927562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528509543119343616\/bDhQei1L_normal.jpeg",
      "id" : 6927562,
      "verified" : false
    }
  },
  "id" : 341971179655020544,
  "created_at" : "2013-06-04 17:34:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kovalic",
      "screen_name" : "muskrat_john",
      "indices" : [ 3, 16 ],
      "id_str" : "14167540",
      "id" : 14167540
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muskrat_john\/status\/341941546792407041\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/7TP83p20rp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL7SBm7CUAI88uS.jpg",
      "id_str" : "341941546796601346",
      "id" : 341941546796601346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL7SBm7CUAI88uS.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7TP83p20rp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341941745589817344",
  "text" : "RT @muskrat_john: Wanted color on your comic? You had to make and send a guide like this to (I am not kidding) Buffalo, NY. http:\/\/t.co\/7TP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/muskrat_john\/status\/341941546792407041\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/7TP83p20rp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BL7SBm7CUAI88uS.jpg",
        "id_str" : "341941546796601346",
        "id" : 341941546796601346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL7SBm7CUAI88uS.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7TP83p20rp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341941546792407041",
    "text" : "Wanted color on your comic? You had to make and send a guide like this to (I am not kidding) Buffalo, NY. http:\/\/t.co\/7TP83p20rp",
    "id" : 341941546792407041,
    "created_at" : "2013-06-04 15:36:32 +0000",
    "user" : {
      "name" : "John Kovalic",
      "screen_name" : "muskrat_john",
      "protected" : false,
      "id_str" : "14167540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422059990241660928\/yu3fAKNb_normal.jpeg",
      "id" : 14167540,
      "verified" : false
    }
  },
  "id" : 341941745589817344,
  "created_at" : "2013-06-04 15:37:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kovalic",
      "screen_name" : "muskrat_john",
      "indices" : [ 0, 13 ],
      "id_str" : "14167540",
      "id" : 14167540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341941546792407041",
  "geo" : { },
  "id_str" : "341941731228524544",
  "in_reply_to_user_id" : 14167540,
  "text" : "@muskrat_john why Buffalo? (Buffalonian here and huge Munchkin fan!)",
  "id" : 341941731228524544,
  "in_reply_to_status_id" : 341941546792407041,
  "created_at" : "2013-06-04 15:37:16 +0000",
  "in_reply_to_screen_name" : "muskrat_john",
  "in_reply_to_user_id_str" : "14167540",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 0, 8 ],
      "id_str" : "14672651",
      "id" : 14672651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341927578724093952",
  "geo" : { },
  "id_str" : "341927745657397248",
  "in_reply_to_user_id" : 14672651,
  "text" : "@fending Y U NO TXT???111one",
  "id" : 341927745657397248,
  "in_reply_to_status_id" : 341927578724093952,
  "created_at" : "2013-06-04 14:41:41 +0000",
  "in_reply_to_screen_name" : "fending",
  "in_reply_to_user_id_str" : "14672651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/5mMr1WtgDL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=EjDTY3_PBkg",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341927529726218241",
  "text" : "Just wait for it: http:\/\/t.co\/5mMr1WtgDL",
  "id" : 341927529726218241,
  "created_at" : "2013-06-04 14:40:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 3, 11 ],
      "id_str" : "3382151",
      "id" : 3382151
    }, {
      "name" : "Rook",
      "screen_name" : "Rook",
      "indices" : [ 113, 118 ],
      "id_str" : "1229521",
      "id" : 1229521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/mlGaDz3Zm0",
      "expanded_url" : "http:\/\/confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
      "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341926715787976705",
  "text" : "RT @dmosher: If you participate in public speaking at all you should watch this amazing talk from Ben Orenstein (@rook): http:\/\/t.co\/mlGaDz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rook",
        "screen_name" : "Rook",
        "indices" : [ 100, 105 ],
        "id_str" : "1229521",
        "id" : 1229521
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/mlGaDz3Zm0",
        "expanded_url" : "http:\/\/confreaks.com\/videos\/2488-railsconf2013-how-to-talk-to-developers",
        "display_url" : "confreaks.com\/videos\/2488-ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "341926577778597888",
    "text" : "If you participate in public speaking at all you should watch this amazing talk from Ben Orenstein (@rook): http:\/\/t.co\/mlGaDz3Zm0",
    "id" : 341926577778597888,
    "created_at" : "2013-06-04 14:37:03 +0000",
    "user" : {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "protected" : false,
      "id_str" : "3382151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494583437466943489\/m3yZB77Y_normal.png",
      "id" : 3382151,
      "verified" : false
    }
  },
  "id" : 341926715787976705,
  "created_at" : "2013-06-04 14:37:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341775384955731969",
  "geo" : { },
  "id_str" : "341778201950945280",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal would be interesting to see it catch up. I don\u2019t care who wins or loses, just happy that \u2018gem push\u2019 caught fire and everyone wins",
  "id" : 341778201950945280,
  "in_reply_to_status_id" : 341775384955731969,
  "created_at" : "2013-06-04 04:47:27 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "npmbot",
      "screen_name" : "npmjs",
      "indices" : [ 0, 6 ],
      "id_str" : "309528017",
      "id" : 309528017
    }, {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 7, 14 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341743329232424960",
  "geo" : { },
  "id_str" : "341774926010793987",
  "in_reply_to_user_id" : 309528017,
  "text" : "@npmjs @mikeal bring it!! (*\uFF40\u3078\u00B4*)",
  "id" : 341774926010793987,
  "in_reply_to_status_id" : 341743329232424960,
  "created_at" : "2013-06-04 04:34:26 +0000",
  "in_reply_to_screen_name" : "npmjs",
  "in_reply_to_user_id_str" : "309528017",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 0, 5 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341753119274835968",
  "geo" : { },
  "id_str" : "341755375659384832",
  "in_reply_to_user_id" : 1183041,
  "text" : "@wilw the sliders on the character cards suck! we've been using bobby pins instead, you should try it out!",
  "id" : 341755375659384832,
  "in_reply_to_status_id" : 341753119274835968,
  "created_at" : "2013-06-04 03:16:45 +0000",
  "in_reply_to_screen_name" : "wilw",
  "in_reply_to_user_id_str" : "1183041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Tom Lee ",
      "screen_name" : "tjl",
      "indices" : [ 3, 7 ],
      "id_str" : "720863",
      "id" : 720863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341753200774356992",
  "text" : "RT @tjl: once had a Zynga engineer describe \u201Cpinch\u201D to me, process by which they deliberately cause psychological distress to extract money\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341672842590552064",
    "text" : "once had a Zynga engineer describe \u201Cpinch\u201D to me, process by which they deliberately cause psychological distress to extract money\/referrals",
    "id" : 341672842590552064,
    "created_at" : "2013-06-03 21:48:48 +0000",
    "user" : {
      "name" : " Tom Lee ",
      "screen_name" : "tjl",
      "protected" : false,
      "id_str" : "720863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000822121461\/29f58ed5415a1932c20b4af8e4e91492_normal.png",
      "id" : 720863,
      "verified" : false
    }
  },
  "id" : 341753200774356992,
  "created_at" : "2013-06-04 03:08:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/nfe5L7S4jz",
      "expanded_url" : "http:\/\/www.gq.com\/news-politics\/newsmakers\/201306\/kim-jong-il-sushi-chef-kenji-fujimoto-adam-johnson-2013?printable=true",
      "display_url" : "gq.com\/news-politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341748142674427904",
  "text" : "It's sad how \"So Ronely\" is quite accurate: http:\/\/t.co\/nfe5L7S4jz",
  "id" : 341748142674427904,
  "created_at" : "2013-06-04 02:48:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341744988633313281",
  "geo" : { },
  "id_str" : "341745412274806784",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza yeah but this isn't a \"discover stuff\" game. Honestly it doesn't feel like the same company made it.",
  "id" : 341745412274806784,
  "in_reply_to_status_id" : 341744988633313281,
  "created_at" : "2013-06-04 02:37:10 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341744893099667456",
  "text" : "Not really impressed with Scrolls. Single player seems way too difficult or I'm missing something (this from a Nethack &amp; DF fanatic!)",
  "id" : 341744893099667456,
  "created_at" : "2013-06-04 02:35:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341731745458176001",
  "geo" : { },
  "id_str" : "341732303883616256",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison not even sure if there's a way to add people!",
  "id" : 341732303883616256,
  "in_reply_to_status_id" : 341731745458176001,
  "created_at" : "2013-06-04 01:45:04 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaporgrave",
      "screen_name" : "flangy",
      "indices" : [ 3, 10 ],
      "id_str" : "14209746",
      "id" : 14209746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341723461330288641",
  "text" : "RT @flangy: If you play an RPG backwards it's about a dude resurrecting decreasingly powerful creatures until he forgets how.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341720216235028480",
    "text" : "If you play an RPG backwards it's about a dude resurrecting decreasingly powerful creatures until he forgets how.",
    "id" : 341720216235028480,
    "created_at" : "2013-06-04 00:57:03 +0000",
    "user" : {
      "name" : "vaporgrave",
      "screen_name" : "flangy",
      "protected" : false,
      "id_str" : "14209746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563561802621923328\/5mXMD7EY_normal.jpeg",
      "id" : 14209746,
      "verified" : false
    }
  },
  "id" : 341723461330288641,
  "created_at" : "2013-06-04 01:09:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/341723371874156545\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/K2eqpsdLIR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL4LmKBCAAAsOGK.png",
      "id_str" : "341723371878350848",
      "id" : 341723371878350848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL4LmKBCAAAsOGK.png",
      "sizes" : [ {
        "h" : 551,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/K2eqpsdLIR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341723371874156545",
  "text" : "Picked up Scrolls and nabbed \"qrush\", launched the game and I'm already liking these graphics. http:\/\/t.co\/K2eqpsdLIR",
  "id" : 341723371874156545,
  "created_at" : "2013-06-04 01:09:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/oW189zneKl",
      "expanded_url" : "http:\/\/shirt.woot.com\/?variation=4&utm_expid=3762817-11&utm_referrer=http%3A%2F%2Fwww.woot.com%2F",
      "display_url" : "shirt.woot.com\/?variation=4&u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341720922589372416",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub I'm assuming you saw this: http:\/\/t.co\/oW189zneKl",
  "id" : 341720922589372416,
  "created_at" : "2013-06-04 00:59:51 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/YhHKumhyjH",
      "expanded_url" : "https:\/\/github.com\/monospacecollective\/MSCollectionViewCalendarLayout",
      "display_url" : "github.com\/monospacecolle\u2026"
    }, {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/N7VtBfCM8a",
      "expanded_url" : "https:\/\/github.com\/square\/objc-TimesSquare",
      "display_url" : "github.com\/square\/objc-Ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341663050614591488",
  "text" : "Anyone used https:\/\/t.co\/YhHKumhyjH or https:\/\/t.co\/N7VtBfCM8a ? both look pretty nice!",
  "id" : 341663050614591488,
  "created_at" : "2013-06-03 21:09:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald Braithwaite",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341660392075980801",
  "geo" : { },
  "id_str" : "341661846215983104",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald I can't handle these mustaches",
  "id" : 341661846215983104,
  "in_reply_to_status_id" : 341660392075980801,
  "created_at" : "2013-06-03 21:05:06 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/8uEPFm1sS2",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/0ba6b1438f4830db2a243ab8f2e421e5\/tumblr_mng9ug0a8d1qb5gkjo3_500.jpg",
      "display_url" : "24.media.tumblr.com\/0ba6b1438f4830\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341659633561251840",
  "text" : "Current status: http:\/\/t.co\/8uEPFm1sS2",
  "id" : 341659633561251840,
  "created_at" : "2013-06-03 20:56:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/p3KnFMWLKg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0bR75pkAI58&list=UUcBHuQPjWZ-xqgsdViAhuAQ&index=8",
      "display_url" : "youtube.com\/watch?v=0bR75p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341647365222047744",
  "text" : "Anchorman Buffalo. Check out these suits. https:\/\/t.co\/p3KnFMWLKg",
  "id" : 341647365222047744,
  "created_at" : "2013-06-03 20:07:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Roes",
      "screen_name" : "jroes",
      "indices" : [ 0, 6 ],
      "id_str" : "1431461",
      "id" : 1431461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341616307650838531",
  "geo" : { },
  "id_str" : "341616889384038400",
  "in_reply_to_user_id" : 1431461,
  "text" : "@jroes makes up for the presents we woke up to this morning with! :(",
  "id" : 341616889384038400,
  "in_reply_to_status_id" : 341616307650838531,
  "created_at" : "2013-06-03 18:06:28 +0000",
  "in_reply_to_screen_name" : "jroes",
  "in_reply_to_user_id_str" : "1431461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/341616176155197442\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Y0btCcUSKU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL2qGi3CAAAIkEs.jpg",
      "id_str" : "341616176163586048",
      "id" : 341616176163586048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL2qGi3CAAAIkEs.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/Y0btCcUSKU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341616176155197442",
  "text" : "Working at home for the day means I get husky high fives for shipping builds! http:\/\/t.co\/Y0btCcUSKU",
  "id" : 341616176155197442,
  "created_at" : "2013-06-03 18:03:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/7yQRWkmSTi",
      "expanded_url" : "http:\/\/papersplea.se\/",
      "display_url" : "papersplea.se"
    } ]
  },
  "geo" : { },
  "id_str" : "341614707515482112",
  "text" : "Glory to Arstotzka! Papers, Please is going to be out this summer: http:\/\/t.co\/7yQRWkmSTi",
  "id" : 341614707515482112,
  "created_at" : "2013-06-03 17:57:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Wilcox",
      "screen_name" : "rwilcox",
      "indices" : [ 0, 8 ],
      "id_str" : "11766092",
      "id" : 11766092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341572246978056192",
  "geo" : { },
  "id_str" : "341573526303698945",
  "in_reply_to_user_id" : 11766092,
  "text" : "@rwilcox Wat?",
  "id" : 341573526303698945,
  "in_reply_to_status_id" : 341572246978056192,
  "created_at" : "2013-06-03 15:14:09 +0000",
  "in_reply_to_screen_name" : "rwilcox",
  "in_reply_to_user_id_str" : "11766092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "has_many :wizards",
      "screen_name" : "kerrizor",
      "indices" : [ 0, 9 ],
      "id_str" : "2998581",
      "id" : 2998581
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 10, 20 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341570419972767744",
  "geo" : { },
  "id_str" : "341571687487270912",
  "in_reply_to_user_id" : 2998581,
  "text" : "@kerrizor @aspleenic no problem!",
  "id" : 341571687487270912,
  "in_reply_to_status_id" : 341570419972767744,
  "created_at" : "2013-06-03 15:06:51 +0000",
  "in_reply_to_screen_name" : "kerrizor",
  "in_reply_to_user_id_str" : "2998581",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 15, 24 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 52, 66 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/80o2X9y6cF",
      "expanded_url" : "http:\/\/openhack.github.io\/buffalo\/",
      "display_url" : "openhack.github.io\/buffalo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "341571130072645632",
  "text" : "Buffalo's 18th @OpenHack meetup is tomorrow evening @coworkbuffalo. http:\/\/t.co\/80o2X9y6cF",
  "id" : 341571130072645632,
  "created_at" : "2013-06-03 15:04:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 97, 112 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/G7h7abfIpb",
      "expanded_url" : "http:\/\/www.changesinlongitude.com\/things-to-do-in-buffalo-ny\/",
      "display_url" : "changesinlongitude.com\/things-to-do-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341570013129474048",
  "text" : "RT @aspleenic: 11 unique things to do in Buffalo, for real http:\/\/t.co\/G7h7abfIpb - check it out @nickelcityruby goers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 82, 97 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/G7h7abfIpb",
        "expanded_url" : "http:\/\/www.changesinlongitude.com\/things-to-do-in-buffalo-ny\/",
        "display_url" : "changesinlongitude.com\/things-to-do-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "341227421007228929",
    "text" : "11 unique things to do in Buffalo, for real http:\/\/t.co\/G7h7abfIpb - check it out @nickelcityruby goers",
    "id" : 341227421007228929,
    "created_at" : "2013-06-02 16:18:51 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 341570013129474048,
  "created_at" : "2013-06-03 15:00:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/HnTflS8ppy",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
      "display_url" : "nickelcityruby.com\/cfp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "341569797059919872",
  "text" : "RT @nickelcityruby: There are only 6 days left to submit your proposal for Nickel City Ruby! We want to see you in Buffalo! http:\/\/t.co\/HnT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/HnTflS8ppy",
        "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
        "display_url" : "nickelcityruby.com\/cfp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "341569453064081408",
    "text" : "There are only 6 days left to submit your proposal for Nickel City Ruby! We want to see you in Buffalo! http:\/\/t.co\/HnTflS8ppy",
    "id" : 341569453064081408,
    "created_at" : "2013-06-03 14:57:58 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 341569797059919872,
  "created_at" : "2013-06-03 14:59:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/d8amGfIxtu",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp",
      "display_url" : "nickelcityruby.com\/cfp"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/CLdbV3gwoJ",
      "expanded_url" : "http:\/\/vimeo.com\/11040425",
      "display_url" : "vimeo.com\/11040425"
    } ]
  },
  "geo" : { },
  "id_str" : "341569771155894272",
  "text" : "YOU! The one who is on Twitter now! SUBMIT! http:\/\/t.co\/d8amGfIxtu http:\/\/t.co\/CLdbV3gwoJ",
  "id" : 341569771155894272,
  "created_at" : "2013-06-03 14:59:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 9, 18 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/uqsXRCj7dG",
      "expanded_url" : "http:\/\/openhack.github.io\/",
      "display_url" : "openhack.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "341564178458361856",
  "text" : "Up to 66 @OpenHack cities. Where's yours? http:\/\/t.co\/uqsXRCj7dG",
  "id" : 341564178458361856,
  "created_at" : "2013-06-03 14:37:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 0, 5 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 6, 15 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "JP Burke",
      "screen_name" : "yatpay",
      "indices" : [ 16, 23 ],
      "id_str" : "17240983",
      "id" : 17240983
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 68, 82 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341557174343966721",
  "geo" : { },
  "id_str" : "341557370989711360",
  "in_reply_to_user_id" : 33823,
  "text" : "@jhsu @sabiddle @yatpay yes! Need to update the site. 7pm as normal @coworkbuffalo",
  "id" : 341557370989711360,
  "in_reply_to_status_id" : 341557174343966721,
  "created_at" : "2013-06-03 14:09:57 +0000",
  "in_reply_to_screen_name" : "jhsu",
  "in_reply_to_user_id_str" : "33823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cichon",
      "screen_name" : "SteveBuffalo",
      "indices" : [ 0, 13 ],
      "id_str" : "235665553",
      "id" : 235665553
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 52, 66 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341552976193810433",
  "geo" : { },
  "id_str" : "341554197105369088",
  "in_reply_to_user_id" : 235665553,
  "text" : "@SteveBuffalo if you need more humans to be around, @coworkbuffalo would love to have you. Congrats on the new path!",
  "id" : 341554197105369088,
  "in_reply_to_status_id" : 341552976193810433,
  "created_at" : "2013-06-03 13:57:21 +0000",
  "in_reply_to_screen_name" : "SteveBuffalo",
  "in_reply_to_user_id_str" : "235665553",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341552124343250944",
  "geo" : { },
  "id_str" : "341553634628227072",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle yes, dragging today but need to get the announce out",
  "id" : 341553634628227072,
  "in_reply_to_status_id" : 341552124343250944,
  "created_at" : "2013-06-03 13:55:06 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 69, 80 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341549372544282625",
  "text" : "Sticking it out for the long haul is a huge achievement. Congrats to @thoughtbot for 10 years, and here\u2019s to 10 more! \uD83C\uDF7B",
  "id" : 341549372544282625,
  "created_at" : "2013-06-03 13:38:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 3, 10 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 26, 37 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341548865209634816",
  "text" : "RT @cpytel: This week was @thoughtbot\u2019s official 10 year anniversary. That\u2019s a long time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thoughtbot",
        "screen_name" : "thoughtbot",
        "indices" : [ 14, 25 ],
        "id_str" : "14114392",
        "id" : 14114392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341374514355130368",
    "text" : "This week was @thoughtbot\u2019s official 10 year anniversary. That\u2019s a long time.",
    "id" : 341374514355130368,
    "created_at" : "2013-06-03 02:03:21 +0000",
    "user" : {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "protected" : false,
      "id_str" : "9488922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1617210225\/headshot_normal.png",
      "id" : 9488922,
      "verified" : false
    }
  },
  "id" : 341548865209634816,
  "created_at" : "2013-06-03 13:36:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341541206116937729",
  "geo" : { },
  "id_str" : "341543585021313024",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh bwahah! Such typical husky behavior. Comes to no one, wants to run and be chased.",
  "id" : 341543585021313024,
  "in_reply_to_status_id" : 341541206116937729,
  "created_at" : "2013-06-03 13:15:10 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "indices" : [ 3, 14 ],
      "id_str" : "103914540",
      "id" : 103914540
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341543391298981888",
  "text" : "RT @samkottler: The #rubygems DNS provider is currently receiving a massive, sustained DDoS attack so service will be slow or unavailable. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubygems",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341540011520438272",
    "text" : "The #rubygems DNS provider is currently receiving a massive, sustained DDoS attack so service will be slow or unavailable. Sorry!",
    "id" : 341540011520438272,
    "created_at" : "2013-06-03 13:00:58 +0000",
    "user" : {
      "name" : "Sam Kottler",
      "screen_name" : "samkottler",
      "protected" : false,
      "id_str" : "103914540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572808884675301376\/whqN3Ix2_normal.jpeg",
      "id" : 103914540,
      "verified" : false
    }
  },
  "id" : 341543391298981888,
  "created_at" : "2013-06-03 13:14:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 14, 22 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341539743525396480",
  "geo" : { },
  "id_str" : "341540197680439296",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik @evanphx yep certainly down and that\u2019s our DNS provider.",
  "id" : 341540197680439296,
  "in_reply_to_status_id" : 341539743525396480,
  "created_at" : "2013-06-03 13:01:43 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341410370067521536",
  "text" : "Agricola Gamers\u2019 Deck is pretty wild. Lost to a mountain of Meat Pies.",
  "id" : 341410370067521536,
  "created_at" : "2013-06-03 04:25:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 13, 19 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341351371578167296",
  "geo" : { },
  "id_str" : "341363454013218816",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude @mwn3d awesome! Muir Woods is amazing too but a drive.",
  "id" : 341363454013218816,
  "in_reply_to_status_id" : 341351371578167296,
  "created_at" : "2013-06-03 01:19:24 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Berkopec",
      "screen_name" : "nateberkopec",
      "indices" : [ 0, 13 ],
      "id_str" : "18259813",
      "id" : 18259813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341335728711688192",
  "geo" : { },
  "id_str" : "341340026191376384",
  "in_reply_to_user_id" : 18259813,
  "text" : "@nateberkopec oh totally. I love that game but placing brown settlers to work on fields is a little much",
  "id" : 341340026191376384,
  "in_reply_to_status_id" : 341335728711688192,
  "created_at" : "2013-06-02 23:46:18 +0000",
  "in_reply_to_screen_name" : "nateberkopec",
  "in_reply_to_user_id_str" : "18259813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    }, {
      "name" : "Mike Neurohr",
      "screen_name" : "mwn3d",
      "indices" : [ 29, 35 ],
      "id_str" : "325866689",
      "id" : 325866689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341332629867622400",
  "geo" : { },
  "id_str" : "341339835056926721",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude whoa going with @mwn3d ?! Make sure to go to Blue Bottle Coffee or Ritual Roasters!",
  "id" : 341339835056926721,
  "in_reply_to_status_id" : 341332629867622400,
  "created_at" : "2013-06-02 23:45:33 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/341326206907584514\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/qPzQHvgq6Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLyiYHPCEAA3U49.jpg",
      "id_str" : "341326206915973120",
      "id" : 341326206915973120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLyiYHPCEAA3U49.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/qPzQHvgq6Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341326206907584514",
  "text" : "This Agricola expansion card feels a little racist. http:\/\/t.co\/qPzQHvgq6Y",
  "id" : 341326206907584514,
  "created_at" : "2013-06-02 22:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/i6ywIvNwbe",
      "expanded_url" : "http:\/\/twitpic.com\/cuz16g",
      "display_url" : "twitpic.com\/cuz16g"
    } ]
  },
  "geo" : { },
  "id_str" : "341258705968431106",
  "text" : "RT @rubiety: The new Google Maps is so great, it can even find you some homeless people! http:\/\/t.co\/i6ywIvNwbe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/i6ywIvNwbe",
        "expanded_url" : "http:\/\/twitpic.com\/cuz16g",
        "display_url" : "twitpic.com\/cuz16g"
      } ]
    },
    "geo" : { },
    "id_str" : "341258154656550912",
    "text" : "The new Google Maps is so great, it can even find you some homeless people! http:\/\/t.co\/i6ywIvNwbe",
    "id" : 341258154656550912,
    "created_at" : "2013-06-02 18:20:59 +0000",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 341258705968431106,
  "created_at" : "2013-06-02 18:23:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/dumb-ways-to-die\/id639930688?mt=8&uo=4\" rel=\"nofollow\"\u003EDumb Ways to Die on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/341182498568540162\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/3WC0cq9Muk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLwfrL8CEAEkTRs.jpg",
      "id_str" : "341182498572734465",
      "id" : 341182498572734465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLwfrL8CEAEkTRs.jpg",
      "sizes" : [ {
        "h" : 293,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 870
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 870
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3WC0cq9Muk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/4w9ez9ImXL",
      "expanded_url" : "http:\/\/appstore.com\/dumbwaystodie",
      "display_url" : "appstore.com\/dumbwaystodie"
    } ]
  },
  "geo" : { },
  "id_str" : "341182498568540162",
  "text" : "Oh no, I got squashed by a train again: http:\/\/t.co\/4w9ez9ImXL http:\/\/t.co\/3WC0cq9Muk",
  "id" : 341182498568540162,
  "created_at" : "2013-06-02 13:20:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "willrax",
      "screen_name" : "willrax",
      "indices" : [ 3, 11 ],
      "id_str" : "24123755",
      "id" : 24123755
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 85, 96 ],
      "id_str" : "381521407",
      "id" : 381521407
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 104, 110 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341041431240130560",
  "text" : "RT @willrax: So happy to find out motion-layout works great with OSX apps built with @RubyMotion thanks @qrush!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 72, 83 ],
        "id_str" : "381521407",
        "id" : 381521407
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 91, 97 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341027412961800192",
    "text" : "So happy to find out motion-layout works great with OSX apps built with @RubyMotion thanks @qrush!",
    "id" : 341027412961800192,
    "created_at" : "2013-06-02 03:04:05 +0000",
    "user" : {
      "name" : "willrax",
      "screen_name" : "willrax",
      "protected" : false,
      "id_str" : "24123755",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503133363029286912\/OcAhsK3o_normal.jpeg",
      "id" : 24123755,
      "verified" : false
    }
  },
  "id" : 341041431240130560,
  "created_at" : "2013-06-02 03:59:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Marxist Tarot Card",
      "screen_name" : "steveklabnik",
      "indices" : [ 15, 28 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341039738133807104",
  "geo" : { },
  "id_str" : "341040244415668224",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @steveklabnik this is a big reason I bought Revolights. I want to be perceived as a car.",
  "id" : 341040244415668224,
  "in_reply_to_status_id" : 341039738133807104,
  "created_at" : "2013-06-02 03:55:05 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 0, 12 ],
      "id_str" : "15954816",
      "id" : 15954816
    }, {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 13, 27 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340953858719244288",
  "geo" : { },
  "id_str" : "340954477840453632",
  "in_reply_to_user_id" : 15954816,
  "text" : "@wesgarrison @Carols10cents YES",
  "id" : 340954477840453632,
  "in_reply_to_status_id" : 340953858719244288,
  "created_at" : "2013-06-01 22:14:16 +0000",
  "in_reply_to_screen_name" : "wesgarrison",
  "in_reply_to_user_id_str" : "15954816",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "mike susz",
      "screen_name" : "mikesusz",
      "indices" : [ 8, 17 ],
      "id_str" : "14531472",
      "id" : 14531472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340953152822075393",
  "geo" : { },
  "id_str" : "340953944849272832",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh @mikesusz How to Wrestle Bulldogs and Break Builds",
  "id" : 340953944849272832,
  "in_reply_to_status_id" : 340953152822075393,
  "created_at" : "2013-06-01 22:12:09 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340891749100687360",
  "geo" : { },
  "id_str" : "340935878551683073",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco i\u2019ve been on Keto for the last few months and it\u2019s been amazing. Down almost 20 lbs. http:\/\/reddit\/r\/keto (read sidebar faqs)",
  "id" : 340935878551683073,
  "in_reply_to_status_id" : 340891749100687360,
  "created_at" : "2013-06-01 21:00:22 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 3, 18 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    }, {
      "name" : "Synacor",
      "screen_name" : "Synacor",
      "indices" : [ 37, 45 ],
      "id_str" : "19976046",
      "id" : 19976046
    }, {
      "name" : "Chargify",
      "screen_name" : "Chargify",
      "indices" : [ 48, 57 ],
      "id_str" : "51077652",
      "id" : 51077652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/NpvNA8BhUR",
      "expanded_url" : "http:\/\/nickelcityruby.com\/#sponsors",
      "display_url" : "nickelcityruby.com\/#sponsors"
    } ]
  },
  "geo" : { },
  "id_str" : "340823687265656834",
  "text" : "RT @nickelcityruby: Thanks so far to @synacor + @chargify for sponsoring! http:\/\/t.co\/NpvNA8BhUR contact us re: sponsorship! CFP still open\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Synacor",
        "screen_name" : "Synacor",
        "indices" : [ 17, 25 ],
        "id_str" : "19976046",
        "id" : 19976046
      }, {
        "name" : "Chargify",
        "screen_name" : "Chargify",
        "indices" : [ 28, 37 ],
        "id_str" : "51077652",
        "id" : 51077652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/NpvNA8BhUR",
        "expanded_url" : "http:\/\/nickelcityruby.com\/#sponsors",
        "display_url" : "nickelcityruby.com\/#sponsors"
      } ]
    },
    "geo" : { },
    "id_str" : "339744507341975553",
    "text" : "Thanks so far to @synacor + @chargify for sponsoring! http:\/\/t.co\/NpvNA8BhUR contact us re: sponsorship! CFP still open and tickets on sale!",
    "id" : 339744507341975553,
    "created_at" : "2013-05-29 14:06:17 +0000",
    "user" : {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "protected" : false,
      "id_str" : "1067596351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411760556\/d1452897bc9bf0f519642dcc8074dccf_normal.png",
      "id" : 1067596351,
      "verified" : false
    }
  },
  "id" : 340823687265656834,
  "created_at" : "2013-06-01 13:34:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 15, 30 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xIW1YsdgOF",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
      "display_url" : "nickelcityruby.com\/cfp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "340823640541118464",
  "text" : "RT @jhsu: lulz @nickelcityruby team going to have a HARD time picking talks, many good submissions, it's still open! http:\/\/t.co\/xIW1YsdgOF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NickelCityRuby",
        "screen_name" : "nickelcityruby",
        "indices" : [ 5, 20 ],
        "id_str" : "1067596351",
        "id" : 1067596351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/xIW1YsdgOF",
        "expanded_url" : "http:\/\/nickelcityruby.com\/cfp\/",
        "display_url" : "nickelcityruby.com\/cfp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "340481129427652608",
    "text" : "lulz @nickelcityruby team going to have a HARD time picking talks, many good submissions, it's still open! http:\/\/t.co\/xIW1YsdgOF",
    "id" : 340481129427652608,
    "created_at" : "2013-05-31 14:53:21 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 340823640541118464,
  "created_at" : "2013-06-01 13:34:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 35, 50 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/d8amGfIxtu",
      "expanded_url" : "http:\/\/nickelcityruby.com\/cfp",
      "display_url" : "nickelcityruby.com\/cfp"
    } ]
  },
  "geo" : { },
  "id_str" : "340823365340246016",
  "text" : "I want to see you speak in Buffalo @nickelcityruby! It\u2019s our first Ruby conf and you should talk here. http:\/\/t.co\/d8amGfIxtu",
  "id" : 340823365340246016,
  "created_at" : "2013-06-01 13:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 10, 20 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340675543747919873",
  "geo" : { },
  "id_str" : "340700852966801408",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant @aquaranto we should start betting.",
  "id" : 340700852966801408,
  "in_reply_to_status_id" : 340675543747919873,
  "created_at" : "2013-06-01 05:26:27 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
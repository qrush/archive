Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/itor4fSa",
      "expanded_url" : "http:\/\/path.com\/p\/2sFvia",
      "display_url" : "path.com\/p\/2sFvia"
    } ]
  },
  "geo" : { },
  "id_str" : "153338500069081088",
  "text" : "Rolling hard into 2012. Thanks for an awesome year, folks. (with Amanda) [pic] \u2014 http:\/\/t.co\/itor4fSa",
  "id" : 153338500069081088,
  "created_at" : "2012-01-01 04:55:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 0, 10 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153282247502475264",
  "geo" : { },
  "id_str" : "153295111684493312",
  "in_reply_to_user_id" : 5965482,
  "text" : "@jankowski I would invest in your trail mix company. JANKOWSKIX",
  "id" : 153295111684493312,
  "in_reply_to_status_id" : 153282247502475264,
  "created_at" : "2012-01-01 02:02:57 +0000",
  "in_reply_to_screen_name" : "jankowski",
  "in_reply_to_user_id_str" : "5965482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/PCuyUW9D",
      "expanded_url" : "http:\/\/path.com\/p\/3UdgLA",
      "display_url" : "path.com\/p\/3UdgLA"
    } ]
  },
  "geo" : { },
  "id_str" : "153258971489247232",
  "text" : "Last Dogfish of 2011! (with Amanda at Allen Street Hardware Cafe) [pic] \u2014 http:\/\/t.co\/PCuyUW9D",
  "id" : 153258971489247232,
  "created_at" : "2011-12-31 23:39:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bob",
      "screen_name" : "rjw1",
      "indices" : [ 0, 5 ],
      "id_str" : "328203",
      "id" : 328203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153167009205600256",
  "geo" : { },
  "id_str" : "153209502362120192",
  "in_reply_to_user_id" : 328203,
  "text" : "@rjw1 anything I can do to help? Have a specific problem?",
  "id" : 153209502362120192,
  "in_reply_to_status_id" : 153167009205600256,
  "created_at" : "2011-12-31 20:22:46 +0000",
  "in_reply_to_screen_name" : "rjw1",
  "in_reply_to_user_id_str" : "328203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153148936440389633",
  "geo" : { },
  "id_str" : "153156666177757186",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu born and raised here, I think that's more than technically ;)",
  "id" : 153156666177757186,
  "in_reply_to_status_id" : 153148936440389633,
  "created_at" : "2011-12-31 16:52:49 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153123255002206209",
  "geo" : { },
  "id_str" : "153128053508284416",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl how is that not true for any team\/company?",
  "id" : 153128053508284416,
  "in_reply_to_status_id" : 153123255002206209,
  "created_at" : "2011-12-31 14:59:07 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/aLZEhxVC",
      "expanded_url" : "http:\/\/bit.ly\/srkCPh",
      "display_url" : "bit.ly\/srkCPh"
    } ]
  },
  "geo" : { },
  "id_str" : "153113833907564546",
  "text" : "Buffalo represent! http:\/\/t.co\/aLZEhxVC",
  "id" : 153113833907564546,
  "created_at" : "2011-12-31 14:02:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153113270063071234",
  "geo" : { },
  "id_str" : "153113537739370496",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo walk softly and carry a big leaf blower",
  "id" : 153113537739370496,
  "in_reply_to_status_id" : 153113270063071234,
  "created_at" : "2011-12-31 14:01:26 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153112686689914881",
  "geo" : { },
  "id_str" : "153113423247450112",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl awesome. I want to hack on more hardware stuff too, need to get an arduino (is that even the best option still?)",
  "id" : 153113423247450112,
  "in_reply_to_status_id" : 153112686689914881,
  "created_at" : "2011-12-31 14:00:59 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153106363843747840",
  "geo" : { },
  "id_str" : "153112003848835073",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl well, duh, but we were never the cool kids anyway",
  "id" : 153112003848835073,
  "in_reply_to_status_id" : 153106363843747840,
  "created_at" : "2011-12-31 13:55:21 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153004542135508992",
  "geo" : { },
  "id_str" : "153111460040556544",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt are you in town?",
  "id" : 153111460040556544,
  "in_reply_to_status_id" : 153004542135508992,
  "created_at" : "2011-12-31 13:53:11 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152930622258688001",
  "geo" : { },
  "id_str" : "152931499723849728",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou awesome ASCII art.",
  "id" : 152931499723849728,
  "in_reply_to_status_id" : 152930622258688001,
  "created_at" : "2011-12-31 01:58:05 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Cuadra",
      "screen_name" : "jimmycuadra",
      "indices" : [ 0, 12 ],
      "id_str" : "23913921",
      "id" : 23913921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152929544616153089",
  "geo" : { },
  "id_str" : "152930139565596672",
  "in_reply_to_user_id" : 23913921,
  "text" : "@jimmycuadra i really hope this is serious",
  "id" : 152930139565596672,
  "in_reply_to_status_id" : 152929544616153089,
  "created_at" : "2011-12-31 01:52:41 +0000",
  "in_reply_to_screen_name" : "jimmycuadra",
  "in_reply_to_user_id_str" : "23913921",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152928855487823872",
  "geo" : { },
  "id_str" : "152930039997018112",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety this is going in the talk now",
  "id" : 152930039997018112,
  "in_reply_to_status_id" : 152928855487823872,
  "created_at" : "2011-12-31 01:52:17 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152928623626690560",
  "text" : "Definitely want some more responses, cmon folks! Why did you make a RubyGem or contribute to one? Fixing a bug? Scratching an itch?",
  "id" : 152928623626690560,
  "created_at" : "2011-12-31 01:46:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 15, 25 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152921246131171331",
  "geo" : { },
  "id_str" : "152921897099735041",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @kevinburg speaking of this, I'd love to hear your photo backup war stories. I now have ~850 I don't want to lose, ever.",
  "id" : 152921897099735041,
  "in_reply_to_status_id" : 152921246131171331,
  "created_at" : "2011-12-31 01:19:56 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152921718330114050",
  "text" : "For me it was pretty simple: Adding a few features to Jekyll I needed for my blog, like the published flag.",
  "id" : 152921718330114050,
  "created_at" : "2011-12-31 01:19:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 39, 48 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152921243442626560",
  "text" : "Getting ready for my #codemash talk on @rubygems, one question for you: what problem did you solve by writing a RubyGem?",
  "id" : 152921243442626560,
  "created_at" : "2011-12-31 01:17:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Gavazzi",
      "screen_name" : "trentg",
      "indices" : [ 0, 7 ],
      "id_str" : "16493682",
      "id" : 16493682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152882939284295680",
  "geo" : { },
  "id_str" : "152917627289862144",
  "in_reply_to_user_id" : 16493682,
  "text" : "@trentg thanks! :)",
  "id" : 152917627289862144,
  "in_reply_to_status_id" : 152882939284295680,
  "created_at" : "2011-12-31 01:02:58 +0000",
  "in_reply_to_screen_name" : "trentg",
  "in_reply_to_user_id_str" : "16493682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 64, 73 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 74, 88 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/HggJz2Jo",
      "expanded_url" : "http:\/\/armcannon.bandcamp.com\/track\/smegmaman-three-he-enter-magma",
      "display_url" : "armcannon.bandcamp.com\/track\/smegmama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152857361676111873",
  "text" : "I think my favorite by far is http:\/\/t.co\/HggJz2Jo . METAL. \/cc @bquarant @joshuaclayton",
  "id" : 152857361676111873,
  "created_at" : "2011-12-30 21:03:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/4ZTAhTKR",
      "expanded_url" : "http:\/\/armcannon.bandcamp.com\/album\/return-of-the-attack-of-the-legend-of-pizzor",
      "display_url" : "armcannon.bandcamp.com\/album\/return-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152856977872130050",
  "text" : "These guys are playing tonight in Buffalo. They're from Buffalo. Buffalo. http:\/\/t.co\/4ZTAhTKR",
  "id" : 152856977872130050,
  "created_at" : "2011-12-30 21:01:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152845593084047360",
  "geo" : { },
  "id_str" : "152848179094757376",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson a list of assertions in the README would be really helpful",
  "id" : 152848179094757376,
  "in_reply_to_status_id" : 152845593084047360,
  "created_at" : "2011-12-30 20:27:00 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 85 ],
      "url" : "https:\/\/t.co\/qYhilTeT",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/bats",
      "display_url" : "github.com\/sstephenson\/ba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152847941332242432",
  "text" : "RT @sstephenson: Bats 0.1.0, the Bash Automated Testing System: https:\/\/t.co\/qYhilTeT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 68 ],
        "url" : "https:\/\/t.co\/qYhilTeT",
        "expanded_url" : "https:\/\/github.com\/sstephenson\/bats",
        "display_url" : "github.com\/sstephenson\/ba\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "152845593084047360",
    "text" : "Bats 0.1.0, the Bash Automated Testing System: https:\/\/t.co\/qYhilTeT",
    "id" : 152845593084047360,
    "created_at" : "2011-12-30 20:16:43 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 152847941332242432,
  "created_at" : "2011-12-30 20:26:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Chang",
      "screen_name" : "maeldur",
      "indices" : [ 0, 8 ],
      "id_str" : "242656319",
      "id" : 242656319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152120211561136128",
  "geo" : { },
  "id_str" : "152622729223356417",
  "in_reply_to_user_id" : 242656319,
  "text" : "@maeldur fixed, sorry. Bad deploy.",
  "id" : 152622729223356417,
  "in_reply_to_status_id" : 152120211561136128,
  "created_at" : "2011-12-30 05:31:08 +0000",
  "in_reply_to_screen_name" : "maeldur",
  "in_reply_to_user_id_str" : "242656319",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goggins",
      "screen_name" : "jgoggins",
      "indices" : [ 0, 9 ],
      "id_str" : "29755018",
      "id" : 29755018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152458585463463936",
  "geo" : { },
  "id_str" : "152622644364197888",
  "in_reply_to_user_id" : 29755018,
  "text" : "@jgoggins fixed, sorry :(",
  "id" : 152622644364197888,
  "in_reply_to_status_id" : 152458585463463936,
  "created_at" : "2011-12-30 05:30:48 +0000",
  "in_reply_to_screen_name" : "jgoggins",
  "in_reply_to_user_id_str" : "29755018",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152621449151119360",
  "text" : "Seriously, why isn't the emoji keyboard on by default for iOS? \uD83C\uDD92\uD83D\uDCD6\uD83C\uDD71\u00AE\uD83C\uDD7E",
  "id" : 152621449151119360,
  "created_at" : "2011-12-30 05:26:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/5gnCsTLE",
      "expanded_url" : "http:\/\/apprentice.io\/",
      "display_url" : "apprentice.io"
    } ]
  },
  "geo" : { },
  "id_str" : "152480843531685888",
  "text" : "Loving the software apprenticeship push, we need more developers! (developers, developers!) http:\/\/t.co\/5gnCsTLE",
  "id" : 152480843531685888,
  "created_at" : "2011-12-29 20:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/VXGn3taH",
      "expanded_url" : "http:\/\/bostinno.com\/channels\/the-rise-of-the-software-apprenticeship-academy\/",
      "display_url" : "bostinno.com\/channels\/the-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152480166164172801",
  "text" : "RT @thoughtbot: The Rise of the Software Apprenticeship Academy http:\/\/t.co\/VXGn3taH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/VXGn3taH",
        "expanded_url" : "http:\/\/bostinno.com\/channels\/the-rise-of-the-software-apprenticeship-academy\/",
        "display_url" : "bostinno.com\/channels\/the-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "152430968601452544",
    "text" : "The Rise of the Software Apprenticeship Academy http:\/\/t.co\/VXGn3taH",
    "id" : 152430968601452544,
    "created_at" : "2011-12-29 16:49:09 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 152480166164172801,
  "created_at" : "2011-12-29 20:04:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Busch",
      "screen_name" : "mikelikesbikes",
      "indices" : [ 0, 15 ],
      "id_str" : "10444422",
      "id" : 10444422
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 30, 40 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152320313265373184",
  "geo" : { },
  "id_str" : "152411394699042816",
  "in_reply_to_user_id" : 10444422,
  "text" : "@mikelikesbikes found one for @aquaranto already, thanks though!",
  "id" : 152411394699042816,
  "in_reply_to_status_id" : 152320313265373184,
  "created_at" : "2011-12-29 15:31:22 +0000",
  "in_reply_to_screen_name" : "mikelikesbikes",
  "in_reply_to_user_id_str" : "10444422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152233602237730817",
  "geo" : { },
  "id_str" : "152236777200037888",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi i know you're trolling, but why is this a bad thing? choices are good, I'm glad we have them. I'm just happy people are sharing code.",
  "id" : 152236777200037888,
  "in_reply_to_status_id" : 152233602237730817,
  "created_at" : "2011-12-29 03:57:30 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 8, 19 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152191787702816769",
  "geo" : { },
  "id_str" : "152192494044594176",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky @phillapier hop on gchat!!!",
  "id" : 152192494044594176,
  "in_reply_to_status_id" : 152191787702816769,
  "created_at" : "2011-12-29 01:01:32 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 76, 82 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 83, 94 ],
      "id_str" : "14555937",
      "id" : 14555937
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 95, 102 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/IsgrJ8xA",
      "expanded_url" : "http:\/\/www.livephish.com\/",
      "display_url" : "livephish.com"
    } ]
  },
  "geo" : { },
  "id_str" : "152183274117152769",
  "text" : "Watching tonight's Phish show live on http:\/\/t.co\/IsgrJ8xA. Anyone else in? @cmeik @phillapier @Croaky",
  "id" : 152183274117152769,
  "created_at" : "2011-12-29 00:24:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason King",
      "screen_name" : "smathy",
      "indices" : [ 0, 7 ],
      "id_str" : "9786912",
      "id" : 9786912
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 8, 15 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152100733469204480",
  "geo" : { },
  "id_str" : "152101694191316994",
  "in_reply_to_user_id" : 9786912,
  "text" : "@smathy @sferik it doesn't support running test by line number. that's the whole mission of it. i dont want to run tests by name, ever.",
  "id" : 152101694191316994,
  "in_reply_to_status_id" : 152100733469204480,
  "created_at" : "2011-12-28 19:00:44 +0000",
  "in_reply_to_screen_name" : "smathy",
  "in_reply_to_user_id_str" : "9786912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason King",
      "screen_name" : "smathy",
      "indices" : [ 0, 7 ],
      "id_str" : "9786912",
      "id" : 9786912
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 8, 15 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152065952954073089",
  "geo" : { },
  "id_str" : "152069361899806721",
  "in_reply_to_user_id" : 9786912,
  "text" : "@smathy @sferik no, i dont want to edit test files in order to run tests, that completely misses the point. no better than -n 'test name'",
  "id" : 152069361899806721,
  "in_reply_to_status_id" : 152065952954073089,
  "created_at" : "2011-12-28 16:52:15 +0000",
  "in_reply_to_screen_name" : "smathy",
  "in_reply_to_user_id_str" : "9786912",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152054948715180033",
  "geo" : { },
  "id_str" : "152057292202848259",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic it's a basic auth endpoint, login with your creds and get your API key",
  "id" : 152057292202848259,
  "in_reply_to_status_id" : 152054948715180033,
  "created_at" : "2011-12-28 16:04:18 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 40, 50 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152049092963475456",
  "text" : "Really excited to attend #codemash with @aquaranto, her first conf! Should we bring some card\/board games?",
  "id" : 152049092963475456,
  "created_at" : "2011-12-28 15:31:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152039855126355970",
  "geo" : { },
  "id_str" : "152040616723881988",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant dude. going to install today.",
  "id" : 152040616723881988,
  "in_reply_to_status_id" : 152039855126355970,
  "created_at" : "2011-12-28 14:58:02 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vlad Gorodetsky",
      "screen_name" : "_beai",
      "indices" : [ 0, 6 ],
      "id_str" : "7852",
      "id" : 7852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152033853735845888",
  "geo" : { },
  "id_str" : "152034373586255872",
  "in_reply_to_user_id" : 7852,
  "text" : "@_beai Just emailed you about them.",
  "id" : 152034373586255872,
  "in_reply_to_status_id" : 152033853735845888,
  "created_at" : "2011-12-28 14:33:13 +0000",
  "in_reply_to_screen_name" : "_beai",
  "in_reply_to_user_id_str" : "7852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vlad Gorodetsky",
      "screen_name" : "_beai",
      "indices" : [ 0, 6 ],
      "id_str" : "7852",
      "id" : 7852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152033360187887616",
  "in_reply_to_user_id" : 7852,
  "text" : "@_beai i'm going to forcibly yank all of the one letter gem names you're taking, because that's really not cool",
  "id" : 152033360187887616,
  "created_at" : "2011-12-28 14:29:12 +0000",
  "in_reply_to_screen_name" : "_beai",
  "in_reply_to_user_id_str" : "7852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/6Fmjaz2i",
      "expanded_url" : "https:\/\/github.com\/qrush\/m",
      "display_url" : "github.com\/qrush\/m"
    } ]
  },
  "geo" : { },
  "id_str" : "152030592257638400",
  "text" : "Wrote a gem to run Test::Unit tests by line number, looking for feedback! https:\/\/t.co\/6Fmjaz2i",
  "id" : 152030592257638400,
  "created_at" : "2011-12-28 14:18:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "152021076371705857",
  "geo" : { },
  "id_str" : "152022218384211968",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 whaaat? I can't find or search for that on http:\/\/t.co\/bdjxoR36.",
  "id" : 152022218384211968,
  "in_reply_to_status_id" : 152021076371705857,
  "created_at" : "2011-12-28 13:44:55 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 3, 10 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/pYm1QGkF",
      "expanded_url" : "http:\/\/afreshcup.com\/home\/2011\/12\/28\/one-and-two-letter-gems.html",
      "display_url" : "afreshcup.com\/home\/2011\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152020993123155969",
  "text" : "RT @MikeG1: Morning silliness: One- and Two-Letter Gems http:\/\/t.co\/pYm1QGkF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/pYm1QGkF",
        "expanded_url" : "http:\/\/afreshcup.com\/home\/2011\/12\/28\/one-and-two-letter-gems.html",
        "display_url" : "afreshcup.com\/home\/2011\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "151997992180776961",
    "text" : "Morning silliness: One- and Two-Letter Gems http:\/\/t.co\/pYm1QGkF",
    "id" : 151997992180776961,
    "created_at" : "2011-12-28 12:08:39 +0000",
    "user" : {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "protected" : true,
      "id_str" : "728173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57930155\/Photo1Small_normal.png",
      "id" : 728173,
      "verified" : false
    }
  },
  "id" : 152020993123155969,
  "created_at" : "2011-12-28 13:40:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apigee",
      "screen_name" : "Apigee",
      "indices" : [ 6, 13 ],
      "id_str" : "26094126",
      "id" : 26094126
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 21, 30 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 65 ],
      "url" : "https:\/\/t.co\/RzrZSZhu",
      "expanded_url" : "https:\/\/apigee.com\/console\/rubygems",
      "display_url" : "apigee.com\/console\/rubyge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "152015812830564353",
  "text" : "Neat, @apigee made a @rubygems API console: https:\/\/t.co\/RzrZSZhu",
  "id" : 152015812830564353,
  "created_at" : "2011-12-28 13:19:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "152011130200539137",
  "geo" : { },
  "id_str" : "152012069351329792",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl link? Also, I don't want to edit my test file to run anything",
  "id" : 152012069351329792,
  "in_reply_to_status_id" : 152011130200539137,
  "created_at" : "2011-12-28 13:04:36 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151931374243282945",
  "geo" : { },
  "id_str" : "151932057772232704",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal neat, the other gems were not working for 1.8, could give that a try",
  "id" : 151932057772232704,
  "in_reply_to_status_id" : 151931374243282945,
  "created_at" : "2011-12-28 07:46:39 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151927761030750209",
  "text" : "Freshly cut gem, sick dog, #1 on HN. OK late night.",
  "id" : 151927761030750209,
  "created_at" : "2011-12-28 07:29:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Milewski",
      "screen_name" : "tmilewski",
      "indices" : [ 0, 10 ],
      "id_str" : "9761452",
      "id" : 9761452
    }, {
      "name" : "Danny G",
      "screen_name" : "buzzedword",
      "indices" : [ 11, 22 ],
      "id_str" : "17825124",
      "id" : 17825124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151920935811825665",
  "geo" : { },
  "id_str" : "151926743995924480",
  "in_reply_to_user_id" : 9761452,
  "text" : "@tmilewski @buzzedword just edited the readme on mobile safari, that's all.",
  "id" : 151926743995924480,
  "in_reply_to_status_id" : 151920935811825665,
  "created_at" : "2011-12-28 07:25:33 +0000",
  "in_reply_to_screen_name" : "tmilewski",
  "in_reply_to_user_id_str" : "9761452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151702320596533248",
  "geo" : { },
  "id_str" : "151918618786004992",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic yes the latest release's upload failed, they need to cut a new gem.",
  "id" : 151918618786004992,
  "in_reply_to_status_id" : 151702320596533248,
  "created_at" : "2011-12-28 06:53:15 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 19, 26 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151917952432742400",
  "text" : "Just made my first @github commit via iPhone. \uD83D\uDC4D",
  "id" : 151917952432742400,
  "created_at" : "2011-12-28 06:50:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151915297396371456",
  "geo" : { },
  "id_str" : "151916863507542018",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes I did try the rspec runner first, but T::U compat was removed in 2.x",
  "id" : 151916863507542018,
  "in_reply_to_status_id" : 151915297396371456,
  "created_at" : "2011-12-28 06:46:17 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Hanke",
      "screen_name" : "hanke",
      "indices" : [ 0, 6 ],
      "id_str" : "1018421",
      "id" : 1018421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ub1lZ7OZ",
      "expanded_url" : "http:\/\/bugs.ruby-lang.org\/issues\/5653",
      "display_url" : "bugs.ruby-lang.org\/issues\/5653"
    } ]
  },
  "in_reply_to_status_id_str" : "151908353461862400",
  "geo" : { },
  "id_str" : "151908641639903232",
  "in_reply_to_user_id" : 1018421,
  "text" : "@hanke autoload is going away in ruby eventually, enough said. http:\/\/t.co\/ub1lZ7OZ",
  "id" : 151908641639903232,
  "in_reply_to_status_id" : 151908353461862400,
  "created_at" : "2011-12-28 06:13:37 +0000",
  "in_reply_to_screen_name" : "hanke",
  "in_reply_to_user_id_str" : "1018421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 72 ],
      "url" : "https:\/\/t.co\/6Fmjaz2i",
      "expanded_url" : "https:\/\/github.com\/qrush\/m",
      "display_url" : "github.com\/qrush\/m"
    } ]
  },
  "geo" : { },
  "id_str" : "151903129787576320",
  "text" : "Finally took a one letter gem name, introducing m! https:\/\/t.co\/6Fmjaz2i",
  "id" : 151903129787576320,
  "created_at" : "2011-12-28 05:51:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 21, 30 ],
      "id_str" : "252481460",
      "id" : 252481460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151902786043383808",
  "text" : "It's insane how easy @travisci makes it to get CI up and running.",
  "id" : 151902786043383808,
  "created_at" : "2011-12-28 05:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 3, 12 ],
      "id_str" : "9267332",
      "id" : 9267332
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 17, 23 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151889025156923392",
  "text" : "RT @rtomayko: So @raggi is doing a hell of a job maintaining four different versions of rack. Keep bangin' man. It's appreciated.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Tucker",
        "screen_name" : "raggi",
        "indices" : [ 3, 9 ],
        "id_str" : "15359408",
        "id" : 15359408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "151887433439522816",
    "text" : "So @raggi is doing a hell of a job maintaining four different versions of rack. Keep bangin' man. It's appreciated.",
    "id" : 151887433439522816,
    "created_at" : "2011-12-28 04:49:20 +0000",
    "user" : {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "protected" : false,
      "id_str" : "9267332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3109364645\/f89b77ce2f3afa72fdc3ca7e08f3c4f9_normal.png",
      "id" : 9267332,
      "verified" : false
    }
  },
  "id" : 151889025156923392,
  "created_at" : "2011-12-28 04:55:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 0, 7 ],
      "id_str" : "814306",
      "id" : 814306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151878912723517441",
  "geo" : { },
  "id_str" : "151879600107032576",
  "in_reply_to_user_id" : 814306,
  "text" : "@Shella i don't know what's worse, going out in public with one or the poopflap",
  "id" : 151879600107032576,
  "in_reply_to_status_id" : 151878912723517441,
  "created_at" : "2011-12-28 04:18:13 +0000",
  "in_reply_to_screen_name" : "Shella",
  "in_reply_to_user_id_str" : "814306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151860097532956672",
  "geo" : { },
  "id_str" : "151863556999098370",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox haha working from home has its advantages :)",
  "id" : 151863556999098370,
  "in_reply_to_status_id" : 151860097532956672,
  "created_at" : "2011-12-28 03:14:28 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/NJAFdJ6l",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/GEB\/comments\/nmy4p\/starting_a_readthrough_january_17\/",
      "display_url" : "reddit.com\/r\/GEB\/comments\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "151795621039316993",
  "text" : "Anyone else want to read G\u00F6del, Escher, Bach with me? \/r\/GEB is starting it on 1\/17. http:\/\/t.co\/NJAFdJ6l",
  "id" : 151795621039316993,
  "created_at" : "2011-12-27 22:44:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151770939166703616",
  "geo" : { },
  "id_str" : "151777525671010307",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Yup.",
  "id" : 151777525671010307,
  "in_reply_to_status_id" : 151770939166703616,
  "created_at" : "2011-12-27 21:32:36 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151767427603111936",
  "geo" : { },
  "id_str" : "151768772754157569",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant my brain is moving too fast. and lots of Phish.",
  "id" : 151768772754157569,
  "in_reply_to_status_id" : 151767427603111936,
  "created_at" : "2011-12-27 20:57:49 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151738216607793152",
  "geo" : { },
  "id_str" : "151739353234808832",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant you mean she poops at parties? without closings of doors?",
  "id" : 151739353234808832,
  "in_reply_to_status_id" : 151738216607793152,
  "created_at" : "2011-12-27 19:00:55 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 20, 33 ],
      "id_str" : "5911122",
      "id" : 5911122
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 94, 98 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/743fMdID",
      "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424052970204464404577114792428726720.html?mod=WSJ_hpp_editorsPicks_3",
      "display_url" : "online.wsj.com\/article\/SB1000\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "151722949160861696",
  "text" : "RT @kevinpurdy: How @ChrisSmithAV started the \"Cash Mob\" social spending trend in Buffalo (at @wsj): http:\/\/t.co\/743fMdID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C",
        "screen_name" : "ChrisSmithAV",
        "indices" : [ 4, 17 ],
        "id_str" : "5911122",
        "id" : 5911122
      }, {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 78, 82 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/743fMdID",
        "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424052970204464404577114792428726720.html?mod=WSJ_hpp_editorsPicks_3",
        "display_url" : "online.wsj.com\/article\/SB1000\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "151717296845500416",
    "text" : "How @ChrisSmithAV started the \"Cash Mob\" social spending trend in Buffalo (at @wsj): http:\/\/t.co\/743fMdID",
    "id" : 151717296845500416,
    "created_at" : "2011-12-27 17:33:16 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 151722949160861696,
  "created_at" : "2011-12-27 17:55:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Horn",
      "screen_name" : "stevehorn",
      "indices" : [ 0, 10 ],
      "id_str" : "14181366",
      "id" : 14181366
    }, {
      "name" : "Pete Gordon",
      "screen_name" : "petegordon",
      "indices" : [ 11, 22 ],
      "id_str" : "15524746",
      "id" : 15524746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151636458472615938",
  "geo" : { },
  "id_str" : "151659279470960640",
  "in_reply_to_user_id" : 14181366,
  "text" : "@stevehorn @petegordon I am looking to buy!",
  "id" : 151659279470960640,
  "in_reply_to_status_id" : 151636458472615938,
  "created_at" : "2011-12-27 13:42:44 +0000",
  "in_reply_to_screen_name" : "stevehorn",
  "in_reply_to_user_id_str" : "14181366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelli Shaver",
      "screen_name" : "kellishaver",
      "indices" : [ 0, 12 ],
      "id_str" : "11805922",
      "id" : 11805922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151550355640037376",
  "geo" : { },
  "id_str" : "151658885772623872",
  "in_reply_to_user_id" : 11805922,
  "text" : "@kellishaver gem install bundler --pre and it will be a lot faster :)",
  "id" : 151658885772623872,
  "in_reply_to_status_id" : 151550355640037376,
  "created_at" : "2011-12-27 13:41:10 +0000",
  "in_reply_to_screen_name" : "kellishaver",
  "in_reply_to_user_id_str" : "11805922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/4CVB2bcj",
      "expanded_url" : "http:\/\/instagr.am\/p\/cBfZi\/",
      "display_url" : "instagr.am\/p\/cBfZi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "151525096635383808",
  "text" : "Inns & Cathedrals! http:\/\/t.co\/4CVB2bcj",
  "id" : 151525096635383808,
  "created_at" : "2011-12-27 04:49:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151493126152929280",
  "geo" : { },
  "id_str" : "151522597367058432",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 nice! It's made a huge world of difference for our husky :)",
  "id" : 151522597367058432,
  "in_reply_to_status_id" : 151493126152929280,
  "created_at" : "2011-12-27 04:39:37 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151522411945263104",
  "text" : "OH: \"do you have one of those bikes without pedals?\" \"...a tire?\"",
  "id" : 151522411945263104,
  "created_at" : "2011-12-27 04:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Busch",
      "screen_name" : "mikelikesbikes",
      "indices" : [ 0, 15 ],
      "id_str" : "10444422",
      "id" : 10444422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151366696391811072",
  "geo" : { },
  "id_str" : "151375954047016960",
  "in_reply_to_user_id" : 10444422,
  "text" : "@mikelikesbikes awesome, thanks",
  "id" : 151375954047016960,
  "in_reply_to_status_id" : 151366696391811072,
  "created_at" : "2011-12-26 18:56:54 +0000",
  "in_reply_to_screen_name" : "mikelikesbikes",
  "in_reply_to_user_id_str" : "10444422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151141547755311105",
  "geo" : { },
  "id_str" : "151310993920765952",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt waaaay too intense",
  "id" : 151310993920765952,
  "in_reply_to_status_id" : 151141547755311105,
  "created_at" : "2011-12-26 14:38:46 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151305984382468096",
  "text" : "Still looking for a #codemash ticket! If you know of someone I will send them REAL Buffalo wings. Seriously, not kidding.",
  "id" : 151305984382468096,
  "created_at" : "2011-12-26 14:18:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/IRWmDQrv",
      "expanded_url" : "http:\/\/instagr.am\/p\/bzSn-\/",
      "display_url" : "instagr.am\/p\/bzSn-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "151209763164782592",
  "text" : "Smooshface. http:\/\/t.co\/IRWmDQrv",
  "id" : 151209763164782592,
  "created_at" : "2011-12-26 07:56:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/R874bUew",
      "expanded_url" : "http:\/\/path.com\/p\/2070Eu",
      "display_url" : "path.com\/p\/2070Eu"
    } ]
  },
  "geo" : { },
  "id_str" : "151134988857909248",
  "text" : "This game is insane. Haha, get it? (with Amanda) [pic] \u2014 http:\/\/t.co\/R874bUew",
  "id" : 151134988857909248,
  "created_at" : "2011-12-26 02:59:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 25, 35 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/150973143673081856\/photo\/1",
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/lg59kgt6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhhdRjeCEAA2EU6.jpg",
      "id_str" : "150973143677276160",
      "id" : 150973143677276160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhhdRjeCEAA2EU6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/lg59kgt6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150973143673081856",
  "text" : "Definitely Christmas for @gemcutter! http:\/\/t.co\/lg59kgt6",
  "id" : 150973143673081856,
  "created_at" : "2011-12-25 16:16:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150914034022092800",
  "geo" : { },
  "id_str" : "150919196350484482",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel dang dude, hope it turns out ok. I had it in high school, not fun. Flip side: play video games\/nethack for a week!",
  "id" : 150919196350484482,
  "in_reply_to_status_id" : 150914034022092800,
  "created_at" : "2011-12-25 12:41:55 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genki Takiuchi",
      "screen_name" : "takiuchi",
      "indices" : [ 0, 9 ],
      "id_str" : "1788391",
      "id" : 1788391
    }, {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 10, 20 ],
      "id_str" : "7220202",
      "id" : 7220202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150703756261064704",
  "geo" : { },
  "id_str" : "150820655766585344",
  "in_reply_to_user_id" : 1788391,
  "text" : "@takiuchi @a_matsuda would love to see patches to use a native version instead of flash. :) clippy is great though.",
  "id" : 150820655766585344,
  "in_reply_to_status_id" : 150703756261064704,
  "created_at" : "2011-12-25 06:10:21 +0000",
  "in_reply_to_screen_name" : "takiuchi",
  "in_reply_to_user_id_str" : "1788391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    }, {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 15, 21 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150792694476705792",
  "geo" : { },
  "id_str" : "150798477864075265",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt @wfarr do you need help? Is something not working?",
  "id" : 150798477864075265,
  "in_reply_to_status_id" : 150792694476705792,
  "created_at" : "2011-12-25 04:42:13 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150756968896798720",
  "geo" : { },
  "id_str" : "150760374914908161",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella grats dude!!!",
  "id" : 150760374914908161,
  "in_reply_to_status_id" : 150756968896798720,
  "created_at" : "2011-12-25 02:10:49 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    }, {
      "name" : "ian carlino",
      "screen_name" : "iancarlino",
      "indices" : [ 139, 140 ],
      "id_str" : "430918662",
      "id" : 430918662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MIkAJYWr",
      "expanded_url" : "http:\/\/www.nytimes.com\/2011\/12\/24\/theater\/sheas-performing-arts-center-in-buffalo.html?_r=2",
      "display_url" : "nytimes.com\/2011\/12\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150757543541604352",
  "text" : "RT @BuffaloRising: The NY Times on Buffalo and Shea's,  \"Buffalo has emerged as a major bellwether in commercial theater.\" http:\/\/t.co\/M ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ian carlino",
        "screen_name" : "iancarlino",
        "indices" : [ 128, 139 ],
        "id_str" : "430918662",
        "id" : 430918662
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/MIkAJYWr",
        "expanded_url" : "http:\/\/www.nytimes.com\/2011\/12\/24\/theater\/sheas-performing-arts-center-in-buffalo.html?_r=2",
        "display_url" : "nytimes.com\/2011\/12\/24\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "150755591395098624",
    "text" : "The NY Times on Buffalo and Shea's,  \"Buffalo has emerged as a major bellwether in commercial theater.\" http:\/\/t.co\/MIkAJYWr HT @iancarlino",
    "id" : 150755591395098624,
    "created_at" : "2011-12-25 01:51:48 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 150757543541604352,
  "created_at" : "2011-12-25 01:59:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 27, 35 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/JABIX6VE",
      "expanded_url" : "http:\/\/instagr.am\/p\/bT9Fb\/",
      "display_url" : "instagr.am\/p\/bT9Fb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "150724968211165184",
  "text" : "Finally killed the rest of @jayunit's champagne ! http:\/\/t.co\/JABIX6VE",
  "id" : 150724968211165184,
  "created_at" : "2011-12-24 23:50:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150608436831330304",
  "geo" : { },
  "id_str" : "150608693837299714",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky gooboy!",
  "id" : 150608693837299714,
  "in_reply_to_status_id" : 150608436831330304,
  "created_at" : "2011-12-24 16:08:05 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150607505188331521",
  "geo" : { },
  "id_str" : "150608546923421697",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems all code needs tests, it's inexcusable without",
  "id" : 150608546923421697,
  "in_reply_to_status_id" : 150607505188331521,
  "created_at" : "2011-12-24 16:07:30 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150464725866643457",
  "geo" : { },
  "id_str" : "150606304874987521",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi i want it to be more flexible than just where the method starts.",
  "id" : 150606304874987521,
  "in_reply_to_status_id" : 150464725866643457,
  "created_at" : "2011-12-24 15:58:35 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150605008411430912",
  "geo" : { },
  "id_str" : "150605529935384576",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems no tests? :(",
  "id" : 150605529935384576,
  "in_reply_to_status_id" : 150605008411430912,
  "created_at" : "2011-12-24 15:55:31 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150413193544601600",
  "text" : "Got a simple line test\/unit by line runner working with ruby_parser. Extremely excited for this.",
  "id" : 150413193544601600,
  "created_at" : "2011-12-24 03:11:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 37, 46 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/150375475871617025\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/E8O6GQfM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhY9staCEAAIVrp.jpg",
      "id_str" : "150375475875811328",
      "id" : 150375475875811328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhY9staCEAAIVrp.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/E8O6GQfM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150375475871617025",
  "text" : "First new laptop sticker courtesy of @bquarant ! Thanks bro! http:\/\/t.co\/E8O6GQfM",
  "id" : 150375475871617025,
  "created_at" : "2011-12-24 00:41:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nils Jonsson",
      "screen_name" : "njonsson",
      "indices" : [ 0, 9 ],
      "id_str" : "38503",
      "id" : 38503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149933316039127040",
  "geo" : { },
  "id_str" : "150361466124505088",
  "in_reply_to_user_id" : 38503,
  "text" : "@njonsson yea there's a pull request open for it that I need to review. Family &gt; code, I'll get to it soon",
  "id" : 150361466124505088,
  "in_reply_to_status_id" : 149933316039127040,
  "created_at" : "2011-12-23 23:45:41 +0000",
  "in_reply_to_screen_name" : "njonsson",
  "in_reply_to_user_id_str" : "38503",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    }, {
      "name" : "Andrew Clay Shafer",
      "screen_name" : "littleidea",
      "indices" : [ 11, 22 ],
      "id_str" : "14079705",
      "id" : 14079705
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 23, 35 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150335713915830272",
  "geo" : { },
  "id_str" : "150340629812101121",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox @littleidea @bcardarella nope",
  "id" : 150340629812101121,
  "in_reply_to_status_id" : 150335713915830272,
  "created_at" : "2011-12-23 22:22:53 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150328476828835840",
  "geo" : { },
  "id_str" : "150330284582244352",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton it's a christmas inebriation miracle!",
  "id" : 150330284582244352,
  "in_reply_to_status_id" : 150328476828835840,
  "created_at" : "2011-12-23 21:41:47 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Na0KiuN6",
      "expanded_url" : "http:\/\/www.reddit.com\/user\/WHOSE_A_GOOD_BOY",
      "display_url" : "reddit.com\/user\/WHOSE_A_G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150324753985572865",
  "text" : "Found my new favorite reddit account: http:\/\/t.co\/Na0KiuN6",
  "id" : 150324753985572865,
  "created_at" : "2011-12-23 21:19:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wmoxam",
      "screen_name" : "wmoxam",
      "indices" : [ 0, 7 ],
      "id_str" : "14049936",
      "id" : 14049936
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 42, 50 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150300656794730496",
  "geo" : { },
  "id_str" : "150316899874521088",
  "in_reply_to_user_id" : 14049936,
  "text" : "@wmoxam I haven't played in months, maybe @ddollar knows",
  "id" : 150316899874521088,
  "in_reply_to_status_id" : 150300656794730496,
  "created_at" : "2011-12-23 20:48:36 +0000",
  "in_reply_to_screen_name" : "wmoxam",
  "in_reply_to_user_id_str" : "14049936",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150289346552020993",
  "text" : "TIL I learned if you try to transfer 5 gigs of photos over AirDrop and use the Internet on 4 MacBooks your router will stop working.",
  "id" : 150289346552020993,
  "created_at" : "2011-12-23 18:59:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Howell",
      "screen_name" : "mxcl",
      "indices" : [ 0, 5 ],
      "id_str" : "3374231",
      "id" : 3374231
    }, {
      "name" : "Jenn Ayres",
      "screen_name" : "ayresphoto",
      "indices" : [ 124, 135 ],
      "id_str" : "83498704",
      "id" : 83498704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150284270638862338",
  "geo" : { },
  "id_str" : "150284494761508864",
  "in_reply_to_user_id" : 3374231,
  "text" : "@mxcl sounds like a bad photographer. got ours pretty much with rights released (except commerical use but that's fine) \/cc @ayresphoto",
  "id" : 150284494761508864,
  "in_reply_to_status_id" : 150284270638862338,
  "created_at" : "2011-12-23 18:39:50 +0000",
  "in_reply_to_screen_name" : "mxcl",
  "in_reply_to_user_id_str" : "3374231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/cJtcp7xZ",
      "expanded_url" : "https:\/\/github.com\/lamberta",
      "display_url" : "github.com\/lamberta"
    }, {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/7AXNJgLV",
      "expanded_url" : "http:\/\/lamberta.github.com\/html5-animation\/",
      "display_url" : "lamberta.github.com\/html5-animatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150277952603566080",
  "text" : "\"Foundation HTML5 Animation with Javascript\", new book out from Buffalo native https:\/\/t.co\/cJtcp7xZ !!! http:\/\/t.co\/7AXNJgLV",
  "id" : 150277952603566080,
  "created_at" : "2011-12-23 18:13:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/qJyzPlWZ",
      "expanded_url" : "http:\/\/quaran.to\/stupidrubytricks",
      "display_url" : "quaran.to\/stupidrubytric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150256466811551745",
  "text" : "My presentation from #WNYRuby this month: Stupid Ruby Tricks! http:\/\/t.co\/qJyzPlWZ (WARNING: TRICKS MAY BE HARMFUL AND\/OR STUPID)",
  "id" : 150256466811551745,
  "created_at" : "2011-12-23 16:48:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150217253722402816",
  "geo" : { },
  "id_str" : "150221805544669185",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez this made me laugh and I need that right now. Thanks dude.",
  "id" : 150221805544669185,
  "in_reply_to_status_id" : 150217253722402816,
  "created_at" : "2011-12-23 14:30:44 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150217095341277184",
  "text" : "Merry Christmas Buffalo! My present: a broken passenger side window.",
  "id" : 150217095341277184,
  "created_at" : "2011-12-23 14:12:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149967932636667904",
  "geo" : { },
  "id_str" : "149968705059696642",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove I know! Everyone just needs to give it a REST!",
  "id" : 149968705059696642,
  "in_reply_to_status_id" : 149967932636667904,
  "created_at" : "2011-12-22 21:45:00 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 69, 79 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Zvkxsmu0",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3062-thanks-simplehonestwork",
      "display_url" : "37signals.com\/svn\/posts\/3062\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149946208469778432",
  "text" : "Blown away by the generosity, craftsmanship, and thoughtfulness from @37signals with this: http:\/\/t.co\/Zvkxsmu0",
  "id" : 149946208469778432,
  "created_at" : "2011-12-22 20:15:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149701165322477568",
  "text" : "For those curious about the thundershirt, it was a sudden change from hyper\/freaked out from folks leaving to chilled out and almost drowsy.",
  "id" : 149701165322477568,
  "created_at" : "2011-12-22 04:01:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 0, 10 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149666021270233088",
  "geo" : { },
  "id_str" : "149679970308984833",
  "in_reply_to_user_id" : 15001533,
  "text" : "@mikeburns I get it!",
  "id" : 149679970308984833,
  "in_reply_to_status_id" : 149666021270233088,
  "created_at" : "2011-12-22 02:37:40 +0000",
  "in_reply_to_screen_name" : "mikeburns",
  "in_reply_to_user_id_str" : "15001533",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/kGIn4nWX",
      "expanded_url" : "http:\/\/path.com\/p\/3TWKl6",
      "display_url" : "path.com\/p\/3TWKl6"
    } ]
  },
  "geo" : { },
  "id_str" : "149678874182168576",
  "text" : "Bridges, Castles, Bazaars + Traders & Builders (with Amanda) [pic] \u2014 http:\/\/t.co\/kGIn4nWX",
  "id" : 149678874182168576,
  "created_at" : "2011-12-22 02:33:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149664081622732800",
  "geo" : { },
  "id_str" : "149665208909053952",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss dude let's play! My game center ID is quaranto",
  "id" : 149665208909053952,
  "in_reply_to_status_id" : 149664081622732800,
  "created_at" : "2011-12-22 01:39:01 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/149663893994733569\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/hqilRKmy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhO2hMWCAAEhSdk.jpg",
      "id_str" : "149663893998927873",
      "id" : 149663893998927873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhO2hMWCAAEhSdk.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hqilRKmy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149663893994733569",
  "text" : "Just tried thundershirt for the first time, holy crap. Huge difference. http:\/\/t.co\/hqilRKmy",
  "id" : 149663893994733569,
  "created_at" : "2011-12-22 01:33:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Chupp",
      "screen_name" : "semanticart",
      "indices" : [ 0, 12 ],
      "id_str" : "14212434",
      "id" : 14212434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149603682575581186",
  "geo" : { },
  "id_str" : "149603789857497088",
  "in_reply_to_user_id" : 14212434,
  "text" : "@semanticart ha HAA",
  "id" : 149603789857497088,
  "in_reply_to_status_id" : 149603682575581186,
  "created_at" : "2011-12-21 21:34:57 +0000",
  "in_reply_to_screen_name" : "semanticart",
  "in_reply_to_user_id_str" : "14212434",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 0, 11 ],
      "id_str" : "14107142",
      "id" : 14107142
    }, {
      "name" : "Aslak Helles\u00F8y",
      "screen_name" : "aslak_hellesoy",
      "indices" : [ 12, 27 ],
      "id_str" : "4994591",
      "id" : 4994591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149596628515422208",
  "geo" : { },
  "id_str" : "149597230175760384",
  "in_reply_to_user_id" : 14107142,
  "text" : "@dchelimsky @aslak_hellesoy i'm not counting cucumber here, i mean the other ruby test frameworks. minitest, test\/unit, etc.",
  "id" : 149597230175760384,
  "in_reply_to_status_id" : 149596628515422208,
  "created_at" : "2011-12-21 21:08:53 +0000",
  "in_reply_to_screen_name" : "dchelimsky",
  "in_reply_to_user_id_str" : "14107142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 0, 10 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/oAPgnhYQ",
      "expanded_url" : "http:\/\/www.ruby-lang.org\/en\/news\/2008\/08\/23\/dos-vulnerability-in-rexml\/",
      "display_url" : "ruby-lang.org\/en\/news\/2008\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149589023478910977",
  "geo" : { },
  "id_str" : "149589627337064449",
  "in_reply_to_user_id" : 9980812,
  "text" : "@igrigorik http:\/\/t.co\/oAPgnhYQ",
  "id" : 149589627337064449,
  "in_reply_to_status_id" : 149589023478910977,
  "created_at" : "2011-12-21 20:38:41 +0000",
  "in_reply_to_screen_name" : "igrigorik",
  "in_reply_to_user_id_str" : "9980812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin",
      "screen_name" : "mynyml",
      "indices" : [ 0, 7 ],
      "id_str" : "15689114",
      "id" : 15689114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149585106774917120",
  "geo" : { },
  "id_str" : "149586912947077121",
  "in_reply_to_user_id" : 15689114,
  "text" : "@mynyml that is not any easier than renaming a test case to something silly so you can match it with -n",
  "id" : 149586912947077121,
  "in_reply_to_status_id" : 149585106774917120,
  "created_at" : "2011-12-21 20:27:53 +0000",
  "in_reply_to_screen_name" : "mynyml",
  "in_reply_to_user_id_str" : "15689114",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149582875606532096",
  "text" : "Why is rspec the only ruby test framework that supports running tests by line number?",
  "id" : 149582875606532096,
  "created_at" : "2011-12-21 20:11:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Chapman",
      "screen_name" : "byllc",
      "indices" : [ 0, 6 ],
      "id_str" : "34287352",
      "id" : 34287352
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 15, 25 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149525965712789504",
  "geo" : { },
  "id_str" : "149529621887590401",
  "in_reply_to_user_id" : 34287352,
  "text" : "@byllc i blame @aspleenic !!",
  "id" : 149529621887590401,
  "in_reply_to_status_id" : 149525965712789504,
  "created_at" : "2011-12-21 16:40:14 +0000",
  "in_reply_to_screen_name" : "byllc",
  "in_reply_to_user_id_str" : "34287352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 0, 6 ],
      "id_str" : "14339524",
      "id" : 14339524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149332644725927936",
  "in_reply_to_user_id" : 14339524,
  "text" : "@phoet your pull has some comments once you're awake ! :D",
  "id" : 149332644725927936,
  "created_at" : "2011-12-21 03:37:31 +0000",
  "in_reply_to_screen_name" : "phoet",
  "in_reply_to_user_id_str" : "14339524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149330209127145473",
  "geo" : { },
  "id_str" : "149330790600294401",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw geddy can't even stay still for &gt; 10 seconds when awake.",
  "id" : 149330790600294401,
  "in_reply_to_status_id" : 149330209127145473,
  "created_at" : "2011-12-21 03:30:09 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149313128553918464",
  "geo" : { },
  "id_str" : "149322949038583808",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 some projects aren't meant to be rescued ;)",
  "id" : 149322949038583808,
  "in_reply_to_status_id" : 149313128553918464,
  "created_at" : "2011-12-21 02:58:59 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Gunderloy",
      "screen_name" : "MikeG1",
      "indices" : [ 0, 7 ],
      "id_str" : "728173",
      "id" : 728173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149308176037183488",
  "geo" : { },
  "id_str" : "149312361344413696",
  "in_reply_to_user_id" : 728173,
  "text" : "@MikeG1 sounds like he was having fun and wrote something. What is wrong with that?",
  "id" : 149312361344413696,
  "in_reply_to_status_id" : 149308176037183488,
  "created_at" : "2011-12-21 02:16:55 +0000",
  "in_reply_to_screen_name" : "MikeG1",
  "in_reply_to_user_id_str" : "728173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 0, 8 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "TheresaPrestonWerner",
      "screen_name" : "tpdubs2",
      "indices" : [ 9, 17 ],
      "id_str" : "118292028",
      "id" : 118292028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149297348865048576",
  "geo" : { },
  "id_str" : "149299253829828608",
  "in_reply_to_user_id" : 5502392,
  "text" : "@mojombo @tpdubs2 congrats dude!!",
  "id" : 149299253829828608,
  "in_reply_to_status_id" : 149297348865048576,
  "created_at" : "2011-12-21 01:24:50 +0000",
  "in_reply_to_screen_name" : "mojombo",
  "in_reply_to_user_id_str" : "5502392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/6YpHdB2Q",
      "expanded_url" : "http:\/\/path.com\/p\/11bGAP",
      "display_url" : "path.com\/p\/11bGAP"
    } ]
  },
  "geo" : { },
  "id_str" : "149285544587825152",
  "text" : "Sleepy cats in shops are the best. (with Amanda at Elmwood Village) [pic] \u2014 http:\/\/t.co\/6YpHdB2Q",
  "id" : 149285544587825152,
  "created_at" : "2011-12-21 00:30:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149256007015604225",
  "text" : "CORRECTION, NOW HIRING DESINGINEER WITH MUSIC VIDEO FIRST ROUND EXPERIENCES ONLY",
  "id" : 149256007015604225,
  "created_at" : "2011-12-20 22:32:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149164865175552001",
  "text" : "LOOKING FOR DESINGINEER WITH 8 YRS OF COFFEESCRIPT\/NODE.JS\/RUBBY ON RAILS EXPERIENCE",
  "id" : 149164865175552001,
  "created_at" : "2011-12-20 16:30:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149162985783435266",
  "geo" : { },
  "id_str" : "149164704579854336",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant this term makes me vomit a little bit",
  "id" : 149164704579854336,
  "in_reply_to_status_id" : 149162985783435266,
  "created_at" : "2011-12-20 16:30:11 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnneylee Rollins",
      "screen_name" : "JLeeGhost",
      "indices" : [ 0, 10 ],
      "id_str" : "306117941",
      "id" : 306117941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/ulMerXcb",
      "expanded_url" : "http:\/\/guides.rubygems.org\/specification-reference\/#add_development_dependency",
      "display_url" : "guides.rubygems.org\/specification-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149019749244874752",
  "geo" : { },
  "id_str" : "149145724821577728",
  "in_reply_to_user_id" : 306117941,
  "text" : "@JLeeGhost sounds like a development dependency? http:\/\/t.co\/ulMerXcb",
  "id" : 149145724821577728,
  "in_reply_to_status_id" : 149019749244874752,
  "created_at" : "2011-12-20 15:14:46 +0000",
  "in_reply_to_screen_name" : "JLeeGhost",
  "in_reply_to_user_id_str" : "306117941",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Faloona",
      "screen_name" : "faloonatic",
      "indices" : [ 0, 11 ],
      "id_str" : "172394522",
      "id" : 172394522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/VkGQHftz",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "147423878736654336",
  "geo" : { },
  "id_str" : "149116103744946176",
  "in_reply_to_user_id" : 172394522,
  "text" : "@faloonatic check out http:\/\/t.co\/VkGQHftz instead. I want to deprecate the old site.",
  "id" : 149116103744946176,
  "in_reply_to_status_id" : 147423878736654336,
  "created_at" : "2011-12-20 13:17:04 +0000",
  "in_reply_to_screen_name" : "faloonatic",
  "in_reply_to_user_id_str" : "172394522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leon",
      "screen_name" : "rubybuddha",
      "indices" : [ 0, 11 ],
      "id_str" : "129873542",
      "id" : 129873542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148980356459134978",
  "geo" : { },
  "id_str" : "148980914335137792",
  "in_reply_to_user_id" : 129873542,
  "text" : "@rubybuddha gem install bundler --pre",
  "id" : 148980914335137792,
  "in_reply_to_status_id" : 148980356459134978,
  "created_at" : "2011-12-20 04:19:52 +0000",
  "in_reply_to_screen_name" : "rubybuddha",
  "in_reply_to_user_id_str" : "129873542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/O8RYmOaN",
      "expanded_url" : "http:\/\/path.com\/p\/10SuhD",
      "display_url" : "path.com\/p\/10SuhD"
    } ]
  },
  "geo" : { },
  "id_str" : "148944990767288321",
  "text" : "It's a tree! (with Amanda) [pic] \u2014 http:\/\/t.co\/O8RYmOaN",
  "id" : 148944990767288321,
  "created_at" : "2011-12-20 01:57:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148916851802513408",
  "geo" : { },
  "id_str" : "148922502377250817",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius beeeewyoooooooooooooouuuu",
  "id" : 148922502377250817,
  "in_reply_to_status_id" : 148916851802513408,
  "created_at" : "2011-12-20 00:27:46 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 24, 34 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Gaug.es",
      "screen_name" : "gaugesapp",
      "indices" : [ 50, 60 ],
      "id_str" : "245369690",
      "id" : 245369690
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/148891663861944321\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/10NcZXXd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhD4Le8CEAAcqvR.jpg",
      "id_str" : "148891663870332928",
      "id" : 148891663870332928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhD4Le8CEAAcqvR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/10NcZXXd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148891663861944321",
  "text" : "Watching users fly into @gemcutter in realtime on @gaugesapp never gets old. http:\/\/t.co\/10NcZXXd",
  "id" : 148891663861944321,
  "created_at" : "2011-12-19 22:25:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Touset",
      "screen_name" : "stouset",
      "indices" : [ 0, 8 ],
      "id_str" : "23962897",
      "id" : 23962897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148880035074424832",
  "geo" : { },
  "id_str" : "148886123509317632",
  "in_reply_to_user_id" : 23962897,
  "text" : "@stouset yes, they are. i havent had a chance yet to look into it, there's a pull request open about it.",
  "id" : 148886123509317632,
  "in_reply_to_status_id" : 148880035074424832,
  "created_at" : "2011-12-19 22:03:12 +0000",
  "in_reply_to_screen_name" : "stouset",
  "in_reply_to_user_id_str" : "23962897",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 0, 6 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Pete O'Grady",
      "screen_name" : "peteog",
      "indices" : [ 7, 14 ],
      "id_str" : "2276651694",
      "id" : 2276651694
    }, {
      "name" : "jelveh",
      "screen_name" : "jelveh",
      "indices" : [ 15, 22 ],
      "id_str" : "14555398",
      "id" : 14555398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148763025300660224",
  "geo" : { },
  "id_str" : "148763196033994752",
  "in_reply_to_user_id" : 5743852,
  "text" : "@qrush @peteog @jelveh haha I asked already. Too early to tweet",
  "id" : 148763196033994752,
  "in_reply_to_status_id" : 148763025300660224,
  "created_at" : "2011-12-19 13:54:44 +0000",
  "in_reply_to_screen_name" : "qrush",
  "in_reply_to_user_id_str" : "5743852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete O'Grady",
      "screen_name" : "peteog",
      "indices" : [ 0, 7 ],
      "id_str" : "2276651694",
      "id" : 2276651694
    }, {
      "name" : "jelveh",
      "screen_name" : "jelveh",
      "indices" : [ 8, 15 ],
      "id_str" : "14555398",
      "id" : 14555398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148763025300660224",
  "text" : "@peteog @jelveh is this still happening?",
  "id" : 148763025300660224,
  "created_at" : "2011-12-19 13:54:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/5U4rO8LM",
      "expanded_url" : "http:\/\/path.com\/p\/9wGEn",
      "display_url" : "path.com\/p\/9wGEn"
    } ]
  },
  "geo" : { },
  "id_str" : "148575836398821376",
  "text" : "I'm helping! [pic] \u2014 http:\/\/t.co\/5U4rO8LM",
  "id" : 148575836398821376,
  "created_at" : "2011-12-19 01:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 0, 9 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 10, 18 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148453101748236288",
  "geo" : { },
  "id_str" : "148453160468480000",
  "in_reply_to_user_id" : 19297751,
  "text" : "@gitready @jo_liss thanks so much!!!",
  "id" : 148453160468480000,
  "in_reply_to_status_id" : 148453101748236288,
  "created_at" : "2011-12-18 17:22:46 +0000",
  "in_reply_to_screen_name" : "gitready",
  "in_reply_to_user_id_str" : "19297751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 3, 12 ],
      "id_str" : "19297751",
      "id" : 19297751
    }, {
      "name" : "Jo Liss",
      "screen_name" : "jo_liss",
      "indices" : [ 34, 42 ],
      "id_str" : "223422672",
      "id" : 223422672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Zj78ZOau",
      "expanded_url" : "http:\/\/gitready.com\/advanced\/2011\/10\/21\/ribbon-and-catchup-reading-new-commits.html",
      "display_url" : "gitready.com\/advanced\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "148453139186585600",
  "text" : "RT @gitready: New guest post from @jo_liss: http:\/\/t.co\/Zj78ZOau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jo Liss",
        "screen_name" : "jo_liss",
        "indices" : [ 20, 28 ],
        "id_str" : "223422672",
        "id" : 223422672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/Zj78ZOau",
        "expanded_url" : "http:\/\/gitready.com\/advanced\/2011\/10\/21\/ribbon-and-catchup-reading-new-commits.html",
        "display_url" : "gitready.com\/advanced\/2011\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "148453101748236288",
    "text" : "New guest post from @jo_liss: http:\/\/t.co\/Zj78ZOau",
    "id" : 148453101748236288,
    "created_at" : "2011-12-18 17:22:32 +0000",
    "user" : {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "protected" : false,
      "id_str" : "19297751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/72335082\/2776359417_fa33869cd0_o_normal.png",
      "id" : 19297751,
      "verified" : false
    }
  },
  "id" : 148453139186585600,
  "created_at" : "2011-12-18 17:22:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Boston",
      "screen_name" : "bostonaholic",
      "indices" : [ 0, 13 ],
      "id_str" : "16313839",
      "id" : 16313839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147383485701693440",
  "geo" : { },
  "id_str" : "148451713131610112",
  "in_reply_to_user_id" : 16313839,
  "text" : "@bostonaholic I'm looking for one, still got it?",
  "id" : 148451713131610112,
  "in_reply_to_status_id" : 147383485701693440,
  "created_at" : "2011-12-18 17:17:01 +0000",
  "in_reply_to_screen_name" : "bostonaholic",
  "in_reply_to_user_id_str" : "16313839",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McGeary",
      "screen_name" : "rmm5t",
      "indices" : [ 0, 6 ],
      "id_str" : "11645552",
      "id" : 11645552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148424925512859649",
  "geo" : { },
  "id_str" : "148440177000452097",
  "in_reply_to_user_id" : 11645552,
  "text" : "@rmm5t that's nuts! kind of found the place on a whim too.",
  "id" : 148440177000452097,
  "in_reply_to_status_id" : 148424925512859649,
  "created_at" : "2011-12-18 16:31:10 +0000",
  "in_reply_to_screen_name" : "rmm5t",
  "in_reply_to_user_id_str" : "11645552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148416472316784640",
  "text" : "It smells like Cheerios down here and i haven't ate breakfast. PROBLEM.",
  "id" : 148416472316784640,
  "created_at" : "2011-12-18 14:56:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/ob4xpTMV",
      "expanded_url" : "http:\/\/path.com\/p\/yBjJg",
      "display_url" : "path.com\/p\/yBjJg"
    } ]
  },
  "geo" : { },
  "id_str" : "148408211236593664",
  "text" : "Every morning. [pic] \u2014 http:\/\/t.co\/ob4xpTMV",
  "id" : 148408211236593664,
  "created_at" : "2011-12-18 14:24:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148405466240786432",
  "geo" : { },
  "id_str" : "148407188682059776",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba php is one helluva drug",
  "id" : 148407188682059776,
  "in_reply_to_status_id" : 148405466240786432,
  "created_at" : "2011-12-18 14:20:05 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 0, 8 ],
      "id_str" : "9664212",
      "id" : 9664212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148398306740019200",
  "geo" : { },
  "id_str" : "148403146299949056",
  "in_reply_to_user_id" : 9664212,
  "text" : "@joealba haha it was in september, went to the Cape. I think it was code free :P",
  "id" : 148403146299949056,
  "in_reply_to_status_id" : 148398306740019200,
  "created_at" : "2011-12-18 14:04:01 +0000",
  "in_reply_to_screen_name" : "joealba",
  "in_reply_to_user_id_str" : "9664212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 5, 15 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/u93mPh8d",
      "expanded_url" : "http:\/\/www.ayresphoto.com\/wedding\/amanda-nick\/",
      "display_url" : "ayresphoto.com\/wedding\/amanda\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.920972, -78.880333 ]
  },
  "id_str" : "148394936834867200",
  "text" : "Yay! @aquaranto and I got married! And there are now pictures to prove it. http:\/\/t.co\/u93mPh8d",
  "id" : 148394936834867200,
  "created_at" : "2011-12-18 13:31:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148021585570312192",
  "geo" : { },
  "id_str" : "148028026410647552",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j paid $50 for ours, just around 7. But yeah, seriously",
  "id" : 148028026410647552,
  "in_reply_to_status_id" : 148021585570312192,
  "created_at" : "2011-12-17 13:13:26 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147833906073309185",
  "geo" : { },
  "id_str" : "147833990601117696",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 thanks dude!",
  "id" : 147833990601117696,
  "in_reply_to_status_id" : 147833906073309185,
  "created_at" : "2011-12-17 00:22:24 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lyon",
      "screen_name" : "mattly",
      "indices" : [ 0, 7 ],
      "id_str" : "1768041",
      "id" : 1768041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147823923088732160",
  "geo" : { },
  "id_str" : "147833926365351937",
  "in_reply_to_user_id" : 1768041,
  "text" : "@mattly \/play yeah",
  "id" : 147833926365351937,
  "in_reply_to_status_id" : 147823923088732160,
  "created_at" : "2011-12-17 00:22:09 +0000",
  "in_reply_to_screen_name" : "mattly",
  "in_reply_to_user_id_str" : "1768041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 0, 6 ],
      "id_str" : "14339524",
      "id" : 14339524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147775354038272001",
  "geo" : { },
  "id_str" : "147782001506783232",
  "in_reply_to_user_id" : 14339524,
  "text" : "@phoet awesome!!!",
  "id" : 147782001506783232,
  "in_reply_to_status_id" : 147775354038272001,
  "created_at" : "2011-12-16 20:55:49 +0000",
  "in_reply_to_screen_name" : "phoet",
  "in_reply_to_user_id_str" : "14339524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147772393551695872",
  "text" : "@withloudhands :+1:",
  "id" : 147772393551695872,
  "created_at" : "2011-12-16 20:17:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/lPrRcPkb",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3059-2011-year-end-campfire-feature-blowout",
      "display_url" : "37signals.com\/svn\/posts\/3059\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147754378575618050",
  "text" : "Wrote about the new features\/goodies on Campfire! http:\/\/t.co\/lPrRcPkb",
  "id" : 147754378575618050,
  "created_at" : "2011-12-16 19:06:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/RyYdGLs9",
      "expanded_url" : "http:\/\/www.theatlanticcities.com\/arts-and-lifestyle\/2011\/12\/buffalo-then-and-now-1902-2011\/716\/",
      "display_url" : "theatlanticcities.com\/arts-and-lifes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147747357109391360",
  "text" : "Fascinating look at Buffalo, then and now: http:\/\/t.co\/RyYdGLs9",
  "id" : 147747357109391360,
  "created_at" : "2011-12-16 18:38:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 3, 10 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147703801640529920",
  "text" : "RT @cssboy: I'm looking for someone to help with wireframe \/ visual design on a project. Hourly contract work, great team & tech. Get @  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147703382369505280",
    "text" : "I'm looking for someone to help with wireframe \/ visual design on a project. Hourly contract work, great team & tech. Get @ me people.",
    "id" : 147703382369505280,
    "created_at" : "2011-12-16 15:43:25 +0000",
    "user" : {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "protected" : false,
      "id_str" : "3928731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1536392271\/image_normal.jpg",
      "id" : 3928731,
      "verified" : false
    }
  },
  "id" : 147703801640529920,
  "created_at" : "2011-12-16 15:45:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147545928885219329",
  "geo" : { },
  "id_str" : "147660243269201921",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik no dude, that's insane",
  "id" : 147660243269201921,
  "in_reply_to_status_id" : 147545928885219329,
  "created_at" : "2011-12-16 12:52:00 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147536805368045569",
  "geo" : { },
  "id_str" : "147538706700574720",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik yes, on iOS.",
  "id" : 147538706700574720,
  "in_reply_to_status_id" : 147536805368045569,
  "created_at" : "2011-12-16 04:49:03 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147535595705602048",
  "text" : "Omg, expansions for Carcassone. Who's in? I'm quaranto on game center.",
  "id" : 147535595705602048,
  "created_at" : "2011-12-16 04:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147437503429873664",
  "text" : "Does anyone actually enjoy using Cron? It's just terrible.",
  "id" : 147437503429873664,
  "created_at" : "2011-12-15 22:06:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 50, 58 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/07h1HdUo",
      "expanded_url" : "https:\/\/groups.google.com\/group\/gemcutter\/msg\/2d4d82657bb77c08",
      "display_url" : "groups.google.com\/group\/gemcutte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147156669619634176",
  "text" : "Posted my thoughts here: http:\/\/t.co\/07h1HdUo hey @antirez am I crazy? :)",
  "id" : 147156669619634176,
  "created_at" : "2011-12-15 03:30:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147154089334149120",
  "text" : "This way we'll let people build nicer, better graphs and we can stop worrying about maintaining crappy ones.",
  "id" : 147154089334149120,
  "created_at" : "2011-12-15 03:20:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 68, 78 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147153942135050240",
  "text" : "I think I've made up my mind: going to kill historical downloads on @gemcutter, replace with a Redis pub\/sub API.",
  "id" : 147153942135050240,
  "created_at" : "2011-12-15 03:20:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pete higgins",
      "screen_name" : "pete_higgins",
      "indices" : [ 0, 13 ],
      "id_str" : "216806575",
      "id" : 216806575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147092371476193280",
  "geo" : { },
  "id_str" : "147109498132234240",
  "in_reply_to_user_id" : 216806575,
  "text" : "@pete_higgins haha",
  "id" : 147109498132234240,
  "in_reply_to_status_id" : 147092371476193280,
  "created_at" : "2011-12-15 00:23:32 +0000",
  "in_reply_to_screen_name" : "pete_higgins",
  "in_reply_to_user_id_str" : "216806575",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147076674176036866",
  "text" : "Apparently I'm dumber than a bag of hammers, and a FileUtils.rm_rf just went postal in this test suite.",
  "id" : 147076674176036866,
  "created_at" : "2011-12-14 22:13:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147072365854068737",
  "text" : "Even stranger, the 1Password agent is still running, but its app is no where. WTF.",
  "id" : 147072365854068737,
  "created_at" : "2011-12-14 21:55:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147071759194128384",
  "text" : "WTF?! OSX just deleted all of the applications I've installed since getting this MBP, and removed some random ~ dirs. WTF??",
  "id" : 147071759194128384,
  "created_at" : "2011-12-14 21:53:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "37signals Changelog",
      "screen_name" : "37changes",
      "indices" : [ 3, 13 ],
      "id_str" : "113395745",
      "id" : 113395745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/bAVB0eLJ",
      "expanded_url" : "http:\/\/bit.ly\/ufVE4g",
      "display_url" : "bit.ly\/ufVE4g"
    } ]
  },
  "geo" : { },
  "id_str" : "147027096772943876",
  "text" : "RT @37changes: Campfire feature: Animated gifs now resize and animate when thumbnailed! http:\/\/t.co\/bAVB0eLJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/bAVB0eLJ",
        "expanded_url" : "http:\/\/bit.ly\/ufVE4g",
        "display_url" : "bit.ly\/ufVE4g"
      } ]
    },
    "geo" : { },
    "id_str" : "147026970989953024",
    "text" : "Campfire feature: Animated gifs now resize and animate when thumbnailed! http:\/\/t.co\/bAVB0eLJ",
    "id" : 147026970989953024,
    "created_at" : "2011-12-14 18:55:36 +0000",
    "user" : {
      "name" : "37signals Changelog",
      "screen_name" : "37changes",
      "protected" : false,
      "id_str" : "113395745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689704459\/37_normal.png",
      "id" : 113395745,
      "verified" : false
    }
  },
  "id" : 147027096772943876,
  "created_at" : "2011-12-14 18:56:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147026234319187968",
  "geo" : { },
  "id_str" : "147026636573904897",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin yeah if there's transparent frames there's problems :(",
  "id" : 147026636573904897,
  "in_reply_to_status_id" : 147026234319187968,
  "created_at" : "2011-12-14 18:54:16 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "147024457003843584",
  "geo" : { },
  "id_str" : "147024609781358594",
  "in_reply_to_user_id" : 96235840,
  "text" : "@freeblankets try now!",
  "id" : 147024609781358594,
  "in_reply_to_status_id" : 147024457003843584,
  "created_at" : "2011-12-14 18:46:13 +0000",
  "in_reply_to_screen_name" : "giantrobotbee",
  "in_reply_to_user_id_str" : "96235840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147024287927238656",
  "text" : "Upload an animated gif into Campfire. I dare you.",
  "id" : 147024287927238656,
  "created_at" : "2011-12-14 18:44:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 0, 14 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146997378531078144",
  "geo" : { },
  "id_str" : "147000329785982976",
  "in_reply_to_user_id" : 5896952,
  "text" : "@BuffaloRising YES.",
  "id" : 147000329785982976,
  "in_reply_to_status_id" : 146997378531078144,
  "created_at" : "2011-12-14 17:09:44 +0000",
  "in_reply_to_screen_name" : "BuffaloRising",
  "in_reply_to_user_id_str" : "5896952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 0, 9 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146965224568799233",
  "geo" : { },
  "id_str" : "146972410376228864",
  "in_reply_to_user_id" : 14212405,
  "text" : "@metadave haha whaaat",
  "id" : 146972410376228864,
  "in_reply_to_status_id" : 146965224568799233,
  "created_at" : "2011-12-14 15:18:47 +0000",
  "in_reply_to_screen_name" : "metadave",
  "in_reply_to_user_id_str" : "14212405",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 45, 55 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146937271764008960",
  "geo" : { },
  "id_str" : "146940283995697152",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn hell yes. I would do this but I think @aquaranto would hate me.",
  "id" : 146940283995697152,
  "in_reply_to_status_id" : 146937271764008960,
  "created_at" : "2011-12-14 13:11:08 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gh33da",
      "screen_name" : "gh33da",
      "indices" : [ 0, 7 ],
      "id_str" : "16468950",
      "id" : 16468950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146760988807528449",
  "geo" : { },
  "id_str" : "146794250862993408",
  "in_reply_to_user_id" : 16468950,
  "text" : "@gh33da no idea dude, I don't go near that hellhole",
  "id" : 146794250862993408,
  "in_reply_to_status_id" : 146760988807528449,
  "created_at" : "2011-12-14 03:30:51 +0000",
  "in_reply_to_screen_name" : "gh33da",
  "in_reply_to_user_id_str" : "16468950",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/oX5VoYcR",
      "expanded_url" : "http:\/\/path.com\/p\/1y6clL",
      "display_url" : "path.com\/p\/1y6clL"
    } ]
  },
  "geo" : { },
  "id_str" : "146751919187181568",
  "text" : "#WNYRuby night is go! (with Joseph and Amanda at Caputi's Sheridan Pub) [pic] \u2014 http:\/\/t.co\/oX5VoYcR",
  "id" : 146751919187181568,
  "created_at" : "2011-12-14 00:42:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/5VsaHP2l",
      "expanded_url" : "http:\/\/jammit.com\/store\/keyboard",
      "display_url" : "jammit.com\/store\/keyboard"
    }, {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/FsxrERxx",
      "expanded_url" : "http:\/\/jammit.com\/store\/drums",
      "display_url" : "jammit.com\/store\/drums"
    }, {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/FRfUJpHb",
      "expanded_url" : "http:\/\/jammit.com\/store\/guitar",
      "display_url" : "jammit.com\/store\/guitar"
    } ]
  },
  "in_reply_to_status_id_str" : "146704256710348800",
  "geo" : { },
  "id_str" : "146704832277917698",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety no? http:\/\/t.co\/5VsaHP2l http:\/\/t.co\/FsxrERxx http:\/\/t.co\/FRfUJpHb",
  "id" : 146704832277917698,
  "in_reply_to_status_id" : 146704256710348800,
  "created_at" : "2011-12-13 21:35:32 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/xlYXMeHl",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=zTH4bH9hmMw#",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146701416386396160",
  "text" : "Holy crap, this app looks awesome. And oh yeah, RUSH! http:\/\/t.co\/xlYXMeHl!",
  "id" : 146701416386396160,
  "created_at" : "2011-12-13 21:21:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 3, 11 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 91, 106 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 107, 116 ],
      "id_str" : "14212405",
      "id" : 14212405
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 117, 123 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 139, 140 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/vL145qVd",
      "expanded_url" : "http:\/\/bit.ly\/s689Br",
      "display_url" : "bit.ly\/s689Br"
    } ]
  },
  "geo" : { },
  "id_str" : "146611048861024256",
  "text" : "RT @wnyruby: Still seats available for tonight: http:\/\/t.co\/vL145qVd #WNYRuby - talks from @1ofyourmeteors @metadave @qrush and swag fro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Josef",
        "screen_name" : "1ofyourmeteors",
        "indices" : [ 78, 93 ],
        "id_str" : "155998525",
        "id" : 155998525
      }, {
        "name" : "Dave Parfitt",
        "screen_name" : "metadave",
        "indices" : [ 94, 103 ],
        "id_str" : "14212405",
        "id" : 14212405
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 104, 110 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Engine Yard",
        "screen_name" : "engineyard",
        "indices" : [ 125, 136 ],
        "id_str" : "7255652",
        "id" : 7255652
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/vL145qVd",
        "expanded_url" : "http:\/\/bit.ly\/s689Br",
        "display_url" : "bit.ly\/s689Br"
      } ]
    },
    "geo" : { },
    "id_str" : "146610372336553984",
    "text" : "Still seats available for tonight: http:\/\/t.co\/vL145qVd #WNYRuby - talks from @1ofyourmeteors @metadave @qrush and swag from @engineyard :)",
    "id" : 146610372336553984,
    "created_at" : "2011-12-13 15:20:11 +0000",
    "user" : {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "protected" : false,
      "id_str" : "205886758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1149676438\/wnyruby_normal.png",
      "id" : 205886758,
      "verified" : false
    }
  },
  "id" : 146611048861024256,
  "created_at" : "2011-12-13 15:22:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/fStUtgmD",
      "expanded_url" : "https:\/\/path.com\/p\/4BKQJw",
      "display_url" : "path.com\/p\/4BKQJw"
    } ]
  },
  "geo" : { },
  "id_str" : "146595292467298304",
  "text" : "Run!!! http:\/\/t.co\/fStUtgmD",
  "id" : 146595292467298304,
  "created_at" : "2011-12-13 14:20:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/1FaG53bK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ey2L_ExKWuI",
      "display_url" : "youtube.com\/watch?v=ey2L_E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "146409585572462592",
  "geo" : { },
  "id_str" : "146410465097023488",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw i see that and raise you http:\/\/t.co\/1FaG53bK",
  "id" : 146410465097023488,
  "in_reply_to_status_id" : 146409585572462592,
  "created_at" : "2011-12-13 02:05:49 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Rhinesmith",
      "screen_name" : "jerhinesmith",
      "indices" : [ 0, 13 ],
      "id_str" : "14564588",
      "id" : 14564588
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 18, 26 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146405776200708097",
  "geo" : { },
  "id_str" : "146409223373328384",
  "in_reply_to_user_id" : 14564588,
  "text" : "@jerhinesmith bug @ddollar, i havent played in months",
  "id" : 146409223373328384,
  "in_reply_to_status_id" : 146405776200708097,
  "created_at" : "2011-12-13 02:00:53 +0000",
  "in_reply_to_screen_name" : "jerhinesmith",
  "in_reply_to_user_id_str" : "14564588",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/X9K3ZU8k",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=31g0YE61PLQ",
      "display_url" : "youtube.com\/watch?v=31g0YE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146408761442054144",
  "text" : "Better current status: http:\/\/t.co\/X9K3ZU8k",
  "id" : 146408761442054144,
  "created_at" : "2011-12-13 01:59:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/USTvqLo9",
      "expanded_url" : "http:\/\/i.imgur.com\/ZtHFo.gif",
      "display_url" : "i.imgur.com\/ZtHFo.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "146408484685103104",
  "text" : "Current status: http:\/\/t.co\/USTvqLo9",
  "id" : 146408484685103104,
  "created_at" : "2011-12-13 01:57:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145302911549833216",
  "geo" : { },
  "id_str" : "146337895073071104",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith is your title now Heroku Barista?",
  "id" : 146337895073071104,
  "in_reply_to_status_id" : 145302911549833216,
  "created_at" : "2011-12-12 21:17:27 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146326868361097216",
  "text" : "Just mapped Divvy resize areas to Nethack character movements. Yep.",
  "id" : 146326868361097216,
  "created_at" : "2011-12-12 20:33:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/8VQrZiOk",
      "expanded_url" : "http:\/\/is.gd\/zyCdob",
      "display_url" : "is.gd\/zyCdob"
    } ]
  },
  "geo" : { },
  "id_str" : "146246123630239744",
  "text" : "\"If your company lacks the tools to communicate remotely, it\u2019s highly probable it can\u2019t communicate at all.\" http:\/\/t.co\/8VQrZiOk",
  "id" : 146246123630239744,
  "created_at" : "2011-12-12 15:12:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146216250593382400",
  "text" : "Looking to buy another CodeMash ticket, would appreciate any help in finding one!",
  "id" : 146216250593382400,
  "created_at" : "2011-12-12 13:14:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 36, 44 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/QmdzNI50",
      "expanded_url" : "http:\/\/www.scribd.com\/doc\/70908450\/Travel-Hacking",
      "display_url" : "scribd.com\/doc\/70908450\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "145900685995683841",
  "text" : "Awesome talk on travel hacking from @rubiety. Dude flys like no other. http:\/\/t.co\/QmdzNI50",
  "id" : 145900685995683841,
  "created_at" : "2011-12-11 16:20:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 1, 10 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 78, 86 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/9eT7yCd7",
      "expanded_url" : "http:\/\/is.gd\/ogpni1",
      "display_url" : "is.gd\/ogpni1"
    } ]
  },
  "geo" : { },
  "id_str" : "145869711287128067",
  "text" : "\u201C@rubygems: jay_unit (0.0.1): http:\/\/t.co\/9eT7yCd7 Seriously simple testing.\u201D @jayunit ZOMG",
  "id" : 145869711287128067,
  "created_at" : "2011-12-11 14:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Pie Inglis",
      "screen_name" : "zachinglis",
      "indices" : [ 0, 11 ],
      "id_str" : "770545",
      "id" : 770545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145679274911875073",
  "geo" : { },
  "id_str" : "145700386811031554",
  "in_reply_to_user_id" : 770545,
  "text" : "@zachinglis thanks dude !!",
  "id" : 145700386811031554,
  "in_reply_to_status_id" : 145679274911875073,
  "created_at" : "2011-12-11 03:04:13 +0000",
  "in_reply_to_screen_name" : "zachinglis",
  "in_reply_to_user_id_str" : "770545",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/4MCmFYHn",
      "expanded_url" : "https:\/\/path.com\/p\/35WRlS",
      "display_url" : "path.com\/p\/35WRlS"
    } ]
  },
  "geo" : { },
  "id_str" : "145649376386228224",
  "text" : "Playing Chrononauts, this game is wacky. http:\/\/t.co\/4MCmFYHn",
  "id" : 145649376386228224,
  "created_at" : "2011-12-10 23:41:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah rich",
      "screen_name" : "micahbrich",
      "indices" : [ 0, 11 ],
      "id_str" : "14566614",
      "id" : 14566614
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/145591571742593024\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/eTjNG43m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgU-w1xCEAE4uZq.jpg",
      "id_str" : "145591571746787329",
      "id" : 145591571746787329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgU-w1xCEAE4uZq.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eTjNG43m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145554865798660096",
  "geo" : { },
  "id_str" : "145591571742593024",
  "in_reply_to_user_id" : 14566614,
  "text" : "@micahbrich yeah he's pooped out, we let him run for over an hour http:\/\/t.co\/eTjNG43m",
  "id" : 145591571742593024,
  "in_reply_to_status_id" : 145554865798660096,
  "created_at" : "2011-12-10 19:51:51 +0000",
  "in_reply_to_screen_name" : "micahbrich",
  "in_reply_to_user_id_str" : "14566614",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145528350818050048",
  "text" : "Awesome day at the dog park, ground was frozen over (no mud!) and 2 other huskies were there.",
  "id" : 145528350818050048,
  "created_at" : "2011-12-10 15:40:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 15, 25 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145356812659601408",
  "text" : "Now I get it...@gemcutter's load spikes on the hour today were probably due to mirrors, hourly crons hitting us. Mind blown.",
  "id" : 145356812659601408,
  "created_at" : "2011-12-10 04:18:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 19, 29 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145276772156579840",
  "text" : "I'm trying to keep @gemcutter up to date with what we're trying out here, folks. Sorry. :(",
  "id" : 145276772156579840,
  "created_at" : "2011-12-09 23:00:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 0, 11 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145261551312584704",
  "geo" : { },
  "id_str" : "145270016307240961",
  "in_reply_to_user_id" : 9994542,
  "text" : "@brianmario passenger has worked well for us, not sure what's going wrong yet. we're discussing it in #rubygems on freenode.",
  "id" : 145270016307240961,
  "in_reply_to_status_id" : 145261551312584704,
  "created_at" : "2011-12-09 22:34:05 +0000",
  "in_reply_to_screen_name" : "brianmario",
  "in_reply_to_user_id_str" : "9994542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 3, 14 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145255524970143744",
  "text" : "RT @themcgruff: True story: Some guy's F5 key almost took down Basecamp.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145253985698320384",
    "text" : "True story: Some guy's F5 key almost took down Basecamp.",
    "id" : 145253985698320384,
    "created_at" : "2011-12-09 21:30:23 +0000",
    "user" : {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "protected" : false,
      "id_str" : "13984262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539946640417619968\/0wwEYfHi_normal.png",
      "id" : 13984262,
      "verified" : false
    }
  },
  "id" : 145255524970143744,
  "created_at" : "2011-12-09 21:36:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Radcliffe",
      "screen_name" : "dwradcliffe",
      "indices" : [ 0, 12 ],
      "id_str" : "19627341",
      "id" : 19627341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145244135778029568",
  "geo" : { },
  "id_str" : "145249084930932738",
  "in_reply_to_user_id" : 19627341,
  "text" : "@dwradcliffe because passenger works? what are you trying to ask here?",
  "id" : 145249084930932738,
  "in_reply_to_status_id" : 145244135778029568,
  "created_at" : "2011-12-09 21:10:55 +0000",
  "in_reply_to_screen_name" : "dwradcliffe",
  "in_reply_to_user_id_str" : "19627341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145243355784294401",
  "text" : "RT @gemcutter: Apparently, apache is dying\/restarting on an hourly basis, and we have no idea why yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145243158647799808",
    "text" : "Apparently, apache is dying\/restarting on an hourly basis, and we have no idea why yet.",
    "id" : 145243158647799808,
    "created_at" : "2011-12-09 20:47:22 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 145243355784294401,
  "created_at" : "2011-12-09 20:48:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Bodenner",
      "screen_name" : "ralphbod",
      "indices" : [ 0, 9 ],
      "id_str" : "89854263",
      "id" : 89854263
    }, {
      "name" : "David Eisinger",
      "screen_name" : "deisinger",
      "indices" : [ 10, 20 ],
      "id_str" : "12571852",
      "id" : 12571852
    }, {
      "name" : "justin_herrick.rb",
      "screen_name" : "JAH2488",
      "indices" : [ 21, 29 ],
      "id_str" : "17934912",
      "id" : 17934912
    }, {
      "name" : "Matt Hooks",
      "screen_name" : "matthooks",
      "indices" : [ 30, 40 ],
      "id_str" : "14592020",
      "id" : 14592020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145224720047013889",
  "geo" : { },
  "id_str" : "145243312243212288",
  "in_reply_to_user_id" : 89854263,
  "text" : "@ralphbod @deisinger @JAH2488 @matthooks i have no idea what's wrong yet, sorry guys",
  "id" : 145243312243212288,
  "in_reply_to_status_id" : 145224720047013889,
  "created_at" : "2011-12-09 20:47:58 +0000",
  "in_reply_to_screen_name" : "ralphbod",
  "in_reply_to_user_id_str" : "89854263",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/wxtSonyu",
      "expanded_url" : "http:\/\/www.winextra.com\/wp-content\/uploads\/2010\/06\/win7_annoyances-e1277352900437.jpg",
      "display_url" : "winextra.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "145237729616207872",
  "text" : "Yes, this is a real book: http:\/\/t.co\/wxtSonyu",
  "id" : 145237729616207872,
  "created_at" : "2011-12-09 20:25:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lindeman",
      "screen_name" : "alindeman",
      "indices" : [ 0, 10 ],
      "id_str" : "13235612",
      "id" : 13235612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145205539004100608",
  "geo" : { },
  "id_str" : "145208254161629184",
  "in_reply_to_user_id" : 13235612,
  "text" : "@alindeman please try out gem install bundler --pre, it's way faster",
  "id" : 145208254161629184,
  "in_reply_to_status_id" : 145205539004100608,
  "created_at" : "2011-12-09 18:28:40 +0000",
  "in_reply_to_screen_name" : "alindeman",
  "in_reply_to_user_id_str" : "13235612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bedell",
      "screen_name" : "kbedell",
      "indices" : [ 0, 8 ],
      "id_str" : "6578432",
      "id" : 6578432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145176845996916736",
  "geo" : { },
  "id_str" : "145196125949919232",
  "in_reply_to_user_id" : 6578432,
  "text" : "@kbedell K talked at RIT while I was there, it was great. Sad that I'll never get to hear R :(",
  "id" : 145196125949919232,
  "in_reply_to_status_id" : 145176845996916736,
  "created_at" : "2011-12-09 17:40:28 +0000",
  "in_reply_to_screen_name" : "kbedell",
  "in_reply_to_user_id_str" : "6578432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Speicher",
      "screen_name" : "rspeicher",
      "indices" : [ 0, 10 ],
      "id_str" : "15929592",
      "id" : 15929592
    }, {
      "name" : "Nick Zadrozny",
      "screen_name" : "nz_",
      "indices" : [ 49, 53 ],
      "id_str" : "49923",
      "id" : 49923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145193207209279488",
  "geo" : { },
  "id_str" : "145195965891100674",
  "in_reply_to_user_id" : 15929592,
  "text" : "@rspeicher yeah searching has been slow forever, @nz_ is going to infuse some Solr magic to make it better!",
  "id" : 145195965891100674,
  "in_reply_to_status_id" : 145193207209279488,
  "created_at" : "2011-12-09 17:39:50 +0000",
  "in_reply_to_screen_name" : "rspeicher",
  "in_reply_to_user_id_str" : "15929592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Chen",
      "screen_name" : "jcsalterego",
      "indices" : [ 0, 12 ],
      "id_str" : "14343561",
      "id" : 14343561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145192929818972160",
  "geo" : { },
  "id_str" : "145193204508139520",
  "in_reply_to_user_id" : 14343561,
  "text" : "@jcsalterego We're on Rackspace, so no.",
  "id" : 145193204508139520,
  "in_reply_to_status_id" : 145192929818972160,
  "created_at" : "2011-12-09 17:28:52 +0000",
  "in_reply_to_screen_name" : "jcsalterego",
  "in_reply_to_user_id_str" : "14343561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/bdjxoR36",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "145192702269603840",
  "text" : "I'm getting a lot of reports of downtime from NewRelic, StillAlive, Pingdom for http:\/\/t.co\/bdjxoR36, but no tweets. Anyone seeing this?",
  "id" : 145192702269603840,
  "created_at" : "2011-12-09 17:26:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145171106008018944",
  "text" : "Just found out about `awk '\u007Bprint $NF\u007D'`. AWK rules.",
  "id" : 145171106008018944,
  "created_at" : "2011-12-09 16:01:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145156692185849856",
  "text" : "Whoa, new twitter. Very discombobulated.",
  "id" : 145156692185849856,
  "created_at" : "2011-12-09 15:03:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/U0AfMb4m",
      "expanded_url" : "https:\/\/path.com\/p\/1xWpuJ",
      "display_url" : "path.com\/p\/1xWpuJ"
    } ]
  },
  "geo" : { },
  "id_str" : "144953812199800833",
  "text" : "coffee coffee coffee http:\/\/t.co\/U0AfMb4m",
  "id" : 144953812199800833,
  "created_at" : "2011-12-09 01:37:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter van Hardenberg",
      "screen_name" : "pvh",
      "indices" : [ 0, 4 ],
      "id_str" : "15532680",
      "id" : 15532680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144921323242651649",
  "geo" : { },
  "id_str" : "144926757034795008",
  "in_reply_to_user_id" : 15532680,
  "text" : "@pvh that's mostly his audience though. The books are fantastic.",
  "id" : 144926757034795008,
  "in_reply_to_status_id" : 144921323242651649,
  "created_at" : "2011-12-08 23:50:06 +0000",
  "in_reply_to_screen_name" : "pvh",
  "in_reply_to_user_id_str" : "15532680",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144915660777070593",
  "geo" : { },
  "id_str" : "144919203118448640",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath gem install bundler --pre",
  "id" : 144919203118448640,
  "in_reply_to_status_id" : 144915660777070593,
  "created_at" : "2011-12-08 23:20:05 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144855957409767425",
  "text" : "RT @r00k: I know a lot about Rails, vim, and professional development for programmers. Do you need (free) help with any of those? Get in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144855707752214528",
    "text" : "I know a lot about Rails, vim, and professional development for programmers. Do you need (free) help with any of those? Get in touch.",
    "id" : 144855707752214528,
    "created_at" : "2011-12-08 19:07:46 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 144855957409767425,
  "created_at" : "2011-12-08 19:08:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collegiate Times",
      "screen_name" : "CollegiateTimes",
      "indices" : [ 9, 25 ],
      "id_str" : "45960001",
      "id" : 45960001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144853172584841217",
  "text" : "Watching @CollegiateTimes is scary\/sad\/terrifying.",
  "id" : 144853172584841217,
  "created_at" : "2011-12-08 18:57:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144842431446269952",
  "text" : "I downloaded the new Twitter iOS client, and the web side looks the same still :(",
  "id" : 144842431446269952,
  "created_at" : "2011-12-08 18:15:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Denton",
      "screen_name" : "nicknotned",
      "indices" : [ 0, 11 ],
      "id_str" : "13029",
      "id" : 13029
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144794424738725888",
  "in_reply_to_user_id" : 13029,
  "text" : "@nicknotned @kevinpurdy i mean, congrats for being on top of it, but cmon, label your x-axis.",
  "id" : 144794424738725888,
  "created_at" : "2011-12-08 15:04:15 +0000",
  "in_reply_to_screen_name" : "nicknotned",
  "in_reply_to_user_id_str" : "13029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 3, 13 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144793849791905793",
  "text" : "RT @jbarnette: Revised log levels proposal: \"fyi,\" \"wtf,\" and \"omg.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144791640589078530",
    "text" : "Revised log levels proposal: \"fyi,\" \"wtf,\" and \"omg.\"",
    "id" : 144791640589078530,
    "created_at" : "2011-12-08 14:53:11 +0000",
    "user" : {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "protected" : false,
      "id_str" : "10453902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482193494002642944\/J3ZE2OBm_normal.jpeg",
      "id" : 10453902,
      "verified" : false
    }
  },
  "id" : 144793849791905793,
  "created_at" : "2011-12-08 15:01:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Denton",
      "screen_name" : "nicknotned",
      "indices" : [ 0, 11 ],
      "id_str" : "13029",
      "id" : 13029
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 12, 23 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144791755903074305",
  "geo" : { },
  "id_str" : "144793784088145920",
  "in_reply_to_user_id" : 13029,
  "text" : "@nicknotned @kevinpurdy this is possibly the worse graph ever created. What is this, a USA Today infographic?",
  "id" : 144793784088145920,
  "in_reply_to_status_id" : 144791755903074305,
  "created_at" : "2011-12-08 15:01:42 +0000",
  "in_reply_to_screen_name" : "nicknotned",
  "in_reply_to_user_id_str" : "13029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/gTM9wgGG",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3327202",
      "display_url" : "news.ycombinator.com\/item?id=3327202"
    } ]
  },
  "in_reply_to_status_id_str" : "144677167853346816",
  "geo" : { },
  "id_str" : "144770966969516033",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit another analysis of this: http:\/\/t.co\/gTM9wgGG",
  "id" : 144770966969516033,
  "in_reply_to_status_id" : 144677167853346816,
  "created_at" : "2011-12-08 13:31:02 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/jc1CECsm",
      "expanded_url" : "http:\/\/imgur.com\/1lCpd",
      "display_url" : "imgur.com\/1lCpd"
    } ]
  },
  "geo" : { },
  "id_str" : "144545408562110465",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense HERE IS A PICTURE OF A CAT IN EXCHANGE FOR FOLLOWINGS http:\/\/t.co\/jc1CECsm",
  "id" : 144545408562110465,
  "created_at" : "2011-12-07 22:34:45 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144545177036533761",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Y U NO FOLLOW ME!?",
  "id" : 144545177036533761,
  "created_at" : "2011-12-07 22:33:50 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Robertson",
      "screen_name" : "patricksroberts",
      "indices" : [ 0, 16 ],
      "id_str" : "46661605",
      "id" : 46661605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144523955208847360",
  "geo" : { },
  "id_str" : "144531472689278978",
  "in_reply_to_user_id" : 46661605,
  "text" : "@patricksroberts haha no, my master stroke will be less obnoxious",
  "id" : 144531472689278978,
  "in_reply_to_status_id" : 144523955208847360,
  "created_at" : "2011-12-07 21:39:23 +0000",
  "in_reply_to_screen_name" : "patricksroberts",
  "in_reply_to_user_id_str" : "46661605",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144511726325477376",
  "geo" : { },
  "id_str" : "144512832732536832",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena i honestly haven't looked at it in forever, i have zero context right now.",
  "id" : 144512832732536832,
  "in_reply_to_status_id" : 144511726325477376,
  "created_at" : "2011-12-07 20:25:18 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    }, {
      "name" : "seacreature",
      "screen_name" : "seacreature",
      "indices" : [ 12, 24 ],
      "id_str" : "517029319",
      "id" : 517029319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144511330181853184",
  "geo" : { },
  "id_str" : "144511525472837632",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena @seacreature blergh i'll handle it tonight. been swamped.",
  "id" : 144511525472837632,
  "in_reply_to_status_id" : 144511330181853184,
  "created_at" : "2011-12-07 20:20:07 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RIT SSE",
      "screen_name" : "rit_sse",
      "indices" : [ 37, 45 ],
      "id_str" : "345915846",
      "id" : 345915846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/ajknrnYe",
      "expanded_url" : "http:\/\/knowyourmeme.com\/memes\/flipping-tables-%E2%95%AF%E2%96%A1%EF%BC%89%E2%95%AF%EF%B8%B5-%E2%94%BB%E2%94%81%E2%94%BB",
      "display_url" : "knowyourmeme.com\/memes\/flipping\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144510071425089537",
  "text" : "Did not expect to see a reference to @rit_sse on http:\/\/t.co\/ajknrnYe.",
  "id" : 144510071425089537,
  "created_at" : "2011-12-07 20:14:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 32, 39 ],
      "id_str" : "14114222",
      "id" : 14114222
    }, {
      "name" : "ari rizzitano",
      "screen_name" : "arizzitano",
      "indices" : [ 41, 52 ],
      "id_str" : "124151910",
      "id" : 124151910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/hrHESSEm",
      "expanded_url" : "http:\/\/www.alphanail.com\/",
      "display_url" : "alphanail.com"
    } ]
  },
  "geo" : { },
  "id_str" : "144491724532756480",
  "text" : "What. http:\/\/t.co\/hrHESSEm (via @jayroh, @arizzitano)",
  "id" : 144491724532756480,
  "created_at" : "2011-12-07 19:01:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/X9rdcnox",
      "expanded_url" : "http:\/\/files.sharenator.com\/u_mad_bro_Picture_Challenge_3-s469x428-160564-535.jpg",
      "display_url" : "files.sharenator.com\/u_mad_bro_Pict\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "144491122142621696",
  "geo" : { },
  "id_str" : "144491374346125312",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek http:\/\/t.co\/X9rdcnox",
  "id" : 144491374346125312,
  "in_reply_to_status_id" : 144491122142621696,
  "created_at" : "2011-12-07 19:00:02 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/tjyGrteM",
      "expanded_url" : "https:\/\/github.com\/mxcl\/homebrew\/pull\/9019\/files",
      "display_url" : "github.com\/mxcl\/homebrew\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144452508327227393",
  "text" : "Made my first Homebrew recipe! http:\/\/t.co\/tjyGrteM",
  "id" : 144452508327227393,
  "created_at" : "2011-12-07 16:25:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon-Paul Lussier",
      "screen_name" : "jonpaullussier",
      "indices" : [ 0, 15 ],
      "id_str" : "94493550",
      "id" : 94493550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/iPyuAVOp",
      "expanded_url" : "http:\/\/images.google.com",
      "display_url" : "images.google.com"
    } ]
  },
  "in_reply_to_status_id_str" : "144449636688601088",
  "geo" : { },
  "id_str" : "144450008626900992",
  "in_reply_to_user_id" : 94493550,
  "text" : "@jonpaullussier yeah try it on http:\/\/t.co\/iPyuAVOp, my bad",
  "id" : 144450008626900992,
  "in_reply_to_status_id" : 144449636688601088,
  "created_at" : "2011-12-07 16:15:40 +0000",
  "in_reply_to_screen_name" : "jonpaullussier",
  "in_reply_to_user_id_str" : "94493550",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144448868254355456",
  "text" : "Drag an image onto Google's search bar. I DARE YOU.",
  "id" : 144448868254355456,
  "created_at" : "2011-12-07 16:11:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144435695157641216",
  "geo" : { },
  "id_str" : "144436795344556032",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou wow awesome. may ruby be with you!",
  "id" : 144436795344556032,
  "in_reply_to_status_id" : 144435695157641216,
  "created_at" : "2011-12-07 15:23:10 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144406665779888128",
  "geo" : { },
  "id_str" : "144407358041374720",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer play more nethack :)",
  "id" : 144407358041374720,
  "in_reply_to_status_id" : 144406665779888128,
  "created_at" : "2011-12-07 13:26:11 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 49, 56 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/144305381240352768\/photo\/1",
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/P0kwYvrd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgCs-sxCMAAvBTf.jpg",
      "id_str" : "144305381244547072",
      "id" : 144305381244547072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgCs-sxCMAAvBTf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/P0kwYvrd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144305381240352768",
  "text" : "Never tied before in Carcassone. Epic match with @tekkub ! http:\/\/t.co\/P0kwYvrd",
  "id" : 144305381240352768,
  "created_at" : "2011-12-07 06:40:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144293705073963008",
  "text" : "So far, Path is great at telling me when people are sleeping. SOCIAL.",
  "id" : 144293705073963008,
  "created_at" : "2011-12-07 05:54:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann With No E",
      "screen_name" : "rocketslide",
      "indices" : [ 10, 22 ],
      "id_str" : "10035582",
      "id" : 10035582
    }, {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 24, 34 ],
      "id_str" : "355473809",
      "id" : 355473809
    }, {
      "name" : "Edwrd Ocampo-Gooding",
      "screen_name" : "edwardog",
      "indices" : [ 63, 72 ],
      "id_str" : "14251580",
      "id" : 14251580
    }, {
      "name" : "Emily Garvey",
      "screen_name" : "CiaoEmily",
      "indices" : [ 74, 84 ],
      "id_str" : "264372235",
      "id" : 264372235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/K1AcOw4j",
      "expanded_url" : "http:\/\/librarianheygirl.tumblr.com\/",
      "display_url" : "librarianheygirl.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "144258733260816384",
  "text" : "Attention @rocketslide, @kikiaards : http:\/\/t.co\/K1AcOw4j (via @edwardog, @ciaoemily)",
  "id" : 144258733260816384,
  "created_at" : "2011-12-07 03:35:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Len Smith",
      "screen_name" : "ignu",
      "indices" : [ 0, 5 ],
      "id_str" : "6649832",
      "id" : 6649832
    }, {
      "name" : "Randy Schmidt",
      "screen_name" : "R38Y",
      "indices" : [ 6, 11 ],
      "id_str" : "1465521",
      "id" : 1465521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144249502503682049",
  "geo" : { },
  "id_str" : "144252436851343360",
  "in_reply_to_user_id" : 6649832,
  "text" : "@ignu @r38y I approve of this sticker.",
  "id" : 144252436851343360,
  "in_reply_to_status_id" : 144249502503682049,
  "created_at" : "2011-12-07 03:10:35 +0000",
  "in_reply_to_screen_name" : "ignu",
  "in_reply_to_user_id_str" : "6649832",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/eqSqXdIh",
      "expanded_url" : "http:\/\/i.imgur.com\/iEqUb.jpg",
      "display_url" : "i.imgur.com\/iEqUb.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "144249880062332928",
  "text" : "Huskies. http:\/\/t.co\/eqSqXdIh",
  "id" : 144249880062332928,
  "created_at" : "2011-12-07 03:00:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Glass",
      "screen_name" : "iterology",
      "indices" : [ 0, 10 ],
      "id_str" : "20953318",
      "id" : 20953318
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 49, 59 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144248986465861632",
  "geo" : { },
  "id_str" : "144249223066558464",
  "in_reply_to_user_id" : 20953318,
  "text" : "@iterology i am on lion, but it was happening on @gemcutter's production RHEL box too.",
  "id" : 144249223066558464,
  "in_reply_to_status_id" : 144248986465861632,
  "created_at" : "2011-12-07 02:57:49 +0000",
  "in_reply_to_screen_name" : "iterology",
  "in_reply_to_user_id_str" : "20953318",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/EF2l1lXt",
      "expanded_url" : "http:\/\/groups.google.com\/group\/gemcutter\/msg\/86648bf267e9a99c",
      "display_url" : "groups.google.com\/group\/gemcutte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144249074189742080",
  "text" : "RT @gemcutter: Downloads cron post-mortem: http:\/\/t.co\/EF2l1lXt TL;DR, we lost some data, still working on it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/EF2l1lXt",
        "expanded_url" : "http:\/\/groups.google.com\/group\/gemcutter\/msg\/86648bf267e9a99c",
        "display_url" : "groups.google.com\/group\/gemcutte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "144249022310395904",
    "text" : "Downloads cron post-mortem: http:\/\/t.co\/EF2l1lXt TL;DR, we lost some data, still working on it.",
    "id" : 144249022310395904,
    "created_at" : "2011-12-07 02:57:01 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 144249074189742080,
  "created_at" : "2011-12-07 02:57:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Glass",
      "screen_name" : "iterology",
      "indices" : [ 0, 10 ],
      "id_str" : "20953318",
      "id" : 20953318
    }, {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "indices" : [ 11, 19 ],
      "id_str" : "15201409",
      "id" : 15201409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/LZkGuzBC",
      "expanded_url" : "http:\/\/redmine.ruby-lang.org\/issues\/5719",
      "display_url" : "redmine.ruby-lang.org\/issues\/5719"
    } ]
  },
  "in_reply_to_status_id_str" : "144244744497807361",
  "geo" : { },
  "id_str" : "144245496230330368",
  "in_reply_to_user_id" : 20953318,
  "text" : "@iterology @tcollen mind commenting on that bug report? http:\/\/t.co\/LZkGuzBC",
  "id" : 144245496230330368,
  "in_reply_to_status_id" : 144244744497807361,
  "created_at" : "2011-12-07 02:43:00 +0000",
  "in_reply_to_screen_name" : "iterology",
  "in_reply_to_user_id_str" : "20953318",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Collen",
      "screen_name" : "tcollen",
      "indices" : [ 0, 8 ],
      "id_str" : "15201409",
      "id" : 15201409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144245200418652160",
  "geo" : { },
  "id_str" : "144245440865509376",
  "in_reply_to_user_id" : 15201409,
  "text" : "@tcollen yeah i think it depends on the size\/input of the hash and what's in it. I attempted to bisect it as well.",
  "id" : 144245440865509376,
  "in_reply_to_status_id" : 144245200418652160,
  "created_at" : "2011-12-07 02:42:47 +0000",
  "in_reply_to_screen_name" : "tcollen",
  "in_reply_to_user_id_str" : "15201409",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HyperDav",
      "screen_name" : "HyperDav",
      "indices" : [ 0, 9 ],
      "id_str" : "2789553941",
      "id" : 2789553941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144243223609606144",
  "geo" : { },
  "id_str" : "144244006191247361",
  "in_reply_to_user_id" : 201789953,
  "text" : "@hyperdav i think it's just Hash::[]. :(",
  "id" : 144244006191247361,
  "in_reply_to_status_id" : 144243223609606144,
  "created_at" : "2011-12-07 02:37:05 +0000",
  "in_reply_to_screen_name" : "habanerd",
  "in_reply_to_user_id_str" : "201789953",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Colp",
      "screen_name" : "joshnet",
      "indices" : [ 0, 8 ],
      "id_str" : "5716182",
      "id" : 5716182
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 9, 17 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/LZkGuzBC",
      "expanded_url" : "http:\/\/redmine.ruby-lang.org\/issues\/5719",
      "display_url" : "redmine.ruby-lang.org\/issues\/5719"
    } ]
  },
  "in_reply_to_status_id_str" : "144241885223976963",
  "geo" : { },
  "id_str" : "144242653939245059",
  "in_reply_to_user_id" : 5716182,
  "text" : "@joshnet @capotej http:\/\/t.co\/LZkGuzBC",
  "id" : 144242653939245059,
  "in_reply_to_status_id" : 144241885223976963,
  "created_at" : "2011-12-07 02:31:43 +0000",
  "in_reply_to_screen_name" : "joshnet",
  "in_reply_to_user_id_str" : "5716182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/LZkGuzBC",
      "expanded_url" : "http:\/\/redmine.ruby-lang.org\/issues\/5719",
      "display_url" : "redmine.ruby-lang.org\/issues\/5719"
    } ]
  },
  "geo" : { },
  "id_str" : "144242584192155650",
  "text" : "Yay, my first Ruby bug! http:\/\/t.co\/LZkGuzBC I mean, not yay.",
  "id" : 144242584192155650,
  "created_at" : "2011-12-07 02:31:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144241240899198976",
  "text" : "Oh boy, I found a Ruby 1.9.3 bug! Hashes can't have several thousand items in them, or KABOOM!",
  "id" : 144241240899198976,
  "created_at" : "2011-12-07 02:26:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144219944396136449",
  "geo" : { },
  "id_str" : "144220755276738560",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv haha oops",
  "id" : 144220755276738560,
  "in_reply_to_status_id" : 144219944396136449,
  "created_at" : "2011-12-07 01:04:42 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 11, 19 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144219621988372481",
  "text" : "Looks like @kdaigle has the hookup. Thanks!",
  "id" : 144219621988372481,
  "created_at" : "2011-12-07 01:00:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinterest",
      "screen_name" : "Pinterest",
      "indices" : [ 16, 26 ],
      "id_str" : "106837463",
      "id" : 106837463
    }, {
      "name" : "Aquarant",
      "screen_name" : "Aquarant",
      "indices" : [ 36, 45 ],
      "id_str" : "240432641",
      "id" : 240432641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144218056695103489",
  "text" : "Anyone have any @pinterest invites? @aquarant is dying for one.",
  "id" : 144218056695103489,
  "created_at" : "2011-12-07 00:53:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 0, 6 ],
      "id_str" : "14339524",
      "id" : 14339524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/vzyOcJZk",
      "expanded_url" : "http:\/\/groups.google.com\/group\/gemcutter\/browse_thread\/thread\/c3ca19ff8e05e4f4",
      "display_url" : "groups.google.com\/group\/gemcutte\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "144153605727989760",
  "geo" : { },
  "id_str" : "144155106739367936",
  "in_reply_to_user_id" : 14339524,
  "text" : "@phoet agreed. wrote this up here: http:\/\/t.co\/vzyOcJZk",
  "id" : 144155106739367936,
  "in_reply_to_status_id" : 144153605727989760,
  "created_at" : "2011-12-06 20:43:50 +0000",
  "in_reply_to_screen_name" : "phoet",
  "in_reply_to_user_id_str" : "14339524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 11, 20 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144118176106553344",
  "geo" : { },
  "id_str" : "144132158729109506",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 @bquarant this is what i've been missing since i moved back, clearly. going to have to go now.",
  "id" : 144132158729109506,
  "in_reply_to_status_id" : 144118176106553344,
  "created_at" : "2011-12-06 19:12:39 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan McAdams",
      "screen_name" : "rit",
      "indices" : [ 0, 4 ],
      "id_str" : "5961382",
      "id" : 5961382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144131475867058176",
  "geo" : { },
  "id_str" : "144131739651031040",
  "in_reply_to_user_id" : 5961382,
  "text" : "@rit PATCH MODE ALL THE THINGS! git add -p \/ git checkout -p \/ git stash -p \/ git reset -p",
  "id" : 144131739651031040,
  "in_reply_to_status_id" : 144131475867058176,
  "created_at" : "2011-12-06 19:10:59 +0000",
  "in_reply_to_screen_name" : "rit",
  "in_reply_to_user_id_str" : "5961382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Lqvmmpmz",
      "expanded_url" : "http:\/\/lexington.coop",
      "display_url" : "lexington.coop"
    } ]
  },
  "in_reply_to_status_id_str" : "144130183702659072",
  "geo" : { },
  "id_str" : "144130886722523136",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I'm 5 minutes driving from wegmans now, lol. and 10 mins walking from http:\/\/t.co\/Lqvmmpmz :)",
  "id" : 144130886722523136,
  "in_reply_to_status_id" : 144130183702659072,
  "created_at" : "2011-12-06 19:07:35 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 6, 13 ],
      "id_str" : "9488922",
      "id" : 9488922
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 18, 30 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Oy2e7EVr",
      "expanded_url" : "http:\/\/bostonglobe.com\/business\/2011\/12\/06\/wegmans-expand-into-newton\/E5xHfSQwciJ5HmJ4LroFfL\/story.html",
      "display_url" : "bostonglobe.com\/business\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144129525444395008",
  "text" : "Dang. @cpytel and @bcardarella, kinda jelly: http:\/\/t.co\/Oy2e7EVr",
  "id" : 144129525444395008,
  "created_at" : "2011-12-06 19:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144119421823234049",
  "text" : "RT @bquarant: It's tuesday, time for brogramming",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144066865965174784",
    "text" : "It's tuesday, time for brogramming",
    "id" : 144066865965174784,
    "created_at" : "2011-12-06 14:53:12 +0000",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 144119421823234049,
  "created_at" : "2011-12-06 18:22:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/WPmV2M1m",
      "expanded_url" : "http:\/\/g.co\/maps\/hw58y",
      "display_url" : "g.co\/maps\/hw58y"
    } ]
  },
  "geo" : { },
  "id_str" : "144108462375309312",
  "text" : "Gotta admit, Street View on RIT's campus is rad. http:\/\/t.co\/WPmV2M1m",
  "id" : 144108462375309312,
  "created_at" : "2011-12-06 17:38:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144077984725348352",
  "geo" : { },
  "id_str" : "144082581049196545",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton is this when he takes YER JOB?",
  "id" : 144082581049196545,
  "in_reply_to_status_id" : 144077984725348352,
  "created_at" : "2011-12-06 15:55:38 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/IyuJrq70",
      "expanded_url" : "http:\/\/37signals.com\/basecampnext",
      "display_url" : "37signals.com\/basecampnext"
    } ]
  },
  "geo" : { },
  "id_str" : "144078371742171136",
  "text" : "RT @jasonfried: In 2004, 37signals released Basecamp and changed the way millions manage projects. In 2012\u2026 http:\/\/t.co\/IyuJrq70",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/IyuJrq70",
        "expanded_url" : "http:\/\/37signals.com\/basecampnext",
        "display_url" : "37signals.com\/basecampnext"
      } ]
    },
    "geo" : { },
    "id_str" : "144061190044266496",
    "text" : "In 2004, 37signals released Basecamp and changed the way millions manage projects. In 2012\u2026 http:\/\/t.co\/IyuJrq70",
    "id" : 144061190044266496,
    "created_at" : "2011-12-06 14:30:38 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 144078371742171136,
  "created_at" : "2011-12-06 15:38:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schr\u00F6der",
      "screen_name" : "phoet",
      "indices" : [ 0, 6 ],
      "id_str" : "14339524",
      "id" : 14339524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143610808721612800",
  "geo" : { },
  "id_str" : "143844432637202433",
  "in_reply_to_user_id" : 14339524,
  "text" : "@phoet yeah, i know. going to look into it :(",
  "id" : 143844432637202433,
  "in_reply_to_status_id" : 143610808721612800,
  "created_at" : "2011-12-06 00:09:19 +0000",
  "in_reply_to_screen_name" : "phoet",
  "in_reply_to_user_id_str" : "14339524",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143810926477447168",
  "geo" : { },
  "id_str" : "143813495954214914",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton thanks for reminding me to delete my linked-in profile",
  "id" : 143813495954214914,
  "in_reply_to_status_id" : 143810926477447168,
  "created_at" : "2011-12-05 22:06:24 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143810094365286400",
  "text" : "Are any Gowalla employees going to California? I don't understand why this was a good move.",
  "id" : 143810094365286400,
  "created_at" : "2011-12-05 21:52:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/fBrIydYq",
      "expanded_url" : "http:\/\/lexington.coop\/",
      "display_url" : "lexington.coop"
    } ]
  },
  "geo" : { },
  "id_str" : "143798335915032576",
  "text" : "First use of this TLD I've seen, and happy to be an owner: http:\/\/t.co\/fBrIydYq",
  "id" : 143798335915032576,
  "created_at" : "2011-12-05 21:06:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143783693352308736",
  "geo" : { },
  "id_str" : "143784861214322688",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove this is awesome. thanks for your hard work, i dont think enough people appreciate the tiny things that make huge differences.",
  "id" : 143784861214322688,
  "in_reply_to_status_id" : 143783693352308736,
  "created_at" : "2011-12-05 20:12:36 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143779102824992769",
  "geo" : { },
  "id_str" : "143783369354911744",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams haha traffic on Rt. 9 will be even more terrible.",
  "id" : 143783369354911744,
  "in_reply_to_status_id" : 143779102824992769,
  "created_at" : "2011-12-05 20:06:41 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/5XMJIfwx",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Valley_girl#Sociolect",
      "display_url" : "en.wikipedia.org\/wiki\/Valley_gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143757995195641856",
  "text" : "http:\/\/t.co\/5XMJIfwx is hilarious. \"Womang - Used to refer to the ladies\"",
  "id" : 143757995195641856,
  "created_at" : "2011-12-05 18:25:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/FKBr7CIV",
      "expanded_url" : "http:\/\/me.veekun.com\/blog\/2011\/12\/04\/fuck-passwords\/",
      "display_url" : "me.veekun.com\/blog\/2011\/12\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143714035563626498",
  "text" : "Seriously sick of passwords too. Ugh. http:\/\/t.co\/FKBr7CIV",
  "id" : 143714035563626498,
  "created_at" : "2011-12-05 15:31:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Bellantoni",
      "screen_name" : "mjbellantoni",
      "indices" : [ 0, 13 ],
      "id_str" : "10919432",
      "id" : 10919432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143691767391322112",
  "geo" : { },
  "id_str" : "143707825179344896",
  "in_reply_to_user_id" : 10919432,
  "text" : "@mjbellantoni ugh, i forgot about this :(",
  "id" : 143707825179344896,
  "in_reply_to_status_id" : 143691767391322112,
  "created_at" : "2011-12-05 15:06:30 +0000",
  "in_reply_to_screen_name" : "mjbellantoni",
  "in_reply_to_user_id_str" : "10919432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143694952906493952",
  "geo" : { },
  "id_str" : "143699005040377856",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape just wait until she starts really running. THERE WILL BE MUD.",
  "id" : 143699005040377856,
  "in_reply_to_status_id" : 143694952906493952,
  "created_at" : "2011-12-05 14:31:27 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/G1pI3jUO",
      "expanded_url" : "http:\/\/instagr.am\/p\/XZDM7\/",
      "display_url" : "instagr.am\/p\/XZDM7\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9177150149, -78.8767290115 ]
  },
  "id_str" : "143461671866871808",
  "text" : "36 points! Lost but it was awesome.  @ SPoT Coffee Elmwood Cafe http:\/\/t.co\/G1pI3jUO",
  "id" : 143461671866871808,
  "created_at" : "2011-12-04 22:48:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/YOphSTMI",
      "expanded_url" : "http:\/\/instagr.am\/p\/XYfOt\/",
      "display_url" : "instagr.am\/p\/XYfOt\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9177150149, -78.8767290115 ]
  },
  "id_str" : "143448903453376512",
  "text" : "!\u00A1Puerto Rico!  @ SPoT Coffee Elmwood Cafe http:\/\/t.co\/YOphSTMI",
  "id" : 143448903453376512,
  "created_at" : "2011-12-04 21:57:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 48, 58 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143425234102530048",
  "geo" : { },
  "id_str" : "143426443144216577",
  "in_reply_to_user_id" : 324160285,
  "text" : "@DuglasYun haha we haven't gotten there yet but @aquaranto hearts janeway more than Picard :(",
  "id" : 143426443144216577,
  "in_reply_to_status_id" : 143425234102530048,
  "created_at" : "2011-12-04 20:28:23 +0000",
  "in_reply_to_screen_name" : "dougyun",
  "in_reply_to_user_id_str" : "324160285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/leymGy17",
      "expanded_url" : "http:\/\/instagr.am\/p\/XXbai\/",
      "display_url" : "instagr.am\/p\/XXbai\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9177150149, -78.8767290115 ]
  },
  "id_str" : "143424332843061248",
  "text" : "Intense game of Zombie\/Super Munchkin going down.  @ SPoT Coffee Elmwood Cafe http:\/\/t.co\/leymGy17",
  "id" : 143424332843061248,
  "created_at" : "2011-12-04 20:20:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143359647624081408",
  "text" : "Organized my iPhone icons into groups named Bridge, Comm, Ops, and Engineering last night at 2am. Yep.",
  "id" : 143359647624081408,
  "created_at" : "2011-12-04 16:02:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    }, {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 8, 22 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143310123710939136",
  "geo" : { },
  "id_str" : "143310946721472512",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw @joshuaclayton private\/protected\/public. And lolruby",
  "id" : 143310946721472512,
  "in_reply_to_status_id" : 143310123710939136,
  "created_at" : "2011-12-04 12:49:26 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dziuba",
      "screen_name" : "dozba",
      "indices" : [ 0, 6 ],
      "id_str" : "44282335",
      "id" : 44282335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143214719799525376",
  "geo" : { },
  "id_str" : "143220108268015616",
  "in_reply_to_user_id" : 44282335,
  "text" : "@dozba sounds like you should call it something different.",
  "id" : 143220108268015616,
  "in_reply_to_status_id" : 143214719799525376,
  "created_at" : "2011-12-04 06:48:29 +0000",
  "in_reply_to_screen_name" : "dozba",
  "in_reply_to_user_id_str" : "44282335",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143158253868679168",
  "geo" : { },
  "id_str" : "143162450781548545",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel I feel the same about programmers that have elaborate blog designs and don't write much, or constantly redesign their sites",
  "id" : 143162450781548545,
  "in_reply_to_status_id" : 143158253868679168,
  "created_at" : "2011-12-04 02:59:22 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sabres",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143154559034990592",
  "text" : "Why is everyone out to kill Miller? #Sabres",
  "id" : 143154559034990592,
  "created_at" : "2011-12-04 02:28:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Ji4ZAtfx",
      "expanded_url" : "http:\/\/instagr.am\/p\/XK4vB\/",
      "display_url" : "instagr.am\/p\/XK4vB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.919659, -78.87696865 ]
  },
  "id_str" : "143080156985163777",
  "text" : "HUUURKKK  @ Elmwood Village http:\/\/t.co\/Ji4ZAtfx",
  "id" : 143080156985163777,
  "created_at" : "2011-12-03 21:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/SXnsuEOB",
      "expanded_url" : "http:\/\/instagr.am\/p\/XKb6l\/",
      "display_url" : "instagr.am\/p\/XKb6l\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.919659, -78.87696865 ]
  },
  "id_str" : "143069634936053761",
  "text" : "Random giraffe?  @ Elmwood Village http:\/\/t.co\/SXnsuEOB",
  "id" : 143069634936053761,
  "created_at" : "2011-12-03 20:50:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143066690496888833",
  "geo" : { },
  "id_str" : "143067066663051264",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou I've done that same ramble. What bozos.",
  "id" : 143067066663051264,
  "in_reply_to_status_id" : 143066690496888833,
  "created_at" : "2011-12-03 20:40:21 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 12, 17 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 18, 23 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143065638989082624",
  "geo" : { },
  "id_str" : "143066758809518080",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @JEG2 @avdi it's rails-erd",
  "id" : 143066758809518080,
  "in_reply_to_status_id" : 143065638989082624,
  "created_at" : "2011-12-03 20:39:08 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 6, 17 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 18, 23 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143044465265872896",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 @joshsusser @avdi thanks fellas. Also you guys missed erd.png in Rails.root, very helpful :)",
  "id" : 143044465265872896,
  "created_at" : "2011-12-03 19:10:32 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemnasium",
      "screen_name" : "gemnasiumapp",
      "indices" : [ 5, 18 ],
      "id_str" : "258069853",
      "id" : 258069853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Y0xkYYG7",
      "expanded_url" : "https:\/\/gemnasium.com\/rubygems\/rubygems.org",
      "display_url" : "gemnasium.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143036222552551424",
  "text" : "Wow, @gemnasiumapp is neat: http:\/\/t.co\/Y0xkYYG7",
  "id" : 143036222552551424,
  "created_at" : "2011-12-03 18:37:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 11, 16 ],
      "id_str" : "20941662",
      "id" : 20941662
    }, {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 17, 28 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 29, 34 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 65, 75 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/lxQxd4uw",
      "expanded_url" : "http:\/\/rubyrogues.com\/031-rr-code-reading\/",
      "display_url" : "rubyrogues.com\/031-rr-code-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143033775255846913",
  "text" : "RubyRogues @JEG2 @joshsusser @avdi do a DRAMATIC LIVE READING of @gemcutter! http:\/\/t.co\/lxQxd4uw Thanks guys!",
  "id" : 143033775255846913,
  "created_at" : "2011-12-03 18:28:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/PC871Efi",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YuYhWlKT",
      "expanded_url" : "http:\/\/rubyrogues.com\/031-rr-code-reading",
      "display_url" : "rubyrogues.com\/031-rr-code-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143033297218437120",
  "text" : "RT @thoughtbot: Fun episode of Ruby Rogues podcast this week: read http:\/\/t.co\/PC871Efi source in your editor along w\/ panel. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/PC871Efi",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      }, {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/YuYhWlKT",
        "expanded_url" : "http:\/\/rubyrogues.com\/031-rr-code-reading",
        "display_url" : "rubyrogues.com\/031-rr-code-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "143009206247759872",
    "text" : "Fun episode of Ruby Rogues podcast this week: read http:\/\/t.co\/PC871Efi source in your editor along w\/ panel. http:\/\/t.co\/YuYhWlKT",
    "id" : 143009206247759872,
    "created_at" : "2011-12-03 16:50:26 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 143033297218437120,
  "created_at" : "2011-12-03 18:26:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/gVDAAtzk",
      "expanded_url" : "https:\/\/path.com\/p\/3bgeRs",
      "display_url" : "path.com\/p\/3bgeRs"
    } ]
  },
  "geo" : { },
  "id_str" : "143000785289097216",
  "text" : "So muddy. http:\/\/t.co\/gVDAAtzk",
  "id" : 143000785289097216,
  "created_at" : "2011-12-03 16:16:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142788680753491968",
  "text" : "I don't like Spot Coffee's coffee, and this makes me sad.",
  "id" : 142788680753491968,
  "created_at" : "2011-12-03 02:14:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142778995484798976",
  "text" : "Had beef tongue tacos. \u00A1DELICIOSO!",
  "id" : 142778995484798976,
  "created_at" : "2011-12-03 01:35:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joan",
      "screen_name" : "joanofdark",
      "indices" : [ 0, 11 ],
      "id_str" : "12734002",
      "id" : 12734002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142776058494726145",
  "geo" : { },
  "id_str" : "142778683986415616",
  "in_reply_to_user_id" : 12734002,
  "text" : "@joanofdark he looks huge.",
  "id" : 142778683986415616,
  "in_reply_to_status_id" : 142776058494726145,
  "created_at" : "2011-12-03 01:34:25 +0000",
  "in_reply_to_screen_name" : "joanofdark",
  "in_reply_to_user_id_str" : "12734002",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142770947965988864",
  "text" : "Already glad I didn't go the Sabres game. What a massacre already.",
  "id" : 142770947965988864,
  "created_at" : "2011-12-03 01:03:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142765630733549570",
  "geo" : { },
  "id_str" : "142769732637036544",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety my place is a 10 min walk away. PLZ K THX",
  "id" : 142769732637036544,
  "in_reply_to_status_id" : 142765630733549570,
  "created_at" : "2011-12-03 00:58:51 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/VokmVP6C",
      "expanded_url" : "https:\/\/path.com\/p\/hsQyM",
      "display_url" : "path.com\/p\/hsQyM"
    } ]
  },
  "geo" : { },
  "id_str" : "142765354148564993",
  "text" : "Best seat in the house! http:\/\/t.co\/VokmVP6C",
  "id" : 142765354148564993,
  "created_at" : "2011-12-03 00:41:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142762747749335040",
  "text" : "New years at Blue Monk, $120 and full open bar. Tempting!",
  "id" : 142762747749335040,
  "created_at" : "2011-12-03 00:31:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chap Ambrose",
      "screen_name" : "chapambrose",
      "indices" : [ 0, 12 ],
      "id_str" : "10978282",
      "id" : 10978282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142760882538160128",
  "geo" : { },
  "id_str" : "142762260434128900",
  "in_reply_to_user_id" : 10978282,
  "text" : "@chapambrose it's called drunk",
  "id" : 142762260434128900,
  "in_reply_to_status_id" : 142760882538160128,
  "created_at" : "2011-12-03 00:29:09 +0000",
  "in_reply_to_screen_name" : "chapambrose",
  "in_reply_to_user_id_str" : "10978282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142747633730068480",
  "geo" : { },
  "id_str" : "142747886621425664",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove let's make it a solid 15, couldn't hurt.",
  "id" : 142747886621425664,
  "in_reply_to_status_id" : 142747633730068480,
  "created_at" : "2011-12-02 23:32:02 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Lindsay",
      "screen_name" : "ejlindsay",
      "indices" : [ 0, 10 ],
      "id_str" : "90351184",
      "id" : 90351184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142745214786867200",
  "geo" : { },
  "id_str" : "142745759312388097",
  "in_reply_to_user_id" : 90351184,
  "text" : "@ejlindsay lol at \"dude bro taste\"",
  "id" : 142745759312388097,
  "in_reply_to_status_id" : 142745214786867200,
  "created_at" : "2011-12-02 23:23:35 +0000",
  "in_reply_to_screen_name" : "ejlindsay",
  "in_reply_to_user_id_str" : "90351184",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142694627760283648",
  "geo" : { },
  "id_str" : "142698318999465985",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik done",
  "id" : 142698318999465985,
  "in_reply_to_status_id" : 142694627760283648,
  "created_at" : "2011-12-02 20:15:05 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142477829093855232",
  "geo" : { },
  "id_str" : "142613040045625344",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser this problem doesn't bother me. It's one config change and that's it, don't we have more interesting problems to solve?",
  "id" : 142613040045625344,
  "in_reply_to_status_id" : 142477829093855232,
  "created_at" : "2011-12-02 14:36:13 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142607579292512256",
  "geo" : { },
  "id_str" : "142607866430357504",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy that Z was not intentional",
  "id" : 142607866430357504,
  "in_reply_to_status_id" : 142607579292512256,
  "created_at" : "2011-12-02 14:15:39 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142607408894722048",
  "text" : "Warm oatmeal + fresh granola = craZy delicious !",
  "id" : 142607408894722048,
  "created_at" : "2011-12-02 14:13:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Cade",
      "screen_name" : "cadeparade",
      "indices" : [ 0, 11 ],
      "id_str" : "426455861",
      "id" : 426455861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142514168640184320",
  "geo" : { },
  "id_str" : "142581514515914753",
  "in_reply_to_user_id" : 426455861,
  "text" : "@cadeparade yay!!!",
  "id" : 142581514515914753,
  "in_reply_to_status_id" : 142514168640184320,
  "created_at" : "2011-12-02 12:30:56 +0000",
  "in_reply_to_screen_name" : "cadeparade",
  "in_reply_to_user_id_str" : "426455861",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142435382393438209",
  "geo" : { },
  "id_str" : "142438661311561728",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape still working on recall with ours. Huskies suck at it.",
  "id" : 142438661311561728,
  "in_reply_to_status_id" : 142435382393438209,
  "created_at" : "2011-12-02 03:03:17 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142356558121140225",
  "geo" : { },
  "id_str" : "142363103366094849",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr ugh didn't mean to retweet. thoughtbot is alive and well, and kicking ass.",
  "id" : 142363103366094849,
  "in_reply_to_status_id" : 142356558121140225,
  "created_at" : "2011-12-01 22:03:03 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/TroXJd2r",
      "expanded_url" : "http:\/\/www.cyriak.co.uk\/gifs\/titch.gif",
      "display_url" : "cyriak.co.uk\/gifs\/titch.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "142361796085415936",
  "text" : "Current status: http:\/\/t.co\/TroXJd2r",
  "id" : 142361796085415936,
  "created_at" : "2011-12-01 21:57:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142316983973720064",
  "geo" : { },
  "id_str" : "142317132787613697",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey SUDDEN JIMMY JOHN'S CRAVING ATTACK",
  "id" : 142317132787613697,
  "in_reply_to_status_id" : 142316983973720064,
  "created_at" : "2011-12-01 19:00:23 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142313262321643521",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape your comment is too bitter",
  "id" : 142313262321643521,
  "created_at" : "2011-12-01 18:45:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/8T4A3IDT",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3049-we-welcome-nick-quaranto-to-37signals",
      "display_url" : "37signals.com\/svn\/posts\/3049\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142296620371935233",
  "text" : "It's official! http:\/\/t.co\/8T4A3IDT",
  "id" : 142296620371935233,
  "created_at" : "2011-12-01 17:38:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/LXxF079R",
      "expanded_url" : "http:\/\/www.theblaze.com\/stories\/adam-carolla-breaks-down-occupy-movement-fking-self-entitled-monsters\/",
      "display_url" : "theblaze.com\/stories\/adam-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142284856494268416",
  "text" : "The Ace Man breaks down #OWS. Yep. http:\/\/t.co\/LXxF079R",
  "id" : 142284856494268416,
  "created_at" : "2011-12-01 16:52:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/eAlMeTk8",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/368",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142257345441972224",
  "text" : "RT @gemcutter: Our daily download counts are off, known issue. Will try to fix tonight, sorry folks. http:\/\/t.co\/eAlMeTk8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/eAlMeTk8",
        "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems.org\/issues\/368",
        "display_url" : "github.com\/rubygems\/rubyg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "142257312587972609",
    "text" : "Our daily download counts are off, known issue. Will try to fix tonight, sorry folks. http:\/\/t.co\/eAlMeTk8",
    "id" : 142257312587972609,
    "created_at" : "2011-12-01 15:02:40 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 142257345441972224,
  "created_at" : "2011-12-01 15:02:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/tnNQlvJu",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oiXaT_1I-vw",
      "display_url" : "youtube.com\/watch?v=oiXaT_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142255342150098944",
  "text" : "Current status: http:\/\/t.co\/tnNQlvJu",
  "id" : 142255342150098944,
  "created_at" : "2011-12-01 14:54:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/hTxvOtUc",
      "expanded_url" : "http:\/\/path.com\/p\/3IoDmX",
      "display_url" : "path.com\/p\/3IoDmX"
    } ]
  },
  "geo" : { },
  "id_str" : "142242278201761792",
  "text" : "Possibly the lamest tug battle ever. http:\/\/t.co\/hTxvOtUc",
  "id" : 142242278201761792,
  "created_at" : "2011-12-01 14:02:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29366681621",
  "text" : "Happy Movember!",
  "id" : 29366681621,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Josh",
      "screen_name" : "joshkalderimis",
      "indices" : [ 0, 15 ],
      "id_str" : "628398860",
      "id" : 628398860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29366964192",
  "geo" : { },
  "id_str" : "29367547197",
  "in_reply_to_user_id" : 16601619,
  "text" : "@joshkalderimis bump your dynos!",
  "id" : 29367547197,
  "in_reply_to_status_id" : 29366964192,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "j2h",
  "in_reply_to_user_id_str" : "16601619",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29371358297",
  "text" : "New personal single high score for one WordFeud turn: 118 points. @ablissfulgal not amused. (Play qrush if you're up for a challenge!)",
  "id" : 29371358297,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 0, 13 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29382576064",
  "geo" : { },
  "id_str" : "29383105330",
  "in_reply_to_user_id" : 14766954,
  "text" : "@derickbailey woo! congrats! welcome to the dark side :)",
  "id" : 29383105330,
  "in_reply_to_status_id" : 29382576064,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "derickbailey",
  "in_reply_to_user_id_str" : "14766954",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 22, 33 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29393628841",
  "text" : "@aaronmgough oh nice. @thoughtbot hackfest is tomorrow, will take a look!",
  "id" : 29393628841,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    }, {
      "name" : "David Chelimsky",
      "screen_name" : "dchelimsky",
      "indices" : [ 75, 86 ],
      "id_str" : "14107142",
      "id" : 14107142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29414862173",
  "geo" : { },
  "id_str" : "29415124393",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg you have to put rspec in your development and test bundle group. @dchelimsky had a blog post about this",
  "id" : 29415124393,
  "in_reply_to_status_id" : 29414862173,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29418990249",
  "geo" : { },
  "id_str" : "29419115910",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel all of rspec is like that. Embrace it. Or use test\/unit.",
  "id" : 29419115910,
  "in_reply_to_status_id" : 29418990249,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29302202371",
  "geo" : { },
  "id_str" : "29302726087",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv KARATE CHOP FIGHT",
  "id" : 29302726087,
  "in_reply_to_status_id" : 29302202371,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/yfrog.com\" rel=\"nofollow\"\u003EYfrog\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29138493765",
  "text" : "Part of my dad's birthday present. Couldn't resist. http:\/\/yfrog.com\/jcy8gj",
  "id" : 29138493765,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SendGrid",
      "screen_name" : "SendGrid",
      "indices" : [ 5, 14 ],
      "id_str" : "42126617",
      "id" : 42126617
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 24, 31 ],
      "id_str" : "10257182",
      "id" : 10257182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29154272784",
  "text" : "Free @sendgrid addon on @heroku just *works*. No configuration. So good.",
  "id" : 29154272784,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29158849318",
  "text" : "Holy crap, I think I've stumbled upon a valid use case for Treetop....it would be so much better than writing a ton of regexps...",
  "id" : 29158849318,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 9, 21 ],
      "id_str" : "5716862",
      "id" : 5716862
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 22, 34 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29162011753",
  "geo" : { },
  "id_str" : "29162194911",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @tristandunn @techpickles A++++",
  "id" : 29162194911,
  "in_reply_to_status_id" : 29162011753,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29204267891",
  "text" : "unix beard +1! (echo -en \"INFO\\r\\n\"; sleep 0.1) | nc localhost $port | grep version | cut -d: -f2 | tr -d '\\r'",
  "id" : 29204267891,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 32, 42 ],
      "id_str" : "116526817",
      "id" : 116526817
    }, {
      "name" : "Eric Lutley",
      "screen_name" : "elutley",
      "indices" : [ 47, 55 ],
      "id_str" : "141385784",
      "id" : 141385784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29078321567",
  "text" : "Still finding it hilarious that @JeffLinse and @elutley are on Twitter. Missed out on quite a few years of hilarious drunk tweets.",
  "id" : 29078321567,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29085056754",
  "geo" : { },
  "id_str" : "29086549711",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss it's just an elaborate hoax. Who wants a db you can't run locally?",
  "id" : 29086549711,
  "in_reply_to_status_id" : 29085056754,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kuchta",
      "screen_name" : "kkuchta",
      "indices" : [ 0, 8 ],
      "id_str" : "19041990",
      "id" : 19041990
    }, {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 9, 19 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29100681718",
  "geo" : { },
  "id_str" : "29100737359",
  "in_reply_to_user_id" : 19041990,
  "text" : "@kkuchta @JeffLinse not even sold in MA dude :[",
  "id" : 29100737359,
  "in_reply_to_status_id" : 29100681718,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kkuchta",
  "in_reply_to_user_id_str" : "19041990",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29117450741",
  "text" : "Vim command of the day - :Sex",
  "id" : 29117450741,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29123447215",
  "geo" : { },
  "id_str" : "29123669467",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie I wish the blue bird plushie came with three little ones.",
  "id" : 29123669467,
  "in_reply_to_status_id" : 29123447215,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29128932855",
  "text" : "Huge bike parade on newbury st...with costumes! Totally stopped traffic.",
  "id" : 29128932855,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29131350414",
  "geo" : { },
  "id_str" : "29131449078",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad what could we do better in the \"your app is fucked\" sector?",
  "id" : 29131449078,
  "in_reply_to_status_id" : 29131350414,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Clark",
      "screen_name" : "RobotDeathSquad",
      "indices" : [ 0, 16 ],
      "id_str" : "637113",
      "id" : 637113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29131514720",
  "geo" : { },
  "id_str" : "29132110162",
  "in_reply_to_user_id" : 637113,
  "text" : "@RobotDeathSquad we show errors\/minute...do you just need it updating via ajax?",
  "id" : 29132110162,
  "in_reply_to_status_id" : 29131514720,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "RobotDeathSquad",
  "in_reply_to_user_id_str" : "637113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29038710995",
  "text" : "DOGGLES. http:\/\/30.media.tumblr.com\/tumblr_lb0sc0Q86k1qa9b8ro1_500.jpg",
  "id" : 29038710995,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 39, 48 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29040482632",
  "text" : "Finally getting a chance to use one of @ubuwaits' buttons. Pumped.",
  "id" : 29040482632,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29052234027",
  "text" : "Story of my night: http:\/\/gist.github.com\/652831",
  "id" : 29052234027,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 0, 12 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29055344550",
  "geo" : { },
  "id_str" : "29055516047",
  "in_reply_to_user_id" : 8828952,
  "text" : "@codeofficer http:\/\/www.youtube.com\/watch?v=Q6bARIaMhCM",
  "id" : 29055516047,
  "in_reply_to_status_id" : 29055344550,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "codeofficer",
  "in_reply_to_user_id_str" : "8828952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29075633495",
  "geo" : { },
  "id_str" : "29077392261",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse dude you're in boston? For how long?",
  "id" : 29077392261,
  "in_reply_to_status_id" : 29075633495,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 3, 11 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 25, 31 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29077426941",
  "text" : "RT @jayunit: Coding with @qrush is the best https:\/\/gist.github.com\/44803e954c2f2278a171",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 12, 18 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29056862126",
    "text" : "Coding with @qrush is the best https:\/\/gist.github.com\/44803e954c2f2278a171",
    "id" : 29056862126,
    "created_at" : "2010-10-29 04:28:33 +0000",
    "user" : {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "protected" : false,
      "id_str" : "14238213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435351938\/jason2_normal.png",
      "id" : 14238213,
      "verified" : false
    }
  },
  "id" : 29077426941,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29077848400",
  "geo" : { },
  "id_str" : "29077914625",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse lame, come back some time. or work at the NERD, holy crap.",
  "id" : 29077914625,
  "in_reply_to_status_id" : 29077848400,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 60, 68 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28941708322",
  "text" : "Redis clustering! http:\/\/bit.ly\/bcLNjc Loving the new logo, @antirez!",
  "id" : 28941708322,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28918015544",
  "geo" : { },
  "id_str" : "28942564880",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule what problems were you seeing? I want to get the indexes into CF again.",
  "id" : 28942564880,
  "in_reply_to_status_id" : 28918015544,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28951857511",
  "text" : "I want to run a ton of background processes (not short lived jobs) using Ruby. Resque's not it...what is?",
  "id" : 28951857511,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28952001611",
  "text" : "Actually http:\/\/github.com\/quirkey\/resque-status might work...",
  "id" : 28952001611,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28952194866",
  "geo" : { },
  "id_str" : "28952301146",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie i'm talking about jobs that could go hours, days. basically just want a long running process, but a lot of them.",
  "id" : 28952301146,
  "in_reply_to_status_id" : 28952194866,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobi L\u00FCtke",
      "screen_name" : "tobi",
      "indices" : [ 0, 5 ],
      "id_str" : "676573",
      "id" : 676573
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 66, 73 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28952264432",
  "geo" : { },
  "id_str" : "28952419300",
  "in_reply_to_user_id" : 676573,
  "text" : "@tobi one ruby process + lockrun per user would work, actually... @lsegal is trying to get me on the jruby train instead for this",
  "id" : 28952419300,
  "in_reply_to_status_id" : 28952264432,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "tobi",
  "in_reply_to_user_id_str" : "676573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Eppstein",
      "screen_name" : "chriseppstein",
      "indices" : [ 0, 14 ],
      "id_str" : "14148091",
      "id" : 14148091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28952184912",
  "geo" : { },
  "id_str" : "28952509054",
  "in_reply_to_user_id" : 14148091,
  "text" : "@chriseppstein yeah but if one times out \/ craps itself it needs to restart...resque seems to be able to do that great",
  "id" : 28952509054,
  "in_reply_to_status_id" : 28952184912,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "chriseppstein",
  "in_reply_to_user_id_str" : "14148091",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28958652946",
  "text" : "I love starting new ideas, sketching them out, getting a new rails app set up, color scheme, logo...then...then...",
  "id" : 28958652946,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28958138535",
  "geo" : { },
  "id_str" : "28958694505",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule CloudFront. We really need a better http req tracker for bundler.",
  "id" : 28958694505,
  "in_reply_to_status_id" : 28958138535,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28958138535",
  "geo" : { },
  "id_str" : "28958732952",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule its probably rubygems itself hoarking on making a crapload of little requests for gemspecs",
  "id" : 28958732952,
  "in_reply_to_status_id" : 28958138535,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28993776332",
  "text" : "Is this a joke? Please tell me it's a joke. http:\/\/www.jasondb.com\/",
  "id" : 28993776332,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29020083635",
  "text" : "Majora's Mask is 10 years old. Let that sink in a little. http:\/\/en.wikipedia.org\/wiki\/The_Legend_of_Zelda:_Majora's_Mask",
  "id" : 29020083635,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29025357637",
  "text" : "Apparently it's Halloween?",
  "id" : 29025357637,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29034502490",
  "text" : "Best costume idea, ever: http:\/\/www.mobilecrunch.com\/wp-content\/uploads\/2010\/10\/Angry-Kids.jpg",
  "id" : 29034502490,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Barron",
      "screen_name" : "rubyist",
      "indices" : [ 3, 11 ],
      "id_str" : "819302",
      "id" : 819302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29035094583",
  "text" : "RT @rubyist: YOUR LIP CAN'T HANDLE THE TRUTH (OF THE MO) http:\/\/us.movember.com\/register\/89968",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29034927596",
    "text" : "YOUR LIP CAN'T HANDLE THE TRUTH (OF THE MO) http:\/\/us.movember.com\/register\/89968",
    "id" : 29034927596,
    "created_at" : "2010-10-28 23:43:14 +0000",
    "user" : {
      "name" : "Scott Barron",
      "screen_name" : "rubyist",
      "protected" : false,
      "id_str" : "819302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518429960935985152\/WUXpq_zk_normal.jpeg",
      "id" : 819302,
      "verified" : false
    }
  },
  "id" : 29035094583,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geeks With Balls",
      "screen_name" : "geekswithballs",
      "indices" : [ 19, 34 ],
      "id_str" : "199074313",
      "id" : 199074313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29035148428",
  "text" : "Who else is in for @geekswithballs? :\u007B",
  "id" : 29035148428,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Etheredge",
      "screen_name" : "JustinEtheredge",
      "indices" : [ 0, 16 ],
      "id_str" : "10165302",
      "id" : 10165302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28840715736",
  "geo" : { },
  "id_str" : "28843535002",
  "in_reply_to_user_id" : 10165302,
  "text" : "@JustinEtheredge feature branches. Have CI build master, keep it green. Rebase\/squash branches before merging.",
  "id" : 28843535002,
  "in_reply_to_status_id" : 28840715736,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustinEtheredge",
  "in_reply_to_user_id_str" : "10165302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Potier \u24CC",
      "screen_name" : "BoiteAWeb",
      "indices" : [ 0, 10 ],
      "id_str" : "133325904",
      "id" : 133325904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28821146267",
  "geo" : { },
  "id_str" : "28846087337",
  "in_reply_to_user_id" : 133325904,
  "text" : "@BoiteAWeb will deploy a fix tonight for that. would have been a nicer gesture to DM me instead, but thanks for finding it.",
  "id" : 28846087337,
  "in_reply_to_status_id" : 28821146267,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "BoiteAWeb",
  "in_reply_to_user_id_str" : "133325904",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28847332190",
  "geo" : { },
  "id_str" : "28847395240",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith try out g? sometime :P",
  "id" : 28847395240,
  "in_reply_to_status_id" : 28847332190,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28848232331",
  "geo" : { },
  "id_str" : "28848565539",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox what? i don't understand native development at all.",
  "id" : 28848565539,
  "in_reply_to_status_id" : 28848232331,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Potier \u24CC",
      "screen_name" : "BoiteAWeb",
      "indices" : [ 0, 10 ],
      "id_str" : "133325904",
      "id" : 133325904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28821146267",
  "geo" : { },
  "id_str" : "28848618933",
  "in_reply_to_user_id" : 133325904,
  "text" : "@BoiteAWeb fixed.",
  "id" : 28848618933,
  "in_reply_to_status_id" : 28821146267,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "BoiteAWeb",
  "in_reply_to_user_id_str" : "133325904",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 31, 40 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28880558791",
  "text" : "Awesome slide deck, behind the @rubygems: http:\/\/is.gd\/gma5l TL;DR: we need mirrors!",
  "id" : 28880558791,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 10, 18 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28880674702",
  "geo" : { },
  "id_str" : "28881033728",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage @sikachu thanks, but the bigger problem is building it in while not losing instant deployment, etc. check out that slide deck.",
  "id" : 28881033728,
  "in_reply_to_status_id" : 28880674702,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28881415153",
  "geo" : { },
  "id_str" : "28881536362",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu we have that with the gem webhook system, the hard part is automating it and making fallback work if rubygems.org is unavailable",
  "id" : 28881536362,
  "in_reply_to_status_id" : 28881415153,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28897021509",
  "text" : "\"Internet Explorer 9 has some exciting new features that other browsers lack.\" really? what features?",
  "id" : 28897021509,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 75, 84 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28903463050",
  "text" : "Squashed the initial commit of a repo today for the first time. Deserves a @gitready tip. http:\/\/is.gd\/gmB0I",
  "id" : 28903463050,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28924134344",
  "geo" : { },
  "id_str" : "28924333006",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh \/play vuvuzela",
  "id" : 28924333006,
  "in_reply_to_status_id" : 28924134344,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Pollard",
      "screen_name" : "nfluxx",
      "indices" : [ 0, 7 ],
      "id_str" : "19468773",
      "id" : 19468773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28923687947",
  "geo" : { },
  "id_str" : "28926680708",
  "in_reply_to_user_id" : 19468773,
  "text" : "@nfluxx that's the number of times that .gem has been accessed...what else are you wondering about? :)",
  "id" : 28926680708,
  "in_reply_to_status_id" : 28923687947,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "nfluxx",
  "in_reply_to_user_id_str" : "19468773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Pollard",
      "screen_name" : "nfluxx",
      "indices" : [ 0, 7 ],
      "id_str" : "19468773",
      "id" : 19468773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28926915089",
  "geo" : { },
  "id_str" : "28928306150",
  "in_reply_to_user_id" : 19468773,
  "text" : "@nfluxx mirrors are combing the site all the time too.",
  "id" : 28928306150,
  "in_reply_to_status_id" : 28926915089,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "nfluxx",
  "in_reply_to_user_id_str" : "19468773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28749633616",
  "geo" : { },
  "id_str" : "28751328026",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse dude, go home.",
  "id" : 28751328026,
  "in_reply_to_status_id" : 28749633616,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28792810172",
  "geo" : { },
  "id_str" : "28797145544",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy maybe i'm behind here, could you shoot me an email and\/or to the google group about your plan?",
  "id" : 28797145544,
  "in_reply_to_status_id" : 28792810172,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28798965878",
  "text" : "RT @ra66i: all told, there's &gt;60G of data in .gem files (when expanded), up on rubygems.org. It's 21G as .gem files.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28792441065",
    "text" : "all told, there's &gt;60G of data in .gem files (when expanded), up on rubygems.org. It's 21G as .gem files.",
    "id" : 28792441065,
    "created_at" : "2010-10-26 13:50:50 +0000",
    "user" : {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "protected" : false,
      "id_str" : "15359408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3388593743\/5530c82013709c3922ef8f947092b623_normal.jpeg",
      "id" : 15359408,
      "verified" : false
    }
  },
  "id" : 28798965878,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28808936345",
  "text" : "I sometimes wish that email worked more like twitter. Short, sweet, and it all gets lost in the mix anyway.",
  "id" : 28808936345,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan Ensari",
      "screen_name" : "hakanensari",
      "indices" : [ 0, 12 ],
      "id_str" : "15325245",
      "id" : 15325245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28677410676",
  "geo" : { },
  "id_str" : "28681255404",
  "in_reply_to_user_id" : 15325245,
  "text" : "@hakanensari set a handle instead, http:\/\/rubygems.org\/profile\/edit",
  "id" : 28681255404,
  "in_reply_to_status_id" : 28677410676,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hakanensari",
  "in_reply_to_user_id_str" : "15325245",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan Ensari",
      "screen_name" : "hakanensari",
      "indices" : [ 0, 12 ],
      "id_str" : "15325245",
      "id" : 15325245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28677410676",
  "geo" : { },
  "id_str" : "28681279735",
  "in_reply_to_user_id" : 15325245,
  "text" : "@hakanensari and yeah we probably should...",
  "id" : 28681279735,
  "in_reply_to_status_id" : 28677410676,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "hakanensari",
  "in_reply_to_user_id_str" : "15325245",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "forza",
      "screen_name" : "rubiii",
      "indices" : [ 0, 7 ],
      "id_str" : "18100029",
      "id" : 18100029
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 49, 59 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28691672421",
  "geo" : { },
  "id_str" : "28704065435",
  "in_reply_to_user_id" : 18100029,
  "text" : "@rubiii that's just how rubygems sorts versions, @gemcutter has nothing to do with it :\/",
  "id" : 28704065435,
  "in_reply_to_status_id" : 28691672421,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiii",
  "in_reply_to_user_id_str" : "18100029",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28726549550",
  "geo" : { },
  "id_str" : "28729290490",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil use the mixins, Marc!",
  "id" : 28729290490,
  "in_reply_to_status_id" : 28726549550,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28734739896",
  "text" : "Adventure Time is so math.",
  "id" : 28734739896,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 15, 27 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28626903768",
  "geo" : { },
  "id_str" : "28627125877",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton @fredyatesiv got into the airport listening to that drive, by the time we got through security they bills'd it up :(",
  "id" : 28627125877,
  "in_reply_to_status_id" : 28626903768,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28628600203",
  "text" : "Windows XP is *everywhere* http:\/\/yfrog.com\/08xo4qj",
  "id" : 28628600203,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 35, 45 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28630767714",
  "text" : "Getting closer to profile pages on @gemcutter. Out of 45000+ users, 6000 own gems, average is 3.47 per. zenspider is the outlier with 149.",
  "id" : 28630767714,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28637540378",
  "text" : "Hi Boston!",
  "id" : 28637540378,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28631196854",
  "geo" : { },
  "id_str" : "28638849410",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase mostly rubyforge imports I presume.",
  "id" : 28638849410,
  "in_reply_to_status_id" : 28631196854,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28558598591",
  "text" : "&gt;&gt; (\"01\"..\"10\").to_a =&gt; [\"01\", \"02\", \"03\", \"04\", \"05\", \"06\", \"07\", \"08\", \"09\", \"10\"]",
  "id" : 28558598591,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28559463512",
  "geo" : { },
  "id_str" : "28559712381",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu home for the weekend!",
  "id" : 28559712381,
  "in_reply_to_status_id" : 28559463512,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28616476427",
  "text" : "9\/3\/11, date secured with @ablissfulgal! MISSION ACCOMPLISHED",
  "id" : 28616476427,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28502722347",
  "text" : "Epic. Wish I could afford it. http:\/\/ycombinator.posterous.com\/y-combinators-original-home-for-sale",
  "id" : 28502722347,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "augustl4j",
      "screen_name" : "augustl",
      "indices" : [ 111, 119 ],
      "id_str" : "870091423",
      "id" : 870091423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28504242505",
  "text" : "Brutal star wars ep 1 review, how did I ever watch this movie? http:\/\/www.youtube.com\/watch?v=FxKtZmQgxrI (via @augustl)",
  "id" : 28504242505,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28504934542",
  "text" : "Part 2 is even better, at least wait until he gets to the basement... http:\/\/www.youtube.com\/watch?v=ZG1AWVLnl48",
  "id" : 28504934542,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28404430840",
  "text" : "Current status: http:\/\/30.media.tumblr.com\/tumblr_lajnpbLUaF1qdoomao1_500.jpg",
  "id" : 28404430840,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 76, 86 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28405065249",
  "text" : "Need to migrate the historical downloads to a zset from a hash in #redis on @gemcutter. Store the date as an integer. http:\/\/is.gd\/gcPaY",
  "id" : 28405065249,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28405209263",
  "geo" : { },
  "id_str" : "28405629085",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie because i want the last 30 days worth of downloads (zrevrange), increment (zincrby), fetch all (zrange)",
  "id" : 28405629085,
  "in_reply_to_status_id" : 28405209263,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28405209263",
  "geo" : { },
  "id_str" : "28405665604",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie could easily figure out the top days for downloads for a given gem\/version too",
  "id" : 28405665604,
  "in_reply_to_status_id" : 28405209263,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28405798784",
  "geo" : { },
  "id_str" : "28405862908",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie not yet, haven't had a need to. there's just a daily hash for each version and rubygem so far",
  "id" : 28405862908,
  "in_reply_to_status_id" : 28405798784,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 40, 51 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28421098161",
  "text" : "Turns out we want to keep it in hashes, @pnoordhuis reminded me of the zipmaps we use to save memory. Also, HMGET will do the job too.",
  "id" : 28421098161,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 100, 110 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28420565885",
  "geo" : { },
  "id_str" : "28421206731",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy looks sweet, would love to see how you're figuring out \"hotness\"...and maybe assimilate into @gemcutter :)",
  "id" : 28421206731,
  "in_reply_to_status_id" : 28420565885,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28406724037",
  "geo" : { },
  "id_str" : "28421663399",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire think a high score list. http:\/\/code.google.com\/p\/redis\/wiki\/SortedSets",
  "id" : 28421663399,
  "in_reply_to_status_id" : 28406724037,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28431403033",
  "text" : "Pearl Street. I love this place. http:\/\/yfrog.com\/c8y4qpj",
  "id" : 28431403033,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28450513764",
  "text" : "SABRES!! Should have got tickets.",
  "id" : 28450513764,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lopez",
      "screen_name" : "brianmario",
      "indices" : [ 0, 11 ],
      "id_str" : "9994542",
      "id" : 9994542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27881761089",
  "geo" : { },
  "id_str" : "28019046782",
  "in_reply_to_user_id" : 9994542,
  "text" : "@brianmario hey, you can't repush gems. If you need a platform gem yanked open up a request at help.rubygems.org for now.",
  "id" : 28019046782,
  "in_reply_to_status_id" : 27881761089,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianmario",
  "in_reply_to_user_id_str" : "9994542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28368439280",
  "text" : "Hi Buffalo!",
  "id" : 28368439280,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28370355890",
  "text" : "Google Maps' live wallpaper set to terrain has been awesome this week. Android ftw.",
  "id" : 28370355890,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Lavena",
      "screen_name" : "luislavena",
      "indices" : [ 0, 11 ],
      "id_str" : "16891327",
      "id" : 16891327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27881327254",
  "geo" : { },
  "id_str" : "27881682541",
  "in_reply_to_user_id" : 16891327,
  "text" : "@luislavena we have patches for it, need to merge asap",
  "id" : 27881682541,
  "in_reply_to_status_id" : 27881327254,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "luislavena",
  "in_reply_to_user_id_str" : "16891327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    }, {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 9, 21 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27891977138",
  "geo" : { },
  "id_str" : "27895432210",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer @techpickles rm ~\/.gem\/credentials or change it to log back in",
  "id" : 27895432210,
  "in_reply_to_status_id" : 27891977138,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27925914545",
  "text" : "North Station feels like such a dump compared to South Station.",
  "id" : 27925914545,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27930166230",
  "text" : "The Rails Rumble effect: http:\/\/rubygems.org\/gems\/pusher\/stats",
  "id" : 27930166230,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27945992586",
  "text" : "Won the battle for this location [http:\/\/bit.ly\/bSI0bE] (@ Amtrak Club Car) http:\/\/4sq.com\/cAyxOy",
  "id" : 27945992586,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27947424884",
  "text" : "Hi NYC!",
  "id" : 27947424884,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27977013085",
  "text" : "Kind of wish I was at the Yanks game. I CAN SAY THAT NOW, I'M NOT IN BOSTON",
  "id" : 27977013085,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YOLO",
      "screen_name" : "lifeinzembla",
      "indices" : [ 0, 13 ],
      "id_str" : "12628512",
      "id" : 12628512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27985607453",
  "geo" : { },
  "id_str" : "27990010043",
  "in_reply_to_user_id" : 12628512,
  "text" : "@lifeinzembla not yet :\/",
  "id" : 27990010043,
  "in_reply_to_status_id" : 27985607453,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "lifeinzembla",
  "in_reply_to_user_id_str" : "12628512",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 0, 9 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27988318573",
  "geo" : { },
  "id_str" : "27990063361",
  "in_reply_to_user_id" : 18637556,
  "text" : "@tbranyen the rails way is the best. Also railscasts.com, railstutorial.org, guides.rubyonrails.org",
  "id" : 27990063361,
  "in_reply_to_status_id" : 27988318573,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "tbranyen",
  "in_reply_to_user_id_str" : "18637556",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 48, 55 ],
      "id_str" : "787595",
      "id" : 787595
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 60, 72 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27784777913",
  "geo" : { },
  "id_str" : "27785489037",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape i am just a grasshopper compared to @Croaky and @tristandunn. learning from the masters.",
  "id" : 27785489037,
  "in_reply_to_status_id" : 27784777913,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27788482169",
  "text" : "Any suggestions on where to register a .it domain? gandi.net requires an EU address, godaddy has a huge fee.",
  "id" : 27788482169,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camille Roux",
      "screen_name" : "CamilleRoux",
      "indices" : [ 0, 12 ],
      "id_str" : "1163191",
      "id" : 1163191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27788736543",
  "geo" : { },
  "id_str" : "27788951664",
  "in_reply_to_user_id" : 1163191,
  "text" : "@camilleroux Europe only.",
  "id" : 27788951664,
  "in_reply_to_status_id" : 27788736543,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "CamilleRoux",
  "in_reply_to_user_id_str" : "1163191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Lerche",
      "screen_name" : "carllerche",
      "indices" : [ 0, 11 ],
      "id_str" : "3763061",
      "id" : 3763061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27807195857",
  "geo" : { },
  "id_str" : "27826540432",
  "in_reply_to_user_id" : 3763061,
  "text" : "@carllerche it sounds so sad",
  "id" : 27826540432,
  "in_reply_to_status_id" : 27807195857,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "carllerche",
  "in_reply_to_user_id_str" : "3763061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comte Anthony Eden",
      "screen_name" : "aeden",
      "indices" : [ 0, 6 ],
      "id_str" : "18673",
      "id" : 18673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27840299208",
  "geo" : { },
  "id_str" : "27843961037",
  "in_reply_to_user_id" : 18673,
  "text" : "@aeden yeah, it's really high traffic though. Maybe we should put a link in the footer to it.",
  "id" : 27843961037,
  "in_reply_to_status_id" : 27840299208,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "aeden",
  "in_reply_to_user_id_str" : "18673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27846934667",
  "geo" : { },
  "id_str" : "27848274572",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic they use that newfangled ZIP format to distribute code examples, I need to download WinRAR or something.",
  "id" : 27848274572,
  "in_reply_to_status_id" : 27846934667,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthie BenDor",
      "screen_name" : "unruthless",
      "indices" : [ 0, 11 ],
      "id_str" : "12668332",
      "id" : 12668332
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 38, 49 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Sarah Allen",
      "screen_name" : "ultrasaurus",
      "indices" : [ 127, 139 ],
      "id_str" : "13368452",
      "id" : 13368452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27858139846",
  "geo" : { },
  "id_str" : "27858897561",
  "in_reply_to_user_id" : 12668332,
  "text" : "@unruthless it's at backchannelmedia, @thoughtbot hosts the hackfest on the first tuesday of the month. http:\/\/is.gd\/g8wfd \/cc @ultrasaurus",
  "id" : 27858897561,
  "in_reply_to_status_id" : 27858139846,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "unruthless",
  "in_reply_to_user_id_str" : "12668332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27861791694",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg why isn't your gem article on http:\/\/guides.rubyonrails.org yet? Also, let's write one on ActiveModel.",
  "id" : 27861791694,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27689057726",
  "geo" : { },
  "id_str" : "27690101371",
  "in_reply_to_user_id" : 26840419,
  "text" : "@rkstack1112 dude you need to get out of Idaho more often",
  "id" : 27690101371,
  "in_reply_to_status_id" : 27689057726,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "richardkstack",
  "in_reply_to_user_id_str" : "26840419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27696940128",
  "geo" : { },
  "id_str" : "27697368917",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic your table sucks, I can't sign in and your forgot password page 500's",
  "id" : 27697368917,
  "in_reply_to_status_id" : 27696940128,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27699004098",
  "geo" : { },
  "id_str" : "27699755299",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza confused, this is normal though :) jump on #redis on freenode.",
  "id" : 27699755299,
  "in_reply_to_status_id" : 27699004098,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Etheredge",
      "screen_name" : "JustinEtheredge",
      "indices" : [ 0, 16 ],
      "id_str" : "10165302",
      "id" : 10165302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27706544200",
  "geo" : { },
  "id_str" : "27725442446",
  "in_reply_to_user_id" : 10165302,
  "text" : "@JustinEtheredge great blog post, really glad to see more .net folks joining the dark side :) if you need any help feel free to bug me.",
  "id" : 27725442446,
  "in_reply_to_status_id" : 27706544200,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustinEtheredge",
  "in_reply_to_user_id_str" : "10165302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27736451306",
  "geo" : { },
  "id_str" : "27736480488",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger hit me up",
  "id" : 27736480488,
  "in_reply_to_status_id" : 27736451306,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27740169171",
  "text" : "I really don't get Quora.",
  "id" : 27740169171,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27752775425",
  "geo" : { },
  "id_str" : "27752843394",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer jeweler is mostly a generator for me now. gemspecs weren't the big sell anyway, it was just a nice feature",
  "id" : 27752843394,
  "in_reply_to_status_id" : 27752775425,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul smith",
      "screen_name" : "paulsmith",
      "indices" : [ 34, 44 ],
      "id_str" : "4578",
      "id" : 4578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27759948501",
  "text" : "Redis internals deep dive. Bravo, @paulsmith. http:\/\/www.pauladamsmith.com\/articles\/redis_under_the_hood.html",
  "id" : 27759948501,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27763302366",
  "text" : "Current status: http:\/\/is.gd\/g7a8F",
  "id" : 27763302366,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Rendle",
      "screen_name" : "markrendle",
      "indices" : [ 0, 11 ],
      "id_str" : "21576088",
      "id" : 21576088
    }, {
      "name" : "Ray Booysen",
      "screen_name" : "raybooysen",
      "indices" : [ 12, 23 ],
      "id_str" : "57593",
      "id" : 57593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27763949354",
  "geo" : { },
  "id_str" : "27764056020",
  "in_reply_to_user_id" : 21576088,
  "text" : "@markrendle @raybooysen is there anything we can help out with? :)",
  "id" : 27764056020,
  "in_reply_to_status_id" : 27763949354,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "markrendle",
  "in_reply_to_user_id_str" : "21576088",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Irish",
      "screen_name" : "paul_irish",
      "indices" : [ 0, 11 ],
      "id_str" : "1671811",
      "id" : 1671811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27661860208",
  "geo" : { },
  "id_str" : "27662135570",
  "in_reply_to_user_id" : 1671811,
  "text" : "@paul_irish BOOM",
  "id" : 27662135570,
  "in_reply_to_status_id" : 27661860208,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "paul_irish",
  "in_reply_to_user_id_str" : "1671811",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27674268158",
  "geo" : { },
  "id_str" : "27674299690",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek where?",
  "id" : 27674299690,
  "in_reply_to_status_id" : 27674268158,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27674674097",
  "text" : "http:\/\/rumbledash.heroku.com\/ should be fun to watch in the next few hours!",
  "id" : 27674674097,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 58, 68 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27682431607",
  "text" : "Played around with http:\/\/g.raphaeljs.com, coming soon to @gemcutter... http:\/\/is.gd\/g60g3",
  "id" : 27682431607,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27637992495",
  "text" : "Heading out to #jqcon again! A bit late.",
  "id" : 27637992495,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27644873495",
  "text" : "Arrived at #jqcon day 2!",
  "id" : 27644873495,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27645673149",
  "text" : "I don't care how cool couchdb is, exposing your db straight out to the web is such a bad idea. #jqcon",
  "id" : 27645673149,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27659512634",
  "text" : "\"set relativenumber\" in vim is fucking awesome.",
  "id" : 27659512634,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27660592836",
  "text" : "Does anyone actually use hCard anymore?",
  "id" : 27660592836,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Swedberg",
      "screen_name" : "kswedberg",
      "indices" : [ 6, 16 ],
      "id_str" : "10950672",
      "id" : 10950672
    }, {
      "name" : "Paul Irish",
      "screen_name" : "paul_irish",
      "indices" : [ 77, 88 ],
      "id_str" : "1671811",
      "id" : 1671811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "element",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "jqcon",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27661078715",
  "text" : "Damn. @kswedberg suggests $(\"#element\").fadeToggle() during his #jqcon talk, @paul_irish bangs it out before it's over. http:\/\/is.gd\/g5LiD",
  "id" : 27661078715,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492130491",
  "text" : "LET'S GET READY TO RUMMMMMMBLE",
  "id" : 27492130491,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo Jeanes",
      "screen_name" : "bjeanes",
      "indices" : [ 0, 8 ],
      "id_str" : "13141092",
      "id" : 13141092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27488932278",
  "geo" : { },
  "id_str" : "27493745147",
  "in_reply_to_user_id" : 13141092,
  "text" : "@bjeanes yikes. did it go through? maybe s3 is being slow.",
  "id" : 27493745147,
  "in_reply_to_status_id" : 27488932278,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "bjeanes",
  "in_reply_to_user_id_str" : "13141092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqueryconf",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27501227882",
  "text" : "Is there an easier way to get to the hotel from the Blue Line tomorrow for #jqueryconf?",
  "id" : 27501227882,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bo Jeanes",
      "screen_name" : "bjeanes",
      "indices" : [ 0, 8 ],
      "id_str" : "13141092",
      "id" : 13141092
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 9, 15 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Tom Copeland",
      "screen_name" : "tcopeland",
      "indices" : [ 76, 86 ],
      "id_str" : "15031577",
      "id" : 15031577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27494110799",
  "geo" : { },
  "id_str" : "27501386406",
  "in_reply_to_user_id" : 13141092,
  "text" : "@bjeanes @drnic how did that even work? I thought we capped at 10-15MB. \/cc @tcopeland",
  "id" : 27501386406,
  "in_reply_to_status_id" : 27494110799,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "bjeanes",
  "in_reply_to_user_id_str" : "13141092",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3065\uFF61\u25D5\u203F\u203F\u25D5\uFF61)\u3065",
      "screen_name" : "ladyfox14",
      "indices" : [ 0, 10 ],
      "id_str" : "7795202",
      "id" : 7795202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27502494692",
  "geo" : { },
  "id_str" : "27505348987",
  "in_reply_to_user_id" : 7795202,
  "text" : "@ladyfox14 at home? :)",
  "id" : 27505348987,
  "in_reply_to_status_id" : 27502494692,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ladyfox14",
  "in_reply_to_user_id_str" : "7795202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27502041402",
  "geo" : { },
  "id_str" : "27505378886",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic D:",
  "id" : 27505378886,
  "in_reply_to_status_id" : 27502041402,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27514157164",
  "geo" : { },
  "id_str" : "27533558529",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella gem mirrors.",
  "id" : 27533558529,
  "in_reply_to_status_id" : 27514157164,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqueryconf",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27533704245",
  "text" : "Earliest Saturday yet since I've moved to Boston for #jqueryconf.",
  "id" : 27533704245,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27543911681",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats where are you at?",
  "id" : 27543911681,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27545350137",
  "text" : "Holy crap, this is a cool visualization of the Rails Rumble. http:\/\/rumbledash.heroku.com\/",
  "id" : 27545350137,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27552498672",
  "text" : "Starting to feel that data-* HTML attributes will have the same smell as all upcase &lt;HTML&gt; elements in a few years.",
  "id" : 27552498672,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27568748310",
  "text" : "&lt;style contenteditable=\"\"&gt; just blew my mind. #jqcon",
  "id" : 27568748310,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "wolax",
      "indices" : [ 23, 29 ],
      "id_str" : "8029562",
      "id" : 8029562
    }, {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 31, 43 ],
      "id_str" : "5716862",
      "id" : 5716862
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 45, 56 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27410524815",
  "text" : "Awesome night out with @wolax, @tristandunn, @shellscape. Raining doesn't stop them!",
  "id" : 27410524815,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27435672025",
  "geo" : { },
  "id_str" : "27435896861",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil using JRuby?! Its about time!",
  "id" : 27435896861,
  "in_reply_to_status_id" : 27435672025,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27457168047",
  "text" : "Hilarious nugget of Buffalo Sabres history: http:\/\/en.wikipedia.org\/wiki\/Taro_Tsujimoto",
  "id" : 27457168047,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27465423736",
  "text" : "Angry Birds on the Android Market is FREE. FREEEEEEEEEEEEEEEEEEEE",
  "id" : 27465423736,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Horn",
      "screen_name" : "stevehorn",
      "indices" : [ 0, 10 ],
      "id_str" : "14181366",
      "id" : 14181366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27443599719",
  "geo" : { },
  "id_str" : "27465485615",
  "in_reply_to_user_id" : 14181366,
  "text" : "@stevehorn it's in the version number. how can we do a better job with that?",
  "id" : 27465485615,
  "in_reply_to_status_id" : 27443599719,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevehorn",
  "in_reply_to_user_id_str" : "14181366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27465699026",
  "geo" : { },
  "id_str" : "27465911861",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott are you in town for jqueryconf? you're not far from the robot home base here :)",
  "id" : 27465911861,
  "in_reply_to_status_id" : 27465699026,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Horn",
      "screen_name" : "stevehorn",
      "indices" : [ 0, 10 ],
      "id_str" : "14181366",
      "id" : 14181366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27465758195",
  "geo" : { },
  "id_str" : "27465957664",
  "in_reply_to_user_id" : 14181366,
  "text" : "@stevehorn usually they build \"platform\" specific gems. other than that there's not a good way to tell. we need gem metadata badly.",
  "id" : 27465957664,
  "in_reply_to_status_id" : 27465758195,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevehorn",
  "in_reply_to_user_id_str" : "14181366",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27307642756",
  "text" : "DOTA2. Wow. http:\/\/gameinformer.com\/b\/features\/archive\/2010\/10\/13\/dota-2-announced-details.aspx",
  "id" : 27307642756,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Curtin",
      "screen_name" : "perplexes",
      "indices" : [ 0, 10 ],
      "id_str" : "14678924",
      "id" : 14678924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27307800266",
  "geo" : { },
  "id_str" : "27307891796",
  "in_reply_to_user_id" : 14678924,
  "text" : "@perplexes because Halo came out. And I suck at RTS's.",
  "id" : 27307891796,
  "in_reply_to_status_id" : 27307800266,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "perplexes",
  "in_reply_to_user_id_str" : "14678924",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27307823378",
  "geo" : { },
  "id_str" : "27308075993",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca JUST KLOG IT!",
  "id" : 27308075993,
  "in_reply_to_status_id" : 27307823378,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27308559470",
  "text" : "Vi sitter h\u00E4r i venten och spelar lite DotA 2!  http:\/\/www.youtube.com\/watch?v=0OzWIFX8M-Y",
  "id" : 27308559470,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27309356038",
  "geo" : { },
  "id_str" : "27310465918",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv http:\/\/www.youtuberepeat.com\/watch\/?v=0OzWIFX8M-Y",
  "id" : 27310465918,
  "in_reply_to_status_id" : 27309356038,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 7, 16 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27313272351",
  "text" : "LEGACY @rubygems INDEX FIXED. `gem mirror` works again. ARGHGHH.",
  "id" : 27313272351,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27334259240",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil no mention of testing? Fail.",
  "id" : 27334259240,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27309782569",
  "geo" : { },
  "id_str" : "27335621197",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej i think i just found my halloween costume",
  "id" : 27335621197,
  "in_reply_to_status_id" : 27309782569,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 0, 5 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27356290635",
  "geo" : { },
  "id_str" : "27357798586",
  "in_reply_to_user_id" : 18713,
  "text" : "@al3x yeah I'd love to write Go more. i really like the language, I hope it doesn't go all research-based.",
  "id" : 27357798586,
  "in_reply_to_status_id" : 27356290635,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "al3x",
  "in_reply_to_user_id_str" : "18713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Winkler",
      "screen_name" : "mcmire",
      "indices" : [ 0, 7 ],
      "id_str" : "14453888",
      "id" : 14453888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27360255958",
  "geo" : { },
  "id_str" : "27375494043",
  "in_reply_to_user_id" : 14453888,
  "text" : "@mcmire yeah, i think having rubydoc.info generated for each gem is a huge win. hopefully will push more to write docs!",
  "id" : 27375494043,
  "in_reply_to_status_id" : 27360255958,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mcmire",
  "in_reply_to_user_id_str" : "14453888",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27378715095",
  "text" : "Future lunches are about to get a lot more....piratey http:\/\/yfrog.com\/6b3k6hj",
  "id" : 27378715095,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Richter",
      "screen_name" : "josefrichter",
      "indices" : [ 0, 13 ],
      "id_str" : "15659000",
      "id" : 15659000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27379525153",
  "geo" : { },
  "id_str" : "27379652600",
  "in_reply_to_user_id" : 15659000,
  "text" : "@josefrichter ajax calls, and they're just straight up queries to redis. if you can catch me in #gemcutter on freenode i'll explain more :)",
  "id" : 27379652600,
  "in_reply_to_status_id" : 27379525153,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "josefrichter",
  "in_reply_to_user_id_str" : "15659000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27192576999",
  "text" : "Apparently I'm not smart enough to get a rails generator working through a gem. Weak.",
  "id" : 27192576999,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bostonrb",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27207674420",
  "text" : "As usual, awesome time at #bostonrb. Good talks, great people, delicious beer. Can't go wrong.",
  "id" : 27207674420,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 77, 85 ],
      "id_str" : "12495752",
      "id" : 12495752
    }, {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 90, 100 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27237633646",
  "text" : "Somehow missed this, Ruby5 signed off with some Tom Sawyer last week. Thanks @leshill and @p_elliott! http:\/\/is.gd\/g0czb",
  "id" : 27237633646,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 74, 84 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26754256342",
  "geo" : { },
  "id_str" : "27237732162",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott that was one of the worst issues for the initial gem import on @gemcutter. still don't handle it well for all gems. :\/",
  "id" : 27237732162,
  "in_reply_to_status_id" : 26754256342,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titze Andy",
      "screen_name" : "WebAndy",
      "indices" : [ 0, 8 ],
      "id_str" : "2513057830",
      "id" : 2513057830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27243033250",
  "text" : "@webandy yep, definitely going, see you there!",
  "id" : 27243033250,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27251597385",
  "text" : "How the hell did I refactor anything before writing tests?",
  "id" : 27251597385,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ziromr",
      "screen_name" : "ziromr",
      "indices" : [ 0, 7 ],
      "id_str" : "9689352",
      "id" : 9689352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27279174280",
  "geo" : { },
  "id_str" : "27284666527",
  "in_reply_to_user_id" : 9689352,
  "text" : "@ziromr I'd love to be a part of the discussion. Got a link for me?",
  "id" : 27284666527,
  "in_reply_to_status_id" : 27279174280,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ziromr",
  "in_reply_to_user_id_str" : "9689352",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoang van ninh",
      "screen_name" : "ninh",
      "indices" : [ 0, 5 ],
      "id_str" : "1845099079",
      "id" : 1845099079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27161066487",
  "text" : "@ninh do you guys do usage tracking on all of the images\/assets served from passenger error pages?",
  "id" : 27161066487,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27172495341",
  "text" : "RT @gemcutter: Planning on some downtime tomorrow, 10\/13 around 9:30 EST for a required kernel security upgrade. Stay tuned here for upd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27172383837",
    "text" : "Planning on some downtime tomorrow, 10\/13 around 9:30 EST for a required kernel security upgrade. Stay tuned here for updates.",
    "id" : 27172383837,
    "created_at" : "2010-10-12 20:46:25 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 27172495341,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 56, 66 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27172573857",
  "text" : "Any suggestions for other places to warn of the planned @gemcutter downtime for tomorrow evening? Hitting RubyFlow now.",
  "id" : 27172573857,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 0, 14 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27172676486",
  "geo" : { },
  "id_str" : "27172929384",
  "in_reply_to_user_id" : 8284992,
  "text" : "@jkreeftmeijer hmm, i guess we could hook up https:\/\/github.com\/thoughtbot\/paul_revere",
  "id" : 27172929384,
  "in_reply_to_status_id" : 27172676486,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jkreeftmeijer",
  "in_reply_to_user_id_str" : "8284992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hoang van ninh",
      "screen_name" : "ninh",
      "indices" : [ 0, 5 ],
      "id_str" : "1845099079",
      "id" : 1845099079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27174410916",
  "text" : "@ninh just curious. noticed the images were being served from modrails.com, not localhost :)",
  "id" : 27174410916,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bostonrb",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27182295161",
  "text" : "At #bostonrb!",
  "id" : 27182295161,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 59, 69 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27159802851",
  "text" : "Legacy index (what `gem mirror` uses) hopelessly broken on @gemcutter. Not sure how to fix it. Argh.",
  "id" : 27159802851,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "radamant",
      "screen_name" : "radamant",
      "indices" : [ 0, 9 ],
      "id_str" : "14029822",
      "id" : 14029822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27157089640",
  "geo" : { },
  "id_str" : "27160986277",
  "in_reply_to_user_id" : 14029822,
  "text" : "@radamant new api isn't in yet...must be your lucky day!",
  "id" : 27160986277,
  "in_reply_to_status_id" : 27157089640,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "radamant",
  "in_reply_to_user_id_str" : "14029822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26975376434",
  "geo" : { },
  "id_str" : "26985846908",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs fixed! https:\/\/rubygems.org\/gems\/i18n\/stats",
  "id" : 26985846908,
  "in_reply_to_status_id" : 26975376434,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Relish",
      "screen_name" : "relishapp",
      "indices" : [ 4, 14 ],
      "id_str" : "189057495",
      "id" : 189057495
    }, {
      "name" : "Justin Ko",
      "screen_name" : "justinko",
      "indices" : [ 17, 26 ],
      "id_str" : "23165791",
      "id" : 23165791
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 33, 43 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26986174719",
  "text" : "Hey @relishapp \/ @justinko could @gemcutter's feature suite get a trial?",
  "id" : 26986174719,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Fowler",
      "screen_name" : "davidfowl",
      "indices" : [ 0, 10 ],
      "id_str" : "19481808",
      "id" : 19481808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27008591655",
  "geo" : { },
  "id_str" : "27029183792",
  "in_reply_to_user_id" : 19481808,
  "text" : "@davidfowl there's actually 80,000+ individual gem versions. maybe we should list that number too. :)",
  "id" : 27029183792,
  "in_reply_to_status_id" : 27008591655,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "davidfowl",
  "in_reply_to_user_id_str" : "19481808",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27037633969",
  "geo" : { },
  "id_str" : "27038403272",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez is there any way to get the number of unique ranks for one sorted set? not ZCOUNT (or ZCARD)",
  "id" : 27038403272,
  "in_reply_to_status_id" : 27037633969,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27041023410",
  "geo" : { },
  "id_str" : "27041365831",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez maybe this could be a new command? ZCOUNTRANKS or something. we should discuss in IRC :)",
  "id" : 27041365831,
  "in_reply_to_status_id" : 27041023410,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Pierce",
      "screen_name" : "jonpierce",
      "indices" : [ 0, 10 ],
      "id_str" : "186923",
      "id" : 186923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27055900989",
  "geo" : { },
  "id_str" : "27056137840",
  "in_reply_to_user_id" : 186923,
  "text" : "@jonpierce wow, short notice on that :\/",
  "id" : 27056137840,
  "in_reply_to_status_id" : 27055900989,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jonpierce",
  "in_reply_to_user_id_str" : "186923",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27058921272",
  "geo" : { },
  "id_str" : "27060789313",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv LOL ROFL OMG",
  "id" : 27060789313,
  "in_reply_to_status_id" : 27058921272,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27065879620",
  "geo" : { },
  "id_str" : "27066029027",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman fun, but mind-bendingly hard to test. http:\/\/vowsjs.org and the like are making it easier though.",
  "id" : 27066029027,
  "in_reply_to_status_id" : 27065879620,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian K. Jones",
      "screen_name" : "bkjones",
      "indices" : [ 0, 8 ],
      "id_str" : "7645442",
      "id" : 7645442
    }, {
      "name" : "Jeff Kreeftmeijer",
      "screen_name" : "jkreeftmeijer",
      "indices" : [ 9, 23 ],
      "id_str" : "8284992",
      "id" : 8284992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27054099063",
  "geo" : { },
  "id_str" : "27066973567",
  "in_reply_to_user_id" : 7645442,
  "text" : "@bkjones @jkreeftmeijer our entire team is now comparing different merges in different VCSs to pizza. genius.",
  "id" : 27066973567,
  "in_reply_to_status_id" : 27054099063,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "bkjones",
  "in_reply_to_user_id_str" : "7645442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Stenhouse",
      "screen_name" : "ryanstenhouse",
      "indices" : [ 0, 14 ],
      "id_str" : "9427822",
      "id" : 9427822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27070434082",
  "geo" : { },
  "id_str" : "27071190416",
  "in_reply_to_user_id" : 9427822,
  "text" : "@ryanstenhouse because YAML.load_file is easier than writing a DSL.",
  "id" : 27071190416,
  "in_reply_to_status_id" : 27070434082,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryanstenhouse",
  "in_reply_to_user_id_str" : "9427822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27077804622",
  "geo" : { },
  "id_str" : "27080561626",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler I'm in. mustache.rb.",
  "id" : 27080561626,
  "in_reply_to_status_id" : 27077804622,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26889497255",
  "text" : "Current status: http:\/\/yfrog.com\/jn41864022j",
  "id" : 26889497255,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26893263205",
  "text" : "Ended up with 31 points! http:\/\/yfrog.com\/nbybjdj",
  "id" : 26893263205,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Mongeau",
      "screen_name" : "halogenandtoast",
      "indices" : [ 58, 74 ],
      "id_str" : "15428948",
      "id" : 15428948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26905929005",
  "text" : "Aftermath of game 2, with occupations. 40 points. Lost to @halogenandtoast by 9 points. http:\/\/yfrog.com\/6ggmqwj",
  "id" : 26905929005,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26948678197",
  "text" : "chmod -x chmod http:\/\/www.slideshare.net\/cog\/chmod-x-chmod",
  "id" : 26948678197,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26957488029",
  "geo" : { },
  "id_str" : "26957537998",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella whaaaat. add me, i'm Doctor Q on XBL.",
  "id" : 26957537998,
  "in_reply_to_status_id" : 26957488029,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26959927979",
  "geo" : { },
  "id_str" : "26960582462",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza hell yeah.",
  "id" : 26960582462,
  "in_reply_to_status_id" : 26959927979,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 74, 84 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26971609251",
  "text" : "RT @gemcutter: Gem stats pages now deployed thanks to some hard work from @sprsquish! http:\/\/rubygems.org\/gems\/rake\/stats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Smick",
        "screen_name" : "sprsquish",
        "indices" : [ 59, 69 ],
        "id_str" : "2296675008",
        "id" : 2296675008
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26971485805",
    "text" : "Gem stats pages now deployed thanks to some hard work from @sprsquish! http:\/\/rubygems.org\/gems\/rake\/stats",
    "id" : 26971485805,
    "created_at" : "2010-10-10 21:10:36 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 26971609251,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Smick",
      "screen_name" : "sprsquish",
      "indices" : [ 0, 10 ],
      "id_str" : "2296675008",
      "id" : 2296675008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26971610249",
  "geo" : { },
  "id_str" : "26971774595",
  "in_reply_to_user_id" : 3732061,
  "text" : "@sprsquish that was the easy part! the graph had to have been harder. that being said, the first 5 versions aren't sorted on the overview :\/",
  "id" : 26971774595,
  "in_reply_to_status_id" : 26971610249,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrsprsquish",
  "in_reply_to_user_id_str" : "3732061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Oliveira",
      "screen_name" : "jayroh",
      "indices" : [ 0, 7 ],
      "id_str" : "14114222",
      "id" : 14114222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26972173849",
  "geo" : { },
  "id_str" : "26972347873",
  "in_reply_to_user_id" : 14114222,
  "text" : "@jayroh just gchartrb for now. would love to bring flot in for more curvaceousness",
  "id" : 26972347873,
  "in_reply_to_status_id" : 26972173849,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayroh",
  "in_reply_to_user_id_str" : "14114222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Staudt",
      "screen_name" : "k0raktor",
      "indices" : [ 0, 9 ],
      "id_str" : "35310474",
      "id" : 35310474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26972523110",
  "geo" : { },
  "id_str" : "26972643420",
  "in_reply_to_user_id" : 35310474,
  "text" : "@k0raktor yep, looking into the graph's versions sorting.",
  "id" : 26972643420,
  "in_reply_to_status_id" : 26972523110,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "k0raktor",
  "in_reply_to_user_id_str" : "35310474",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26976991996",
  "text" : "Knowing that Dexter and Deb are married in RL makes Dexter 1000% more creepier.",
  "id" : 26976991996,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26979074661",
  "text" : "RT @gemcutter: Ordering on graph pages fixed! http:\/\/rubygems.org\/gems\/rails\/stats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26978809339",
    "text" : "Ordering on graph pages fixed! http:\/\/rubygems.org\/gems\/rails\/stats",
    "id" : 26978809339,
    "created_at" : "2010-10-10 23:06:06 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 26979074661,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26796984120",
  "text" : "I suck at public transportation. Waited over 10 mins after the bus was supposed to arrive, walked off...saw it, sprinted back, it drives by.",
  "id" : 26796984120,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Art\u016Bras \u0160lajus",
      "screen_name" : "arturaz_",
      "indices" : [ 0, 9 ],
      "id_str" : "200613341",
      "id" : 200613341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26869660643",
  "geo" : { },
  "id_str" : "26875382404",
  "in_reply_to_user_id" : 200613341,
  "text" : "@arturaz_ I just registered a new account successfully. can you try clearing cookies? also crack open an issue at http:\/\/help.rubygems.org",
  "id" : 26875382404,
  "in_reply_to_status_id" : 26869660643,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "arturaz_",
  "in_reply_to_user_id_str" : "200613341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26875657293",
  "text" : "Look at these fucking hipster dinosaurs. http:\/\/www.bite.ca\/bitedaily\/2010\/09\/more-hipster-dinosaurs\/",
  "id" : 26875657293,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 25, 37 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Justin Blake",
      "screen_name" : "blaix",
      "indices" : [ 42, 48 ],
      "id_str" : "8239892",
      "id" : 8239892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26719048323",
  "text" : "Epic WordFeud games with @coreyhaines and @blaix the past few games. Feel free to CHALLENGE me if you have an Android.",
  "id" : 26719048323,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26745869714",
  "geo" : { },
  "id_str" : "26745947805",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim http:\/\/www.youtube.com\/watch?v=6zlViU5PBPY",
  "id" : 26745947805,
  "in_reply_to_status_id" : 26745869714,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26745869714",
  "geo" : { },
  "id_str" : "26746040753",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim baby don't hurt me http:\/\/www.youtube.com\/watch?v=Noq_oR1a0gs&feature=related",
  "id" : 26746040753,
  "in_reply_to_status_id" : 26745869714,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26748448513",
  "text" : "Hey D green line, any time now would be nice.",
  "id" : 26748448513,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26749139762",
  "text" : "A horde of kids just walked onto this train. What's next green line? BRING IT",
  "id" : 26749139762,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 33, 43 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26753793168",
  "text" : "Slow transactions are no fun for @gemcutter. Is there any way to debug this besides randomly adding method tracers? http:\/\/is.gd\/fRnwz",
  "id" : 26753793168,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Imbriaco",
      "screen_name" : "markimbriaco",
      "indices" : [ 0, 13 ],
      "id_str" : "9887162",
      "id" : 9887162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26754315105",
  "geo" : { },
  "id_str" : "26754638071",
  "in_reply_to_user_id" : 9887162,
  "text" : "@markimbriaco i can give you access to this account if you want. they all look like http:\/\/is.gd\/fRobQ",
  "id" : 26754638071,
  "in_reply_to_status_id" : 26754315105,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "markimbriaco",
  "in_reply_to_user_id_str" : "9887162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eaton",
      "screen_name" : "mjeaton",
      "indices" : [ 0, 8 ],
      "id_str" : "6440892",
      "id" : 6440892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26753028490",
  "geo" : { },
  "id_str" : "26754925620",
  "in_reply_to_user_id" : 6440892,
  "text" : "@mjeaton about damn time. if you need any help let me know.",
  "id" : 26754925620,
  "in_reply_to_status_id" : 26753028490,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "mjeaton",
  "in_reply_to_user_id_str" : "6440892",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bocoup",
      "screen_name" : "bocoup",
      "indices" : [ 0, 7 ],
      "id_str" : "98303566",
      "id" : 98303566
    }, {
      "name" : "Tim Branyen",
      "screen_name" : "tbranyen",
      "indices" : [ 8, 17 ],
      "id_str" : "18637556",
      "id" : 18637556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26755190539",
  "geo" : { },
  "id_str" : "26755948219",
  "in_reply_to_user_id" : 98303566,
  "text" : "@bocoup @tbranyen hey congrats! I'll have to stop by the loft sometime.",
  "id" : 26755948219,
  "in_reply_to_status_id" : 26755190539,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "bocoup",
  "in_reply_to_user_id_str" : "98303566",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    }, {
      "name" : "Dan Leveille",
      "screen_name" : "danlev",
      "indices" : [ 10, 17 ],
      "id_str" : "13612732",
      "id" : 13612732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26774790946",
  "geo" : { },
  "id_str" : "26775089251",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold @danlev yeah, seriously. @ablissfulgal has been freaking out about some recent 8 legged visitors.",
  "id" : 26775089251,
  "in_reply_to_status_id" : 26774790946,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 14, 22 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26789118417",
  "geo" : { },
  "id_str" : "26789323712",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie @brynary yeah, I'm not convinced the market is large enough. even less so now that bundler supports git gems",
  "id" : 26789323712,
  "in_reply_to_status_id" : 26789118417,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26599596512",
  "text" : "A lyrics\/tab site combo that didn't suck and used http:\/\/vexflow.com\/vextab\/ would be awesome.",
  "id" : 26599596512,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 94, 105 ],
      "id_str" : "9238852",
      "id" : 9238852
    }, {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 106, 119 ],
      "id_str" : "9645312",
      "id" : 9645312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26620401562",
  "text" : "Summary of most nupack dissenters\/whiners: http:\/\/bit.ly\/bE5Cox Don't let them bring you down @drusellers @ferventcoder!",
  "id" : 26620401562,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Lang",
      "screen_name" : "matthewlang",
      "indices" : [ 0, 12 ],
      "id_str" : "2578492267",
      "id" : 2578492267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26644000369",
  "text" : "@matthewlang there's also webhooks for more real-time notification https:\/\/rubygems.org\/pages\/gem_docs#webhook",
  "id" : 26644000369,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26654565518",
  "text" : "http:\/\/mrdoob.com\/lab\/javascript\/effects\/ie6\/",
  "id" : 26654565518,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ledbetter",
      "screen_name" : "bri3d",
      "indices" : [ 0, 6 ],
      "id_str" : "15600424",
      "id" : 15600424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26663522317",
  "geo" : { },
  "id_str" : "26669178789",
  "in_reply_to_user_id" : 15600424,
  "text" : "@bri3d yeah, we've got a new endpoint ready to make resolving dependencies go WAY faster. just need it implemented in bundler.",
  "id" : 26669178789,
  "in_reply_to_status_id" : 26663522317,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bri3d",
  "in_reply_to_user_id_str" : "15600424",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 3, 11 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26669288601",
  "text" : "RT @antirez: The Redis Logo Contest voting starts... now! http:\/\/redis.io\/logocontest\/index.php",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26663710400",
    "text" : "The Redis Logo Contest voting starts... now! http:\/\/redis.io\/logocontest\/index.php",
    "id" : 26663710400,
    "created_at" : "2010-10-07 16:28:36 +0000",
    "user" : {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "protected" : false,
      "id_str" : "5813712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461550870648217602\/XjbUS5rb_normal.png",
      "id" : 5813712,
      "verified" : false
    }
  },
  "id" : 26669288601,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26685375064",
  "geo" : { },
  "id_str" : "26685667343",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary yes (the obvious choice). newrelic is invaluable for seeing the current performance and health of the app.",
  "id" : 26685667343,
  "in_reply_to_status_id" : 26685375064,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26689641507",
  "geo" : { },
  "id_str" : "26689763128",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius I'm surprised that thread hasn't been blasted by more stupidity yet. I would feel bad for the poor guy.",
  "id" : 26689763128,
  "in_reply_to_status_id" : 26689641507,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philippe Creux",
      "screen_name" : "pcreux",
      "indices" : [ 0, 7 ],
      "id_str" : "17188408",
      "id" : 17188408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26568499391",
  "geo" : { },
  "id_str" : "26569302378",
  "in_reply_to_user_id" : 17188408,
  "text" : "@pcreux Added a link. Keep rockin!",
  "id" : 26569302378,
  "in_reply_to_status_id" : 26568499391,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "pcreux",
  "in_reply_to_user_id_str" : "17188408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26581269676",
  "text" : "I want to rename \"Pairs\" to \"Attack Squads\". The latter sounds way more badass.",
  "id" : 26581269676,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26593472509",
  "text" : "Persuing the Pregel paper. An OSS implementation could really kick ass.",
  "id" : 26593472509,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26511035660",
  "text" : "NEW AXE ACQUIRED http:\/\/yfrog.com\/4j5dsqj",
  "id" : 26511035660,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26512511645",
  "text" : "For the curious, Pillow.rb was made by @ablissfulgal a few years ago.",
  "id" : 26512511645,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Rada",
      "screen_name" : "ferrous26",
      "indices" : [ 0, 10 ],
      "id_str" : "120339804",
      "id" : 120339804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26520348825",
  "geo" : { },
  "id_str" : "26520782404",
  "in_reply_to_user_id" : 120339804,
  "text" : "@ferrous26 what a timesink that would be. much more fun to just let them all in the fray. :)",
  "id" : 26520782404,
  "in_reply_to_status_id" : 26520348825,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferrous26",
  "in_reply_to_user_id_str" : "120339804",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 0, 13 ],
      "id_str" : "15782607",
      "id" : 15782607
    }, {
      "name" : "nap.tld, ltd.",
      "screen_name" : "zapnap",
      "indices" : [ 20, 27 ],
      "id_str" : "1566201",
      "id" : 1566201
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 32, 39 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26531711757",
  "geo" : { },
  "id_str" : "26546301362",
  "in_reply_to_user_id" : 15782607,
  "text" : "@jordansissel yeah, @zapnap and @lsegal rock for getting that working. I'd love to see more services like that.",
  "id" : 26546301362,
  "in_reply_to_status_id" : 26531711757,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "jordansissel",
  "in_reply_to_user_id_str" : "15782607",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26553116576",
  "text" : "RT @thoughtbot: 2 Ruby tutorials for you to rock out with! http:\/\/is.gd\/fNWmv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26553034308",
    "text" : "2 Ruby tutorials for you to rock out with! http:\/\/is.gd\/fNWmv",
    "id" : 26553034308,
    "created_at" : "2010-10-06 13:53:45 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 26553116576,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 63, 69 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26553189499",
  "text" : "One day, 17 Mighty Tacos. Epic. http:\/\/tacoadventure.com\/ (via @chorn)",
  "id" : 26553189499,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 20, 30 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Rolf Timmermans",
      "screen_name" : "molfie",
      "indices" : [ 69, 76 ],
      "id_str" : "14625997",
      "id" : 14625997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26557037885",
  "text" : "Rails ERD diagrams, @gemcutter featured in the examples. Neat stuff, @molfie! http:\/\/rails-erd.rubyforge.org\/gallery.html",
  "id" : 26557037885,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 4, 17 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "A Curious Mind",
      "screen_name" : "drusellers",
      "indices" : [ 18, 29 ],
      "id_str" : "9238852",
      "id" : 9238852
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 109, 119 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26560493526",
  "text" : "Hey @ferventcoder @drusellers is nupack the end of nuproj? wondering what to do with all of the .net gems on @gemcutter.",
  "id" : 26560493526,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Reynolds",
      "screen_name" : "ferventcoder",
      "indices" : [ 0, 13 ],
      "id_str" : "9645312",
      "id" : 9645312
    }, {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 14, 22 ],
      "id_str" : "768197",
      "id" : 768197
    }, {
      "name" : "Scott Koon",
      "screen_name" : "lazycoder",
      "indices" : [ 24, 34 ],
      "id_str" : "697163",
      "id" : 697163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26568367028",
  "geo" : { },
  "id_str" : "26569003671",
  "in_reply_to_user_id" : 9645312,
  "text" : "@ferventcoder @haacked  @lazycoder no, barely any are. it's a web of trust issue. http:\/\/en.wikipedia.org\/wiki\/Web_of_trust",
  "id" : 26569003671,
  "in_reply_to_status_id" : 26568367028,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ferventcoder",
  "in_reply_to_user_id_str" : "9645312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26408489194",
  "geo" : { },
  "id_str" : "26408668969",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan does it use Array#zip? Used that for the first time legitimately last week, piped it into Hash::[]",
  "id" : 26408668969,
  "in_reply_to_status_id" : 26408489194,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Adam Dymitruk",
      "screen_name" : "adymitruk",
      "indices" : [ 0, 10 ],
      "id_str" : "14196181",
      "id" : 14196181
    }, {
      "name" : "\u041C\u044D\u0440\u0438 \u0441\u0430\u0430\u043A\u044F\u043D",
      "screen_name" : "ArmMer",
      "indices" : [ 11, 18 ],
      "id_str" : "369604063",
      "id" : 369604063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26407916406",
  "geo" : { },
  "id_str" : "26409237355",
  "in_reply_to_user_id" : 14196181,
  "text" : "@adymitruk @armmer s\/git-ready\/gitready. Maybe I should get that .com just in case",
  "id" : 26409237355,
  "in_reply_to_status_id" : 26407916406,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "adymitruk",
  "in_reply_to_user_id_str" : "14196181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26433051782",
  "text" : "Alive.",
  "id" : 26433051782,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26433278431",
  "text" : "Current status: http:\/\/26.media.tumblr.com\/tumblr_l9d1dsXVre1qanlfzo1_500.png",
  "id" : 26433278431,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Chacon",
      "screen_name" : "chacon",
      "indices" : [ 0, 7 ],
      "id_str" : "127583",
      "id" : 127583
    }, {
      "name" : "Joel Spolsky",
      "screen_name" : "spolsky",
      "indices" : [ 70, 78 ],
      "id_str" : "15948437",
      "id" : 15948437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26431783781",
  "geo" : { },
  "id_str" : "26433604687",
  "in_reply_to_user_id" : 127583,
  "text" : "@chacon is there anything else being taught\/discussed besides HG? \/cc @spolsky",
  "id" : 26433604687,
  "in_reply_to_status_id" : 26431783781,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "chacon",
  "in_reply_to_user_id_str" : "127583",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The NEWW Bird",
      "screen_name" : "webcomixweekend",
      "indices" : [ 0, 16 ],
      "id_str" : "20686269",
      "id" : 20686269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26466673795",
  "in_reply_to_user_id" : 20686269,
  "text" : "@webcomixweekend hey, your ticket purchase page should say that the transaction comes through as \"OCTOPUS PIE\" ...definitely a WTF moment",
  "id" : 26466673795,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "webcomixweekend",
  "in_reply_to_user_id_str" : "20686269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26473976877",
  "text" : "WTF apache? http:\/\/img.skitch.com\/20101005-trane8277kyh6w75q2qxci5p75.png",
  "id" : 26473976877,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 2, 12 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Rapha\u00EBl Valyi",
      "screen_name" : "rvalyi",
      "indices" : [ 105, 112 ],
      "id_str" : "39129507",
      "id" : 39129507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26480152071",
  "text" : "A @gemcutter inspired site coming to the OpenERP community. http:\/\/www.loempia.org\/ (thanks for the tip, @rvalyi)",
  "id" : 26480152071,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Goebel",
      "screen_name" : "dreamer3",
      "indices" : [ 0, 9 ],
      "id_str" : "14973933",
      "id" : 14973933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26486038920",
  "geo" : { },
  "id_str" : "26486936054",
  "in_reply_to_user_id" : 14973933,
  "text" : "@dreamer3 is it on github? can we toss it on heroku?",
  "id" : 26486936054,
  "in_reply_to_status_id" : 26486038920,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "dreamer3",
  "in_reply_to_user_id_str" : "14973933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Goebel",
      "screen_name" : "dreamer3",
      "indices" : [ 0, 9 ],
      "id_str" : "14973933",
      "id" : 14973933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26487191335",
  "geo" : { },
  "id_str" : "26487422300",
  "in_reply_to_user_id" : 14973933,
  "text" : "@dreamer3 does it need more than 2 dynos? most of it is cacheable. I can't imagine it would be expensive to run there.",
  "id" : 26487422300,
  "in_reply_to_status_id" : 26487191335,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "dreamer3",
  "in_reply_to_user_id_str" : "14973933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26492007695",
  "text" : "When your signature is longer than the email you sent me (even when your email was several paragraphs), I'm not replying to it.",
  "id" : 26492007695,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Goebel",
      "screen_name" : "dreamer3",
      "indices" : [ 0, 9 ],
      "id_str" : "14973933",
      "id" : 14973933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26488192076",
  "geo" : { },
  "id_str" : "26492063209",
  "in_reply_to_user_id" : 14973933,
  "text" : "@dreamer3 i guess you'll find out quickly how much varnish can handle!",
  "id" : 26492063209,
  "in_reply_to_status_id" : 26488192076,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "dreamer3",
  "in_reply_to_user_id_str" : "14973933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26498171753",
  "geo" : { },
  "id_str" : "26498286473",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit HOLY DUCK FUCK",
  "id" : 26498286473,
  "in_reply_to_status_id" : 26498171753,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eloy Dur\u00E1n",
      "screen_name" : "alloy",
      "indices" : [ 0, 6 ],
      "id_str" : "12459132",
      "id" : 12459132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26264235531",
  "geo" : { },
  "id_str" : "26317908430",
  "in_reply_to_user_id" : 12459132,
  "text" : "@alloy missed ya...tomorrow maybe?",
  "id" : 26317908430,
  "in_reply_to_status_id" : 26264235531,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "alloy",
  "in_reply_to_user_id_str" : "12459132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26331901902",
  "text" : "Extremely lonely with @ablissfulgal on page 40, but it'll fill up fast! http:\/\/www.onemillionpeople.com\/40\/A1\/",
  "id" : 26331901902,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26357019217",
  "text" : "Just got my tickets for NEWW. Excited! http:\/\/webcomicsweekend.com\/",
  "id" : 26357019217,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26358490861",
  "geo" : { },
  "id_str" : "26359727755",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler ooh, I'll pay $30000000 in unmarked bills. Please send your social security number first.",
  "id" : 26359727755,
  "in_reply_to_status_id" : 26358490861,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26360396739",
  "text" : "The T stations' spoken announcements\/reminders sound straight out of Half Life 2. I just need a crowbar.",
  "id" : 26360396739,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Maddox",
      "screen_name" : "patmaddox",
      "indices" : [ 0, 10 ],
      "id_str" : "14955528",
      "id" : 14955528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26393862659",
  "geo" : { },
  "id_str" : "26395014116",
  "in_reply_to_user_id" : 14955528,
  "text" : "@patmaddox EXCUSE ME, SIR",
  "id" : 26395014116,
  "in_reply_to_status_id" : 26393862659,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "patmaddox",
  "in_reply_to_user_id_str" : "14955528",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26403370929",
  "text" : "Train delays coming in and going out of work today. WTF, green line?",
  "id" : 26403370929,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Linse",
      "screen_name" : "JeffLinse",
      "indices" : [ 0, 10 ],
      "id_str" : "116526817",
      "id" : 116526817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26406159881",
  "geo" : { },
  "id_str" : "26406945475",
  "in_reply_to_user_id" : 116526817,
  "text" : "@JeffLinse hi, Jeff. Bored in Seattle?",
  "id" : 26406945475,
  "in_reply_to_status_id" : 26406159881,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "JeffLinse",
  "in_reply_to_user_id_str" : "116526817",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Fletcher",
      "screen_name" : "TimFletcher",
      "indices" : [ 0, 12 ],
      "id_str" : "13395012",
      "id" : 13395012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26207420635",
  "geo" : { },
  "id_str" : "26220219056",
  "in_reply_to_user_id" : 13395012,
  "text" : "@timfletcher yeah, apache had some troubles. If you need any help learning let me know!",
  "id" : 26220219056,
  "in_reply_to_status_id" : 26207420635,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "TimFletcher",
  "in_reply_to_user_id_str" : "13395012",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Lavender",
      "screen_name" : "bhuga",
      "indices" : [ 0, 6 ],
      "id_str" : "15105338",
      "id" : 15105338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26207546425",
  "geo" : { },
  "id_str" : "26220288359",
  "in_reply_to_user_id" : 15105338,
  "text" : "@bhuga you and me both dude. If you have any suggestions or want to help with stability, let me know",
  "id" : 26220288359,
  "in_reply_to_status_id" : 26207546425,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "bhuga",
  "in_reply_to_user_id_str" : "15105338",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Siebel",
      "screen_name" : "StefanSiebel",
      "indices" : [ 0, 13 ],
      "id_str" : "58023077",
      "id" : 58023077
    }, {
      "name" : "Pingdom",
      "screen_name" : "pingdom",
      "indices" : [ 55, 63 ],
      "id_str" : "15674759",
      "id" : 15674759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26207217681",
  "geo" : { },
  "id_str" : "26220356312",
  "in_reply_to_user_id" : 58023077,
  "text" : "@StefanSiebel had some issues with apache, sorry dude. @pingdom alerted us instantly.",
  "id" : 26220356312,
  "in_reply_to_status_id" : 26207217681,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "StefanSiebel",
  "in_reply_to_user_id_str" : "58023077",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Larkowski",
      "screen_name" : "l4rk",
      "indices" : [ 0, 5 ],
      "id_str" : "1940",
      "id" : 1940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26130862085",
  "geo" : { },
  "id_str" : "26138997186",
  "in_reply_to_user_id" : 1940,
  "text" : "@l4rk hell yeah! The concert here in Boston was awesome. Wish I could have seen more.",
  "id" : 26138997186,
  "in_reply_to_status_id" : 26130862085,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "l4rk",
  "in_reply_to_user_id_str" : "1940",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26149553243",
  "geo" : { },
  "id_str" : "26151248546",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect yeah, anything we can do to make the site feel alive is awesome in my book. let me know if you have other ideas.",
  "id" : 26151248546,
  "in_reply_to_status_id" : 26149553243,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 79, 88 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26151275656",
  "text" : "New xbox headset doesn't seem to work. Need to test it tomorrow. Couldn't hear @mittense and company, sadface.",
  "id" : 26151275656,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 8, 18 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 78, 86 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26154523730",
  "text" : "Holy... @gemcutter's redis instance total_commands_processed: 402,025,596 \/cc @antirez",
  "id" : 26154523730,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26154557137",
  "geo" : { },
  "id_str" : "26154656606",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm they're really for two different problem sets, the tools are way different. we can discuss tomorrow in IRC somewhere.",
  "id" : 26154656606,
  "in_reply_to_status_id" : 26154557137,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/screenr.com\" rel=\"nofollow\"\u003EScreenr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 16, 26 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26154997412",
  "text" : "MONITOR log for @gemcutter's redis instance. Would love to visualize this data. http:\/\/screenr.com\/6l4",
  "id" : 26154997412,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "indices" : [ 0, 16 ],
      "id_str" : "14601522",
      "id" : 14601522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26169269650",
  "geo" : { },
  "id_str" : "26177430249",
  "in_reply_to_user_id" : 14601522,
  "text" : "@copiousfreetime sure, let me know!",
  "id" : 26177430249,
  "in_reply_to_status_id" : 26169269650,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "copiousfreetime",
  "in_reply_to_user_id_str" : "14601522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
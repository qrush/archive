Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD",
      "screen_name" : "wuputah",
      "indices" : [ 0, 8 ],
      "id_str" : "14368347",
      "id" : 14368347
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 60, 67 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142034501818785792",
  "geo" : { },
  "id_str" : "142098683591266304",
  "in_reply_to_user_id" : 14368347,
  "text" : "@wuputah will do tomorrow morning. Brain wiped tonight. \/cc @hone02",
  "id" : 142098683591266304,
  "in_reply_to_status_id" : 142034501818785792,
  "created_at" : "2011-12-01 04:32:20 +0000",
  "in_reply_to_screen_name" : "wuputah",
  "in_reply_to_user_id_str" : "14368347",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142070039883956224",
  "geo" : { },
  "id_str" : "142098509456343040",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik will do tomorrow. Also, Y U NO FOLLOW",
  "id" : 142098509456343040,
  "in_reply_to_status_id" : 142070039883956224,
  "created_at" : "2011-12-01 04:31:39 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/142041770384031744\/photo\/1",
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/61bTBCyA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfiiPNNCAAA4baD.jpg",
      "id_str" : "142041770388226048",
      "id" : 142041770388226048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfiiPNNCAAA4baD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/61bTBCyA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142041770384031744",
  "text" : "Path is beautiful! Until you add some people: http:\/\/t.co\/61bTBCyA",
  "id" : 142041770384031744,
  "created_at" : "2011-12-01 00:46:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/gB6Nj432",
      "expanded_url" : "https:\/\/lh3.googleusercontent.com\/-hDgj5-LY0Rg\/TtYOhwkxySI\/AAAAAAAAX84\/F4L20omKHHc\/w300\/1e94aa75b17abcad492585c703b159a6c87ec78f.gif",
      "display_url" : "lh3.googleusercontent.com\/-hDgj5-LY0Rg\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141992720704090112",
  "text" : "Current status: http:\/\/t.co\/gB6Nj432",
  "id" : 141992720704090112,
  "created_at" : "2011-11-30 21:31:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141931944660320257",
  "geo" : { },
  "id_str" : "141964577805041664",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant or lack of sleep, thanks Dr. Quaranto",
  "id" : 141964577805041664,
  "in_reply_to_status_id" : 141931944660320257,
  "created_at" : "2011-11-30 19:39:27 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141934217419440128",
  "geo" : { },
  "id_str" : "141964528488431616",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems dude! hit me up, i'm quaranto on game center.",
  "id" : 141964528488431616,
  "in_reply_to_status_id" : 141934217419440128,
  "created_at" : "2011-11-30 19:39:15 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carcassonne",
      "screen_name" : "CarcassonneApp",
      "indices" : [ 3, 18 ],
      "id_str" : "49669910",
      "id" : 49669910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141929444666388481",
  "text" : "RT @CarcassonneApp: Good news everyone! We will submit the update with the expansion store (and 2 available expansions) for review to th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141928501522612225",
    "text" : "Good news everyone! We will submit the update with the expansion store (and 2 available expansions) for review to the AppStore next week.",
    "id" : 141928501522612225,
    "created_at" : "2011-11-30 17:16:06 +0000",
    "user" : {
      "name" : "Carcassonne",
      "screen_name" : "CarcassonneApp",
      "protected" : false,
      "id_str" : "49669910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/863254920\/CarcassonneIcon512_normal.png",
      "id" : 49669910,
      "verified" : false
    }
  },
  "id" : 141929444666388481,
  "created_at" : "2011-11-30 17:19:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 37, 50 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/VhLNtqSD",
      "expanded_url" : "http:\/\/i.imgur.com\/LcA79.gif",
      "display_url" : "i.imgur.com\/LcA79.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "141885927684440064",
  "geo" : { },
  "id_str" : "141924620080123906",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack http:\/\/t.co\/VhLNtqSD (via @codemastermm)",
  "id" : 141924620080123906,
  "in_reply_to_status_id" : 141885927684440064,
  "created_at" : "2011-11-30 17:00:40 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 71, 81 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141921412343529473",
  "text" : "RT @aquaranto: soooo long 'ablissfulgal' you'll be missed.\nNew handle: @aquaranto!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 56, 66 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141548480610054144",
    "text" : "soooo long 'ablissfulgal' you'll be missed.\nNew handle: @aquaranto!",
    "id" : 141548480610054144,
    "created_at" : "2011-11-29 16:06:02 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 141921412343529473,
  "created_at" : "2011-11-30 16:47:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141919343486316544",
  "text" : "Ever had one of those days when looking through your glasses hurts your head, and looking without glasses hurts too? Gah.",
  "id" : 141919343486316544,
  "created_at" : "2011-11-30 16:39:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Barrett",
      "screen_name" : "thoughtpunch",
      "indices" : [ 0, 13 ],
      "id_str" : "202236256",
      "id" : 202236256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141649248184836096",
  "geo" : { },
  "id_str" : "141687444612464640",
  "in_reply_to_user_id" : 202236256,
  "text" : "@thoughtpunch yeah, moved beginning of November. And haha, no, but they are awesome !",
  "id" : 141687444612464640,
  "in_reply_to_status_id" : 141649248184836096,
  "created_at" : "2011-11-30 01:18:13 +0000",
  "in_reply_to_screen_name" : "thoughtpunch",
  "in_reply_to_user_id_str" : "202236256",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/Cz2eN52B",
      "expanded_url" : "http:\/\/instagr.am\/p\/Wik6N\/",
      "display_url" : "instagr.am\/p\/Wik6N\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8750048826, -78.8766431808 ]
  },
  "id_str" : "141672268379066368",
  "text" : "Let's go Sabres!  @ HSBC Arena http:\/\/t.co\/Cz2eN52B",
  "id" : 141672268379066368,
  "created_at" : "2011-11-30 00:17:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141647345384304640",
  "text" : "Sabres tonight! Who else is going?",
  "id" : 141647345384304640,
  "created_at" : "2011-11-29 22:38:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141530290987352065",
  "geo" : { },
  "id_str" : "141532781103681536",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit WORLD TRAVELERS MORRISONS! ENGAGE!",
  "id" : 141532781103681536,
  "in_reply_to_status_id" : 141530290987352065,
  "created_at" : "2011-11-29 15:03:39 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/fJKAQVzk",
      "expanded_url" : "http:\/\/instagr.am\/p\/WeVnh\/",
      "display_url" : "instagr.am\/p\/WeVnh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "141506812368265216",
  "text" : "Tobi, the one Michael Scott doesn't hate http:\/\/t.co\/fJKAQVzk",
  "id" : 141506812368265216,
  "created_at" : "2011-11-29 13:20:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141452357308391424",
  "geo" : { },
  "id_str" : "141489560289943554",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh congrats! !",
  "id" : 141489560289943554,
  "in_reply_to_status_id" : 141452357308391424,
  "created_at" : "2011-11-29 12:11:54 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan gigante",
      "screen_name" : "dangigante",
      "indices" : [ 0, 11 ],
      "id_str" : "43151378",
      "id" : 43151378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141392371094007808",
  "geo" : { },
  "id_str" : "141393269966909440",
  "in_reply_to_user_id" : 43151378,
  "text" : "@dangigante @manda903 sold! My email is nick [at] quaran.to :)",
  "id" : 141393269966909440,
  "in_reply_to_status_id" : 141392371094007808,
  "created_at" : "2011-11-29 05:49:17 +0000",
  "in_reply_to_screen_name" : "dangigante",
  "in_reply_to_user_id_str" : "43151378",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gemcutter\/status\/141353996010000384\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/sJoCJazb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfYwteACEAALE6C.png",
      "id_str" : "141353996014194688",
      "id" : 141353996014194688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfYwteACEAALE6C.png",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/sJoCJazb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141354040293470209",
  "text" : "RT @gemcutter: Looks like we're back up, on Ruby 1.9.3! http:\/\/t.co\/sJoCJazb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gemcutter\/status\/141353996010000384\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/sJoCJazb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AfYwteACEAALE6C.png",
        "id_str" : "141353996014194688",
        "id" : 141353996014194688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfYwteACEAALE6C.png",
        "sizes" : [ {
          "h" : 196,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 250
        } ],
        "display_url" : "pic.twitter.com\/sJoCJazb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141353996010000384",
    "text" : "Looks like we're back up, on Ruby 1.9.3! http:\/\/t.co\/sJoCJazb",
    "id" : 141353996010000384,
    "created_at" : "2011-11-29 03:13:13 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 141354040293470209,
  "created_at" : "2011-11-29 03:13:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/Xyoq6kad",
      "expanded_url" : "http:\/\/zelda.wikia.com\/wiki\/Six_Medallions",
      "display_url" : "zelda.wikia.com\/wiki\/Six_Medal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "141342619400810498",
  "geo" : { },
  "id_str" : "141350334491664384",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm http:\/\/t.co\/Xyoq6kad",
  "id" : 141350334491664384,
  "in_reply_to_status_id" : 141342619400810498,
  "created_at" : "2011-11-29 02:58:40 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/81ONYa31",
      "expanded_url" : "http:\/\/instagr.am\/p\/Waf_P\/",
      "display_url" : "instagr.am\/p\/Waf_P\/"
    } ]
  },
  "geo" : { },
  "id_str" : "141342427700142084",
  "text" : "Loving the Ocarina of Time references in Skyward Sword. http:\/\/t.co\/81ONYa31",
  "id" : 141342427700142084,
  "created_at" : "2011-11-29 02:27:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    }, {
      "name" : "Thunderbolt Labs",
      "screen_name" : "ThunderboltLabs",
      "indices" : [ 40, 56 ],
      "id_str" : "414333099",
      "id" : 414333099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141322241345462273",
  "geo" : { },
  "id_str" : "141328942090039296",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh Ahhh just saw this. MAKE IT SO! @ThunderboltLabs",
  "id" : 141328942090039296,
  "in_reply_to_status_id" : 141322241345462273,
  "created_at" : "2011-11-29 01:33:40 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141321932921516032",
  "geo" : { },
  "id_str" : "141328418749947906",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh wow dude! Leaving EY?",
  "id" : 141328418749947906,
  "in_reply_to_status_id" : 141321932921516032,
  "created_at" : "2011-11-29 01:31:35 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/wUHKBbGH",
      "expanded_url" : "http:\/\/sadtrombone.com\/",
      "display_url" : "sadtrombone.com"
    } ]
  },
  "in_reply_to_status_id_str" : "141309368799997952",
  "geo" : { },
  "id_str" : "141309823605157888",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou http:\/\/t.co\/wUHKBbGH",
  "id" : 141309823605157888,
  "in_reply_to_status_id" : 141309368799997952,
  "created_at" : "2011-11-29 00:17:42 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141307180908412928",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy btw, the 3rd string in the index for each gem is its \"platform\". it could be mswin32, linux only, etc.",
  "id" : 141307180908412928,
  "created_at" : "2011-11-29 00:07:11 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141298185405595648",
  "text" : "\"How much money did you spend?\" \"...a lot\"\n\"Conversion of String to Fixnum failed\"",
  "id" : 141298185405595648,
  "created_at" : "2011-11-28 23:31:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/DogQRsck",
      "expanded_url" : "http:\/\/www.livephish.com\/radio\/listen.m3u",
      "display_url" : "livephish.com\/radio\/listen.m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141256633274744832",
  "text" : "Discovering how awesome Live Phish Radio is. http:\/\/t.co\/DogQRsck",
  "id" : 141256633274744832,
  "created_at" : "2011-11-28 20:46:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/Jk41MJSS",
      "expanded_url" : "http:\/\/www.marco.org\/2011\/11\/28\/whatever-works-for-you",
      "display_url" : "marco.org\/2011\/11\/28\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141256094889689089",
  "text" : "Use Whatever Works\u2122: http:\/\/t.co\/Jk41MJSS",
  "id" : 141256094889689089,
  "created_at" : "2011-11-28 20:44:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bloom",
      "screen_name" : "chrisbloom7",
      "indices" : [ 0, 12 ],
      "id_str" : "5158601",
      "id" : 5158601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141187936581455872",
  "geo" : { },
  "id_str" : "141236783563284480",
  "in_reply_to_user_id" : 5158601,
  "text" : "@chrisbloom7 thanks :)",
  "id" : 141236783563284480,
  "in_reply_to_status_id" : 141187936581455872,
  "created_at" : "2011-11-28 19:27:27 +0000",
  "in_reply_to_screen_name" : "chrisbloom7",
  "in_reply_to_user_id_str" : "5158601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141235517349040128",
  "text" : "RT @gemcutter: Tonight at 10PM EST we're upgrading to the latest Passenger and Ruby 1.9.3. Stay tuned here for updates, going to keep do ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141235481311580160",
    "text" : "Tonight at 10PM EST we're upgrading to the latest Passenger and Ruby 1.9.3. Stay tuned here for updates, going to keep downtime minimal.",
    "id" : 141235481311580160,
    "created_at" : "2011-11-28 19:22:17 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 141235517349040128,
  "created_at" : "2011-11-28 19:22:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Woodward",
      "screen_name" : "ericwoodward",
      "indices" : [ 0, 13 ],
      "id_str" : "15435089",
      "id" : 15435089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141201645747961856",
  "geo" : { },
  "id_str" : "141223048190767104",
  "in_reply_to_user_id" : 15435089,
  "text" : "@ericwoodward YOU CAN'T BREAK THOSE CUFFS!! AHHHHHHH",
  "id" : 141223048190767104,
  "in_reply_to_status_id" : 141201645747961856,
  "created_at" : "2011-11-28 18:32:53 +0000",
  "in_reply_to_screen_name" : "ericwoodward",
  "in_reply_to_user_id_str" : "15435089",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/pNGX6Y3f",
      "expanded_url" : "http:\/\/i.imgur.com\/hcmYV.jpg",
      "display_url" : "i.imgur.com\/hcmYV.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "141164777488646147",
  "text" : "I love Dune jokes. http:\/\/t.co\/pNGX6Y3f",
  "id" : 141164777488646147,
  "created_at" : "2011-11-28 14:41:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EYouTube on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/RU4HvrKj",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gW8E22ZLR3k&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=gW8E22\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "140961932462141440",
  "text" : "Current status http:\/\/t.co\/RU4HvrKj",
  "id" : 140961932462141440,
  "created_at" : "2011-11-28 01:15:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/cjmAYORT",
      "expanded_url" : "http:\/\/instagr.am\/p\/WPZbV\/",
      "display_url" : "instagr.am\/p\/WPZbV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "140934724880318464",
  "text" : "Last Slice... http:\/\/t.co\/cjmAYORT",
  "id" : 140934724880318464,
  "created_at" : "2011-11-27 23:27:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/yUU9aGaX",
      "expanded_url" : "http:\/\/instagr.am\/p\/WMD-d\/",
      "display_url" : "instagr.am\/p\/WMD-d\/"
    } ]
  },
  "geo" : { },
  "id_str" : "140846293055582208",
  "text" : "Settlers! First win! http:\/\/t.co\/yUU9aGaX",
  "id" : 140846293055582208,
  "created_at" : "2011-11-27 17:35:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140647747631067136",
  "geo" : { },
  "id_str" : "140650392303312896",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit dude how we did both end up playing laser tag tonight?! GL HF ON WORLD ADVENTURES",
  "id" : 140650392303312896,
  "in_reply_to_status_id" : 140647747631067136,
  "created_at" : "2011-11-27 04:37:21 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140636356392132608",
  "text" : "Got wrecked for the second game. Forgot how awesome Lasertron is. Two stories is awesome.",
  "id" : 140636356392132608,
  "created_at" : "2011-11-27 03:41:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/5mo3lrmq",
      "expanded_url" : "http:\/\/instagr.am\/p\/WE_0y\/",
      "display_url" : "instagr.am\/p\/WE_0y\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9927710886, -78.8142228127 ]
  },
  "id_str" : "140620113157165057",
  "text" : "PWNAGE  @ Lasertron http:\/\/t.co\/5mo3lrmq",
  "id" : 140620113157165057,
  "created_at" : "2011-11-27 02:37:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/e5UURIvQ",
      "expanded_url" : "http:\/\/instagr.am\/p\/WEoLm\/",
      "display_url" : "instagr.am\/p\/WEoLm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "140611398085517312",
  "text" : "Epic battle time! http:\/\/t.co\/e5UURIvQ",
  "id" : 140611398085517312,
  "created_at" : "2011-11-27 02:02:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/iQzNFX5i",
      "expanded_url" : "http:\/\/instagr.am\/p\/WC6rf\/",
      "display_url" : "instagr.am\/p\/WC6rf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.924749, -78.87708 ]
  },
  "id_str" : "140570584689016832",
  "text" : "Phin & Matt's!  @ J.P. Bullfeathers American Grill and Bar http:\/\/t.co\/iQzNFX5i",
  "id" : 140570584689016832,
  "created_at" : "2011-11-26 23:20:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/slLnLtVl",
      "expanded_url" : "http:\/\/instagr.am\/p\/WB6Ka\/",
      "display_url" : "instagr.am\/p\/WB6Ka\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "140546897826947072",
  "text" : "Sunset on the Buffalo waterfront, no filter required!  @ Buffalo Barkyard - Dog Park http:\/\/t.co\/slLnLtVl",
  "id" : 140546897826947072,
  "created_at" : "2011-11-26 21:46:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cBUc0czt",
      "expanded_url" : "http:\/\/i.imgur.com\/r0R56.png",
      "display_url" : "i.imgur.com\/r0R56.png"
    } ]
  },
  "geo" : { },
  "id_str" : "140519307238064128",
  "text" : "Current status: http:\/\/t.co\/cBUc0czt",
  "id" : 140519307238064128,
  "created_at" : "2011-11-26 19:56:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/hzebWFGR",
      "expanded_url" : "http:\/\/i.imgur.com\/0EAfi.jpg",
      "display_url" : "i.imgur.com\/0EAfi.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "140519029570928640",
  "text" : "Cracks me up, every time. http:\/\/t.co\/hzebWFGR",
  "id" : 140519029570928640,
  "created_at" : "2011-11-26 19:55:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt jankowski",
      "screen_name" : "jankowski",
      "indices" : [ 11, 21 ],
      "id_str" : "5965482",
      "id" : 5965482
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/140505518866309120\/photo\/1",
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/mqjN9OKy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfMtBmVCIAAQUwI.jpg",
      "id_str" : "140505518870503424",
      "id" : 140505518870503424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfMtBmVCIAAQUwI.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/mqjN9OKy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140505518866309120",
  "text" : "Just found @jankowski's dream come true at Wegmans. http:\/\/t.co\/mqjN9OKy",
  "id" : 140505518866309120,
  "created_at" : "2011-11-26 19:01:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140440318695845889",
  "geo" : { },
  "id_str" : "140444857629028353",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi also IMO you should have whoever made the last cover do this one. Make it a series, contiguous",
  "id" : 140444857629028353,
  "in_reply_to_status_id" : 140440318695845889,
  "created_at" : "2011-11-26 15:00:38 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140440318695845889",
  "geo" : { },
  "id_str" : "140444506196680704",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi origami one is the best. Sick of the train metaphors.",
  "id" : 140444506196680704,
  "in_reply_to_status_id" : 140440318695845889,
  "created_at" : "2011-11-26 14:59:14 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140443641364746242",
  "geo" : { },
  "id_str" : "140444008391516161",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything 1.9.3 all the way!",
  "id" : 140444008391516161,
  "in_reply_to_status_id" : 140443641364746242,
  "created_at" : "2011-11-26 14:57:15 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140440784632680448",
  "geo" : { },
  "id_str" : "140443836492152832",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw you should make a screencast with cathode for this",
  "id" : 140443836492152832,
  "in_reply_to_status_id" : 140440784632680448,
  "created_at" : "2011-11-26 14:56:34 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/1vfSHgLp",
      "expanded_url" : "http:\/\/www.lasertron.us\/Laser_Tag_Center_Graphics\/Laser_Tag_Center_iso_map_large.gif",
      "display_url" : "lasertron.us\/Laser_Tag_Cent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "140236524817104897",
  "text" : "Future laser tag status: http:\/\/t.co\/1vfSHgLp HECK YES.",
  "id" : 140236524817104897,
  "created_at" : "2011-11-26 01:12:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140235997739876352",
  "text" : "This Sabres game has just been embarrassing to watch. :(",
  "id" : 140235997739876352,
  "created_at" : "2011-11-26 01:10:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ryckbost",
      "screen_name" : "bryckbost",
      "indices" : [ 0, 10 ],
      "id_str" : "8494682",
      "id" : 8494682
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 36, 47 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/9UEb70VR",
      "expanded_url" : "https:\/\/github.com\/collectiveidea\/delayed_job\/issues\/312",
      "display_url" : "github.com\/collectiveidea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "139789939599613955",
  "geo" : { },
  "id_str" : "140221215854964736",
  "in_reply_to_user_id" : 8494682,
  "text" : "@bryckbost http:\/\/t.co\/9UEb70VR \/cc @tenderlove",
  "id" : 140221215854964736,
  "in_reply_to_status_id" : 139789939599613955,
  "created_at" : "2011-11-26 00:11:57 +0000",
  "in_reply_to_screen_name" : "bryckbost",
  "in_reply_to_user_id_str" : "8494682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 8, 22 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/okABZ94j",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ix_11UeGwYY",
      "display_url" : "youtube.com\/watch?v=Ix_11U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "140205254523371520",
  "text" : "I found @joshuaclayton's new kit: http:\/\/t.co\/okABZ94j",
  "id" : 140205254523371520,
  "created_at" : "2011-11-25 23:08:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R D Old",
      "screen_name" : "thatRD",
      "indices" : [ 0, 7 ],
      "id_str" : "1928924059",
      "id" : 1928924059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/hmDRyAfV",
      "expanded_url" : "http:\/\/www.secretgeometry.com\/apps\/cathode\/",
      "display_url" : "secretgeometry.com\/apps\/cathode\/"
    } ]
  },
  "in_reply_to_status_id_str" : "140145984859680768",
  "geo" : { },
  "id_str" : "140178062066200576",
  "in_reply_to_user_id" : 23369749,
  "text" : "@thatRD http:\/\/t.co\/hmDRyAfV",
  "id" : 140178062066200576,
  "in_reply_to_status_id" : 140145984859680768,
  "created_at" : "2011-11-25 21:20:29 +0000",
  "in_reply_to_screen_name" : "lbwski",
  "in_reply_to_user_id_str" : "23369749",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    }, {
      "name" : "Patrick Donnelly",
      "screen_name" : "dunalar",
      "indices" : [ 18, 26 ],
      "id_str" : "32317282",
      "id" : 32317282
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 31, 43 ],
      "id_str" : "248477732",
      "id" : 248477732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140141117030146048",
  "geo" : { },
  "id_str" : "140177591813410816",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu haha no, @dunalar and @ecarlsen912 were visiting.",
  "id" : 140177591813410816,
  "in_reply_to_status_id" : 140141117030146048,
  "created_at" : "2011-11-25 21:18:36 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/OhsPtISa",
      "expanded_url" : "http:\/\/instagr.am\/p\/V0GFd\/",
      "display_url" : "instagr.am\/p\/V0GFd\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9205, -78.877012 ]
  },
  "id_str" : "140135582578917376",
  "text" : "Puppies!  @ Elmwood Village http:\/\/t.co\/OhsPtISa",
  "id" : 140135582578917376,
  "created_at" : "2011-11-25 18:31:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/o5u2TOgo",
      "expanded_url" : "http:\/\/motherjones.com\/kevin-drum\/2011\/11\/real-story-behind-black-friday",
      "display_url" : "motherjones.com\/kevin-drum\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "140125963093671936",
  "geo" : { },
  "id_str" : "140128897009332224",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil http:\/\/t.co\/o5u2TOgo",
  "id" : 140128897009332224,
  "in_reply_to_status_id" : 140125963093671936,
  "created_at" : "2011-11-25 18:05:07 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/iNRKKaSb",
      "expanded_url" : "http:\/\/vimeo.com\/32672792",
      "display_url" : "vimeo.com\/32672792"
    } ]
  },
  "geo" : { },
  "id_str" : "140127848546578432",
  "text" : "`hub compare` and `hub pull-request` just blew my mind. time to alias it to git, i think. http:\/\/t.co\/iNRKKaSb",
  "id" : 140127848546578432,
  "created_at" : "2011-11-25 18:00:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 3, 10 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/xWdUFQNo",
      "expanded_url" : "http:\/\/vimeo.com\/mislav\/hub-17",
      "display_url" : "vimeo.com\/mislav\/hub-17"
    } ]
  },
  "geo" : { },
  "id_str" : "140127737682731009",
  "text" : "RT @mislav: So hub 1.7 is out and I made this screencast for it http:\/\/t.co\/xWdUFQNo\n\nThe screencast itself is a bit different than what ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/xWdUFQNo",
        "expanded_url" : "http:\/\/vimeo.com\/mislav\/hub-17",
        "display_url" : "vimeo.com\/mislav\/hub-17"
      } ]
    },
    "geo" : { },
    "id_str" : "140116807448141824",
    "text" : "So hub 1.7 is out and I made this screencast for it http:\/\/t.co\/xWdUFQNo\n\nThe screencast itself is a bit different than what you're used to.",
    "id" : 140116807448141824,
    "created_at" : "2011-11-25 17:17:04 +0000",
    "user" : {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "protected" : false,
      "id_str" : "7516242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500395960648749056\/A6trldA8_normal.jpeg",
      "id" : 7516242,
      "verified" : false
    }
  },
  "id" : 140127737682731009,
  "created_at" : "2011-11-25 18:00:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "indices" : [ 3, 13 ],
      "id_str" : "14582359",
      "id" : 14582359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "siri",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "tellme",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/wmGnoIeK",
      "expanded_url" : "http:\/\/youtu.be\/SHoukZpMhDE",
      "display_url" : "youtu.be\/SHoukZpMhDE"
    } ]
  },
  "geo" : { },
  "id_str" : "140098379232460800",
  "text" : "RT @acangiano: Apple vs Microsoft in a nutshell: http:\/\/t.co\/wmGnoIeK #lol #siri #tellme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lol",
        "indices" : [ 55, 59 ]
      }, {
        "text" : "siri",
        "indices" : [ 60, 65 ]
      }, {
        "text" : "tellme",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/wmGnoIeK",
        "expanded_url" : "http:\/\/youtu.be\/SHoukZpMhDE",
        "display_url" : "youtu.be\/SHoukZpMhDE"
      } ]
    },
    "geo" : { },
    "id_str" : "140086659298500609",
    "text" : "Apple vs Microsoft in a nutshell: http:\/\/t.co\/wmGnoIeK #lol #siri #tellme",
    "id" : 140086659298500609,
    "created_at" : "2011-11-25 15:17:16 +0000",
    "user" : {
      "name" : "Antonio Cangiano",
      "screen_name" : "acangiano",
      "protected" : false,
      "id_str" : "14582359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473881706768760832\/qIkS0g72_normal.jpeg",
      "id" : 14582359,
      "verified" : false
    }
  },
  "id" : 140098379232460800,
  "created_at" : "2011-11-25 16:03:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hUKuP0dQ",
      "expanded_url" : "http:\/\/jettingrubyist.com",
      "display_url" : "jettingrubyist.com"
    } ]
  },
  "geo" : { },
  "id_str" : "139893110347014145",
  "text" : "RT @rubiety: Compare Obie's terms to mine: only JetBlue (economy, free), staying only at shitty hostels. Payment: your good company. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/hUKuP0dQ",
        "expanded_url" : "http:\/\/jettingrubyist.com",
        "display_url" : "jettingrubyist.com"
      } ]
    },
    "geo" : { },
    "id_str" : "139892636340322304",
    "text" : "Compare Obie's terms to mine: only JetBlue (economy, free), staying only at shitty hostels. Payment: your good company. http:\/\/t.co\/hUKuP0dQ",
    "id" : 139892636340322304,
    "created_at" : "2011-11-25 02:26:18 +0000",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 139893110347014145,
  "created_at" : "2011-11-25 02:28:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 0, 5 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139856959762481152",
  "geo" : { },
  "id_str" : "139866233922273280",
  "in_reply_to_user_id" : 45603,
  "text" : "@obie I just can't believe people pay for it.",
  "id" : 139866233922273280,
  "in_reply_to_status_id" : 139856959762481152,
  "created_at" : "2011-11-25 00:41:23 +0000",
  "in_reply_to_screen_name" : "obie",
  "in_reply_to_user_id_str" : "45603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    }, {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 7, 12 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139853846724878336",
  "geo" : { },
  "id_str" : "139854338486054913",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic @obie It just feels dishonest.",
  "id" : 139854338486054913,
  "in_reply_to_status_id" : 139853846724878336,
  "created_at" : "2011-11-24 23:54:07 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 0, 5 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139790116569874432",
  "geo" : { },
  "id_str" : "139853501852426240",
  "in_reply_to_user_id" : 45603,
  "text" : "@obie 10K a DAY? Is this a joke?",
  "id" : 139853501852426240,
  "in_reply_to_status_id" : 139790116569874432,
  "created_at" : "2011-11-24 23:50:47 +0000",
  "in_reply_to_screen_name" : "obie",
  "in_reply_to_user_id_str" : "45603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/iJ4NVO7A",
      "expanded_url" : "http:\/\/instagr.am\/p\/VqCMf\/",
      "display_url" : "instagr.am\/p\/VqCMf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.0406653048, -78.8648414612 ]
  },
  "id_str" : "139826302982176768",
  "text" : "DessertOverflowException  @ North Tonawanda, NY http:\/\/t.co\/iJ4NVO7A",
  "id" : 139826302982176768,
  "created_at" : "2011-11-24 22:02:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ryckbost",
      "screen_name" : "bryckbost",
      "indices" : [ 0, 10 ],
      "id_str" : "8494682",
      "id" : 8494682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139789939599613955",
  "geo" : { },
  "id_str" : "139802289807441920",
  "in_reply_to_user_id" : 8494682,
  "text" : "@bryckbost yes, happening on staging as we've been trying out 1.9.3\/RVM",
  "id" : 139802289807441920,
  "in_reply_to_status_id" : 139789939599613955,
  "created_at" : "2011-11-24 20:27:17 +0000",
  "in_reply_to_screen_name" : "bryckbost",
  "in_reply_to_user_id_str" : "8494682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/SklnmFqG",
      "expanded_url" : "https:\/\/gist.github.com\/1391857",
      "display_url" : "gist.github.com\/1391857"
    } ]
  },
  "geo" : { },
  "id_str" : "139757451103830016",
  "text" : "This Syck\/Psych debacle is really stupid. Anyone seen this nonsense before? http:\/\/t.co\/SklnmFqG Using 1.9.3 and DelayedJob.",
  "id" : 139757451103830016,
  "created_at" : "2011-11-24 17:29:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Gebhardt",
      "screen_name" : "dgeb",
      "indices" : [ 0, 5 ],
      "id_str" : "14651212",
      "id" : 14651212
    }, {
      "name" : "Russell Jones",
      "screen_name" : "codeofficer",
      "indices" : [ 6, 18 ],
      "id_str" : "8828952",
      "id" : 8828952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139561318163300353",
  "geo" : { },
  "id_str" : "139577344938606592",
  "in_reply_to_user_id" : 14651212,
  "text" : "@dgeb @codeofficer if the biggest problem you have with code is leading spaces, you need to find more interesting problems to work on",
  "id" : 139577344938606592,
  "in_reply_to_status_id" : 139561318163300353,
  "created_at" : "2011-11-24 05:33:26 +0000",
  "in_reply_to_screen_name" : "dgeb",
  "in_reply_to_user_id_str" : "14651212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139550761444057089",
  "text" : "RT @r00k: Every time a vim user hits an arrow key, Bram Moolenaar kills a poor Ugandan child.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139435046057680896",
    "text" : "Every time a vim user hits an arrow key, Bram Moolenaar kills a poor Ugandan child.",
    "id" : 139435046057680896,
    "created_at" : "2011-11-23 20:08:00 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 139550761444057089,
  "created_at" : "2011-11-24 03:47:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139546693858365440",
  "geo" : { },
  "id_str" : "139548375455514624",
  "in_reply_to_user_id" : 21390942,
  "text" : "@danielsju6 me too, and I was there! Good game.",
  "id" : 139548375455514624,
  "in_reply_to_status_id" : 139546693858365440,
  "created_at" : "2011-11-24 03:38:20 +0000",
  "in_reply_to_screen_name" : "jamesuriah",
  "in_reply_to_user_id_str" : "21390942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/MqeNqPM3",
      "expanded_url" : "http:\/\/gowalla.com\/stories\/5fGqw",
      "display_url" : "gowalla.com\/stories\/5fGqw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8750520577, -78.8764071465 ]
  },
  "id_str" : "139490430235578369",
  "text" : "Sabres time!! \u2013 at HSBC Arena http:\/\/t.co\/MqeNqPM3",
  "id" : 139490430235578369,
  "created_at" : "2011-11-23 23:48:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/D5RzCJ9H",
      "expanded_url" : "http:\/\/www.myrobotnation.com\/",
      "display_url" : "myrobotnation.com"
    } ]
  },
  "geo" : { },
  "id_str" : "139410772504739840",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot http:\/\/t.co\/D5RzCJ9H you know what to do",
  "id" : 139410772504739840,
  "created_at" : "2011-11-23 18:31:32 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139171605598314496",
  "geo" : { },
  "id_str" : "139171978421604352",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic it's just plain turrible out",
  "id" : 139171978421604352,
  "in_reply_to_status_id" : 139171605598314496,
  "created_at" : "2011-11-23 02:42:40 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/aS1ecdQX",
      "expanded_url" : "http:\/\/guides.rubygems.org\/rubygems-org-api\/#gem",
      "display_url" : "guides.rubygems.org\/rubygems-org-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "139031273107750912",
  "geo" : { },
  "id_str" : "139055386891259904",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm that is shown through the API though: http:\/\/t.co\/aS1ecdQX",
  "id" : 139055386891259904,
  "in_reply_to_status_id" : 139031273107750912,
  "created_at" : "2011-11-22 18:59:22 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139019440548364289",
  "geo" : { },
  "id_str" : "139031152785752065",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm there's no gem metadata yet :( sign in, there's an edit link when you visit your gem's page.",
  "id" : 139031152785752065,
  "in_reply_to_status_id" : 139019440548364289,
  "created_at" : "2011-11-22 17:23:04 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139000946394017792",
  "text" : "Ever refresh your GMail for a new email and think back \"I used to do this all the time\" ?",
  "id" : 139000946394017792,
  "created_at" : "2011-11-22 15:23:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u00E1maso Wilmer L\u00F3pez ",
      "screen_name" : "welp",
      "indices" : [ 0, 5 ],
      "id_str" : "2252350466",
      "id" : 2252350466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138618113104150528",
  "geo" : { },
  "id_str" : "138847766947442688",
  "in_reply_to_user_id" : 14125067,
  "text" : "@welp try gem install bundler --pre",
  "id" : 138847766947442688,
  "in_reply_to_status_id" : 138618113104150528,
  "created_at" : "2011-11-22 05:14:21 +0000",
  "in_reply_to_screen_name" : "pfweller",
  "in_reply_to_user_id_str" : "14125067",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138845155775094784",
  "geo" : { },
  "id_str" : "138846338229075968",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything git checkout does too...it is glorious",
  "id" : 138846338229075968,
  "in_reply_to_status_id" : 138845155775094784,
  "created_at" : "2011-11-22 05:08:41 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/2QfD79um",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3045-top-tier-this",
      "display_url" : "37signals.com\/svn\/posts\/3045\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138718376552972288",
  "text" : "yay RIT! http:\/\/t.co\/2QfD79um",
  "id" : 138718376552972288,
  "created_at" : "2011-11-21 20:40:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Farrington",
      "screen_name" : "wfarr",
      "indices" : [ 0, 6 ],
      "id_str" : "10403812",
      "id" : 10403812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138712595086581760",
  "geo" : { },
  "id_str" : "138714406233186304",
  "in_reply_to_user_id" : 10403812,
  "text" : "@wfarr no idea. :\/",
  "id" : 138714406233186304,
  "in_reply_to_status_id" : 138712595086581760,
  "created_at" : "2011-11-21 20:24:26 +0000",
  "in_reply_to_screen_name" : "wfarr",
  "in_reply_to_user_id_str" : "10403812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 0, 6 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138709086719066113",
  "geo" : { },
  "id_str" : "138709530338004992",
  "in_reply_to_user_id" : 8000842,
  "text" : "@tpope oh fun, i'm sure if both are installed rubygems gets really...fun",
  "id" : 138709530338004992,
  "in_reply_to_status_id" : 138709086719066113,
  "created_at" : "2011-11-21 20:05:03 +0000",
  "in_reply_to_screen_name" : "tpope",
  "in_reply_to_user_id_str" : "8000842",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138701485943955456",
  "geo" : { },
  "id_str" : "138701899951120384",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan we typically try to contact the original author. of course, hardcore forking action is always an option",
  "id" : 138701899951120384,
  "in_reply_to_status_id" : 138701485943955456,
  "created_at" : "2011-11-21 19:34:44 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 0, 10 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138698016986120192",
  "geo" : { },
  "id_str" : "138698958703820800",
  "in_reply_to_user_id" : 18047782,
  "text" : "@p_elliott yes! loving it here so far :)",
  "id" : 138698958703820800,
  "in_reply_to_status_id" : 138698016986120192,
  "created_at" : "2011-11-21 19:23:03 +0000",
  "in_reply_to_screen_name" : "p_elliott",
  "in_reply_to_user_id_str" : "18047782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 24, 27 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/oePUFD0X",
      "expanded_url" : "http:\/\/omgbloglol.com\/post\/13112129116\/introducing-gem-git-tiny-tools-for-working-with-gems",
      "display_url" : "omgbloglol.com\/post\/131121291\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138695837747388417",
  "text" : "I love gem plugins. And @jm made `gem clone` and `gem fork` ! `gem install gem_git` !! http:\/\/t.co\/oePUFD0X",
  "id" : 138695837747388417,
  "created_at" : "2011-11-21 19:10:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 0, 8 ],
      "id_str" : "15947489",
      "id" : 15947489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138695215098773504",
  "geo" : { },
  "id_str" : "138695510310662144",
  "in_reply_to_user_id" : 15947489,
  "text" : "@sgharms just wait for ActiveSupport::DrumSolo, it'll blow your mind",
  "id" : 138695510310662144,
  "in_reply_to_status_id" : 138695215098773504,
  "created_at" : "2011-11-21 19:09:21 +0000",
  "in_reply_to_screen_name" : "sgharms",
  "in_reply_to_user_id_str" : "15947489",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138692449127239680",
  "geo" : { },
  "id_str" : "138694883044110337",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel thanks Chad.",
  "id" : 138694883044110337,
  "in_reply_to_status_id" : 138692449127239680,
  "created_at" : "2011-11-21 19:06:51 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138693678876196864",
  "geo" : { },
  "id_str" : "138694804828729344",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock i'm based in Buffalo! and well aware :)",
  "id" : 138694804828729344,
  "in_reply_to_status_id" : 138693678876196864,
  "created_at" : "2011-11-21 19:06:32 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138692858814279681",
  "geo" : { },
  "id_str" : "138693062934269952",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits THIS DELAYED JOKE IS RIPE FOR DISRUPTION",
  "id" : 138693062934269952,
  "in_reply_to_status_id" : 138692858814279681,
  "created_at" : "2011-11-21 18:59:37 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 48, 58 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138674317515960321",
  "text" : "Thanks everyone! Really excited to be a part of @37signals :)",
  "id" : 138674317515960321,
  "created_at" : "2011-11-21 17:45:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Block",
      "screen_name" : "sabre1041",
      "indices" : [ 0, 10 ],
      "id_str" : "215818100",
      "id" : 215818100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138674095633080320",
  "geo" : { },
  "id_str" : "138674181893136384",
  "in_reply_to_user_id" : 215818100,
  "text" : "@sabre1041 no, working from Buffalo. I'll be in Chicago more though!",
  "id" : 138674181893136384,
  "in_reply_to_status_id" : 138674095633080320,
  "created_at" : "2011-11-21 17:44:36 +0000",
  "in_reply_to_screen_name" : "sabre1041",
  "in_reply_to_user_id_str" : "215818100",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 3, 7 ],
      "id_str" : "14561327",
      "id" : 14561327
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 31, 37 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 63, 73 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138673709086015488",
  "text" : "RT @dhh: Very happy to welcome @qrush as the newest programmer @37signals!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 22, 28 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 54, 64 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138672994741518336",
    "text" : "Very happy to welcome @qrush as the newest programmer @37signals!",
    "id" : 138672994741518336,
    "created_at" : "2011-11-21 17:39:53 +0000",
    "user" : {
      "name" : "DHH",
      "screen_name" : "dhh",
      "protected" : false,
      "id_str" : "14561327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2556368541\/alng5gtlmjhrdlr3qxqv_normal.jpeg",
      "id" : 14561327,
      "verified" : true
    }
  },
  "id" : 138673709086015488,
  "created_at" : "2011-11-21 17:42:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138485172097138690",
  "geo" : { },
  "id_str" : "138486206555111424",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen with TP, simmer down beavis",
  "id" : 138486206555111424,
  "in_reply_to_status_id" : 138485172097138690,
  "created_at" : "2011-11-21 05:17:39 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138446231537070080",
  "geo" : { },
  "id_str" : "138479642813267969",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen the end is worth it.",
  "id" : 138479642813267969,
  "in_reply_to_status_id" : 138446231537070080,
  "created_at" : "2011-11-21 04:51:34 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138446532545490946",
  "text" : "You can roll pots in this Zelda. THEY BUILT WII BOWLING INTO ZELDA.",
  "id" : 138446532545490946,
  "created_at" : "2011-11-21 02:40:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138444844711411712",
  "text" : "Skyward Sword acquired. Unbelievably excited.",
  "id" : 138444844711411712,
  "created_at" : "2011-11-21 02:33:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/rDhqqWX9",
      "expanded_url" : "http:\/\/robots.thoughtbot.com\/post\/12707447650\/airbrakes-new-team",
      "display_url" : "robots.thoughtbot.com\/post\/127074476\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "138394118966624256",
  "geo" : { },
  "id_str" : "138409877021278208",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou http:\/\/t.co\/rDhqqWX9",
  "id" : 138409877021278208,
  "in_reply_to_status_id" : 138394118966624256,
  "created_at" : "2011-11-21 00:14:20 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138387824973062144",
  "geo" : { },
  "id_str" : "138409451270062080",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu we live 20 mins away or so. Everything in buffalo is 20 minutes away :)",
  "id" : 138409451270062080,
  "in_reply_to_status_id" : 138387824973062144,
  "created_at" : "2011-11-21 00:12:39 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Godin",
      "screen_name" : "Alex_Godin",
      "indices" : [ 0, 11 ],
      "id_str" : "11694962",
      "id" : 11694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138371512561434624",
  "geo" : { },
  "id_str" : "138409321930309632",
  "in_reply_to_user_id" : 11694962,
  "text" : "@Alex_Godin @ablissfulgal won 4 free tickets to the Browns game!",
  "id" : 138409321930309632,
  "in_reply_to_status_id" : 138371512561434624,
  "created_at" : "2011-11-21 00:12:08 +0000",
  "in_reply_to_screen_name" : "Alex_Godin",
  "in_reply_to_user_id_str" : "11694962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138370201296183296",
  "text" : "Homeless guy walks into bar and sat down at our table. Authentic Cleveland experience.",
  "id" : 138370201296183296,
  "created_at" : "2011-11-20 21:36:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Eu2Ceyjs",
      "expanded_url" : "http:\/\/instagr.am\/p\/VCwCN\/",
      "display_url" : "instagr.am\/p\/VCwCN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.4996103321, -81.6936707497 ]
  },
  "id_str" : "138368086196748288",
  "text" : "Come on down to West 6th Street! It's the perfect place if...  @ Downtown Cleveland http:\/\/t.co\/Eu2Ceyjs",
  "id" : 138368086196748288,
  "created_at" : "2011-11-20 21:28:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138277868181524481",
  "text" : "5 minutes into Ohio and spotted a Confederate flag! New record!",
  "id" : 138277868181524481,
  "created_at" : "2011-11-20 15:29:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/9BZFcNG4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ysmLA5TqbIY",
      "display_url" : "youtube.com\/watch?v=ysmLA5\u2026"
    }, {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/w0mC4FMN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oZzgAjjuqZM",
      "display_url" : "youtube.com\/watch?v=oZzgAj\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "138072291203489793",
  "geo" : { },
  "id_str" : "138072917178191872",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape dude. watch: http:\/\/t.co\/9BZFcNG4 http:\/\/t.co\/w0mC4FMN",
  "id" : 138072917178191872,
  "in_reply_to_status_id" : 138072291203489793,
  "created_at" : "2011-11-20 01:55:23 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138071879092158465",
  "text" : "Also, going to the Cleveland Browns game tomorrow! At least it's not Detroit!    It's not Detroit!",
  "id" : 138071879092158465,
  "created_at" : "2011-11-20 01:51:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138071622044229633",
  "text" : "Heading to Blue Monk after the Sabres game. Who else is in?",
  "id" : 138071622044229633,
  "created_at" : "2011-11-20 01:50:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 11, 20 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138069879558373377",
  "geo" : { },
  "id_str" : "138070815735427072",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @ivyhurst woot! I'll walk over after.",
  "id" : 138070815735427072,
  "in_reply_to_status_id" : 138069879558373377,
  "created_at" : "2011-11-20 01:47:02 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138069853587243008",
  "text" : "@IselaMariaPhoto future rock star hair, what a boss",
  "id" : 138069853587243008,
  "created_at" : "2011-11-20 01:43:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Scott",
      "screen_name" : "ivyhurst",
      "indices" : [ 11, 20 ],
      "id_str" : "16450420",
      "id" : 16450420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138067612004392960",
  "geo" : { },
  "id_str" : "138069540914475008",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @ivyhurst you guys up for drinks after the game in Elmwood? Blue monk?",
  "id" : 138069540914475008,
  "in_reply_to_status_id" : 138067612004392960,
  "created_at" : "2011-11-20 01:41:58 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sabres",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138045488074194944",
  "text" : "Finally can watch the #Sabres again on TV! Woot!",
  "id" : 138045488074194944,
  "created_at" : "2011-11-20 00:06:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Scott",
      "screen_name" : "textfiles",
      "indices" : [ 3, 13 ],
      "id_str" : "1465481",
      "id" : 1465481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/xIj8FXdl",
      "expanded_url" : "http:\/\/www.openlibrary.org",
      "display_url" : "openlibrary.org"
    } ]
  },
  "geo" : { },
  "id_str" : "138044499447390208",
  "text" : "RT @textfiles: The project is real, it is resilient, it is brilliantly engineered, and it's waiting. http:\/\/t.co\/xIj8FXdl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/xIj8FXdl",
        "expanded_url" : "http:\/\/www.openlibrary.org",
        "display_url" : "openlibrary.org"
      } ]
    },
    "geo" : { },
    "id_str" : "137972088010047488",
    "text" : "The project is real, it is resilient, it is brilliantly engineered, and it's waiting. http:\/\/t.co\/xIj8FXdl",
    "id" : 137972088010047488,
    "created_at" : "2011-11-19 19:14:43 +0000",
    "user" : {
      "name" : "Jason Scott",
      "screen_name" : "textfiles",
      "protected" : false,
      "id_str" : "1465481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000611389472\/eabaeb13befe96decf6785d0aa4cbaa1_normal.png",
      "id" : 1465481,
      "verified" : false
    }
  },
  "id" : 138044499447390208,
  "created_at" : "2011-11-20 00:02:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Star Simpson",
      "screen_name" : "starsandrobots",
      "indices" : [ 0, 15 ],
      "id_str" : "19281751",
      "id" : 19281751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136759163505221633",
  "geo" : { },
  "id_str" : "138025398620528642",
  "in_reply_to_user_id" : 19281751,
  "text" : "@starsandrobots oh no :(",
  "id" : 138025398620528642,
  "in_reply_to_status_id" : 136759163505221633,
  "created_at" : "2011-11-19 22:46:34 +0000",
  "in_reply_to_screen_name" : "starsandrobots",
  "in_reply_to_user_id_str" : "19281751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/138004242324652032\/photo\/1",
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/XCfmq6k8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AepKIJGCAAI0zXc.jpg",
      "id_str" : "138004242328846338",
      "id" : 138004242328846338,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AepKIJGCAAI0zXc.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XCfmq6k8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138004242324652032",
  "text" : "Geddy's idea of cuddling with @ablissfulgal. Climbed up on her. http:\/\/t.co\/XCfmq6k8",
  "id" : 138004242324652032,
  "created_at" : "2011-11-19 21:22:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/p2yc6XPl",
      "expanded_url" : "http:\/\/instagr.am\/p\/U2r_L\/",
      "display_url" : "instagr.am\/p\/U2r_L\/"
    } ]
  },
  "geo" : { },
  "id_str" : "137990593015070720",
  "text" : "Still an awesome game. http:\/\/t.co\/p2yc6XPl",
  "id" : 137990593015070720,
  "created_at" : "2011-11-19 20:28:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/eC2PD1X1",
      "expanded_url" : "http:\/\/instagr.am\/p\/U1zpp\/",
      "display_url" : "instagr.am\/p\/U1zpp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "137966811592392706",
  "text" : "I love this store. http:\/\/t.co\/eC2PD1X1",
  "id" : 137966811592392706,
  "created_at" : "2011-11-19 18:53:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/o8yvaNBM",
      "expanded_url" : "http:\/\/instagr.am\/p\/U1Ynp\/",
      "display_url" : "instagr.am\/p\/U1Ynp\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.914934, -78.763552 ]
  },
  "id_str" : "137954072463556608",
  "text" : "Sampler!  @ Gordon Biersch Brewery http:\/\/t.co\/o8yvaNBM",
  "id" : 137954072463556608,
  "created_at" : "2011-11-19 18:03:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137940015832506369",
  "text" : "Found a demo of Skyward Sword. DO WANT.",
  "id" : 137940015832506369,
  "created_at" : "2011-11-19 17:07:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/137759850720542720\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/CShUBP2k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aelr2rbCQAAfVve.jpg",
      "id_str" : "137759850724737024",
      "id" : 137759850724737024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aelr2rbCQAAfVve.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/CShUBP2k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137759850720542720",
  "text" : "58 pointer, 4 meeple castle against Frank. Dang! http:\/\/t.co\/CShUBP2k",
  "id" : 137759850720542720,
  "created_at" : "2011-11-19 05:11:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Miceli",
      "screen_name" : "CarlosMiceli",
      "indices" : [ 0, 13 ],
      "id_str" : "16328049",
      "id" : 16328049
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sinatra",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/qQdKwaOP",
      "expanded_url" : "http:\/\/irc.freenode.net",
      "display_url" : "irc.freenode.net"
    } ]
  },
  "in_reply_to_status_id_str" : "137489586451529730",
  "geo" : { },
  "id_str" : "137593961094197248",
  "in_reply_to_user_id" : 16328049,
  "text" : "@CarlosMiceli i think stackoverflow or http:\/\/t.co\/qQdKwaOP \/ #sinatra is a better channel for these ;)",
  "id" : 137593961094197248,
  "in_reply_to_status_id" : 137489586451529730,
  "created_at" : "2011-11-18 18:12:11 +0000",
  "in_reply_to_screen_name" : "CarlosMiceli",
  "in_reply_to_user_id_str" : "16328049",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137556694757675009",
  "geo" : { },
  "id_str" : "137593820505321473",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors D: was heads down...next week bro!",
  "id" : 137593820505321473,
  "in_reply_to_status_id" : 137556694757675009,
  "created_at" : "2011-11-18 18:11:37 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137356568944582656",
  "geo" : { },
  "id_str" : "137357770495242240",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 i know, and @ablissfulgal smoked me 2 games - 1 D:",
  "id" : 137357770495242240,
  "in_reply_to_status_id" : 137356568944582656,
  "created_at" : "2011-11-18 02:33:39 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137354591686762496",
  "geo" : { },
  "id_str" : "137355530552348672",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 yeah! it lives again!",
  "id" : 137355530552348672,
  "in_reply_to_status_id" : 137354591686762496,
  "created_at" : "2011-11-18 02:24:45 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137342037665136641",
  "geo" : { },
  "id_str" : "137348396523589632",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck he's a fire captain though. Lol",
  "id" : 137348396523589632,
  "in_reply_to_status_id" : 137342037665136641,
  "created_at" : "2011-11-18 01:56:24 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/tgz6EkCs",
      "expanded_url" : "http:\/\/instagr.am\/p\/UmKJY\/",
      "display_url" : "instagr.am\/p\/UmKJY\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.919957, -78.876986 ]
  },
  "id_str" : "137342006136537088",
  "text" : "Air hockey in my house! Now I need a pool table.  @ Elmwood Village http:\/\/t.co\/tgz6EkCs",
  "id" : 137342006136537088,
  "created_at" : "2011-11-18 01:31:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137321843089620993",
  "geo" : { },
  "id_str" : "137339025760587776",
  "in_reply_to_user_id" : 14308987,
  "text" : "@deryldoucette damn that's far! Figured it would be in Niagara.",
  "id" : 137339025760587776,
  "in_reply_to_status_id" : 137321843089620993,
  "created_at" : "2011-11-18 01:19:10 +0000",
  "in_reply_to_screen_name" : "daviddwdowney",
  "in_reply_to_user_id_str" : "14308987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137338720406880256",
  "text" : "Learned my dad is called Captain at work. I've watched too much Star Trek for this not be awesome.",
  "id" : 137338720406880256,
  "created_at" : "2011-11-18 01:17:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137317288188710912",
  "geo" : { },
  "id_str" : "137338214573813762",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton or you joined too many tables ?",
  "id" : 137338214573813762,
  "in_reply_to_status_id" : 137317288188710912,
  "created_at" : "2011-11-18 01:15:56 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137317681597657088",
  "geo" : { },
  "id_str" : "137338012425129984",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw just a heads up!",
  "id" : 137338012425129984,
  "in_reply_to_status_id" : 137317681597657088,
  "created_at" : "2011-11-18 01:15:08 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0ydNgPEb",
      "expanded_url" : "http:\/\/instagr.am\/p\/UljrU\/",
      "display_url" : "instagr.am\/p\/UljrU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.880931, -78.877225 ]
  },
  "id_str" : "137320674896265216",
  "text" : "Lake Effect Ale!  @ Pearl Street Grill & Brewery http:\/\/t.co\/0ydNgPEb",
  "id" : 137320674896265216,
  "created_at" : "2011-11-18 00:06:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137271428000124928",
  "geo" : { },
  "id_str" : "137271769479389184",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape oh shit dude :(",
  "id" : 137271769479389184,
  "in_reply_to_status_id" : 137271428000124928,
  "created_at" : "2011-11-17 20:51:54 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137258078763622400",
  "text" : "SNOOOOOOOWWWWW!!!!!",
  "id" : 137258078763622400,
  "created_at" : "2011-11-17 19:57:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/NOqPQI1c",
      "expanded_url" : "http:\/\/instagr.am\/p\/UjygM\/",
      "display_url" : "instagr.am\/p\/UjygM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9197060667, -78.876986 ]
  },
  "id_str" : "137256513709420544",
  "text" : "SNOW!!!!  @ Elmwood Village http:\/\/t.co\/NOqPQI1c",
  "id" : 137256513709420544,
  "created_at" : "2011-11-17 19:51:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 23, 33 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137226064199041024",
  "geo" : { },
  "id_str" : "137244789128175616",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy yay! thank @stevelosh though, he pointed it out :)",
  "id" : 137244789128175616,
  "in_reply_to_status_id" : 137226064199041024,
  "created_at" : "2011-11-17 19:04:42 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/PwrPIxNF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RFDW9b_ejfI",
      "display_url" : "youtube.com\/watch?v=RFDW9b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "137174647396511745",
  "text" : "Today is brought to you by: http:\/\/t.co\/PwrPIxNF",
  "id" : 137174647396511745,
  "created_at" : "2011-11-17 14:25:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137032917972037632",
  "text" : "I'm going to make a social network where everyone automatically follows each other. No friending, circles or +1 nonsense. GET BUSY.",
  "id" : 137032917972037632,
  "created_at" : "2011-11-17 05:02:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/n1F7uwcf",
      "expanded_url" : "https:\/\/rubygems.org\/gems\/bullshit",
      "display_url" : "rubygems.org\/gems\/bullshit"
    }, {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/N8wcr8eS",
      "expanded_url" : "https:\/\/rubygems.org\/gems\/json",
      "display_url" : "rubygems.org\/gems\/json"
    } ]
  },
  "geo" : { },
  "id_str" : "136672200152465408",
  "text" : "Seriously? http:\/\/t.co\/n1F7uwcf is a dev dependency on http:\/\/t.co\/N8wcr8eS? Cmon, really?",
  "id" : 136672200152465408,
  "created_at" : "2011-11-16 05:09:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiskotten",
      "screen_name" : "doctorzaius",
      "indices" : [ 0, 12 ],
      "id_str" : "15294983",
      "id" : 15294983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136669107033612288",
  "geo" : { },
  "id_str" : "136671380841304064",
  "in_reply_to_user_id" : 15294983,
  "text" : "@doctorzaius FEELINGS OF SADNESS AND LONGING FOR WAFTING SCENTS OF URINE ON MASS TRANSIT LINES",
  "id" : 136671380841304064,
  "in_reply_to_status_id" : 136669107033612288,
  "created_at" : "2011-11-16 05:06:11 +0000",
  "in_reply_to_screen_name" : "doctorzaius",
  "in_reply_to_user_id_str" : "15294983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136665274664497152",
  "text" : "Seriously, WNY Ruby was great tonight. Beer + rubyists = win!",
  "id" : 136665274664497152,
  "created_at" : "2011-11-16 04:41:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136664001101832192",
  "text" : "git fetch\nYou don't exist, go away!\n\nwtf?",
  "id" : 136664001101832192,
  "created_at" : "2011-11-16 04:36:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pickett",
      "screen_name" : "dpickett",
      "indices" : [ 0, 9 ],
      "id_str" : "1364461",
      "id" : 1364461
    }, {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 10, 19 ],
      "id_str" : "21431343",
      "id" : 21431343
    }, {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 20, 36 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136657943843180544",
  "geo" : { },
  "id_str" : "136663974035988482",
  "in_reply_to_user_id" : 1364461,
  "text" : "@dpickett @bostonrb @pat_shaughnessy SLIDES\/VIDEO, DO YOU HAS THEM",
  "id" : 136663974035988482,
  "in_reply_to_status_id" : 136657943843180544,
  "created_at" : "2011-11-16 04:36:45 +0000",
  "in_reply_to_screen_name" : "dpickett",
  "in_reply_to_user_id_str" : "1364461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 108, 112 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/qmQQM9eW",
      "expanded_url" : "http:\/\/news.cnet.com\/8301-1023_3-57324275-93\/work-with-the-cool-kids-culture-is-a-weapon-in-2011s-hiring-battle\/",
      "display_url" : "news.cnet.com\/8301-1023_3-57\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "136663419452530688",
  "text" : "This kind of inane garbage is why I'm glad I don't live or work in the Valley\/SF. http:\/\/t.co\/qmQQM9eW (via @dhh)",
  "id" : 136663419452530688,
  "created_at" : "2011-11-16 04:34:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/8be1XgaC",
      "expanded_url" : "http:\/\/instagr.am\/p\/UVVl-\/",
      "display_url" : "instagr.am\/p\/UVVl-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9805709437, -78.8467526436 ]
  },
  "id_str" : "136601577862610944",
  "text" : "Yuengling & Puppies!  @ Caputi's Sheridan Pub http:\/\/t.co\/8be1XgaC",
  "id" : 136601577862610944,
  "created_at" : "2011-11-16 00:28:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "R. Tyler Croy",
      "screen_name" : "agentdero",
      "indices" : [ 8, 18 ],
      "id_str" : "674593",
      "id" : 674593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136455981080117248",
  "geo" : { },
  "id_str" : "136459268021952512",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 @agentdero some days I think rubygems.org makes it too easy ;)",
  "id" : 136459268021952512,
  "in_reply_to_status_id" : 136455981080117248,
  "created_at" : "2011-11-15 15:03:19 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/D8Q5iE2b",
      "expanded_url" : "http:\/\/i.imgur.com\/3yVgV.jpg",
      "display_url" : "i.imgur.com\/3yVgV.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "136252284563750912",
  "text" : "Current status: http:\/\/t.co\/D8Q5iE2b",
  "id" : 136252284563750912,
  "created_at" : "2011-11-15 01:20:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/xvGY6z3E",
      "expanded_url" : "http:\/\/instagr.am\/p\/UM3lk\/",
      "display_url" : "instagr.am\/p\/UM3lk\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9200845, -78.87714529 ]
  },
  "id_str" : "136230931160776704",
  "text" : "Craft beer #3 - Anchor Humming Ale  @ Elmwood Village http:\/\/t.co\/xvGY6z3E",
  "id" : 136230931160776704,
  "created_at" : "2011-11-14 23:55:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Downey",
      "screen_name" : "jonasdowney",
      "indices" : [ 0, 12 ],
      "id_str" : "16454301",
      "id" : 16454301
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 13, 23 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136130872012316675",
  "geo" : { },
  "id_str" : "136133150391812097",
  "in_reply_to_user_id" : 16454301,
  "text" : "@jonasdowney @stevelosh A++++ thanks",
  "id" : 136133150391812097,
  "in_reply_to_status_id" : 136130872012316675,
  "created_at" : "2011-11-14 17:27:26 +0000",
  "in_reply_to_screen_name" : "jonasdowney",
  "in_reply_to_user_id_str" : "16454301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136130350878425088",
  "text" : "Anyone remember that Terms of Service page that had the legalese + nice plain english side by side?",
  "id" : 136130350878425088,
  "created_at" : "2011-11-14 17:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/DB6XqyHU",
      "expanded_url" : "http:\/\/instagr.am\/p\/UKFb0\/",
      "display_url" : "instagr.am\/p\/UKFb0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.888045, -78.87306 ]
  },
  "id_str" : "136118721965064192",
  "text" : "Behold, the penis chair!  @ Main Washington Exchange http:\/\/t.co\/DB6XqyHU",
  "id" : 136118721965064192,
  "created_at" : "2011-11-14 16:30:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135913894337196032",
  "geo" : { },
  "id_str" : "135953759518982144",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps welcome to qrush\/css-haters",
  "id" : 135953759518982144,
  "in_reply_to_status_id" : 135913894337196032,
  "created_at" : "2011-11-14 05:34:36 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135931753243213824",
  "geo" : { },
  "id_str" : "135936295032721408",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit what is this I don't even",
  "id" : 135936295032721408,
  "in_reply_to_status_id" : 135931753243213824,
  "created_at" : "2011-11-14 04:25:12 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hoskings",
      "screen_name" : "ben_h",
      "indices" : [ 0, 6 ],
      "id_str" : "8046732",
      "id" : 8046732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/NJdvuzBF",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "135872923385860096",
  "geo" : { },
  "id_str" : "135876902035529728",
  "in_reply_to_user_id" : 8046732,
  "text" : "@ben_h http:\/\/t.co\/NJdvuzBF please",
  "id" : 135876902035529728,
  "in_reply_to_status_id" : 135872923385860096,
  "created_at" : "2011-11-14 00:29:12 +0000",
  "in_reply_to_screen_name" : "ben_h",
  "in_reply_to_user_id_str" : "8046732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/LPeFuEyp",
      "expanded_url" : "http:\/\/instagr.am\/p\/UEjbC\/",
      "display_url" : "instagr.am\/p\/UEjbC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "135875586143956992",
  "text" : "Craft beer #2 - Kona Fire Rock http:\/\/t.co\/LPeFuEyp",
  "id" : 135875586143956992,
  "created_at" : "2011-11-14 00:23:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/vTU5X8qu",
      "expanded_url" : "http:\/\/instagr.am\/p\/T-0f3\/",
      "display_url" : "instagr.am\/p\/T-0f3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "135699457940520960",
  "text" : "Beautiful fall morning!  @ Buffalo Barkyard - Dog Park http:\/\/t.co\/vTU5X8qu",
  "id" : 135699457940520960,
  "created_at" : "2011-11-13 12:44:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135587066082902016",
  "geo" : { },
  "id_str" : "135588213346680832",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin just drove a truck from Boston =&gt; Buffalo...missed it by 2 weeks T_T",
  "id" : 135588213346680832,
  "in_reply_to_status_id" : 135587066082902016,
  "created_at" : "2011-11-13 05:22:03 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Moore",
      "screen_name" : "sartak",
      "indices" : [ 0, 7 ],
      "id_str" : "6753782",
      "id" : 6753782
    }, {
      "name" : "Emily Donnelly",
      "screen_name" : "ecarlsen912",
      "indices" : [ 8, 20 ],
      "id_str" : "248477732",
      "id" : 248477732
    }, {
      "name" : "Jerry Chen",
      "screen_name" : "jcsalterego",
      "indices" : [ 21, 33 ],
      "id_str" : "14343561",
      "id" : 14343561
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 34, 44 ],
      "id_str" : "15045995",
      "id" : 15045995
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 45, 52 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135584388451799040",
  "geo" : { },
  "id_str" : "135588107205615617",
  "in_reply_to_user_id" : 6753782,
  "text" : "@sartak @ecarlsen912 @jcsalterego @asianmack @lsegal thanks!!",
  "id" : 135588107205615617,
  "in_reply_to_status_id" : 135584388451799040,
  "created_at" : "2011-11-13 05:21:38 +0000",
  "in_reply_to_screen_name" : "sartak",
  "in_reply_to_user_id_str" : "6753782",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135583319747346432",
  "geo" : { },
  "id_str" : "135588013836214272",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape THIS IS A PRUDENT AND WISE INVESTMENT STRATEGY",
  "id" : 135588013836214272,
  "in_reply_to_status_id" : 135583319747346432,
  "created_at" : "2011-11-13 05:21:16 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135583081137586176",
  "text" : "Hey, I'm 24 now!",
  "id" : 135583081137586176,
  "created_at" : "2011-11-13 05:01:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario\u262FAquino",
      "screen_name" : "MarioAquino",
      "indices" : [ 0, 12 ],
      "id_str" : "1321181",
      "id" : 1321181
    }, {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 13, 23 ],
      "id_str" : "14437070",
      "id" : 14437070
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 57, 68 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Rich Kilmer ",
      "screen_name" : "richkilmer",
      "indices" : [ 70, 81 ],
      "id_str" : "798621194",
      "id" : 798621194
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 83, 91 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "David A. Black",
      "screen_name" : "david_a_black",
      "indices" : [ 93, 107 ],
      "id_str" : "9929452",
      "id" : 9929452
    }, {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 109, 119 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135560006912319488",
  "geo" : { },
  "id_str" : "135565080975769600",
  "in_reply_to_user_id" : 1321181,
  "text" : "@MarioAquino @marksands rubycentral pays for it. (thanks @chadfowler, @richkilmer, @evanphx, @david_a_black, @bscofield!)",
  "id" : 135565080975769600,
  "in_reply_to_status_id" : 135560006912319488,
  "created_at" : "2011-11-13 03:50:08 +0000",
  "in_reply_to_screen_name" : "MarioAquino",
  "in_reply_to_user_id_str" : "1321181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 14, 24 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135557694856761344",
  "text" : "On that note, @gemcutter transferred 6.8TB total out in October across S3 and CloudFront. Dang!",
  "id" : 135557694856761344,
  "created_at" : "2011-11-13 03:20:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/TVYtfaIO",
      "expanded_url" : "http:\/\/aws.amazon.com\/sns\/#functionality",
      "display_url" : "aws.amazon.com\/sns\/#functiona\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135551305652510721",
  "text" : "Holy crap, Amazon's pricing chart for SNS references data transfer rate in PB\/month. :O http:\/\/t.co\/TVYtfaIO",
  "id" : 135551305652510721,
  "created_at" : "2011-11-13 02:55:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135539736138874880",
  "text" : "Are there any good iOS apps for email? Don't say Mail.",
  "id" : 135539736138874880,
  "created_at" : "2011-11-13 02:09:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 37, 51 ],
      "id_str" : "10293122",
      "id" : 10293122
    }, {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 56, 63 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135538415847477248",
  "text" : "Seriously epic Carcassone games with @joshuaclayton and @tekkub lately. Worth all $10 for this iOS game.",
  "id" : 135538415847477248,
  "created_at" : "2011-11-13 02:04:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135537120667373569",
  "geo" : { },
  "id_str" : "135537373969793024",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv I can't unfavorite this tweet",
  "id" : 135537373969793024,
  "in_reply_to_status_id" : 135537120667373569,
  "created_at" : "2011-11-13 02:00:02 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135531049638825985",
  "geo" : { },
  "id_str" : "135536885228503040",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv no cable yet...:(",
  "id" : 135536885228503040,
  "in_reply_to_status_id" : 135531049638825985,
  "created_at" : "2011-11-13 01:58:06 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/jgGHfInc",
      "expanded_url" : "http:\/\/instagr.am\/p\/T4lTN\/",
      "display_url" : "instagr.am\/p\/T4lTN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "135494621743689728",
  "text" : "Craft beer birthday thanks to @ablissfulgal! Innis & Gunn first. http:\/\/t.co\/jgGHfInc",
  "id" : 135494621743689728,
  "created_at" : "2011-11-12 23:10:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil LaPier",
      "screen_name" : "phillapier",
      "indices" : [ 0, 11 ],
      "id_str" : "14555937",
      "id" : 14555937
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/135442167652028416\/photo\/1",
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/7k0WeRJ9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AeEv7xLCEAADwnQ.jpg",
      "id_str" : "135442167656222720",
      "id" : 135442167656222720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeEv7xLCEAADwnQ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7k0WeRJ9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135439119764557824",
  "geo" : { },
  "id_str" : "135442167652028416",
  "in_reply_to_user_id" : 14555937,
  "text" : "@phillapier this pup is totally wiped out after the trip to our dog park :) http:\/\/t.co\/7k0WeRJ9",
  "id" : 135442167652028416,
  "in_reply_to_status_id" : 135439119764557824,
  "created_at" : "2011-11-12 19:41:44 +0000",
  "in_reply_to_screen_name" : "phillapier",
  "in_reply_to_user_id_str" : "14555937",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135172977074520064",
  "geo" : { },
  "id_str" : "135193184321011713",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 yep! We should go on a walk with the pup before it gets too cold!",
  "id" : 135193184321011713,
  "in_reply_to_status_id" : 135172977074520064,
  "created_at" : "2011-11-12 03:12:21 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135169309726089216",
  "geo" : { },
  "id_str" : "135169514986934272",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 good luck dude! I'd love to learn how to play someday",
  "id" : 135169514986934272,
  "in_reply_to_status_id" : 135169309726089216,
  "created_at" : "2011-11-12 01:38:18 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135155198950776832",
  "text" : "2nd opt out at the airport. No yelling this time at me, much more groin touching. Rubbed my head too, what a nice chap!",
  "id" : 135155198950776832,
  "created_at" : "2011-11-12 00:41:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Grzesiak",
      "screen_name" : "listrophy",
      "indices" : [ 0, 10 ],
      "id_str" : "1949721",
      "id" : 1949721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135134336398802944",
  "geo" : { },
  "id_str" : "135140154183659520",
  "in_reply_to_user_id" : 1949721,
  "text" : "@listrophy until you realize it has different flags, and behaviors across 'nix versions",
  "id" : 135140154183659520,
  "in_reply_to_status_id" : 135134336398802944,
  "created_at" : "2011-11-11 23:41:38 +0000",
  "in_reply_to_screen_name" : "listrophy",
  "in_reply_to_user_id_str" : "1949721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135124855057162240",
  "geo" : { },
  "id_str" : "135128162584633344",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit PLEASE TO VISIT WHEN IN THE BUFFALO",
  "id" : 135128162584633344,
  "in_reply_to_status_id" : 135124855057162240,
  "created_at" : "2011-11-11 22:53:59 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 10, 19 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "drock manfred",
      "screen_name" : "dmansen",
      "indices" : [ 20, 28 ],
      "id_str" : "22682102",
      "id" : 22682102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/1Br3m5T6",
      "expanded_url" : "http:\/\/livingsocial.com\/adventures\/146799-shootin-+-drinkin",
      "display_url" : "livingsocial.com\/adventures\/146\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135117475867131904",
  "text" : "Attention @marcweil @dmansen http:\/\/t.co\/1Br3m5T6",
  "id" : 135117475867131904,
  "created_at" : "2011-11-11 22:11:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/1FaG53bK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ey2L_ExKWuI",
      "display_url" : "youtube.com\/watch?v=ey2L_E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135103145637445632",
  "text" : "Current status: http:\/\/t.co\/1FaG53bK",
  "id" : 135103145637445632,
  "created_at" : "2011-11-11 21:14:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 0, 11 ],
      "id_str" : "14114392",
      "id" : 14114392
    }, {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 12, 22 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135022302315298818",
  "in_reply_to_user_id" : 14114392,
  "text" : "@thoughtbot @mikeburns haha, thanks for the post! \u00A1Viva la NIOS! :D",
  "id" : 135022302315298818,
  "created_at" : "2011-11-11 15:53:20 +0000",
  "in_reply_to_screen_name" : "thoughtbot",
  "in_reply_to_user_id_str" : "14114392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StylePedant.erl",
      "screen_name" : "seancribbs",
      "indices" : [ 0, 11 ],
      "id_str" : "14939200",
      "id" : 14939200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134985321401163776",
  "geo" : { },
  "id_str" : "134992396810330115",
  "in_reply_to_user_id" : 14939200,
  "text" : "@seancribbs neither. composition.",
  "id" : 134992396810330115,
  "in_reply_to_status_id" : 134985321401163776,
  "created_at" : "2011-11-11 13:54:30 +0000",
  "in_reply_to_screen_name" : "seancribbs",
  "in_reply_to_user_id_str" : "14939200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 6, 15 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134773294002999297",
  "geo" : { },
  "id_str" : "134775720688889856",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k @ubuwaits you two were meant for each other",
  "id" : 134775720688889856,
  "in_reply_to_status_id" : 134773294002999297,
  "created_at" : "2011-11-10 23:33:30 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134702554201333761",
  "geo" : { },
  "id_str" : "134702646211788801",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo awesome! thanks.",
  "id" : 134702646211788801,
  "in_reply_to_status_id" : 134702554201333761,
  "created_at" : "2011-11-10 18:43:08 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/JFiH7lHY",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2011\/11\/the-idea-of-buffalo.html",
      "display_url" : "buffalorising.com\/2011\/11\/the-id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134702588250689536",
  "text" : "Seriously good article about why returning to Buffalo is worth it. My feelings, exactly. http:\/\/t.co\/JFiH7lHY",
  "id" : 134702588250689536,
  "created_at" : "2011-11-10 18:42:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/EwNCMwGe",
      "expanded_url" : "http:\/\/www.buffalorising.com\/2011\/11\/the-idea-of-buffalo.html",
      "display_url" : "buffalorising.com\/2011\/11\/the-id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134701985529212928",
  "text" : "RT @BuffaloRising: A must-read post from Mike Farrell on \"The Idea of Buffalo\" http:\/\/t.co\/EwNCMwGe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/EwNCMwGe",
        "expanded_url" : "http:\/\/www.buffalorising.com\/2011\/11\/the-idea-of-buffalo.html",
        "display_url" : "buffalorising.com\/2011\/11\/the-id\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "134701466177904640",
    "text" : "A must-read post from Mike Farrell on \"The Idea of Buffalo\" http:\/\/t.co\/EwNCMwGe",
    "id" : 134701466177904640,
    "created_at" : "2011-11-10 18:38:26 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 134701985529212928,
  "created_at" : "2011-11-10 18:40:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 0, 5 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134700623135379456",
  "geo" : { },
  "id_str" : "134700846184271872",
  "in_reply_to_user_id" : 2247381,
  "text" : "@popo oh nice! is that a new place?",
  "id" : 134700846184271872,
  "in_reply_to_status_id" : 134700623135379456,
  "created_at" : "2011-11-10 18:35:59 +0000",
  "in_reply_to_screen_name" : "popo",
  "in_reply_to_user_id_str" : "2247381",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134673453256155136",
  "text" : "\"This compiled and installed on my machine the first try!\" - No one, ever.",
  "id" : 134673453256155136,
  "created_at" : "2011-11-10 16:47:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134646921380900864",
  "text" : "I used pianobar for so long I forgot that Pandora had a refresh of their site.",
  "id" : 134646921380900864,
  "created_at" : "2011-11-10 15:01:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134344487680999424",
  "geo" : { },
  "id_str" : "134502762707820544",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw A++++++",
  "id" : 134502762707820544,
  "in_reply_to_status_id" : 134344487680999424,
  "created_at" : "2011-11-10 05:28:52 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiki Aardsma",
      "screen_name" : "kikiaards",
      "indices" : [ 0, 10 ],
      "id_str" : "355473809",
      "id" : 355473809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/ArLANbqy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=NvSmRGvKPDQ",
      "display_url" : "youtube.com\/watch?v=NvSmRG\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "134478144538292225",
  "geo" : { },
  "id_str" : "134481453235978240",
  "in_reply_to_user_id" : 355473809,
  "text" : "@kikiaards this is relevant to your interests http:\/\/t.co\/ArLANbqy",
  "id" : 134481453235978240,
  "in_reply_to_status_id" : 134478144538292225,
  "created_at" : "2011-11-10 04:04:11 +0000",
  "in_reply_to_screen_name" : "kikiaards",
  "in_reply_to_user_id_str" : "355473809",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134476054696951811",
  "text" : "Do you think Henry Ford said \"Horses are ripe for disruption\" in a press release?",
  "id" : 134476054696951811,
  "created_at" : "2011-11-10 03:42:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134038093866074112",
  "text" : "Rack::File::F. Yep. Rack::File::F.",
  "id" : 134038093866074112,
  "created_at" : "2011-11-08 22:42:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133993098492641282",
  "geo" : { },
  "id_str" : "134002465673723904",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic not this week!",
  "id" : 134002465673723904,
  "in_reply_to_status_id" : 133993098492641282,
  "created_at" : "2011-11-08 20:20:52 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 3, 13 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/YnCv7YrC",
      "expanded_url" : "http:\/\/maps.google.com\/maps\/place?q=Caputi's+Sheridan+Pub,+Sheridan+Drive,+Tonawanda,+NY&hl=en&cid=9404276445068264936",
      "display_url" : "maps.google.com\/maps\/place?q=C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134000647166103553",
  "text" : "RT @aspleenic: This month's #WNYRuby meetup is at Caputi's ( http:\/\/t.co\/YnCv7YrC ) is Tuesday Nov. 15th - ALL HACKERS WELCOME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/YnCv7YrC",
        "expanded_url" : "http:\/\/maps.google.com\/maps\/place?q=Caputi's+Sheridan+Pub,+Sheridan+Drive,+Tonawanda,+NY&hl=en&cid=9404276445068264936",
        "display_url" : "maps.google.com\/maps\/place?q=C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "134000520766570499",
    "text" : "This month's #WNYRuby meetup is at Caputi's ( http:\/\/t.co\/YnCv7YrC ) is Tuesday Nov. 15th - ALL HACKERS WELCOME",
    "id" : 134000520766570499,
    "created_at" : "2011-11-08 20:13:08 +0000",
    "user" : {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "protected" : false,
      "id_str" : "31435721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430802777262940160\/IQX2XojB_normal.png",
      "id" : 31435721,
      "verified" : false
    }
  },
  "id" : 134000647166103553,
  "created_at" : "2011-11-08 20:13:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133953015563567104",
  "geo" : { },
  "id_str" : "133982250625810432",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich it overrode self.new *AFTER* having a `def initialize`. quite weird.",
  "id" : 133982250625810432,
  "in_reply_to_status_id" : 133953015563567104,
  "created_at" : "2011-11-08 19:00:32 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 67, 74 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133910606796431360",
  "geo" : { },
  "id_str" : "133918271173963776",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant I almost wish your avatar changed to a wolf for this \/cc @jyurek",
  "id" : 133918271173963776,
  "in_reply_to_status_id" : 133910606796431360,
  "created_at" : "2011-11-08 14:46:18 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dane Harrigan",
      "screen_name" : "daneharrigan",
      "indices" : [ 0, 13 ],
      "id_str" : "26848546",
      "id" : 26848546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133768445987786752",
  "geo" : { },
  "id_str" : "133770663210135552",
  "in_reply_to_user_id" : 26848546,
  "text" : "@daneharrigan that is one of many insane twists that codebase has. yay!!!",
  "id" : 133770663210135552,
  "in_reply_to_status_id" : 133768445987786752,
  "created_at" : "2011-11-08 04:59:46 +0000",
  "in_reply_to_screen_name" : "daneharrigan",
  "in_reply_to_user_id_str" : "26848546",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/G5aLQeOp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8E29c3a_5iE",
      "display_url" : "youtube.com\/watch?v=8E29c3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133769908143144960",
  "text" : "Best grape suit reporter, ever. http:\/\/t.co\/G5aLQeOp",
  "id" : 133769908143144960,
  "created_at" : "2011-11-08 04:56:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gabegl\u00F6vesy\u00F6u",
      "screen_name" : "gabeglovesyou",
      "indices" : [ 0, 14 ],
      "id_str" : "14465929",
      "id" : 14465929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133741570649362432",
  "geo" : { },
  "id_str" : "133742594088894465",
  "in_reply_to_user_id" : 14465929,
  "text" : "@gabeglovesyou i giggled way too much at this",
  "id" : 133742594088894465,
  "in_reply_to_status_id" : 133741570649362432,
  "created_at" : "2011-11-08 03:08:13 +0000",
  "in_reply_to_screen_name" : "gabeglovesyou",
  "in_reply_to_user_id_str" : "14465929",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lyon",
      "screen_name" : "daveisonthego",
      "indices" : [ 0, 14 ],
      "id_str" : "7463152",
      "id" : 7463152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133733152635101186",
  "geo" : { },
  "id_str" : "133738117747326976",
  "in_reply_to_user_id" : 7463152,
  "text" : "@daveisonthego when does this usually go until?",
  "id" : 133738117747326976,
  "in_reply_to_status_id" : 133733152635101186,
  "created_at" : "2011-11-08 02:50:26 +0000",
  "in_reply_to_screen_name" : "daveisonthego",
  "in_reply_to_user_id_str" : "7463152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133731429451436034",
  "geo" : { },
  "id_str" : "133732224439820288",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato DEALT WITH",
  "id" : 133732224439820288,
  "in_reply_to_status_id" : 133731429451436034,
  "created_at" : "2011-11-08 02:27:01 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Srdjan Pejic",
      "screen_name" : "batasrki",
      "indices" : [ 0, 9 ],
      "id_str" : "1649221",
      "id" : 1649221
    }, {
      "name" : "Dan Kubb",
      "screen_name" : "dkubb",
      "indices" : [ 10, 16 ],
      "id_str" : "6148812",
      "id" : 6148812
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 17, 26 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/9CKXfGoC",
      "expanded_url" : "https:\/\/github.com\/rails\/rails\/blob\/2-3-stable\/activesupport\/lib\/active_support\/values\/time_zone.rb#L310",
      "display_url" : "github.com\/rails\/rails\/bl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "133681957371514881",
  "geo" : { },
  "id_str" : "133712977764417537",
  "in_reply_to_user_id" : 1649221,
  "text" : "@batasrki @dkubb @marcweil check out L310 and L181: http:\/\/t.co\/9CKXfGoC",
  "id" : 133712977764417537,
  "in_reply_to_status_id" : 133681957371514881,
  "created_at" : "2011-11-08 01:10:32 +0000",
  "in_reply_to_screen_name" : "batasrki",
  "in_reply_to_user_id_str" : "1649221",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133712471188979712",
  "geo" : { },
  "id_str" : "133712702928457729",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit whaaa?",
  "id" : 133712702928457729,
  "in_reply_to_status_id" : 133712471188979712,
  "created_at" : "2011-11-08 01:09:27 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "initialize",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/g25LSlLL",
      "expanded_url" : "http:\/\/static.rubycentral.org\/IE%20I%20AM%20DISAPPOINT.png",
      "display_url" : "static.rubycentral.org\/IE%20I%20AM%20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133680147697111040",
  "text" : "Dear Ruby classes that redefine their #initialize methods: http:\/\/t.co\/g25LSlLL",
  "id" : 133680147697111040,
  "created_at" : "2011-11-07 23:00:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiolanda gimenez",
      "screen_name" : "HGimenez",
      "indices" : [ 0, 9 ],
      "id_str" : "729936824",
      "id" : 729936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133561030122024960",
  "geo" : { },
  "id_str" : "133570389199683586",
  "in_reply_to_user_id" : 24425454,
  "text" : "@hgimenez sick!",
  "id" : 133570389199683586,
  "in_reply_to_status_id" : 133561030122024960,
  "created_at" : "2011-11-07 15:43:57 +0000",
  "in_reply_to_screen_name" : "hgmnz",
  "in_reply_to_user_id_str" : "24425454",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133394786190241792",
  "geo" : { },
  "id_str" : "133402555035303936",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt do you actually program along with all your complaining ? ;)",
  "id" : 133402555035303936,
  "in_reply_to_status_id" : 133394786190241792,
  "created_at" : "2011-11-07 04:37:02 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133375681571725312",
  "geo" : { },
  "id_str" : "133376603672686593",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh I seriously doubt this guy has even tried to write\/deploy a single line of CS or even convert existing code",
  "id" : 133376603672686593,
  "in_reply_to_status_id" : 133375681571725312,
  "created_at" : "2011-11-07 02:53:54 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133368882894340096",
  "geo" : { },
  "id_str" : "133371664871325696",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik maybe someone from your HS works for collegehumor? Could ask them to....reface it",
  "id" : 133371664871325696,
  "in_reply_to_status_id" : 133368882894340096,
  "created_at" : "2011-11-07 02:34:17 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133366405323173888",
  "geo" : { },
  "id_str" : "133368782453346304",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik also you could be a meme, cheer up!",
  "id" : 133368782453346304,
  "in_reply_to_status_id" : 133366405323173888,
  "created_at" : "2011-11-07 02:22:50 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133366405323173888",
  "geo" : { },
  "id_str" : "133368688643547136",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik you're a PIMP",
  "id" : 133368688643547136,
  "in_reply_to_status_id" : 133366405323173888,
  "created_at" : "2011-11-07 02:22:27 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133368145346953217",
  "geo" : { },
  "id_str" : "133368420803674113",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham brew install vim?",
  "id" : 133368420803674113,
  "in_reply_to_status_id" : 133368145346953217,
  "created_at" : "2011-11-07 02:21:24 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133300445648125953",
  "geo" : { },
  "id_str" : "133300851409301504",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil now wait until the next DST change! :P",
  "id" : 133300851409301504,
  "in_reply_to_status_id" : 133300445648125953,
  "created_at" : "2011-11-06 21:52:54 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Graham",
      "screen_name" : "grahams",
      "indices" : [ 0, 8 ],
      "id_str" : "758727",
      "id" : 758727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133299464457814016",
  "geo" : { },
  "id_str" : "133300412978704384",
  "in_reply_to_user_id" : 758727,
  "text" : "@grahams my favorite hobby with this is seeing if the restaurants are still open. Usually no.",
  "id" : 133300412978704384,
  "in_reply_to_status_id" : 133299464457814016,
  "created_at" : "2011-11-06 21:51:09 +0000",
  "in_reply_to_screen_name" : "grahams",
  "in_reply_to_user_id_str" : "758727",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133297222778486785",
  "geo" : { },
  "id_str" : "133300235320565760",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil tested ? (my guess is unchecked)",
  "id" : 133300235320565760,
  "in_reply_to_status_id" : 133297222778486785,
  "created_at" : "2011-11-06 21:50:27 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133273251014119424",
  "text" : "Rereading Getting Real and watching the Bills. Couldn't be any better!",
  "id" : 133273251014119424,
  "created_at" : "2011-11-06 20:03:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 43, 47 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/o4TYHaOp",
      "expanded_url" : "http:\/\/twitter.com\/pat\/statuses\/133150917049585664",
      "display_url" : "twitter.com\/pat\/statuses\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133153779477524480",
  "text" : "Awesome deep dive into building a gem from @pat: http:\/\/t.co\/o4TYHaOp",
  "id" : 133153779477524480,
  "created_at" : "2011-11-06 12:08:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133119086996627456",
  "geo" : { },
  "id_str" : "133143660622643200",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat would love to see these slides at some point !",
  "id" : 133143660622643200,
  "in_reply_to_status_id" : 133119086996627456,
  "created_at" : "2011-11-06 11:28:17 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133142967350345728",
  "text" : "Also have learned this week that if you stay at the dog park for more than an hour, this pup literally sleeps ALL DAY.",
  "id" : 133142967350345728,
  "created_at" : "2011-11-06 11:25:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133142645211017216",
  "text" : "PUPPY, Y U NO FALL BACK AN HOUR",
  "id" : 133142645211017216,
  "created_at" : "2011-11-06 11:24:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/5W93JrmD",
      "expanded_url" : "http:\/\/instagr.am\/p\/S4AjI\/",
      "display_url" : "instagr.am\/p\/S4AjI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "132912531567161344",
  "text" : "OPQRSTU? http:\/\/t.co\/5W93JrmD",
  "id" : 132912531567161344,
  "created_at" : "2011-11-05 20:09:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132875226584322049",
  "geo" : { },
  "id_str" : "132883618057035777",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety just use the straight up mongo ruby driver, mongoid lets you fall into a relational trap too easily",
  "id" : 132883618057035777,
  "in_reply_to_status_id" : 132875226584322049,
  "created_at" : "2011-11-05 18:14:58 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/gWSpDybW",
      "expanded_url" : "http:\/\/instagr.am\/p\/S29TA\/",
      "display_url" : "instagr.am\/p\/S29TA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "132881653856079872",
  "text" : "Taking notes http:\/\/t.co\/gWSpDybW",
  "id" : 132881653856079872,
  "created_at" : "2011-11-05 18:07:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132836399199174656",
  "text" : "Walked down to the Bidwell Market, got cider, apples, and STEAK. Dog did great but loved to howl at every other dog until he met them.",
  "id" : 132836399199174656,
  "created_at" : "2011-11-05 15:07:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132806861165568000",
  "geo" : { },
  "id_str" : "132836209889255426",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude nope not that time!",
  "id" : 132836209889255426,
  "in_reply_to_status_id" : 132806861165568000,
  "created_at" : "2011-11-05 15:06:35 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 0, 7 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132706214785187840",
  "geo" : { },
  "id_str" : "132786234396385280",
  "in_reply_to_user_id" : 224887329,
  "text" : "@gabebw IF YOU CAN BELIEVE!!!",
  "id" : 132786234396385280,
  "in_reply_to_status_id" : 132706214785187840,
  "created_at" : "2011-11-05 11:47:59 +0000",
  "in_reply_to_screen_name" : "gabebw",
  "in_reply_to_user_id_str" : "224887329",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132633336584740864",
  "text" : "First visit to Blue Monk. Holy crap I can walk to this.",
  "id" : 132633336584740864,
  "created_at" : "2011-11-05 01:40:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert Goet",
      "screen_name" : "gertgoet",
      "indices" : [ 0, 9 ],
      "id_str" : "22762300",
      "id" : 22762300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132506895683563520",
  "geo" : { },
  "id_str" : "132561966538567680",
  "in_reply_to_user_id" : 22762300,
  "text" : "@gertgoet pingdom reported no downtime. Wtf?",
  "id" : 132561966538567680,
  "in_reply_to_status_id" : 132506895683563520,
  "created_at" : "2011-11-04 20:56:50 +0000",
  "in_reply_to_screen_name" : "gertgoet",
  "in_reply_to_user_id_str" : "22762300",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132557870876213249",
  "geo" : { },
  "id_str" : "132558265753157632",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire oh man want to grab a drink before the game?",
  "id" : 132558265753157632,
  "in_reply_to_status_id" : 132557870876213249,
  "created_at" : "2011-11-04 20:42:08 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132542529106227201",
  "geo" : { },
  "id_str" : "132550321049309184",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits get spunk drunk",
  "id" : 132550321049309184,
  "in_reply_to_status_id" : 132542529106227201,
  "created_at" : "2011-11-04 20:10:33 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/gMAnqucl",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ssb_c\/",
      "display_url" : "instagr.am\/p\/Ssb_c\/"
    } ]
  },
  "geo" : { },
  "id_str" : "132470910023241729",
  "text" : "What a boss http:\/\/t.co\/gMAnqucl",
  "id" : 132470910023241729,
  "created_at" : "2011-11-04 14:55:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132304069736931328",
  "text" : "Ok, Tweetbot is gorgeous. I just wish apps had a trial version.",
  "id" : 132304069736931328,
  "created_at" : "2011-11-04 03:52:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ryckbost",
      "screen_name" : "bryckbost",
      "indices" : [ 0, 10 ],
      "id_str" : "8494682",
      "id" : 8494682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132294650336780288",
  "geo" : { },
  "id_str" : "132303742556045312",
  "in_reply_to_user_id" : 8494682,
  "text" : "@bryckbost that's pretty slick.",
  "id" : 132303742556045312,
  "in_reply_to_status_id" : 132294650336780288,
  "created_at" : "2011-11-04 03:50:44 +0000",
  "in_reply_to_screen_name" : "bryckbost",
  "in_reply_to_user_id_str" : "8494682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132290663025881088",
  "geo" : { },
  "id_str" : "132291802706345984",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik this is also why I can't be a consultant. Just drives me nuts to assign dollar values to my time.",
  "id" : 132291802706345984,
  "in_reply_to_status_id" : 132290663025881088,
  "created_at" : "2011-11-04 03:03:18 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132290663025881088",
  "geo" : { },
  "id_str" : "132290995634176000",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik my previous statement still holds.",
  "id" : 132290995634176000,
  "in_reply_to_status_id" : 132290663025881088,
  "created_at" : "2011-11-04 03:00:05 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132285318375276545",
  "geo" : { },
  "id_str" : "132290171516358656",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik WTF does that even mean. I don't assign $ values to my time, I don't think or live that way",
  "id" : 132290171516358656,
  "in_reply_to_status_id" : 132285318375276545,
  "created_at" : "2011-11-04 02:56:49 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Nunnikhoven",
      "screen_name" : "marknca",
      "indices" : [ 0, 8 ],
      "id_str" : "12143922",
      "id" : 12143922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132285171457200128",
  "geo" : { },
  "id_str" : "132290017698648064",
  "in_reply_to_user_id" : 12143922,
  "text" : "@marknca ehhhh I might just deal with TweetDeck then",
  "id" : 132290017698648064,
  "in_reply_to_status_id" : 132285171457200128,
  "created_at" : "2011-11-04 02:56:12 +0000",
  "in_reply_to_screen_name" : "marknca",
  "in_reply_to_user_id_str" : "12143922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/6vwIjNTk",
      "expanded_url" : "http:\/\/instagr.am\/p\/SpGSM\/",
      "display_url" : "instagr.am\/p\/SpGSM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "132289840619323392",
  "text" : "Still the best. http:\/\/t.co\/6vwIjNTk",
  "id" : 132289840619323392,
  "created_at" : "2011-11-04 02:55:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132284398975463425",
  "text" : "Does Tweetbot automatically load conversations? Still trying to justify the price. Not used to paying for apps without free versions.",
  "id" : 132284398975463425,
  "created_at" : "2011-11-04 02:33:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132222803985436672",
  "geo" : { },
  "id_str" : "132246528155860992",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic where is this ?",
  "id" : 132246528155860992,
  "in_reply_to_status_id" : 132222803985436672,
  "created_at" : "2011-11-04 00:03:23 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132204192927461376",
  "geo" : { },
  "id_str" : "132204524449435648",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn PARTY TIME ANONYMOUS MEETING!!?",
  "id" : 132204524449435648,
  "in_reply_to_status_id" : 132204192927461376,
  "created_at" : "2011-11-03 21:16:29 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rufo Sanchez",
      "screen_name" : "rufo",
      "indices" : [ 0, 5 ],
      "id_str" : "710683",
      "id" : 710683
    }, {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 6, 12 ],
      "id_str" : "744613",
      "id" : 744613
    }, {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 13, 19 ],
      "id_str" : "14568910",
      "id" : 14568910
    }, {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 20, 30 ],
      "id_str" : "23374570",
      "id" : 23374570
    }, {
      "name" : "Rich Downie",
      "screen_name" : "richdownie",
      "indices" : [ 31, 42 ],
      "id_str" : "10774712",
      "id" : 10774712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132203824956968960",
  "geo" : { },
  "id_str" : "132204410431475712",
  "in_reply_to_user_id" : 710683,
  "text" : "@rufo @chorn @jfine @jwhitmire @richdownie PLEASE TO VISIT THE RUBY MEETINGS WITH THE FREE BEERS, ENJOY IT MUCHLY YES",
  "id" : 132204410431475712,
  "in_reply_to_status_id" : 132203824956968960,
  "created_at" : "2011-11-03 21:16:02 +0000",
  "in_reply_to_screen_name" : "rufo",
  "in_reply_to_user_id_str" : "710683",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132202122111488000",
  "geo" : { },
  "id_str" : "132202898254856192",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker oh man, looks great! is there any real-time\/webhook stuff? only seeing GET endpoints (polling)",
  "id" : 132202898254856192,
  "in_reply_to_status_id" : 132202122111488000,
  "created_at" : "2011-11-03 21:10:01 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 3, 8 ],
      "id_str" : "33823",
      "id" : 33823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNYRuby",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "ruby",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/Mzh2ru10",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/39827762\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132196417761583104",
  "text" : "RT @jhsu: Next #WNYRuby meet up scheduled for Nov 15th at Caputi's Sheridan Pub http:\/\/t.co\/Mzh2ru10 #ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNYRuby",
        "indices" : [ 5, 13 ]
      }, {
        "text" : "ruby",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/Mzh2ru10",
        "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/39827762\/",
        "display_url" : "meetup.com\/Western-New-Yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "132195873751961600",
    "text" : "Next #WNYRuby meet up scheduled for Nov 15th at Caputi's Sheridan Pub http:\/\/t.co\/Mzh2ru10 #ruby",
    "id" : 132195873751961600,
    "created_at" : "2011-11-03 20:42:07 +0000",
    "user" : {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "protected" : false,
      "id_str" : "33823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448859597818695680\/MySo8-P7_normal.jpeg",
      "id" : 33823,
      "verified" : false
    }
  },
  "id" : 132196417761583104,
  "created_at" : "2011-11-03 20:44:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 0, 5 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/OMYlKOqo",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "in_reply_to_status_id_str" : "131521590050570240",
  "geo" : { },
  "id_str" : "132191587647242240",
  "in_reply_to_user_id" : 15591045,
  "text" : "@tmm1 ah ha, seeing this now. ok, not an ixoth killer, yet. i'm planning to expose webhooks for siri: http:\/\/t.co\/OMYlKOqo",
  "id" : 132191587647242240,
  "in_reply_to_status_id" : 131521590050570240,
  "created_at" : "2011-11-03 20:25:05 +0000",
  "in_reply_to_screen_name" : "tmm1",
  "in_reply_to_user_id_str" : "15591045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Westerink",
      "screen_name" : "davidakachaos",
      "indices" : [ 0, 14 ],
      "id_str" : "6717392",
      "id" : 6717392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132097430014541825",
  "geo" : { },
  "id_str" : "132190624668594176",
  "in_reply_to_user_id" : 6717392,
  "text" : "@davidakachaos not that I'm aware of. Upgrade to bundler 1.1.pre and it will go way faster.",
  "id" : 132190624668594176,
  "in_reply_to_status_id" : 132097430014541825,
  "created_at" : "2011-11-03 20:21:15 +0000",
  "in_reply_to_screen_name" : "davidakachaos",
  "in_reply_to_user_id_str" : "6717392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aman Gupta",
      "screen_name" : "tmm1",
      "indices" : [ 0, 5 ],
      "id_str" : "15591045",
      "id" : 15591045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131470968488071168",
  "geo" : { },
  "id_str" : "132185207326511104",
  "in_reply_to_user_id" : 15591045,
  "text" : "@tmm1 how is this working through wolfram alpha?",
  "id" : 132185207326511104,
  "in_reply_to_status_id" : 131470968488071168,
  "created_at" : "2011-11-03 19:59:43 +0000",
  "in_reply_to_screen_name" : "tmm1",
  "in_reply_to_user_id_str" : "15591045",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132177022867869696",
  "text" : "Coffee shop 5 minutes from my new place has Dogfish 90 on tap and is open way late. AWESOME.",
  "id" : 132177022867869696,
  "created_at" : "2011-11-03 19:27:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 3, 14 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132137314469167104",
  "text" : "RT @shellscape: Google \"Do a Barrel Roll\". If nothing happens, it's time to upgrade your browser",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132136657762783232",
    "text" : "Google \"Do a Barrel Roll\". If nothing happens, it's time to upgrade your browser",
    "id" : 132136657762783232,
    "created_at" : "2011-11-03 16:46:48 +0000",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "protected" : false,
      "id_str" : "16134710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552990084379578368\/tV6fOemg_normal.jpeg",
      "id" : 16134710,
      "verified" : false
    }
  },
  "id" : 132137314469167104,
  "created_at" : "2011-11-03 16:49:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132117759793446912",
  "text" : "Seriously guys, we have enough photo and file sharing apps. Stop it.",
  "id" : 132117759793446912,
  "created_at" : "2011-11-03 15:31:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 12, 17 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132113742946250752",
  "geo" : { },
  "id_str" : "132114759456792576",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @popo in all seriousness it's a terrible idea. You already have to choose a search provider, I can't imagine them forcing G+",
  "id" : 132114759456792576,
  "in_reply_to_status_id" : 132113742946250752,
  "created_at" : "2011-11-03 15:19:47 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard Ritter",
      "screen_name" : "paniq",
      "indices" : [ 3, 9 ],
      "id_str" : "15840592",
      "id" : 15840592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/fUthBWQl",
      "expanded_url" : "https:\/\/www.google.com\/search?q=tilt",
      "display_url" : "google.com\/search?q=tilt"
    } ]
  },
  "geo" : { },
  "id_str" : "132114485216428033",
  "text" : "RT @paniq: http:\/\/t.co\/fUthBWQl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/fUthBWQl",
        "expanded_url" : "https:\/\/www.google.com\/search?q=tilt",
        "display_url" : "google.com\/search?q=tilt"
      } ]
    },
    "geo" : { },
    "id_str" : "132111568820375552",
    "text" : "http:\/\/t.co\/fUthBWQl",
    "id" : 132111568820375552,
    "created_at" : "2011-11-03 15:07:07 +0000",
    "user" : {
      "name" : "Leonard Ritter",
      "screen_name" : "paniq",
      "protected" : false,
      "id_str" : "15840592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545611202974339072\/ISaDskAL_normal.png",
      "id" : 15840592,
      "verified" : false
    }
  },
  "id" : 132114485216428033,
  "created_at" : "2011-11-03 15:18:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Steve Poland",
      "screen_name" : "popo",
      "indices" : [ 12, 17 ],
      "id_str" : "2247381",
      "id" : 2247381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132111419620605953",
  "geo" : { },
  "id_str" : "132112414337540096",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy @popo why stop there, put a +1 button on every keyboard",
  "id" : 132112414337540096,
  "in_reply_to_status_id" : 132111419620605953,
  "created_at" : "2011-11-03 15:10:28 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132110873530609664",
  "text" : "First visit to Spot on Elmwood. Holy crap it got huge!",
  "id" : 132110873530609664,
  "created_at" : "2011-11-03 15:04:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132053671138697216",
  "text" : "Wow, AWS SNS now offers SMS cheaper than Twilio. OH SNAP",
  "id" : 132053671138697216,
  "created_at" : "2011-11-03 11:17:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131940741793587200",
  "geo" : { },
  "id_str" : "131940935616565248",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape fuck you",
  "id" : 131940935616565248,
  "in_reply_to_status_id" : 131940741793587200,
  "created_at" : "2011-11-03 03:49:05 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/5CM1Gosz",
      "expanded_url" : "http:\/\/bostonrb.org\/presentations\/month\/July-2011",
      "display_url" : "bostonrb.org\/presentations\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "131926844499968000",
  "geo" : { },
  "id_str" : "131927027786858496",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil also http:\/\/t.co\/5CM1Gosz",
  "id" : 131927027786858496,
  "in_reply_to_status_id" : 131926844499968000,
  "created_at" : "2011-11-03 02:53:49 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131924389305389056",
  "geo" : { },
  "id_str" : "131924808672882688",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil i dont have experience with any ruby cms directly, but have heard good things about Radiant and Refinery",
  "id" : 131924808672882688,
  "in_reply_to_status_id" : 131924389305389056,
  "created_at" : "2011-11-03 02:45:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131912893770903553",
  "geo" : { },
  "id_str" : "131920629757784064",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox dude you better be playing Tetris Attack",
  "id" : 131920629757784064,
  "in_reply_to_status_id" : 131912893770903553,
  "created_at" : "2011-11-03 02:28:23 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131888409827475458",
  "text" : "Planes in GTAV makes me stupid excited.",
  "id" : 131888409827475458,
  "created_at" : "2011-11-03 00:20:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131726947024773120",
  "geo" : { },
  "id_str" : "131886231003987969",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves good but fucked up utilities...camping with the 'rents tonight",
  "id" : 131886231003987969,
  "in_reply_to_status_id" : 131726947024773120,
  "created_at" : "2011-11-03 00:11:42 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wistow",
      "screen_name" : "deflatermouse",
      "indices" : [ 0, 14 ],
      "id_str" : "9066762",
      "id" : 9066762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131787870766772224",
  "geo" : { },
  "id_str" : "131876995427598336",
  "in_reply_to_user_id" : 9066762,
  "text" : "@deflatermouse If we can improve the Guides more to encourage this I'd love to. Open to more ideas!",
  "id" : 131876995427598336,
  "in_reply_to_status_id" : 131787870766772224,
  "created_at" : "2011-11-02 23:35:00 +0000",
  "in_reply_to_screen_name" : "deflatermouse",
  "in_reply_to_user_id_str" : "9066762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trynity Mirell",
      "screen_name" : "mirell",
      "indices" : [ 0, 7 ],
      "id_str" : "2998829503",
      "id" : 2998829503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131864814216687617",
  "geo" : { },
  "id_str" : "131867712212303874",
  "in_reply_to_user_id" : 12733992,
  "text" : "@mirell AUGGGGHHGHGHHHH",
  "id" : 131867712212303874,
  "in_reply_to_status_id" : 131864814216687617,
  "created_at" : "2011-11-02 22:58:07 +0000",
  "in_reply_to_screen_name" : "evilgaywitch",
  "in_reply_to_user_id_str" : "12733992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131835549945298945",
  "text" : "HelloFax completely fails and rotates images in a random way when uploaded. Fuck faxing.",
  "id" : 131835549945298945,
  "created_at" : "2011-11-02 20:50:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 6, 17 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/131763566746415104\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/4RP0kX9L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdQeRA6CMAAhUei.jpg",
      "id_str" : "131763566750609408",
      "id" : 131763566750609408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdQeRA6CMAAhUei.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/4RP0kX9L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131763566746415104",
  "text" : "Found @tenderlove in Tiny Tower...this is getting creepy http:\/\/t.co\/4RP0kX9L",
  "id" : 131763566746415104,
  "created_at" : "2011-11-02 16:04:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/1EBs5ysR",
      "expanded_url" : "http:\/\/instagr.am\/p\/ScsQt\/",
      "display_url" : "instagr.am\/p\/ScsQt\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8921506518, -78.894828558 ]
  },
  "id_str" : "131726849729511424",
  "text" : "Somehow the dogs didn't eat this one  @ Buffalo Barkyard - Dog Park http:\/\/t.co\/1EBs5ysR",
  "id" : 131726849729511424,
  "created_at" : "2011-11-02 13:38:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131561603404541952",
  "geo" : { },
  "id_str" : "131568057922498560",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh clearly you need TIMECOP",
  "id" : 131568057922498560,
  "in_reply_to_status_id" : 131561603404541952,
  "created_at" : "2011-11-02 03:07:24 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/MRsxnHeX",
      "expanded_url" : "http:\/\/instagr.am\/p\/SZOYD\/",
      "display_url" : "instagr.am\/p\/SZOYD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9200845, -78.87714529 ]
  },
  "id_str" : "131533360706240512",
  "text" : "Current status  @ Elmwood Village http:\/\/t.co\/MRsxnHeX",
  "id" : 131533360706240512,
  "created_at" : "2011-11-02 00:49:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131462143664070656",
  "text" : "Sorry TweetDeck but iOS isn't your forte. Any suggestions for better clients?",
  "id" : 131462143664070656,
  "created_at" : "2011-11-01 20:06:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "indices" : [ 0, 9 ],
      "id_str" : "17137749",
      "id" : 17137749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131445549651083265",
  "geo" : { },
  "id_str" : "131447688913887232",
  "in_reply_to_user_id" : 17137749,
  "text" : "@tzmartin thanks!",
  "id" : 131447688913887232,
  "in_reply_to_status_id" : 131445549651083265,
  "created_at" : "2011-11-01 19:09:05 +0000",
  "in_reply_to_screen_name" : "tzmartin",
  "in_reply_to_user_id_str" : "17137749",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Bair",
      "screen_name" : "renaebair",
      "indices" : [ 0, 10 ],
      "id_str" : "14945269",
      "id" : 14945269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131388217835532289",
  "geo" : { },
  "id_str" : "131397805439844352",
  "in_reply_to_user_id" : 14945269,
  "text" : "@renaebair Barkyard. Autocorrect fail. It's a park.",
  "id" : 131397805439844352,
  "in_reply_to_status_id" : 131388217835532289,
  "created_at" : "2011-11-01 15:50:52 +0000",
  "in_reply_to_screen_name" : "renaebair",
  "in_reply_to_user_id_str" : "14945269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Oynm1an3",
      "expanded_url" : "http:\/\/instagr.am\/p\/SVr8f\/",
      "display_url" : "instagr.am\/p\/SVr8f\/"
    } ]
  },
  "geo" : { },
  "id_str" : "131381199078825984",
  "text" : "Rotated @ The Barkyard http:\/\/t.co\/Oynm1an3",
  "id" : 131381199078825984,
  "created_at" : "2011-11-01 14:44:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/NRLygWPm",
      "expanded_url" : "http:\/\/instagr.am\/p\/SVrlz\/",
      "display_url" : "instagr.am\/p\/SVrlz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "131380763085127680",
  "text" : "Rotated @ Bidwell http:\/\/t.co\/NRLygWPm",
  "id" : 131380763085127680,
  "created_at" : "2011-11-01 14:43:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/TOwnbVzX",
      "expanded_url" : "http:\/\/instagr.am\/p\/SVlx5\/",
      "display_url" : "instagr.am\/p\/SVlx5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "131376669389881344",
  "text" : "The backyard is awesome! http:\/\/t.co\/TOwnbVzX",
  "id" : 131376669389881344,
  "created_at" : "2011-11-01 14:26:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/DFIObsjF",
      "expanded_url" : "http:\/\/instagr.am\/p\/SVRHZ\/",
      "display_url" : "instagr.am\/p\/SVRHZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "131361663730450432",
  "text" : "Made it! http:\/\/t.co\/DFIObsjF",
  "id" : 131361663730450432,
  "created_at" : "2011-11-01 13:27:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131224941315096576",
  "geo" : { },
  "id_str" : "131227469062733824",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt you forgot mapreduce trololololol",
  "id" : 131227469062733824,
  "in_reply_to_status_id" : 131224941315096576,
  "created_at" : "2011-11-01 04:34:01 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Keepers",
      "screen_name" : "bkeepers",
      "indices" : [ 0, 9 ],
      "id_str" : "697893",
      "id" : 697893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130381866145550337",
  "geo" : { },
  "id_str" : "131224237066301440",
  "in_reply_to_user_id" : 697893,
  "text" : "@bkeepers it was 'designed' but that caused confusion and support requests :\/",
  "id" : 131224237066301440,
  "in_reply_to_status_id" : 130381866145550337,
  "created_at" : "2011-11-01 04:21:10 +0000",
  "in_reply_to_screen_name" : "bkeepers",
  "in_reply_to_user_id_str" : "697893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nick  (\u00AC\u00BA-\u00B0)\u00AC",
      "screen_name" : "nickfletchr",
      "indices" : [ 0, 12 ],
      "id_str" : "295805977",
      "id" : 295805977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263745044853452800",
  "geo" : { },
  "id_str" : "263751222052409345",
  "in_reply_to_user_id" : 295805977,
  "text" : "@nickfletchr Thanks! And not going to happen, sorry :)",
  "id" : 263751222052409345,
  "in_reply_to_status_id" : 263745044853452800,
  "created_at" : "2012-10-31 21:16:06 +0000",
  "in_reply_to_screen_name" : "nickfletchr",
  "in_reply_to_user_id_str" : "295805977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263724347460562944",
  "geo" : { },
  "id_str" : "263728172858736640",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle i definitely understand that. it's more heavy duty ops stuff i don't know. strace, how to find out how and why a box is hosed, etc",
  "id" : 263728172858736640,
  "in_reply_to_status_id" : 263724347460562944,
  "created_at" : "2012-10-31 19:44:30 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263722238723883008",
  "geo" : { },
  "id_str" : "263723983780847616",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle i can follow slicehost tutorials pretty well. beyond that i'm not much help.",
  "id" : 263723983780847616,
  "in_reply_to_status_id" : 263722238723883008,
  "created_at" : "2012-10-31 19:27:52 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Block Club",
      "screen_name" : "BlockClub",
      "indices" : [ 128, 138 ],
      "id_str" : "21003240",
      "id" : 21003240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/1HPHQzjf",
      "expanded_url" : "http:\/\/www.buffalo.com\/news\/blog\/young-money-talking-with-patrick-finan-of-block-club-creative\/",
      "display_url" : "buffalo.com\/news\/blog\/youn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263708924123947008",
  "text" : "\"I hope more and more entrepreneurs realize that there\u2019s more to business than making a quick buck.\"  http:\/\/t.co\/1HPHQzjf (via @BlockClub)",
  "id" : 263708924123947008,
  "created_at" : "2012-10-31 18:28:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 32, 43 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 48, 60 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263699825105702913",
  "text" : "Had a lot of fun on InBeta with @kevinpurdy and @ginatrapani yesterday, thanks for having me! (Also, I managed to not swear at all!)",
  "id" : 263699825105702913,
  "created_at" : "2012-10-31 17:51:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/4ljigBPq",
      "expanded_url" : "http:\/\/5by5.tv\/inbeta\/22",
      "display_url" : "5by5.tv\/inbeta\/22"
    } ]
  },
  "geo" : { },
  "id_str" : "263699071317995522",
  "text" : "The Legion of Markdoom! http:\/\/t.co\/4ljigBPq",
  "id" : 263699071317995522,
  "created_at" : "2012-10-31 17:48:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 55, 67 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 88, 94 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iOeGNJwE",
      "expanded_url" : "http:\/\/5by5.tv\/inbeta\/22",
      "display_url" : "5by5.tv\/inbeta\/22"
    } ]
  },
  "geo" : { },
  "id_str" : "263699041320329217",
  "text" : "RT @kevinpurdy: &lt;In Beta&gt; Ep. 22 is up, with me, @ginatrapani, and SPESHIAL GUEST @qrush talking code, community, and Markdown: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 39, 51 ],
        "id_str" : "930061",
        "id" : 930061
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 72, 78 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/iOeGNJwE",
        "expanded_url" : "http:\/\/5by5.tv\/inbeta\/22",
        "display_url" : "5by5.tv\/inbeta\/22"
      } ]
    },
    "geo" : { },
    "id_str" : "263699000736239616",
    "text" : "&lt;In Beta&gt; Ep. 22 is up, with me, @ginatrapani, and SPESHIAL GUEST @qrush talking code, community, and Markdown: http:\/\/t.co\/iOeGNJwE",
    "id" : 263699000736239616,
    "created_at" : "2012-10-31 17:48:35 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 263699041320329217,
  "created_at" : "2012-10-31 17:48:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 58, 70 ],
      "id_str" : "11886642",
      "id" : 11886642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/uvESxsni",
      "expanded_url" : "http:\/\/www.pidgame.com\/index.php?page=videos",
      "display_url" : "pidgame.com\/index.php?page\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263697489155211266",
  "text" : "Most likely found my next game: http:\/\/t.co\/uvESxsni (via @fredyatesiv)",
  "id" : 263697489155211266,
  "created_at" : "2012-10-31 17:42:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263687749616422912",
  "geo" : { },
  "id_str" : "263690185273905152",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 Nope. Triggered the paywall since I wanted to test out if incognito\/private browsing got around it.",
  "id" : 263690185273905152,
  "in_reply_to_status_id" : 263687749616422912,
  "created_at" : "2012-10-31 17:13:33 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    }, {
      "name" : "Cassandra Moffitt",
      "screen_name" : "cassandrarife",
      "indices" : [ 14, 28 ],
      "id_str" : "2585986136",
      "id" : 2585986136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263682707719069696",
  "geo" : { },
  "id_str" : "263682910538854400",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt @cassandrarife uh....",
  "id" : 263682910538854400,
  "in_reply_to_status_id" : 263682707719069696,
  "created_at" : "2012-10-31 16:44:39 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/263672680606216193\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/wci4Tpn3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6jA5_FCMAA5h5a.png",
      "id_str" : "263672680618799104",
      "id" : 263672680618799104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6jA5_FCMAA5h5a.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wci4Tpn3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263672680606216193",
  "text" : "The Buffalo News Paywall is such a fucking joke. New incognito window gets around it. http:\/\/t.co\/wci4Tpn3",
  "id" : 263672680606216193,
  "created_at" : "2012-10-31 16:04:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/263655661257252864\/photo\/1",
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/bJjTBPOj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ixbVDCYAAqqJY.png",
      "id_str" : "263655661265641472",
      "id" : 263655661265641472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ixbVDCYAAqqJY.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/bJjTBPOj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263655789896548352",
  "text" : "MAGICAL BUFFALO NEWS! http:\/\/t.co\/bJjTBPOj",
  "id" : 263655789896548352,
  "created_at" : "2012-10-31 14:56:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/263655661257252864\/photo\/1",
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/bJjTBPOj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ixbVDCYAAqqJY.png",
      "id_str" : "263655661265641472",
      "id" : 263655661265641472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ixbVDCYAAqqJY.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/bJjTBPOj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263654909264674816",
  "geo" : { },
  "id_str" : "263655661257252864",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy How's this? http:\/\/t.co\/bJjTBPOj",
  "id" : 263655661257252864,
  "in_reply_to_status_id" : 263654909264674816,
  "created_at" : "2012-10-31 14:56:23 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marksands",
      "screen_name" : "marksands",
      "indices" : [ 3, 13 ],
      "id_str" : "14437070",
      "id" : 14437070
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 15, 21 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marksands\/status\/263655457581850624\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/yqqAFgaB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ixPeSCYAAd_g_.png",
      "id_str" : "263655457586044928",
      "id" : 263655457586044928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ixPeSCYAAd_g_.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yqqAFgaB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263655561420230658",
  "text" : "RT @marksands: @qrush ha, you can\u2019t even close out of it on mobile safari! http:\/\/t.co\/yqqAFgaB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marksands\/status\/263655457581850624\/photo\/1",
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/yqqAFgaB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ixPeSCYAAd_g_.png",
        "id_str" : "263655457586044928",
        "id" : 263655457586044928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ixPeSCYAAd_g_.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yqqAFgaB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "263653507075305472",
    "geo" : { },
    "id_str" : "263655457581850624",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush ha, you can\u2019t even close out of it on mobile safari! http:\/\/t.co\/yqqAFgaB",
    "id" : 263655457581850624,
    "in_reply_to_status_id" : 263653507075305472,
    "created_at" : "2012-10-31 14:55:34 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "marksands",
      "screen_name" : "marksands",
      "protected" : false,
      "id_str" : "14437070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3711473833\/4ce901976bacb4ce7ba31aee97c57b21_normal.png",
      "id" : 14437070,
      "verified" : false
    }
  },
  "id" : 263655561420230658,
  "created_at" : "2012-10-31 14:55:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263654017085886464",
  "text" : "RSS: \"COMING SOON!\" [BN]raged.",
  "id" : 263654017085886464,
  "created_at" : "2012-10-31 14:49:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 16, 22 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263653639770497024",
  "text" : "RT @jasonfried: @qrush 40% off though!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "263652487758753792",
    "geo" : { },
    "id_str" : "263653453870559233",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush 40% off though!!",
    "id" : 263653453870559233,
    "in_reply_to_status_id" : 263652487758753792,
    "created_at" : "2012-10-31 14:47:36 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 263653639770497024,
  "created_at" : "2012-10-31 14:48:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/hwrUDDHZ",
      "expanded_url" : "http:\/\/bostonglobe.com\/",
      "display_url" : "bostonglobe.com"
    }, {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/B2f6vPQP",
      "expanded_url" : "http:\/\/usatoday.com\/",
      "display_url" : "usatoday.com"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/VZ5jRZNW",
      "expanded_url" : "http:\/\/www.nytimes.com\/skimmer\/",
      "display_url" : "nytimes.com\/skimmer\/"
    } ]
  },
  "geo" : { },
  "id_str" : "263653507075305472",
  "text" : "Does anyone at the Buffalo News take pride their work? So many role models: http:\/\/t.co\/hwrUDDHZ http:\/\/t.co\/B2f6vPQP http:\/\/t.co\/VZ5jRZNW",
  "id" : 263653507075305472,
  "created_at" : "2012-10-31 14:47:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/263652487758753792\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/KwdTqWZi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6iuim1CMAEZbcS.png",
      "id_str" : "263652487762948097",
      "id" : 263652487762948097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6iuim1CMAEZbcS.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1394
      } ],
      "display_url" : "pic.twitter.com\/KwdTqWZi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263652487758753792",
  "text" : "The Buffalo News website is a disgrace and really puts this entire region to shame. http:\/\/t.co\/KwdTqWZi",
  "id" : 263652487758753792,
  "created_at" : "2012-10-31 14:43:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/KooWdIRf",
      "expanded_url" : "http:\/\/instagr.am\/p\/RcuFvws6jU\/",
      "display_url" : "instagr.am\/p\/RcuFvws6jU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "263640397224476672",
  "text" : "RT @coworkbuffalo: Frank is blooming again! http:\/\/t.co\/KooWdIRf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/KooWdIRf",
        "expanded_url" : "http:\/\/instagr.am\/p\/RcuFvws6jU\/",
        "display_url" : "instagr.am\/p\/RcuFvws6jU\/"
      } ]
    },
    "geo" : { },
    "id_str" : "263640309878108160",
    "text" : "Frank is blooming again! http:\/\/t.co\/KooWdIRf",
    "id" : 263640309878108160,
    "created_at" : "2012-10-31 13:55:22 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 263640397224476672,
  "created_at" : "2012-10-31 13:55:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 50, 64 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263345630892654592",
  "text" : "Terrible wifi at Spot Elmwood is reminding me why @coworkbuffalo exists.",
  "id" : 263345630892654592,
  "created_at" : "2012-10-30 18:24:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 36, 42 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "5by5",
      "screen_name" : "5by5",
      "indices" : [ 67, 72 ],
      "id_str" : "106231780",
      "id" : 106231780
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 87, 99 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 106, 117 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kLktAdvF",
      "expanded_url" : "http:\/\/5by5.tv\/live",
      "display_url" : "5by5.tv\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "263329608118706176",
  "text" : "RT @ginatrapani: With special guest @qrush today--come join us. RT @5by5: In Beta with @ginatrapani &amp; @kevinpurdy is starting now -  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 19, 25 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "5by5",
        "screen_name" : "5by5",
        "indices" : [ 50, 55 ],
        "id_str" : "106231780",
        "id" : 106231780
      }, {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 70, 82 ],
        "id_str" : "930061",
        "id" : 930061
      }, {
        "name" : "Kevin Purdy",
        "screen_name" : "kevinpurdy",
        "indices" : [ 89, 100 ],
        "id_str" : "14687182",
        "id" : 14687182
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/kLktAdvF",
        "expanded_url" : "http:\/\/5by5.tv\/live",
        "display_url" : "5by5.tv\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "263325056682303488",
    "text" : "With special guest @qrush today--come join us. RT @5by5: In Beta with @ginatrapani &amp; @kevinpurdy is starting now - http:\/\/t.co\/kLktAdvF",
    "id" : 263325056682303488,
    "created_at" : "2012-10-30 17:02:40 +0000",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550825678673682432\/YRqb4FJE_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 263329608118706176,
  "created_at" : "2012-10-30 17:20:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 10, 21 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263325225473683456",
  "geo" : { },
  "id_str" : "263329511234482176",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle @kevinpurdy haha yes, trying to tone it down a bit :)",
  "id" : 263329511234482176,
  "in_reply_to_status_id" : 263325225473683456,
  "created_at" : "2012-10-30 17:20:22 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 3, 14 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 86, 92 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/ZlZ0HJkT",
      "expanded_url" : "http:\/\/live.5by5.tv",
      "display_url" : "live.5by5.tv"
    } ]
  },
  "geo" : { },
  "id_str" : "263325259695005697",
  "text" : "RT @kevinpurdy: &lt;In Beta&gt; starting now: http:\/\/t.co\/ZlZ0HJkT with special guest @qrush. Talking code, project communities, and MAR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 70, 76 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/ZlZ0HJkT",
        "expanded_url" : "http:\/\/live.5by5.tv",
        "display_url" : "live.5by5.tv"
      } ]
    },
    "geo" : { },
    "id_str" : "263325090459045888",
    "text" : "&lt;In Beta&gt; starting now: http:\/\/t.co\/ZlZ0HJkT with special guest @qrush. Talking code, project communities, and MARKDOWN.",
    "id" : 263325090459045888,
    "created_at" : "2012-10-30 17:02:48 +0000",
    "user" : {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "protected" : false,
      "id_str" : "14687182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563319164790513664\/GEmp2Ijj_normal.jpeg",
      "id" : 14687182,
      "verified" : false
    }
  },
  "id" : 263325259695005697,
  "created_at" : "2012-10-30 17:03:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 13, 24 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/GQ0qFK5j",
      "expanded_url" : "http:\/\/www.rubymotion.com\/support\/training\/",
      "display_url" : "rubymotion.com\/support\/traini\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263320499063496704",
  "text" : "RT @rjs: The @RubyMotion guys are on fire. Now they offer an intensive five-day training course: http:\/\/t.co\/GQ0qFK5j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyMotion",
        "screen_name" : "RubyMotion",
        "indices" : [ 4, 15 ],
        "id_str" : "381521407",
        "id" : 381521407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/GQ0qFK5j",
        "expanded_url" : "http:\/\/www.rubymotion.com\/support\/training\/",
        "display_url" : "rubymotion.com\/support\/traini\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "263319837290418176",
    "text" : "The @RubyMotion guys are on fire. Now they offer an intensive five-day training course: http:\/\/t.co\/GQ0qFK5j",
    "id" : 263319837290418176,
    "created_at" : "2012-10-30 16:41:56 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 263320499063496704,
  "created_at" : "2012-10-30 16:44:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Diago",
      "screen_name" : "josefdiago",
      "indices" : [ 0, 11 ],
      "id_str" : "251839105",
      "id" : 251839105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263308525302845440",
  "geo" : { },
  "id_str" : "263316364700303361",
  "in_reply_to_user_id" : 251839105,
  "text" : "@josefdiago nope!",
  "id" : 263316364700303361,
  "in_reply_to_status_id" : 263308525302845440,
  "created_at" : "2012-10-30 16:28:08 +0000",
  "in_reply_to_screen_name" : "josefdiago",
  "in_reply_to_user_id_str" : "251839105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/DNaHwN5H",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/programming\/user\/consultant_barbie\/",
      "display_url" : "reddit.com\/r\/programming\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263302504413020161",
  "text" : "$X is hard. Let's go shopping! http:\/\/t.co\/DNaHwN5H",
  "id" : 263302504413020161,
  "created_at" : "2012-10-30 15:33:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/8awttAN9",
      "expanded_url" : "http:\/\/turntable.fm\/jam_bands_no_lames_1up1down",
      "display_url" : "turntable.fm\/jam_bands_no_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263294511264960514",
  "text" : "DJing in the Jam Bands | No Lames | 1Up1Down room. Now playing Perpetual Groove #turntablefm http:\/\/t.co\/8awttAN9",
  "id" : 263294511264960514,
  "created_at" : "2012-10-30 15:01:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    }, {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 11, 25 ],
      "id_str" : "5543292",
      "id" : 5543292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263294160612773889",
  "geo" : { },
  "id_str" : "263294411562180608",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic @edwardmichael preposterous, no one in buffalo knows each other",
  "id" : 263294411562180608,
  "in_reply_to_status_id" : 263294160612773889,
  "created_at" : "2012-10-30 15:00:54 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward M. Bujanowski",
      "screen_name" : "edwardmichael",
      "indices" : [ 0, 14 ],
      "id_str" : "5543292",
      "id" : 5543292
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 23, 33 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263278606682312704",
  "geo" : { },
  "id_str" : "263293882337468416",
  "in_reply_to_user_id" : 5543292,
  "text" : "@edwardmichael i heard @aspleenic plays some drums",
  "id" : 263293882337468416,
  "in_reply_to_status_id" : 263278606682312704,
  "created_at" : "2012-10-30 14:58:47 +0000",
  "in_reply_to_screen_name" : "edwardmichael",
  "in_reply_to_user_id_str" : "5543292",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Barone",
      "screen_name" : "buffalofoodie",
      "indices" : [ 44, 58 ],
      "id_str" : "190038945",
      "id" : 190038945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/Ns0N6GT2",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/thebmft\/the-black-market-food-truck",
      "display_url" : "kickstarter.com\/projects\/thebm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263277494726176768",
  "text" : "MORE FOOD TRUCKS! http:\/\/t.co\/Ns0N6GT2 (via @buffalofoodie",
  "id" : 263277494726176768,
  "created_at" : "2012-10-30 13:53:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zerohedge",
      "screen_name" : "zerohedge",
      "indices" : [ 3, 13 ],
      "id_str" : "18856867",
      "id" : 18856867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/GuoetpGu",
      "expanded_url" : "http:\/\/twitpic.com\/b8ntyj",
      "display_url" : "twitpic.com\/b8ntyj"
    } ]
  },
  "geo" : { },
  "id_str" : "263137060758634497",
  "text" : "RT @zerohedge: NYC Subway may have some problems for a while http:\/\/t.co\/GuoetpGu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/GuoetpGu",
        "expanded_url" : "http:\/\/twitpic.com\/b8ntyj",
        "display_url" : "twitpic.com\/b8ntyj"
      } ]
    },
    "geo" : { },
    "id_str" : "263134303410614274",
    "text" : "NYC Subway may have some problems for a while http:\/\/t.co\/GuoetpGu",
    "id" : 263134303410614274,
    "created_at" : "2012-10-30 04:24:41 +0000",
    "user" : {
      "name" : "zerohedge",
      "screen_name" : "zerohedge",
      "protected" : false,
      "id_str" : "18856867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/72647502\/tyler_normal.jpg",
      "id" : 18856867,
      "verified" : false
    }
  },
  "id" : 263137060758634497,
  "created_at" : "2012-10-30 04:35:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Buffalo OpenCoffee",
      "screen_name" : "BfloOpenCoffee",
      "indices" : [ 94, 109 ],
      "id_str" : "300394295",
      "id" : 300394295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "BfloFRED",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263136664644366336",
  "text" : "RT @coworkbuffalo: Closed tomorrow thanks to #Sandy. #BfloFRED has been pushed off as well as @BfloOpenCoffee. Just stay safe, ok?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffalo OpenCoffee",
        "screen_name" : "BfloOpenCoffee",
        "indices" : [ 75, 90 ],
        "id_str" : "300394295",
        "id" : 300394295
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 26, 32 ]
      }, {
        "text" : "BfloFRED",
        "indices" : [ 34, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263136502786187264",
    "text" : "Closed tomorrow thanks to #Sandy. #BfloFRED has been pushed off as well as @BfloOpenCoffee. Just stay safe, ok?",
    "id" : 263136502786187264,
    "created_at" : "2012-10-30 04:33:25 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 263136664644366336,
  "created_at" : "2012-10-30 04:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "soffes",
      "indices" : [ 0, 7 ],
      "id_str" : "6154602",
      "id" : 6154602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263128450557153280",
  "geo" : { },
  "id_str" : "263129399023521793",
  "in_reply_to_user_id" : 6154602,
  "text" : "@soffes I really hate making fun of events that result in harm\/death :(",
  "id" : 263129399023521793,
  "in_reply_to_status_id" : 263128450557153280,
  "created_at" : "2012-10-30 04:05:12 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263127690909990912",
  "text" : "@IselaMariaPhoto yeah, plenty windy though.",
  "id" : 263127690909990912,
  "created_at" : "2012-10-30 03:58:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263123727372414977",
  "text" : "Creepy night with the house creaking and howling from the wind. Very glad the dog doesn\u2019t get spooked with big storms.",
  "id" : 263123727372414977,
  "created_at" : "2012-10-30 03:42:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/inu57caT",
      "expanded_url" : "http:\/\/github.github.com\/github",
      "display_url" : "github.github.com\/github"
    } ]
  },
  "geo" : { },
  "id_str" : "263010955372404736",
  "text" : "Can someone at github make this URL not 404? http:\/\/t.co\/inu57caT",
  "id" : 263010955372404736,
  "created_at" : "2012-10-29 20:14:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262996525863534593",
  "text" : "RT @holman: I can\u2019t believe this hurricane is still hurling towards the east coast even after all of the witty tweet puns we\u2019ve made abo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262995796121772033",
    "text" : "I can\u2019t believe this hurricane is still hurling towards the east coast even after all of the witty tweet puns we\u2019ve made about it.",
    "id" : 262995796121772033,
    "created_at" : "2012-10-29 19:14:18 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550019686230794240\/gWlpdYw2_normal.png",
      "id" : 11322372,
      "verified" : false
    }
  },
  "id" : 262996525863534593,
  "created_at" : "2012-10-29 19:17:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262995014794235904",
  "geo" : { },
  "id_str" : "262995192771145728",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn you could do this without a storm, you know",
  "id" : 262995192771145728,
  "in_reply_to_status_id" : 262995014794235904,
  "created_at" : "2012-10-29 19:11:54 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 3, 9 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PROTIP",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262995090530783232",
  "text" : "RT @chorn: #PROTIP: Kill all your neighbors, take their stuff, make it look like storm damage.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PROTIP",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262995014794235904",
    "text" : "#PROTIP: Kill all your neighbors, take their stuff, make it look like storm damage.",
    "id" : 262995014794235904,
    "created_at" : "2012-10-29 19:11:12 +0000",
    "user" : {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "protected" : false,
      "id_str" : "744613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2310147637\/niixqq7ibisfwaat2xmg_normal.png",
      "id" : 744613,
      "verified" : false
    }
  },
  "id" : 262995090530783232,
  "created_at" : "2012-10-29 19:11:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262982951594250241",
  "geo" : { },
  "id_str" : "262983232369336320",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k Email 1: DELETE TESTS",
  "id" : 262983232369336320,
  "in_reply_to_status_id" : 262982951594250241,
  "created_at" : "2012-10-29 18:24:23 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 3, 12 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 34, 43 ],
      "id_str" : "715440464",
      "id" : 715440464
    }, {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 119, 127 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262963166630248448",
  "text" : "RT @openhack: Hurray! We now have @openhack ! We'll use this for announcements for new cities, and more. Big thanks to @micheal for help ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHack",
        "screen_name" : "openhack",
        "indices" : [ 20, 29 ],
        "id_str" : "715440464",
        "id" : 715440464
      }, {
        "name" : "Micheal",
        "screen_name" : "micheal",
        "indices" : [ 105, 113 ],
        "id_str" : "16144033",
        "id" : 16144033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262963000246427650",
    "text" : "Hurray! We now have @openhack ! We'll use this for announcements for new cities, and more. Big thanks to @micheal for helping us out !",
    "id" : 262963000246427650,
    "created_at" : "2012-10-29 17:03:59 +0000",
    "user" : {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "protected" : false,
      "id_str" : "715440464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2820837518\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 715440464,
      "verified" : false
    }
  },
  "id" : 262963166630248448,
  "created_at" : "2012-10-29 17:04:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micheal",
      "screen_name" : "micheal",
      "indices" : [ 0, 8 ],
      "id_str" : "16144033",
      "id" : 16144033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262960056155394048",
  "geo" : { },
  "id_str" : "262960786807332865",
  "in_reply_to_user_id" : 16144033,
  "text" : "@micheal thanks! I need to reset it now.",
  "id" : 262960786807332865,
  "in_reply_to_status_id" : 262960056155394048,
  "created_at" : "2012-10-29 16:55:11 +0000",
  "in_reply_to_screen_name" : "micheal",
  "in_reply_to_user_id_str" : "16144033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "262927971604652032",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Men Without Hats: The Safety Dance \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 262927971604652032,
  "created_at" : "2012-10-29 14:44:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "indices" : [ 3, 12 ],
      "id_str" : "14212405",
      "id" : 14212405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262923694215688193",
  "text" : "RT @metadave: I will meet everyone at the Winchester.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262922755916320768",
    "text" : "I will meet everyone at the Winchester.",
    "id" : 262922755916320768,
    "created_at" : "2012-10-29 14:24:04 +0000",
    "user" : {
      "name" : "Dave Parfitt",
      "screen_name" : "metadave",
      "protected" : false,
      "id_str" : "14212405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517399116389703681\/iIxMwZO3_normal.jpeg",
      "id" : 14212405,
      "verified" : false
    }
  },
  "id" : 262923694215688193,
  "created_at" : "2012-10-29 14:27:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bkirst77",
      "screen_name" : "BK77",
      "indices" : [ 0, 5 ],
      "id_str" : "8209142",
      "id" : 8209142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/MWlTW6xv",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Geddy_Lee",
      "display_url" : "en.wikipedia.org\/wiki\/Geddy_Lee"
    } ]
  },
  "in_reply_to_status_id_str" : "262760161200984064",
  "geo" : { },
  "id_str" : "262761095427653632",
  "in_reply_to_user_id" : 8209142,
  "text" : "@BK77 Come on, \"Getty Lee\" Are you fucking kidding me? http:\/\/t.co\/MWlTW6xv",
  "id" : 262761095427653632,
  "in_reply_to_status_id" : 262760161200984064,
  "created_at" : "2012-10-29 03:41:41 +0000",
  "in_reply_to_screen_name" : "BK77",
  "in_reply_to_user_id_str" : "8209142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/H9KMFu4H",
      "expanded_url" : "http:\/\/swanson.github.com\/blog\/2012\/10\/28\/i-dont-have-time.html",
      "display_url" : "swanson.github.com\/blog\/2012\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "262760684541075456",
  "text" : "Found a post I'm going to send to anyone who says \"How do you make time for that?\" http:\/\/t.co\/H9KMFu4H",
  "id" : 262760684541075456,
  "created_at" : "2012-10-29 03:40:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake @ddfreyne",
      "screen_name" : "ddfreyne",
      "indices" : [ 3, 12 ],
      "id_str" : "635353",
      "id" : 635353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/Cbazk2o7",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "262703101302173696",
  "text" : "RT @ddfreyne: Ooh, 37 signals\u2019 sub looks pretty sweet: https:\/\/t.co\/Cbazk2o7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 62 ],
        "url" : "https:\/\/t.co\/Cbazk2o7",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "262634045786177536",
    "text" : "Ooh, 37 signals\u2019 sub looks pretty sweet: https:\/\/t.co\/Cbazk2o7",
    "id" : 262634045786177536,
    "created_at" : "2012-10-28 19:16:50 +0000",
    "user" : {
      "name" : "Fake @ddfreyne",
      "screen_name" : "ddfreyne",
      "protected" : false,
      "id_str" : "635353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564760943511343104\/T6elgCiF_normal.jpeg",
      "id" : 635353,
      "verified" : false
    }
  },
  "id" : 262703101302173696,
  "created_at" : "2012-10-28 23:51:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 3, 12 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 131 ],
      "url" : "https:\/\/t.co\/AikvtXiM",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "262703072961245184",
  "text" : "RT @roidrage: Guess that means I can work on Tasseo tomorrow and finally start setting up our own set of sub: https:\/\/t.co\/AikvtXiM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 117 ],
        "url" : "https:\/\/t.co\/AikvtXiM",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "262653481175896065",
    "text" : "Guess that means I can work on Tasseo tomorrow and finally start setting up our own set of sub: https:\/\/t.co\/AikvtXiM",
    "id" : 262653481175896065,
    "created_at" : "2012-10-28 20:34:04 +0000",
    "user" : {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "protected" : false,
      "id_str" : "14658472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2938540224\/9ffc554b0eabb077a915cfe0d56f3c1f_normal.jpeg",
      "id" : 14658472,
      "verified" : false
    }
  },
  "id" : 262703072961245184,
  "created_at" : "2012-10-28 23:51:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262654861064155136",
  "geo" : { },
  "id_str" : "262703005856575488",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors I actually started Dead Rising. I always just killed zombies and never did the story.",
  "id" : 262703005856575488,
  "in_reply_to_status_id" : 262654861064155136,
  "created_at" : "2012-10-28 23:50:52 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaz Adams",
      "screen_name" : "chazadams",
      "indices" : [ 0, 10 ],
      "id_str" : "14807622",
      "id" : 14807622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262629001737158656",
  "geo" : { },
  "id_str" : "262629436401270784",
  "in_reply_to_user_id" : 14807622,
  "text" : "@chazadams Super Meat Boy is extremely, throw controller at the wall frustrating (but good!) Looked at Fez but didn't seem worth it.",
  "id" : 262629436401270784,
  "in_reply_to_status_id" : 262629001737158656,
  "created_at" : "2012-10-28 18:58:31 +0000",
  "in_reply_to_screen_name" : "chazadams",
  "in_reply_to_user_id_str" : "14807622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian G\u00F6ttschkes",
      "screen_name" : "Sgoettschkes",
      "indices" : [ 3, 16 ],
      "id_str" : "62806594",
      "id" : 62806594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/bkFHokFH",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "262628750531891201",
  "text" : "RT @Sgoettschkes: If you don't know sub, you should definitly check it out. Scripting gets so much nicer! https:\/\/t.co\/bkFHokFH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 109 ],
        "url" : "https:\/\/t.co\/bkFHokFH",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "261504728683401217",
    "text" : "If you don't know sub, you should definitly check it out. Scripting gets so much nicer! https:\/\/t.co\/bkFHokFH",
    "id" : 261504728683401217,
    "created_at" : "2012-10-25 16:29:20 +0000",
    "user" : {
      "name" : "Sebastian G\u00F6ttschkes",
      "screen_name" : "Sgoettschkes",
      "protected" : false,
      "id_str" : "62806594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2203745595\/sebi_klein_normal.jpg",
      "id" : 62806594,
      "verified" : false
    }
  },
  "id" : 262628750531891201,
  "created_at" : "2012-10-28 18:55:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Fusco",
      "screen_name" : "PKoin",
      "indices" : [ 3, 9 ],
      "id_str" : "319675086",
      "id" : 319675086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckingmarvellous",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 69 ],
      "url" : "https:\/\/t.co\/0UF2O2vf",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "262628740218097664",
  "text" : "RT @PKoin: a delicious way to organize programs https:\/\/t.co\/0UF2O2vf #fuckingmarvellous",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot for Chrome\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fuckingmarvellous",
        "indices" : [ 59, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 58 ],
        "url" : "https:\/\/t.co\/0UF2O2vf",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "261870443345096704",
    "text" : "a delicious way to organize programs https:\/\/t.co\/0UF2O2vf #fuckingmarvellous",
    "id" : 261870443345096704,
    "created_at" : "2012-10-26 16:42:33 +0000",
    "user" : {
      "name" : "Julien Fusco",
      "screen_name" : "PKoin",
      "protected" : false,
      "id_str" : "319675086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2812184894\/4c6c0f3bb3f4ce72352888ace05f4ab7_normal.jpeg",
      "id" : 319675086,
      "verified" : false
    }
  },
  "id" : 262628740218097664,
  "created_at" : "2012-10-28 18:55:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Vandervort",
      "screen_name" : "openczun",
      "indices" : [ 3, 12 ],
      "id_str" : "16049164",
      "id" : 16049164
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 70, 76 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262628664972300289",
  "text" : "RT @openczun: today is 'move scripts to sub framework' day. Nice job, @qrush .",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 56, 62 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262626279738720260",
    "text" : "today is 'move scripts to sub framework' day. Nice job, @qrush .",
    "id" : 262626279738720260,
    "created_at" : "2012-10-28 18:45:59 +0000",
    "user" : {
      "name" : "Roger Vandervort",
      "screen_name" : "openczun",
      "protected" : false,
      "id_str" : "16049164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/215340032\/roger_normal.jpg",
      "id" : 16049164,
      "verified" : false
    }
  },
  "id" : 262628664972300289,
  "created_at" : "2012-10-28 18:55:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Vandervort",
      "screen_name" : "openczun",
      "indices" : [ 0, 9 ],
      "id_str" : "16049164",
      "id" : 16049164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262626279738720260",
  "geo" : { },
  "id_str" : "262628650078326784",
  "in_reply_to_user_id" : 16049164,
  "text" : "@openczun Woot!",
  "id" : 262628650078326784,
  "in_reply_to_status_id" : 262626279738720260,
  "created_at" : "2012-10-28 18:55:24 +0000",
  "in_reply_to_screen_name" : "openczun",
  "in_reply_to_user_id_str" : "16049164",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262628406049509376",
  "text" : "Visited both the Xbox Live marketplace and Wii Virtual Console today, and nothing looked interesting\/challenging. :\/",
  "id" : 262628406049509376,
  "created_at" : "2012-10-28 18:54:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262418218843525120",
  "text" : "I am terrible at Letterpress. \uD83D\uDE10 Feel free to challenge me! I\u2019m quaranto on Game Center.",
  "id" : 262418218843525120,
  "created_at" : "2012-10-28 04:59:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262283277019258880",
  "geo" : { },
  "id_str" : "262284197379596289",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik This is neat, but I don't fully understand...is this about software development\/code?",
  "id" : 262284197379596289,
  "in_reply_to_status_id" : 262283277019258880,
  "created_at" : "2012-10-27 20:06:40 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262198097051009024",
  "text" : "Beyond excited for the next few months. Can\u2019t say why yet! ;)",
  "id" : 262198097051009024,
  "created_at" : "2012-10-27 14:24:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea LaRowe",
      "screen_name" : "alarowe",
      "indices" : [ 0, 8 ],
      "id_str" : "270917610",
      "id" : 270917610
    }, {
      "name" : "Brent LaRowe",
      "screen_name" : "Blarowe",
      "indices" : [ 9, 17 ],
      "id_str" : "15080463",
      "id" : 15080463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262162282023370752",
  "geo" : { },
  "id_str" : "262197781513531392",
  "in_reply_to_user_id" : 270917610,
  "text" : "@alarowe @Blarowe bring guns?",
  "id" : 262197781513531392,
  "in_reply_to_status_id" : 262162282023370752,
  "created_at" : "2012-10-27 14:23:17 +0000",
  "in_reply_to_screen_name" : "alarowe",
  "in_reply_to_user_id_str" : "270917610",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 3, 17 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262197671530491905",
  "text" : "RT @communitybeer: Last week at Bidwell: a lovely, rainy day. No In C, but we have a small amount of Batch 100 and a bit of Preacher Man!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262166945154097152",
    "text" : "Last week at Bidwell: a lovely, rainy day. No In C, but we have a small amount of Batch 100 and a bit of Preacher Man!",
    "id" : 262166945154097152,
    "created_at" : "2012-10-27 12:20:45 +0000",
    "user" : {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "protected" : false,
      "id_str" : "145294977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477088444733071361\/g7q5sNbw_normal.jpeg",
      "id" : 145294977,
      "verified" : false
    }
  },
  "id" : 262197671530491905,
  "created_at" : "2012-10-27 14:22:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Community Beer Works",
      "screen_name" : "communitybeer",
      "indices" : [ 0, 14 ],
      "id_str" : "145294977",
      "id" : 145294977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262166945154097152",
  "geo" : { },
  "id_str" : "262197657777364993",
  "in_reply_to_user_id" : 145294977,
  "text" : "@communitybeer oh snap! I\u2019ll stop by and get the growler filled up.",
  "id" : 262197657777364993,
  "in_reply_to_status_id" : 262166945154097152,
  "created_at" : "2012-10-27 14:22:47 +0000",
  "in_reply_to_screen_name" : "communitybeer",
  "in_reply_to_user_id_str" : "145294977",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262011958218326016",
  "text" : "Thought about this for a while: I hope I\u2019m still playing with Ruby when Rake hits version 20.0.",
  "id" : 262011958218326016,
  "created_at" : "2012-10-27 02:04:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 3, 11 ],
      "id_str" : "6592472",
      "id" : 6592472
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261990805055631360",
  "text" : "RT @rubiety: @qrush So THAT is where the dog's name came from....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "261984027148431360",
    "geo" : { },
    "id_str" : "261989098552692737",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush So THAT is where the dog's name came from....",
    "id" : 261989098552692737,
    "in_reply_to_status_id" : 261984027148431360,
    "created_at" : "2012-10-27 00:34:03 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "protected" : false,
      "id_str" : "6592472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549691657881264128\/BiVkh3eS_normal.jpeg",
      "id" : 6592472,
      "verified" : false
    }
  },
  "id" : 261990805055631360,
  "created_at" : "2012-10-27 00:40:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/261987916677541889\/photo\/1",
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/kstetXKP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6LEn0VCcAAIy8I.jpg",
      "id_str" : "261987916681736192",
      "id" : 261987916681736192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6LEn0VCcAAIy8I.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kstetXKP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261987916677541889",
  "text" : "Terrible photo, but here\u2019s the TelePrompTer. So sad. http:\/\/t.co\/kstetXKP",
  "id" : 261987916677541889,
  "created_at" : "2012-10-27 00:29:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261984418846081025",
  "geo" : { },
  "id_str" : "261984777794629634",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant Peart writes most of the songs.",
  "id" : 261984777794629634,
  "in_reply_to_status_id" : 261984418846081025,
  "created_at" : "2012-10-27 00:16:53 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261984027148431360",
  "text" : "Call me crazy, but I think Geddy Lee has a TelePrompTer with scrolling lyrics on his side of the stage. WTF?!",
  "id" : 261984027148431360,
  "created_at" : "2012-10-27 00:13:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261978102639493120",
  "text" : "Only at a Rush concert would I get yelled at to sit down.",
  "id" : 261978102639493120,
  "created_at" : "2012-10-26 23:50:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261973037702840320",
  "text" : "At the FN Center, and one thing is obvious: Everyone wants to see some hockey.",
  "id" : 261973037702840320,
  "created_at" : "2012-10-26 23:30:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 3, 12 ],
      "id_str" : "12855662",
      "id" : 12855662
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 26, 32 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/1Mo0dpx8",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261911324802560000",
  "text" : "RT @adelevie: DC anyone? \u201C@qrush: Not even a week into #openhack and we have 11 cities listed. Where's yours? http:\/\/t.co\/1Mo0dpx8\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 12, 18 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/1Mo0dpx8",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "261901725357723648",
    "text" : "DC anyone? \u201C@qrush: Not even a week into #openhack and we have 11 cities listed. Where's yours? http:\/\/t.co\/1Mo0dpx8\u201D",
    "id" : 261901725357723648,
    "created_at" : "2012-10-26 18:46:51 +0000",
    "user" : {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "protected" : false,
      "id_str" : "12855662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564507125276098561\/0YeB7mNp_normal.jpeg",
      "id" : 12855662,
      "verified" : false
    }
  },
  "id" : 261911324802560000,
  "created_at" : "2012-10-26 19:25:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "indices" : [ 3, 17 ],
      "id_str" : "15789234",
      "id" : 15789234
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/I7e0lsTy",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261911314509733888",
  "text" : "RT @scottradcliff: \"@qrush Not even a week into #openhack and we have 11 cities listed. Where's yours? http:\/\/t.co\/I7e0lsTy \" Why are we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 1, 7 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/I7e0lsTy",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "in_reply_to_status_id_str" : "261900963827306496",
    "geo" : { },
    "id_str" : "261901873538273280",
    "in_reply_to_user_id" : 5743852,
    "text" : "\"@qrush Not even a week into #openhack and we have 11 cities listed. Where's yours? http:\/\/t.co\/I7e0lsTy \" Why are we not doing this Toledo?",
    "id" : 261901873538273280,
    "in_reply_to_status_id" : 261900963827306496,
    "created_at" : "2012-10-26 18:47:27 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "protected" : false,
      "id_str" : "15789234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2276044147\/8zzal988v07sdi6eh14o_normal.jpeg",
      "id" : 15789234,
      "verified" : false
    }
  },
  "id" : 261911314509733888,
  "created_at" : "2012-10-26 19:24:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "indices" : [ 3, 12 ],
      "id_str" : "17137749",
      "id" : 17137749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/S0SntxtY",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261911288819634178",
  "text" : "RT @tzmartin: OpenHack is taking off!  We need San Fran on the list.. hm.. http:\/\/t.co\/S0SntxtY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/S0SntxtY",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "261909187368472576",
    "text" : "OpenHack is taking off!  We need San Fran on the list.. hm.. http:\/\/t.co\/S0SntxtY",
    "id" : 261909187368472576,
    "created_at" : "2012-10-26 19:16:30 +0000",
    "user" : {
      "name" : "\uF8FF tz martin",
      "screen_name" : "tzmartin",
      "protected" : false,
      "id_str" : "17137749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502078261526929410\/EJbwzQOU_normal.jpeg",
      "id" : 17137749,
      "verified" : false
    }
  },
  "id" : 261911288819634178,
  "created_at" : "2012-10-26 19:24:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261903382745321472",
  "geo" : { },
  "id_str" : "261903798002384899",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella I just pushed a commit to shove it into YAML, but it seems locally the sorting is different than GitHub. Alpha sounds good.",
  "id" : 261903798002384899,
  "in_reply_to_status_id" : 261903382745321472,
  "created_at" : "2012-10-26 18:55:06 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261900963827306496",
  "text" : "Not even a week into #openhack and we have 11 cities listed. Where's yours? http:\/\/t.co\/Dih7bxvF",
  "id" : 261900963827306496,
  "created_at" : "2012-10-26 18:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 3, 12 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/kXwy9aPE",
      "expanded_url" : "http:\/\/reefpoints.dockyard.com\/community\/2012\/10\/26\/openhack-boston.html",
      "display_url" : "reefpoints.dockyard.com\/community\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261893167924776961",
  "text" : "RT @DockYard: OpenHack Boston 1.0 Recap http:\/\/t.co\/kXwy9aPE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/kXwy9aPE",
        "expanded_url" : "http:\/\/reefpoints.dockyard.com\/community\/2012\/10\/26\/openhack-boston.html",
        "display_url" : "reefpoints.dockyard.com\/community\/2012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261890799359369216",
    "text" : "OpenHack Boston 1.0 Recap http:\/\/t.co\/kXwy9aPE",
    "id" : 261890799359369216,
    "created_at" : "2012-10-26 18:03:26 +0000",
    "user" : {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "protected" : false,
      "id_str" : "18545770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000606125141\/c367193b2bf7b32dad02e39c9db058f5_normal.jpeg",
      "id" : 18545770,
      "verified" : false
    }
  },
  "id" : 261893167924776961,
  "created_at" : "2012-10-26 18:12:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/261883907987881985\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/fKryjwJc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6JmBtyCQAA3thx.jpg",
      "id_str" : "261883907996270592",
      "id" : 261883907996270592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6JmBtyCQAA3thx.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/fKryjwJc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261884386386001920",
  "text" : "RT @coworkbuffalo: The most decorated conf badge ever. Have you brought your badge in yet for our wall? http:\/\/t.co\/fKryjwJc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/261883907987881985\/photo\/1",
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/fKryjwJc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6JmBtyCQAA3thx.jpg",
        "id_str" : "261883907996270592",
        "id" : 261883907996270592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6JmBtyCQAA3thx.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/fKryjwJc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261883907987881985",
    "text" : "The most decorated conf badge ever. Have you brought your badge in yet for our wall? http:\/\/t.co\/fKryjwJc",
    "id" : 261883907987881985,
    "created_at" : "2012-10-26 17:36:04 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 261884386386001920,
  "created_at" : "2012-10-26 17:37:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261884321139417088",
  "text" : "@IselaMariaPhoto I think 4 now?",
  "id" : 261884321139417088,
  "created_at" : "2012-10-26 17:37:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandre Lamoureux",
      "screen_name" : "lamoureuxalex",
      "indices" : [ 0, 14 ],
      "id_str" : "177368647",
      "id" : 177368647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261850869757263872",
  "geo" : { },
  "id_str" : "261859368126009344",
  "in_reply_to_user_id" : 177368647,
  "text" : "@lamoureuxalex woot! i've seen them a few times now. still kicking ass.",
  "id" : 261859368126009344,
  "in_reply_to_status_id" : 261850869757263872,
  "created_at" : "2012-10-26 15:58:33 +0000",
  "in_reply_to_screen_name" : "lamoureuxalex",
  "in_reply_to_user_id_str" : "177368647",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "indices" : [ 3, 17 ],
      "id_str" : "5896952",
      "id" : 5896952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261856596617998336",
  "text" : "RT @BuffaloRising: It's 2012 and there's a sold-out Rush concert at the First Niagara Center tonight. Buffalo. For Real.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261855755001532416",
    "text" : "It's 2012 and there's a sold-out Rush concert at the First Niagara Center tonight. Buffalo. For Real.",
    "id" : 261855755001532416,
    "created_at" : "2012-10-26 15:44:11 +0000",
    "user" : {
      "name" : "Buffalo Rising",
      "screen_name" : "BuffaloRising",
      "protected" : false,
      "id_str" : "5896952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749220504\/buffalorisingblue_normal.jpg",
      "id" : 5896952,
      "verified" : false
    }
  },
  "id" : 261856596617998336,
  "created_at" : "2012-10-26 15:47:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sergio Tulentsev",
      "screen_name" : "stulentsev",
      "indices" : [ 0, 11 ],
      "id_str" : "17606646",
      "id" : 17606646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261742777119932416",
  "geo" : { },
  "id_str" : "261835369690058752",
  "in_reply_to_user_id" : 17606646,
  "text" : "@stulentsev Sorry :(",
  "id" : 261835369690058752,
  "in_reply_to_status_id" : 261742777119932416,
  "created_at" : "2012-10-26 14:23:11 +0000",
  "in_reply_to_screen_name" : "stulentsev",
  "in_reply_to_user_id_str" : "17606646",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261835096670216192",
  "text" : "Seeing RUSH tonight. Excited!!",
  "id" : 261835096670216192,
  "created_at" : "2012-10-26 14:22:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    }, {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 13, 23 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261681055419994112",
  "geo" : { },
  "id_str" : "261686051108700160",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson @asianmack what a sad existence",
  "id" : 261686051108700160,
  "in_reply_to_status_id" : 261681055419994112,
  "created_at" : "2012-10-26 04:29:51 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lash",
      "screen_name" : "danlash",
      "indices" : [ 0, 8 ],
      "id_str" : "14729552",
      "id" : 14729552
    }, {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 9, 20 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261662165096857600",
  "geo" : { },
  "id_str" : "261662390117085184",
  "in_reply_to_user_id" : 14729552,
  "text" : "@danlash @shellscape my prediction: BOOTS!",
  "id" : 261662390117085184,
  "in_reply_to_status_id" : 261662165096857600,
  "created_at" : "2012-10-26 02:55:49 +0000",
  "in_reply_to_screen_name" : "danlash",
  "in_reply_to_user_id_str" : "14729552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 29, 39 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/261628074746081281\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/beKn7miS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6F9WQrCcAAPW4h.png",
      "id_str" : "261628074750275584",
      "id" : 261628074750275584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6F9WQrCcAAPW4h.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/beKn7miS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261628074746081281",
  "text" : "GameCenter is so (null)! \/cc @asianmack http:\/\/t.co\/beKn7miS",
  "id" : 261628074746081281,
  "created_at" : "2012-10-26 00:39:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asianmack",
      "screen_name" : "asianmack",
      "indices" : [ 0, 10 ],
      "id_str" : "15045995",
      "id" : 15045995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261626132720406528",
  "geo" : { },
  "id_str" : "261627612617662465",
  "in_reply_to_user_id" : 15045995,
  "text" : "@asianmack more like unusable.",
  "id" : 261627612617662465,
  "in_reply_to_status_id" : 261626132720406528,
  "created_at" : "2012-10-26 00:37:38 +0000",
  "in_reply_to_screen_name" : "asianmack",
  "in_reply_to_user_id_str" : "15045995",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261616204920287232",
  "geo" : { },
  "id_str" : "261616763693838337",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk You Only Letterpress Once",
  "id" : 261616763693838337,
  "in_reply_to_status_id" : 261616204920287232,
  "created_at" : "2012-10-25 23:54:31 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 0, 9 ],
      "id_str" : "18545770",
      "id" : 18545770
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 10, 22 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261596428554600448",
  "geo" : { },
  "id_str" : "261609572236685313",
  "in_reply_to_user_id" : 18545770,
  "text" : "@DockYard @bcardarella woot! You should do a write up on how it went!",
  "id" : 261609572236685313,
  "in_reply_to_status_id" : 261596428554600448,
  "created_at" : "2012-10-25 23:25:57 +0000",
  "in_reply_to_screen_name" : "DockYard",
  "in_reply_to_user_id_str" : "18545770",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261590523205255169",
  "geo" : { },
  "id_str" : "261592728540950528",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck because Bundler can\u2019t depend on YAML or JSON.",
  "id" : 261592728540950528,
  "in_reply_to_status_id" : 261590523205255169,
  "created_at" : "2012-10-25 22:19:01 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 29, 37 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 39, 46 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/UDAGCVTk",
      "expanded_url" : "http:\/\/RubyGems.org\/Bundler",
      "display_url" : "RubyGems.org\/Bundler"
    } ]
  },
  "geo" : { },
  "id_str" : "261589849939787776",
  "text" : "Just wanted to say thanks to @evanphx, @hone02 and everyone else that has pitched in with the latest http:\/\/t.co\/UDAGCVTk fires.",
  "id" : 261589849939787776,
  "created_at" : "2012-10-25 22:07:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261583170644885505",
  "geo" : { },
  "id_str" : "261583781310369792",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k I\u2019m mixed on this. I\u2019ve read more code since I can do it on my own pace.",
  "id" : 261583781310369792,
  "in_reply_to_status_id" : 261583170644885505,
  "created_at" : "2012-10-25 21:43:28 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 8, 19 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261549686463283200",
  "geo" : { },
  "id_str" : "261549848011108352",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @jimweirich This is a mistake??",
  "id" : 261549848011108352,
  "in_reply_to_status_id" : 261549686463283200,
  "created_at" : "2012-10-25 19:28:37 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam McCrea",
      "screen_name" : "adamlogic",
      "indices" : [ 0, 10 ],
      "id_str" : "10201182",
      "id" : 10201182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "261541395326726144",
  "geo" : { },
  "id_str" : "261547860712099841",
  "in_reply_to_user_id" : 10201182,
  "text" : "@adamlogic would be awesome to fly this under the OpenHack banner: http:\/\/t.co\/Dih7bxvF",
  "id" : 261547860712099841,
  "in_reply_to_status_id" : 261541395326726144,
  "created_at" : "2012-10-25 19:20:43 +0000",
  "in_reply_to_screen_name" : "adamlogic",
  "in_reply_to_user_id_str" : "10201182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "261524657935634432",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Little Feat: Skin It Back \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 261524657935634432,
  "created_at" : "2012-10-25 17:48:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261513715172638720",
  "text" : "Happening right now in front of my porch: Middle-aged bald dude in PJs blasting shitty tunes out of a yellow Crossfire, polishing it. WTF.",
  "id" : 261513715172638720,
  "created_at" : "2012-10-25 17:05:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "indices" : [ 3, 14 ],
      "id_str" : "20745130",
      "id" : 20745130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/MvtzdMrh",
      "expanded_url" : "http:\/\/www.firstmenonthemoon.com\/",
      "display_url" : "firstmenonthemoon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261492342144507904",
  "text" : "RT @ZachWeiner: http:\/\/t.co\/MvtzdMrh SOOOO COOOOOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/MvtzdMrh",
        "expanded_url" : "http:\/\/www.firstmenonthemoon.com\/",
        "display_url" : "firstmenonthemoon.com"
      } ]
    },
    "geo" : { },
    "id_str" : "261449396657467393",
    "text" : "http:\/\/t.co\/MvtzdMrh SOOOO COOOOOL",
    "id" : 261449396657467393,
    "created_at" : "2012-10-25 12:49:28 +0000",
    "user" : {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "protected" : false,
      "id_str" : "20745130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2634755453\/40ffdf8a114b08a13aecc6f2a3a17320_normal.png",
      "id" : 20745130,
      "verified" : true
    }
  },
  "id" : 261492342144507904,
  "created_at" : "2012-10-25 15:40:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy's Truck",
      "screen_name" : "amys_truck",
      "indices" : [ 0, 11 ],
      "id_str" : "634069219",
      "id" : 634069219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261486662939463680",
  "geo" : { },
  "id_str" : "261487101403615233",
  "in_reply_to_user_id" : 634069219,
  "text" : "@amys_truck Neither of those twitter handles are correct.",
  "id" : 261487101403615233,
  "in_reply_to_status_id" : 261486662939463680,
  "created_at" : "2012-10-25 15:19:17 +0000",
  "in_reply_to_screen_name" : "amys_truck",
  "in_reply_to_user_id_str" : "634069219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 25, 34 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 110 ],
      "url" : "https:\/\/t.co\/FihxbYp0",
      "expanded_url" : "https:\/\/guestlistapp.com\/events\/132006",
      "display_url" : "guestlistapp.com\/events\/132006"
    } ]
  },
  "geo" : { },
  "id_str" : "261476479362289664",
  "text" : "RT @bcardarella: Tonight @DockYard will host Boston\u2019s first OpenHack, open to everybody! https:\/\/t.co\/FihxbYp0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DockYard",
        "screen_name" : "DockYard",
        "indices" : [ 8, 17 ],
        "id_str" : "18545770",
        "id" : 18545770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 93 ],
        "url" : "https:\/\/t.co\/FihxbYp0",
        "expanded_url" : "https:\/\/guestlistapp.com\/events\/132006",
        "display_url" : "guestlistapp.com\/events\/132006"
      } ]
    },
    "geo" : { },
    "id_str" : "261476240597319680",
    "text" : "Tonight @DockYard will host Boston\u2019s first OpenHack, open to everybody! https:\/\/t.co\/FihxbYp0",
    "id" : 261476240597319680,
    "created_at" : "2012-10-25 14:36:08 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 261476479362289664,
  "created_at" : "2012-10-25 14:37:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Watson",
      "screen_name" : "wa7son",
      "indices" : [ 3, 10 ],
      "id_str" : "6063132",
      "id" : 6063132
    }, {
      "name" : "Jim Jones",
      "screen_name" : "aantix",
      "indices" : [ 82, 89 ],
      "id_str" : "3659691",
      "id" : 3659691
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 90, 98 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Steve Derico",
      "screen_name" : "stevederico",
      "indices" : [ 99, 111 ],
      "id_str" : "14655968",
      "id" : 14655968
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 112, 118 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/2V7iLwZ7",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261468178100678657",
  "text" : "RT @wa7son: Anybody have an SF location-suggestion for http:\/\/t.co\/2V7iLwZ7 ? \/cc @aantix @jayunit @stevederico @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Jones",
        "screen_name" : "aantix",
        "indices" : [ 70, 77 ],
        "id_str" : "3659691",
        "id" : 3659691
      }, {
        "name" : "Jason Morrison",
        "screen_name" : "jayunit",
        "indices" : [ 78, 86 ],
        "id_str" : "14238213",
        "id" : 14238213
      }, {
        "name" : "Steve Derico",
        "screen_name" : "stevederico",
        "indices" : [ 87, 99 ],
        "id_str" : "14655968",
        "id" : 14655968
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 100, 106 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/2V7iLwZ7",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "in_reply_to_status_id_str" : "260981326012903424",
    "geo" : { },
    "id_str" : "261359455709589504",
    "in_reply_to_user_id" : 3659691,
    "text" : "Anybody have an SF location-suggestion for http:\/\/t.co\/2V7iLwZ7 ? \/cc @aantix @jayunit @stevederico @qrush",
    "id" : 261359455709589504,
    "in_reply_to_status_id" : 260981326012903424,
    "created_at" : "2012-10-25 06:52:04 +0000",
    "in_reply_to_screen_name" : "aantix",
    "in_reply_to_user_id_str" : "3659691",
    "user" : {
      "name" : "Thomas Watson",
      "screen_name" : "wa7son",
      "protected" : false,
      "id_str" : "6063132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522048892464930818\/kNw8OM28_normal.jpeg",
      "id" : 6063132,
      "verified" : false
    }
  },
  "id" : 261468178100678657,
  "created_at" : "2012-10-25 14:04:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261467421108477952",
  "text" : "It's a hacking on the porch kind of day, and then some RIT Hockey. Heck yes!",
  "id" : 261467421108477952,
  "created_at" : "2012-10-25 14:01:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261314113119084545",
  "geo" : { },
  "id_str" : "261315464096002048",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk Argh!",
  "id" : 261315464096002048,
  "in_reply_to_status_id" : 261314113119084545,
  "created_at" : "2012-10-25 03:57:16 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 54, 65 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/261313963835412480\/photo\/1",
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/RJJG3Uci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6BfqmWCUAEfU3-.png",
      "id_str" : "261313963839606785",
      "id" : 261313963839606785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6BfqmWCUAEfU3-.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RJJG3Uci"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261313963835412480",
  "text" : "HTML made an appearance in this Letterpress duel with @trevorturk ! http:\/\/t.co\/RJJG3Uci",
  "id" : 261313963835412480,
  "created_at" : "2012-10-25 03:51:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    }, {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 12, 23 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261300031880065024",
  "geo" : { },
  "id_str" : "261301901247787008",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk @jasonfried i'm getting this error pretty constantly too. i wonder if it's because it's hammering Game Center.",
  "id" : 261301901247787008,
  "in_reply_to_status_id" : 261300031880065024,
  "created_at" : "2012-10-25 03:03:22 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 0, 11 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 12, 23 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261294786579931136",
  "geo" : { },
  "id_str" : "261295052876288000",
  "in_reply_to_user_id" : 14372143,
  "text" : "@jasonfried @trevorturk it would be nice if it kept track! I can't beat the master wordsmith yet.",
  "id" : 261295052876288000,
  "in_reply_to_status_id" : 261294786579931136,
  "created_at" : "2012-10-25 02:36:09 +0000",
  "in_reply_to_screen_name" : "jasonfried",
  "in_reply_to_user_id_str" : "14372143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Turk",
      "screen_name" : "trevorturk",
      "indices" : [ 0, 11 ],
      "id_str" : "1742",
      "id" : 1742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261290382137122816",
  "geo" : { },
  "id_str" : "261292780796653568",
  "in_reply_to_user_id" : 1742,
  "text" : "@trevorturk this is what I get for playing too many action games",
  "id" : 261292780796653568,
  "in_reply_to_status_id" : 261290382137122816,
  "created_at" : "2012-10-25 02:27:08 +0000",
  "in_reply_to_screen_name" : "trevorturk",
  "in_reply_to_user_id_str" : "1742",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/261281961723691009\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/eQeff38w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6BCj1NCAAAyEpK.png",
      "id_str" : "261281961732079616",
      "id" : 261281961732079616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6BCj1NCAAAyEpK.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/eQeff38w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261281961723691009",
  "text" : "Apparently MEXICAN is not a word. http:\/\/t.co\/eQeff38w",
  "id" : 261281961723691009,
  "created_at" : "2012-10-25 01:44:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261257380136894464",
  "text" : "Alright, bought Letterpress. My Game Center ID is quaranto. Bring it!",
  "id" : 261257380136894464,
  "created_at" : "2012-10-25 00:06:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261249636226977792",
  "text" : "Officially at the point where I'm watching anime subtitled. Somewhat ashamed of this.",
  "id" : 261249636226977792,
  "created_at" : "2012-10-24 23:35:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHack Birmingham",
      "screen_name" : "OpenHackBHM",
      "indices" : [ 3, 15 ],
      "id_str" : "902688300",
      "id" : 902688300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xBEOWOr3",
      "expanded_url" : "http:\/\/openhack.github.com\/birmingham\/",
      "display_url" : "openhack.github.com\/birmingham\/"
    } ]
  },
  "geo" : { },
  "id_str" : "261234300211572737",
  "text" : "RT @OpenHackBHM: A group with a simple purpose: Code together, on anything. If you're a programmer of any kind, come join us! http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/xBEOWOr3",
        "expanded_url" : "http:\/\/openhack.github.com\/birmingham\/",
        "display_url" : "openhack.github.com\/birmingham\/"
      } ]
    },
    "geo" : { },
    "id_str" : "261228805417480192",
    "text" : "A group with a simple purpose: Code together, on anything. If you're a programmer of any kind, come join us! http:\/\/t.co\/xBEOWOr3",
    "id" : 261228805417480192,
    "created_at" : "2012-10-24 22:12:55 +0000",
    "user" : {
      "name" : "OpenHack Birmingham",
      "screen_name" : "OpenHackBHM",
      "protected" : false,
      "id_str" : "902688300",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821332209\/4b1be1b9600913604bed891a097a141e_normal.png",
      "id" : 902688300,
      "verified" : false
    }
  },
  "id" : 261234300211572737,
  "created_at" : "2012-10-24 22:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261223390810087424",
  "text" : "Wikipedia is non-profit, but it's the #5 website in the worBLERGHGHASDASDAHWALL OF TEXTPLEASE GIVE US MONEAYSASDASD",
  "id" : 261223390810087424,
  "created_at" : "2012-10-24 21:51:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 0, 12 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261186346545192963",
  "geo" : { },
  "id_str" : "261189319174287360",
  "in_reply_to_user_id" : 6707392,
  "text" : "@sstephenson time to make a kinect enabled DDR MMO",
  "id" : 261189319174287360,
  "in_reply_to_status_id" : 261186346545192963,
  "created_at" : "2012-10-24 19:36:01 +0000",
  "in_reply_to_screen_name" : "sstephenson",
  "in_reply_to_user_id_str" : "6707392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 3, 15 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/E0cP0lQK",
      "expanded_url" : "http:\/\/f.cl.ly\/items\/1z1R100K1O3R2I1I3F43\/kinect%20png%20stream.mov",
      "display_url" : "f.cl.ly\/items\/1z1R100K\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7JHwDwNi",
      "expanded_url" : "https:\/\/github.com\/sstephenson\/kinect",
      "display_url" : "github.com\/sstephenson\/ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261189096590954498",
  "text" : "RT @sstephenson: Kinect depth PNGs piped to Node.js, then sent to the browser as an HTML5 SSE stream of data URIs. http:\/\/t.co\/E0cP0lQK  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/E0cP0lQK",
        "expanded_url" : "http:\/\/f.cl.ly\/items\/1z1R100K1O3R2I1I3F43\/kinect%20png%20stream.mov",
        "display_url" : "f.cl.ly\/items\/1z1R100K\u2026"
      }, {
        "indices" : [ 119, 140 ],
        "url" : "https:\/\/t.co\/7JHwDwNi",
        "expanded_url" : "https:\/\/github.com\/sstephenson\/kinect",
        "display_url" : "github.com\/sstephenson\/ki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261186346545192963",
    "text" : "Kinect depth PNGs piped to Node.js, then sent to the browser as an HTML5 SSE stream of data URIs. http:\/\/t.co\/E0cP0lQK https:\/\/t.co\/7JHwDwNi",
    "id" : 261186346545192963,
    "created_at" : "2012-10-24 19:24:12 +0000",
    "user" : {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "protected" : false,
      "id_str" : "6707392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434450913151840257\/VySz8SQS_normal.png",
      "id" : 6707392,
      "verified" : false
    }
  },
  "id" : 261189096590954498,
  "created_at" : "2012-10-24 19:35:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261172375536664576",
  "geo" : { },
  "id_str" : "261172845051273216",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic why not a real picture then? Looks shopped, poorly :(",
  "id" : 261172845051273216,
  "in_reply_to_status_id" : 261172375536664576,
  "created_at" : "2012-10-24 18:30:33 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/aD9bnhUr",
      "expanded_url" : "http:\/\/www.avclub.com\/articles\/prepare-your-intestines-for-their-own-unexpected-j,87874\/",
      "display_url" : "avclub.com\/articles\/prepa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261172448236544000",
  "text" : "RT @NYWineWench: I have no words. http:\/\/t.co\/aD9bnhUr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/aD9bnhUr",
        "expanded_url" : "http:\/\/www.avclub.com\/articles\/prepare-your-intestines-for-their-own-unexpected-j,87874\/",
        "display_url" : "avclub.com\/articles\/prepa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261169775089172480",
    "text" : "I have no words. http:\/\/t.co\/aD9bnhUr",
    "id" : 261169775089172480,
    "created_at" : "2012-10-24 18:18:21 +0000",
    "user" : {
      "name" : "Julia Burke",
      "screen_name" : "juliabwrites",
      "protected" : false,
      "id_str" : "72991857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553240923862089728\/a60saFx7_normal.jpeg",
      "id" : 72991857,
      "verified" : false
    }
  },
  "id" : 261172448236544000,
  "created_at" : "2012-10-24 18:28:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261170531947118592",
  "geo" : { },
  "id_str" : "261172147270074368",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic did you guys steal that lower image? :\/",
  "id" : 261172147270074368,
  "in_reply_to_status_id" : 261170531947118592,
  "created_at" : "2012-10-24 18:27:46 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 3, 13 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 75, 81 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261166305342812160",
  "text" : "RT @aquaranto: I googled for a git command I forgot and ended up on a site @qrush wrote when we were in college... Weird.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 60, 66 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261165564813250561",
    "text" : "I googled for a git command I forgot and ended up on a site @qrush wrote when we were in college... Weird.",
    "id" : 261165564813250561,
    "created_at" : "2012-10-24 18:01:37 +0000",
    "user" : {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "protected" : false,
      "id_str" : "5744442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458793231677804544\/0So9q6Uw_normal.jpeg",
      "id" : 5744442,
      "verified" : false
    }
  },
  "id" : 261166305342812160,
  "created_at" : "2012-10-24 18:04:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joshua schachter",
      "screen_name" : "joshu",
      "indices" : [ 0, 6 ],
      "id_str" : "5017",
      "id" : 5017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261163062801858561",
  "geo" : { },
  "id_str" : "261163483427643393",
  "in_reply_to_user_id" : 5017,
  "text" : "@joshu oh my glob.",
  "id" : 261163483427643393,
  "in_reply_to_status_id" : 261163062801858561,
  "created_at" : "2012-10-24 17:53:21 +0000",
  "in_reply_to_screen_name" : "joshu",
  "in_reply_to_user_id_str" : "5017",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 30, 37 ],
      "id_str" : "6505422",
      "id" : 6505422
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 38, 48 ],
      "id_str" : "14575143",
      "id" : 14575143
    }, {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 49, 56 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261155849920208896",
  "geo" : { },
  "id_str" : "261156257782697987",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham haha wow. MIT'd! \/cc @jyurek @joeferris @cpytel",
  "id" : 261156257782697987,
  "in_reply_to_status_id" : 261155849920208896,
  "created_at" : "2012-10-24 17:24:38 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Caudle",
      "screen_name" : "JosephCaudle",
      "indices" : [ 3, 16 ],
      "id_str" : "395411907",
      "id" : 395411907
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 90, 96 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/EMti0EZR",
      "expanded_url" : "http:\/\/openhack.github.com\/fortwayne\/",
      "display_url" : "openhack.github.com\/fortwayne\/"
    } ]
  },
  "geo" : { },
  "id_str" : "261153833781190656",
  "text" : "RT @JosephCaudle: Pretty excited to be getting OpenHack going here! http:\/\/t.co\/EMti0EZR \/@qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 72, 78 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/EMti0EZR",
        "expanded_url" : "http:\/\/openhack.github.com\/fortwayne\/",
        "display_url" : "openhack.github.com\/fortwayne\/"
      } ]
    },
    "geo" : { },
    "id_str" : "261150368044556288",
    "text" : "Pretty excited to be getting OpenHack going here! http:\/\/t.co\/EMti0EZR \/@qrush",
    "id" : 261150368044556288,
    "created_at" : "2012-10-24 17:01:14 +0000",
    "user" : {
      "name" : "Joseph Caudle",
      "screen_name" : "JosephCaudle",
      "protected" : false,
      "id_str" : "395411907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497584646507741184\/r_pN9a6a_normal.jpeg",
      "id" : 395411907,
      "verified" : false
    }
  },
  "id" : 261153833781190656,
  "created_at" : "2012-10-24 17:15:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 14, 30 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 36, 44 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 45, 52 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261150741501190144",
  "geo" : { },
  "id_str" : "261150997567660032",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @rubygems_status wtf? @evanphx @hone02",
  "id" : 261150997567660032,
  "in_reply_to_status_id" : 261150741501190144,
  "created_at" : "2012-10-24 17:03:44 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whentheponydies",
      "screen_name" : "whentheponydies",
      "indices" : [ 0, 16 ],
      "id_str" : "10114802",
      "id" : 10114802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261119178113699841",
  "geo" : { },
  "id_str" : "261132157160923136",
  "in_reply_to_user_id" : 10114802,
  "text" : "@whentheponydies Convinced these sites are for solving big city coworking problems.",
  "id" : 261132157160923136,
  "in_reply_to_status_id" : 261119178113699841,
  "created_at" : "2012-10-24 15:48:52 +0000",
  "in_reply_to_screen_name" : "whentheponydies",
  "in_reply_to_user_id_str" : "10114802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Amy's Truck",
      "screen_name" : "amys_truck",
      "indices" : [ 47, 58 ],
      "id_str" : "634069219",
      "id" : 634069219
    }, {
      "name" : "Sweet Hearth",
      "screen_name" : "SweetHearthNY",
      "indices" : [ 87, 101 ],
      "id_str" : "499027134",
      "id" : 499027134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/BFk1rUSn",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "geo" : { },
  "id_str" : "261131846744670208",
  "text" : "RT @coworkbuffalo: Our food truck page now has @amys_truck! Also we have finally fixed @SweetHearthNY. http:\/\/t.co\/BFk1rUSn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy's Truck",
        "screen_name" : "amys_truck",
        "indices" : [ 28, 39 ],
        "id_str" : "634069219",
        "id" : 634069219
      }, {
        "name" : "Sweet Hearth",
        "screen_name" : "SweetHearthNY",
        "indices" : [ 68, 82 ],
        "id_str" : "499027134",
        "id" : 499027134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/BFk1rUSn",
        "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
        "display_url" : "coworkbuffalo.com\/food"
      } ]
    },
    "geo" : { },
    "id_str" : "261131440459239425",
    "text" : "Our food truck page now has @amys_truck! Also we have finally fixed @SweetHearthNY. http:\/\/t.co\/BFk1rUSn",
    "id" : 261131440459239425,
    "created_at" : "2012-10-24 15:46:01 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 261131846744670208,
  "created_at" : "2012-10-24 15:47:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Caudle",
      "screen_name" : "JosephCaudle",
      "indices" : [ 0, 13 ],
      "id_str" : "395411907",
      "id" : 395411907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261129797852344320",
  "geo" : { },
  "id_str" : "261131147797491712",
  "in_reply_to_user_id" : 395411907,
  "text" : "@JosephCaudle No reason, really. Should be any version of 1.9.3.",
  "id" : 261131147797491712,
  "in_reply_to_status_id" : 261129797852344320,
  "created_at" : "2012-10-24 15:44:51 +0000",
  "in_reply_to_screen_name" : "JosephCaudle",
  "in_reply_to_user_id_str" : "395411907",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Radcliff",
      "screen_name" : "scottradcliff",
      "indices" : [ 0, 14 ],
      "id_str" : "15789234",
      "id" : 15789234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261124410566656000",
  "geo" : { },
  "id_str" : "261124758408687616",
  "in_reply_to_user_id" : 15789234,
  "text" : "@scottradcliff I missed the CFP. :(",
  "id" : 261124758408687616,
  "in_reply_to_status_id" : 261124410566656000,
  "created_at" : "2012-10-24 15:19:28 +0000",
  "in_reply_to_screen_name" : "scottradcliff",
  "in_reply_to_user_id_str" : "15789234",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/2abqjB1P",
      "expanded_url" : "http:\/\/codemash.org\/",
      "display_url" : "codemash.org"
    } ]
  },
  "geo" : { },
  "id_str" : "261121658172080128",
  "text" : "Going to CodeMash 2013. Tickets go on sale at 2pm. http:\/\/t.co\/2abqjB1P 5 words to convince you: CODE WATERSLIDES ARCADE WINTER BOARDGAMES.",
  "id" : 261121658172080128,
  "created_at" : "2012-10-24 15:07:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 3, 15 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 87, 96 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/vaCxIgq0",
      "expanded_url" : "http:\/\/openhack.github.com\/boston",
      "display_url" : "openhack.github.com\/boston"
    } ]
  },
  "geo" : { },
  "id_str" : "261118944486756352",
  "text" : "RT @bcardarella: 7 people already signed up for tomorrow night\u2019s OpenHack in Boston at @DockYard http:\/\/t.co\/vaCxIgq0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DockYard",
        "screen_name" : "DockYard",
        "indices" : [ 70, 79 ],
        "id_str" : "18545770",
        "id" : 18545770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/vaCxIgq0",
        "expanded_url" : "http:\/\/openhack.github.com\/boston",
        "display_url" : "openhack.github.com\/boston"
      } ]
    },
    "geo" : { },
    "id_str" : "261118604811046913",
    "text" : "7 people already signed up for tomorrow night\u2019s OpenHack in Boston at @DockYard http:\/\/t.co\/vaCxIgq0",
    "id" : 261118604811046913,
    "created_at" : "2012-10-24 14:55:01 +0000",
    "user" : {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "protected" : false,
      "id_str" : "18787589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553511645\/21a9348ff9f9ff11f9278695b8afa76d_normal.jpeg",
      "id" : 18787589,
      "verified" : false
    }
  },
  "id" : 261118944486756352,
  "created_at" : "2012-10-24 14:56:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/QxsB7Pd0",
      "expanded_url" : "http:\/\/imgur.com\/a\/LnxLz",
      "display_url" : "imgur.com\/a\/LnxLz"
    } ]
  },
  "geo" : { },
  "id_str" : "261113311213522946",
  "text" : "IS NOTHING EASY? http:\/\/t.co\/QxsB7Pd0",
  "id" : 261113311213522946,
  "created_at" : "2012-10-24 14:33:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 14, 21 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/X1KXxAbH",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/wheredidthesodago",
      "display_url" : "reddit.com\/r\/wheredidthes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261112906672910336",
  "text" : "It seems that @jyurek has discovered a gif vein from deep within the lulz mountain: http:\/\/t.co\/X1KXxAbH",
  "id" : 261112906672910336,
  "created_at" : "2012-10-24 14:32:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Dixon",
      "screen_name" : "obfuscurity",
      "indices" : [ 0, 12 ],
      "id_str" : "66432490",
      "id" : 66432490
    }, {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 13, 23 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "indices" : [ 24, 37 ],
      "id_str" : "19768213",
      "id" : 19768213
    }, {
      "name" : "Baltimore JavaScript",
      "screen_name" : "bmorejs",
      "indices" : [ 38, 46 ],
      "id_str" : "56393254",
      "id" : 56393254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261102525065875457",
  "geo" : { },
  "id_str" : "261109061062373378",
  "in_reply_to_user_id" : 66432490,
  "text" : "@obfuscurity @ngauthier @bmoreonrails @bmorejs A+++++ WOULD MERGE PULL REQUEST",
  "id" : 261109061062373378,
  "in_reply_to_status_id" : 261102525065875457,
  "created_at" : "2012-10-24 14:17:05 +0000",
  "in_reply_to_screen_name" : "obfuscurity",
  "in_reply_to_user_id_str" : "66432490",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 14, 22 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "OpenHack",
      "screen_name" : "openhack",
      "indices" : [ 41, 50 ],
      "id_str" : "715440464",
      "id" : 715440464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261107475569332224",
  "text" : "Can anyone at @twitter help me take over @openhack ? Would love to use it for announcements, etc.",
  "id" : 261107475569332224,
  "created_at" : "2012-10-24 14:10:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "David J",
      "screen_name" : "djwonk",
      "indices" : [ 8, 15 ],
      "id_str" : "10251992",
      "id" : 10251992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261093276449382400",
  "geo" : { },
  "id_str" : "261099999407009793",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @djwonk start it up again!",
  "id" : 261099999407009793,
  "in_reply_to_status_id" : 261093276449382400,
  "created_at" : "2012-10-24 13:41:05 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 14, 19 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261087902388330496",
  "geo" : { },
  "id_str" : "261089670002249728",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito @avdi been brainstorming all morning about this. Will post soon!",
  "id" : 261089670002249728,
  "in_reply_to_status_id" : 261087902388330496,
  "created_at" : "2012-10-24 13:00:02 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/t9AGlwLL",
      "expanded_url" : "http:\/\/rob.pike.usesthis.com\/",
      "display_url" : "rob.pike.usesthis.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261081577671503874",
  "text" : "The best Setup so far. Plan 9 pipedreams. http:\/\/t.co\/t9AGlwLL",
  "id" : 261081577671503874,
  "created_at" : "2012-10-24 12:27:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "indices" : [ 3, 12 ],
      "id_str" : "18545770",
      "id" : 18545770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/pqgTthkt",
      "expanded_url" : "http:\/\/openhack.github.com\/boston",
      "display_url" : "openhack.github.com\/boston"
    } ]
  },
  "geo" : { },
  "id_str" : "261080421104766976",
  "text" : "RT @DockYard: We\u2019re happy to host Boston\u2019s first OpenHack event this Thursday: http:\/\/t.co\/pqgTthkt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/pqgTthkt",
        "expanded_url" : "http:\/\/openhack.github.com\/boston",
        "display_url" : "openhack.github.com\/boston"
      } ]
    },
    "geo" : { },
    "id_str" : "260968351059292161",
    "text" : "We\u2019re happy to host Boston\u2019s first OpenHack event this Thursday: http:\/\/t.co\/pqgTthkt",
    "id" : 260968351059292161,
    "created_at" : "2012-10-24 04:57:58 +0000",
    "user" : {
      "name" : "DockYard",
      "screen_name" : "DockYard",
      "protected" : false,
      "id_str" : "18545770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000606125141\/c367193b2bf7b32dad02e39c9db058f5_normal.jpeg",
      "id" : 18545770,
      "verified" : false
    }
  },
  "id" : 261080421104766976,
  "created_at" : "2012-10-24 12:23:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal",
      "screen_name" : "Neal_Kemp",
      "indices" : [ 3, 13 ],
      "id_str" : "285978809",
      "id" : 285978809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/s42oAL8q",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "261080393078427648",
  "text" : "RT @Neal_Kemp: Anyone else in San Jose want to get this started? http:\/\/t.co\/s42oAL8q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/s42oAL8q",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260959959183933441",
    "text" : "Anyone else in San Jose want to get this started? http:\/\/t.co\/s42oAL8q",
    "id" : 260959959183933441,
    "created_at" : "2012-10-24 04:24:37 +0000",
    "user" : {
      "name" : "Neal",
      "screen_name" : "Neal_Kemp",
      "protected" : false,
      "id_str" : "285978809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462632835585560577\/CWIFiAhm_normal.jpeg",
      "id" : 285978809,
      "verified" : false
    }
  },
  "id" : 261080393078427648,
  "created_at" : "2012-10-24 12:23:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 3, 9 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261080389152555008",
  "text" : "RT @cmeik: gonna try to organize this openhack thing in pvd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260958039333535745",
    "text" : "gonna try to organize this openhack thing in pvd",
    "id" : 260958039333535745,
    "created_at" : "2012-10-24 04:16:59 +0000",
    "user" : {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "protected" : false,
      "id_str" : "6815762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563790577485889540\/RAksq4d3_normal.jpeg",
      "id" : 6815762,
      "verified" : false
    }
  },
  "id" : 261080389152555008,
  "created_at" : "2012-10-24 12:23:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260955669123977216",
  "geo" : { },
  "id_str" : "260956148159631361",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi agreed. Been thinking of having one here in Buffalo, but something more general would be longer lasting. Like CodeMash or StrangeLoop.",
  "id" : 260956148159631361,
  "in_reply_to_status_id" : 260955669123977216,
  "created_at" : "2012-10-24 04:09:28 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevan MacGee",
      "screen_name" : "kevanmacgee",
      "indices" : [ 3, 15 ],
      "id_str" : "263450469",
      "id" : 263450469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROC",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/YklnPz6Z",
      "expanded_url" : "http:\/\/openhack.github.com",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260955926385795072",
  "text" : "RT @kevanmacgee: So who else is interested in starting an OpenHack here in Rochester?http:\/\/t.co\/YklnPz6Z #ROC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROC",
        "indices" : [ 89, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/YklnPz6Z",
        "expanded_url" : "http:\/\/openhack.github.com",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260952152367824896",
    "text" : "So who else is interested in starting an OpenHack here in Rochester?http:\/\/t.co\/YklnPz6Z #ROC",
    "id" : 260952152367824896,
    "created_at" : "2012-10-24 03:53:36 +0000",
    "user" : {
      "name" : "Kevan MacGee",
      "screen_name" : "kevanmacgee",
      "protected" : false,
      "id_str" : "263450469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267475636\/n536652332_1092767_2766_square_normal.jpg",
      "id" : 263450469,
      "verified" : false
    }
  },
  "id" : 260955926385795072,
  "created_at" : "2012-10-24 04:08:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Watson",
      "screen_name" : "wa7son",
      "indices" : [ 3, 10 ],
      "id_str" : "6063132",
      "id" : 6063132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/2V7iLwZ7",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260943215056793600",
  "text" : "RT @wa7son: Hi San Francisco hackers. Would you guys wanna http:\/\/t.co\/2V7iLwZ7 ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/2V7iLwZ7",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260932361116585984",
    "text" : "Hi San Francisco hackers. Would you guys wanna http:\/\/t.co\/2V7iLwZ7 ?",
    "id" : 260932361116585984,
    "created_at" : "2012-10-24 02:34:57 +0000",
    "user" : {
      "name" : "Thomas Watson",
      "screen_name" : "wa7son",
      "protected" : false,
      "id_str" : "6063132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522048892464930818\/kNw8OM28_normal.jpeg",
      "id" : 6063132,
      "verified" : false
    }
  },
  "id" : 260943215056793600,
  "created_at" : "2012-10-24 03:18:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Meeker",
      "screen_name" : "CuriousCurmudge",
      "indices" : [ 3, 19 ],
      "id_str" : "87356793",
      "id" : 87356793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mlbw2UfI",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260943052431048704",
  "text" : "RT @CuriousCurmudge: Any interest in putting together an OpenHack group in Richmond? Professionals and students welcome. http:\/\/t.co\/mlb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/mlbw2UfI",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260941734102568962",
    "text" : "Any interest in putting together an OpenHack group in Richmond? Professionals and students welcome. http:\/\/t.co\/mlbw2UfI",
    "id" : 260941734102568962,
    "created_at" : "2012-10-24 03:12:12 +0000",
    "user" : {
      "name" : "Brian Meeker",
      "screen_name" : "CuriousCurmudge",
      "protected" : false,
      "id_str" : "87356793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528238551951884288\/CtKAFUoT_normal.jpeg",
      "id" : 87356793,
      "verified" : false
    }
  },
  "id" : 260943052431048704,
  "created_at" : "2012-10-24 03:17:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Busch",
      "screen_name" : "mikelikesbikes",
      "indices" : [ 0, 15 ],
      "id_str" : "10444422",
      "id" : 10444422
    }, {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 16, 25 ],
      "id_str" : "5573992",
      "id" : 5573992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260933601158393857",
  "geo" : { },
  "id_str" : "260934337900466178",
  "in_reply_to_user_id" : 10444422,
  "text" : "@mikelikesbikes @tundal45 I think variations on the night theme are acceptable. Multiple OHs per city too.",
  "id" : 260934337900466178,
  "in_reply_to_status_id" : 260933601158393857,
  "created_at" : "2012-10-24 02:42:48 +0000",
  "in_reply_to_screen_name" : "mikelikesbikes",
  "in_reply_to_user_id_str" : "10444422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conferenshish",
      "screen_name" : "tundal45",
      "indices" : [ 0, 9 ],
      "id_str" : "5573992",
      "id" : 5573992
    }, {
      "name" : "Mike Busch",
      "screen_name" : "mikelikesbikes",
      "indices" : [ 10, 25 ],
      "id_str" : "10444422",
      "id" : 10444422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260926569848127490",
  "geo" : { },
  "id_str" : "260930586041016322",
  "in_reply_to_user_id" : 5573992,
  "text" : "@tundal45 @mikelikesbikes keep me posted! Not sure how Code &amp; Coffee works, but the intros are a big deal for welcoming people",
  "id" : 260930586041016322,
  "in_reply_to_status_id" : 260926569848127490,
  "created_at" : "2012-10-24 02:27:54 +0000",
  "in_reply_to_screen_name" : "tundal45",
  "in_reply_to_user_id_str" : "5573992",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 0, 10 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260929652548329472",
  "geo" : { },
  "id_str" : "260929746509103104",
  "in_reply_to_user_id" : 31435721,
  "text" : "@aspleenic where were you?",
  "id" : 260929746509103104,
  "in_reply_to_status_id" : 260929652548329472,
  "created_at" : "2012-10-24 02:24:34 +0000",
  "in_reply_to_screen_name" : "aspleenic",
  "in_reply_to_user_id_str" : "31435721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "indices" : [ 3, 11 ],
      "id_str" : "9664212",
      "id" : 9664212
    }, {
      "name" : "End of Line Club",
      "screen_name" : "EOLclub",
      "indices" : [ 17, 25 ],
      "id_str" : "517181695",
      "id" : 517181695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/y4uTUviB",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260924682138689536",
  "text" : "RT @joealba: Hey @EOLclub, want to get PVD on this list? http:\/\/t.co\/y4uTUviB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "End of Line Club",
        "screen_name" : "EOLclub",
        "indices" : [ 4, 12 ],
        "id_str" : "517181695",
        "id" : 517181695
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/y4uTUviB",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260919880696623104",
    "text" : "Hey @EOLclub, want to get PVD on this list? http:\/\/t.co\/y4uTUviB",
    "id" : 260919880696623104,
    "created_at" : "2012-10-24 01:45:21 +0000",
    "user" : {
      "name" : "Joe Alba",
      "screen_name" : "joealba",
      "protected" : false,
      "id_str" : "9664212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523186241777319936\/ms43eT3N_normal.jpeg",
      "id" : 9664212,
      "verified" : false
    }
  },
  "id" : 260924682138689536,
  "created_at" : "2012-10-24 02:04:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    }, {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "indices" : [ 15, 28 ],
      "id_str" : "19768213",
      "id" : 19768213
    }, {
      "name" : "Baltimore JavaScript",
      "screen_name" : "bmorejs",
      "indices" : [ 29, 37 ],
      "id_str" : "56393254",
      "id" : 56393254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/2NnHjStF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260924672881868800",
  "text" : "RT @ngauthier: @bmoreonrails @bmorejs we should get on this http:\/\/t.co\/2NnHjStF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "B'more on Rails",
        "screen_name" : "bmoreonrails",
        "indices" : [ 0, 13 ],
        "id_str" : "19768213",
        "id" : 19768213
      }, {
        "name" : "Baltimore JavaScript",
        "screen_name" : "bmorejs",
        "indices" : [ 14, 22 ],
        "id_str" : "56393254",
        "id" : 56393254
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/2NnHjStF",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260919409839857664",
    "in_reply_to_user_id" : 19768213,
    "text" : "@bmoreonrails @bmorejs we should get on this http:\/\/t.co\/2NnHjStF",
    "id" : 260919409839857664,
    "created_at" : "2012-10-24 01:43:29 +0000",
    "in_reply_to_screen_name" : "bmoreonrails",
    "in_reply_to_user_id_str" : "19768213",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539452893112201217\/aJOphfgM_normal.png",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 260924672881868800,
  "created_at" : "2012-10-24 02:04:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Cowart",
      "screen_name" : "davecowart",
      "indices" : [ 3, 14 ],
      "id_str" : "14774213",
      "id" : 14774213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/UCjCCE5x",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260924661896990720",
  "text" : "RT @davecowart: would any developers (in Birmingham) be interested in doing this? http:\/\/t.co\/UCjCCE5x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/UCjCCE5x",
        "expanded_url" : "http:\/\/openhack.github.com\/",
        "display_url" : "openhack.github.com"
      } ]
    },
    "geo" : { },
    "id_str" : "260917044596338688",
    "text" : "would any developers (in Birmingham) be interested in doing this? http:\/\/t.co\/UCjCCE5x",
    "id" : 260917044596338688,
    "created_at" : "2012-10-24 01:34:05 +0000",
    "user" : {
      "name" : "Dave Cowart",
      "screen_name" : "davecowart",
      "protected" : false,
      "id_str" : "14774213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000080955551\/8985ae86dd1892a86397595b1881783f_normal.jpeg",
      "id" : 14774213,
      "verified" : false
    }
  },
  "id" : 260924661896990720,
  "created_at" : "2012-10-24 02:04:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 69 ],
      "url" : "https:\/\/t.co\/zKFhAwgR",
      "expanded_url" : "https:\/\/github.com\/OpenHack\/openhack.github.com\/pull\/1",
      "display_url" : "github.com\/OpenHack\/openh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260918845227819008",
  "text" : "Got our first PR for a new #openhack city: NYC! https:\/\/t.co\/zKFhAwgR",
  "id" : 260918845227819008,
  "created_at" : "2012-10-24 01:41:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    }, {
      "name" : "Ernie Miller",
      "screen_name" : "erniemiller",
      "indices" : [ 10, 22 ],
      "id_str" : "16143891",
      "id" : 16143891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260915233445535745",
  "geo" : { },
  "id_str" : "260915428619059200",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn @erniemiller Yes! Let me know if I can help with the site!",
  "id" : 260915428619059200,
  "in_reply_to_status_id" : 260915233445535745,
  "created_at" : "2012-10-24 01:27:40 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Dih7bxvF",
      "expanded_url" : "http:\/\/openhack.github.com\/",
      "display_url" : "openhack.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260911017868013569",
  "text" : "Excited to announce a community site for #openhack! Let's get your city on the list: http:\/\/t.co\/Dih7bxvF",
  "id" : 260911017868013569,
  "created_at" : "2012-10-24 01:10:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 0, 11 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260890094569943040",
  "geo" : { },
  "id_str" : "260890269715681280",
  "in_reply_to_user_id" : 14687182,
  "text" : "@kevinpurdy Bringing down the house.",
  "id" : 260890269715681280,
  "in_reply_to_status_id" : 260890094569943040,
  "created_at" : "2012-10-23 23:47:42 +0000",
  "in_reply_to_screen_name" : "kevinpurdy",
  "in_reply_to_user_id_str" : "14687182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 32, 46 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/260888152800112640\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/p3FSj4FZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A57cZIpCMAA_sr4.jpg",
      "id_str" : "260888152808501248",
      "id" : 260888152808501248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A57cZIpCMAA_sr4.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/p3FSj4FZ"
    } ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260888152800112640",
  "text" : "19 people here for #openhack at @coworkbuffalo ! So excited to bring together Buffalo\u2019s tech community. http:\/\/t.co\/p3FSj4FZ",
  "id" : 260888152800112640,
  "created_at" : "2012-10-23 23:39:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260887105960562688",
  "text" : "\"Please find more details below, as this is a HOT POSITION and URGETNT,  please reply back me soon. And even ready to pay any rate\"",
  "id" : 260887105960562688,
  "created_at" : "2012-10-23 23:35:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "Melissa Sullivan",
      "screen_name" : "globalquest",
      "indices" : [ 14, 26 ],
      "id_str" : "33045069",
      "id" : 33045069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260806399674707969",
  "geo" : { },
  "id_str" : "260814794641264641",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito @globalquest sounds good to me, and thanks! going to order around 6 like last time.",
  "id" : 260814794641264641,
  "in_reply_to_status_id" : 260806399674707969,
  "created_at" : "2012-10-23 18:47:47 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260726638839463936",
  "text" : "Lots of terrible driving tweets today in Buffalo. Happy to be taking the bus.",
  "id" : 260726638839463936,
  "created_at" : "2012-10-23 12:57:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 25, 38 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260610517394128896",
  "text" : "Trying to predict future @herpderpedia events. Next up: \u201Chow do I vote?\u201D",
  "id" : 260610517394128896,
  "created_at" : "2012-10-23 05:16:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 3, 10 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "\u0412\u0441\u0435\u0441\u043B\u0430\u0432 \u041F\u043E\u043A\u0440\u043E\u0432\u0441\u043A\u0438\u0439",
      "screen_name" : "dan_sosedoff",
      "indices" : [ 56, 69 ],
      "id_str" : "203110801",
      "id" : 203110801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/UEOh49rd",
      "expanded_url" : "http:\/\/status.rubygems.org\/",
      "display_url" : "status.rubygems.org"
    }, {
      "indices" : [ 71, 92 ],
      "url" : "https:\/\/t.co\/ahunPeA5",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems-status\/pull\/4",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260590106895872001",
  "text" : "RT @sferik: Awesome redesign of http:\/\/t.co\/UEOh49rd by @dan_sosedoff: https:\/\/t.co\/ahunPeA5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0412\u0441\u0435\u0441\u043B\u0430\u0432 \u041F\u043E\u043A\u0440\u043E\u0432\u0441\u043A\u0438\u0439",
        "screen_name" : "dan_sosedoff",
        "indices" : [ 44, 57 ],
        "id_str" : "203110801",
        "id" : 203110801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/UEOh49rd",
        "expanded_url" : "http:\/\/status.rubygems.org\/",
        "display_url" : "status.rubygems.org"
      }, {
        "indices" : [ 59, 80 ],
        "url" : "https:\/\/t.co\/ahunPeA5",
        "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems-status\/pull\/4",
        "display_url" : "github.com\/rubygems\/rubyg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "260484410405699585",
    "text" : "Awesome redesign of http:\/\/t.co\/UEOh49rd by @dan_sosedoff: https:\/\/t.co\/ahunPeA5",
    "id" : 260484410405699585,
    "created_at" : "2012-10-22 20:54:57 +0000",
    "user" : {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "protected" : false,
      "id_str" : "7505382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567932260847206401\/ErQwT5za_normal.jpeg",
      "id" : 7505382,
      "verified" : false
    }
  },
  "id" : 260590106895872001,
  "created_at" : "2012-10-23 03:54:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 3, 12 ],
      "id_str" : "20531902",
      "id" : 20531902
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 84, 98 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenHack",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ZVpKnr9L",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/86099862\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260589775868809218",
  "text" : "RT @sabiddle: Held off on coding tonight so I have something to do for #OpenHack at @coworkbuffalo tomorrow night. http:\/\/t.co\/ZVpKnr9L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 70, 84 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenHack",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/ZVpKnr9L",
        "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/86099862\/",
        "display_url" : "meetup.com\/Western-New-Yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "260574737011449856",
    "text" : "Held off on coding tonight so I have something to do for #OpenHack at @coworkbuffalo tomorrow night. http:\/\/t.co\/ZVpKnr9L",
    "id" : 260574737011449856,
    "created_at" : "2012-10-23 02:53:53 +0000",
    "user" : {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "protected" : false,
      "id_str" : "20531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2696016475\/32aa0b0b3249511f0e106601d87bab01_normal.png",
      "id" : 20531902,
      "verified" : false
    }
  },
  "id" : 260589775868809218,
  "created_at" : "2012-10-23 03:53:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robison",
      "screen_name" : "robisonrobison",
      "indices" : [ 0, 15 ],
      "id_str" : "47352570",
      "id" : 47352570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260588532916162561",
  "geo" : { },
  "id_str" : "260588925918248961",
  "in_reply_to_user_id" : 47352570,
  "text" : "@robisonrobison that location would keep the skyway around too. :( need them downtown though!",
  "id" : 260588925918248961,
  "in_reply_to_status_id" : 260588532916162561,
  "created_at" : "2012-10-23 03:50:16 +0000",
  "in_reply_to_screen_name" : "robisonrobison",
  "in_reply_to_user_id_str" : "47352570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/Pmm9Fe5w",
      "expanded_url" : "http:\/\/bitly.com\/XMTn1U",
      "display_url" : "bitly.com\/XMTn1U"
    } ]
  },
  "geo" : { },
  "id_str" : "260588288694419456",
  "text" : "Please PLEASE let the Bills move downtown. It\u2019s time! http:\/\/t.co\/Pmm9Fe5w",
  "id" : 260588288694419456,
  "created_at" : "2012-10-23 03:47:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Spahr-Summers",
      "screen_name" : "jspahrsummers",
      "indices" : [ 0, 14 ],
      "id_str" : "166028855",
      "id" : 166028855
    }, {
      "name" : "jp",
      "screen_name" : "jparishy",
      "indices" : [ 15, 24 ],
      "id_str" : "22065324",
      "id" : 22065324
    }, {
      "name" : "Terin Stock",
      "screen_name" : "terinjokes",
      "indices" : [ 25, 36 ],
      "id_str" : "69052146",
      "id" : 69052146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260480394804207617",
  "geo" : { },
  "id_str" : "260480835776569344",
  "in_reply_to_user_id" : 166028855,
  "text" : "@jspahrsummers @jparishy @terinjokes Definitely better. Submodules make me sad.",
  "id" : 260480835776569344,
  "in_reply_to_status_id" : 260480394804207617,
  "created_at" : "2012-10-22 20:40:45 +0000",
  "in_reply_to_screen_name" : "jspahrsummers",
  "in_reply_to_user_id_str" : "166028855",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260471124742270976",
  "geo" : { },
  "id_str" : "260474906335145984",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito I have no idea where the receipt went from last time...so was going to give it to EY!",
  "id" : 260474906335145984,
  "in_reply_to_status_id" : 260471124742270976,
  "created_at" : "2012-10-22 20:17:11 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terin Stock",
      "screen_name" : "terinjokes",
      "indices" : [ 0, 11 ],
      "id_str" : "69052146",
      "id" : 69052146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260463608935370752",
  "geo" : { },
  "id_str" : "260464654692782080",
  "in_reply_to_user_id" : 69052146,
  "text" : "@terinjokes It just seems out of place and tossed in, definitely bloat.",
  "id" : 260464654692782080,
  "in_reply_to_status_id" : 260463608935370752,
  "created_at" : "2012-10-22 19:36:27 +0000",
  "in_reply_to_screen_name" : "terinjokes",
  "in_reply_to_user_id_str" : "69052146",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 120 ],
      "url" : "https:\/\/t.co\/sOPVkzva",
      "expanded_url" : "https:\/\/github.com\/github\/Mantle\/blob\/master\/Mantle\/CGGeometry%2BMTLConvenienceAdditions.h",
      "display_url" : "github.com\/github\/Mantle\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260460587350376448",
  "text" : "Of course an iOS data model framework needs geometry helper functions. THROW IT ALL IN. *facepalm* https:\/\/t.co\/sOPVkzva",
  "id" : 260460587350376448,
  "created_at" : "2012-10-22 19:20:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260453174412996609",
  "geo" : { },
  "id_str" : "260456952264536064",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn Nope, on Mac too.",
  "id" : 260456952264536064,
  "in_reply_to_status_id" : 260453174412996609,
  "created_at" : "2012-10-22 19:05:51 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/qppixk1n",
      "expanded_url" : "http:\/\/www.ftlgame.com\/",
      "display_url" : "ftlgame.com"
    } ]
  },
  "in_reply_to_status_id_str" : "260451120210644992",
  "geo" : { },
  "id_str" : "260451459500482562",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh FTL. Only $10 on Steam. http:\/\/t.co\/qppixk1n",
  "id" : 260451459500482562,
  "in_reply_to_status_id" : 260451120210644992,
  "created_at" : "2012-10-22 18:44:01 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 21, 28 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260426346289831936",
  "geo" : { },
  "id_str" : "260430502861873152",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan roger! @hone02 might have updates !",
  "id" : 260430502861873152,
  "in_reply_to_status_id" : 260426346289831936,
  "created_at" : "2012-10-22 17:20:45 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 3, 16 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/LL0OWZpZ",
      "expanded_url" : "http:\/\/i.imgur.com\/WTta3.gif",
      "display_url" : "i.imgur.com\/WTta3.gif"
    }, {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/DhmQ6wTG",
      "expanded_url" : "http:\/\/i.imgur.com\/OmrVb.gif",
      "display_url" : "i.imgur.com\/OmrVb.gif"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/3CVnp0lh",
      "expanded_url" : "http:\/\/i.imgur.com\/Drd2P.gif",
      "display_url" : "i.imgur.com\/Drd2P.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "260390571456204802",
  "text" : "RT @lindseybieda: Mitt Romney as Leonard J Crabs: http:\/\/t.co\/LL0OWZpZ http:\/\/t.co\/DhmQ6wTG http:\/\/t.co\/3CVnp0lh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/rstat.us\/\" rel=\"nofollow\"\u003ERstat.us App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/LL0OWZpZ",
        "expanded_url" : "http:\/\/i.imgur.com\/WTta3.gif",
        "display_url" : "i.imgur.com\/WTta3.gif"
      }, {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/DhmQ6wTG",
        "expanded_url" : "http:\/\/i.imgur.com\/OmrVb.gif",
        "display_url" : "i.imgur.com\/OmrVb.gif"
      }, {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/3CVnp0lh",
        "expanded_url" : "http:\/\/i.imgur.com\/Drd2P.gif",
        "display_url" : "i.imgur.com\/Drd2P.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "260183418103537664",
    "text" : "Mitt Romney as Leonard J Crabs: http:\/\/t.co\/LL0OWZpZ http:\/\/t.co\/DhmQ6wTG http:\/\/t.co\/3CVnp0lh",
    "id" : 260183418103537664,
    "created_at" : "2012-10-22 00:58:55 +0000",
    "user" : {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "protected" : false,
      "id_str" : "14928483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569192760029089792\/zaGhTAHK_normal.jpeg",
      "id" : 14928483,
      "verified" : false
    }
  },
  "id" : 260390571456204802,
  "created_at" : "2012-10-22 14:42:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 51, 65 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 87, 99 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260388831986073600",
  "text" : "Hey, it's Monday! Who's getting some stuff done at @coworkbuffalo today? Thinking of a @whereslloyd run...",
  "id" : 260388831986073600,
  "created_at" : "2012-10-22 14:35:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 13, 20 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260386434635145216",
  "geo" : { },
  "id_str" : "260386747689627649",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @hone02 bundle ALL THE GEMS!",
  "id" : 260386747689627649,
  "in_reply_to_status_id" : 260386434635145216,
  "created_at" : "2012-10-22 14:26:53 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 4, 16 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260385530829750272",
  "text" : "Hey @turntablefm your twitter login has been broken for over a week now. Can you please fix it?",
  "id" : 260385530829750272,
  "created_at" : "2012-10-22 14:22:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "260374529774321664",
  "geo" : { },
  "id_str" : "260379668400701440",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock it makes the git repos huge though. this is the policy on http:\/\/t.co\/bdjsRgTW but i wouldn't force that on other apps.",
  "id" : 260379668400701440,
  "in_reply_to_status_id" : 260374529774321664,
  "created_at" : "2012-10-22 13:58:45 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 41, 55 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenHack",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/64xqvD4F",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/86099862\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260372797614850048",
  "text" : "Very pumped for #OpenHack tomorrow night @coworkbuffalo. Hoping to launch something fun! http:\/\/t.co\/64xqvD4F",
  "id" : 260372797614850048,
  "created_at" : "2012-10-22 13:31:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/IWa3Qxnw",
      "expanded_url" : "http:\/\/hone.herokuapp.com\/bundler%20heroku\/2012\/10\/22\/rubygems-and-the-dependency-api.html",
      "display_url" : "hone.herokuapp.com\/bundler%20hero\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260362925259231235",
  "text" : "We need some help testing the new Bundler Dependency API server: http:\/\/t.co\/IWa3Qxnw",
  "id" : 260362925259231235,
  "created_at" : "2012-10-22 12:52:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bills",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/lDSWjW0f",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MK6TXMsvgQg",
      "display_url" : "youtube.com\/watch?v=MK6TXM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260072869688668160",
  "text" : "Current #Bills game status: http:\/\/t.co\/lDSWjW0f",
  "id" : 260072869688668160,
  "created_at" : "2012-10-21 17:39:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259832783625658368",
  "text" : "Sometimes when watching sports events, I wonder how good of a 2D polygon I\u2019d make in a sports game audience.",
  "id" : 259832783625658368,
  "created_at" : "2012-10-21 01:45:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35(\u03DB\u3123\u0287lo\u0287s@)",
      "screen_name" : "stolt45",
      "indices" : [ 0, 8 ],
      "id_str" : "9483652",
      "id" : 9483652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259667769015009280",
  "geo" : { },
  "id_str" : "259671268092178432",
  "in_reply_to_user_id" : 9483652,
  "text" : "@stolt45 lockout dude\u2026RIT hockey tonight though! Sold out :(",
  "id" : 259671268092178432,
  "in_reply_to_status_id" : 259667769015009280,
  "created_at" : "2012-10-20 15:03:49 +0000",
  "in_reply_to_screen_name" : "stolt45",
  "in_reply_to_user_id_str" : "9483652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u256F\u00B0\u25A1\u00B0)\u256F\uFE35(\u03DB\u3123\u0287lo\u0287s@)",
      "screen_name" : "stolt45",
      "indices" : [ 0, 8 ],
      "id_str" : "9483652",
      "id" : 9483652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259658775051517952",
  "geo" : { },
  "id_str" : "259664176992100352",
  "in_reply_to_user_id" : 9483652,
  "text" : "@stolt45 are you here? Just today for the hockey game too. Buffalo isn\u2019t that far away!",
  "id" : 259664176992100352,
  "in_reply_to_status_id" : 259658775051517952,
  "created_at" : "2012-10-20 14:35:38 +0000",
  "in_reply_to_screen_name" : "stolt45",
  "in_reply_to_user_id_str" : "9483652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259655937462251520",
  "text" : "Hi RIT!",
  "id" : 259655937462251520,
  "created_at" : "2012-10-20 14:02:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259484655038894081",
  "geo" : { },
  "id_str" : "259484962087133184",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove the transcript is good. Basically, going to offload the dependency API to Heroku.",
  "id" : 259484962087133184,
  "in_reply_to_status_id" : 259484655038894081,
  "created_at" : "2012-10-20 02:43:30 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "indices" : [ 3, 18 ],
      "id_str" : "415345747",
      "id" : 415345747
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259480698992340992",
  "text" : "RT @parkerwightman: @qrush Seeing inside these kinds of issues is extremely enlightening, I wish OS platforms would hold public collabor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "259479554199011328",
    "geo" : { },
    "id_str" : "259480312617242624",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush Seeing inside these kinds of issues is extremely enlightening, I wish OS platforms would hold public collaborations more often.",
    "id" : 259480312617242624,
    "in_reply_to_status_id" : 259479554199011328,
    "created_at" : "2012-10-20 02:25:02 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Parker Wightman",
      "screen_name" : "parkerwightman",
      "protected" : false,
      "id_str" : "415345747",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3275135966\/0807c621b3a96c8c9c451844e9812f8e_normal.jpeg",
      "id" : 415345747,
      "verified" : false
    }
  },
  "id" : 259480698992340992,
  "created_at" : "2012-10-20 02:26:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    }, {
      "name" : "Joe Hsu",
      "screen_name" : "jhsu",
      "indices" : [ 9, 14 ],
      "id_str" : "33823",
      "id" : 33823
    }, {
      "name" : "R D Old",
      "screen_name" : "thatRD",
      "indices" : [ 15, 22 ],
      "id_str" : "1928924059",
      "id" : 1928924059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259464346269282306",
  "geo" : { },
  "id_str" : "259480287187177473",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle @jhsu @thatRD thanks! definitely still learning a lot here. trying to be as open as possible.",
  "id" : 259480287187177473,
  "in_reply_to_status_id" : 259464346269282306,
  "created_at" : "2012-10-20 02:24:56 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 3, 9 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 34, 43 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 60, 69 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259479648268845056",
  "text" : "RT @cmeik: If I was to organize a @rubygems.org hackfest at @rubyconf to help people get their first commit, would you be interested?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 23, 32 ],
        "id_str" : "14881835",
        "id" : 14881835
      }, {
        "name" : "rubyconf",
        "screen_name" : "rubyconf",
        "indices" : [ 49, 58 ],
        "id_str" : "16222737",
        "id" : 16222737
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259479105752412161",
    "text" : "If I was to organize a @rubygems.org hackfest at @rubyconf to help people get their first commit, would you be interested?",
    "id" : 259479105752412161,
    "created_at" : "2012-10-20 02:20:14 +0000",
    "user" : {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "protected" : false,
      "id_str" : "6815762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563790577485889540\/RAksq4d3_normal.jpeg",
      "id" : 6815762,
      "verified" : false
    }
  },
  "id" : 259479648268845056,
  "created_at" : "2012-10-20 02:22:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "259479554199011328",
  "text" : "Crazy stats from tonight's http:\/\/t.co\/bdjsRgTW hangout: 300 gems pushed avg\/day over the past 30 days, nearly 250K unique versions indexed!",
  "id" : 259479554199011328,
  "created_at" : "2012-10-20 02:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259478089350934528",
  "text" : "G+ is really amazing. Encoded an entire hour of video on the fly, as we were having it, and live broadcasted it. This is the future.",
  "id" : 259478089350934528,
  "created_at" : "2012-10-20 02:16:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 33, 42 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Wes Garri\u222Eon",
      "screen_name" : "wesgarrison",
      "indices" : [ 126, 138 ],
      "id_str" : "15954816",
      "id" : 15954816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/1rpBXFDw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=z73uiWKdJhw",
      "display_url" : "youtube.com\/watch?v=z73uiW\u2026"
    }, {
      "indices" : [ 97, 118 ],
      "url" : "https:\/\/t.co\/RvIr926h",
      "expanded_url" : "https:\/\/gist.github.com\/3921560",
      "display_url" : "gist.github.com\/3921560"
    } ]
  },
  "geo" : { },
  "id_str" : "259477998246440960",
  "text" : "Here's the entire video from the @rubygems G+ hangout tonight: http:\/\/t.co\/1rpBXFDw (Transcript: https:\/\/t.co\/RvIr926h thanks @wesgarrison!)",
  "id" : 259477998246440960,
  "created_at" : "2012-10-20 02:15:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    }, {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/h8NahlPK",
      "expanded_url" : "http:\/\/youtu.be\/z73uiWKdJhw",
      "display_url" : "youtu.be\/z73uiWKdJhw"
    } ]
  },
  "geo" : { },
  "id_str" : "259460372573065216",
  "text" : "It's http:\/\/t.co\/t7WATcFT pow-wow time. http:\/\/t.co\/h8NahlPK if you want to watch us try to get some work done.",
  "id" : 259460372573065216,
  "created_at" : "2012-10-20 01:05:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259409607246622720",
  "text" : "OH: \"Tapas is a Spanish word for tiny-ass food\"",
  "id" : 259409607246622720,
  "created_at" : "2012-10-19 21:44:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/V8kIlc5h",
      "expanded_url" : "http:\/\/spinningflamingskull.com\/",
      "display_url" : "spinningflamingskull.com"
    } ]
  },
  "geo" : { },
  "id_str" : "259403761284435968",
  "text" : "Possibly the best domain\/gif combo I've seen lately: http:\/\/t.co\/V8kIlc5h",
  "id" : 259403761284435968,
  "created_at" : "2012-10-19 21:20:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 0, 6 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259391424888438784",
  "geo" : { },
  "id_str" : "259393296231702529",
  "in_reply_to_user_id" : 9885102,
  "text" : "@drnic it does now...\"$AUTHOR wrote this\"",
  "id" : 259393296231702529,
  "in_reply_to_status_id" : 259391424888438784,
  "created_at" : "2012-10-19 20:39:15 +0000",
  "in_reply_to_screen_name" : "drnic",
  "in_reply_to_user_id_str" : "9885102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/wM3BPebn",
      "expanded_url" : "http:\/\/37svn.com\/3285",
      "display_url" : "37svn.com\/3285"
    } ]
  },
  "geo" : { },
  "id_str" : "259390970695663617",
  "text" : "something about 13px sans-serif faces on the web [...] feels like \u201Cmy Rails app just spit this out of a database.\u201D http:\/\/t.co\/wM3BPebn",
  "id" : 259390970695663617,
  "created_at" : "2012-10-19 20:30:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Berube",
      "screen_name" : "DTB",
      "indices" : [ 0, 4 ],
      "id_str" : "1474721",
      "id" : 1474721
    }, {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 5, 20 ],
      "id_str" : "72883",
      "id" : 72883
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 76, 90 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/o4UkVsBi",
      "expanded_url" : "http:\/\/whoownsmyavailability.com\/",
      "display_url" : "whoownsmyavailability.com"
    } ]
  },
  "in_reply_to_status_id_str" : "259381686196916224",
  "geo" : { },
  "id_str" : "259384924572880896",
  "in_reply_to_user_id" : 1474721,
  "text" : "@DTB @ChrisVanPatten http:\/\/t.co\/o4UkVsBi (Also, for small time stuff, like @coworkbuffalo, it's not going to matter in the long run)",
  "id" : 259384924572880896,
  "in_reply_to_status_id" : 259381686196916224,
  "created_at" : "2012-10-19 20:05:59 +0000",
  "in_reply_to_screen_name" : "DTB",
  "in_reply_to_user_id_str" : "1474721",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 0, 11 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Alex Williams",
      "screen_name" : "alexwilliams",
      "indices" : [ 12, 25 ],
      "id_str" : "791300",
      "id" : 791300
    }, {
      "name" : "Antony Falco",
      "screen_name" : "antonyfalco",
      "indices" : [ 26, 38 ],
      "id_str" : "82993674",
      "id" : 82993674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259352992506073088",
  "geo" : { },
  "id_str" : "259384589292814336",
  "in_reply_to_user_id" : 816653,
  "text" : "@TechCrunch @alexwilliams @antonyfalco this is truly a pathetic content recycle job. Can't even spell the company name right?",
  "id" : 259384589292814336,
  "in_reply_to_status_id" : 259352992506073088,
  "created_at" : "2012-10-19 20:04:39 +0000",
  "in_reply_to_screen_name" : "TechCrunch",
  "in_reply_to_user_id_str" : "816653",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259377663112773632",
  "text" : "@HarringtonCorey wow, congrats! pretty intense space for being bootstrapped. hope it works out!",
  "id" : 259377663112773632,
  "created_at" : "2012-10-19 19:37:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259377100740517888",
  "text" : "Is GitHub Pages down? 504's on all of my hosted sites.",
  "id" : 259377100740517888,
  "created_at" : "2012-10-19 19:34:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259376554004582400",
  "text" : "@HarringtonCorey wow, nice space! Did you guys have outside funding?",
  "id" : 259376554004582400,
  "created_at" : "2012-10-19 19:32:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259360979819847681",
  "geo" : { },
  "id_str" : "259361730642186240",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef YES! He's the best interpreter.",
  "id" : 259361730642186240,
  "in_reply_to_status_id" : 259360979819847681,
  "created_at" : "2012-10-19 18:33:49 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RITentconf",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259358787834634241",
  "text" : "Thought for a moment #RITentconf was a conf for stoners at RIT. Are we sure it's not behind Gracie's?",
  "id" : 259358787834634241,
  "created_at" : "2012-10-19 18:22:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy's Truck",
      "screen_name" : "amys_truck",
      "indices" : [ 0, 11 ],
      "id_str" : "634069219",
      "id" : 634069219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/EYaWwERQ",
      "expanded_url" : "http:\/\/coworkbuffalo.com\/food",
      "display_url" : "coworkbuffalo.com\/food"
    } ]
  },
  "in_reply_to_status_id_str" : "259309507409231872",
  "geo" : { },
  "id_str" : "259309914021847040",
  "in_reply_to_user_id" : 634069219,
  "text" : "@amys_truck hey there! I'd love to put you on http:\/\/t.co\/EYaWwERQ, but please provide times along with location too!",
  "id" : 259309914021847040,
  "in_reply_to_status_id" : 259309507409231872,
  "created_at" : "2012-10-19 15:07:55 +0000",
  "in_reply_to_screen_name" : "amys_truck",
  "in_reply_to_user_id_str" : "634069219",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259308345536700416",
  "text" : "Pumped to see some RIT hockey tomorrow. It's been far too long.",
  "id" : 259308345536700416,
  "created_at" : "2012-10-19 15:01:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Mazzi",
      "screen_name" : "jmazzi",
      "indices" : [ 0, 7 ],
      "id_str" : "15395778",
      "id" : 15395778
    }, {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 8, 20 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259307306515320832",
  "geo" : { },
  "id_str" : "259307543082459137",
  "in_reply_to_user_id" : 15395778,
  "text" : "@jmazzi @turntablefm it's under a performance license...so anyone can upload and play anything, as long as others are listening",
  "id" : 259307543082459137,
  "in_reply_to_status_id" : 259307306515320832,
  "created_at" : "2012-10-19 14:58:30 +0000",
  "in_reply_to_screen_name" : "jmazzi",
  "in_reply_to_user_id_str" : "15395778",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/3pe4pQ6w",
      "expanded_url" : "http:\/\/codepen.io\/",
      "display_url" : "codepen.io"
    } ]
  },
  "geo" : { },
  "id_str" : "259305642605572097",
  "text" : "Looks like http:\/\/t.co\/3pe4pQ6w is what I was thinking of! Supports saving, forking, full screen...awesome.",
  "id" : 259305642605572097,
  "created_at" : "2012-10-19 14:50:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259304449120534528",
  "text" : "What's the pastebin type site that lets you edit HTML\/CSS\/JS live?",
  "id" : 259304449120534528,
  "created_at" : "2012-10-19 14:46:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turntable",
      "screen_name" : "turntablefm",
      "indices" : [ 47, 59 ],
      "id_str" : "1934900918",
      "id" : 1934900918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259298901138485248",
  "text" : "2 days now and I haven't been able to log into @turntablefm via twitter. :(",
  "id" : 259298901138485248,
  "created_at" : "2012-10-19 14:24:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkdevo",
      "screen_name" : "mkdevo",
      "indices" : [ 0, 7 ],
      "id_str" : "158371168",
      "id" : 158371168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259085308904239104",
  "geo" : { },
  "id_str" : "259086860171763712",
  "in_reply_to_user_id" : 158371168,
  "text" : "@mkdevo OUCH",
  "id" : 259086860171763712,
  "in_reply_to_status_id" : 259085308904239104,
  "created_at" : "2012-10-19 00:21:35 +0000",
  "in_reply_to_screen_name" : "mkdevo",
  "in_reply_to_user_id_str" : "158371168",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/08aEXDks",
      "expanded_url" : "http:\/\/robrhinehart.com\/?p=119",
      "display_url" : "robrhinehart.com\/?p=119"
    } ]
  },
  "geo" : { },
  "id_str" : "259086586644422656",
  "text" : "Possibly the best introduction to any software I've ever read: http:\/\/t.co\/08aEXDks",
  "id" : 259086586644422656,
  "created_at" : "2012-10-19 00:20:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mental Brew",
      "screen_name" : "mentalbrew",
      "indices" : [ 0, 11 ],
      "id_str" : "188497147",
      "id" : 188497147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 33 ],
      "url" : "https:\/\/t.co\/NVJ1xKei",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubygems-org",
      "display_url" : "groups.google.com\/group\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "259007982300459009",
  "geo" : { },
  "id_str" : "259026666700021760",
  "in_reply_to_user_id" : 188497147,
  "text" : "@mentalbrew https:\/\/t.co\/NVJ1xKei",
  "id" : 259026666700021760,
  "in_reply_to_status_id" : 259007982300459009,
  "created_at" : "2012-10-18 20:22:24 +0000",
  "in_reply_to_screen_name" : "mentalbrew",
  "in_reply_to_user_id_str" : "188497147",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258961324514631681",
  "geo" : { },
  "id_str" : "258961685262528514",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety LIKE AN OIL BARON",
  "id" : 258961685262528514,
  "in_reply_to_status_id" : 258961324514631681,
  "created_at" : "2012-10-18 16:04:11 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/258765870157946881\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/yNEJw4zQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5dSMBtCYAAXCxR.png",
      "id_str" : "258765870166335488",
      "id" : 258765870166335488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5dSMBtCYAAXCxR.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/yNEJw4zQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258765870157946881",
  "text" : "The sad state of iPhone games summed up in one ingame screenshot. http:\/\/t.co\/yNEJw4zQ",
  "id" : 258765870157946881,
  "created_at" : "2012-10-18 03:06:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Kriss",
      "screen_name" : "jkriss",
      "indices" : [ 0, 7 ],
      "id_str" : "7475972",
      "id" : 7475972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258754879613440000",
  "geo" : { },
  "id_str" : "258756249770917888",
  "in_reply_to_user_id" : 7475972,
  "text" : "@jkriss that's what it should be doing",
  "id" : 258756249770917888,
  "in_reply_to_status_id" : 258754879613440000,
  "created_at" : "2012-10-18 02:27:52 +0000",
  "in_reply_to_screen_name" : "jkriss",
  "in_reply_to_user_id_str" : "7475972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Kriss",
      "screen_name" : "jkriss",
      "indices" : [ 0, 7 ],
      "id_str" : "7475972",
      "id" : 7475972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 80 ],
      "url" : "https:\/\/t.co\/l3M3xPyT",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/?fromgroups#!forum\/rubygems-org",
      "display_url" : "groups.google.com\/forum\/?fromgro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "258752355930103808",
  "geo" : { },
  "id_str" : "258754020284436480",
  "in_reply_to_user_id" : 7475972,
  "text" : "@jkriss we're having a pow-wow on friday to talk about it: https:\/\/t.co\/l3M3xPyT",
  "id" : 258754020284436480,
  "in_reply_to_status_id" : 258752355930103808,
  "created_at" : "2012-10-18 02:19:00 +0000",
  "in_reply_to_screen_name" : "jkriss",
  "in_reply_to_user_id_str" : "7475972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Kriss",
      "screen_name" : "jkriss",
      "indices" : [ 0, 7 ],
      "id_str" : "7475972",
      "id" : 7475972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258752355930103808",
  "geo" : { },
  "id_str" : "258753934611591169",
  "in_reply_to_user_id" : 7475972,
  "text" : "@jkriss No ETA. this is all volunteer work.",
  "id" : 258753934611591169,
  "in_reply_to_status_id" : 258752355930103808,
  "created_at" : "2012-10-18 02:18:40 +0000",
  "in_reply_to_screen_name" : "jkriss",
  "in_reply_to_user_id_str" : "7475972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Kriss",
      "screen_name" : "jkriss",
      "indices" : [ 0, 7 ],
      "id_str" : "7475972",
      "id" : 7475972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/jri6n5Qm",
      "expanded_url" : "http:\/\/status.rubygems.org\/",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "258750571362799616",
  "geo" : { },
  "id_str" : "258752024156454912",
  "in_reply_to_user_id" : 7475972,
  "text" : "@jkriss it's everyone. we've temporarily disabled it since it's killing our server :( http:\/\/t.co\/jri6n5Qm",
  "id" : 258752024156454912,
  "in_reply_to_status_id" : 258750571362799616,
  "created_at" : "2012-10-18 02:11:04 +0000",
  "in_reply_to_screen_name" : "jkriss",
  "in_reply_to_user_id_str" : "7475972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Justin Rolston",
      "screen_name" : "justinrolston",
      "indices" : [ 14, 28 ],
      "id_str" : "2290991",
      "id" : 2290991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/3X177GBc",
      "expanded_url" : "http:\/\/status.rubygems.org",
      "display_url" : "status.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "258749112181207041",
  "geo" : { },
  "id_str" : "258749919010095104",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @justinrolston http:\/\/t.co\/3X177GBc the new dep API basically is killing our server...so it's temporarily disabled",
  "id" : 258749919010095104,
  "in_reply_to_status_id" : 258749112181207041,
  "created_at" : "2012-10-18 02:02:42 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258699569284673537",
  "text" : "Saw a bad motorcycle accident off Grant St on the 198. Looks like a bike got flipped over, guy was just in a pile over the rail :(",
  "id" : 258699569284673537,
  "created_at" : "2012-10-17 22:42:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/EtShO4l2",
      "expanded_url" : "http:\/\/gordonkeith.files.wordpress.com\/2012\/07\/ylvcg.gif",
      "display_url" : "gordonkeith.files.wordpress.com\/2012\/07\/ylvcg.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "258684555677011968",
  "geo" : { },
  "id_str" : "258685627443335171",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove ME TOO WAT!? http:\/\/t.co\/EtShO4l2",
  "id" : 258685627443335171,
  "in_reply_to_status_id" : 258684555677011968,
  "created_at" : "2012-10-17 21:47:14 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham McIntire",
      "screen_name" : "gmcintire",
      "indices" : [ 48, 58 ],
      "id_str" : "642713",
      "id" : 642713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/NraIu4NZ",
      "expanded_url" : "http:\/\/i.imgur.com\/OPfWw.png",
      "display_url" : "i.imgur.com\/OPfWw.png"
    } ]
  },
  "geo" : { },
  "id_str" : "258684690175766529",
  "text" : "Current today status: http:\/\/t.co\/NraIu4NZ (via @gmcintire)",
  "id" : 258684690175766529,
  "created_at" : "2012-10-17 21:43:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258682269521309696",
  "geo" : { },
  "id_str" : "258682456612417536",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss but you're still using XCode...:)",
  "id" : 258682456612417536,
  "in_reply_to_status_id" : 258682269521309696,
  "created_at" : "2012-10-17 21:34:38 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258681710223433728",
  "geo" : { },
  "id_str" : "258682053585944576",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Yep, XCode. Ignoring! :)",
  "id" : 258682053585944576,
  "in_reply_to_status_id" : 258681710223433728,
  "created_at" : "2012-10-17 21:33:02 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258680975830159360",
  "geo" : { },
  "id_str" : "258681439489503232",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza I haven't even figured out wtf autolayout is. Must be some XCode thing :)",
  "id" : 258681439489503232,
  "in_reply_to_status_id" : 258680975830159360,
  "created_at" : "2012-10-17 21:30:35 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristopher Murata",
      "screen_name" : "krsmurata",
      "indices" : [ 0, 10 ],
      "id_str" : "9711282",
      "id" : 9711282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 121 ],
      "url" : "https:\/\/t.co\/NVJ1xKei",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubygems-org",
      "display_url" : "groups.google.com\/group\/rubygems\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "258680516889436160",
  "geo" : { },
  "id_str" : "258681080620654592",
  "in_reply_to_user_id" : 9711282,
  "text" : "@krsmurata RC has funding, but they are a non-profit. If you're actually interested in helping out: https:\/\/t.co\/NVJ1xKei",
  "id" : 258681080620654592,
  "in_reply_to_status_id" : 258680516889436160,
  "created_at" : "2012-10-17 21:29:10 +0000",
  "in_reply_to_screen_name" : "krsmurata",
  "in_reply_to_user_id_str" : "9711282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258676215701966848",
  "geo" : { },
  "id_str" : "258680672737173506",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza Have you played with UICollectionView yet? Ran into too many undocumented roadblocks.",
  "id" : 258680672737173506,
  "in_reply_to_status_id" : 258676215701966848,
  "created_at" : "2012-10-17 21:27:33 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristopher Murata",
      "screen_name" : "krsmurata",
      "indices" : [ 0, 10 ],
      "id_str" : "9711282",
      "id" : 9711282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258679156198490112",
  "geo" : { },
  "id_str" : "258680041079181312",
  "in_reply_to_user_id" : 9711282,
  "text" : "@krsmurata this is a hard, and touchy issue. RubyCentral (a 501.3c) officially backs the site.",
  "id" : 258680041079181312,
  "in_reply_to_status_id" : 258679156198490112,
  "created_at" : "2012-10-17 21:25:02 +0000",
  "in_reply_to_screen_name" : "krsmurata",
  "in_reply_to_user_id_str" : "9711282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    }, {
      "name" : "Mig Reyes",
      "screen_name" : "migreyes",
      "indices" : [ 45, 54 ],
      "id_str" : "1051521",
      "id" : 1051521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258669223042248704",
  "geo" : { },
  "id_str" : "258669619936649216",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin @37signals ah, seeing that too. \/cc @migreyes",
  "id" : 258669619936649216,
  "in_reply_to_status_id" : 258669223042248704,
  "created_at" : "2012-10-17 20:43:37 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Chernyak",
      "screen_name" : "hakunin",
      "indices" : [ 0, 8 ],
      "id_str" : "11622052",
      "id" : 11622052
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 9, 19 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258668263674896384",
  "geo" : { },
  "id_str" : "258668561780838400",
  "in_reply_to_user_id" : 11622052,
  "text" : "@hakunin @37signals bad link",
  "id" : 258668561780838400,
  "in_reply_to_status_id" : 258668263674896384,
  "created_at" : "2012-10-17 20:39:25 +0000",
  "in_reply_to_screen_name" : "hakunin",
  "in_reply_to_user_id_str" : "11622052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Y8tKNFNf",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258667116872495107",
  "text" : "The SvN redesign is gorgeous, and responsive. Need to write more! http:\/\/t.co\/Y8tKNFNf",
  "id" : 258667116872495107,
  "created_at" : "2012-10-17 20:33:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258662704217202689",
  "text" : "RT @rubygems_status: We are back up, but the new dependency API is not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258660880324128768",
    "text" : "We are back up, but the new dependency API is not.",
    "id" : 258660880324128768,
    "created_at" : "2012-10-17 20:08:54 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 258662704217202689,
  "created_at" : "2012-10-17 20:16:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258646755334303744",
  "text" : "RT @rubygems_status: The site is in maintenance mode while we figure out why the load on the server doesn\u2019t cease. Sorry everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258646698648293376",
    "text" : "The site is in maintenance mode while we figure out why the load on the server doesn\u2019t cease. Sorry everyone.",
    "id" : 258646698648293376,
    "created_at" : "2012-10-17 19:12:33 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 258646755334303744,
  "created_at" : "2012-10-17 19:12:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258642299356069891",
  "text" : "Absolute wash today.",
  "id" : 258642299356069891,
  "created_at" : "2012-10-17 18:55:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "258632174402670592",
  "text" : "Someone is trying to sell me on HYPERSCALING http:\/\/t.co\/bdjsRgTW right now.",
  "id" : 258632174402670592,
  "created_at" : "2012-10-17 18:14:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Leighton",
      "screen_name" : "jonleighton",
      "indices" : [ 0, 12 ],
      "id_str" : "14330565",
      "id" : 14330565
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 13, 19 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258624104834408448",
  "geo" : { },
  "id_str" : "258626610092191744",
  "in_reply_to_user_id" : 14330565,
  "text" : "@jonleighton @qrush This really isn't the problem, it's under RubyCentral.",
  "id" : 258626610092191744,
  "in_reply_to_status_id" : 258624104834408448,
  "created_at" : "2012-10-17 17:52:43 +0000",
  "in_reply_to_screen_name" : "jonleighton",
  "in_reply_to_user_id_str" : "14330565",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    }, {
      "indices" : [ 77, 98 ],
      "url" : "https:\/\/t.co\/nuRsbpwi",
      "expanded_url" : "https:\/\/groups.google.com\/group\/rubygems-org\/browse_thread\/thread\/fb197039857d060c",
      "display_url" : "groups.google.com\/group\/rubygems\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258626261621014529",
  "text" : "Going to have a pow-wow on Friday about http:\/\/t.co\/bdjsRgTW current status: https:\/\/t.co\/nuRsbpwi",
  "id" : 258626261621014529,
  "created_at" : "2012-10-17 17:51:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258608612182720512",
  "geo" : { },
  "id_str" : "258609894310154240",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam sorry :(",
  "id" : 258609894310154240,
  "in_reply_to_status_id" : 258608612182720512,
  "created_at" : "2012-10-17 16:46:18 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258607538533175298",
  "text" : "For those looking to help with rubygems issues: There's no secret ways to get involved. Look at the issues, get on #rubygems IRC.",
  "id" : 258607538533175298,
  "created_at" : "2012-10-17 16:36:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 0, 11 ],
      "id_str" : "14086000",
      "id" : 14086000
    }, {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 12, 22 ],
      "id_str" : "15023866",
      "id" : 15023866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258605577431834624",
  "geo" : { },
  "id_str" : "258605983742439424",
  "in_reply_to_user_id" : 14086000,
  "text" : "@timocratic @freerobby i'm not in the business of selling gems, and I never will be.",
  "id" : 258605983742439424,
  "in_reply_to_status_id" : 258605577431834624,
  "created_at" : "2012-10-17 16:30:45 +0000",
  "in_reply_to_screen_name" : "timocratic",
  "in_reply_to_user_id_str" : "14086000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/AeODtl3M",
      "expanded_url" : "http:\/\/Rubygems.org",
      "display_url" : "Rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "258574577066713088",
  "text" : "http:\/\/t.co\/AeODtl3M is down again and I am the only one responding. I'm about ready to give up on this.",
  "id" : 258574577066713088,
  "created_at" : "2012-10-17 14:25:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tilo Sloboda",
      "screen_name" : "tilosloboda",
      "indices" : [ 0, 12 ],
      "id_str" : "578304269",
      "id" : 578304269
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 13, 21 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 22, 30 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258554237959671808",
  "geo" : { },
  "id_str" : "258565366677135360",
  "in_reply_to_user_id" : 578304269,
  "text" : "@tilosloboda @evanphx @drbrain there is a \"dependencies\" string entry...but RG 2.0 should make this easier with metadata.",
  "id" : 258565366677135360,
  "in_reply_to_status_id" : 258554237959671808,
  "created_at" : "2012-10-17 13:49:21 +0000",
  "in_reply_to_screen_name" : "tilosloboda",
  "in_reply_to_user_id_str" : "578304269",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258407664843907072",
  "text" : "Wished an old friend good luck tonight as he departs on a one-way journey to Vietnam, and hitchhike to Thailand. Adventure ahoy!",
  "id" : 258407664843907072,
  "created_at" : "2012-10-17 03:22:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Worthy",
      "screen_name" : "eliseworthy",
      "indices" : [ 0, 12 ],
      "id_str" : "198661893",
      "id" : 198661893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258289804385603585",
  "geo" : { },
  "id_str" : "258290005577961473",
  "in_reply_to_user_id" : 198661893,
  "text" : "@eliseworthy Crap, did I miss the CFP for this!?",
  "id" : 258290005577961473,
  "in_reply_to_status_id" : 258289804385603585,
  "created_at" : "2012-10-16 19:35:10 +0000",
  "in_reply_to_screen_name" : "eliseworthy",
  "in_reply_to_user_id_str" : "198661893",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258273520004517888",
  "text" : "Took the Linwood bike path from around W. Utica to North, it's nice! But still hard to navigate after North.",
  "id" : 258273520004517888,
  "created_at" : "2012-10-16 18:29:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257951809136635904",
  "text" : "Current status: wrong number of arguments (177726112 for 0)",
  "id" : 257951809136635904,
  "created_at" : "2012-10-15 21:11:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ridgeway",
      "screen_name" : "Ang3lFir3",
      "indices" : [ 0, 10 ],
      "id_str" : "7792122",
      "id" : 7792122
    }, {
      "name" : "Heroku",
      "screen_name" : "heroku",
      "indices" : [ 11, 18 ],
      "id_str" : "10257182",
      "id" : 10257182
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 34, 42 ],
      "id_str" : "839931",
      "id" : 839931
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 43, 50 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 51, 58 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257928292546523137",
  "geo" : { },
  "id_str" : "257928536432730112",
  "in_reply_to_user_id" : 7792122,
  "text" : "@Ang3lFir3 @heroku What? WTF? \/cc @ddollar @hone02 @geemus",
  "id" : 257928536432730112,
  "in_reply_to_status_id" : 257928292546523137,
  "created_at" : "2012-10-15 19:38:49 +0000",
  "in_reply_to_screen_name" : "Ang3lFir3",
  "in_reply_to_user_id_str" : "7792122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Townsend",
      "screen_name" : "RyanTownsend",
      "indices" : [ 0, 13 ],
      "id_str" : "2202971",
      "id" : 2202971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257923637464674304",
  "geo" : { },
  "id_str" : "257923762631081985",
  "in_reply_to_user_id" : 2202971,
  "text" : "@RyanTownsend we're looking into it :(",
  "id" : 257923762631081985,
  "in_reply_to_status_id" : 257923637464674304,
  "created_at" : "2012-10-15 19:19:51 +0000",
  "in_reply_to_screen_name" : "RyanTownsend",
  "in_reply_to_user_id_str" : "2202971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bart\u0142omiej Kozal",
      "screen_name" : "_bkzl",
      "indices" : [ 0, 6 ],
      "id_str" : "447830209",
      "id" : 447830209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257902823897985024",
  "geo" : { },
  "id_str" : "257910340300439552",
  "in_reply_to_user_id" : 447830209,
  "text" : "@_bkzl what's your email?",
  "id" : 257910340300439552,
  "in_reply_to_status_id" : 257902823897985024,
  "created_at" : "2012-10-15 18:26:31 +0000",
  "in_reply_to_screen_name" : "_bkzl",
  "in_reply_to_user_id_str" : "447830209",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacek Michael Gr\u0119",
      "screen_name" : "jgrebski",
      "indices" : [ 0, 9 ],
      "id_str" : "27922285",
      "id" : 27922285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257897335332417537",
  "geo" : { },
  "id_str" : "257910224999047168",
  "in_reply_to_user_id" : 27922285,
  "text" : "@jgrebski what's your email?",
  "id" : 257910224999047168,
  "in_reply_to_status_id" : 257897335332417537,
  "created_at" : "2012-10-15 18:26:04 +0000",
  "in_reply_to_screen_name" : "jgrebski",
  "in_reply_to_user_id_str" : "27922285",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marten Veldthuis",
      "screen_name" : "mveldth",
      "indices" : [ 0, 8 ],
      "id_str" : "14447826",
      "id" : 14447826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257877302694789120",
  "geo" : { },
  "id_str" : "257878366915530752",
  "in_reply_to_user_id" : 14447826,
  "text" : "@mveldth have an email I can bug you at?",
  "id" : 257878366915530752,
  "in_reply_to_status_id" : 257877302694789120,
  "created_at" : "2012-10-15 16:19:28 +0000",
  "in_reply_to_screen_name" : "mveldth",
  "in_reply_to_user_id_str" : "14447826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory K15d",
      "screen_name" : "allspiritseve",
      "indices" : [ 0, 14 ],
      "id_str" : "14911812",
      "id" : 14911812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257876180940779522",
  "geo" : { },
  "id_str" : "257876847948337153",
  "in_reply_to_user_id" : 14911812,
  "text" : "@allspiritseve what's your email (or github?)",
  "id" : 257876847948337153,
  "in_reply_to_status_id" : 257876180940779522,
  "created_at" : "2012-10-15 16:13:26 +0000",
  "in_reply_to_screen_name" : "allspiritseve",
  "in_reply_to_user_id_str" : "14911812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 0, 10 ],
      "id_str" : "3452911",
      "id" : 3452911
    }, {
      "name" : "Elizabeth Weil",
      "screen_name" : "elizabeth",
      "indices" : [ 11, 21 ],
      "id_str" : "8491",
      "id" : 8491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257874609532198912",
  "geo" : { },
  "id_str" : "257875137477632000",
  "in_reply_to_user_id" : 3452911,
  "text" : "@kevinweil @elizabeth everything happens so much",
  "id" : 257875137477632000,
  "in_reply_to_status_id" : 257874609532198912,
  "created_at" : "2012-10-15 16:06:38 +0000",
  "in_reply_to_screen_name" : "kevinweil",
  "in_reply_to_user_id_str" : "3452911",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257873124228464640",
  "text" : "Further clarifying: If you run a user group of any kind in any city (Not just US!) I've got an idea for you. Ping me!",
  "id" : 257873124228464640,
  "created_at" : "2012-10-15 15:58:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marten Veldthuis",
      "screen_name" : "mveldth",
      "indices" : [ 0, 8 ],
      "id_str" : "14447826",
      "id" : 14447826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257872543908786176",
  "geo" : { },
  "id_str" : "257872701337772032",
  "in_reply_to_user_id" : 14447826,
  "text" : "@mveldth Nope!",
  "id" : 257872701337772032,
  "in_reply_to_status_id" : 257872543908786176,
  "created_at" : "2012-10-15 15:56:57 +0000",
  "in_reply_to_screen_name" : "mveldth",
  "in_reply_to_user_id_str" : "14447826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257872535876669441",
  "text" : "RT @coworkbuffalo: We are open early today. We're up early because we're (likely) making it official: we're doubling our coworking space.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257822068677152769",
    "text" : "We are open early today. We're up early because we're (likely) making it official: we're doubling our coworking space.",
    "id" : 257822068677152769,
    "created_at" : "2012-10-15 12:35:45 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 257872535876669441,
  "created_at" : "2012-10-15 15:56:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arran Ross-Paterson",
      "screen_name" : "arranrp",
      "indices" : [ 0, 8 ],
      "id_str" : "5738612",
      "id" : 5738612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257867438639681537",
  "geo" : { },
  "id_str" : "257870361796952064",
  "in_reply_to_user_id" : 5738612,
  "text" : "@arranrp got an email? :)",
  "id" : 257870361796952064,
  "in_reply_to_status_id" : 257867438639681537,
  "created_at" : "2012-10-15 15:47:39 +0000",
  "in_reply_to_screen_name" : "arranrp",
  "in_reply_to_user_id_str" : "5738612",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Sternal-Johnson",
      "screen_name" : "ceejayoz",
      "indices" : [ 0, 9 ],
      "id_str" : "717973",
      "id" : 717973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257868719156510720",
  "geo" : { },
  "id_str" : "257870253252571137",
  "in_reply_to_user_id" : 717973,
  "text" : "@ceejayoz who runs this? Need an email.",
  "id" : 257870253252571137,
  "in_reply_to_status_id" : 257868719156510720,
  "created_at" : "2012-10-15 15:47:14 +0000",
  "in_reply_to_screen_name" : "ceejayoz",
  "in_reply_to_user_id_str" : "717973",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camille Roux",
      "screen_name" : "CamilleRoux",
      "indices" : [ 0, 12 ],
      "id_str" : "1163191",
      "id" : 1163191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257867196607369216",
  "geo" : { },
  "id_str" : "257869558151516160",
  "in_reply_to_user_id" : 1163191,
  "text" : "@CamilleRoux whats your email\/github?",
  "id" : 257869558151516160,
  "in_reply_to_status_id" : 257867196607369216,
  "created_at" : "2012-10-15 15:44:28 +0000",
  "in_reply_to_screen_name" : "CamilleRoux",
  "in_reply_to_user_id_str" : "1163191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C",
      "screen_name" : "ChrisSmithAV",
      "indices" : [ 0, 13 ],
      "id_str" : "5911122",
      "id" : 5911122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/FerMGIMH",
      "expanded_url" : "http:\/\/blog.wtfconcept.com\/wp-content\/uploads\/2011\/04\/trololol.gif",
      "display_url" : "blog.wtfconcept.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "257866979979968512",
  "geo" : { },
  "id_str" : "257867261333884928",
  "in_reply_to_user_id" : 5911122,
  "text" : "@ChrisSmithAV http:\/\/t.co\/FerMGIMH",
  "id" : 257867261333884928,
  "in_reply_to_status_id" : 257866979979968512,
  "created_at" : "2012-10-15 15:35:20 +0000",
  "in_reply_to_screen_name" : "ChrisSmithAV",
  "in_reply_to_user_id_str" : "5911122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257866551787651072",
  "text" : "Hey, who runs a programming related user group that follows me (Not here in Buffalo!) Ping me, I have a proposal for you!",
  "id" : 257866551787651072,
  "created_at" : "2012-10-15 15:32:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Draplin Design Co.",
      "screen_name" : "Draplin",
      "indices" : [ 4, 12 ],
      "id_str" : "14229273",
      "id" : 14229273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/F8RgwJzA",
      "expanded_url" : "http:\/\/www.draplin.com\/2012\/10\/tonight_buffalo.html",
      "display_url" : "draplin.com\/2012\/10\/tonigh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257862010153340928",
  "text" : "Hey @draplin are there any more of these Buffalo posters available? http:\/\/t.co\/F8RgwJzA",
  "id" : 257862010153340928,
  "created_at" : "2012-10-15 15:14:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257668699148935169",
  "geo" : { },
  "id_str" : "257670329227419648",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan oh c\u2019mon. Maybe some people see it as a learning or fun opportunity?",
  "id" : 257670329227419648,
  "in_reply_to_status_id" : 257668699148935169,
  "created_at" : "2012-10-15 02:32:48 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/YDOIEj0B",
      "expanded_url" : "http:\/\/wny-ruby-represent.r12.railsrumble.com\/",
      "display_url" : "wny-ruby-represent.r12.railsrumble.com"
    } ]
  },
  "geo" : { },
  "id_str" : "257657420149563393",
  "text" : "Solving the \"who's bringing what\" problem for parties: http:\/\/t.co\/YDOIEj0B Love this idea!",
  "id" : 257657420149563393,
  "created_at" : "2012-10-15 01:41:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257207717582745602",
  "text" : "Lacking the ability to be productive today. Saturday!",
  "id" : 257207717582745602,
  "created_at" : "2012-10-13 19:54:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257104279905656832",
  "geo" : { },
  "id_str" : "257104728352247809",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage P I Z Z A \uD83C\uDF55",
  "id" : 257104728352247809,
  "in_reply_to_status_id" : 257104279905656832,
  "created_at" : "2012-10-13 13:05:18 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257104592838459394",
  "text" : "Played Le Havre until 5am. Love that game but\u2026never again.",
  "id" : 257104592838459394,
  "created_at" : "2012-10-13 13:04:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257022264460075009",
  "geo" : { },
  "id_str" : "257024371766480896",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors TOP SCORE",
  "id" : 257024371766480896,
  "in_reply_to_status_id" : 257022264460075009,
  "created_at" : "2012-10-13 07:46:00 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 0, 13 ],
      "id_str" : "6082492",
      "id" : 6082492
    }, {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 14, 23 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256926958489841666",
  "geo" : { },
  "id_str" : "256933676481396736",
  "in_reply_to_user_id" : 6082492,
  "text" : "@greggpollack @schneems you sure you\u2019re not at a phish show?",
  "id" : 256933676481396736,
  "in_reply_to_status_id" : 256926958489841666,
  "created_at" : "2012-10-13 01:45:36 +0000",
  "in_reply_to_screen_name" : "greggpollack",
  "in_reply_to_user_id_str" : "6082492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/xAgnbvZK",
      "expanded_url" : "http:\/\/fairytalesfor20somethings.tumblr.com\/",
      "display_url" : "fairytalesfor20somethings.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "256872264144928768",
  "text" : "Exactly what you think it is: http:\/\/t.co\/xAgnbvZK",
  "id" : 256872264144928768,
  "created_at" : "2012-10-12 21:41:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "indices" : [ 3, 9 ],
      "id_str" : "35293",
      "id" : 35293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/6EnqpUvi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GQyatIpkHvM",
      "display_url" : "youtube.com\/watch?v=GQyatI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256871276667338753",
  "text" : "RT @mrgan: As we've seen so many times in the past, the best way to promote your new tech product is to rap about it http:\/\/t.co\/6EnqpUvi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/6EnqpUvi",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GQyatIpkHvM",
        "display_url" : "youtube.com\/watch?v=GQyatI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256863514948411395",
    "text" : "As we've seen so many times in the past, the best way to promote your new tech product is to rap about it http:\/\/t.co\/6EnqpUvi",
    "id" : 256863514948411395,
    "created_at" : "2012-10-12 21:06:48 +0000",
    "user" : {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "protected" : false,
      "id_str" : "35293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564092871871959040\/b2w9o5gs_normal.png",
      "id" : 35293,
      "verified" : false
    }
  },
  "id" : 256871276667338753,
  "created_at" : "2012-10-12 21:37:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256830267937935360",
  "text" : "Today I learned the most obfuscated way ever to convert a JS date to an integer: \"var now = +(new Date());\"",
  "id" : 256830267937935360,
  "created_at" : "2012-10-12 18:54:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256825398820749312",
  "geo" : { },
  "id_str" : "256826270644584449",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx holy shit, wow. UB and RIT are on this list...",
  "id" : 256826270644584449,
  "in_reply_to_status_id" : 256825398820749312,
  "created_at" : "2012-10-12 18:38:49 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/YnDiK4yP",
      "expanded_url" : "http:\/\/zachholman.com\/talk\/product-is-the-byproduct",
      "display_url" : "zachholman.com\/talk\/product-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256824891293175809",
  "text" : "\"Nothing great was ever not shipped\" - http:\/\/t.co\/YnDiK4yP",
  "id" : 256824891293175809,
  "created_at" : "2012-10-12 18:33:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256817591358746626",
  "text" : "Added the title of \"student-teacher\" today to my list of titles. Still terrified about this, but it was a lot of fun.",
  "id" : 256817591358746626,
  "created_at" : "2012-10-12 18:04:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256786260226625536",
  "geo" : { },
  "id_str" : "256786551105781760",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo nuke them from orbit.",
  "id" : 256786551105781760,
  "in_reply_to_status_id" : 256786260226625536,
  "created_at" : "2012-10-12 16:00:59 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 8, 18 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 41 ],
      "url" : "https:\/\/t.co\/a0ApotGf",
      "expanded_url" : "https:\/\/img.skitch.com\/20121012-dggbw8htwt9ckk9jrynr6ueee8.png",
      "display_url" : "img.skitch.com\/20121012-dggbw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256777294536921088",
  "text" : "Fridays @37signals: https:\/\/t.co\/a0ApotGf",
  "id" : 256777294536921088,
  "created_at" : "2012-10-12 15:24:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256776584827109377",
  "text" : "Snapping necks, cashing checks.",
  "id" : 256776584827109377,
  "created_at" : "2012-10-12 15:21:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/WSb34amI",
      "expanded_url" : "http:\/\/turntable.fm\/thoughtbot2",
      "display_url" : "turntable.fm\/thoughtbot2"
    } ]
  },
  "geo" : { },
  "id_str" : "256772758099329024",
  "text" : "DJing in the thoughtbot room. Now playing Breakestra: Family Rap [feat. feat Chali 2na, Soup, Double K] \u266B\u266A #turntablefm http:\/\/t.co\/WSb34amI",
  "id" : 256772758099329024,
  "created_at" : "2012-10-12 15:06:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256613004131577856",
  "text" : "Discovered this year\u2019s motto: scare the hell out of yourself and hope to come out better for it.",
  "id" : 256613004131577856,
  "created_at" : "2012-10-12 04:31:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256590734122184705",
  "geo" : { },
  "id_str" : "256600115966513152",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape hockey? I have season tickets. Pumped.",
  "id" : 256600115966513152,
  "in_reply_to_status_id" : 256590734122184705,
  "created_at" : "2012-10-12 03:40:09 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Lorang",
      "screen_name" : "noahhlo",
      "indices" : [ 0, 8 ],
      "id_str" : "234465384",
      "id" : 234465384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256552264334966784",
  "geo" : { },
  "id_str" : "256553894442840064",
  "in_reply_to_user_id" : 234465384,
  "text" : "@noahhlo NOIKEAH",
  "id" : 256553894442840064,
  "in_reply_to_status_id" : 256552264334966784,
  "created_at" : "2012-10-12 00:36:29 +0000",
  "in_reply_to_screen_name" : "noahhlo",
  "in_reply_to_user_id_str" : "234465384",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidmoffitt",
      "screen_name" : "davidmoffitt",
      "indices" : [ 0, 13 ],
      "id_str" : "15101175",
      "id" : 15101175
    }, {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 14, 22 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256511870872211457",
  "geo" : { },
  "id_str" : "256512249819193344",
  "in_reply_to_user_id" : 15101175,
  "text" : "@davidmoffitt @rubiety yeah baby!",
  "id" : 256512249819193344,
  "in_reply_to_status_id" : 256511870872211457,
  "created_at" : "2012-10-11 21:51:00 +0000",
  "in_reply_to_screen_name" : "davidmoffitt",
  "in_reply_to_user_id_str" : "15101175",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 7, 16 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 28, 42 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256461841679650816",
  "text" : "A wild @bquarant appears at @coworkbuffalo!",
  "id" : 256461841679650816,
  "created_at" : "2012-10-11 18:30:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tarse",
      "screen_name" : "isacult",
      "indices" : [ 0, 8 ],
      "id_str" : "2896192499",
      "id" : 2896192499
    }, {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 9, 18 ],
      "id_str" : "616163",
      "id" : 616163
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 19, 23 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "256454900387573761",
  "text" : "@isacult @joshpeek @dhh That being said, I'm all fine with a service to do it, just not http:\/\/t.co\/bdjsRgTW. We have enough problems as is.",
  "id" : 256454900387573761,
  "created_at" : "2012-10-11 18:03:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tarse",
      "screen_name" : "isacult",
      "indices" : [ 0, 8 ],
      "id_str" : "2896192499",
      "id" : 2896192499
    }, {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 9, 18 ],
      "id_str" : "616163",
      "id" : 616163
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 19, 23 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256454689334366208",
  "text" : "@isacult @joshpeek @dhh the entire point of gemcutter was to accept built gems only &amp; avoid the FUBAR approach of gem building as a service",
  "id" : 256454689334366208,
  "created_at" : "2012-10-11 18:02:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jessop",
      "screen_name" : "will_j",
      "indices" : [ 0, 7 ],
      "id_str" : "14432203",
      "id" : 14432203
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 8, 12 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256413684212043777",
  "geo" : { },
  "id_str" : "256413973468045312",
  "in_reply_to_user_id" : 14432203,
  "text" : "@will_j @dhh yep, bundler's gem tasks have nailed this. building gems as a service failed before, and I don't think it's gotten any easier",
  "id" : 256413973468045312,
  "in_reply_to_status_id" : 256413684212043777,
  "created_at" : "2012-10-11 15:20:29 +0000",
  "in_reply_to_screen_name" : "will_j",
  "in_reply_to_user_id_str" : "14432203",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "Joe Bean Roasters",
      "screen_name" : "JoeBeanRoasters",
      "indices" : [ 62, 78 ],
      "id_str" : "83895391",
      "id" : 83895391
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/256396095926726656\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/lr9hVqpH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A47m5AvCcAEfK7i.jpg",
      "id_str" : "256396095930920961",
      "id" : 256396095930920961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A47m5AvCcAEfK7i.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/lr9hVqpH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256402828250210304",
  "text" : "RT @coworkbuffalo: What\u2019s you\u2019re missing out on here\u2026Chemex + @JoeBeanRoasters (We\u2019re open for the day too!) http:\/\/t.co\/lr9hVqpH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Bean Roasters",
        "screen_name" : "JoeBeanRoasters",
        "indices" : [ 43, 59 ],
        "id_str" : "83895391",
        "id" : 83895391
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/256396095926726656\/photo\/1",
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/lr9hVqpH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A47m5AvCcAEfK7i.jpg",
        "id_str" : "256396095930920961",
        "id" : 256396095930920961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A47m5AvCcAEfK7i.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/lr9hVqpH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256396095926726656",
    "text" : "What\u2019s you\u2019re missing out on here\u2026Chemex + @JoeBeanRoasters (We\u2019re open for the day too!) http:\/\/t.co\/lr9hVqpH",
    "id" : 256396095926726656,
    "created_at" : "2012-10-11 14:09:28 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 256402828250210304,
  "created_at" : "2012-10-11 14:36:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256372942718513152",
  "geo" : { },
  "id_str" : "256373350509719552",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer cool. About to start something similar tomorrow and far too nervous about it! I will check out kidsruby.",
  "id" : 256373350509719552,
  "in_reply_to_status_id" : 256372942718513152,
  "created_at" : "2012-10-11 12:39:04 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256367648953233408",
  "geo" : { },
  "id_str" : "256368521741746176",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer awesome. What are you using to help teach it?",
  "id" : 256368521741746176,
  "in_reply_to_status_id" : 256367648953233408,
  "created_at" : "2012-10-11 12:19:53 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lloyd Taco Trucks",
      "screen_name" : "whereslloyd",
      "indices" : [ 0, 12 ],
      "id_str" : "156689065",
      "id" : 156689065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256121628260462592",
  "geo" : { },
  "id_str" : "256138995300450304",
  "in_reply_to_user_id" : 156689065,
  "text" : "@whereslloyd What time?",
  "id" : 256138995300450304,
  "in_reply_to_status_id" : 256121628260462592,
  "created_at" : "2012-10-10 21:07:49 +0000",
  "in_reply_to_screen_name" : "whereslloyd",
  "in_reply_to_user_id_str" : "156689065",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256127194596782080",
  "text" : "\"ALIEN MONSTER\" \"HIGH VOLTAGE SIGN\"",
  "id" : 256127194596782080,
  "created_at" : "2012-10-10 20:20:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256127116192649217",
  "text" : "Holy shit, VoiceOver in iOS SPEAKS EMOJI.",
  "id" : 256127116192649217,
  "created_at" : "2012-10-10 20:20:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "herpderpedia",
      "screen_name" : "herpderpedia",
      "indices" : [ 28, 41 ],
      "id_str" : "467162656",
      "id" : 467162656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256053690497114112",
  "geo" : { },
  "id_str" : "256054770098372608",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil Don't make me get @herpderpedia out.",
  "id" : 256054770098372608,
  "in_reply_to_status_id" : 256053690497114112,
  "created_at" : "2012-10-10 15:33:09 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/NBcQgXqY",
      "expanded_url" : "http:\/\/www.sunwaylagoon.com\/amusement.asp",
      "display_url" : "sunwaylagoon.com\/amusement.asp"
    } ]
  },
  "geo" : { },
  "id_str" : "256050535826862080",
  "text" : "WILD WILD WEST. \"The excitement never stops at the Niagara Falls Flume Ride...\" http:\/\/t.co\/NBcQgXqY",
  "id" : 256050535826862080,
  "created_at" : "2012-10-10 15:16:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curtis Duhn",
      "screen_name" : "cduhn",
      "indices" : [ 0, 6 ],
      "id_str" : "3947081",
      "id" : 3947081
    }, {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 7, 20 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 21, 31 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 105, 119 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256039687280549890",
  "geo" : { },
  "id_str" : "256040952370704385",
  "in_reply_to_user_id" : 3947081,
  "text" : "@cduhn @robertromito @magnachef I'd like to keep it consistent. How many show up? Can we just have it at @coworkbuffalo ? (with more chairs)",
  "id" : 256040952370704385,
  "in_reply_to_status_id" : 256039687280549890,
  "created_at" : "2012-10-10 14:38:14 +0000",
  "in_reply_to_screen_name" : "cduhn",
  "in_reply_to_user_id_str" : "3947081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256034864569143296",
  "geo" : { },
  "id_str" : "256035529135636480",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda slash too many times, and a horde of cats with huge gold chains fly in every direction, scratching you to death",
  "id" : 256035529135636480,
  "in_reply_to_status_id" : 256034864569143296,
  "created_at" : "2012-10-10 14:16:41 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/epnjp2aB",
      "expanded_url" : "http:\/\/turntable.fm\/coworkbuffalo",
      "display_url" : "turntable.fm\/coworkbuffalo"
    } ]
  },
  "geo" : { },
  "id_str" : "256033005150289922",
  "text" : "DJing in the CoworkBuffalo room. Come hang out! Now playing Strangefolk: So Well \u266B\u266A #turntablefm http:\/\/t.co\/epnjp2aB",
  "id" : 256033005150289922,
  "created_at" : "2012-10-10 14:06:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/Z2XX3dTK",
      "expanded_url" : "http:\/\/www.writography.net\/code\/simcity-alerts\/",
      "display_url" : "writography.net\/code\/simcity-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256031803662553088",
  "text" : "This is amazing: http:\/\/t.co\/Z2XX3dTK",
  "id" : 256031803662553088,
  "created_at" : "2012-10-10 14:01:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 0, 13 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 14, 24 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 25, 39 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255915360342130688",
  "geo" : { },
  "id_str" : "256006180365799425",
  "in_reply_to_user_id" : 38450774,
  "text" : "@robertromito @magnachef @coworkbuffalo we\u2019ve got every other Tuesday from here on out. Event repeats on meet up.",
  "id" : 256006180365799425,
  "in_reply_to_status_id" : 255915360342130688,
  "created_at" : "2012-10-10 12:20:04 +0000",
  "in_reply_to_screen_name" : "robertromito",
  "in_reply_to_user_id_str" : "38450774",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenHack",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255896056947175425",
  "text" : "Really excited to turn #OpenHack into a bigger thing than just here in Buffalo. Stay tuned.",
  "id" : 255896056947175425,
  "created_at" : "2012-10-10 05:02:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 3, 16 ],
      "id_str" : "38450774",
      "id" : 38450774
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255895938915237888",
  "text" : "RT @robertromito: Who's up for an #openhack next Tuesday?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 16, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255857542129926144",
    "text" : "Who's up for an #openhack next Tuesday?",
    "id" : 255857542129926144,
    "created_at" : "2012-10-10 02:29:26 +0000",
    "user" : {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "protected" : false,
      "id_str" : "38450774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/250418735\/myheadshot_normal.jpg",
      "id" : 38450774,
      "verified" : false
    }
  },
  "id" : 255895938915237888,
  "created_at" : "2012-10-10 05:02:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 3, 10 ],
      "id_str" : "22627592",
      "id" : 22627592
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 89, 103 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhack",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255895893977493505",
  "text" : "RT @zobar2: #openhack was rad. Very chill, welcoming. A lot of different stuff going on. @coworkbuffalo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 77, 91 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openhack",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.95966855, -78.85040582 ]
    },
    "id_str" : "255855117918674944",
    "text" : "#openhack was rad. Very chill, welcoming. A lot of different stuff going on. @coworkbuffalo",
    "id" : 255855117918674944,
    "created_at" : "2012-10-10 02:19:48 +0000",
    "user" : {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "protected" : false,
      "id_str" : "22627592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458782626443051008\/OAQrrTuE_normal.png",
      "id" : 22627592,
      "verified" : false
    }
  },
  "id" : 255895893977493505,
  "created_at" : "2012-10-10 05:01:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255856021313036288",
  "geo" : { },
  "id_str" : "255856135918198784",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr Every other Tuesday.",
  "id" : 255856135918198784,
  "in_reply_to_status_id" : 255856021313036288,
  "created_at" : "2012-10-10 02:23:51 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/SC7Ub0fu",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=sAzzbrFgcUw",
      "display_url" : "youtube.com\/watch?v=sAzzbr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255855145794035712",
  "text" : "This video is going to make any video game nerd smile: http:\/\/t.co\/SC7Ub0fu",
  "id" : 255855145794035712,
  "created_at" : "2012-10-10 02:19:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "indices" : [ 3, 16 ],
      "id_str" : "38450774",
      "id" : 38450774
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 37, 51 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenHack",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255851928100171777",
  "text" : "RT @robertromito: Enjoying #OpenHack @coworkbuffalo. Geeks geeking out on different things. The exact ambiance I've been looking for.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 19, 33 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenHack",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255838617459630081",
    "text" : "Enjoying #OpenHack @coworkbuffalo. Geeks geeking out on different things. The exact ambiance I've been looking for.",
    "id" : 255838617459630081,
    "created_at" : "2012-10-10 01:14:14 +0000",
    "user" : {
      "name" : "Robert Romito",
      "screen_name" : "robertromito",
      "protected" : false,
      "id_str" : "38450774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/250418735\/myheadshot_normal.jpg",
      "id" : 38450774,
      "verified" : false
    }
  },
  "id" : 255851928100171777,
  "created_at" : "2012-10-10 02:07:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 14, 25 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255851566127513600",
  "text" : "Big thanks to @engineyard for sponsoring Buffalo\u2019s first OpenHack night! Lots of great code and discussion.",
  "id" : 255851566127513600,
  "created_at" : "2012-10-10 02:05:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 58, 72 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255815868506832896",
  "text" : "Victims of our own success: Out of chairs for OpenHack at @coworkbuffalo. Someday these won't be problems!",
  "id" : 255815868506832896,
  "created_at" : "2012-10-09 23:43:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 0, 10 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255738554129469440",
  "geo" : { },
  "id_str" : "255738818471264256",
  "in_reply_to_user_id" : 5744442,
  "text" : "@aquaranto yeah, a few cuts and a brushburn. nothing serious.",
  "id" : 255738818471264256,
  "in_reply_to_status_id" : 255738554129469440,
  "created_at" : "2012-10-09 18:37:40 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255738005703258112",
  "text" : "First official dooring, fell off bike. Only a few scratches. Mostly my fault for going too fast and not paying attention. Woo...",
  "id" : 255738005703258112,
  "created_at" : "2012-10-09 18:34:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fending",
      "screen_name" : "fending",
      "indices" : [ 3, 11 ],
      "id_str" : "14672651",
      "id" : 14672651
    }, {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 36, 48 ],
      "id_str" : "140515765",
      "id" : 140515765
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 108, 122 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255669123063881731",
  "text" : "RT @fending: Hey, did you know that @TEDxBuffalo is being streamed online? And that it's on a big screen at @coworkbuffalo?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxBuffalo",
        "screen_name" : "TEDxBuffalo",
        "indices" : [ 23, 35 ],
        "id_str" : "140515765",
        "id" : 140515765
      }, {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 95, 109 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255663521814159360",
    "text" : "Hey, did you know that @TEDxBuffalo is being streamed online? And that it's on a big screen at @coworkbuffalo?",
    "id" : 255663521814159360,
    "created_at" : "2012-10-09 13:38:28 +0000",
    "user" : {
      "name" : "fending",
      "screen_name" : "fending",
      "protected" : false,
      "id_str" : "14672651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468101796\/ed9f5bca1aff3f91233b2986acb0fd4e_normal.jpeg",
      "id" : 14672651,
      "verified" : false
    }
  },
  "id" : 255669123063881731,
  "created_at" : "2012-10-09 14:00:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 42, 51 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cl9wMGej",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fhdCslFcKFU",
      "display_url" : "youtube.com\/watch?v=fhdCsl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255665467107180544",
  "text" : "Current status: http:\/\/t.co\/cl9wMGej (via @roidrage)",
  "id" : 255665467107180544,
  "created_at" : "2012-10-09 13:46:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Sussman",
      "screen_name" : "noahsussman",
      "indices" : [ 0, 12 ],
      "id_str" : "6331142",
      "id" : 6331142
    }, {
      "name" : "Sebastian Delmont",
      "screen_name" : "sd",
      "indices" : [ 13, 16 ],
      "id_str" : "755241",
      "id" : 755241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255663032057872384",
  "geo" : { },
  "id_str" : "255663582459596800",
  "in_reply_to_user_id" : 6331142,
  "text" : "@noahsussman @sd yeah not trying to say any system is perfect, but the way the article puts it smells bad to me",
  "id" : 255663582459596800,
  "in_reply_to_status_id" : 255663032057872384,
  "created_at" : "2012-10-09 13:38:42 +0000",
  "in_reply_to_screen_name" : "noahsussman",
  "in_reply_to_user_id_str" : "6331142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen Lillich",
      "screen_name" : "Geewiz",
      "indices" : [ 3, 10 ],
      "id_str" : "659393",
      "id" : 659393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/l4hB8wRM",
      "expanded_url" : "http:\/\/bit.ly\/Qcdp2n",
      "display_url" : "bit.ly\/Qcdp2n"
    } ]
  },
  "geo" : { },
  "id_str" : "255649721908088833",
  "text" : "RT @Geewiz: Nice way to package a set of command line tools: \"Automating with convention: Introducing sub\" http:\/\/t.co\/l4hB8wRM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/l4hB8wRM",
        "expanded_url" : "http:\/\/bit.ly\/Qcdp2n",
        "display_url" : "bit.ly\/Qcdp2n"
      } ]
    },
    "geo" : { },
    "id_str" : "255562017258233856",
    "text" : "Nice way to package a set of command line tools: \"Automating with convention: Introducing sub\" http:\/\/t.co\/l4hB8wRM",
    "id" : 255562017258233856,
    "created_at" : "2012-10-09 06:55:07 +0000",
    "user" : {
      "name" : "Jochen Lillich",
      "screen_name" : "Geewiz",
      "protected" : false,
      "id_str" : "659393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432967348236980224\/aN8hsw-r_normal.jpeg",
      "id" : 659393,
      "verified" : false
    }
  },
  "id" : 255649721908088833,
  "created_at" : "2012-10-09 12:43:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255510425251246080",
  "text" : "\"The bottles are bribes from engineers trying to persuade Rossi to incorporate their changes into the Push\" How is this not totally fucked?",
  "id" : 255510425251246080,
  "created_at" : "2012-10-09 03:30:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Letterle",
      "screen_name" : "mletterle",
      "indices" : [ 0, 10 ],
      "id_str" : "458173",
      "id" : 458173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255507716628422657",
  "geo" : { },
  "id_str" : "255510048380448768",
  "in_reply_to_user_id" : 458173,
  "text" : "@mletterle why isn't this \"today\" instead of \"one day\" ?",
  "id" : 255510048380448768,
  "in_reply_to_status_id" : 255507716628422657,
  "created_at" : "2012-10-09 03:28:37 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/3Oztem1d",
      "expanded_url" : "http:\/\/www.businessweek.com\/articles\/2012-10-08\/the-only-earthling-with-a-facebook-dislike-button",
      "display_url" : "businessweek.com\/articles\/2012-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255509588034588672",
  "text" : "FB engineers have 4 stars, lose one for production\/release bugs. Less = more review. Seems unhealthy: http:\/\/t.co\/3Oztem1d",
  "id" : 255509588034588672,
  "created_at" : "2012-10-09 03:26:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255480666580455425",
  "geo" : { },
  "id_str" : "255481335211245568",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove please tell me you worked Gorby into your talks IRL",
  "id" : 255481335211245568,
  "in_reply_to_status_id" : 255480666580455425,
  "created_at" : "2012-10-09 01:34:31 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "auntie moon",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 21, 29 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255471287428853761",
  "geo" : { },
  "id_str" : "255471781324922881",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @twitter @capotej that seems to have resolved it, but many times it has not. What a shitshow.",
  "id" : 255471781324922881,
  "in_reply_to_status_id" : 255471287428853761,
  "created_at" : "2012-10-09 00:56:33 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 42 ],
      "url" : "https:\/\/t.co\/V8cFMRzL",
      "expanded_url" : "https:\/\/img.skitch.com\/20121009-r3esi2msir2u967swb1d1m66i2.png",
      "display_url" : "img.skitch.com\/20121009-r3esi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "255470721722101760",
  "geo" : { },
  "id_str" : "255471280273362944",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej Did you see https:\/\/t.co\/V8cFMRzL ?",
  "id" : 255471280273362944,
  "in_reply_to_status_id" : 255470721722101760,
  "created_at" : "2012-10-09 00:54:34 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 19, 27 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/V8cFMRzL",
      "expanded_url" : "https:\/\/img.skitch.com\/20121009-r3esi2msir2u967swb1d1m66i2.png",
      "display_url" : "img.skitch.com\/20121009-r3esi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255471000228073472",
  "text" : "This. WTF is this, @twitter? Does anyone use the website who works there? https:\/\/t.co\/V8cFMRzL",
  "id" : 255471000228073472,
  "created_at" : "2012-10-09 00:53:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/xxSp7RSI",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "255469125030260736",
  "text" : "I've had a light beneath my \"Me\" button on http:\/\/t.co\/xxSp7RSI for a while now, no idea how to clear it. So sick of this lack of caring.",
  "id" : 255469125030260736,
  "created_at" : "2012-10-09 00:46:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Von Strasburg",
      "screen_name" : "justingoboom",
      "indices" : [ 0, 13 ],
      "id_str" : "3479601",
      "id" : 3479601
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 14, 28 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255367275622825984",
  "geo" : { },
  "id_str" : "255468244444520448",
  "in_reply_to_user_id" : 3479601,
  "text" : "@justingoboom @coworkbuffalo we're trying to keep all of the decor as matched as possible. thanks for the offer.",
  "id" : 255468244444520448,
  "in_reply_to_status_id" : 255367275622825984,
  "created_at" : "2012-10-09 00:42:30 +0000",
  "in_reply_to_screen_name" : "justingoboom",
  "in_reply_to_user_id_str" : "3479601",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 24, 34 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255444985216897024",
  "geo" : { },
  "id_str" : "255445058222948352",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors whaaaat @aquaranto",
  "id" : 255445058222948352,
  "in_reply_to_status_id" : 255444985216897024,
  "created_at" : "2012-10-08 23:10:22 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Josef",
      "screen_name" : "1ofyourmeteors",
      "indices" : [ 0, 15 ],
      "id_str" : "155998525",
      "id" : 155998525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255443792222625792",
  "geo" : { },
  "id_str" : "255444546270404609",
  "in_reply_to_user_id" : 155998525,
  "text" : "@1ofyourmeteors wat",
  "id" : 255444546270404609,
  "in_reply_to_status_id" : 255443792222625792,
  "created_at" : "2012-10-08 23:08:20 +0000",
  "in_reply_to_screen_name" : "1ofyourmeteors",
  "in_reply_to_user_id_str" : "155998525",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 0, 7 ],
      "id_str" : "14425908",
      "id" : 14425908
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 8, 16 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 17, 24 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255443848682168320",
  "geo" : { },
  "id_str" : "255444488015720448",
  "in_reply_to_user_id" : 14425908,
  "text" : "@jc00ke @evanphx @sferik that\u2019s probably a good step, but invalidating it is hard",
  "id" : 255444488015720448,
  "in_reply_to_status_id" : 255443848682168320,
  "created_at" : "2012-10-08 23:08:06 +0000",
  "in_reply_to_screen_name" : "jc00ke",
  "in_reply_to_user_id_str" : "14425908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 24, 34 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255438991044775936",
  "geo" : { },
  "id_str" : "255441851933401088",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik @cldwalker sounds like it\u2019s benchmark\/optimize time.",
  "id" : 255441851933401088,
  "in_reply_to_status_id" : 255438991044775936,
  "created_at" : "2012-10-08 22:57:38 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255439935165829120",
  "text" : "Alright, no idea what I\u2019m talking about. Lack the time to make any of it real. I\u2019m going to grill some shit and continue with life.",
  "id" : 255439935165829120,
  "created_at" : "2012-10-08 22:50:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 24, 34 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255438085414858752",
  "geo" : { },
  "id_str" : "255438831237615616",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik @cldwalker Maybe it\u2019s time for v2 of the dep API then? Need to decrease load somehow.",
  "id" : 255438831237615616,
  "in_reply_to_status_id" : 255438085414858752,
  "created_at" : "2012-10-08 22:45:37 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 0, 6 ],
      "id_str" : "11294",
      "id" : 11294
    }, {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 7, 17 ],
      "id_str" : "870450487",
      "id" : 870450487
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 118, 126 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255437182637068290",
  "geo" : { },
  "id_str" : "255437507762716672",
  "in_reply_to_user_id" : 11294,
  "text" : "@nzkoz @samsoffes literally have no idea how to set any of that shit up. Looking to get back to ZERO maintenance. \/cc @evanphx",
  "id" : 255437507762716672,
  "in_reply_to_status_id" : 255437182637068290,
  "created_at" : "2012-10-08 22:40:22 +0000",
  "in_reply_to_screen_name" : "nzkoz",
  "in_reply_to_user_id_str" : "11294",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 9, 16 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 17, 23 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 24, 34 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255436918781788161",
  "geo" : { },
  "id_str" : "255437323490193408",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @sferik @cmeik @cldwalker every HTML endpoint. All of them. Edit profile, etc would be a separate (with push\/bundler 1.1 API)",
  "id" : 255437323490193408,
  "in_reply_to_status_id" : 255436918781788161,
  "created_at" : "2012-10-08 22:39:38 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    }, {
      "name" : "Michael Koziarski",
      "screen_name" : "nzkoz",
      "indices" : [ 11, 17 ],
      "id_str" : "11294",
      "id" : 11294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255436850657910784",
  "geo" : { },
  "id_str" : "255436963216232449",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes @nzkoz that's all API...i mean specifically all of the rails HTML endpoints.",
  "id" : 255436963216232449,
  "in_reply_to_status_id" : 255436850657910784,
  "created_at" : "2012-10-08 22:38:12 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Golick",
      "screen_name" : "jamesgolick",
      "indices" : [ 0, 12 ],
      "id_str" : "12027042",
      "id" : 12027042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255436340185952256",
  "geo" : { },
  "id_str" : "255436801387425792",
  "in_reply_to_user_id" : 12027042,
  "text" : "@jamesgolick \"slow as fuck\" is a bad reason to switch",
  "id" : 255436801387425792,
  "in_reply_to_status_id" : 255436340185952256,
  "created_at" : "2012-10-08 22:37:33 +0000",
  "in_reply_to_screen_name" : "jamesgolick",
  "in_reply_to_user_id_str" : "12027042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 4, 12 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 13, 20 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 21, 27 ],
      "id_str" : "6815762",
      "id" : 6815762
    }, {
      "name" : "Gabriel Horner",
      "screen_name" : "cldwalker",
      "indices" : [ 28, 38 ],
      "id_str" : "19846068",
      "id" : 19846068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 85 ],
      "url" : "https:\/\/t.co\/ohyAniop",
      "expanded_url" : "https:\/\/twitter.com\/qrush\/status\/255436095012085761",
      "display_url" : "twitter.com\/qrush\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255436471132119040",
  "text" : "Hey @evanphx @sferik @cmeik @cldwalker what do you think about: https:\/\/t.co\/ohyAniop",
  "id" : 255436471132119040,
  "created_at" : "2012-10-08 22:36:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "255436095012085761",
  "text" : "This is a little nuts...what if http:\/\/t.co\/bdjsRgTW was 100% static? The API was still there, but all HTML is compiled and served off S3.",
  "id" : 255436095012085761,
  "created_at" : "2012-10-08 22:34:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/TdSzC1sB",
      "expanded_url" : "http:\/\/monstersuniversity.com\/edu\/index.html",
      "display_url" : "monstersuniversity.com\/edu\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "255423018359201793",
  "text" : "It's pretty pathetic that this looks better than most university sites out there: http:\/\/t.co\/TdSzC1sB",
  "id" : 255423018359201793,
  "created_at" : "2012-10-08 21:42:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 0, 8 ],
      "id_str" : "15944824",
      "id" : 15944824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255394497515634688",
  "geo" : { },
  "id_str" : "255404900916289536",
  "in_reply_to_user_id" : 15944824,
  "text" : "@paulehr yep, 27\".",
  "id" : 255404900916289536,
  "in_reply_to_status_id" : 255394497515634688,
  "created_at" : "2012-10-08 20:30:48 +0000",
  "in_reply_to_screen_name" : "paulehr",
  "in_reply_to_user_id_str" : "15944824",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zed",
      "screen_name" : "zedshaw",
      "indices" : [ 0, 8 ],
      "id_str" : "15029296",
      "id" : 15029296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255403959206936576",
  "geo" : { },
  "id_str" : "255404495654223872",
  "in_reply_to_user_id" : 15029296,
  "text" : "@zedshaw Love this idea. I'd like to see a product like this.",
  "id" : 255404495654223872,
  "in_reply_to_status_id" : 255403959206936576,
  "created_at" : "2012-10-08 20:29:11 +0000",
  "in_reply_to_screen_name" : "zedshaw",
  "in_reply_to_user_id_str" : "15029296",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chap Ambrose",
      "screen_name" : "chapambrose",
      "indices" : [ 0, 12 ],
      "id_str" : "10978282",
      "id" : 10978282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255388701440495616",
  "geo" : { },
  "id_str" : "255388999315767296",
  "in_reply_to_user_id" : 10978282,
  "text" : "@chapambrose i'm just one piece in the puzzle...thanks dude.",
  "id" : 255388999315767296,
  "in_reply_to_status_id" : 255388701440495616,
  "created_at" : "2012-10-08 19:27:36 +0000",
  "in_reply_to_screen_name" : "chapambrose",
  "in_reply_to_user_id_str" : "10978282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255386847738486784",
  "geo" : { },
  "id_str" : "255387062423924736",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k Nope, not doing any more confs in 2012.",
  "id" : 255387062423924736,
  "in_reply_to_status_id" : 255386847738486784,
  "created_at" : "2012-10-08 19:19:55 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Kuchera",
      "screen_name" : "BenKuchera",
      "indices" : [ 3, 14 ],
      "id_str" : "14575846",
      "id" : 14575846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aZ27qYyt",
      "expanded_url" : "http:\/\/penny-arcade.com\/report\/editorial-article\/artemis-the-six-player-starship-simulator-is-coming-to-ios-devices-with-ful",
      "display_url" : "penny-arcade.com\/report\/editori\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255381348288712704",
  "text" : "RT @BenKuchera: The PC starship simulator Artemis is coming to iOS. Playing with a full six-person bridge will be MUCH eaiser: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/aZ27qYyt",
        "expanded_url" : "http:\/\/penny-arcade.com\/report\/editorial-article\/artemis-the-six-player-starship-simulator-is-coming-to-ios-devices-with-ful",
        "display_url" : "penny-arcade.com\/report\/editori\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "255377105368530944",
    "text" : "The PC starship simulator Artemis is coming to iOS. Playing with a full six-person bridge will be MUCH eaiser: http:\/\/t.co\/aZ27qYyt",
    "id" : 255377105368530944,
    "created_at" : "2012-10-08 18:40:21 +0000",
    "user" : {
      "name" : "Ben Kuchera",
      "screen_name" : "BenKuchera",
      "protected" : false,
      "id_str" : "14575846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547652876462346241\/GLxjgDpP_normal.png",
      "id" : 14575846,
      "verified" : true
    }
  },
  "id" : 255381348288712704,
  "created_at" : "2012-10-08 18:57:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turntablefm",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/WSb34amI",
      "expanded_url" : "http:\/\/turntable.fm\/thoughtbot2",
      "display_url" : "turntable.fm\/thoughtbot2"
    } ]
  },
  "geo" : { },
  "id_str" : "255378925641949185",
  "text" : "DJing in the thoughtbot room. Come hang out! Now playing Dragonforce: Heroes Of Our Time \u266B\u266A #turntablefm http:\/\/t.co\/WSb34amI",
  "id" : 255378925641949185,
  "created_at" : "2012-10-08 18:47:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 0, 7 ],
      "id_str" : "14425908",
      "id" : 14425908
    }, {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 8, 20 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/gLkVNqap",
      "expanded_url" : "http:\/\/m.rubygems.org",
      "display_url" : "m.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "255365365515833344",
  "geo" : { },
  "id_str" : "255367516480737281",
  "in_reply_to_user_id" : 14425908,
  "text" : "@jc00ke @bcardarella http:\/\/t.co\/gLkVNqap",
  "id" : 255367516480737281,
  "in_reply_to_status_id" : 255365365515833344,
  "created_at" : "2012-10-08 18:02:15 +0000",
  "in_reply_to_screen_name" : "jc00ke",
  "in_reply_to_user_id_str" : "14425908",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 14, 26 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 38, 47 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/gYgk12nv",
      "expanded_url" : "https:\/\/twitter.com\/rubygems\/status\/255360401766772736",
      "display_url" : "twitter.com\/rubygems\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255360769925992448",
  "text" : "Big thanks to @bcardarella for fixing @rubygems! https:\/\/t.co\/gYgk12nv",
  "id" : 255360769925992448,
  "created_at" : "2012-10-08 17:35:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 57, 71 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/4hfsIU68",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/events\/86048082\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255348664204152832",
  "text" : "Happy to announce the first OpenHack night, tomorrow 7pm @coworkbuffalo: http:\/\/t.co\/4hfsIU68",
  "id" : 255348664204152832,
  "created_at" : "2012-10-08 16:47:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan deLevie",
      "screen_name" : "adelevie",
      "indices" : [ 0, 9 ],
      "id_str" : "12855662",
      "id" : 12855662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255346229406482435",
  "geo" : { },
  "id_str" : "255348054444630016",
  "in_reply_to_user_id" : 12855662,
  "text" : "@adelevie all I did was extract it, Sam did the heavy lifting in rbenv :)",
  "id" : 255348054444630016,
  "in_reply_to_status_id" : 255346229406482435,
  "created_at" : "2012-10-08 16:44:54 +0000",
  "in_reply_to_screen_name" : "adelevie",
  "in_reply_to_user_id_str" : "12855662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ehrenreich",
      "screen_name" : "paulehr",
      "indices" : [ 80, 88 ],
      "id_str" : "15944824",
      "id" : 15944824
    }, {
      "name" : "Luis Jos\u00E9 Da Silva",
      "screen_name" : "luisjoseve",
      "indices" : [ 89, 100 ],
      "id_str" : "56423575",
      "id" : 56423575
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 101, 109 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/255341785012899840\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/DHQUYxz3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4soACiCEAAxAnH.jpg",
      "id_str" : "255341785021288448",
      "id" : 255341785021288448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4soACiCEAAxAnH.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DHQUYxz3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255341785012899840",
  "text" : "Since some folks asked, here\u2019s the vertical setup. No rotation, just placement. @paulehr @luisjoseve @jayunit http:\/\/t.co\/DHQUYxz3",
  "id" : 255341785012899840,
  "created_at" : "2012-10-08 16:20:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 111 ],
      "url" : "https:\/\/t.co\/QhiTRYJ7",
      "expanded_url" : "https:\/\/twitter.com\/i\/#!\/search\/realtime\/%22am%20i%20the%20only%20one%22",
      "display_url" : "twitter.com\/i\/#!\/search\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255338841949478912",
  "text" : "Stupid twitter bot idea: Respond to all tweets with \"Am I the only one [...]\" with \"Yes.\" https:\/\/t.co\/QhiTRYJ7",
  "id" : 255338841949478912,
  "created_at" : "2012-10-08 16:08:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 13, 24 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255332375758770176",
  "geo" : { },
  "id_str" : "255334792181190656",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @laserlemon I think I just did it? Let me know. Probably need to watch the logs and see what's up.",
  "id" : 255334792181190656,
  "in_reply_to_status_id" : 255332375758770176,
  "created_at" : "2012-10-08 15:52:13 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 13, 22 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 71, 82 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255331831229063168",
  "geo" : { },
  "id_str" : "255332225812398080",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @rubygems honestly not sure. You have reminded me to hook @laserlemon up with access to it. want to help debug too?",
  "id" : 255332225812398080,
  "in_reply_to_status_id" : 255331831229063168,
  "created_at" : "2012-10-08 15:42:01 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 13, 22 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255322633711808513",
  "geo" : { },
  "id_str" : "255330296143151105",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella @rubygems Halted?",
  "id" : 255330296143151105,
  "in_reply_to_status_id" : 255322633711808513,
  "created_at" : "2012-10-08 15:34:21 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255320706471059457",
  "geo" : { },
  "id_str" : "255321034935382016",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle it's just posturing, ranking...dislike.",
  "id" : 255321034935382016,
  "in_reply_to_status_id" : 255320706471059457,
  "created_at" : "2012-10-08 14:57:33 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Biddle",
      "screen_name" : "sabiddle",
      "indices" : [ 0, 9 ],
      "id_str" : "20531902",
      "id" : 20531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255320706471059457",
  "geo" : { },
  "id_str" : "255320922750345216",
  "in_reply_to_user_id" : 20531902,
  "text" : "@sabiddle I am, but that doesn't change the feeling",
  "id" : 255320922750345216,
  "in_reply_to_status_id" : 255320706471059457,
  "created_at" : "2012-10-08 14:57:06 +0000",
  "in_reply_to_screen_name" : "sabiddle",
  "in_reply_to_user_id_str" : "20531902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/to40Rng4",
      "expanded_url" : "http:\/\/www.starling-software.com\/employment\/programmer-competency-matrix.html",
      "display_url" : "starling-software.com\/employment\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255320159714164737",
  "text" : "How to make yourself feel inferior and depressed, instantly: http:\/\/t.co\/to40Rng4",
  "id" : 255320159714164737,
  "created_at" : "2012-10-08 14:54:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ori Rawlings",
      "screen_name" : "orirawlings",
      "indices" : [ 3, 15 ],
      "id_str" : "14793715",
      "id" : 14793715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 83 ],
      "url" : "https:\/\/t.co\/QoiZE3iz",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "255319645454745601",
  "text" : "RT @orirawlings: Looking forward to playing around with this. https:\/\/t.co\/QoiZE3iz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 66 ],
        "url" : "https:\/\/t.co\/QoiZE3iz",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "255291382858661889",
    "text" : "Looking forward to playing around with this. https:\/\/t.co\/QoiZE3iz",
    "id" : 255291382858661889,
    "created_at" : "2012-10-08 12:59:43 +0000",
    "user" : {
      "name" : "Ori Rawlings",
      "screen_name" : "orirawlings",
      "protected" : false,
      "id_str" : "14793715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471783858166579201\/_Jnec8Wo_normal.jpeg",
      "id" : 14793715,
      "verified" : false
    }
  },
  "id" : 255319645454745601,
  "created_at" : "2012-10-08 14:52:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Perry",
      "screen_name" : "DeanPerry",
      "indices" : [ 0, 10 ],
      "id_str" : "5489202",
      "id" : 5489202
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 59, 67 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubygems",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255308788343664640",
  "geo" : { },
  "id_str" : "255312451338395648",
  "in_reply_to_user_id" : 5489202,
  "text" : "@DeanPerry we have a few official mirrors already. Talk to @evanphx and jump on #rubygems on Freenode.",
  "id" : 255312451338395648,
  "in_reply_to_status_id" : 255308788343664640,
  "created_at" : "2012-10-08 14:23:26 +0000",
  "in_reply_to_screen_name" : "DeanPerry",
  "in_reply_to_user_id_str" : "5489202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    }, {
      "name" : "Jimmy Bogard",
      "screen_name" : "jbogard",
      "indices" : [ 9, 17 ],
      "id_str" : "11956732",
      "id" : 11956732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255310007783026690",
  "geo" : { },
  "id_str" : "255310103580917760",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit @jbogard it's not rotated.",
  "id" : 255310103580917760,
  "in_reply_to_status_id" : 255310007783026690,
  "created_at" : "2012-10-08 14:14:06 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 14, 25 ],
      "id_str" : "13984262",
      "id" : 13984262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255308571246473216",
  "text" : "Big thanks to @themcgruff for helping me stumble through this.",
  "id" : 255308571246473216,
  "created_at" : "2012-10-08 14:08:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/bdjsRgTW",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "255308526883307521",
  "text" : "I am the only one responding to http:\/\/t.co\/bdjsRgTW downtime right now. Sorry everyone.",
  "id" : 255308526883307521,
  "created_at" : "2012-10-08 14:07:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255306037362561024",
  "text" : "Trying out vertical orientation for monitors today, Thunderbolt above laptop. Passive display up top (email, campfire), active on bottom.",
  "id" : 255306037362561024,
  "created_at" : "2012-10-08 13:57:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255216966539816960",
  "geo" : { },
  "id_str" : "255296147051147264",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k why not Hawaii?",
  "id" : 255296147051147264,
  "in_reply_to_status_id" : 255216966539816960,
  "created_at" : "2012-10-08 13:18:39 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/eugBZ9Rz",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=gjwofYhUJEM&desktop_uri=%2Fwatch%3Fv%3DgjwofYhUJEM",
      "display_url" : "m.youtube.com\/#\/watch?v=gjwo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "255178165146746880",
  "geo" : { },
  "id_str" : "255179083850334208",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler without closings of doors? http:\/\/t.co\/eugBZ9Rz",
  "id" : 255179083850334208,
  "in_reply_to_status_id" : 255178165146746880,
  "created_at" : "2012-10-08 05:33:29 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 3, 11 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 107 ],
      "url" : "https:\/\/t.co\/eenvW43l",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "255178128836665346",
  "text" : "RT @capotej: late to the party, but this is an awesome way to organize shell scripts: https:\/\/t.co\/eenvW43l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 94 ],
        "url" : "https:\/\/t.co\/eenvW43l",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "255148007819984896",
    "text" : "late to the party, but this is an awesome way to organize shell scripts: https:\/\/t.co\/eenvW43l",
    "id" : 255148007819984896,
    "created_at" : "2012-10-08 03:30:00 +0000",
    "user" : {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "protected" : false,
      "id_str" : "8898642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497932410890510337\/i-8d5ayf_normal.jpeg",
      "id" : 8898642,
      "verified" : false
    }
  },
  "id" : 255178128836665346,
  "created_at" : "2012-10-08 05:29:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255154066546630656",
  "geo" : { },
  "id_str" : "255178039607054336",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej awesome!",
  "id" : 255178039607054336,
  "in_reply_to_status_id" : 255154066546630656,
  "created_at" : "2012-10-08 05:29:20 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 3, 11 ],
      "id_str" : "8898642",
      "id" : 8898642
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 102, 108 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https:\/\/t.co\/vVsZxiZD",
      "expanded_url" : "https:\/\/github.com\/capotej\/kiev",
      "display_url" : "github.com\/capotej\/kiev"
    } ]
  },
  "geo" : { },
  "id_str" : "255177777081376768",
  "text" : "RT @capotej: wrapped up that embeddable key\/value store into a sub command: https:\/\/t.co\/vVsZxiZD \/cc @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 89, 95 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 84 ],
        "url" : "https:\/\/t.co\/vVsZxiZD",
        "expanded_url" : "https:\/\/github.com\/capotej\/kiev",
        "display_url" : "github.com\/capotej\/kiev"
      } ]
    },
    "geo" : { },
    "id_str" : "255154066546630656",
    "text" : "wrapped up that embeddable key\/value store into a sub command: https:\/\/t.co\/vVsZxiZD \/cc @qrush",
    "id" : 255154066546630656,
    "created_at" : "2012-10-08 03:54:04 +0000",
    "user" : {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "protected" : false,
      "id_str" : "8898642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497932410890510337\/i-8d5ayf_normal.jpeg",
      "id" : 8898642,
      "verified" : false
    }
  },
  "id" : 255177777081376768,
  "created_at" : "2012-10-08 05:28:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 112, 115 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/eW7J4d9B",
      "expanded_url" : "http:\/\/zannaland.com\/inside-the-siemens-vip-lounge-in-epcots-spaceship-earth\/",
      "display_url" : "zannaland.com\/inside-the-sie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255134484767318018",
  "text" : "Apparently there's VIP lounges in every Epcot pavilion!? Maybe for #magicruby 2013? :P http:\/\/t.co\/eW7J4d9B \/cc @jm",
  "id" : 255134484767318018,
  "created_at" : "2012-10-08 02:36:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Miller",
      "screen_name" : "theediguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14122207",
      "id" : 14122207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255033322625982465",
  "geo" : { },
  "id_str" : "255102902778073088",
  "in_reply_to_user_id" : 14122207,
  "text" : "@theediguy yeah, it's a constant for us. have opted out 100% of the time i've flown since the machines went in. &gt;:[",
  "id" : 255102902778073088,
  "in_reply_to_status_id" : 255033322625982465,
  "created_at" : "2012-10-08 00:30:46 +0000",
  "in_reply_to_screen_name" : "theediguy",
  "in_reply_to_user_id_str" : "14122207",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255094286905913344",
  "geo" : { },
  "id_str" : "255099871294541824",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg this has been a requested feature for a while, but nearly everything is on hold due to stability issues :(",
  "id" : 255099871294541824,
  "in_reply_to_status_id" : 255094286905913344,
  "created_at" : "2012-10-08 00:18:43 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255079086442041345",
  "geo" : { },
  "id_str" : "255099773961519104",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub Japan pavilion at World Showcase.",
  "id" : 255099773961519104,
  "in_reply_to_status_id" : 255079086442041345,
  "created_at" : "2012-10-08 00:18:20 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255072218218905600",
  "geo" : { },
  "id_str" : "255073279998570496",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents FOR WHOM THE TEST FAILS",
  "id" : 255073279998570496,
  "in_reply_to_status_id" : 255072218218905600,
  "created_at" : "2012-10-07 22:33:03 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Capote",
      "screen_name" : "capotej",
      "indices" : [ 0, 8 ],
      "id_str" : "8898642",
      "id" : 8898642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/GbHwaTnx",
      "expanded_url" : "http:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "in_reply_to_status_id_str" : "254998144968962048",
  "geo" : { },
  "id_str" : "255024043059724288",
  "in_reply_to_user_id" : 8898642,
  "text" : "@capotej awesome! this should be a sub. http:\/\/t.co\/GbHwaTnx possibly more lines of code but would be awesome :)",
  "id" : 255024043059724288,
  "in_reply_to_status_id" : 254998144968962048,
  "created_at" : "2012-10-07 19:17:24 +0000",
  "in_reply_to_screen_name" : "capotej",
  "in_reply_to_user_id_str" : "8898642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 70, 80 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255010953677123584",
  "text" : "Free massage courtesy of Orlando International! A TSA agent chastised @aquaranto saying we probably don\u2019t use cell phones or laptops either.",
  "id" : 255010953677123584,
  "created_at" : "2012-10-07 18:25:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254926933635235840",
  "geo" : { },
  "id_str" : "255005372320985089",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit is this a B&amp;B place?! If not, I should be.",
  "id" : 255005372320985089,
  "in_reply_to_status_id" : 254926933635235840,
  "created_at" : "2012-10-07 18:03:13 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Patten",
      "screen_name" : "ChrisVanPatten",
      "indices" : [ 0, 15 ],
      "id_str" : "72883",
      "id" : 72883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254974924211490816",
  "geo" : { },
  "id_str" : "254985502720139264",
  "in_reply_to_user_id" : 72883,
  "text" : "@ChrisVanPatten you\u2019re really resisting the dark side here",
  "id" : 254985502720139264,
  "in_reply_to_status_id" : 254974924211490816,
  "created_at" : "2012-10-07 16:44:15 +0000",
  "in_reply_to_screen_name" : "ChrisVanPatten",
  "in_reply_to_user_id_str" : "72883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 13, 20 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/254974156616114177\/photo\/1",
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/wrdPv7w6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4nZpQBCIAAenTT.jpg",
      "id_str" : "254974156620308480",
      "id" : 254974156620308480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4nZpQBCIAAenTT.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/wrdPv7w6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254974156616114177",
  "text" : "Hey, I found @tekkub ? http:\/\/t.co\/wrdPv7w6",
  "id" : 254974156616114177,
  "created_at" : "2012-10-07 15:59:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254946497232252928",
  "text" : "Pretty sure I spotted a neckbeard animatronic character in Spaceship Earth.",
  "id" : 254946497232252928,
  "created_at" : "2012-10-07 14:09:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Diago",
      "screen_name" : "josefdiago",
      "indices" : [ 0, 11 ],
      "id_str" : "251839105",
      "id" : 251839105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254904843402088449",
  "geo" : { },
  "id_str" : "254907958545240064",
  "in_reply_to_user_id" : 251839105,
  "text" : "@josefdiago we\u2019re only around for the morning\u2026sorry :(",
  "id" : 254907958545240064,
  "in_reply_to_status_id" : 254904843402088449,
  "created_at" : "2012-10-07 11:36:07 +0000",
  "in_reply_to_screen_name" : "josefdiago",
  "in_reply_to_user_id_str" : "251839105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254904204731219969",
  "text" : "I wake up at 7 for two things: flights, and Epcot.",
  "id" : 254904204731219969,
  "created_at" : "2012-10-07 11:21:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254779919098318848",
  "geo" : { },
  "id_str" : "254787811226554368",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k being caremad about this won\u2019t help. Educate, lead by example.",
  "id" : 254787811226554368,
  "in_reply_to_status_id" : 254779919098318848,
  "created_at" : "2012-10-07 03:38:42 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Storimer",
      "screen_name" : "jstorimer",
      "indices" : [ 3, 13 ],
      "id_str" : "22868382",
      "id" : 22868382
    }, {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 83, 86 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MagicRuby",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254755375037956096",
  "text" : "RT @jstorimer: Totally exhausted from a great couple of days at #MagicRuby. Thanks @jm and co for putting it together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy McAnally",
        "screen_name" : "jm",
        "indices" : [ 68, 71 ],
        "id_str" : "937561",
        "id" : 937561
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MagicRuby",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254749159322697728",
    "text" : "Totally exhausted from a great couple of days at #MagicRuby. Thanks @jm and co for putting it together.",
    "id" : 254749159322697728,
    "created_at" : "2012-10-07 01:05:07 +0000",
    "user" : {
      "name" : "Jesse Storimer",
      "screen_name" : "jstorimer",
      "protected" : false,
      "id_str" : "22868382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540771289460273152\/yF8_mSGm_normal.jpeg",
      "id" : 22868382,
      "verified" : false
    }
  },
  "id" : 254755375037956096,
  "created_at" : "2012-10-07 01:29:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254755252471992320",
  "text" : "Disney Gangham style dance off with characters. Did they keep the screaming at butts?",
  "id" : 254755252471992320,
  "created_at" : "2012-10-07 01:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254744440499994624",
  "geo" : { },
  "id_str" : "254745604008316929",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan headed to Epcot tomorrow morning\u2026 flight tomorrow afternoon.",
  "id" : 254745604008316929,
  "in_reply_to_status_id" : 254744440499994624,
  "created_at" : "2012-10-07 00:50:59 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Williams",
      "screen_name" : "Sarah70007",
      "indices" : [ 0, 11 ],
      "id_str" : "6736462",
      "id" : 6736462
    }, {
      "name" : "Chris Williams",
      "screen_name" : "cdwillie76",
      "indices" : [ 12, 23 ],
      "id_str" : "6680972",
      "id" : 6680972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254730240658657280",
  "geo" : { },
  "id_str" : "254732627498631168",
  "in_reply_to_user_id" : 6736462,
  "text" : "@Sarah70007 @cdwillie76 ok! Out now.",
  "id" : 254732627498631168,
  "in_reply_to_status_id" : 254730240658657280,
  "created_at" : "2012-10-06 23:59:25 +0000",
  "in_reply_to_screen_name" : "Sarah70007",
  "in_reply_to_user_id_str" : "6736462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    }, {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 6, 17 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254727225583210500",
  "geo" : { },
  "id_str" : "254728503763820544",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k @jnunemaker comparing chest hairiness?",
  "id" : 254728503763820544,
  "in_reply_to_status_id" : 254727225583210500,
  "created_at" : "2012-10-06 23:43:02 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "cdwillie76",
      "indices" : [ 0, 11 ],
      "id_str" : "6680972",
      "id" : 6680972
    }, {
      "name" : "Sarah Williams",
      "screen_name" : "Sarah70007",
      "indices" : [ 12, 23 ],
      "id_str" : "6736462",
      "id" : 6736462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254725318928109569",
  "geo" : { },
  "id_str" : "254728313216593921",
  "in_reply_to_user_id" : 6680972,
  "text" : "@cdwillie76 @Sarah70007 yes! In line for haunted mansion. Hungry.",
  "id" : 254728313216593921,
  "in_reply_to_status_id" : 254725318928109569,
  "created_at" : "2012-10-06 23:42:17 +0000",
  "in_reply_to_screen_name" : "cdwillie76",
  "in_reply_to_user_id_str" : "6680972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254715897661501440",
  "text" : "Wedding party just boarded the \uD83D\uDE9D. Can\u2019t make this up.",
  "id" : 254715897661501440,
  "created_at" : "2012-10-06 22:52:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Lanotte",
      "screen_name" : "glanotte",
      "indices" : [ 3, 12 ],
      "id_str" : "14800547",
      "id" : 14800547
    }, {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 33, 36 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254715755151646720",
  "text" : "RT @glanotte: A big thank you to @jm and all sponsors, attendees and speakers for a fun, well done and informative #magicruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy McAnally",
        "screen_name" : "jm",
        "indices" : [ 19, 22 ],
        "id_str" : "937561",
        "id" : 937561
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "magicruby",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254707462580604928",
    "text" : "A big thank you to @jm and all sponsors, attendees and speakers for a fun, well done and informative #magicruby",
    "id" : 254707462580604928,
    "created_at" : "2012-10-06 22:19:25 +0000",
    "user" : {
      "name" : "Geoff Lanotte",
      "screen_name" : "glanotte",
      "protected" : false,
      "id_str" : "14800547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468208205521092608\/ge_GZulc_normal.jpeg",
      "id" : 14800547,
      "verified" : false
    }
  },
  "id" : 254715755151646720,
  "created_at" : "2012-10-06 22:52:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 0, 13 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Chris Williams",
      "screen_name" : "cdwillie76",
      "indices" : [ 14, 25 ],
      "id_str" : "6680972",
      "id" : 6680972
    }, {
      "name" : "Sarah Williams",
      "screen_name" : "Sarah70007",
      "indices" : [ 26, 37 ],
      "id_str" : "6736462",
      "id" : 6736462
    }, {
      "name" : "Aimee Booth",
      "screen_name" : "AimeeBooth",
      "indices" : [ 38, 49 ],
      "id_str" : "971164316",
      "id" : 971164316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254711169351307264",
  "geo" : { },
  "id_str" : "254713832465899521",
  "in_reply_to_user_id" : 17035875,
  "text" : "@olivierlacan @cdwillie76 @Sarah70007 @aimeebooth not raining at all over here! Seriously!",
  "id" : 254713832465899521,
  "in_reply_to_status_id" : 254711169351307264,
  "created_at" : "2012-10-06 22:44:44 +0000",
  "in_reply_to_screen_name" : "olivierlacan",
  "in_reply_to_user_id_str" : "17035875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254695023570993152",
  "text" : "Hey #magicruby, going to Magic Kingdom after Indiana Jones! Meet outside of the event? We can drive 3 over.",
  "id" : 254695023570993152,
  "created_at" : "2012-10-06 21:30:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "cdwillie76",
      "indices" : [ 0, 11 ],
      "id_str" : "6680972",
      "id" : 6680972
    }, {
      "name" : "Olivier Lacan",
      "screen_name" : "olivierlacan",
      "indices" : [ 12, 25 ],
      "id_str" : "17035875",
      "id" : 17035875
    }, {
      "name" : "Sarah Williams",
      "screen_name" : "Sarah70007",
      "indices" : [ 26, 37 ],
      "id_str" : "6736462",
      "id" : 6736462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254690297953546240",
  "geo" : { },
  "id_str" : "254690482154778625",
  "in_reply_to_user_id" : 6680972,
  "text" : "@cdwillie76 @olivierlacan @Sarah70007 ok! At Indiana Jones.",
  "id" : 254690482154778625,
  "in_reply_to_status_id" : 254690297953546240,
  "created_at" : "2012-10-06 21:11:57 +0000",
  "in_reply_to_screen_name" : "cdwillie76",
  "in_reply_to_user_id_str" : "6680972",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coderjoe",
      "screen_name" : "coderjoe",
      "indices" : [ 0, 9 ],
      "id_str" : "15494948",
      "id" : 15494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254686367014060033",
  "geo" : { },
  "id_str" : "254689193626849280",
  "in_reply_to_user_id" : 15494948,
  "text" : "@coderjoe !!FUN!!",
  "id" : 254689193626849280,
  "in_reply_to_status_id" : 254686367014060033,
  "created_at" : "2012-10-06 21:06:50 +0000",
  "in_reply_to_screen_name" : "coderjoe",
  "in_reply_to_user_id_str" : "15494948",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/254669109999071232\/photo\/1",
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Jig3f6ez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4jENM0CcAAE8XD.jpg",
      "id_str" : "254669110003265536",
      "id" : 254669110003265536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4jENM0CcAAE8XD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Jig3f6ez"
    } ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254669109999071232",
  "text" : "\uD83D\uDE9D Basically, #magicruby! http:\/\/t.co\/Jig3f6ez",
  "id" : 254669109999071232,
  "created_at" : "2012-10-06 19:47:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254658033282584576",
  "geo" : { },
  "id_str" : "254666624425144320",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin haha, I heard. Glad to meet you! Hitting Magic Kingdom if you\u2019re up for it.",
  "id" : 254666624425144320,
  "in_reply_to_status_id" : 254658033282584576,
  "created_at" : "2012-10-06 19:37:09 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254617698103881729",
  "geo" : { },
  "id_str" : "254631937946296320",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm haha just trolling :)",
  "id" : 254631937946296320,
  "in_reply_to_status_id" : 254617698103881729,
  "created_at" : "2012-10-06 17:19:19 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254615950429659136",
  "text" : "Wondering how nervous the Disney staff is of guests wandering into #magicruby and seeing the content\/images on some slides. Magical! \u2728",
  "id" : 254615950429659136,
  "created_at" : "2012-10-06 16:15:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Van Cleef",
      "screen_name" : "joshvc",
      "indices" : [ 0, 7 ],
      "id_str" : "15422369",
      "id" : 15422369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254613758121504769",
  "geo" : { },
  "id_str" : "254614828247814145",
  "in_reply_to_user_id" : 15422369,
  "text" : "@joshvc sweet !",
  "id" : 254614828247814145,
  "in_reply_to_status_id" : 254613758121504769,
  "created_at" : "2012-10-06 16:11:20 +0000",
  "in_reply_to_screen_name" : "joshvc",
  "in_reply_to_user_id_str" : "15422369",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254599134118572032",
  "text" : "Going to hit the crazy cars\/explosion show behind the Conf at 1:20PM! #magicruby",
  "id" : 254599134118572032,
  "created_at" : "2012-10-06 15:08:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Jimeno",
      "screen_name" : "pablojimeno",
      "indices" : [ 3, 15 ],
      "id_str" : "73153128",
      "id" : 73153128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/0y7Q8Xwx",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254554330684850176",
  "text" : "RT @pablojimeno: Reading about a simple yet awesome tool. Automating with convention, Introducing sub\nhttp:\/\/t.co\/0y7Q8Xwx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/0y7Q8Xwx",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
        "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "254497779970355200",
    "text" : "Reading about a simple yet awesome tool. Automating with convention, Introducing sub\nhttp:\/\/t.co\/0y7Q8Xwx",
    "id" : 254497779970355200,
    "created_at" : "2012-10-06 08:26:13 +0000",
    "user" : {
      "name" : "Pablo Jimeno",
      "screen_name" : "pablojimeno",
      "protected" : false,
      "id_str" : "73153128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465560323131326464\/RGAb2KgP_normal.jpeg",
      "id" : 73153128,
      "verified" : false
    }
  },
  "id" : 254554330684850176,
  "created_at" : "2012-10-06 12:10:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streeting",
      "screen_name" : "stevestreeting",
      "indices" : [ 14, 29 ],
      "id_str" : "138065190",
      "id" : 138065190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/6OpksWtG",
      "expanded_url" : "http:\/\/flpbd.it\/I0Kox",
      "display_url" : "flpbd.it\/I0Kox"
    } ]
  },
  "geo" : { },
  "id_str" : "254553198726098944",
  "text" : "Really neat: \u201C@stevestreeting: Disney crafts 3D printed optics http:\/\/t.co\/6OpksWtG\u201D",
  "id" : 254553198726098944,
  "created_at" : "2012-10-06 12:06:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 0, 8 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254448247559553024",
  "geo" : { },
  "id_str" : "254449761048993793",
  "in_reply_to_user_id" : 3382151,
  "text" : "@dmosher this\u2026might be my first kick starter.",
  "id" : 254449761048993793,
  "in_reply_to_status_id" : 254448247559553024,
  "created_at" : "2012-10-06 05:15:25 +0000",
  "in_reply_to_screen_name" : "dmosher",
  "in_reply_to_user_id_str" : "3382151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "indices" : [ 3, 11 ],
      "id_str" : "3382151",
      "id" : 3382151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/BCe4gd1c",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/trammel\/the-official-settlers-of-catan-gaming-board",
      "display_url" : "kickstarter.com\/projects\/tramm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254449684960145408",
  "text" : "RT @dmosher: If you are a Settlers of Catan fan you _have_ to check out this Kickstarter: http:\/\/t.co\/BCe4gd1c #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/BCe4gd1c",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/trammel\/the-official-settlers-of-catan-gaming-board",
        "display_url" : "kickstarter.com\/projects\/tramm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "254448247559553024",
    "text" : "If you are a Settlers of Catan fan you _have_ to check out this Kickstarter: http:\/\/t.co\/BCe4gd1c #fb",
    "id" : 254448247559553024,
    "created_at" : "2012-10-06 05:09:24 +0000",
    "user" : {
      "name" : "Dave Mosher",
      "screen_name" : "dmosher",
      "protected" : false,
      "id_str" : "3382151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494583437466943489\/m3yZB77Y_normal.png",
      "id" : 3382151,
      "verified" : false
    }
  },
  "id" : 254449684960145408,
  "created_at" : "2012-10-06 05:15:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 0, 10 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/gyFHzYiu",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xMOcyCLZHBQ",
      "display_url" : "youtube.com\/watch?v=xMOcyC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "254440827445706753",
  "geo" : { },
  "id_str" : "254441433883365377",
  "in_reply_to_user_id" : 23830105,
  "text" : "@joedamato http:\/\/t.co\/gyFHzYiu",
  "id" : 254441433883365377,
  "in_reply_to_status_id" : 254440827445706753,
  "created_at" : "2012-10-06 04:42:19 +0000",
  "in_reply_to_screen_name" : "joedamato",
  "in_reply_to_user_id_str" : "23830105",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/254420092106993664\/photo\/1",
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/ubfYocT7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4fhuc4CcAAxc8C.png",
      "id_str" : "254420092111187968",
      "id" : 254420092111187968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4fhuc4CcAAxc8C.png",
      "sizes" : [ {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 1394
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ubfYocT7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254420092106993664",
  "text" : "Unrelated: I FINALLY BEAT FTL (on easy). WOO! http:\/\/t.co\/ubfYocT7",
  "id" : 254420092106993664,
  "created_at" : "2012-10-06 03:17:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254369336653914112",
  "geo" : { },
  "id_str" : "254419907050078208",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss been lucky to have visited Disney quite a few times when growing up, always in the summer. This is a treat :)",
  "id" : 254419907050078208,
  "in_reply_to_status_id" : 254369336653914112,
  "created_at" : "2012-10-06 03:16:47 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Brown",
      "screen_name" : "BrownWebDesign",
      "indices" : [ 0, 15 ],
      "id_str" : "18452956",
      "id" : 18452956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254392590047272960",
  "geo" : { },
  "id_str" : "254419749675601920",
  "in_reply_to_user_id" : 18452956,
  "text" : "@BrownWebDesign thanks man!",
  "id" : 254419749675601920,
  "in_reply_to_status_id" : 254392590047272960,
  "created_at" : "2012-10-06 03:16:09 +0000",
  "in_reply_to_screen_name" : "BrownWebDesign",
  "in_reply_to_user_id_str" : "18452956",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 3, 11 ],
      "id_str" : "425253989",
      "id" : 425253989
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 46, 56 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/embrown\/status\/254320563848355840\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/05fYZuD9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4eHNJPCIAA-i8b.jpg",
      "id_str" : "254320563856744448",
      "id" : 254320563856744448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4eHNJPCIAA-i8b.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      } ],
      "display_url" : "pic.twitter.com\/05fYZuD9"
    } ],
    "hashtags" : [ {
      "text" : "MagicRuby",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254330280003895296",
  "text" : "RT @embrown: Staying afloat at #MagicRuby. cc:@aquaranto http:\/\/t.co\/05fYZuD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 33, 43 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/embrown\/status\/254320563848355840\/photo\/1",
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/05fYZuD9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4eHNJPCIAA-i8b.jpg",
        "id_str" : "254320563856744448",
        "id" : 254320563856744448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4eHNJPCIAA-i8b.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        } ],
        "display_url" : "pic.twitter.com\/05fYZuD9"
      } ],
      "hashtags" : [ {
        "text" : "MagicRuby",
        "indices" : [ 18, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254320563848355840",
    "text" : "Staying afloat at #MagicRuby. cc:@aquaranto http:\/\/t.co\/05fYZuD9",
    "id" : 254320563848355840,
    "created_at" : "2012-10-05 20:42:02 +0000",
    "user" : {
      "name" : "Erin",
      "screen_name" : "embrown",
      "protected" : false,
      "id_str" : "425253989",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_6_normal.png",
      "id" : 425253989,
      "verified" : false
    }
  },
  "id" : 254330280003895296,
  "created_at" : "2012-10-05 21:20:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254329204752146432",
  "text" : "Hitting up some rides the rest of the day at Hollywood Studios. Hit me up if you\u2019d like to join our troop! #magicruby",
  "id" : 254329204752146432,
  "created_at" : "2012-10-05 21:16:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254317316970536960",
  "text" : "Holy crap, it really rains in Florida.",
  "id" : 254317316970536960,
  "created_at" : "2012-10-05 20:29:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 15, 25 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254306494475034624",
  "text" : "Super proud of @aquaranto for her first conf talk at #magicruby ! Seriously best development community out there.",
  "id" : 254306494475034624,
  "created_at" : "2012-10-05 19:46:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "embrown",
      "indices" : [ 3, 11 ],
      "id_str" : "425253989",
      "id" : 425253989
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 29, 39 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MagicRuby",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254306171521998848",
  "text" : "RT @embrown: Awesome talk by @aquaranto on Lean Development! #MagicRuby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 16, 26 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MagicRuby",
        "indices" : [ 48, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254300492732194817",
    "text" : "Awesome talk by @aquaranto on Lean Development! #MagicRuby",
    "id" : 254300492732194817,
    "created_at" : "2012-10-05 19:22:16 +0000",
    "user" : {
      "name" : "Erin",
      "screen_name" : "embrown",
      "protected" : false,
      "id_str" : "425253989",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_6_normal.png",
      "id" : 425253989,
      "verified" : false
    }
  },
  "id" : 254306171521998848,
  "created_at" : "2012-10-05 19:44:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254234732383072257",
  "geo" : { },
  "id_str" : "254240990443999233",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon Internets are bad here, but I can hook you up!",
  "id" : 254240990443999233,
  "in_reply_to_status_id" : 254234732383072257,
  "created_at" : "2012-10-05 15:25:50 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 8, 22 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/254231869992873985\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/LdrRI5BY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4c2ie4CMAAIugj.jpg",
      "id_str" : "254231870001262592",
      "id" : 254231870001262592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4c2ie4CMAAIugj.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LdrRI5BY"
    } ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254231869992873985",
  "text" : "Getting @coworkbuffalo stickers on laptops from everywhere. Want one? Find me at #magicruby ! http:\/\/t.co\/LdrRI5BY",
  "id" : 254231869992873985,
  "created_at" : "2012-10-05 14:49:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    }, {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 12, 28 ],
      "id_str" : "529540581",
      "id" : 529540581
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 29, 38 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253641534484922368",
  "geo" : { },
  "id_str" : "254193869904822272",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon @rubygems_status @rubygems I keep forgetting about it\u2026please!!",
  "id" : 254193869904822272,
  "in_reply_to_status_id" : 253641534484922368,
  "created_at" : "2012-10-05 12:18:35 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex D'Andrea",
      "screen_name" : "alexkiesel",
      "indices" : [ 3, 14 ],
      "id_str" : "43917218",
      "id" : 43917218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 94 ],
      "url" : "https:\/\/t.co\/kJU4VUXw",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "254190816384409600",
  "text" : "RT @alexkiesel: When I write a shell script again, I'll give this a try: https:\/\/t.co\/kJU4VUXw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 78 ],
        "url" : "https:\/\/t.co\/kJU4VUXw",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "254171950379835392",
    "text" : "When I write a shell script again, I'll give this a try: https:\/\/t.co\/kJU4VUXw",
    "id" : 254171950379835392,
    "created_at" : "2012-10-05 10:51:29 +0000",
    "user" : {
      "name" : "Alex D'Andrea",
      "screen_name" : "alexkiesel",
      "protected" : false,
      "id_str" : "43917218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1142322240\/DSC04173-crop_normal.JPG",
      "id" : 43917218,
      "verified" : false
    }
  },
  "id" : 254190816384409600,
  "created_at" : "2012-10-05 12:06:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Stack",
      "screen_name" : "richardkstack",
      "indices" : [ 0, 14 ],
      "id_str" : "26840419",
      "id" : 26840419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253990447142285313",
  "geo" : { },
  "id_str" : "254007690307706880",
  "in_reply_to_user_id" : 26840419,
  "text" : "@richardkstack or go to mountain west ruby Conf!",
  "id" : 254007690307706880,
  "in_reply_to_status_id" : 253990447142285313,
  "created_at" : "2012-10-04 23:58:47 +0000",
  "in_reply_to_screen_name" : "richardkstack",
  "in_reply_to_user_id_str" : "26840419",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253990580638605312",
  "text" : "There\u2019s a monorail emoji. \uD83D\uDE9D #magicruby",
  "id" : 253990580638605312,
  "created_at" : "2012-10-04 22:50:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "magicruby",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253978949917483008",
  "text" : "Woo, finally made it to Disney for #magicruby!",
  "id" : 253978949917483008,
  "created_at" : "2012-10-04 22:04:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Anand",
      "screen_name" : "_arjuna",
      "indices" : [ 0, 8 ],
      "id_str" : "175490389",
      "id" : 175490389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253913000631734272",
  "geo" : { },
  "id_str" : "253952885627437057",
  "in_reply_to_user_id" : 175490389,
  "text" : "@_arjuna headed to MagicRuby\u2026sorry!",
  "id" : 253952885627437057,
  "in_reply_to_status_id" : 253913000631734272,
  "created_at" : "2012-10-04 20:21:00 +0000",
  "in_reply_to_screen_name" : "_arjuna",
  "in_reply_to_user_id_str" : "175490389",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253909021009006592",
  "text" : "Fire truck already put it out. Maybe it\u2019s a drill?",
  "id" : 253909021009006592,
  "created_at" : "2012-10-04 17:26:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/253908855266893825\/photo\/1",
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/c01wMFyn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4YQwjQCYAAetsM.jpg",
      "id_str" : "253908855275282432",
      "id" : 253908855275282432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4YQwjQCYAAetsM.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c01wMFyn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253908855266893825",
  "text" : "Just a fire visible from our aircraft at JFK. WTF?! http:\/\/t.co\/c01wMFyn",
  "id" : 253908855266893825,
  "created_at" : "2012-10-04 17:26:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Soffes",
      "screen_name" : "samsoffes",
      "indices" : [ 0, 10 ],
      "id_str" : "870450487",
      "id" : 870450487
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 11, 23 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253898040275001344",
  "geo" : { },
  "id_str" : "253906269507821568",
  "in_reply_to_user_id" : 6154602,
  "text" : "@samsoffes @sstephenson no, Sam definitely wrote most of it. I extracted it, wrote up docs, made it work for anyone.",
  "id" : 253906269507821568,
  "in_reply_to_status_id" : 253898040275001344,
  "created_at" : "2012-10-04 17:15:46 +0000",
  "in_reply_to_screen_name" : "soffes",
  "in_reply_to_user_id_str" : "6154602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Griffiths",
      "screen_name" : "johnantoni",
      "indices" : [ 3, 14 ],
      "id_str" : "755346",
      "id" : 755346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/arLlKi0T",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "253897426069516288",
  "text" : "RT @johnantoni: creating my own sub https:\/\/t.co\/arLlKi0T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 41 ],
        "url" : "https:\/\/t.co\/arLlKi0T",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "253895006266462209",
    "text" : "creating my own sub https:\/\/t.co\/arLlKi0T",
    "id" : 253895006266462209,
    "created_at" : "2012-10-04 16:31:01 +0000",
    "user" : {
      "name" : "John Griffiths",
      "screen_name" : "johnantoni",
      "protected" : false,
      "id_str" : "755346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553303973004730368\/kOGFPmW__normal.png",
      "id" : 755346,
      "verified" : false
    }
  },
  "id" : 253897426069516288,
  "created_at" : "2012-10-04 16:40:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253874257996697601",
  "text" : "RT @nexxylove: WELCOME TO THE AIRPORT. RADIATION OR MOLESTATION, YOUR CHOICE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253872355338752000",
    "text" : "WELCOME TO THE AIRPORT. RADIATION OR MOLESTATION, YOUR CHOICE!",
    "id" : 253872355338752000,
    "created_at" : "2012-10-04 15:01:00 +0000",
    "user" : {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571613144133296128\/-EmxBenM_normal.jpeg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 253874257996697601,
  "created_at" : "2012-10-04 15:08:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tammer Saleh",
      "screen_name" : "tsaleh",
      "indices" : [ 0, 7 ],
      "id_str" : "3286561",
      "id" : 3286561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253864874516545536",
  "geo" : { },
  "id_str" : "253865845086883840",
  "in_reply_to_user_id" : 3286561,
  "text" : "@tsaleh I will confirm this later.",
  "id" : 253865845086883840,
  "in_reply_to_status_id" : 253864874516545536,
  "created_at" : "2012-10-04 14:35:08 +0000",
  "in_reply_to_screen_name" : "tsaleh",
  "in_reply_to_user_id_str" : "3286561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253864712834543616",
  "text" : "Yay she\u2019s back!",
  "id" : 253864712834543616,
  "created_at" : "2012-10-04 14:30:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 13, 23 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253864510832648194",
  "text" : "The TSA took @aquaranto somewhere and didn\u2019t tell me. Not happy about this.",
  "id" : 253864510832648194,
  "created_at" : "2012-10-04 14:29:50 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Clay Shafer",
      "screen_name" : "littleidea",
      "indices" : [ 0, 11 ],
      "id_str" : "14079705",
      "id" : 14079705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253837718340108288",
  "geo" : { },
  "id_str" : "253857204266995713",
  "in_reply_to_user_id" : 14079705,
  "text" : "@littleidea dammit Loch Ness monster, get off my lawn!",
  "id" : 253857204266995713,
  "in_reply_to_status_id" : 253837718340108288,
  "created_at" : "2012-10-04 14:00:48 +0000",
  "in_reply_to_screen_name" : "littleidea",
  "in_reply_to_user_id_str" : "14079705",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253843437680476160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.9288235959, -78.732108241 ]
  },
  "id_str" : "253856876524101633",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden gitready\u2019s code is under MIT, content under CC.",
  "id" : 253856876524101633,
  "in_reply_to_status_id" : 253843437680476160,
  "created_at" : "2012-10-04 13:59:30 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ami  Mahloof",
      "screen_name" : "RailsRaider",
      "indices" : [ 0, 12 ],
      "id_str" : "15393907",
      "id" : 15393907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253633624476372993",
  "geo" : { },
  "id_str" : "253686707084464128",
  "in_reply_to_user_id" : 15393907,
  "text" : "@RailsRaider Thanks!",
  "id" : 253686707084464128,
  "in_reply_to_status_id" : 253633624476372993,
  "created_at" : "2012-10-04 02:43:18 +0000",
  "in_reply_to_screen_name" : "RailsRaider",
  "in_reply_to_user_id_str" : "15393907",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ami  Mahloof",
      "screen_name" : "RailsRaider",
      "indices" : [ 3, 15 ],
      "id_str" : "15393907",
      "id" : 15393907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sub",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qvlZ5nd4",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "253686684812722176",
  "text" : "RT @RailsRaider: I love #sub from 37signals simple elegant &amp; effective way to bunch all your scripts into one command https:\/\/t.co\/q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sub",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 126 ],
        "url" : "https:\/\/t.co\/qvlZ5nd4",
        "expanded_url" : "https:\/\/github.com\/37signals\/sub",
        "display_url" : "github.com\/37signals\/sub"
      } ]
    },
    "geo" : { },
    "id_str" : "253633624476372993",
    "text" : "I love #sub from 37signals simple elegant &amp; effective way to bunch all your scripts into one command https:\/\/t.co\/qvlZ5nd4\n\nBeautiful!",
    "id" : 253633624476372993,
    "created_at" : "2012-10-03 23:12:23 +0000",
    "user" : {
      "name" : "Ami  Mahloof",
      "screen_name" : "RailsRaider",
      "protected" : false,
      "id_str" : "15393907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487632220996124672\/uZ98kUWj_normal.jpeg",
      "id" : 15393907,
      "verified" : false
    }
  },
  "id" : 253686684812722176,
  "created_at" : "2012-10-04 02:43:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duncan Davidson",
      "screen_name" : "duncan",
      "indices" : [ 3, 10 ],
      "id_str" : "823098",
      "id" : 823098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253685267171520514",
  "text" : "RT @duncan: The real loser in this debate is us. All of us. Sigh. Wish I'd skipped it and put that time into making something.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253682060114419712",
    "text" : "The real loser in this debate is us. All of us. Sigh. Wish I'd skipped it and put that time into making something.",
    "id" : 253682060114419712,
    "created_at" : "2012-10-04 02:24:50 +0000",
    "user" : {
      "name" : "Duncan Davidson",
      "screen_name" : "duncan",
      "protected" : false,
      "id_str" : "823098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630897965\/6aaefdb63045ad9ac50e1bb02f606640_normal.jpeg",
      "id" : 823098,
      "verified" : false
    }
  },
  "id" : 253685267171520514,
  "created_at" : "2012-10-04 02:37:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 3, 14 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tenderlove\/status\/253643778500481024\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/SBMcdEb1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4UfrDVCUAA0YwB.png",
      "id_str" : "253643778504675328",
      "id" : 253643778504675328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4UfrDVCUAA0YwB.png",
      "sizes" : [ {
        "h" : 317,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 643
      } ],
      "display_url" : "pic.twitter.com\/SBMcdEb1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253643845403803648",
  "text" : "RT @tenderlove: I think this might be about tents. http:\/\/t.co\/SBMcdEb1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tenderlove\/status\/253643778500481024\/photo\/1",
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/SBMcdEb1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4UfrDVCUAA0YwB.png",
        "id_str" : "253643778504675328",
        "id" : 253643778504675328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4UfrDVCUAA0YwB.png",
        "sizes" : [ {
          "h" : 317,
          "resize" : "fit",
          "w" : 643
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 317,
          "resize" : "fit",
          "w" : 643
        } ],
        "display_url" : "pic.twitter.com\/SBMcdEb1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253643778500481024",
    "text" : "I think this might be about tents. http:\/\/t.co\/SBMcdEb1",
    "id" : 253643778500481024,
    "created_at" : "2012-10-03 23:52:44 +0000",
    "user" : {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "protected" : false,
      "id_str" : "14761655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325798111\/ca48276f8ebbbbac9c6ce83aac3c8548_normal.jpeg",
      "id" : 14761655,
      "verified" : false
    }
  },
  "id" : 253643845403803648,
  "created_at" : "2012-10-03 23:52:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "indices" : [ 3, 15 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "The Ruby Hangout",
      "screen_name" : "RubyHangout",
      "indices" : [ 30, 42 ],
      "id_str" : "788178800",
      "id" : 788178800
    }, {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 48, 59 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 64, 71 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/PNSCLpoN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qPNPovbvdGE&feature=g-all-lss&ytsession=X8Ybv8InKqBbLsnQPA1S8T9ve2LoiVCJzNfhj4LBQsA257X61TJIujKiEVS4app3sWclZ08yF7BR3BejUhi0er823ZOxs1MNPblPgNk3uBD0wmfmm3v89UPEXtEYwz6dKkWph9cZCIrz12oZ0F8gfZ6kdSYlZUNEL1QzWuCLRMVpHinkHYozhnlfmYDIP73_Ef9p2ymSsPGJoY9fCNCG8zOXFYuDmkf4OX4Ubvk0JT0",
      "display_url" : "youtube.com\/watch?v=qPNPov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253639284702183426",
  "text" : "RT @coreyhaines: Watching the @RubyHangout with @chadfowler and @elight http:\/\/t.co\/PNSCLpoN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Ruby Hangout",
        "screen_name" : "RubyHangout",
        "indices" : [ 13, 25 ],
        "id_str" : "788178800",
        "id" : 788178800
      }, {
        "name" : "Chad Fowler",
        "screen_name" : "chadfowler",
        "indices" : [ 31, 42 ],
        "id_str" : "790205",
        "id" : 790205
      }, {
        "name" : "Evan Light",
        "screen_name" : "elight",
        "indices" : [ 47, 54 ],
        "id_str" : "3948061",
        "id" : 3948061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/PNSCLpoN",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qPNPovbvdGE&feature=g-all-lss&ytsession=X8Ybv8InKqBbLsnQPA1S8T9ve2LoiVCJzNfhj4LBQsA257X61TJIujKiEVS4app3sWclZ08yF7BR3BejUhi0er823ZOxs1MNPblPgNk3uBD0wmfmm3v89UPEXtEYwz6dKkWph9cZCIrz12oZ0F8gfZ6kdSYlZUNEL1QzWuCLRMVpHinkHYozhnlfmYDIP73_Ef9p2ymSsPGJoY9fCNCG8zOXFYuDmkf4OX4Ubvk0JT0",
        "display_url" : "youtube.com\/watch?v=qPNPov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253633924922761216",
    "text" : "Watching the @RubyHangout with @chadfowler and @elight http:\/\/t.co\/PNSCLpoN",
    "id" : 253633924922761216,
    "created_at" : "2012-10-03 23:13:34 +0000",
    "user" : {
      "name" : "Your Hype Man YEAH!",
      "screen_name" : "coreyhaines",
      "protected" : false,
      "id_str" : "11458102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559070931516411904\/TBA7KnoH_normal.jpeg",
      "id" : 11458102,
      "verified" : false
    }
  },
  "id" : 253639284702183426,
  "created_at" : "2012-10-03 23:34:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253631823849091072",
  "text" : "Constantly getting \"An error occurred\" on YouTube videos. Only happens on my home internet...any ideas?",
  "id" : 253631823849091072,
  "created_at" : "2012-10-03 23:05:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253630326188957696",
  "geo" : { },
  "id_str" : "253630619379200000",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler got a G+ link?",
  "id" : 253630619379200000,
  "in_reply_to_status_id" : 253630326188957696,
  "created_at" : "2012-10-03 23:00:26 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/PkxNRtNk",
      "expanded_url" : "https:\/\/gist.github.com\/3830137",
      "display_url" : "gist.github.com\/3830137"
    } ]
  },
  "geo" : { },
  "id_str" : "253625640320921601",
  "text" : "RT @rubygems_status: The post-mortem on todays outage: https:\/\/t.co\/PkxNRtNk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 55 ],
        "url" : "https:\/\/t.co\/PkxNRtNk",
        "expanded_url" : "https:\/\/gist.github.com\/3830137",
        "display_url" : "gist.github.com\/3830137"
      } ]
    },
    "geo" : { },
    "id_str" : "253617874202157056",
    "text" : "The post-mortem on todays outage: https:\/\/t.co\/PkxNRtNk",
    "id" : 253617874202157056,
    "created_at" : "2012-10-03 22:09:47 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 253625640320921601,
  "created_at" : "2012-10-03 22:40:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt culpepper",
      "screen_name" : "_mculp",
      "indices" : [ 0, 7 ],
      "id_str" : "21530821",
      "id" : 21530821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253612304560689152",
  "geo" : { },
  "id_str" : "253616268966506496",
  "in_reply_to_user_id" : 21530821,
  "text" : "@_mculp yes, we are aware.",
  "id" : 253616268966506496,
  "in_reply_to_status_id" : 253612304560689152,
  "created_at" : "2012-10-03 22:03:25 +0000",
  "in_reply_to_screen_name" : "_mculp",
  "in_reply_to_user_id_str" : "21530821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c  l  e  e  e  f",
      "screen_name" : "moonpolysoft",
      "indices" : [ 0, 13 ],
      "id_str" : "14204623",
      "id" : 14204623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253600258351837184",
  "geo" : { },
  "id_str" : "253600582546358272",
  "in_reply_to_user_id" : 14204623,
  "text" : "@moonpolysoft drolpthwizard?",
  "id" : 253600582546358272,
  "in_reply_to_status_id" : 253600258351837184,
  "created_at" : "2012-10-03 21:01:05 +0000",
  "in_reply_to_screen_name" : "moonpolysoft",
  "in_reply_to_user_id_str" : "14204623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253599872945639424",
  "text" : "RT @rubygems_status: Pulled the trigger on our new setup! Don\u2019t all hit it at once. Actually, please do!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253599761549123584",
    "text" : "Pulled the trigger on our new setup! Don\u2019t all hit it at once. Actually, please do!",
    "id" : 253599761549123584,
    "created_at" : "2012-10-03 20:57:49 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 253599872945639424,
  "created_at" : "2012-10-03 20:58:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/epO1iZQx",
      "expanded_url" : "https:\/\/twitter.com\/drnic\/status\/253570807211651074\/",
      "display_url" : "twitter.com\/drnic\/status\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253592106831081472",
  "text" : "Just blown away by this. ~600M downloads in one year!? https:\/\/t.co\/epO1iZQx",
  "id" : 253592106831081472,
  "created_at" : "2012-10-03 20:27:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbrake Bug Tracker",
      "screen_name" : "airbrake",
      "indices" : [ 0, 9 ],
      "id_str" : "298023205",
      "id" : 298023205
    }, {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 10, 16 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253572354616205312",
  "geo" : { },
  "id_str" : "253590672244879360",
  "in_reply_to_user_id" : 298023205,
  "text" : "@airbrake @drnic we disabled them for perf reasons. Hopefully they will return.",
  "id" : 253590672244879360,
  "in_reply_to_status_id" : 253572354616205312,
  "created_at" : "2012-10-03 20:21:42 +0000",
  "in_reply_to_screen_name" : "airbrake",
  "in_reply_to_user_id_str" : "298023205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "indices" : [ 3, 9 ],
      "id_str" : "9885102",
      "id" : 9885102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/drnic\/status\/253570807211651074\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VOFOuGn9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4TdTkGCcAE_5kd.jpg",
      "id_str" : "253570807215845377",
      "id" : 253570807215845377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4TdTkGCcAE_5kd.jpg",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VOFOuGn9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253590587993886720",
  "text" : "RT @drnic: In the last year, rubygems tripled the number of total downloads to 900m. Slide from my ScriptBowl talk at JavaOne. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/drnic\/status\/253570807211651074\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/VOFOuGn9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4TdTkGCcAE_5kd.jpg",
        "id_str" : "253570807215845377",
        "id" : 253570807215845377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4TdTkGCcAE_5kd.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VOFOuGn9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253570807211651074",
    "text" : "In the last year, rubygems tripled the number of total downloads to 900m. Slide from my ScriptBowl talk at JavaOne. http:\/\/t.co\/VOFOuGn9",
    "id" : 253570807211651074,
    "created_at" : "2012-10-03 19:02:46 +0000",
    "user" : {
      "name" : "Dr Nic",
      "screen_name" : "drnic",
      "protected" : false,
      "id_str" : "9885102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540867377907253249\/T8RB8AXG_normal.jpeg",
      "id" : 9885102,
      "verified" : false
    }
  },
  "id" : 253590587993886720,
  "created_at" : "2012-10-03 20:21:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Maggard",
      "screen_name" : "cmaggard",
      "indices" : [ 0, 9 ],
      "id_str" : "13643732",
      "id" : 13643732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253589925881061376",
  "geo" : { },
  "id_str" : "253590263442837504",
  "in_reply_to_user_id" : 13643732,
  "text" : "@cmaggard haha\u2026:(",
  "id" : 253590263442837504,
  "in_reply_to_status_id" : 253589925881061376,
  "created_at" : "2012-10-03 20:20:04 +0000",
  "in_reply_to_screen_name" : "cmaggard",
  "in_reply_to_user_id_str" : "13643732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "indices" : [ 3, 19 ],
      "id_str" : "529540581",
      "id" : 529540581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253589001238372352",
  "text" : "RT @rubygems_status: We\u2019re starting maintenance mode. Hold onto your butts, we\u2019re moving to a much more stable setup!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253588910863708160",
    "text" : "We\u2019re starting maintenance mode. Hold onto your butts, we\u2019re moving to a much more stable setup!",
    "id" : 253588910863708160,
    "created_at" : "2012-10-03 20:14:42 +0000",
    "user" : {
      "name" : "RubyGems Status",
      "screen_name" : "rubygems_status",
      "protected" : false,
      "id_str" : "529540581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535452674729078784\/5jL6-BA5_normal.jpeg",
      "id" : 529540581,
      "verified" : false
    }
  },
  "id" : 253589001238372352,
  "created_at" : "2012-10-03 20:15:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Weibley",
      "screen_name" : "themcgruff",
      "indices" : [ 0, 11 ],
      "id_str" : "13984262",
      "id" : 13984262
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 12, 20 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253570539757633537",
  "geo" : { },
  "id_str" : "253577275264610306",
  "in_reply_to_user_id" : 13984262,
  "text" : "@themcgruff @evanphx I would love this. Please!!",
  "id" : 253577275264610306,
  "in_reply_to_status_id" : 253570539757633537,
  "created_at" : "2012-10-03 19:28:28 +0000",
  "in_reply_to_screen_name" : "themcgruff",
  "in_reply_to_user_id_str" : "13984262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/t7WATcFT",
      "expanded_url" : "http:\/\/RubyGems.org",
      "display_url" : "RubyGems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "253564355365445632",
  "text" : "http:\/\/t.co\/t7WATcFT has a 42 load average, I have no time or knowhow of how to fix this. I can't say how sad I am about this.",
  "id" : 253564355365445632,
  "created_at" : "2012-10-03 18:37:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.89097902, -78.87571943 ]
  },
  "id_str" : "253557229805002753",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k not following me!",
  "id" : 253557229805002753,
  "created_at" : "2012-10-03 18:08:49 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 0, 11 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 12, 22 ],
      "id_str" : "5744442",
      "id" : 5744442
    }, {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 23, 36 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253539514901991424",
  "geo" : { },
  "id_str" : "253540922942435328",
  "in_reply_to_user_id" : 9510922,
  "text" : "@ashedryden @aquaranto @steveklabnik we've always talked about opening a board game store\/delicious snackery. I guess this fits in?",
  "id" : 253540922942435328,
  "in_reply_to_status_id" : 253539514901991424,
  "created_at" : "2012-10-03 17:04:01 +0000",
  "in_reply_to_screen_name" : "ashedryden",
  "in_reply_to_user_id_str" : "9510922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/W7v7SUim",
      "expanded_url" : "http:\/\/washingtondc.craigslist.org\/nva\/tlg\/3310486791.html",
      "display_url" : "washingtondc.craigslist.org\/nva\/tlg\/331048\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253537097137418240",
  "text" : "\"Dungeon Master experience in Dungeons and Dragons\" ... \"It is preferable that cup size be at least C or greater.\" http:\/\/t.co\/W7v7SUim",
  "id" : 253537097137418240,
  "created_at" : "2012-10-03 16:48:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J. McIntyre",
      "screen_name" : "_ajm",
      "indices" : [ 0, 5 ],
      "id_str" : "74257747",
      "id" : 74257747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253512668894359552",
  "geo" : { },
  "id_str" : "253512967696568320",
  "in_reply_to_user_id" : 74257747,
  "text" : "@_ajm Pathetic.",
  "id" : 253512967696568320,
  "in_reply_to_status_id" : 253512668894359552,
  "created_at" : "2012-10-03 15:12:56 +0000",
  "in_reply_to_screen_name" : "_ajm",
  "in_reply_to_user_id_str" : "74257747",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/n9Deb8Sw",
      "expanded_url" : "http:\/\/buffalo.com",
      "display_url" : "buffalo.com"
    }, {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/feyuqVjX",
      "expanded_url" : "http:\/\/buffalonews.com",
      "display_url" : "buffalonews.com"
    } ]
  },
  "geo" : { },
  "id_str" : "253511418144497665",
  "text" : "I really don't know who's in charge of design at http:\/\/t.co\/n9Deb8Sw and http:\/\/t.co\/feyuqVjX, but they deserve to be fired.",
  "id" : 253511418144497665,
  "created_at" : "2012-10-03 15:06:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Problem",
      "screen_name" : "BonzoESC",
      "indices" : [ 0, 9 ],
      "id_str" : "7865582",
      "id" : 7865582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253504278541520897",
  "geo" : { },
  "id_str" : "253510017272127488",
  "in_reply_to_user_id" : 7865582,
  "text" : "@BonzoESC Yes! (holy shit!)",
  "id" : 253510017272127488,
  "in_reply_to_status_id" : 253504278541520897,
  "created_at" : "2012-10-03 15:01:12 +0000",
  "in_reply_to_screen_name" : "BonzoESC",
  "in_reply_to_user_id_str" : "7865582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253509239602036736",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm hey, how long are the lightning talks at magicruby?",
  "id" : 253509239602036736,
  "created_at" : "2012-10-03 14:58:07 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hampton",
      "screen_name" : "hcatlin",
      "indices" : [ 0, 8 ],
      "id_str" : "12986052",
      "id" : 12986052
    }, {
      "name" : "RUBY CASTILLO",
      "screen_name" : "MAGICRUBY",
      "indices" : [ 9, 19 ],
      "id_str" : "130302604",
      "id" : 130302604
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 20, 30 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252852278384545792",
  "geo" : { },
  "id_str" : "253509168089157632",
  "in_reply_to_user_id" : 12986052,
  "text" : "@hcatlin @MAGICRUBY @aquaranto Oh man!!",
  "id" : 253509168089157632,
  "in_reply_to_status_id" : 252852278384545792,
  "created_at" : "2012-10-03 14:57:50 +0000",
  "in_reply_to_screen_name" : "hcatlin",
  "in_reply_to_user_id_str" : "12986052",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/aKXitdZA",
      "expanded_url" : "http:\/\/www.therubyhangout.com\/blog\/2012\/09\/16\/first-meetup-oct-3rd\/",
      "display_url" : "therubyhangout.com\/blog\/2012\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253502853015015424",
  "text" : "Excited to attend the first Ruby Hangout! http:\/\/t.co\/aKXitdZA",
  "id" : 253502853015015424,
  "created_at" : "2012-10-03 14:32:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Fowler",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253499768721010688",
  "geo" : { },
  "id_str" : "253501860189724672",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler Looks like the site is dying :(",
  "id" : 253501860189724672,
  "in_reply_to_status_id" : 253499768721010688,
  "created_at" : "2012-10-03 14:28:47 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253499069018804224",
  "geo" : { },
  "id_str" : "253499374200569856",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k awkward level...1000",
  "id" : 253499374200569856,
  "in_reply_to_status_id" : 253499069018804224,
  "created_at" : "2012-10-03 14:18:55 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 3, 8 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253499300540215296",
  "text" : "RT @r00k: If you tell the JetBlue agent to also have a great flight, just own it. Stare menacingly until they book a ticket.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253499069018804224",
    "text" : "If you tell the JetBlue agent to also have a great flight, just own it. Stare menacingly until they book a ticket.",
    "id" : 253499069018804224,
    "created_at" : "2012-10-03 14:17:42 +0000",
    "user" : {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "protected" : false,
      "id_str" : "11280212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511894914360434688\/TEsS1j0z_normal.jpeg",
      "id" : 11280212,
      "verified" : false
    }
  },
  "id" : 253499300540215296,
  "created_at" : "2012-10-03 14:18:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 34, 48 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253328722747346945",
  "text" : "Really happy to see photos of the @coworkbuffalo stickers...MOAR!",
  "id" : 253328722747346945,
  "created_at" : "2012-10-03 03:00:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253298682164822019",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.988511025, -78.7987823385 ]
  },
  "id_str" : "253302616233218048",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape she\u2019s huge!",
  "id" : 253302616233218048,
  "in_reply_to_status_id" : 253298682164822019,
  "created_at" : "2012-10-03 01:17:04 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 90 ],
      "url" : "https:\/\/t.co\/CT4UrFwh",
      "expanded_url" : "https:\/\/github.com\/github\/gemoji",
      "display_url" : "github.com\/github\/gemoji"
    } ]
  },
  "geo" : { },
  "id_str" : "253302085309845505",
  "text" : "RT @steveklabnik: BRB working on a PR to merge this into Rails Core: https:\/\/t.co\/CT4UrFwh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 72 ],
        "url" : "https:\/\/t.co\/CT4UrFwh",
        "expanded_url" : "https:\/\/github.com\/github\/gemoji",
        "display_url" : "github.com\/github\/gemoji"
      } ]
    },
    "geo" : { },
    "id_str" : "253300113148084224",
    "text" : "BRB working on a PR to merge this into Rails Core: https:\/\/t.co\/CT4UrFwh",
    "id" : 253300113148084224,
    "created_at" : "2012-10-03 01:07:07 +0000",
    "user" : {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507242322803687425\/txL9b_xo_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 253302085309845505,
  "created_at" : "2012-10-03 01:14:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 18, 26 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253289448442314752",
  "text" : "Over 30 people at @wnyruby tonight. Very proud of this community!",
  "id" : 253289448442314752,
  "created_at" : "2012-10-03 00:24:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    }, {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 44, 52 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/253284575101460480\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/l871Q53s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4PY-qZCIAAeHdS.jpg",
      "id_str" : "253284575105654784",
      "id" : 253284575105654784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4PY-qZCIAAeHdS.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l871Q53s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253284978899705859",
  "text" : "RT @coworkbuffalo: Our stickers have landed @wnyruby ! http:\/\/t.co\/l871Q53s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNY Ruby",
        "screen_name" : "wnyruby",
        "indices" : [ 25, 33 ],
        "id_str" : "205886758",
        "id" : 205886758
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/253284575101460480\/photo\/1",
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/l871Q53s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4PY-qZCIAAeHdS.jpg",
        "id_str" : "253284575105654784",
        "id" : 253284575105654784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4PY-qZCIAAeHdS.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/l871Q53s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253284575101460480",
    "text" : "Our stickers have landed @wnyruby ! http:\/\/t.co\/l871Q53s",
    "id" : 253284575101460480,
    "created_at" : "2012-10-03 00:05:23 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 253284978899705859,
  "created_at" : "2012-10-03 00:06:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Anderson",
      "screen_name" : "mr_ndrsn",
      "indices" : [ 0, 9 ],
      "id_str" : "774032401",
      "id" : 774032401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253284435502444544",
  "geo" : { },
  "id_str" : "253284795717677056",
  "in_reply_to_user_id" : 774032401,
  "text" : "@mr_ndrsn will do! I only have 5 minutes\u2026the README has plenty of info",
  "id" : 253284795717677056,
  "in_reply_to_status_id" : 253284435502444544,
  "created_at" : "2012-10-03 00:06:15 +0000",
  "in_reply_to_screen_name" : "mr_ndrsn",
  "in_reply_to_user_id_str" : "774032401",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 10, 18 ],
      "id_str" : "205886758",
      "id" : 205886758
    }, {
      "name" : "Engine Yard",
      "screen_name" : "engineyard",
      "indices" : [ 27, 38 ],
      "id_str" : "7255652",
      "id" : 7255652
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/253284146724614144\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/peWi9D5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4PYlukCMAAqIxi.jpg",
      "id_str" : "253284146728808448",
      "id" : 253284146728808448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4PYlukCMAAqIxi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/peWi9D5Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253284146724614144",
  "text" : "ZOMG it\u2019s @wnyruby time at @engineyard Buffalo! http:\/\/t.co\/peWi9D5Y",
  "id" : 253284146724614144,
  "created_at" : "2012-10-03 00:03:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/JJgAEhaU",
      "expanded_url" : "http:\/\/i.imgur.com\/zrVh2.png",
      "display_url" : "i.imgur.com\/zrVh2.png"
    } ]
  },
  "geo" : { },
  "id_str" : "253243463045373952",
  "text" : "How most of my FTL games go... http:\/\/t.co\/JJgAEhaU",
  "id" : 253243463045373952,
  "created_at" : "2012-10-02 21:22:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffael Schmid",
      "screen_name" : "rafschmid",
      "indices" : [ 0, 10 ],
      "id_str" : "191774451",
      "id" : 191774451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253218889289326592",
  "geo" : { },
  "id_str" : "253221155257851904",
  "in_reply_to_user_id" : 191774451,
  "text" : "@rafschmid 7:30-9ish, probably. all lightning talks tonight!",
  "id" : 253221155257851904,
  "in_reply_to_status_id" : 253218889289326592,
  "created_at" : "2012-10-02 19:53:22 +0000",
  "in_reply_to_screen_name" : "rafschmid",
  "in_reply_to_user_id_str" : "191774451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/d50KIdJG",
      "expanded_url" : "http:\/\/www.itsartmag.com\/features\/paperman-breakdown\/#.UGtEQPl25Ig",
      "display_url" : "itsartmag.com\/features\/paper\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253220754852810752",
  "text" : "Always deeply inspired\/blown away by behind the scenes CG techniques. http:\/\/t.co\/d50KIdJG",
  "id" : 253220754852810752,
  "created_at" : "2012-10-02 19:51:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffael Schmid",
      "screen_name" : "rafschmid",
      "indices" : [ 0, 10 ],
      "id_str" : "191774451",
      "id" : 191774451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/XTyK8Gf4",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/buffalo",
      "display_url" : "reddit.com\/r\/buffalo"
    } ]
  },
  "in_reply_to_status_id_str" : "253215978001928192",
  "geo" : { },
  "id_str" : "253218112760061952",
  "in_reply_to_user_id" : 191774451,
  "text" : "@rafschmid as for attractions...lots on the sidebar of http:\/\/t.co\/XTyK8Gf4",
  "id" : 253218112760061952,
  "in_reply_to_status_id" : 253215978001928192,
  "created_at" : "2012-10-02 19:41:17 +0000",
  "in_reply_to_screen_name" : "rafschmid",
  "in_reply_to_user_id_str" : "191774451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffael Schmid",
      "screen_name" : "rafschmid",
      "indices" : [ 0, 10 ],
      "id_str" : "191774451",
      "id" : 191774451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253215978001928192",
  "geo" : { },
  "id_str" : "253217227896131586",
  "in_reply_to_user_id" : 191774451,
  "text" : "@rafschmid Definitely wander about Elmwood Village. +1 to Blue Monk, Cole's, or Liberty Hound for food\/drinks. Albright Knox is great too.",
  "id" : 253217227896131586,
  "in_reply_to_status_id" : 253215978001928192,
  "created_at" : "2012-10-02 19:37:46 +0000",
  "in_reply_to_screen_name" : "rafschmid",
  "in_reply_to_user_id_str" : "191774451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253214808852271104",
  "text" : "How you know you haven't had enough coffee today: You try to pour coffee out of a french press before pushing it down.",
  "id" : 253214808852271104,
  "created_at" : "2012-10-02 19:28:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffael Schmid",
      "screen_name" : "rafschmid",
      "indices" : [ 0, 10 ],
      "id_str" : "191774451",
      "id" : 191774451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/OYHmmgLA",
      "expanded_url" : "http:\/\/www.meetup.com\/Western-New-York-Ruby\/",
      "display_url" : "meetup.com\/Western-New-Yo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "253136324050182144",
  "geo" : { },
  "id_str" : "253204269329698816",
  "in_reply_to_user_id" : 191774451,
  "text" : "@rafschmid well, WNYRuby is tonight... http:\/\/t.co\/OYHmmgLA",
  "id" : 253204269329698816,
  "in_reply_to_status_id" : 253136324050182144,
  "created_at" : "2012-10-02 18:46:16 +0000",
  "in_reply_to_screen_name" : "rafschmid",
  "in_reply_to_user_id_str" : "191774451",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253193990185312257",
  "geo" : { },
  "id_str" : "253194406377684992",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems it is. it's terrible.",
  "id" : 253194406377684992,
  "in_reply_to_status_id" : 253193990185312257,
  "created_at" : "2012-10-02 18:07:05 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fletcher Nichol",
      "screen_name" : "fnichol",
      "indices" : [ 3, 11 ],
      "id_str" : "139169934",
      "id" : 139169934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/t7xWGiq9",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253190791927824384",
  "text" : "RT @fnichol: If you maintain shell scripts, check out \u2018sub\u2019 http:\/\/t.co\/t7xWGiq9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/t7xWGiq9",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
        "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253181371156148224",
    "text" : "If you maintain shell scripts, check out \u2018sub\u2019 http:\/\/t.co\/t7xWGiq9",
    "id" : 253181371156148224,
    "created_at" : "2012-10-02 17:15:17 +0000",
    "user" : {
      "name" : "Fletcher Nichol",
      "screen_name" : "fnichol",
      "protected" : false,
      "id_str" : "139169934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554766848588541953\/dqVE8vjC_normal.jpeg",
      "id" : 139169934,
      "verified" : false
    }
  },
  "id" : 253190791927824384,
  "created_at" : "2012-10-02 17:52:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Leavitt",
      "screen_name" : "n8leav",
      "indices" : [ 3, 10 ],
      "id_str" : "15345495",
      "id" : 15345495
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 12, 18 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 19, 31 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253146486764871680",
  "text" : "RT @n8leav: @qrush @sstephenson Very cool!... amazing how many scripts you collect over time, and this seems like a good structure all w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Sam Stephenson",
        "screen_name" : "sstephenson",
        "indices" : [ 7, 19 ],
        "id_str" : "6707392",
        "id" : 6707392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "251696410632794114",
    "geo" : { },
    "id_str" : "253142392599891969",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @sstephenson Very cool!... amazing how many scripts you collect over time, and this seems like a good structure all w tab complete!",
    "id" : 253142392599891969,
    "in_reply_to_status_id" : 251696410632794114,
    "created_at" : "2012-10-02 14:40:24 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Nathan Leavitt",
      "screen_name" : "n8leav",
      "protected" : false,
      "id_str" : "15345495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466809203630166016\/tbzEhx-H_normal.png",
      "id" : 15345495,
      "verified" : false
    }
  },
  "id" : 253146486764871680,
  "created_at" : "2012-10-02 14:56:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "indices" : [ 3, 10 ],
      "id_str" : "5452072",
      "id" : 5452072
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 12, 26 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/IAEQJ75m",
      "expanded_url" : "http:\/\/instagr.am\/p\/QSEoYQsqTJ\/",
      "display_url" : "instagr.am\/p\/QSEoYQsqTJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "253144280120557568",
  "text" : "RT @nb3004: @coworkbuffalo stickers!\nhttp:\/\/t.co\/IAEQJ75m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CoworkBuffalo",
        "screen_name" : "coworkbuffalo",
        "indices" : [ 0, 14 ],
        "id_str" : "491801330",
        "id" : 491801330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/IAEQJ75m",
        "expanded_url" : "http:\/\/instagr.am\/p\/QSEoYQsqTJ\/",
        "display_url" : "instagr.am\/p\/QSEoYQsqTJ\/"
      } ]
    },
    "geo" : { },
    "id_str" : "253143947021529088",
    "in_reply_to_user_id" : 491801330,
    "text" : "@coworkbuffalo stickers!\nhttp:\/\/t.co\/IAEQJ75m",
    "id" : 253143947021529088,
    "created_at" : "2012-10-02 14:46:34 +0000",
    "in_reply_to_screen_name" : "coworkbuffalo",
    "in_reply_to_user_id_str" : "491801330",
    "user" : {
      "name" : "Nicholas Barone",
      "screen_name" : "nb3004",
      "protected" : false,
      "id_str" : "5452072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477084296000585728\/PVswHXyq_normal.jpeg",
      "id" : 5452072,
      "verified" : false
    }
  },
  "id" : 253144280120557568,
  "created_at" : "2012-10-02 14:47:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Collins",
      "screen_name" : "ecollins7",
      "indices" : [ 0, 10 ],
      "id_str" : "19304692",
      "id" : 19304692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253141953846317056",
  "geo" : { },
  "id_str" : "253142392654413825",
  "in_reply_to_user_id" : 19304692,
  "text" : "@ecollins7 it's no problem, it's just we're casual users and not Square reps ;)",
  "id" : 253142392654413825,
  "in_reply_to_status_id" : 253141953846317056,
  "created_at" : "2012-10-02 14:40:24 +0000",
  "in_reply_to_screen_name" : "ecollins7",
  "in_reply_to_user_id_str" : "19304692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Collins",
      "screen_name" : "ecollins7",
      "indices" : [ 0, 10 ],
      "id_str" : "19304692",
      "id" : 19304692
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253140478483128321",
  "geo" : { },
  "id_str" : "253141666200965121",
  "in_reply_to_user_id" : 19304692,
  "text" : "@ecollins7 @kevinpurdy this is getting ridiculous. can you please just contact Square's support?",
  "id" : 253141666200965121,
  "in_reply_to_status_id" : 253140478483128321,
  "created_at" : "2012-10-02 14:37:31 +0000",
  "in_reply_to_screen_name" : "ecollins7",
  "in_reply_to_user_id_str" : "19304692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Collins",
      "screen_name" : "ecollins7",
      "indices" : [ 0, 10 ],
      "id_str" : "19304692",
      "id" : 19304692
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 11, 22 ],
      "id_str" : "14687182",
      "id" : 14687182
    }, {
      "name" : "A",
      "screen_name" : "AshleiJ",
      "indices" : [ 23, 31 ],
      "id_str" : "23344561",
      "id" : 23344561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253138316067745792",
  "geo" : { },
  "id_str" : "253139263351300097",
  "in_reply_to_user_id" : 19304692,
  "text" : "@ecollins7 @kevinpurdy @AshleiJ welcome to the wonderful world of using credit cards. there's no way around the fees.",
  "id" : 253139263351300097,
  "in_reply_to_status_id" : 253138316067745792,
  "created_at" : "2012-10-02 14:27:58 +0000",
  "in_reply_to_screen_name" : "ecollins7",
  "in_reply_to_user_id_str" : "19304692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253120970498387968",
  "text" : "Wow, rm -rf ~\/Library\/Mail cleared up ~16GB. See ya!",
  "id" : 253120970498387968,
  "created_at" : "2012-10-02 13:15:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/x6gPch3F",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Nnzw_i4YmKk",
      "display_url" : "youtube.com\/watch?v=Nnzw_i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "253070913547931648",
  "geo" : { },
  "id_str" : "253108515969851392",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage also we need whistle tips. WHUP WHUP! http:\/\/t.co\/x6gPch3F BUT ONLY IN THE MORNING!",
  "id" : 253108515969851392,
  "in_reply_to_status_id" : 253070913547931648,
  "created_at" : "2012-10-02 12:25:47 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    }, {
      "name" : "Kevin Purdy",
      "screen_name" : "kevinpurdy",
      "indices" : [ 28, 39 ],
      "id_str" : "14687182",
      "id" : 14687182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253070913547931648",
  "geo" : { },
  "id_str" : "253107576684830720",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage this is basically @kevinpurdy, every day.",
  "id" : 253107576684830720,
  "in_reply_to_status_id" : 253070913547931648,
  "created_at" : "2012-10-02 12:22:03 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252978527694114816",
  "geo" : { },
  "id_str" : "252978760394088448",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza this is dumb.",
  "id" : 252978760394088448,
  "in_reply_to_status_id" : 252978527694114816,
  "created_at" : "2012-10-02 03:50:11 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252967904771973120",
  "text" : "RT @rjs: People consistently overvalue ideas and undervalue the ability to execute on them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252967654460100609",
    "text" : "People consistently overvalue ideas and undervalue the ability to execute on them.",
    "id" : 252967654460100609,
    "created_at" : "2012-10-02 03:06:03 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 252967904771973120,
  "created_at" : "2012-10-02 03:07:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 42, 50 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252960411941474304",
  "text" : "Got my lightning talk about sub ready for @wnyruby tomorrow! Excited to talk about non-Ruby stuff.",
  "id" : 252960411941474304,
  "created_at" : "2012-10-02 02:37:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNY Ruby",
      "screen_name" : "wnyruby",
      "indices" : [ 70, 78 ],
      "id_str" : "205886758",
      "id" : 205886758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https:\/\/t.co\/rsjCPw43",
      "expanded_url" : "https:\/\/github.com\/37signals\/sub",
      "display_url" : "github.com\/37signals\/sub"
    } ]
  },
  "geo" : { },
  "id_str" : "252928296260628480",
  "text" : "Anyone using sub yet? What for? Getting a lightning talk together for @WNYRuby and MagicRuby about it. https:\/\/t.co\/rsjCPw43",
  "id" : 252928296260628480,
  "created_at" : "2012-10-02 00:29:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252921138525663232",
  "geo" : { },
  "id_str" : "252921518785458176",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik You are now a tent. Your brother is a tent. I am a tent. You live in a tent. Tent tent tent. Tent.",
  "id" : 252921518785458176,
  "in_reply_to_status_id" : 252921138525663232,
  "created_at" : "2012-10-02 00:02:43 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol&lt;'a&gt;",
      "screen_name" : "Carols10cents",
      "indices" : [ 0, 14 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252920603751890945",
  "geo" : { },
  "id_str" : "252920715047747584",
  "in_reply_to_user_id" : 194688433,
  "text" : "@Carols10cents baking a pie takes like 3 weeks, right?",
  "id" : 252920715047747584,
  "in_reply_to_status_id" : 252920603751890945,
  "created_at" : "2012-10-01 23:59:32 +0000",
  "in_reply_to_screen_name" : "Carols10cents",
  "in_reply_to_user_id_str" : "194688433",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 3, 17 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/252917908664102912\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/5MNrZUL3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4KLf3fCMAEatWC.jpg",
      "id_str" : "252917908672491521",
      "id" : 252917908672491521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4KLf3fCMAEatWC.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5MNrZUL3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252918118551277568",
  "text" : "RT @coworkbuffalo: Coding up some Battleship at Buffalo Learning to Code! http:\/\/t.co\/5MNrZUL3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/coworkbuffalo\/status\/252917908664102912\/photo\/1",
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/5MNrZUL3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4KLf3fCMAEatWC.jpg",
        "id_str" : "252917908672491521",
        "id" : 252917908672491521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4KLf3fCMAEatWC.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5MNrZUL3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252917908664102912",
    "text" : "Coding up some Battleship at Buffalo Learning to Code! http:\/\/t.co\/5MNrZUL3",
    "id" : 252917908664102912,
    "created_at" : "2012-10-01 23:48:24 +0000",
    "user" : {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "protected" : false,
      "id_str" : "491801330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249540449\/huge_buffalo_transparent_normal.png",
      "id" : 491801330,
      "verified" : false
    }
  },
  "id" : 252918118551277568,
  "created_at" : "2012-10-01 23:49:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252914686469754881",
  "geo" : { },
  "id_str" : "252914892577849344",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano yep! If you need a place to crash let me know. We could grab a drink at least.",
  "id" : 252914892577849344,
  "in_reply_to_status_id" : 252914686469754881,
  "created_at" : "2012-10-01 23:36:23 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252912448036802560",
  "geo" : { },
  "id_str" : "252912692984152064",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano holy crap! Coming to Buffalo at all?",
  "id" : 252912692984152064,
  "in_reply_to_status_id" : 252912448036802560,
  "created_at" : "2012-10-01 23:27:39 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tkml Technologies",
      "screen_name" : "tkmltech",
      "indices" : [ 3, 12 ],
      "id_str" : "370171956",
      "id" : 370171956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/HPpkMTjQ",
      "expanded_url" : "http:\/\/bit.ly\/U2vo0K",
      "display_url" : "bit.ly\/U2vo0K"
    } ]
  },
  "geo" : { },
  "id_str" : "252905887491047425",
  "text" : "RT @tkmltech: http:\/\/t.co\/HPpkMTjQ  Great example of finding efficiency in routine tasks. Something that just about any developer can ap ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HPpkMTjQ",
        "expanded_url" : "http:\/\/bit.ly\/U2vo0K",
        "display_url" : "bit.ly\/U2vo0K"
      } ]
    },
    "geo" : { },
    "id_str" : "252862711245979648",
    "text" : "http:\/\/t.co\/HPpkMTjQ  Great example of finding efficiency in routine tasks. Something that just about any developer can appreciate.",
    "id" : 252862711245979648,
    "created_at" : "2012-10-01 20:09:02 +0000",
    "user" : {
      "name" : "tkml Technologies",
      "screen_name" : "tkmltech",
      "protected" : false,
      "id_str" : "370171956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554781566\/tkml_final_square_normal.jpg",
      "id" : 370171956,
      "verified" : false
    }
  },
  "id" : 252905887491047425,
  "created_at" : "2012-10-01 23:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Eli Kalderon",
      "screen_name" : "PhilGeek",
      "indices" : [ 3, 12 ],
      "id_str" : "15250535",
      "id" : 15250535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/WXAraHUE",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
      "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252905868276953088",
  "text" : "RT @PhilGeek: Organizing shell scripts with subcommands. Some nice ideas here http:\/\/t.co\/WXAraHUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/WXAraHUE",
        "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3264-automating-with-convention-introducing-sub",
        "display_url" : "37signals.com\/svn\/posts\/3264\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252904120132964352",
    "text" : "Organizing shell scripts with subcommands. Some nice ideas here http:\/\/t.co\/WXAraHUE",
    "id" : 252904120132964352,
    "created_at" : "2012-10-01 22:53:35 +0000",
    "user" : {
      "name" : "Mark Eli Kalderon",
      "screen_name" : "PhilGeek",
      "protected" : false,
      "id_str" : "15250535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000380304290\/b644bc5f6803723b4074534bf0011f35_normal.jpeg",
      "id" : 15250535,
      "verified" : false
    }
  },
  "id" : 252905868276953088,
  "created_at" : "2012-10-01 23:00:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 0, 15 ],
      "id_str" : "267895957",
      "id" : 267895957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252891115991212032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.8954673437, -78.8793790904 ]
  },
  "id_str" : "252902761933447169",
  "in_reply_to_user_id" : 267895957,
  "text" : "@gabrielgironda heck yes!",
  "id" : 252902761933447169,
  "in_reply_to_status_id" : 252891115991212032,
  "created_at" : "2012-10-01 22:48:11 +0000",
  "in_reply_to_screen_name" : "gabrielgironda",
  "in_reply_to_user_id_str" : "267895957",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "indices" : [ 3, 18 ],
      "id_str" : "267895957",
      "id" : 267895957
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 20, 26 ],
      "id_str" : "5743852",
      "id" : 5743852
    }, {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 27, 39 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252902758351527936",
  "text" : "RT @gabrielgironda: @qrush @sstephenson moving a bunch of bullshit shell scripts i had laying around into a 'sub' setup. thanks!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      }, {
        "name" : "Sam Stephenson",
        "screen_name" : "sstephenson",
        "indices" : [ 7, 19 ],
        "id_str" : "6707392",
        "id" : 6707392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252891115991212032",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush @sstephenson moving a bunch of bullshit shell scripts i had laying around into a 'sub' setup. thanks!",
    "id" : 252891115991212032,
    "created_at" : "2012-10-01 22:01:55 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "First E-Rando",
      "screen_name" : "gabrielgironda",
      "protected" : true,
      "id_str" : "267895957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560982536772259840\/0R0rl2ao_normal.jpeg",
      "id" : 267895957,
      "verified" : false
    }
  },
  "id" : 252902758351527936,
  "created_at" : "2012-10-01 22:48:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Mazzola",
      "screen_name" : "ubuwaits",
      "indices" : [ 0, 9 ],
      "id_str" : "6980232",
      "id" : 6980232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252827219272011776",
  "geo" : { },
  "id_str" : "252828427856515073",
  "in_reply_to_user_id" : 6980232,
  "text" : "@ubuwaits \"Inventin' Shit\"",
  "id" : 252828427856515073,
  "in_reply_to_status_id" : 252827219272011776,
  "created_at" : "2012-10-01 17:52:49 +0000",
  "in_reply_to_screen_name" : "ubuwaits",
  "in_reply_to_user_id_str" : "6980232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 3, 10 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252819725422321664",
  "text" : "RT @mikeal: \"I've been writing JavaScript for years but what I really want are type errors\" -- Nobody",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252817549547413506",
    "text" : "\"I've been writing JavaScript for years but what I really want are type errors\" -- Nobody",
    "id" : 252817549547413506,
    "created_at" : "2012-10-01 17:09:35 +0000",
    "user" : {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "protected" : false,
      "id_str" : "668423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549609524038877184\/01oMFk1H_normal.png",
      "id" : 668423,
      "verified" : false
    }
  },
  "id" : 252819725422321664,
  "created_at" : "2012-10-01 17:18:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 3, 11 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252817582623686656",
  "text" : "RT @nkohari: TypeScript is just JavaScript with training wheels bolted on. How predictably Microsoft.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252816720643899392",
    "text" : "TypeScript is just JavaScript with training wheels bolted on. How predictably Microsoft.",
    "id" : 252816720643899392,
    "created_at" : "2012-10-01 17:06:17 +0000",
    "user" : {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "protected" : false,
      "id_str" : "6532552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486557242955534337\/o_ehcxEA_normal.jpeg",
      "id" : 6532552,
      "verified" : false
    }
  },
  "id" : 252817582623686656,
  "created_at" : "2012-10-01 17:09:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/fJjyM6oN",
      "expanded_url" : "http:\/\/blogs.msdn.com\/b\/somasegar\/archive\/2012\/10\/01\/typescript-javascript-development-at-application-scale.aspx",
      "display_url" : "blogs.msdn.com\/b\/somasegar\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252815585753305088",
  "text" : "Seriously, Microsoft? http:\/\/t.co\/fJjyM6oN",
  "id" : 252815585753305088,
  "created_at" : "2012-10-01 17:01:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Draplin Design Co.",
      "screen_name" : "Draplin",
      "indices" : [ 0, 8 ],
      "id_str" : "14229273",
      "id" : 14229273
    }, {
      "name" : "Ad Club of Buffalo",
      "screen_name" : "adclubofbuffalo",
      "indices" : [ 9, 25 ],
      "id_str" : "102076081",
      "id" : 102076081
    }, {
      "name" : "CoworkBuffalo",
      "screen_name" : "coworkbuffalo",
      "indices" : [ 115, 129 ],
      "id_str" : "491801330",
      "id" : 491801330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252813289824858112",
  "geo" : { },
  "id_str" : "252815216616816640",
  "in_reply_to_user_id" : 14229273,
  "text" : "@draplin @adclubofbuffalo awesome! if you need a place to get some stuff done before the event, you should drop by @coworkbuffalo :)",
  "id" : 252815216616816640,
  "in_reply_to_status_id" : 252813289824858112,
  "created_at" : "2012-10-01 17:00:19 +0000",
  "in_reply_to_screen_name" : "Draplin",
  "in_reply_to_user_id_str" : "14229273",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 46 ],
      "url" : "https:\/\/t.co\/nbNSmsve",
      "expanded_url" : "https:\/\/gist.github.com\/3812312",
      "display_url" : "gist.github.com\/3812312"
    } ]
  },
  "in_reply_to_status_id_str" : "252784788031815680",
  "geo" : { },
  "id_str" : "252785654331736064",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss Works fine here. https:\/\/t.co\/nbNSmsve",
  "id" : 252785654331736064,
  "in_reply_to_status_id" : 252784788031815680,
  "created_at" : "2012-10-01 15:02:51 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "503",
      "screen_name" : "jcoglan",
      "indices" : [ 0, 8 ],
      "id_str" : "1452984702",
      "id" : 1452984702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252652342237872129",
  "geo" : { },
  "id_str" : "252763279645102080",
  "in_reply_to_user_id" : 13861042,
  "text" : "@jcoglan maybe something has a lock to that specific version?",
  "id" : 252763279645102080,
  "in_reply_to_status_id" : 252652342237872129,
  "created_at" : "2012-10-01 13:33:56 +0000",
  "in_reply_to_screen_name" : "mountain_ghosts",
  "in_reply_to_user_id_str" : "13861042",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    }, {
      "name" : "Amanda Quaranto",
      "screen_name" : "aquaranto",
      "indices" : [ 26, 36 ],
      "id_str" : "5744442",
      "id" : 5744442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252754946074755073",
  "text" : "RT @ashedryden: This week @aquaranto is speaking at her first Ruby conference. Everyone wish her luck! &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Quaranto",
        "screen_name" : "aquaranto",
        "indices" : [ 10, 20 ],
        "id_str" : "5744442",
        "id" : 5744442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252754772317327360",
    "text" : "This week @aquaranto is speaking at her first Ruby conference. Everyone wish her luck! &lt;3",
    "id" : 252754772317327360,
    "created_at" : "2012-10-01 13:00:08 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 252754946074755073,
  "created_at" : "2012-10-01 13:00:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 3, 14 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/NGOLWnfV",
      "expanded_url" : "http:\/\/blog.jessitron.com\/2012\/09\/this-is-not-ok.html?m=1",
      "display_url" : "blog.jessitron.com\/2012\/09\/this-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252753215433625601",
  "text" : "RT @ashedryden: What it's like to be a woman in a sea of men at a tech conference. http:\/\/t.co\/NGOLWnfV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/NGOLWnfV",
        "expanded_url" : "http:\/\/blog.jessitron.com\/2012\/09\/this-is-not-ok.html?m=1",
        "display_url" : "blog.jessitron.com\/2012\/09\/this-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252751863768838144",
    "text" : "What it's like to be a woman in a sea of men at a tech conference. http:\/\/t.co\/NGOLWnfV",
    "id" : 252751863768838144,
    "created_at" : "2012-10-01 12:48:34 +0000",
    "user" : {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "protected" : false,
      "id_str" : "9510922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568990886835404800\/eWG_A-yu_normal.jpeg",
      "id" : 9510922,
      "verified" : false
    }
  },
  "id" : 252753215433625601,
  "created_at" : "2012-10-01 12:53:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pfeifer",
      "screen_name" : "fbonacci",
      "indices" : [ 3, 12 ],
      "id_str" : "20704612",
      "id" : 20704612
    }, {
      "name" : "David Frum",
      "screen_name" : "davidfrum",
      "indices" : [ 15, 25 ],
      "id_str" : "18686907",
      "id" : 18686907
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidfrum\/status\/252747324714000384\/photo\/1",
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/tgXbbf8j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4HwWkwCIAA6X3N.png",
      "id_str" : "252747324722388992",
      "id" : 252747324722388992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4HwWkwCIAA6X3N.png",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 503
      } ],
      "display_url" : "pic.twitter.com\/tgXbbf8j"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Xr7p5xJk",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2012\/10\/01\/rip-cobber.html",
      "display_url" : "thedailybeast.com\/articles\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "252752899342487552",
  "text" : "RT @fbonacci: \u201C@davidfrum: Obituary for a dog. http:\/\/t.co\/Xr7p5xJk http:\/\/t.co\/tgXbbf8j\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Frum",
        "screen_name" : "davidfrum",
        "indices" : [ 1, 11 ],
        "id_str" : "18686907",
        "id" : 18686907
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidfrum\/status\/252747324714000384\/photo\/1",
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/tgXbbf8j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4HwWkwCIAA6X3N.png",
        "id_str" : "252747324722388992",
        "id" : 252747324722388992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4HwWkwCIAA6X3N.png",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 503
        } ],
        "display_url" : "pic.twitter.com\/tgXbbf8j"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/Xr7p5xJk",
        "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2012\/10\/01\/rip-cobber.html",
        "display_url" : "thedailybeast.com\/articles\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252748335394455552",
    "text" : "\u201C@davidfrum: Obituary for a dog. http:\/\/t.co\/Xr7p5xJk http:\/\/t.co\/tgXbbf8j\u201D",
    "id" : 252748335394455552,
    "created_at" : "2012-10-01 12:34:33 +0000",
    "user" : {
      "name" : "Pfeifer",
      "screen_name" : "fbonacci",
      "protected" : false,
      "id_str" : "20704612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3024020215\/edf076c04fb3d2969377262ef2d6c1a2_normal.jpeg",
      "id" : 20704612,
      "verified" : false
    }
  },
  "id" : 252752899342487552,
  "created_at" : "2012-10-01 12:52:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/yqTTUmvc",
      "expanded_url" : "http:\/\/bit.ly\/Pyq6DO",
      "display_url" : "bit.ly\/Pyq6DO"
    } ]
  },
  "geo" : { },
  "id_str" : "252625271763656704",
  "text" : "RT @codepoet_ch: The shell command handling from rbenv extracted, so you can easily make new shell commands! http:\/\/t.co\/yqTTUmvc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/yqTTUmvc",
        "expanded_url" : "http:\/\/bit.ly\/Pyq6DO",
        "display_url" : "bit.ly\/Pyq6DO"
      } ]
    },
    "geo" : { },
    "id_str" : "252604880294916098",
    "text" : "The shell command handling from rbenv extracted, so you can easily make new shell commands! http:\/\/t.co\/yqTTUmvc",
    "id" : 252604880294916098,
    "created_at" : "2012-10-01 03:04:31 +0000",
    "user" : {
      "name" : "Andreas Arnold",
      "screen_name" : "featureenvy",
      "protected" : false,
      "id_str" : "198181478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2083127874\/me2_normal.jpg",
      "id" : 198181478,
      "verified" : false
    }
  },
  "id" : 252625271763656704,
  "created_at" : "2012-10-01 04:25:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
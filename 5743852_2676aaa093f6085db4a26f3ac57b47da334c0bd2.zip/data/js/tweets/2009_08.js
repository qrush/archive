Grailbird.data.tweets_2009_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3678882253",
  "text" : "Finally got my desk set up. Woot.",
  "id" : 3678882253,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 69, 82 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3679319416",
  "text" : "Going to play some TF2 for the first time in months. I blame this on @codemastermm and the TF2 posters strewn about campus.",
  "id" : 3679319416,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3688637769",
  "text" : "Video: Lots of people hate Wind Waker, but it\u2019s one of my favorite Zelda games. http:\/\/tumblr.com\/x172xg19k",
  "id" : 3688637769,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3689043954",
  "text" : "Video: 63 DEGREES. http:\/\/tumblr.com\/x172xgbuw",
  "id" : 3689043954,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3692372100",
  "text" : "Should I bother to upgrade my mac mini to snow leopard?",
  "id" : 3692372100,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coworking Rochester",
      "screen_name" : "coworkingroc",
      "indices" : [ 3, 16 ],
      "id_str" : "19386993",
      "id" : 19386993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3666415885",
  "text" : "At @coworkingroc. Way better than staying on campus to work.",
  "id" : 3666415885,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3667737565",
  "text" : "Photo: kevin: pretty sweet chart! http:\/\/tumblr.com\/x172wz321",
  "id" : 3667737565,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3669046933",
  "text" : "Now looking for a Ruby\/Rails consulting gig, if you have a lead or know of any let me know!",
  "id" : 3669046933,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3669321778",
  "text" : "Photo:  http:\/\/tumblr.com\/x172x05y4",
  "id" : 3669321778,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Veverka",
      "screen_name" : "veverkap",
      "indices" : [ 0, 9 ],
      "id_str" : "5500152",
      "id" : 5500152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3669531274",
  "geo" : { },
  "id_str" : "3669855093",
  "in_reply_to_user_id" : 5500152,
  "text" : "@veverkap yeah, i saw that...it seems like they're looking for a full timer though.",
  "id" : 3669855093,
  "in_reply_to_status_id" : 3669531274,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "veverkap",
  "in_reply_to_user_id_str" : "5500152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3670990041",
  "text" : "Snuggie. FOR DOGS. https:\/\/www.snuggiefordogs.com\/flare\/next",
  "id" : 3670990041,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Yoder",
      "screen_name" : "dyoder",
      "indices" : [ 0, 7 ],
      "id_str" : "14767983",
      "id" : 14767983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3661122466",
  "geo" : { },
  "id_str" : "3663934471",
  "in_reply_to_user_id" : 14767983,
  "text" : "@dyoder Ah, perhaps it's the dependency on the json gem...I'm surprised that JRuby can't handle that, I thought it was pretty standard",
  "id" : 3663934471,
  "in_reply_to_status_id" : 3661122466,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "dyoder",
  "in_reply_to_user_id_str" : "14767983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rit",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3664475646",
  "text" : "Aww, all of the freshman are wearing RIT shirts. How cute. #rit",
  "id" : 3664475646,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3664392336",
  "geo" : { },
  "id_str" : "3664899865",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh awesome post on branching man, i left a comment. moderation ftl :[",
  "id" : 3664899865,
  "in_reply_to_status_id" : 3664392336,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3647433152",
  "text" : "First RIT win: wireless router in the apartment. Boom.",
  "id" : 3647433152,
  "created_at" : "2009-08-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Yoder",
      "screen_name" : "dyoder",
      "indices" : [ 0, 7 ],
      "id_str" : "14767983",
      "id" : 14767983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3650337549",
  "geo" : { },
  "id_str" : "3651977718",
  "in_reply_to_user_id" : 14767983,
  "text" : "@dyoder it's on the list! I haven't played around much with jruby yet but that's a good excuse to :)",
  "id" : 3651977718,
  "in_reply_to_status_id" : 3650337549,
  "created_at" : "2009-08-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "dyoder",
  "in_reply_to_user_id_str" : "14767983",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3632394959",
  "text" : "Made it to Rochester and unpacked. DISTILLERY TIME.",
  "id" : 3632394959,
  "created_at" : "2009-08-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3632402347",
  "text" : "Correction: unloaded. Unpacking may take eons.",
  "id" : 3632402347,
  "created_at" : "2009-08-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lockfort",
      "screen_name" : "clockfort",
      "indices" : [ 0, 10 ],
      "id_str" : "16381663",
      "id" : 16381663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3600191203",
  "in_reply_to_user_id" : 16381663,
  "text" : "@clockfort my worse: killed by the castle's drawbridge exploding. or maybe stepping in lava. twice.",
  "id" : 3600191203,
  "created_at" : "2009-08-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "clockfort",
  "in_reply_to_user_id_str" : "16381663",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3601157885",
  "text" : "Going to get the moving truck. Freight elevator next door to our apartment ftw!",
  "id" : 3601157885,
  "created_at" : "2009-08-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3614578036",
  "text" : "Staying at BC for the night. Their dorms' wireless access disallows IRC, ssh, and ping, yet they have a CS school here. wtf?",
  "id" : 3614578036,
  "created_at" : "2009-08-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3568480287",
  "text" : "Photo:  http:\/\/tumblr.com\/x172upp11",
  "id" : 3568480287,
  "created_at" : "2009-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3587116163",
  "text" : "Packing my crap LIKE A BOSS",
  "id" : 3587116163,
  "created_at" : "2009-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3555198242",
  "text" : "Photo: USS Dog http:\/\/tumblr.com\/x172ugb3z",
  "id" : 3555198242,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3557606021",
  "text" : "Photo: \u201CFAKE. If it was really Chuck Norris this car would have exploded on impact.\u201D Via flickr. http:\/\/tumblr.com\/x172ui0ad",
  "id" : 3557606021,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alaina",
      "screen_name" : "Marigold",
      "indices" : [ 0, 9 ],
      "id_str" : "5744682",
      "id" : 5744682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3560928973",
  "geo" : { },
  "id_str" : "3560967682",
  "in_reply_to_user_id" : 5744682,
  "text" : "@Marigold good, the food there was crappy anyway. i always got subs.",
  "id" : 3560967682,
  "in_reply_to_status_id" : 3560928973,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Marigold",
  "in_reply_to_user_id_str" : "5744682",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Johnson",
      "screen_name" : "commondream",
      "indices" : [ 0, 12 ],
      "id_str" : "2703041",
      "id" : 2703041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gemcutter",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3561326842",
  "geo" : { },
  "id_str" : "3561717738",
  "in_reply_to_user_id" : 2703041,
  "text" : "@commondream if you have questions feel free to bug us in #gemcutter on FreeNode. I'm liking it so far, but I may be a tad bit biased. :)",
  "id" : 3561717738,
  "in_reply_to_status_id" : 3561326842,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "commondream",
  "in_reply_to_user_id_str" : "2703041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Johnson",
      "screen_name" : "commondream",
      "indices" : [ 0, 12 ],
      "id_str" : "2703041",
      "id" : 2703041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3561984647",
  "geo" : { },
  "id_str" : "3562135438",
  "in_reply_to_user_id" : 2703041,
  "text" : "@commondream the redesign was done by thoughtbot, but it's an oss project: http:\/\/github.com\/qrush\/gemcutter and thanks!",
  "id" : 3562135438,
  "in_reply_to_status_id" : 3561984647,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "commondream",
  "in_reply_to_user_id_str" : "2703041",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3562442039",
  "geo" : { },
  "id_str" : "3562470348",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza just use git-svn. and i heard there's an svn shelve, but meh.",
  "id" : 3562470348,
  "in_reply_to_status_id" : 3562442039,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 0, 12 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3562670656",
  "in_reply_to_user_id" : 658643,
  "text" : "@SteveStreza you accidentally all the logic.",
  "id" : 3562670656,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3526585188",
  "geo" : { },
  "id_str" : "3528352558",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky definitely. i sent a github message to the author, haven't heard anything back yet.",
  "id" : 3528352558,
  "in_reply_to_status_id" : 3526585188,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yhara_en",
      "screen_name" : "yhara_en",
      "indices" : [ 0, 9 ],
      "id_str" : "10703982",
      "id" : 10703982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3532922046",
  "geo" : { },
  "id_str" : "3533811994",
  "in_reply_to_user_id" : 10703982,
  "text" : "@yhara_en I think there's something wrong with the gem indexing, trying to resolve it.",
  "id" : 3533811994,
  "in_reply_to_status_id" : 3532922046,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "yhara_en",
  "in_reply_to_user_id_str" : "10703982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yhara_en",
      "screen_name" : "yhara_en",
      "indices" : [ 0, 9 ],
      "id_str" : "10703982",
      "id" : 10703982
    }, {
      "name" : "David Dollar",
      "screen_name" : "ddollar",
      "indices" : [ 65, 73 ],
      "id_str" : "839931",
      "id" : 839931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3535926380",
  "geo" : { },
  "id_str" : "3536354222",
  "in_reply_to_user_id" : 10703982,
  "text" : "@yhara_en Indexing for new gems just got fixed by the impeccable @ddollar... all the gems that were lost in the ether will be fixed soon",
  "id" : 3536354222,
  "in_reply_to_status_id" : 3535926380,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "yhara_en",
  "in_reply_to_user_id_str" : "10703982",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3541271540",
  "text" : "Overheard: Nick Q.: why doesnt bighearton have a slidechop yet full of dick jokes? Mike B.: Nick have some... http:\/\/tumblr.com\/x172u3ul0",
  "id" : 3541271540,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3542114220",
  "text" : "It might get loud looks awesome. http:\/\/www.sonyclassics.com\/itmightgetloud\/",
  "id" : 3542114220,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3542131711",
  "text" : "&gt;&gt; Rubygem.sum(:downloads) =&gt; 2231 (for @rubygemcutter) woot!",
  "id" : 3542131711,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3545088914",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil you should try out http:\/\/slidechop.com :)",
  "id" : 3545088914,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3502335243",
  "text" : "presentations for hackers: http:\/\/slidechop.com (my #railsrumble entry)",
  "id" : 3502335243,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B9\u30AE\u30A6\u30C1",
      "screen_name" : "nokogiri",
      "indices" : [ 0, 9 ],
      "id_str" : "133939177",
      "id" : 133939177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3502810941",
  "text" : "@nokogiri yes, you just need slidedown installed. we should probably have a tutorial for that",
  "id" : 3502810941,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Kohari",
      "screen_name" : "nkohari",
      "indices" : [ 0, 8 ],
      "id_str" : "6532552",
      "id" : 6532552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3502841152",
  "in_reply_to_user_id" : 6532552,
  "text" : "@nkohari oops, i meant you for that last one.",
  "id" : 3502841152,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "nkohari",
  "in_reply_to_user_id_str" : "6532552",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jasmin Leitgeb",
      "screen_name" : "LeitgebJ",
      "indices" : [ 0, 9 ],
      "id_str" : "1617039331",
      "id" : 1617039331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3502798612",
  "geo" : { },
  "id_str" : "3506088431",
  "in_reply_to_user_id" : 14886639,
  "text" : "@leitgebj woot! glad you're enjoying it :) let me know if there's way you can think of to improve it.",
  "id" : 3506088431,
  "in_reply_to_status_id" : 3502798612,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "justinleitgeb",
  "in_reply_to_user_id_str" : "14886639",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anita Kuno",
      "screen_name" : "anteaya",
      "indices" : [ 0, 8 ],
      "id_str" : "14262153",
      "id" : 14262153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3502475428",
  "geo" : { },
  "id_str" : "3506159277",
  "in_reply_to_user_id" : 14262153,
  "text" : "@anteaya thanks! let me know if it actually works. ... &gt;_&gt;",
  "id" : 3506159277,
  "in_reply_to_status_id" : 3502475428,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "anteaya",
  "in_reply_to_user_id_str" : "14262153",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3512787311",
  "geo" : { },
  "id_str" : "3512805065",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm has reached annoying level 37!",
  "id" : 3512805065,
  "in_reply_to_status_id" : 3512787311,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "darthzippy",
      "screen_name" : "darthzippy",
      "indices" : [ 0, 11 ],
      "id_str" : "14602075",
      "id" : 14602075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3512773067",
  "geo" : { },
  "id_str" : "3512888514",
  "in_reply_to_user_id" : 14602075,
  "text" : "@darthzippy thanks! glad you're liking it! chop chop chop chop http:\/\/bit.ly\/RquYV",
  "id" : 3512888514,
  "in_reply_to_status_id" : 3512773067,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "darthzippy",
  "in_reply_to_user_id_str" : "14602075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3517299309",
  "text" : "\"SHARKS.\" - This is just so my avatar TURNS INTO A FUCKING SHARK http:\/\/tumblr.com\/x172tkbya",
  "id" : 3517299309,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3517402184",
  "text" : "SHARKS. - this is just so my avatar TURNS INTO A FUCKING SHARK. http:\/\/tumblr.com\/x172tkezo",
  "id" : 3517402184,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jes\u00FAs GS",
      "screen_name" : "blaxter",
      "indices" : [ 0, 8 ],
      "id_str" : "5380272",
      "id" : 5380272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3516928520",
  "geo" : { },
  "id_str" : "3517853228",
  "in_reply_to_user_id" : 5380272,
  "text" : "@blaxter awesome! I'd love to fix the gem on both 1.9 and jruby...I should really get a CI server up for this.",
  "id" : 3517853228,
  "in_reply_to_status_id" : 3516928520,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "blaxter",
  "in_reply_to_user_id_str" : "5380272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Younge",
      "screen_name" : "ayounge",
      "indices" : [ 0, 8 ],
      "id_str" : "14746618",
      "id" : 14746618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3517990800",
  "geo" : { },
  "id_str" : "3518064211",
  "in_reply_to_user_id" : 14746618,
  "text" : "@ayounge wait, what? we're getting charged early to move in next week for perkins.",
  "id" : 3518064211,
  "in_reply_to_status_id" : 3517990800,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ayounge",
  "in_reply_to_user_id_str" : "14746618",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3520159919",
  "text" : "Just had an idea for a Git patch. Now to write some C...",
  "id" : 3520159919,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heart\u2764n",
      "screen_name" : "bighearton",
      "indices" : [ 0, 11 ],
      "id_str" : "67765461",
      "id" : 67765461
    }, {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 25, 33 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3482283953",
  "geo" : { },
  "id_str" : "3482320446",
  "in_reply_to_user_id" : 67765461,
  "text" : "@bighearton i think it's @jayunit",
  "id" : 3482320446,
  "in_reply_to_status_id" : 3482283953,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "bighearton",
  "in_reply_to_user_id_str" : "67765461",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3484540776",
  "text" : "http:\/\/twitter.com\/Doc__Brown is my new hero.",
  "id" : 3484540776,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3490368028",
  "text" : "Final day of the #railsrumble, waiting for the train. We could be done now and I'd be happy.",
  "id" : 3490368028,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Moss",
      "screen_name" : "joelmoss",
      "indices" : [ 0, 9 ],
      "id_str" : "867511",
      "id" : 867511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3489371908",
  "geo" : { },
  "id_str" : "3490640532",
  "in_reply_to_user_id" : 867511,
  "text" : "@joelmoss let me know if there's any questions! that being said, the API for pushing gems could use some more docs for sure.",
  "id" : 3490640532,
  "in_reply_to_status_id" : 3489371908,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "joelmoss",
  "in_reply_to_user_id_str" : "867511",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 53, 64 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3491217964",
  "text" : "#railsrumble countdown clock installed on one of the @thoughtbot TV's. T minus 11 hours.",
  "id" : 3491217964,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3491300742",
  "text" : "For others rumbling: east coast countdown until the #railsrumble wraps up: http:\/\/bit.ly\/6inm7",
  "id" : 3491300742,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nunemaker",
      "screen_name" : "jnunemaker",
      "indices" : [ 0, 11 ],
      "id_str" : "4243",
      "id" : 4243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3464398118",
  "geo" : { },
  "id_str" : "3464422062",
  "in_reply_to_user_id" : 4243,
  "text" : "@jnunemaker how to blog about ruby and not suck at it. remembering _why. something about mongodb.",
  "id" : 3464422062,
  "in_reply_to_status_id" : 3464398118,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jnunemaker",
  "in_reply_to_user_id_str" : "4243",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3464763915",
  "text" : "Awesome countdown for the #railsrumble: http:\/\/teabass.com\/rumble\/",
  "id" : 3464763915,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3465042769",
  "text" : "Bug report: \"PHP 5.3 includes goto. This is a problem.\" PHP dev team member: \"goto hell;\" http:\/\/bugs.php.net\/bug.php?id=48669",
  "id" : 3465042769,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3470749390",
  "text" : "Definitely slept in, will have to catch the second train into Boston for the #railsrumble.",
  "id" : 3470749390,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Andrijevik",
      "screen_name" : "vandrijevik",
      "indices" : [ 0, 12 ],
      "id_str" : "14407694",
      "id" : 14407694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3473293509",
  "in_reply_to_user_id" : 14407694,
  "text" : "@vandrijevik neither. anteup. payup. uoweme.",
  "id" : 3473293509,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "vandrijevik",
  "in_reply_to_user_id_str" : "14407694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidechop",
      "screen_name" : "slidechop",
      "indices" : [ 11, 21 ],
      "id_str" : "67766098",
      "id" : 67766098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3475096504",
  "text" : "Looks like @slidechop is ALIVE! Git pushes are working, the site is sending emails too. Woot!",
  "id" : 3475096504,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 29, 41 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3461752460",
  "text" : "Setting up our Linode slice. @tristandunn's sprinkle script is crazy. #railsrumble",
  "id" : 3461752460,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railsrumble",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3463942396",
  "text" : "Heading home from the #railsrumble. Server set up and rails app deployed. woot!",
  "id" : 3463942396,
  "created_at" : "2009-08-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3449083094",
  "text" : "Last friday going to Boston. sadface.",
  "id" : 3449083094,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3461380264",
  "text" : "LETS GET READY TO RUMMMMMMMBLE!",
  "id" : 3461380264,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3419178889",
  "text" : "Photo: DEMI-DOG. http:\/\/tumblr.com\/x172rf0gk",
  "id" : 3419178889,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg Pollack",
      "screen_name" : "greggpollack",
      "indices" : [ 62, 75 ],
      "id_str" : "6082492",
      "id" : 6082492
    }, {
      "name" : "Nathaniel Bibler",
      "screen_name" : "nbibler",
      "indices" : [ 80, 88 ],
      "id_str" : "14351836",
      "id" : 14351836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3427391482",
  "text" : "gemcutter is on ruby5! plenty of work to do still, but thanks @greggpollack and @nbibler http:\/\/ruby5.envylabs.com",
  "id" : 3427391482,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmytro Shteflyuk",
      "screen_name" : "kpumuk",
      "indices" : [ 0, 7 ],
      "id_str" : "18355994",
      "id" : 18355994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3428777465",
  "geo" : { },
  "id_str" : "3428821723",
  "in_reply_to_user_id" : 18355994,
  "text" : "@kpumuk There's a redesign in progress. http:\/\/bit.ly\/Zatu3",
  "id" : 3428821723,
  "in_reply_to_status_id" : 3428777465,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "kpumuk",
  "in_reply_to_user_id_str" : "18355994",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3430051642",
  "geo" : { },
  "id_str" : "3430584059",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle are you talking about a support ticket or the site in general? we were just getting flooded a few moments ago.",
  "id" : 3430584059,
  "in_reply_to_status_id" : 3430051642,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50 Daniel Lucraft",
      "screen_name" : "danlucraft",
      "indices" : [ 0, 11 ],
      "id_str" : "13094142",
      "id" : 13094142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3402265831",
  "geo" : { },
  "id_str" : "3403250617",
  "in_reply_to_user_id" : 13094142,
  "text" : "@danlucraft Gemcutter automatically pulls in the latest gems from Rubyforge nightly, so hopefully you'll only need one. :)",
  "id" : 3403250617,
  "in_reply_to_status_id" : 3402265831,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "danlucraft",
  "in_reply_to_user_id_str" : "13094142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ric Roberts",
      "screen_name" : "RicRoberts",
      "indices" : [ 0, 11 ],
      "id_str" : "16550758",
      "id" : 16550758
    }, {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 21, 32 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3404152920",
  "geo" : { },
  "id_str" : "3404570131",
  "in_reply_to_user_id" : 16550758,
  "text" : "@RicRoberts it's not @thoughtbot's, although they're supported the redesign. it's the community's first and foremost. http:\/\/is.gd\/2ooUc",
  "id" : 3404570131,
  "in_reply_to_status_id" : 3404152920,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "RicRoberts",
  "in_reply_to_user_id_str" : "16550758",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3409058493",
  "text" : "Where did _why go? This just isn't cool. http:\/\/whytheluckystiff.net\/ http:\/\/poignantguide.net\/ http:\/\/hackety.org\/ http:\/\/shoooes.net\/",
  "id" : 3409058493,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "why the lucky stiff",
      "screen_name" : "_why",
      "indices" : [ 125, 130 ],
      "id_str" : "275198114",
      "id" : 275198114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3409353465",
  "text" : "Just forked shoes and hpricot. Anyone have to source to the poignant guide? I think we should try to salvage all we can from @_why.",
  "id" : 3409353465,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3410484271",
  "text" : "Photo:  http:\/\/tumblr.com\/x172r8hs2",
  "id" : 3410484271,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Durham",
      "screen_name" : "jeremydurham",
      "indices" : [ 0, 13 ],
      "id_str" : "966341",
      "id" : 966341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3410932435",
  "geo" : { },
  "id_str" : "3411039753",
  "in_reply_to_user_id" : 966341,
  "text" : "@jeremydurham headed back to Rochester, NY next week to finish up at RIT.",
  "id" : 3411039753,
  "in_reply_to_status_id" : 3410932435,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeremydurham",
  "in_reply_to_user_id_str" : "966341",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3414508279",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Bravo sir, well done. Definitely the perspective I needed on this those situation.",
  "id" : 3414508279,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3383419371",
  "text" : "Photo: if websites were people http:\/\/tumblr.com\/x172qnuwk",
  "id" : 3383419371,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3385500167",
  "geo" : { },
  "id_str" : "3385984701",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton you've got to do gem tumble or remove rubyforge as a source, otherwise that won't help",
  "id" : 3385984701,
  "in_reply_to_status_id" : 3385500167,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 44, 54 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3387548578",
  "text" : "Awesome redesign of http:\/\/gemcutter.org by @kevinburg: http:\/\/is.gd\/2n6g1 Now I just have to get it on the site.",
  "id" : 3387548578,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Leveille",
      "screen_name" : "danlev",
      "indices" : [ 0, 7 ],
      "id_str" : "13612732",
      "id" : 13612732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3388280589",
  "in_reply_to_user_id" : 13612732,
  "text" : "@danlev what have you done",
  "id" : 3388280589,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "danlev",
  "in_reply_to_user_id_str" : "13612732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3389227088",
  "geo" : { },
  "id_str" : "3389257397",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini it syncs on a nightly basis. that should go in the FAQ.",
  "id" : 3389257397,
  "in_reply_to_status_id" : 3389227088,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bostonrb",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3392991533",
  "text" : "Last #bostonrb hackfest while I'm still in town. Sadface.",
  "id" : 3392991533,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3353801255",
  "text" : "District 9 was great, but now I want to see District 10.",
  "id" : 3353801255,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3355931520",
  "text" : "Today's XKCD is full of win. http:\/\/xkcd.com And lesbians on GitHub.",
  "id" : 3355931520,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Calavera",
      "screen_name" : "calavera",
      "indices" : [ 0, 9 ],
      "id_str" : "728823",
      "id" : 728823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3359790418",
  "geo" : { },
  "id_str" : "3359948903",
  "in_reply_to_user_id" : 728823,
  "text" : "@calavera Yeah, they could a bit tinier. There's been more pressing issues than form styles to solve with @rubygemcutter :)",
  "id" : 3359948903,
  "in_reply_to_status_id" : 3359790418,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "calavera",
  "in_reply_to_user_id_str" : "728823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Calavera",
      "screen_name" : "calavera",
      "indices" : [ 0, 9 ],
      "id_str" : "728823",
      "id" : 728823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3360162110",
  "in_reply_to_user_id" : 728823,
  "text" : "@calavera thanks! yeah hopefully you won't have to do that anymore :)",
  "id" : 3360162110,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "calavera",
  "in_reply_to_user_id_str" : "728823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3361254292",
  "text" : "Photo: Rich .NET AJAX makes me UNCOMFORTABLY ENERGETIC http:\/\/tumblr.com\/x172q5pl2",
  "id" : 3361254292,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3362151777",
  "text" : "ssh-forever looks awesome. and it's #1 for downloads on http:\/\/gemcutter.org! http:\/\/is.gd\/2laTU",
  "id" : 3362151777,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3362246293",
  "text" : "Video: THE PANTS WERE DEAD http:\/\/tumblr.com\/x172q6iu4",
  "id" : 3362246293,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joegrammer",
      "screen_name" : "joefiorini",
      "indices" : [ 0, 11 ],
      "id_str" : "13893562",
      "id" : 13893562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3362396728",
  "geo" : { },
  "id_str" : "3362756692",
  "in_reply_to_user_id" : 13893562,
  "text" : "@joefiorini thanks! redesign coming soon hopefully: http:\/\/bit.ly\/OvhpP",
  "id" : 3362756692,
  "in_reply_to_status_id" : 3362396728,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "joefiorini",
  "in_reply_to_user_id_str" : "13893562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3367984792",
  "geo" : { },
  "id_str" : "3368170831",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer awesome! gonna try it out for gemcutter. which gets me thinking...perhaps you guys should host the devver gem there instead! :)",
  "id" : 3368170831,
  "in_reply_to_status_id" : 3367984792,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3339030191",
  "text" : "MBTA budget cuts have led to the train cab's lights being totally off for this ride. Or at least, this is the only excuse I can think of.",
  "id" : 3339030191,
  "created_at" : "2009-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3339164623",
  "text" : "\"you obviously haven\u2019t worked in a real business where it comes down to dollars and time, not necessarily...\" http:\/\/tumblr.com\/x172plb10",
  "id" : 3339164623,
  "created_at" : "2009-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3339573657",
  "text" : "Not really enjoying SpeakerRate as a concept. I'd rather have someone directly tell me what they liked\/didn't like about my talk.",
  "id" : 3339573657,
  "created_at" : "2009-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3339585080",
  "text" : "If you can't take the criticism, you shouldn't be on the podium. SpeakerRate's rating doesn't help that even with logging in to vote.",
  "id" : 3339585080,
  "created_at" : "2009-08-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "developer_day",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3319607069",
  "text" : "Excited for my #developer_day talk tomorrow. Not excited about taking a 7am train on Saturday.",
  "id" : 3319607069,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3319704898",
  "text" : "Photo:  http:\/\/tumblr.com\/x172p5jmb",
  "id" : 3319704898,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3322055318",
  "text" : "\"Hi. I\u2019m at the cabin. Have had 3 whiskeys. It\u2019s been a hard day. And it\u2019s really hard to type. [\u2026] I...\" http:\/\/tumblr.com\/x172p78qs",
  "id" : 3322055318,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3327878973",
  "geo" : { },
  "id_str" : "3328163686",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky My brain is full of Erlang now, too.",
  "id" : 3328163686,
  "in_reply_to_status_id" : 3327878973,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3328311663",
  "text" : "DEVELOPER DEVELOPER DEVELOPER DAY",
  "id" : 3328311663,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 11, 20 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3328622686",
  "text" : "looks like @gitready is now en Espa\u00F1ol: http:\/\/es.gitready.com",
  "id" : 3328622686,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3331787674",
  "text" : "Photo:  http:\/\/tumblr.com\/x172pfgfs",
  "id" : 3331787674,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3333556737",
  "text" : "My next talk is going to be not about Git.",
  "id" : 3333556737,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3333812239",
  "text" : "Holy crap, http:\/\/testswarm.com is awesome.",
  "id" : 3333812239,
  "created_at" : "2009-08-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3315962459",
  "geo" : { },
  "id_str" : "3316016168",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky That was a noob question and of course, I mean it in jest.",
  "id" : 3316016168,
  "in_reply_to_status_id" : 3315962459,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Darnowsky",
      "screen_name" : "PhilDarnowsky",
      "indices" : [ 0, 14 ],
      "id_str" : "16930130",
      "id" : 16930130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3315962459",
  "geo" : { },
  "id_str" : "3316022126",
  "in_reply_to_user_id" : 16930130,
  "text" : "@PhilDarnowsky I should have specified that I wasn't the author of said quote.",
  "id" : 3316022126,
  "in_reply_to_status_id" : 3315962459,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "PhilDarnowsky",
  "in_reply_to_user_id_str" : "16930130",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3315811222",
  "geo" : { },
  "id_str" : "3316036785",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh how easy is it to work with branches with hg-git? I really don't like hg's branching model.",
  "id" : 3316036785,
  "in_reply_to_status_id" : 3315811222,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3316081935",
  "text" : "Video: this doesn\u2019t get old. http:\/\/tumblr.com\/x172p318a",
  "id" : 3316081935,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3316114677",
  "text" : "Videos that disable embedding suck.",
  "id" : 3316114677,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3316210392",
  "geo" : { },
  "id_str" : "3316799772",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh I need to try out hg more, but: http:\/\/bit.ly\/AoIGq",
  "id" : 3316799772,
  "in_reply_to_status_id" : 3316210392,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 3, 13 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IE6",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3317668279",
  "text" : "RT @stevelosh Microsoft will support #IE6 until 2014: http:\/\/news.bbc.co.uk\/2\/hi\/... FFFFFFFFFUUUUUUUUUUU",
  "id" : 3317668279,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3297120606",
  "text" : "Photo:  http:\/\/tumblr.com\/x172oouf9",
  "id" : 3297120606,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3298752813",
  "text" : "Link: www.fuckingmoviereviews.com\/... http:\/\/tumblr.com\/x172oq353",
  "id" : 3298752813,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Yates",
      "screen_name" : "fredyatesiv",
      "indices" : [ 0, 12 ],
      "id_str" : "11886642",
      "id" : 11886642
    }, {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 21, 28 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3298793999",
  "geo" : { },
  "id_str" : "3298862986",
  "in_reply_to_user_id" : 11886642,
  "text" : "@fredyatesiv i blame @Croaky.",
  "id" : 3298862986,
  "in_reply_to_status_id" : 3298793999,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "fredyatesiv",
  "in_reply_to_user_id_str" : "11886642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3300617989",
  "text" : "Photo:  http:\/\/tumblr.com\/x172oriw8",
  "id" : 3300617989,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3301345762",
  "text" : "Little known facts: searching for \"flux capacitor\" brings up ads for eBay motors.",
  "id" : 3301345762,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3301834971",
  "text" : "I'm definitely not a real man. http:\/\/bit.ly\/h9h2s",
  "id" : 3301834971,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3307329200",
  "text" : "\"Pretty soon, all programming will be web programming. If you don\u2019t think that\u2019s a cause for celebration...\" http:\/\/tumblr.com\/x172oxcep",
  "id" : 3307329200,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3310540090",
  "text" : "Video:  http:\/\/tumblr.com\/x172ozct7",
  "id" : 3310540090,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3310631935",
  "text" : "Video: I\u2019m moving to Japan. http:\/\/tumblr.com\/x172ozesg",
  "id" : 3310631935,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3312447979",
  "geo" : { },
  "id_str" : "3312511164",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash That class was a joke, complete injustice to both languages. I hope this opinion is based on other experiences.",
  "id" : 3312511164,
  "in_reply_to_status_id" : 3312447979,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3312736859",
  "text" : "Lerxst Rants - This is the \u201Cstream of consciousness\u201D part of the song. There\u2019s an entire playlist of these... http:\/\/tumblr.com\/x172p0sbz",
  "id" : 3312736859,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3313993799",
  "text" : "Visiting a site that's ASP, uses tables, and was definitely designed +10 years ago. Somehow, these always fit together.",
  "id" : 3313993799,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 0, 10 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3315440465",
  "geo" : { },
  "id_str" : "3315515030",
  "in_reply_to_user_id" : 7921582,
  "text" : "@bscofield welcome to boston!",
  "id" : 3315515030,
  "in_reply_to_status_id" : 3315440465,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "bscofield",
  "in_reply_to_user_id_str" : "7921582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "github",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3315759380",
  "text" : "\"does anyone use git without github though?\" - #github http:\/\/tumblr.com\/x172p2sqq",
  "id" : 3315759380,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 16, 27 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3278514139",
  "text" : "Came out #2 for @thoughtbot poker. We should definitely had done that more often.",
  "id" : 3278514139,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3285957503",
  "text" : "Awesome post about DVCS and inflexibility: http:\/\/bit.ly\/mm66b",
  "id" : 3285957503,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3285975783",
  "text" : "Slightly derailed freight train on the track next to the commuter rail in Lawrence. Luckily, it didn't roll over onto our track.",
  "id" : 3285975783,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3287475714",
  "text" : "Has anyone heard of a ruby net\/http way to get upload status? I'd love to get a progress bar when pushing gems on @rubygemcutter.",
  "id" : 3287475714,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3287546213",
  "geo" : { },
  "id_str" : "3287580300",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck yes, a POST and just plain 'ol net\/http.",
  "id" : 3287580300,
  "in_reply_to_status_id" : 3287546213,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3287658009",
  "geo" : { },
  "id_str" : "3287799027",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck I'm not so sure that's ideal...i'm not doing multipart post and the problem is how much of the file has been uploaded, not read",
  "id" : 3287799027,
  "in_reply_to_status_id" : 3287658009,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3291518021",
  "text" : "Stupid ruby tricks. Do you have any? http:\/\/bit.ly\/KmnXJ",
  "id" : 3291518021,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3292491929",
  "text" : "Photo:  http:\/\/tumblr.com\/x172olkek",
  "id" : 3292491929,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Angilly",
      "screen_name" : "angilly",
      "indices" : [ 0, 8 ],
      "id_str" : "16195791",
      "id" : 16195791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3293404628",
  "geo" : { },
  "id_str" : "3293512717",
  "in_reply_to_user_id" : 16195791,
  "text" : "@angilly We can make it, let's leave now.",
  "id" : 3293512717,
  "in_reply_to_status_id" : 3293404628,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "angilly",
  "in_reply_to_user_id_str" : "16195791",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomayko",
      "screen_name" : "rtomayko",
      "indices" : [ 0, 9 ],
      "id_str" : "9267332",
      "id" : 9267332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3294147179",
  "geo" : { },
  "id_str" : "3294185389",
  "in_reply_to_user_id" : 9267332,
  "text" : "@rtomayko Thanks man!",
  "id" : 3294185389,
  "in_reply_to_status_id" : 3294147179,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "rtomayko",
  "in_reply_to_user_id_str" : "9267332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Ruby Group",
      "screen_name" : "bostonrb",
      "indices" : [ 16, 25 ],
      "id_str" : "21431343",
      "id" : 21431343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3258410597",
  "text" : "Another awesome @bostonrb meeting\/cbc trip. Thanks for making it so much fun!",
  "id" : 3258410597,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3265015054",
  "text" : "I'm still not getting LinkedIn. Especially when people who haven't contacted me in years want to \"connect\".",
  "id" : 3265015054,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3266465278",
  "geo" : { },
  "id_str" : "3266708569",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh gitweb sucks. ginatra is nice, but github is the best :) http:\/\/ginatra.lenary.co.uk\/",
  "id" : 3266708569,
  "in_reply_to_status_id" : 3266465278,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaroslav Markin",
      "screen_name" : "yaroslav",
      "indices" : [ 0, 9 ],
      "id_str" : "7605802",
      "id" : 7605802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3268440632",
  "geo" : { },
  "id_str" : "3268554070",
  "in_reply_to_user_id" : 7605802,
  "text" : "@yaroslav http:\/\/tinyrobots.thoughtbot.com\/post\/118622270",
  "id" : 3268554070,
  "in_reply_to_status_id" : 3268440632,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "yaroslav",
  "in_reply_to_user_id_str" : "7605802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 46, 55 ],
      "id_str" : "18230025",
      "id" : 18230025
    }, {
      "name" : "PaulSolt",
      "screen_name" : "PaulSolt",
      "indices" : [ 57, 66 ],
      "id_str" : "14683259",
      "id" : 14683259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3268749174",
  "text" : "RIT's Gmail is up! http:\/\/google.rit.edu (via @marcweil, @PaulSolt). Oh wait, I've been using gmail with RIT since I was a freshman.",
  "id" : 3268749174,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3270110241",
  "text" : "$600 to fly anywhere for a month. This is tempting. http:\/\/bit.ly\/1efmH8",
  "id" : 3270110241,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "augustl4j",
      "screen_name" : "augustl",
      "indices" : [ 0, 8 ],
      "id_str" : "870091423",
      "id" : 870091423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "offrails",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3271187432",
  "text" : "@augustl referring to #offrails? :[",
  "id" : 3271187432,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3272523269",
  "geo" : { },
  "id_str" : "3272583080",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano You still have to wait for mirroring. Enter: http:\/\/gemcutter.org",
  "id" : 3272583080,
  "in_reply_to_status_id" : 3272523269,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3240109573",
  "text" : "Just got `gem migrate &lt;yourgem&gt;` working for @rubygemcutter! woot! One step closer to beta.",
  "id" : 3240109573,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3240225317",
  "text" : "So yeah, if you've got a project on RubyForge: gem install gemcutter -s http:\/\/gemcutter.org; gem migrate yourgem",
  "id" : 3240225317,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Riteau",
      "screen_name" : "priteau",
      "indices" : [ 98, 106 ],
      "id_str" : "18118060",
      "id" : 18118060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3244372900",
  "text" : "Just migrated a gem from Rubyforge to http:\/\/gemcutter.org. The process is totally seamless. (via @priteau) woot!",
  "id" : 3244372900,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3248543471",
  "geo" : { },
  "id_str" : "3248576314",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg Where?!",
  "id" : 3248576314,
  "in_reply_to_status_id" : 3248543471,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3250806720",
  "geo" : { },
  "id_str" : "3250864187",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps Twitter's backend is mostly Scala now. http:\/\/bit.ly\/x2Irj",
  "id" : 3250864187,
  "in_reply_to_status_id" : 3250806720,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3251792030",
  "text" : "This relationship is headed for an EPIC FAIL http:\/\/bit.ly\/1ae69A",
  "id" : 3251792030,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3252993474",
  "text" : "google on ROIDS: http:\/\/www2.sandbox.google.com\/",
  "id" : 3252993474,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubiojr",
      "screen_name" : "rubiojr",
      "indices" : [ 0, 8 ],
      "id_str" : "9757562",
      "id" : 9757562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3225860048",
  "in_reply_to_user_id" : 9757562,
  "text" : "@rubiojr Glad you're liking it! :) Let me know if you're having issues with the site.",
  "id" : 3225860048,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "rubiojr",
  "in_reply_to_user_id_str" : "9757562",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat McDermott",
      "screen_name" : "nerdofthunder",
      "indices" : [ 0, 14 ],
      "id_str" : "14457987",
      "id" : 14457987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3227822072",
  "geo" : { },
  "id_str" : "3227855396",
  "in_reply_to_user_id" : 14457987,
  "text" : "@nerdofthunder Agreed. Dibella's subs &gt; Wegmans.",
  "id" : 3227855396,
  "in_reply_to_status_id" : 3227822072,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "nerdofthunder",
  "in_reply_to_user_id_str" : "14457987",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3230447184",
  "text" : "Ruby 1.8.6 is 50% faster on Linux than Windows, 1.9.1 is 70% faster. http:\/\/is.gd\/2aMxY Who seriously does Ruby and uses Windows?",
  "id" : 3230447184,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Nichols",
      "screen_name" : "techpickles",
      "indices" : [ 60, 72 ],
      "id_str" : "6556972",
      "id" : 6556972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3201584808",
  "text" : "Commit number dos to Rails, co-authored by the one and only @techpickles: http:\/\/is.gd\/28zcz",
  "id" : 3201584808,
  "created_at" : "2009-08-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 0, 7 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3202147943",
  "in_reply_to_user_id" : 787595,
  "text" : "@Croaky dude, stop reading those Snapple bottlecaps. they're all lies.",
  "id" : 3202147943,
  "created_at" : "2009-08-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Croaky",
  "in_reply_to_user_id_str" : "787595",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3192385549",
  "text" : "Heading out for some BUGMASH at the thoughtbot office. Driving &gt; taking the train.",
  "id" : 3192385549,
  "created_at" : "2009-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3193213434",
  "text" : "bugmash is on at the tbot office, woot!",
  "id" : 3193213434,
  "created_at" : "2009-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3198274673",
  "text" : "Woot, first rails patch! http:\/\/github.com\/rails\/rails\/commit\/5786395760f1e1906c878df4023cac3741e66e87",
  "id" : 3198274673,
  "created_at" : "2009-08-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3180970548",
  "text" : "New headphones FTW!",
  "id" : 3180970548,
  "created_at" : "2009-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3184285583",
  "text" : "I just instance_eval'd that &block LIKE A BOSS",
  "id" : 3184285583,
  "created_at" : "2009-08-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3171043253",
  "text" : "Commuter rail train stuck at Ballardvalle...being told that another train is going to latch on and shove it out of the way for us.",
  "id" : 3171043253,
  "created_at" : "2009-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3168636295",
  "text" : "This is way too much fun. http:\/\/translationparty.com\/",
  "id" : 3168636295,
  "created_at" : "2009-08-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3138406513",
  "text" : "Lesson learned: Use 'digest' when signing a Twitter account up for GitHub post-receive hooks. Or else.",
  "id" : 3138406513,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3139194656",
  "text" : "kill -9, no more CPU time",
  "id" : 3139194656,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3144384052",
  "text" : "I might blog a lot, but I still suck at copywriting.",
  "id" : 3144384052,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kane",
      "screen_name" : "codemastermm",
      "indices" : [ 0, 13 ],
      "id_str" : "15375238",
      "id" : 15375238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3150772413",
  "geo" : { },
  "id_str" : "3150830589",
  "in_reply_to_user_id" : 15375238,
  "text" : "@codemastermm Obviously, the reviewers are all COBRA agents.",
  "id" : 3150830589,
  "in_reply_to_status_id" : 3150772413,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "codemastermm",
  "in_reply_to_user_id_str" : "15375238",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    }, {
      "name" : "Git Ready",
      "screen_name" : "gitready",
      "indices" : [ 94, 103 ],
      "id_str" : "19297751",
      "id" : 19297751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3151063655",
  "geo" : { },
  "id_str" : "3151130325",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer Haven't played with that before. If you find any, pass it along, it'll be great for @gitready.",
  "id" : 3151130325,
  "in_reply_to_status_id" : 3151063655,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3151336789",
  "text" : "Whenever I do \"rake db:reset RAILS_ENV=production\" on my local machine, a little part of me screams bloody murder",
  "id" : 3151336789,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Schoolcraft",
      "screen_name" : "jschoolcraft",
      "indices" : [ 0, 13 ],
      "id_str" : "14225666",
      "id" : 14225666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3123276553",
  "geo" : { },
  "id_str" : "3123537018",
  "in_reply_to_user_id" : 14225666,
  "text" : "@jschoolcraft I don't keep hoptoad private (what's the point?), but for S3 I just stick the secret and key in my ENV.",
  "id" : 3123537018,
  "in_reply_to_status_id" : 3123276553,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "jschoolcraft",
  "in_reply_to_user_id_str" : "14225666",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3124467059",
  "geo" : { },
  "id_str" : "3125709383",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg jacknifed bobcat on the 5, SLOOOOOOOOOOOOW AND GO. split load of oranges slaaaaablahblahblahblah",
  "id" : 3125709383,
  "in_reply_to_status_id" : 3124467059,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3095066916",
  "text" : "Gemcutter's first blog post, in Japanese: http:\/\/is.gd\/1ZI2c",
  "id" : 3095066916,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Burg",
      "screen_name" : "kevinburg",
      "indices" : [ 0, 10 ],
      "id_str" : "10852412",
      "id" : 10852412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3097457397",
  "geo" : { },
  "id_str" : "3097618459",
  "in_reply_to_user_id" : 10852412,
  "text" : "@kevinburg LIGHTNING ROUND! Ace Rockola bringing you TRAFFIC AND WEATHER, TRAFFIC AND WEATHER, TRAFFIC AND WEATHER!!!",
  "id" : 3097618459,
  "in_reply_to_status_id" : 3097457397,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevinburg",
  "in_reply_to_user_id_str" : "10852412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3099213151",
  "text" : "The club nearby started a concert (AT 1AM) that is ridiculously loud and woke @ablissfulgal and I up. Don't these people have jobs?",
  "id" : 3099213151,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3102623771",
  "text" : "What college didn't teach you about programming, or, why to go to a coop school: http:\/\/is.gd\/20rwD",
  "id" : 3102623771,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3103995996",
  "text" : "FALCON KICK! http:\/\/img25.imageshack.us\/img25\/2656\/22473080xf6.jpg REFLECT! http:\/\/imgur.com\/d376K.png",
  "id" : 3103995996,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Woods",
      "screen_name" : "bryanwoods",
      "indices" : [ 0, 11 ],
      "id_str" : "11857402",
      "id" : 11857402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3107356821",
  "geo" : { },
  "id_str" : "3107418015",
  "in_reply_to_user_id" : 11857402,
  "text" : "@bryanwoods We are, it's called IRC.",
  "id" : 3107418015,
  "in_reply_to_status_id" : 3107356821,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "bryanwoods",
  "in_reply_to_user_id_str" : "11857402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Miller, Jr.",
      "screen_name" : "saigonnezumi",
      "indices" : [ 0, 13 ],
      "id_str" : "14710509",
      "id" : 14710509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3104952815",
  "geo" : { },
  "id_str" : "3107441648",
  "in_reply_to_user_id" : 14710509,
  "text" : "@saigonnezumi Yes, I use jekyll :) If you've got any questions, toss em here: http:\/\/groups.google.com\/group\/jekyll-rb",
  "id" : 3107441648,
  "in_reply_to_status_id" : 3104952815,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "saigonnezumi",
  "in_reply_to_user_id_str" : "14710509",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3078397936",
  "text" : "Funny People was more people than funny.",
  "id" : 3078397936,
  "created_at" : "2009-08-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
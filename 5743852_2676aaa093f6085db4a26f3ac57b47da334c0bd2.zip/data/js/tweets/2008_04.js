Grailbird.data.tweets_2008_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800788229",
  "geo" : { },
  "id_str" : "800802123",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome Looks like several already have...I'd prefer a desktop app though.",
  "id" : 800802123,
  "in_reply_to_status_id" : 800788229,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800808308",
  "text" : "Anyone else remember Book It with Pizza Hut? This blogger feels the incentive of acquiring knowledge is greater than pizza. http:\/\/is.gd\/aJV",
  "id" : 800808308,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800861275",
  "text" : "I haven't made an index card crib sheet for a test since high school. It's sad that i'm doing it now 3 years into college.",
  "id" : 800861275,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800867231",
  "text" : "Getting off the grid. Too much to do tonight.",
  "id" : 800867231,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800947447",
  "text" : "Twitter, I'm trying to get work done. Dammit.",
  "id" : 800947447,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800955310",
  "text" : "Awesome rant by Joel: http:\/\/is.gd\/aNo Even more of a reason to avoid MS employment after graduation. As if I needed another.",
  "id" : 800955310,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Buckbee",
      "screen_name" : "mbuckbee",
      "indices" : [ 0, 9 ],
      "id_str" : "5972282",
      "id" : 5972282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800958246",
  "geo" : { },
  "id_str" : "800960015",
  "in_reply_to_user_id" : 5972282,
  "text" : "@mbuckbee  I'm starting to envision Live Mesh as the Borg's plot to assimilate our data to the hive mind. Luckily, resistance isn't futile.",
  "id" : 800960015,
  "in_reply_to_status_id" : 800958246,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mbuckbee",
  "in_reply_to_user_id_str" : "5972282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 0, 6 ],
      "id_str" : "5774462",
      "id" : 5774462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800961917",
  "geo" : { },
  "id_str" : "800963295",
  "in_reply_to_user_id" : 5774462,
  "text" : "@grigs Maybe you don't know how OpenID auth works? Your auth provider handles all login info, it just passes back a token for WP to process.",
  "id" : 800963295,
  "in_reply_to_status_id" : 800961917,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "grigs",
  "in_reply_to_user_id_str" : "5774462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 0, 6 ],
      "id_str" : "5774462",
      "id" : 5774462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800961917",
  "geo" : { },
  "id_str" : "800963620",
  "in_reply_to_user_id" : 5774462,
  "text" : "@grigs Oh, sorry, didn't see your most recent tweet. That blows. Perhaps there's a newer plugin?",
  "id" : 800963620,
  "in_reply_to_status_id" : 800961917,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "grigs",
  "in_reply_to_user_id_str" : "5774462",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800963901",
  "geo" : { },
  "id_str" : "800964303",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway I'm sort of meh about them. Didn't see any that would really bring me back to the portal homepage.",
  "id" : 800964303,
  "in_reply_to_status_id" : 800963901,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800965962",
  "text" : "Test studied for, paper written (not proofread, will need to do that), and raytracer reflected. Great success! Can I has sleep now plz?",
  "id" : 800965962,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Evans",
      "screen_name" : "paulecoyote",
      "indices" : [ 0, 12 ],
      "id_str" : "7065942",
      "id" : 7065942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801028228",
  "geo" : { },
  "id_str" : "801220688",
  "in_reply_to_user_id" : 7065942,
  "text" : "@paulecoyote That's debatable. Right now I'm not planning on moving to SF or NYC, so I doubt it will be very high.",
  "id" : 801220688,
  "in_reply_to_status_id" : 801028228,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "paulecoyote",
  "in_reply_to_user_id_str" : "7065942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801225618",
  "text" : "My professor warned me that his BS radar was going off when correcting my test on information systems. Maybe it's just because I hate Java.",
  "id" : 801225618,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "jesmith81",
      "indices" : [ 0, 10 ],
      "id_str" : "7775872",
      "id" : 7775872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801223502",
  "geo" : { },
  "id_str" : "801225940",
  "in_reply_to_user_id" : 7775872,
  "text" : "@jesmith81 Do you really have to pay your bills?",
  "id" : 801225940,
  "in_reply_to_status_id" : 801223502,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "jesmith81",
  "in_reply_to_user_id_str" : "7775872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Moore",
      "screen_name" : "abiteofsanity",
      "indices" : [ 0, 14 ],
      "id_str" : "954792990",
      "id" : 954792990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801228975",
  "text" : "@abiteofsanity I think I prefer this bash.org quote instead: http:\/\/bash.org\/?338364",
  "id" : 801228975,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just A Sun God",
      "screen_name" : "JustaSunGod",
      "indices" : [ 0, 12 ],
      "id_str" : "11390722",
      "id" : 11390722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801227442",
  "geo" : { },
  "id_str" : "801229591",
  "in_reply_to_user_id" : 11390722,
  "text" : "@JustaSunGod I'm capable of doing Java, but I'd just rather not if I have a choice. Thankfully that choice is usually available.",
  "id" : 801229591,
  "in_reply_to_status_id" : 801227442,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustaSunGod",
  "in_reply_to_user_id_str" : "11390722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Cole",
      "screen_name" : "samuelcole",
      "indices" : [ 0, 11 ],
      "id_str" : "12188",
      "id" : 12188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801240473",
  "geo" : { },
  "id_str" : "801241633",
  "in_reply_to_user_id" : 12188,
  "text" : "@samuelcole I'm not sure how accurate that fact is. I think it's only if you join a huge corporation like MS or Google.",
  "id" : 801241633,
  "in_reply_to_status_id" : 801240473,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "samuelcole",
  "in_reply_to_user_id_str" : "12188",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801242908",
  "text" : "CNN, way to report the real news: http:\/\/tinyurl.com\/6zocwk",
  "id" : 801242908,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Adkins",
      "screen_name" : "leeadkins",
      "indices" : [ 0, 10 ],
      "id_str" : "2895081",
      "id" : 2895081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801244091",
  "geo" : { },
  "id_str" : "801268976",
  "in_reply_to_user_id" : 2895081,
  "text" : "@leeadkins It's easy to teach many basic CS principles with, be it OO, threading, networking, GUIs, and so on. Great for learning.",
  "id" : 801268976,
  "in_reply_to_status_id" : 801244091,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "leeadkins",
  "in_reply_to_user_id_str" : "2895081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800969732",
  "geo" : { },
  "id_str" : "801269799",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton You've inspired me to look into finding a new WP theme and spending more time on my blog. Now I just need to find that time....",
  "id" : 801269799,
  "in_reply_to_status_id" : 800969732,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Adkins",
      "screen_name" : "leeadkins",
      "indices" : [ 0, 10 ],
      "id_str" : "2895081",
      "id" : 2895081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801274366",
  "geo" : { },
  "id_str" : "801279318",
  "in_reply_to_user_id" : 2895081,
  "text" : "@leeadkins Heh, I wish I actually had a grasp on pointers. I still need to run through K&R someday...",
  "id" : 801279318,
  "in_reply_to_status_id" : 801274366,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "leeadkins",
  "in_reply_to_user_id_str" : "2895081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801318108",
  "geo" : { },
  "id_str" : "801365152",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton ehhhh. That would just be fugly.",
  "id" : 801365152,
  "in_reply_to_status_id" : 801318108,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801436905",
  "geo" : { },
  "id_str" : "801437639",
  "in_reply_to_user_id" : 7488582,
  "text" : "@runeinalya I've never understood why Wild Wings is so damn slow. I tend to find that taking out food is faster than sitting in.",
  "id" : 801437639,
  "in_reply_to_status_id" : 801436905,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Brewster",
      "screen_name" : "Adora",
      "indices" : [ 0, 6 ],
      "id_str" : "781730",
      "id" : 781730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801477495",
  "geo" : { },
  "id_str" : "801478907",
  "in_reply_to_user_id" : 781730,
  "text" : "@adora digging the blog redesign, i've been hunting for themes all day and I can't seem to find a perfect one.",
  "id" : 801478907,
  "in_reply_to_status_id" : 801477495,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Adora",
  "in_reply_to_user_id_str" : "781730",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Brewster",
      "screen_name" : "Adora",
      "indices" : [ 0, 6 ],
      "id_str" : "781730",
      "id" : 781730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801481353",
  "geo" : { },
  "id_str" : "801483342",
  "in_reply_to_user_id" : 781730,
  "text" : "@Adora Thanks for the tip! I'll be sure to check them out.",
  "id" : 801483342,
  "in_reply_to_status_id" : 801481353,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Adora",
  "in_reply_to_user_id_str" : "781730",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Thorp",
      "screen_name" : "thorpus",
      "indices" : [ 0, 8 ],
      "id_str" : "71903",
      "id" : 71903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801488159",
  "geo" : { },
  "id_str" : "801490750",
  "in_reply_to_user_id" : 71903,
  "text" : "@thorpus Valid point, but let's have the stats speak...if more people look at his website than the RSS feed than it's more than worth it.",
  "id" : 801490750,
  "in_reply_to_status_id" : 801488159,
  "created_at" : "2008-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "thorpus",
  "in_reply_to_user_id_str" : "71903",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800679312",
  "geo" : { },
  "id_str" : "800741634",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco http:\/\/tinyurl.com\/62ny3d",
  "id" : 800741634,
  "in_reply_to_status_id" : 800679312,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800775704",
  "text" : "Anyone know of decent Windows widgets\/apps that use the Basecamp API?",
  "id" : 800775704,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800777111",
  "text" : "Correction: Backpack API. Not Basecamp.",
  "id" : 800777111,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800784756",
  "geo" : { },
  "id_str" : "800786300",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome yeah it looks dumb though. I might make my own in WPF.",
  "id" : 800786300,
  "in_reply_to_status_id" : 800784756,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shella",
      "screen_name" : "Shella",
      "indices" : [ 0, 7 ],
      "id_str" : "814306",
      "id" : 814306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799891287",
  "geo" : { },
  "id_str" : "799963409",
  "in_reply_to_user_id" : 814306,
  "text" : "@Shella I concur. I hate the water temple though, but I'd play it over just for some of the other awesome dungeons. (Forest rules!)",
  "id" : 799963409,
  "in_reply_to_status_id" : 799891287,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Shella",
  "in_reply_to_user_id_str" : "814306",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799964568",
  "text" : "Hey, twitter web interface. I'm absolutely sick of you losing my tweets.",
  "id" : 799964568,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 34, 39 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800137198",
  "text" : "I splurged and bought the TV from @woot. Definitely not touching GTA4 again until it arrives.",
  "id" : 800137198,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800348187",
  "text" : "GTA4 is calling me. Haunting me.",
  "id" : 800348187,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800356368",
  "text" : "I love visual studio's ''' and \/\/\/ automatic commenting. I know Eclipse has it too, but there's something satisfying in it.",
  "id" : 800356368,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800360989",
  "text" : "I'm a moron. This USENET post by Jeff Bezos was from 1994, not 2008. Interesting piece of history though. http:\/\/is.gd\/asC",
  "id" : 800360989,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Hynes",
      "screen_name" : "heathershae",
      "indices" : [ 0, 12 ],
      "id_str" : "1049301",
      "id" : 1049301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800366845",
  "geo" : { },
  "id_str" : "800371927",
  "in_reply_to_user_id" : 1049301,
  "text" : "@heathershae I'll bug @ablissfulgal to follow you tonight.",
  "id" : 800371927,
  "in_reply_to_status_id" : 800366845,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "heathershae",
  "in_reply_to_user_id_str" : "1049301",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800431569",
  "text" : "Holy crap, it's May tomorrow.",
  "id" : 800431569,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800492023",
  "text" : "I'm having flashbacks to the first loop I wrote in VB6\/ASP. I remember finding it a year and a half later and being appalled.",
  "id" : 800492023,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800494962",
  "geo" : { },
  "id_str" : "800499055",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Impossible. It was 45 degrees out. I think you're hallucinating.",
  "id" : 800499055,
  "in_reply_to_status_id" : 800494962,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800457103",
  "geo" : { },
  "id_str" : "800500735",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk hey, how did that java thing go? or did you failboat it?",
  "id" : 800500735,
  "in_reply_to_status_id" : 800457103,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800195708",
  "geo" : { },
  "id_str" : "800509103",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Awesome post and tutorial about how to use OpenID. I really need to install the WP plugin for it.",
  "id" : 800509103,
  "in_reply_to_status_id" : 800195708,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 11, 19 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800510829",
  "text" : "Retweeting @iGexome ITS SNOWING OH MY GOD ITS SNOWING",
  "id" : 800510829,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800670677",
  "text" : "Reflection on my raytracer. (somewhat) DONE.",
  "id" : 800670677,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800673336",
  "geo" : { },
  "id_str" : "800677093",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Hey, I fixed the dumb shadow bit. By just ignoring it.",
  "id" : 800677093,
  "in_reply_to_status_id" : 800673336,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800682405",
  "text" : "Must stop watching Rush videos and get to the assloads of work I need to get done.",
  "id" : 800682405,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800688425",
  "text" : "Anyone use 37signals' Backpack for personal stuff, and how does it help?",
  "id" : 800688425,
  "created_at" : "2008-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799133899",
  "text" : "This is a bit old, but hilarious. South Park kills 10 YouTube viral videos. http:\/\/is.gd\/9QX",
  "id" : 799133899,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bacigalupo",
      "screen_name" : "tonybgoode",
      "indices" : [ 0, 11 ],
      "id_str" : "2852911",
      "id" : 2852911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799161086",
  "geo" : { },
  "id_str" : "799164134",
  "in_reply_to_user_id" : 2852911,
  "text" : "@tonybgoode Good idea, mostly for identifying. Usually I still like to introduce myself and ask for names despite what they may be wearing.",
  "id" : 799164134,
  "in_reply_to_status_id" : 799161086,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "tonybgoode",
  "in_reply_to_user_id_str" : "2852911",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799182309",
  "text" : "I've been doing a lot of reading about software engineering processes: Waterfall, Code and fix, Spiral...what do most OSS projects go with?",
  "id" : 799182309,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799223613",
  "text" : "at least 100 in the gamestop line already. who knows about eb games",
  "id" : 799223613,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry O'Brien",
      "screen_name" : "lobrien",
      "indices" : [ 0, 8 ],
      "id_str" : "6151482",
      "id" : 6151482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799507705",
  "geo" : { },
  "id_str" : "799534564",
  "in_reply_to_user_id" : 6151482,
  "text" : "@lobrien Thanks for responding! I was mostly wondering if they even had a process in the first place. I know most have release schedules.",
  "id" : 799534564,
  "in_reply_to_status_id" : 799507705,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "lobrien",
  "in_reply_to_user_id_str" : "6151482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Colligan",
      "screen_name" : "colligan",
      "indices" : [ 0, 9 ],
      "id_str" : "511283",
      "id" : 511283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799541624",
  "geo" : { },
  "id_str" : "799542286",
  "in_reply_to_user_id" : 511283,
  "text" : "@colligan I'll take two to go please.",
  "id" : 799542286,
  "in_reply_to_status_id" : 799541624,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "colligan",
  "in_reply_to_user_id_str" : "511283",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799545099",
  "text" : "I'm convinced that software engineering metrics are pointless. Anyone actually have a story of how they are useful in industry?",
  "id" : 799545099,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799579933",
  "text" : "It's free cone day at Ben and Jerry's on campus and it's definitely not on the way to anything I have to get done today.",
  "id" : 799579933,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799601714",
  "geo" : { },
  "id_str" : "799603626",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Epic battles like that are common happenings in Nethack. I am liking Shiren a lot though.",
  "id" : 799603626,
  "in_reply_to_status_id" : 799601714,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799630689",
  "text" : "One of the achievements in GTA4 is playing with a Rockstar Developer. That will be sure to frustrate many a Gamerscore whore.",
  "id" : 799630689,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Brogan",
      "screen_name" : "chrisbrogan",
      "indices" : [ 0, 12 ],
      "id_str" : "10202",
      "id" : 10202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799631711",
  "geo" : { },
  "id_str" : "799638084",
  "in_reply_to_user_id" : 10202,
  "text" : "@chrisbrogan Hey CrossTech!",
  "id" : 799638084,
  "in_reply_to_status_id" : 799631711,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrisbrogan",
  "in_reply_to_user_id_str" : "10202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799636882",
  "geo" : { },
  "id_str" : "799639313",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton Awesome post. If I didn't have an exam, paper, and huge programming assignment this week along with 20+ hours of work, I'd blog",
  "id" : 799639313,
  "in_reply_to_status_id" : 799636882,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799638424",
  "geo" : { },
  "id_str" : "799641389",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman That just seems silly...can't Java do 301 redirects? Someday RESTful design will catch on...",
  "id" : 799641389,
  "in_reply_to_status_id" : 799638424,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799646779",
  "geo" : { },
  "id_str" : "799647748",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I think we need to get a GTA match going tonight.",
  "id" : 799647748,
  "in_reply_to_status_id" : 799646779,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799717193",
  "geo" : { },
  "id_str" : "799720364",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor thanks for the follow, and good luck!",
  "id" : 799720364,
  "in_reply_to_status_id" : 799717193,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799744880",
  "text" : "Urge to play GTA4 rising...must wait...6 hours...",
  "id" : 799744880,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799745936",
  "geo" : { },
  "id_str" : "799748918",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike I already have it for Xbox 360, work and plenty of homework is impeding me. :)",
  "id" : 799748918,
  "in_reply_to_status_id" : 799745936,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799749707",
  "text" : "Listening to Opie and Anthony, not exactly live, but still hilarious.",
  "id" : 799749707,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799763958",
  "geo" : { },
  "id_str" : "799776625",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike Doctor Q, whats yours. and there's a space in there.",
  "id" : 799776625,
  "in_reply_to_status_id" : 799763958,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799783377",
  "text" : "Holy crap. Ocarina of Time is almost 10 years old. I remember being so excited and reading Nintendo Power reviews. Not much has changed, eh?",
  "id" : 799783377,
  "created_at" : "2008-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csharp",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798705483",
  "text" : "Horrifying code seen in ##csharp: Dictionary&lt;string, List&lt;Dictionary&lt;int, List&lt;ProductObject&gt;&gt;&gt;&gt; HostingOptionsD ...",
  "id" : 798705483,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798705893",
  "text" : "Trying to figure out why Twitter is sticking \"...\" after my last tweet.",
  "id" : 798705893,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798710608",
  "geo" : { },
  "id_str" : "798711829",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I need to unearth my USB cable for my phone, I shall do it later today.",
  "id" : 798711829,
  "in_reply_to_status_id" : 798710608,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 11, 22 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798714247",
  "text" : "Retweeting @maslowbeer: no spaces so doesn't know where to newline so truncates instead. clicking on ellipses shows full tweet. Thanks!",
  "id" : 798714247,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798762672",
  "geo" : { },
  "id_str" : "798763522",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal has a job!",
  "id" : 798763522,
  "in_reply_to_status_id" : 798762672,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798787549",
  "text" : "I'm not an xemacs user, but if I was one, Steve Yegge would make me angry. http:\/\/is.gd\/9CI",
  "id" : 798787549,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798808465",
  "text" : "nearly 80 degrees over the weekend, and then 40ish today. What gives.",
  "id" : 798808465,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798844459",
  "text" : "The USA according to rednecks... http:\/\/tinyurl.com\/5lh5q6",
  "id" : 798844459,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csharp",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798852003",
  "text" : "More dumb code from ##csharp, ridiculously long type name:  ListViewVirtualItemsSelectionRangeChangedEventHandler",
  "id" : 798852003,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798914638",
  "text" : "Out of memory error and crash in Eclipse when trying to do a JSP\/J2EE tutorial. Another daily reminder of why I hate Java so much.",
  "id" : 798914638,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798916760",
  "geo" : { },
  "id_str" : "798918144",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome It's for a class project that I have to write up a small reflection for. Not even worth it, but I'll keep it in mind, thanks.",
  "id" : 798918144,
  "in_reply_to_status_id" : 798916760,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Hryb",
      "screen_name" : "majornelson",
      "indices" : [ 0, 12 ],
      "id_str" : "15913",
      "id" : 15913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798964674",
  "geo" : { },
  "id_str" : "798969330",
  "in_reply_to_user_id" : 15913,
  "text" : "@majornelson I hate you. How did you get a copy?",
  "id" : 798969330,
  "in_reply_to_status_id" : 798964674,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "majornelson",
  "in_reply_to_user_id_str" : "15913",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799083905",
  "text" : "Hooked up my xbox to my 1680x1050 monitor and with optical sound for some GTA goodness tonight. It shall be glorious.",
  "id" : 799083905,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798323589",
  "text" : "Updated to Wordpress 2.5.1, quite painless.",
  "id" : 798323589,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798325380",
  "text" : "GoDaddy's site needs a serious usability study. It's so damn busy and filled with images and links that don't matter.",
  "id" : 798325380,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Milton",
      "screen_name" : "Jaxidian",
      "indices" : [ 0, 9 ],
      "id_str" : "14267403",
      "id" : 14267403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798324348",
  "geo" : { },
  "id_str" : "798325542",
  "in_reply_to_user_id" : 14267403,
  "text" : "@Jaxidian Not sure, usually patches are best to upgrade because they plug security holes.",
  "id" : 798325542,
  "in_reply_to_status_id" : 798324348,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jaxidian",
  "in_reply_to_user_id_str" : "14267403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798624641",
  "text" : "2 Benadryl pills last night actually helped me get a decent night of sleep. Didn't help too much with the whole sick as a dog thing though.",
  "id" : 798624641,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798650486",
  "geo" : { },
  "id_str" : "798651017",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog The real question will be, how will you be able to work with Mario Kart and GTA4 sitting there on Wednesday?",
  "id" : 798651017,
  "in_reply_to_status_id" : 798650486,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798652822",
  "text" : "I think I'm going to hold off on buying a $700 TV and just hook my xbox up to my monitor with the $15 VGA cable. Much cheaper. OMG RECESSION",
  "id" : 798652822,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798653383",
  "text" : "Seeing lots of tweets about the Apple Store being down. I'm still amazed at the fact that they can turn downtime into hype.",
  "id" : 798653383,
  "created_at" : "2008-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Sutton",
      "screen_name" : "waynesutton",
      "indices" : [ 0, 12 ],
      "id_str" : "874",
      "id" : 874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797769256",
  "geo" : { },
  "id_str" : "797771350",
  "in_reply_to_user_id" : 874,
  "text" : "@waynesutton You're going to need to do some server side work in order to make that happen, can't get away with it securely client-side only",
  "id" : 797771350,
  "in_reply_to_status_id" : 797769256,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "waynesutton",
  "in_reply_to_user_id_str" : "874",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ike Pigott",
      "screen_name" : "ikepigott",
      "indices" : [ 0, 10 ],
      "id_str" : "496723",
      "id" : 496723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797776171",
  "geo" : { },
  "id_str" : "797776630",
  "in_reply_to_user_id" : 496723,
  "text" : "@ikepigott Don't miss the timeless classic, \"Myspace for Dummies.\"",
  "id" : 797776630,
  "in_reply_to_status_id" : 797776171,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ikepigott",
  "in_reply_to_user_id_str" : "496723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797800076",
  "text" : "I want a new TV for GTA4. Any suggestions?",
  "id" : 797800076,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Grubbs",
      "screen_name" : "DougGrubbs",
      "indices" : [ 0, 11 ],
      "id_str" : "822451266",
      "id" : 822451266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797823958",
  "text" : "@douggrubbs I'm a college student. Are you nuts?",
  "id" : 797823958,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Grubbs",
      "screen_name" : "DougGrubbs",
      "indices" : [ 0, 11 ],
      "id_str" : "822451266",
      "id" : 822451266
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 56, 65 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 66, 73 ],
      "id_str" : "6118872",
      "id" : 6118872
    }, {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 74, 84 ],
      "id_str" : "5278561",
      "id" : 5278561
    }, {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 85, 93 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798294429",
  "text" : "@douggrubbs Yeah, there's quite a few of us on Twitter. @mittense @Zoomba @IslandDog @CariElf",
  "id" : 798294429,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798294494",
  "text" : "I'm looking for some decent rails hosting. Any suggestions?",
  "id" : 798294494,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mgbaron",
      "screen_name" : "mgbaron",
      "indices" : [ 0, 8 ],
      "id_str" : "14288718",
      "id" : 14288718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798296113",
  "geo" : { },
  "id_str" : "798296865",
  "in_reply_to_user_id" : 14288718,
  "text" : "@mgbaron Yeah it's a bit too much. I was hoping for under $50\/month.",
  "id" : 798296865,
  "in_reply_to_status_id" : 798296113,
  "created_at" : "2008-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "mgbaron",
  "in_reply_to_user_id_str" : "14288718",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797408486",
  "text" : "8am is just too early for a saturday.",
  "id" : 797408486,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797693297",
  "text" : "First time in while that I've actually beaten a WC3 tower defense map with my roommate.",
  "id" : 797693297,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Franks",
      "screen_name" : "ariedana",
      "indices" : [ 0, 9 ],
      "id_str" : "1694311",
      "id" : 1694311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797696307",
  "geo" : { },
  "id_str" : "797696659",
  "in_reply_to_user_id" : 1694311,
  "text" : "@ariedana If you're on Windows, try InstantRails. It's Ruby, Rails, Apache, and MySQL all in one download.",
  "id" : 797696659,
  "in_reply_to_status_id" : 797696307,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ariedana",
  "in_reply_to_user_id_str" : "1694311",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797699896",
  "text" : "As someone who hasn't really done much unit testing before, what's the easiest way to incorporate it into daily programming?",
  "id" : 797699896,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Buckbee",
      "screen_name" : "mbuckbee",
      "indices" : [ 0, 9 ],
      "id_str" : "5972282",
      "id" : 5972282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797703358",
  "geo" : { },
  "id_str" : "797704316",
  "in_reply_to_user_id" : 5972282,
  "text" : "@mbuckbee Isn't that double the work though? And don't the tests eventually become a copy of the code? I guess I need to see more examples.",
  "id" : 797704316,
  "in_reply_to_status_id" : 797703358,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mbuckbee",
  "in_reply_to_user_id_str" : "5972282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Buckbee",
      "screen_name" : "mbuckbee",
      "indices" : [ 0, 9 ],
      "id_str" : "5972282",
      "id" : 5972282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797705275",
  "geo" : { },
  "id_str" : "797706463",
  "in_reply_to_user_id" : 5972282,
  "text" : "@mbuckbee I suppose, I guess it's hard to see the benefit, I've learned about it but I haven't seen it in practice yet.",
  "id" : 797706463,
  "in_reply_to_status_id" : 797705275,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mbuckbee",
  "in_reply_to_user_id_str" : "5972282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797709141",
  "geo" : { },
  "id_str" : "797709401",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Yes. http:\/\/usedwigs.com\/tattoos\/",
  "id" : 797709401,
  "in_reply_to_status_id" : 797709141,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797710062",
  "geo" : { },
  "id_str" : "797710760",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton If you've got any decent blogs\/links\/tutorials, I'd appreciate it.",
  "id" : 797710760,
  "in_reply_to_status_id" : 797710062,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797716373",
  "geo" : { },
  "id_str" : "797717218",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton We went over JUnit briefly in a class over a year ago. Currently using RoR, C#, vb.net. Ruby examples would be killer.",
  "id" : 797717218,
  "in_reply_to_status_id" : 797716373,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797721180",
  "text" : "What an awesome company Twitter site. Stardock needs one. http:\/\/twitter.zappos.com\/",
  "id" : 797721180,
  "created_at" : "2008-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796474485",
  "text" : "I got invited to the Windows Live Mesh beta. Still trying to figure out wtf it does or is good for.",
  "id" : 796474485,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796694459",
  "geo" : { },
  "id_str" : "796699845",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee I wonder a lot about that too...I think the key for oneself is to be genuine, and knowing in your heart that you're being true.",
  "id" : 796699845,
  "in_reply_to_status_id" : 796694459,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796699965",
  "text" : "Friday! It's HERE!",
  "id" : 796699965,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796702656",
  "geo" : { },
  "id_str" : "796702952",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera I think they're still around, just perhaps not adding you? :P",
  "id" : 796702952,
  "in_reply_to_status_id" : 796702656,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Milton",
      "screen_name" : "Jaxidian",
      "indices" : [ 0, 9 ],
      "id_str" : "14267403",
      "id" : 14267403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796711138",
  "geo" : { },
  "id_str" : "796713128",
  "in_reply_to_user_id" : 14267403,
  "text" : "@Jaxidian Twhirl or Witty. Twhirl is a great Adobe AIR client, Witty uses WPF.",
  "id" : 796713128,
  "in_reply_to_status_id" : 796711138,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jaxidian",
  "in_reply_to_user_id_str" : "14267403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Stockton",
      "screen_name" : "johnnystock",
      "indices" : [ 0, 12 ],
      "id_str" : "12032162",
      "id" : 12032162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796715349",
  "geo" : { },
  "id_str" : "796717455",
  "in_reply_to_user_id" : 12032162,
  "text" : "@johnnystock I've got a Mesh invite too and haven't figured out what to do with it. I have my own SVN server, so it seems pointless.",
  "id" : 796717455,
  "in_reply_to_status_id" : 796715349,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "johnnystock",
  "in_reply_to_user_id_str" : "12032162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreakingNewsOn",
      "screen_name" : "BreakingNewsOn",
      "indices" : [ 5, 20 ],
      "id_str" : "27867231",
      "id" : 27867231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796800196",
  "text" : "From @BreakingNewsOn: US Def. official: Cargo ship contracted by US Military Sealift Command fired at least one shot toward an Iranian boat.",
  "id" : 796800196,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796805585",
  "text" : "Currently wtf'ing at vb.net's lib keyword. Robbed me of a decent local variable name.",
  "id" : 796805585,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milksama",
      "screen_name" : "milksama",
      "indices" : [ 0, 9 ],
      "id_str" : "14245580",
      "id" : 14245580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796838758",
  "geo" : { },
  "id_str" : "796839100",
  "in_reply_to_user_id" : 14245580,
  "text" : "@milksama Hungarian notation sucks outside of C++. Even in C++ it sucks.",
  "id" : 796839100,
  "in_reply_to_status_id" : 796838758,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "milksama",
  "in_reply_to_user_id_str" : "14245580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Browell",
      "screen_name" : "dbrowell",
      "indices" : [ 11, 20 ],
      "id_str" : "10879802",
      "id" : 10879802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROFLcon",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796845777",
  "text" : "Retweeting @dbrowell: #ROFLcon the LOLcat guy just admitted he doesn't have a cat",
  "id" : 796845777,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796848293",
  "geo" : { },
  "id_str" : "796850081",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco How much was that TV? I need a new one, especially for GTA4",
  "id" : 796850081,
  "in_reply_to_status_id" : 796848293,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice gray",
      "screen_name" : "justice_gray",
      "indices" : [ 0, 13 ],
      "id_str" : "613073028",
      "id" : 613073028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jquery",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796928965",
  "text" : "@justice_gray Great choice! #jquery on freenode is another great resource if you need help",
  "id" : 796928965,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Browell",
      "screen_name" : "dbrowell",
      "indices" : [ 0, 9 ],
      "id_str" : "10879802",
      "id" : 10879802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796937645",
  "geo" : { },
  "id_str" : "796939287",
  "in_reply_to_user_id" : 10879802,
  "text" : "@dbrowell Powerthirst &gt; Brawndo.",
  "id" : 796939287,
  "in_reply_to_status_id" : 796937645,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dbrowell",
  "in_reply_to_user_id_str" : "10879802",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Milton",
      "screen_name" : "Jaxidian",
      "indices" : [ 0, 9 ],
      "id_str" : "14267403",
      "id" : 14267403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796953965",
  "geo" : { },
  "id_str" : "796954695",
  "in_reply_to_user_id" : 14267403,
  "text" : "@Jaxidian I think you want the Overrides keyword on the method.",
  "id" : 796954695,
  "in_reply_to_status_id" : 796953965,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jaxidian",
  "in_reply_to_user_id_str" : "14267403",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797115999",
  "text" : "worst band ever. sounds like the killers then horrifying when the singer starts",
  "id" : 797115999,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 45, 54 ],
      "id_str" : "14237677",
      "id" : 14237677
    }, {
      "name" : "Andrew Brennan",
      "screen_name" : "AB",
      "indices" : [ 59, 62 ],
      "id_str" : "798513",
      "id" : 798513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797116795",
  "text" : "at the paramore\/jimmy eat world concert with @mittense and @ab",
  "id" : 797116795,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 45, 54 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797116866",
  "text" : "at the paramore\/jimmy eat world concert with @mittense and @ablissfulgal",
  "id" : 797116866,
  "created_at" : "2008-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795607060",
  "geo" : { },
  "id_str" : "795608089",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk What's up? I can help out :)",
  "id" : 795608089,
  "in_reply_to_status_id" : 795607060,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795608411",
  "text" : "Engorging myself with a delicious Slurpee. First time since last summer I've had one...",
  "id" : 795608411,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795669994",
  "text" : "twhirl's 0.8 version removed the function key shortcuts and it's really making me angry.",
  "id" : 795669994,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795952674",
  "text" : "Why doesn't Twitter support OpenID?",
  "id" : 795952674,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Ambrose Little",
      "screen_name" : "dotnettemplar",
      "indices" : [ 0, 14 ],
      "id_str" : "22227290",
      "id" : 22227290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795611976",
  "geo" : { },
  "id_str" : "795953072",
  "in_reply_to_user_id" : 10696752,
  "text" : "@dotNetTemplar Going back to the campus religion question, RIT.",
  "id" : 795953072,
  "in_reply_to_status_id" : 795611976,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ambroselittle",
  "in_reply_to_user_id_str" : "10696752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795975128",
  "text" : "We were just asked to assign 'dog points' to different breeds of dogs. How does this relate to software engineering again?",
  "id" : 795975128,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796045384",
  "text" : "Javascript supports octal? What?! http:\/\/tinyurl.com\/6dgd6q",
  "id" : 796045384,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796181362",
  "text" : "Set up @ablissfulgal's new eeePC on the wireless. It's so cute.",
  "id" : 796181362,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796185515",
  "geo" : { },
  "id_str" : "796189318",
  "in_reply_to_user_id" : 7488582,
  "text" : "@runeinalya I didn't get to play with it much besides entering in the WEP key...I shall report back when I get the time...",
  "id" : 796189318,
  "in_reply_to_status_id" : 796185515,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795587531",
  "text" : "Not enjoying the evangelical Christians pushing their religion on campus. And I'm Catholic.",
  "id" : 795587531,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 0, 7 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795547457",
  "geo" : { },
  "id_str" : "795607897",
  "in_reply_to_user_id" : 9993542,
  "text" : "@twhirl New version doesn't have the F-key shortcuts! wtf?",
  "id" : 795607897,
  "in_reply_to_status_id" : 795547457,
  "created_at" : "2008-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "twhirl",
  "in_reply_to_user_id_str" : "9993542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lozanotek",
      "screen_name" : "lozanotek",
      "indices" : [ 11, 21 ],
      "id_str" : "72720195",
      "id" : 72720195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794721619",
  "text" : "Retweeting @lozanotek: mvc - sun style ... http:\/\/snurl.com\/25d7u Shows why Java is really fubar for webdev.",
  "id" : 794721619,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794724189",
  "text" : "Hey Fox News, YOU CANT PROJECT A WINNER WHEN THERE'S BARELY ANY VOTES IN.",
  "id" : 794724189,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Adkins",
      "screen_name" : "leeadkins",
      "indices" : [ 0, 10 ],
      "id_str" : "2895081",
      "id" : 2895081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794725450",
  "geo" : { },
  "id_str" : "794727611",
  "in_reply_to_user_id" : 2895081,
  "text" : "@leeadkins I would love to do some more Rails programming, want to finish up the coding and papers I have to write for me instead? :P",
  "id" : 794727611,
  "in_reply_to_status_id" : 794725450,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "leeadkins",
  "in_reply_to_user_id_str" : "2895081",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795066182",
  "text" : "Woke up late for registration, managed to get in 3\/4 of my classes. Slight failboat.",
  "id" : 795066182,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794863040",
  "geo" : { },
  "id_str" : "795083980",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Asplode is a lot of fun! (Now that it actually runs)",
  "id" : 795083980,
  "in_reply_to_status_id" : 794863040,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795110035",
  "text" : "Hey SL advocates\/zealots, programmming.reddit discussion topic on reasons to use SL needs some help: http:\/\/is.gd\/8gt",
  "id" : 795110035,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe",
      "screen_name" : "cwgabriel",
      "indices" : [ 26, 36 ],
      "id_str" : "14464369",
      "id" : 14464369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795131874",
  "text" : "PennyArcade is on twitter @cwgabriel! nearly 1k followers and Gabe has only been on for a day. Hilarious twitter comic too: http:\/\/is.gd\/8ek",
  "id" : 795131874,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795150503",
  "geo" : { },
  "id_str" : "795155612",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman Just curious what language\/environment are you starting TDD with?",
  "id" : 795155612,
  "in_reply_to_status_id" : 795150503,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795179409",
  "text" : "The county is doing construction work on the corner just outside of my apartment, Painful screeching noises the whole morning BEEP BEEP BEEP",
  "id" : 795179409,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795308589",
  "text" : "For some reason the Communication department deemed it necessary to tell everyone that a graduate got a job. OH BOY.",
  "id" : 795308589,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Nelson",
      "screen_name" : "robertnelson",
      "indices" : [ 0, 13 ],
      "id_str" : "868851",
      "id" : 868851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795325030",
  "geo" : { },
  "id_str" : "795325765",
  "in_reply_to_user_id" : 868851,
  "text" : "@robertnelson Honestly, I wouldn't bother with it. It was neat for a while but towards the end of the game it just sucked.",
  "id" : 795325765,
  "in_reply_to_status_id" : 795325030,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "robertnelson",
  "in_reply_to_user_id_str" : "868851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795327962",
  "text" : "OLPC to scrap Linux for Windows. WHAT?! http:\/\/is.gd\/8me",
  "id" : 795327962,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795328517",
  "geo" : { },
  "id_str" : "795329501",
  "in_reply_to_user_id" : 7488582,
  "text" : "@runeinalya No idea, I'm a Windows user at heart, but it just seems like a strange direction.",
  "id" : 795329501,
  "in_reply_to_status_id" : 795328517,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795277513",
  "geo" : { },
  "id_str" : "795337299",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman Just saw your replies, thanks :)  I'm always interested in the process, especially for .net shops",
  "id" : 795337299,
  "in_reply_to_status_id" : 795277513,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795342105",
  "geo" : { },
  "id_str" : "795343246",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Yeah, I played around with one at BaseCamp. Too slow for me, but I thought the point was to use FOSS on it. Maybe I'm mistaken.",
  "id" : 795343246,
  "in_reply_to_status_id" : 795342105,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795353334",
  "text" : "Lots of anger over the Ozzie Memo: \"Software is dead, long live the web.\" Any thoughts from you .NET\/Windows devs? http:\/\/is.gd\/8n1",
  "id" : 795353334,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Grubbs",
      "screen_name" : "DougGrubbs",
      "indices" : [ 0, 11 ],
      "id_str" : "822451266",
      "id" : 822451266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795355356",
  "text" : "@douggrubbs Try http:\/\/www.twhirl.org",
  "id" : 795355356,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Webster",
      "screen_name" : "paxguy",
      "indices" : [ 11, 18 ],
      "id_str" : "166263113",
      "id" : 166263113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795356433",
  "text" : "Retweeting @Paxguy: Jim Davis digs Garfield Without Garfield.  http:\/\/tinyurl.com\/527d32",
  "id" : 795356433,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795358773",
  "text" : "@scottcreynolds If this is the direction that MS is going, I wonder if it's reason to worry for us at the bottom of the food chain.",
  "id" : 795358773,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Schmulen",
      "screen_name" : "mschmulen",
      "indices" : [ 0, 10 ],
      "id_str" : "10864492",
      "id" : 10864492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795365807",
  "geo" : { },
  "id_str" : "795368060",
  "in_reply_to_user_id" : 10864492,
  "text" : "@mschmulen Interesting, I haven't heard of that before...php backend for .net",
  "id" : 795368060,
  "in_reply_to_status_id" : 795365807,
  "created_at" : "2008-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mschmulen",
  "in_reply_to_user_id_str" : "10864492",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793979785",
  "text" : "I don't get burnt out. I just slowly fizzle.",
  "id" : 793979785,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794317254",
  "text" : "I need to register for classes for next year. Tomorrow.",
  "id" : 794317254,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794364541",
  "text" : "Starting to grow sick of all of the project management stuff I'm learning in SE classes but I'd rather learn this than esoteric theories....",
  "id" : 794364541,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794444960",
  "text" : "Watching Harry met Sally in a class. By watching I mean poking my head up every so often to laugh.",
  "id" : 794444960,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Kelly",
      "screen_name" : "hci",
      "indices" : [ 0, 4 ],
      "id_str" : "12628652",
      "id" : 12628652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794448236",
  "geo" : { },
  "id_str" : "794448583",
  "in_reply_to_user_id" : 12628652,
  "text" : "@hci Human communication...silly liberal arts class.",
  "id" : 794448583,
  "in_reply_to_status_id" : 794448236,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "hci",
  "in_reply_to_user_id_str" : "12628652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794555255",
  "text" : "Check out some desk setups that are most likely better than yours. http:\/\/tinyurl.com\/5s3w8k",
  "id" : 794555255,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Wilson",
      "screen_name" : "belthesar",
      "indices" : [ 0, 10 ],
      "id_str" : "10623882",
      "id" : 10623882
    }, {
      "name" : "hashtags",
      "screen_name" : "hashtags",
      "indices" : [ 70, 79 ],
      "id_str" : "9720292",
      "id" : 9720292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794554267",
  "geo" : { },
  "id_str" : "794555522",
  "in_reply_to_user_id" : 10623882,
  "text" : "@belthesar They're hashtags. Check out http:\/\/hashtags.org and follow @hashtags",
  "id" : 794555522,
  "in_reply_to_status_id" : 794554267,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "belthesar",
  "in_reply_to_user_id_str" : "10623882",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794557755",
  "geo" : { },
  "id_str" : "794560642",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton Perhaps a more financial one, in reference to saving money instead of blowing it on credit cards and expensive stuff",
  "id" : 794560642,
  "in_reply_to_status_id" : 794557755,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csharp",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794582985",
  "text" : "Best ##csharp quote today: &lt;schwepps&gt; that's why you get multiple cpu on windows, one dedicated for explorer.exe, one for each vis ...",
  "id" : 794582985,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794586971",
  "text" : "\"Yup. There\u2019s straight, gay, and emacs.\" http:\/\/blog.xcski.com\/2008\/04\/18\/i-loled",
  "id" : 794586971,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794599487",
  "text" : "My wrists are killing me today. Probably has to do with me typing\/coding nonstop for the past 3 days.",
  "id" : 794599487,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794613157",
  "geo" : { },
  "id_str" : "794613573",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror When is your next podcast? I have a question for ye, (actually several), but you haven't mentioned when the cutoff is.",
  "id" : 794613573,
  "in_reply_to_status_id" : 794613157,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Owens",
      "screen_name" : "joshowens",
      "indices" : [ 0, 10 ],
      "id_str" : "768288",
      "id" : 768288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794629985",
  "geo" : { },
  "id_str" : "794631352",
  "in_reply_to_user_id" : 768288,
  "text" : "@joshowens Yeah, use views and partials. Helpers seem to be more for pulling complex code out of the view (partials too)",
  "id" : 794631352,
  "in_reply_to_status_id" : 794629985,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshowens",
  "in_reply_to_user_id_str" : "768288",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794635337",
  "text" : "Damn. Stardock's MyColors is on the front page of Download.com. Also their comments suck nearly as much as youtube's.",
  "id" : 794635337,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794651063",
  "geo" : { },
  "id_str" : "794653152",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked This could spawn an entire new Design Patterns book!",
  "id" : 794653152,
  "in_reply_to_status_id" : 794651063,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794665930",
  "text" : "RIT email fails at forwarding. Just got emails from 8 hours ago sent to my GMail. Seriously, it's not that hard, is it?",
  "id" : 794665930,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794669292",
  "geo" : { },
  "id_str" : "794682268",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton That's pathetic. I know storage space = money, but with GMail's storage you'd think most univ's would step up a bit",
  "id" : 794682268,
  "in_reply_to_status_id" : 794669292,
  "created_at" : "2008-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793555623",
  "text" : "\"OBAMA OSAMA HUMM ARE THEY BROTHERS?\" church sign in SC reads... And they won't take it down. He's a CHRISTIAN! wtf! http:\/\/is.gd\/7H7",
  "id" : 793555623,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zer0Her0",
      "screen_name" : "Zer0Her0",
      "indices" : [ 0, 9 ],
      "id_str" : "662843",
      "id" : 662843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793552897",
  "geo" : { },
  "id_str" : "793555732",
  "in_reply_to_user_id" : 662843,
  "text" : "@Zer0Her0 What can Sony do right?",
  "id" : 793555732,
  "in_reply_to_status_id" : 793552897,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zer0Her0",
  "in_reply_to_user_id_str" : "662843",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just A Sun God",
      "screen_name" : "JustaSunGod",
      "indices" : [ 0, 12 ],
      "id_str" : "11390722",
      "id" : 11390722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793601422",
  "geo" : { },
  "id_str" : "793604898",
  "in_reply_to_user_id" : 11390722,
  "text" : "@JustaSunGod borkety bork bork",
  "id" : 793604898,
  "in_reply_to_status_id" : 793601422,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustaSunGod",
  "in_reply_to_user_id_str" : "11390722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793618136",
  "geo" : { },
  "id_str" : "793619398",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I will buy the shirt that says \"HILLARY DROPS OUT, FINALLY\"",
  "id" : 793619398,
  "in_reply_to_status_id" : 793618136,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793623452",
  "geo" : { },
  "id_str" : "793626068",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Clever...they really shouldn't allow that to happen",
  "id" : 793626068,
  "in_reply_to_status_id" : 793623452,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793629627",
  "geo" : { },
  "id_str" : "793634939",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike Around 3 huge tour groups came by the fishbowl labs on Saturday....I felt like some sort of lab experiment or model on display",
  "id" : 793634939,
  "in_reply_to_status_id" : 793629627,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793751872",
  "text" : "Guest lecturer who's a PHD student on optics from UR...very interesting stuff. Physics scares me sometimes.",
  "id" : 793751872,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793756468",
  "geo" : { },
  "id_str" : "793758300",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I doubt that will ever happen, 3D is hard to Google. Also check out http:\/\/en.wikipedia.org\/wiki\/VRML , which failed.",
  "id" : 793758300,
  "in_reply_to_status_id" : 793756468,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793761005",
  "geo" : { },
  "id_str" : "793762744",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense That's an embedded runtime. I thought you were talking about browsers supporting a 3D world, which is what VRML was trying to do.",
  "id" : 793762744,
  "in_reply_to_status_id" : 793761005,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793793337",
  "text" : "DrNic's TextMate settings for Eclipse are awesome.",
  "id" : 793793337,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793799325",
  "geo" : { },
  "id_str" : "793802312",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Don't forget our good old friend &lt;marquee&gt; too",
  "id" : 793802312,
  "in_reply_to_status_id" : 793799325,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 26, 38 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793335741",
  "text" : "My roommates got to shake @BarackObama's hand this weekend in Harrisburg!",
  "id" : 793335741,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Andrews",
      "screen_name" : "SteveAndrews",
      "indices" : [ 0, 13 ],
      "id_str" : "5728662",
      "id" : 5728662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793338628",
  "geo" : { },
  "id_str" : "793339478",
  "in_reply_to_user_id" : 5728662,
  "text" : "@SteveAndrews Using notepad for programming is akin to attempting to cook with dull knives. It'll get the job done but it'll be a pain.",
  "id" : 793339478,
  "in_reply_to_status_id" : 793338628,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveAndrews",
  "in_reply_to_user_id_str" : "5728662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793365142",
  "text" : "Simple things in Ruby on Rails seem to take so long to figure out, but once you do...it's amazing. And then usually there's a better way.",
  "id" : 793365142,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793402896",
  "text" : "Up until god awful hours of the night working on Rails again. Enjoying every minute of it, too, somehow.",
  "id" : 793402896,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Jaquith",
      "screen_name" : "braverydanger",
      "indices" : [ 0, 14 ],
      "id_str" : "7935372",
      "id" : 7935372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793548118",
  "geo" : { },
  "id_str" : "793551334",
  "in_reply_to_user_id" : 7935372,
  "text" : "@braverydanger The office is soooo much better when it's only a few feet away from your bed too. :)",
  "id" : 793551334,
  "in_reply_to_status_id" : 793548118,
  "created_at" : "2008-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "braverydanger",
  "in_reply_to_user_id_str" : "7935372",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792759257",
  "text" : "Free Laundry at RIT always wins.",
  "id" : 792759257,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792809796",
  "text" : "8 hours of coding, 5 hours of laundry, and I still have a poster to make. This day will never end.",
  "id" : 792809796,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonic Linley",
      "screen_name" : "Jonic",
      "indices" : [ 0, 6 ],
      "id_str" : "654033",
      "id" : 654033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792811153",
  "geo" : { },
  "id_str" : "792812281",
  "in_reply_to_user_id" : 654033,
  "text" : "@jonic Avoid the web interface if at all possible...outside clients seem to work great",
  "id" : 792812281,
  "in_reply_to_status_id" : 792811153,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jonic",
  "in_reply_to_user_id_str" : "654033",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792841378",
  "geo" : { },
  "id_str" : "792842798",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash Was that app actually supposed to do something?",
  "id" : 792842798,
  "in_reply_to_status_id" : 792841378,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792845922",
  "text" : "Why must the ruby keyword be 'elsif' instead of 'elseif' or 'else if' ? That's just dumb.",
  "id" : 792845922,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howland",
      "screen_name" : "backslash",
      "indices" : [ 0, 10 ],
      "id_str" : "8161622",
      "id" : 8161622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792845752",
  "geo" : { },
  "id_str" : "792846636",
  "in_reply_to_user_id" : 8161622,
  "text" : "@backslash Ahh...not a good idea to drum at quarter to 2 in the morning. I shall try and report back tomorrow. :)",
  "id" : 792846636,
  "in_reply_to_status_id" : 792845752,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "backslash",
  "in_reply_to_user_id_str" : "8161622",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792860453",
  "text" : "It's nearly 3am, I need to go to 10am mass, and I'm awake working on Rails. Too much koolaid!",
  "id" : 792860453,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793049442",
  "text" : "A Rush song came on in a campus eatery and I most likely made a fool of myself by singing along with it.",
  "id" : 793049442,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793197678",
  "text" : "I think I tried just about every cheat in GTA: San Andreas now, and I'm extremely bored with it. Let's hope GTA4 can keep my attention",
  "id" : 793197678,
  "created_at" : "2008-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792288444",
  "text" : "Successful trip to Buffalo and back to get my fixed Jeep and plenty of other junk. Driving for some reason causes so much fatigue.",
  "id" : 792288444,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792436292",
  "text" : "Going to head out to fill the tires of my '70s schwinn bike today! It still rides like a dream.",
  "id" : 792436292,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792436452",
  "text" : "Wow, meth really messes people up. http:\/\/tinyurl.com\/5oemwv",
  "id" : 792436452,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792440671",
  "text" : "\"Was Bill O'Reilly a marine?\" This Catholic priest speaks the truth and defends Rev. Wright on Fox News. http:\/\/tinyurl.com\/3ver5g",
  "id" : 792440671,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792489633",
  "text" : "Preparing to live in the SE lab for the rest of the day.",
  "id" : 792489633,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792498320",
  "geo" : { },
  "id_str" : "792499280",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense There is no way that scout could not have been mowed down by that sentry.",
  "id" : 792499280,
  "in_reply_to_status_id" : 792498320,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Briggs",
      "screen_name" : "briggsb",
      "indices" : [ 0, 8 ],
      "id_str" : "1563671",
      "id" : 1563671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792503328",
  "geo" : { },
  "id_str" : "792503786",
  "in_reply_to_user_id" : 1563671,
  "text" : "@briggsb The Tron guy AND Randall Munroe of XKCD are there? The universe might explode.",
  "id" : 792503786,
  "in_reply_to_status_id" : 792503328,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "briggsb",
  "in_reply_to_user_id_str" : "1563671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792619139",
  "text" : "Having lots of fun with Rails! Been looking forward to this all week. The Rails koolaid tastes delicious.",
  "id" : 792619139,
  "created_at" : "2008-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 68, 78 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791478069",
  "text" : "Wow, the Jing project has a really neat app and interface. Props to @IslandDog for pointing it out.",
  "id" : 791478069,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791496294",
  "text" : "Hurray, mid-term CG project update finished, even with a neat video made with Jing.",
  "id" : 791496294,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alesandro Ortiz",
      "screen_name" : "The_PHP_Jedi",
      "indices" : [ 0, 13 ],
      "id_str" : "1692901",
      "id" : 1692901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791549810",
  "geo" : { },
  "id_str" : "791551222",
  "in_reply_to_user_id" : 1692901,
  "text" : "@The_PHP_Jedi Ahh, trolls and e-drama, the eternal constant in the Greater Internet Theory",
  "id" : 791551222,
  "in_reply_to_status_id" : 791549810,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_PHP_Jedi",
  "in_reply_to_user_id_str" : "1692901",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791625437",
  "text" : "Great work tonight on my raytracer, procedural shading on the floor completed with both squares and circles for bonus points. woot!",
  "id" : 791625437,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791627794",
  "text" : "http:\/\/dilbert.com got injected with Flash. And there seems to be daily animations now. Man, I hate 100% flash websites.",
  "id" : 791627794,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 4, 16 ],
      "id_str" : "717313",
      "id" : 717313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791783314",
  "text" : "Via @arstechnica: wifi popular with 'young people' backups not so much. I really need to sign up for a backup service. http:\/\/is.gd\/76o",
  "id" : 791783314,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791789756",
  "geo" : { },
  "id_str" : "791789830",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I'm pretty sure it wasn't called \"Microsoft Vista Ultimate BETA\" They really need to learn the Google way of shifting blame",
  "id" : 791789830,
  "in_reply_to_status_id" : 791789756,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791813787",
  "text" : "Obama on the Colbert Report! Distractions are now ON NOTICE! http:\/\/tinyurl.com\/5738ds",
  "id" : 791813787,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791820589",
  "text" : "Princess Bride....the game?! http:\/\/www.princessbridegame.com\/",
  "id" : 791820589,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791825869",
  "geo" : { },
  "id_str" : "791826262",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP INCONCEIVABLE!",
  "id" : 791826262,
  "in_reply_to_status_id" : 791825869,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791901527",
  "text" : "Broke 600 karma on Reddit. Must find more silly pictures and websites to get over 1000.",
  "id" : 791901527,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791957231",
  "text" : "Awesome, my princess bride story has climbed to #6 on Reddit.",
  "id" : 791957231,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791961385",
  "text" : "Perhaps it's only for http:\/\/reddit.com\/r\/reddit.com\/ Curse Reddit's subreddit system, it's quite confusing at times.",
  "id" : 791961385,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791964754",
  "geo" : { },
  "id_str" : "791966247",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I believe it's called 'upmod.' Who knows what voodoo magic is required to get stories on the *real* frontpage however...",
  "id" : 791966247,
  "in_reply_to_status_id" : 791964754,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791997584",
  "text" : "Best comment on the Princess Bride reddit story: \"The controls are difficult, I feel like I need six fingers to play it.\"",
  "id" : 791997584,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791997556",
  "geo" : { },
  "id_str" : "791999344",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Holy crap, are they ok? Any local news stories that you can link  to yet?",
  "id" : 791999344,
  "in_reply_to_status_id" : 791997556,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792010608",
  "geo" : { },
  "id_str" : "792013515",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog Signed up, but the site does jack squat right now.",
  "id" : 792013515,
  "in_reply_to_status_id" : 792010608,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792163510",
  "text" : "I've ascended my fifth nethack character! http:\/\/alt.org\/nethack\/userdata\/DoctorNick\/dumplog\/1206303499.nh343.txt Which class next?",
  "id" : 792163510,
  "created_at" : "2008-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791315204",
  "geo" : { },
  "id_str" : "791316097",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox I felt like jumping out of the third floor windows after every CS Theory test...I managed a B though",
  "id" : 791316097,
  "in_reply_to_status_id" : 791315204,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digg",
      "screen_name" : "digg",
      "indices" : [ 0, 5 ],
      "id_str" : "15163466",
      "id" : 15163466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791298557",
  "geo" : { },
  "id_str" : "791316542",
  "in_reply_to_user_id" : 14334532,
  "text" : "@digg welcome to Twitter!",
  "id" : 791316542,
  "in_reply_to_status_id" : 791298557,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "DiggSupport",
  "in_reply_to_user_id_str" : "14334532",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Albrecht",
      "screen_name" : "alexalbrecht",
      "indices" : [ 0, 13 ],
      "id_str" : "14413075",
      "id" : 14413075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791324111",
  "geo" : { },
  "id_str" : "791325715",
  "in_reply_to_user_id" : 14413075,
  "text" : "@alexalbrecht What's your \/played? The world must know...",
  "id" : 791325715,
  "in_reply_to_status_id" : 791324111,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "alexalbrecht",
  "in_reply_to_user_id_str" : "14413075",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791361698",
  "geo" : { },
  "id_str" : "791364877",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor What is with all of these naked women and porn stars on your timeline today XD",
  "id" : 791364877,
  "in_reply_to_status_id" : 791361698,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791365478",
  "geo" : { },
  "id_str" : "791367090",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Where do you teach?",
  "id" : 791367090,
  "in_reply_to_status_id" : 791365478,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 0, 8 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791405083",
  "geo" : { },
  "id_str" : "791406804",
  "in_reply_to_user_id" : 291,
  "text" : "@goldman IT'S JUST NOT...THE SAME.",
  "id" : 791406804,
  "in_reply_to_status_id" : 791405083,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "goldman",
  "in_reply_to_user_id_str" : "291",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791412377",
  "text" : "I am unnaturally, unhealthily obsessed with Rush. Seriously. I can't stop listening to them.",
  "id" : 791412377,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Watermasysk",
      "screen_name" : "scottw",
      "indices" : [ 0, 7 ],
      "id_str" : "15023",
      "id" : 15023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791422847",
  "geo" : { },
  "id_str" : "791423527",
  "in_reply_to_user_id" : 15023,
  "text" : "@scottw Next time I'll take your coach seat and you can stay home if you want. :)",
  "id" : 791423527,
  "in_reply_to_status_id" : 791422847,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "scottw",
  "in_reply_to_user_id_str" : "15023",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791442568",
  "geo" : { },
  "id_str" : "791444161",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn What?! Where is it?",
  "id" : 791444161,
  "in_reply_to_status_id" : 791442568,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Badera",
      "screen_name" : "andrewbadera",
      "indices" : [ 0, 13 ],
      "id_str" : "1535551",
      "id" : 1535551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791448932",
  "geo" : { },
  "id_str" : "791450273",
  "in_reply_to_user_id" : 1535551,
  "text" : "@andrewbadera Congrats! I wish I was on it too, but I am just an apprentice compared to you gurus...",
  "id" : 791450273,
  "in_reply_to_status_id" : 791448932,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewbadera",
  "in_reply_to_user_id_str" : "1535551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JComboBox",
      "screen_name" : "JComboBox",
      "indices" : [ 0, 10 ],
      "id_str" : "14198120",
      "id" : 14198120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790715390",
  "geo" : { },
  "id_str" : "790716331",
  "in_reply_to_user_id" : 14198120,
  "text" : "@JComboBox Yeah, but what about network neutrality?",
  "id" : 790716331,
  "in_reply_to_status_id" : 790715390,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "JComboBox",
  "in_reply_to_user_id_str" : "14198120",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 69, 81 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790717358",
  "text" : "Top Chef is much more important than the debate to @ablissfulgal. Go @BarackObama!",
  "id" : 790717358,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790722743",
  "text" : "I would really like to upload the paper I just worked for an hour on that's a day late, but MyCourses is down. Desire2Learn sucks!",
  "id" : 790722743,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 0, 8 ],
      "id_str" : "778057",
      "id" : 778057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790741839",
  "geo" : { },
  "id_str" : "790742665",
  "in_reply_to_user_id" : 778057,
  "text" : "@acarvin I've been watching the debate too. Obama is really kicking ass... ACK ACK ACK ACK ACK is all I hear from Hillary's mouth",
  "id" : 790742665,
  "in_reply_to_status_id" : 790741839,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "acarvin",
  "in_reply_to_user_id_str" : "778057",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790750944",
  "geo" : { },
  "id_str" : "790751730",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy How did he dodge it? He stated 16 months, and he said he would give the order to pull them out. Don't be ridiculous.",
  "id" : 790751730,
  "in_reply_to_status_id" : 790750944,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790766823",
  "text" : "Well then, calling someone 'ridiculous' on Twitter earns an unfollow. E-drama in 140 characters!",
  "id" : 790766823,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Laporte",
      "screen_name" : "leolaporte",
      "indices" : [ 0, 11 ],
      "id_str" : "3829151",
      "id" : 3829151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790814852",
  "geo" : { },
  "id_str" : "790816539",
  "in_reply_to_user_id" : 3829151,
  "text" : "@leolaporte Recap: Hillary: ACK ACK ACK Obama: HOPE HOPE UNITY Hillary: ACK ACK EXPERIENCE ACK Obama: UNITY HOPE SOME TAXES HOPE HOPE",
  "id" : 790816539,
  "in_reply_to_status_id" : 790814852,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "leolaporte",
  "in_reply_to_user_id_str" : "3829151",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790850115",
  "text" : "South Park's internet outage episode is a riot.",
  "id" : 790850115,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790859305",
  "text" : "Wow, ABC News backlash on the debates tonight. http:\/\/tinyurl.com\/5vfas7",
  "id" : 790859305,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790860211",
  "text" : "I'm not a big MySQL guy, but close sourcing sections of it sounds like a BAD CALL. http:\/\/is.gd\/6Lm",
  "id" : 790860211,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790864901",
  "text" : "broke down and decided to set up a LinkedIn profile.",
  "id" : 790864901,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790868018",
  "text" : "So much information to fill out for LinkedIn. I'll have to do it later.",
  "id" : 790868018,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791105389",
  "text" : "Lovely, SE class may be filmed this morning. I'm glad I had to give my   presentation last class instead of today.",
  "id" : 791105389,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791231649",
  "text" : "Does anyone else feel that the inclusion of Darth Vader and Yoda in Soul Caliber 4 is just a bit silly? Awesome, but silly?",
  "id" : 791231649,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791243027",
  "geo" : { },
  "id_str" : "791243990",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Look on codeplex! there were plenty there",
  "id" : 791243990,
  "in_reply_to_status_id" : 791243027,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791247730",
  "text" : "I have a serious addiction to cold vanilla Voortman sugar cookies. I need help.",
  "id" : 791247730,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791247388",
  "geo" : { },
  "id_str" : "791249343",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Someone needs to flood his inbox with DEVELOPERS DEVELOPERS DEVELOPERS",
  "id" : 791249343,
  "in_reply_to_status_id" : 791247388,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791250329",
  "text" : "Awesome blog post: What makes a great developer? http:\/\/is.gd\/6U8",
  "id" : 791250329,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 0, 14 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791268504",
  "geo" : { },
  "id_str" : "791275979",
  "in_reply_to_user_id" : 749863,
  "text" : "@hotdogsladies Operation aborted in IE7 on http:\/\/43folders.com Prevents all IE users from viewing that site",
  "id" : 791275979,
  "in_reply_to_status_id" : 791268504,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "hotdogsladies",
  "in_reply_to_user_id_str" : "749863",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scobelizer",
      "screen_name" : "Scobelizer",
      "indices" : [ 65, 76 ],
      "id_str" : "2625781",
      "id" : 2625781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791284952",
  "text" : "Twitter's about those you follow more than those who follow you. @scobelizer hits the nail on the head: http:\/\/is.gd\/61D",
  "id" : 791284952,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791288927",
  "geo" : { },
  "id_str" : "791292312",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk hey, your new blog template looks great in Firefox but is pretty messed up in IE7",
  "id" : 791292312,
  "in_reply_to_status_id" : 791288927,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mike stedman",
      "screen_name" : "ravuya",
      "indices" : [ 0, 7 ],
      "id_str" : "8939632",
      "id" : 8939632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791296149",
  "geo" : { },
  "id_str" : "791297677",
  "in_reply_to_user_id" : 8939632,
  "text" : "@ravuya Where'd you get it from? @ablissfulgal is considering purchasing one",
  "id" : 791297677,
  "in_reply_to_status_id" : 791296149,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ravuya",
  "in_reply_to_user_id_str" : "8939632",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791281754",
  "geo" : { },
  "id_str" : "791300930",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Perhaps provide a simple form or replies on Twitter...You really should have expected some friction, too much effort for most",
  "id" : 791300930,
  "in_reply_to_status_id" : 791281754,
  "created_at" : "2008-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789938123",
  "geo" : { },
  "id_str" : "789946595",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense You've just got to check your dependencies, patch your kernel, and make...what's so hard about that? It's so easy.",
  "id" : 789946595,
  "in_reply_to_status_id" : 789938123,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789948193",
  "text" : "Not looking forward to doing more Java crap tonight. It's like I have a test or something tomorrow in it...aww crap.",
  "id" : 789948193,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789952816",
  "text" : "Bidding is up to $9k for http:\/\/xs.to\/",
  "id" : 789952816,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789948937",
  "geo" : { },
  "id_str" : "789956337",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror I see Danica Patrick, and she's definitely not out of my memory yet.",
  "id" : 789956337,
  "in_reply_to_status_id" : 789948937,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789959752",
  "geo" : { },
  "id_str" : "789960236",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense There's plenty of girls on this continent that play games.",
  "id" : 789960236,
  "in_reply_to_status_id" : 789959752,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay.",
      "screen_name" : "meangrape",
      "indices" : [ 0, 10 ],
      "id_str" : "336113",
      "id" : 336113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789976579",
  "geo" : { },
  "id_str" : "789979762",
  "in_reply_to_user_id" : 336113,
  "text" : "@meangrape Heh, I wish I knew ASL...huge deaf community here on my campus",
  "id" : 789979762,
  "in_reply_to_status_id" : 789976579,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "meangrape",
  "in_reply_to_user_id_str" : "336113",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789981078",
  "text" : "Does anyone actually use AOP\/AspectJ?",
  "id" : 789981078,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gapingvoid",
      "screen_name" : "gapingvoid",
      "indices" : [ 0, 11 ],
      "id_str" : "72982024",
      "id" : 72982024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789983036",
  "geo" : { },
  "id_str" : "789984125",
  "in_reply_to_user_id" : 50193,
  "text" : "@gapingvoid Welcome back. You're not on http:\/\/twitter.alltop.com for nothing :)",
  "id" : 789984125,
  "in_reply_to_status_id" : 789983036,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "hughcartoons",
  "in_reply_to_user_id_str" : "50193",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789985490",
  "text" : "I'm learning that I can't get any work done at my apartment with 3-4 other people constantly talking, TV on, etc.",
  "id" : 789985490,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790004706",
  "text" : "If you have more than 3 animated gifs on your website that aren't avatars, I hate you.",
  "id" : 790004706,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790255389",
  "text" : "Prepare to hurl...cheesy Internal Vista SP1 sales video:  http:\/\/is.gd\/6wG",
  "id" : 790255389,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Taylor",
      "screen_name" : "alanataylor",
      "indices" : [ 0, 12 ],
      "id_str" : "12367712",
      "id" : 12367712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790279287",
  "geo" : { },
  "id_str" : "790282073",
  "in_reply_to_user_id" : 12367712,
  "text" : "@alanataylor Heh, I remember the AOL chatrooms...I could never get into the bigger ones, my connection sucked.",
  "id" : 790282073,
  "in_reply_to_status_id" : 790279287,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanataylor",
  "in_reply_to_user_id_str" : "12367712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790331421",
  "text" : "Looks like the Pope has stopped by W's house.",
  "id" : 790331421,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790338092",
  "geo" : { },
  "id_str" : "790341247",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Time to bum a ride there, sleep on a couch, and sneak in the backdoor of the conference center.",
  "id" : 790341247,
  "in_reply_to_status_id" : 790338092,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790345371",
  "text" : "The pope speaks english much better than I could have imagined. Quite a german accent, but very fluent.",
  "id" : 790345371,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergio pereira",
      "screen_name" : "sergiopereira",
      "indices" : [ 0, 14 ],
      "id_str" : "823751",
      "id" : 823751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790373332",
  "geo" : { },
  "id_str" : "790379510",
  "in_reply_to_user_id" : 823751,
  "text" : "@sergiopereira His Holiness needs to update more often...",
  "id" : 790379510,
  "in_reply_to_status_id" : 790373332,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "sergiopereira",
  "in_reply_to_user_id_str" : "823751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790406304",
  "text" : "One of the huge Sun Microsystems Black Boxes is currently parked outside of my school: http:\/\/blogs.sun.com\/HPC\/resource\/pbb.jpg",
  "id" : 790406304,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790651749",
  "text" : "Penny Arcade always delivers.",
  "id" : 790651749,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790692046",
  "text" : "Really loving the view out of my apartment's front windows. Downtown Rochester and the lake are ~15 miles away, and quite visible",
  "id" : 790692046,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790695567",
  "text" : "Word 2007's compatibility options are haunting: \"Auto space the way Word 95 does\", \"Layout this document as if created in Word for MSDOS\"",
  "id" : 790695567,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790707088",
  "geo" : { },
  "id_str" : "790708962",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense DO EEEEEEEEEET. And what coffee shop? Did I miss something?",
  "id" : 790708962,
  "in_reply_to_status_id" : 790707088,
  "created_at" : "2008-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gemma howard",
      "screen_name" : "mizbhavin",
      "indices" : [ 0, 10 ],
      "id_str" : "24664097",
      "id" : 24664097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789869165",
  "geo" : { },
  "id_str" : "789869797",
  "in_reply_to_user_id" : 11310222,
  "text" : "@MizBhavin GO BILLS!",
  "id" : 789869797,
  "in_reply_to_status_id" : 789869165,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Beverlee_B",
  "in_reply_to_user_id_str" : "11310222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789877698",
  "text" : "I am deeply disturbed by the fact that Ebaums World's HQ is less than 10 minutes away from my current location.",
  "id" : 789877698,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Primiani",
      "screen_name" : "joeyprimiani",
      "indices" : [ 0, 13 ],
      "id_str" : "159680125",
      "id" : 159680125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789838741",
  "geo" : { },
  "id_str" : "789878940",
  "in_reply_to_user_id" : 780459,
  "text" : "@joeyprimiani dude, your big wheel wreck video is EPIC. i can't believe it didn't get on AHF.",
  "id" : 789878940,
  "in_reply_to_status_id" : 789838741,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "jp",
  "in_reply_to_user_id_str" : "780459",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Rowse",
      "screen_name" : "problogger",
      "indices" : [ 0, 11 ],
      "id_str" : "1143031",
      "id" : 1143031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789879424",
  "geo" : { },
  "id_str" : "789880094",
  "in_reply_to_user_id" : 1143031,
  "text" : "@problogger I wrote a blog post about this very subject. http:\/\/tinyurl.com\/2ua9sg",
  "id" : 789880094,
  "in_reply_to_status_id" : 789879424,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "problogger",
  "in_reply_to_user_id_str" : "1143031",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789890087",
  "text" : "I have homework, therefore I procrastinate.",
  "id" : 789890087,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "niccolo benvenuti",
      "screen_name" : "nbenvenuti",
      "indices" : [ 0, 11 ],
      "id_str" : "50257972",
      "id" : 50257972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789893708",
  "geo" : { },
  "id_str" : "789900833",
  "in_reply_to_user_id" : 7281072,
  "text" : "@nbenvenuti Oooh, I love mad libs. There's no twitterlibs site yet, is there... :)",
  "id" : 789900833,
  "in_reply_to_status_id" : 789893708,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "NinoB",
  "in_reply_to_user_id_str" : "7281072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789242097",
  "geo" : { },
  "id_str" : "789243135",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Ahh. Yeah, Aptana + RadRails is clutch.",
  "id" : 789243135,
  "in_reply_to_status_id" : 789242097,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stever Robbins",
      "screen_name" : "GetItDoneGuy",
      "indices" : [ 0, 13 ],
      "id_str" : "6548932",
      "id" : 6548932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789245450",
  "geo" : { },
  "id_str" : "789254128",
  "in_reply_to_user_id" : 6548932,
  "text" : "@GetItDoneGuy I've been in the city...Vesuvius towers over the city, it's an amazing sight. To even think what it looked like that day...",
  "id" : 789254128,
  "in_reply_to_status_id" : 789245450,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "GetItDoneGuy",
  "in_reply_to_user_id_str" : "6548932",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789315555",
  "text" : "Tried \"Wild\" hot sauce at Buffalo Wild Wings tonight...great stuff, bearable but still tasty.",
  "id" : 789315555,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789492576",
  "text" : "Twitter is back alive! And whoa, I surpassed 1,000 tweets.",
  "id" : 789492576,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789506991",
  "geo" : { },
  "id_str" : "789509935",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP Hah, oddly enough I didn't base my handle after the simpsons character...it's a long, long story. But I shall consider!",
  "id" : 789509935,
  "in_reply_to_status_id" : 789506991,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789521767",
  "text" : "Finished preparing for my SE presentation today. Some days I just loathe my department, but it's work that needs to get done.",
  "id" : 789521767,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789566226",
  "geo" : { },
  "id_str" : "789572776",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba If I was there, I would gladly ruin it for you. I can probably manage that from here too. :)",
  "id" : 789572776,
  "in_reply_to_status_id" : 789566226,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789597417",
  "text" : "\"This is echoed in our campaign theme song \"Vi sitter I Ventrilo och spelar DOTA\" by BassHunter.\" A pitch for RIT student govt pres.",
  "id" : 789597417,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick O'Neill",
      "screen_name" : "biznickman",
      "indices" : [ 0, 11 ],
      "id_str" : "24944172",
      "id" : 24944172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789600032",
  "geo" : { },
  "id_str" : "789604742",
  "in_reply_to_user_id" : 965651,
  "text" : "@biznickman I wonder how they'll handle that for API traffic...perhaps insert ads into public timelines?",
  "id" : 789604742,
  "in_reply_to_status_id" : 789600032,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "allnick",
  "in_reply_to_user_id_str" : "965651",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789607984",
  "text" : "Why to take the stairs instead of the elevator. http:\/\/snurl.com\/24i04",
  "id" : 789607984,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789610957",
  "text" : "Wow, this kicks StreetView's default view's ass. http:\/\/www.mapjack.com\/?TpbyUmRbacUE7CAA",
  "id" : 789610957,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789642742",
  "text" : "Presentation on RUP went ok. Didn't get grilled by the professor due to a lack of time. Saved by the bell!",
  "id" : 789642742,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Olshan",
      "screen_name" : "rolshan",
      "indices" : [ 0, 8 ],
      "id_str" : "55710148",
      "id" : 55710148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789731337",
  "text" : "@rolshan So true! I'm glad someone is not afraid to stand up to them.",
  "id" : 789731337,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789743925",
  "text" : "There is a dropdown menu floating on my desktop for no apparent reason. It's just hanging out there. Doesn't belong to any app in particular",
  "id" : 789743925,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Conery",
      "screen_name" : "robconery",
      "indices" : [ 0, 10 ],
      "id_str" : "248815441",
      "id" : 248815441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789747075",
  "text" : "@robconery Have they figured out how to beat Flash yet? (I'm not a big Flash fan, but I still don't see it happening yet)",
  "id" : 789747075,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789751118",
  "text" : "Going back to table layouts for HTML email. Standards, who needs them?",
  "id" : 789751118,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789777068",
  "text" : "I've been wondering. How does Twitter make money? Maybe they sell lemonade?",
  "id" : 789777068,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 68, 80 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789786091",
  "text" : "Wow, lots of responses about how Twitter makes money! Best one from @steveswrong: birdseed.",
  "id" : 789786091,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Franks",
      "screen_name" : "ariedana",
      "indices" : [ 0, 9 ],
      "id_str" : "1694311",
      "id" : 1694311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789791893",
  "geo" : { },
  "id_str" : "789792616",
  "in_reply_to_user_id" : 1694311,
  "text" : "@ariedana Do you need a free stress test?",
  "id" : 789792616,
  "in_reply_to_status_id" : 789791893,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ariedana",
  "in_reply_to_user_id_str" : "1694311",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789797239",
  "text" : "Another email from my department to drop out of the college and join a startup (and not get paid for a while). What a joke.",
  "id" : 789797239,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789802054",
  "geo" : { },
  "id_str" : "789803582",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton I'm sorry but I value finishing my college education much higher than any startup right now.",
  "id" : 789803582,
  "in_reply_to_status_id" : 789802054,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789804296",
  "geo" : { },
  "id_str" : "789805628",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob exactly. hence why I really dislike those emails, so pointless. but I bet someone will bite.",
  "id" : 789805628,
  "in_reply_to_status_id" : 789804296,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789806852",
  "geo" : { },
  "id_str" : "789808082",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob My school department...software engineering here at RIT.",
  "id" : 789808082,
  "in_reply_to_status_id" : 789806852,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Fox",
      "screen_name" : "AmyFox",
      "indices" : [ 0, 7 ],
      "id_str" : "16305557",
      "id" : 16305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789809543",
  "geo" : { },
  "id_str" : "789810187",
  "in_reply_to_user_id" : 3885361,
  "text" : "@amyfox I'm Catholic, I'm sort of meh about it. Mostly interested in what he says about all of the scandals.",
  "id" : 789810187,
  "in_reply_to_status_id" : 789809543,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "amykant",
  "in_reply_to_user_id_str" : "3885361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreakingNewsOn",
      "screen_name" : "BreakingNewsOn",
      "indices" : [ 11, 26 ],
      "id_str" : "27867231",
      "id" : 27867231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789856232",
  "text" : "Retweeting @BreakingNewsOn: Hostage situation on an Amtrak in Lousiana. WTF?",
  "id" : 789856232,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BreakingNewsOn",
      "screen_name" : "BreakingNewsOn",
      "indices" : [ 0, 15 ],
      "id_str" : "27867231",
      "id" : 27867231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789856105",
  "geo" : { },
  "id_str" : "789857317",
  "in_reply_to_user_id" : 6017542,
  "text" : "@BreakingNewsOn It was a prank. http:\/\/tinyurl.com\/6gk7fx",
  "id" : 789857317,
  "in_reply_to_status_id" : 789856105,
  "created_at" : "2008-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "BreakingNews",
  "in_reply_to_user_id_str" : "6017542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788642668",
  "text" : "Snow is falling...virtually. And it's pretty enough for one night of work!",
  "id" : 788642668,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788815258",
  "text" : "Why is it that in every sci-fi comic\/book\/movie there's always a salvage crew or salvagers. Is there _THAT_ much crap in space?",
  "id" : 788815258,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Kelly",
      "screen_name" : "hci",
      "indices" : [ 0, 4 ],
      "id_str" : "12628652",
      "id" : 12628652
    }, {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 5, 13 ],
      "id_str" : "10266282",
      "id" : 10266282
    }, {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 14, 21 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788817691",
  "geo" : { },
  "id_str" : "788822124",
  "in_reply_to_user_id" : 12628652,
  "text" : "@hci @CarrieP @zoomba Perhaps I'm just sick of Ctrl+Alt+Del's current storyline, that's all. :)",
  "id" : 788822124,
  "in_reply_to_status_id" : 788817691,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "hci",
  "in_reply_to_user_id_str" : "12628652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 0, 5 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788834968",
  "geo" : { },
  "id_str" : "788835705",
  "in_reply_to_user_id" : 12534,
  "text" : "@beep It's probably all of the followers you missed getting emails from over the weekend when their emailing service was dead.",
  "id" : 788835705,
  "in_reply_to_status_id" : 788834968,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "beep",
  "in_reply_to_user_id_str" : "12534",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788837585",
  "text" : "Nabbing more .NET gurus on twitter thanks to http:\/\/www.hashtags.org\/tag\/mvp08\/",
  "id" : 788837585,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Leon Watson",
      "screen_name" : "MarkLeonWatson",
      "indices" : [ 0, 15 ],
      "id_str" : "9064182",
      "id" : 9064182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788847654",
  "geo" : { },
  "id_str" : "788850818",
  "in_reply_to_user_id" : 9064182,
  "text" : "@MarkLeonWatson Zombies? Just because they use .NET doesn't make them brainless...I'm open to other langs too, been using RoR lately",
  "id" : 788850818,
  "in_reply_to_status_id" : 788847654,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarkLeonWatson",
  "in_reply_to_user_id_str" : "9064182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergio pereira",
      "screen_name" : "sergiopereira",
      "indices" : [ 0, 14 ],
      "id_str" : "823751",
      "id" : 823751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788858052",
  "geo" : { },
  "id_str" : "788860394",
  "in_reply_to_user_id" : 823751,
  "text" : "@sergiopereira No, it needs a cowbell for Don't Fear the Reaper!",
  "id" : 788860394,
  "in_reply_to_status_id" : 788858052,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "sergiopereira",
  "in_reply_to_user_id_str" : "823751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Leon Watson",
      "screen_name" : "MarkLeonWatson",
      "indices" : [ 0, 15 ],
      "id_str" : "9064182",
      "id" : 9064182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788862082",
  "geo" : { },
  "id_str" : "788863764",
  "in_reply_to_user_id" : 9064182,
  "text" : "@MarkLeonWatson Yes, drinking from the MS firehose is a bad call...usually being ridicuously over zealous for any one tool is bad too imo",
  "id" : 788863764,
  "in_reply_to_status_id" : 788862082,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarkLeonWatson",
  "in_reply_to_user_id_str" : "9064182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sergio pereira",
      "screen_name" : "sergiopereira",
      "indices" : [ 0, 14 ],
      "id_str" : "823751",
      "id" : 823751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788866649",
  "geo" : { },
  "id_str" : "788867752",
  "in_reply_to_user_id" : 823751,
  "text" : "@sergiopereira Rock Band PVC Tube Kit, only $300!",
  "id" : 788867752,
  "in_reply_to_status_id" : 788866649,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "sergiopereira",
  "in_reply_to_user_id_str" : "823751",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788884565",
  "text" : "Ever wanted to own an image hosting site? http:\/\/marketplace.sitepoint.com\/auctions\/33173 only $8000!",
  "id" : 788884565,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788955486",
  "text" : "Powerpoint wall of text crits you for 1000! You die...",
  "id" : 788955486,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788973693",
  "text" : "Interesting, the Pope will be addressing sex abuse in the Church this week... http:\/\/snurl.com\/24e6l",
  "id" : 788973693,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789026023",
  "text" : "So much food in this CG2 class...it's all taunting me.",
  "id" : 789026023,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bellware",
      "screen_name" : "sbellware",
      "indices" : [ 0, 10 ],
      "id_str" : "15636332",
      "id" : 15636332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789048750",
  "text" : "@sbellware Wow. What exactly is happening? Just a lot of spouting about how MS everything is the one and only?",
  "id" : 789048750,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789063965",
  "text" : "Just met someone who uses Ubuntu, has a job set up at MS, and learned C# on the plane out to Redmond, and will be working on .NET... WTF?",
  "id" : 789063965,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Rubin",
      "screen_name" : "danrubin",
      "indices" : [ 0, 9 ],
      "id_str" : "12741",
      "id" : 12741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789062479",
  "geo" : { },
  "id_str" : "789066638",
  "in_reply_to_user_id" : 12741,
  "text" : "@danrubin What kind of guitar? I'm attempting to learn bass guitar",
  "id" : 789066638,
  "in_reply_to_status_id" : 789062479,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "danrubin",
  "in_reply_to_user_id_str" : "12741",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Trinity",
      "screen_name" : "TheProkrammer",
      "indices" : [ 0, 14 ],
      "id_str" : "1454222514",
      "id" : 1454222514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789065898",
  "geo" : { },
  "id_str" : "789067221",
  "in_reply_to_user_id" : 458173,
  "text" : "@TheProkrammer He said he's played with Mono, but barely any C# experience outside of that interview. Just makes me wonder...",
  "id" : 789067221,
  "in_reply_to_status_id" : 789065898,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mletterle",
  "in_reply_to_user_id_str" : "458173",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789098910",
  "text" : "\"...there were reported instances of biased-related harassment as well as anti-Semitic graffiti on-campus.\" This just makes me sick.",
  "id" : 789098910,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789177627",
  "geo" : { },
  "id_str" : "789178627",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 What OS?",
  "id" : 789178627,
  "in_reply_to_status_id" : 789177627,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789185086",
  "geo" : { },
  "id_str" : "789185254",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr Use the old ones to be safe, not everyone is on the bleeding edge of MS.",
  "id" : 789185254,
  "in_reply_to_status_id" : 789185086,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789184868",
  "geo" : { },
  "id_str" : "789186101",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 I suggest you install Dev-C++, it has everything you need in a decent IDE",
  "id" : 789186101,
  "in_reply_to_status_id" : 789184868,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789203405",
  "geo" : { },
  "id_str" : "789208967",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco No Country for Old Men!",
  "id" : 789208967,
  "in_reply_to_status_id" : 789203405,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarrieP",
      "screen_name" : "CarrieP",
      "indices" : [ 0, 8 ],
      "id_str" : "10266282",
      "id" : 10266282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789205293",
  "geo" : { },
  "id_str" : "789210788",
  "in_reply_to_user_id" : 10266282,
  "text" : "@CarrieP Don't even joke about that. It would be amazing.",
  "id" : 789210788,
  "in_reply_to_status_id" : 789205293,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarrieP",
  "in_reply_to_user_id_str" : "10266282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789221400",
  "text" : "Watching snowflakes, this time on my monitor. They shouldn't be blinking in and out of existence but they are for some reason.",
  "id" : 789221400,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788510964",
  "text" : "I can't stand to watch the Compassion Forum now on CNN.",
  "id" : 788510964,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788526203",
  "text" : "\"Do you believe God wants to you be president?\" IMPORTANT QUESTIONS ABOUND.",
  "id" : 788526203,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788527734",
  "text" : "Holy crap, roommate's parents were just on CNN clapping for Obama.",
  "id" : 788527734,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788567127",
  "text" : "I think when playing NES games on the Wii, there shouldn't be a reset button...you just have to hit the side of the Wii really hard.",
  "id" : 788567127,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 0, 8 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788611700",
  "geo" : { },
  "id_str" : "788612302",
  "in_reply_to_user_id" : 1221471,
  "text" : "@shashib Yes but how about all of the emails we've missed? :(",
  "id" : 788612302,
  "in_reply_to_status_id" : 788611700,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "shashib",
  "in_reply_to_user_id_str" : "1221471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ike Pigott",
      "screen_name" : "ikepigott",
      "indices" : [ 0, 10 ],
      "id_str" : "496723",
      "id" : 496723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788616575",
  "geo" : { },
  "id_str" : "788617526",
  "in_reply_to_user_id" : 496723,
  "text" : "@ikepigott Mine too! :D Filters ftw.",
  "id" : 788617526,
  "in_reply_to_status_id" : 788616575,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ikepigott",
  "in_reply_to_user_id_str" : "496723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 0, 8 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788616956",
  "geo" : { },
  "id_str" : "788617606",
  "in_reply_to_user_id" : 1221471,
  "text" : "@shashib yeah, looks like I twittered too soon.",
  "id" : 788617606,
  "in_reply_to_status_id" : 788616956,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "shashib",
  "in_reply_to_user_id_str" : "1221471",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788631378",
  "text" : "Alrighty then...either I bound my number of particles generated or face out of memory exceptions. Tough choice!",
  "id" : 788631378,
  "created_at" : "2008-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788103048",
  "text" : "Confident enough in Rails wizardry to set up migrations and relationships! Good start so far...when will the magic end?",
  "id" : 788103048,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 0, 6 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788107143",
  "geo" : { },
  "id_str" : "788108152",
  "in_reply_to_user_id" : 14243440,
  "text" : "@zubaz But what about the GERMS! and the ABDUCTORS! and RAPISTS! and, and, and, and, and!",
  "id" : 788108152,
  "in_reply_to_status_id" : 788107143,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "zubaz",
  "in_reply_to_user_id_str" : "14243440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adele McAlear",
      "screen_name" : "AdeleMcAlear",
      "indices" : [ 0, 13 ],
      "id_str" : "5554222",
      "id" : 5554222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788109634",
  "geo" : { },
  "id_str" : "788110409",
  "in_reply_to_user_id" : 5554222,
  "text" : "@adelemcalear That's just dumb.",
  "id" : 788110409,
  "in_reply_to_status_id" : 788109634,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "AdeleMcAlear",
  "in_reply_to_user_id_str" : "5554222",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Poltavskiy",
      "screen_name" : "Scabr",
      "indices" : [ 11, 17 ],
      "id_str" : "11403902",
      "id" : 11403902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788110495",
  "text" : "Retweeting @Scabr: Twitter Account and Followers For Sale http:\/\/tinyurl.com\/3zs6kl",
  "id" : 788110495,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 0, 8 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788136761",
  "geo" : { },
  "id_str" : "788137486",
  "in_reply_to_user_id" : 5768872,
  "text" : "@garyvee added!",
  "id" : 788137486,
  "in_reply_to_status_id" : 788136761,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "garyvee",
  "in_reply_to_user_id_str" : "5768872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788141328",
  "text" : "Auction is now up to $455.00....this is getting ridiculous.",
  "id" : 788141328,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788142043",
  "text" : "Ray tracer isn't perfect, but it'll do. Checkpoint 3 and one bonus item done. Just don't move the spheres too close, and don't ask questions",
  "id" : 788142043,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788144611",
  "geo" : { },
  "id_str" : "788144848",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk I just followed ya. :)",
  "id" : 788144848,
  "in_reply_to_status_id" : 788144611,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788329114",
  "text" : "Preparing to spend the rest of my waking hours today in the SE lab.",
  "id" : 788329114,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788331507",
  "text" : "I'd much rather be doing Rails than learning about IBM's Rational Unified Process for one of my classes. Surprise? I think not.",
  "id" : 788331507,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788334129",
  "geo" : { },
  "id_str" : "788335160",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane BarCamp was great! Had a lot of fun, and only briefly, going to need to use it for the rails project I'm working on ;)",
  "id" : 788335160,
  "in_reply_to_status_id" : 788334129,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788334299",
  "geo" : { },
  "id_str" : "788335360",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Time to start doing it on the side then! :) I have plenty of links to get you started if you'd like.",
  "id" : 788335360,
  "in_reply_to_status_id" : 788334299,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788336697",
  "geo" : { },
  "id_str" : "788337217",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Perhaps create somethin interesting with Twitter or another open API? That's as real as you can get w\/o getting paid...",
  "id" : 788337217,
  "in_reply_to_status_id" : 788336697,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788339342",
  "geo" : { },
  "id_str" : "788340400",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob According to http:\/\/tinyurl.com\/2ylm4j definitely a bad idea",
  "id" : 788340400,
  "in_reply_to_status_id" : 788339342,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788342487",
  "text" : "Why do people whistle in labs? I can understand talking, laughing...but whistling? Give me a break.",
  "id" : 788342487,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788342101",
  "geo" : { },
  "id_str" : "788342798",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Honestly I have no idea. Getting involved with the Rails community on IRC and learning it is all i'm doing.",
  "id" : 788342798,
  "in_reply_to_status_id" : 788342101,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788344306",
  "text" : "\"Initial Operational Capability Milestone\" man I really dislike enterprise-y terms like this.",
  "id" : 788344306,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788352727",
  "text" : "\"Therefore think of each phase having 15 steps to an iteration\" How much worse can this get.",
  "id" : 788352727,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lawrence",
      "screen_name" : "SamLawrence",
      "indices" : [ 0, 12 ],
      "id_str" : "7462572",
      "id" : 7462572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788362431",
  "geo" : { },
  "id_str" : "788362599",
  "in_reply_to_user_id" : 7462572,
  "text" : "@SamLawrence If it did, lolcats would never have been spawned.",
  "id" : 788362599,
  "in_reply_to_status_id" : 788362431,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "SamLawrence",
  "in_reply_to_user_id_str" : "7462572",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 0, 8 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788371066",
  "geo" : { },
  "id_str" : "788376796",
  "in_reply_to_user_id" : 849101,
  "text" : "@jmspool 3-5? Wow. I'm lucky to have 1 decent one.",
  "id" : 788376796,
  "in_reply_to_status_id" : 788371066,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "jmspool",
  "in_reply_to_user_id_str" : "849101",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C. Welch",
      "screen_name" : "bynkii",
      "indices" : [ 0, 7 ],
      "id_str" : "656933",
      "id" : 656933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788377321",
  "geo" : { },
  "id_str" : "788378678",
  "in_reply_to_user_id" : 656933,
  "text" : "@bynkii My favorite is when they walk into a room and immediately know that A VICTIMS HAIR WAS IN UPPER CURVE OF THE SINK PIPE. ridiculous.",
  "id" : 788378678,
  "in_reply_to_status_id" : 788377321,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "bynkii",
  "in_reply_to_user_id_str" : "656933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tweet140",
      "screen_name" : "tweet140",
      "indices" : [ 50, 59 ],
      "id_str" : "12167322",
      "id" : 12167322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788380141",
  "text" : "It would be fun to create a dummy account to game @tweet140. Just fill it with 70req\/hr of one character * 140",
  "id" : 788380141,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788384063",
  "text" : "Ahh, old ray tracing papers: \"They all took approximately 50\rminutes each to compute on a VAX 780.\"  They're huge! http:\/\/snurl.com\/24ayzs",
  "id" : 788384063,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tweet140",
      "screen_name" : "tweet140",
      "indices" : [ 33, 42 ],
      "id_str" : "12167322",
      "id" : 12167322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788392237",
  "text" : "I tweet like a duck according to @tweet140, with only an 88 avg character count. I need to work my way up the aviary chain here...",
  "id" : 788392237,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788401192",
  "text" : "Realizing I made a huge mistake in not forming a group for my CG2 project...midterm checkpoint is thursday and I haven't started.",
  "id" : 788401192,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788401610",
  "text" : "Rails &gt; C# &gt; Java\/J2EE! What next?! *screams*",
  "id" : 788401610,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788405419",
  "text" : "One day I hope I'll look back and wonder why I was flipping between 3-4 languages on a daily basis.",
  "id" : 788405419,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788407934",
  "text" : "I want to hurt the designer of Books 24x7 that decided that highlighting words in hot pink was a good idea.",
  "id" : 788407934,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788412718",
  "text" : "It really bothers me that POJO is an accepted term in the Java community. Does a regular object need its own special name? That's just dumb.",
  "id" : 788412718,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Zehnder Rossi",
      "screen_name" : "shawnz",
      "indices" : [ 0, 7 ],
      "id_str" : "7789282",
      "id" : 7789282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788414608",
  "geo" : { },
  "id_str" : "788415181",
  "in_reply_to_user_id" : 7789282,
  "text" : "@shawnz d) messy, and always takes too many napkins than necessary",
  "id" : 788415181,
  "in_reply_to_status_id" : 788414608,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "shawnz",
  "in_reply_to_user_id_str" : "7789282",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788429853",
  "text" : "I wonder if there's a limit to how much web app knowledge can fit in my head...attempting to cram in this Java crap might cause implosion",
  "id" : 788429853,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788430945",
  "text" : "Yeah, I can't stand this Java\/Spring crap any more. Too complex to sink in during one sitting, will probably have to fudge the assignment.",
  "id" : 788430945,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788500429",
  "geo" : { },
  "id_str" : "788501873",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk What is this polling tool?",
  "id" : 788501873,
  "in_reply_to_status_id" : 788500429,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ Vaynerchuk",
      "screen_name" : "ajvchuk",
      "indices" : [ 0, 8 ],
      "id_str" : "15235124",
      "id" : 15235124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788505598",
  "geo" : { },
  "id_str" : "788507778",
  "in_reply_to_user_id" : 792537,
  "text" : "@ajvchuk interesting. i'm building a polling site for twitter so I was interested in seeing. thanks.",
  "id" : 788507778,
  "in_reply_to_status_id" : 788505598,
  "created_at" : "2008-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ajv",
  "in_reply_to_user_id_str" : "792537",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kee Hinckley",
      "screen_name" : "nazgul",
      "indices" : [ 0, 7 ],
      "id_str" : "2084821",
      "id" : 2084821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787907817",
  "geo" : { },
  "id_str" : "787908487",
  "in_reply_to_user_id" : 2084821,
  "text" : "@nazgul Dear god. Please tell me this isn't our country's fault.",
  "id" : 787908487,
  "in_reply_to_status_id" : 787907817,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "nazgul",
  "in_reply_to_user_id_str" : "2084821",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787904446",
  "geo" : { },
  "id_str" : "787912985",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig you're on the advisory board for aptana? news to me.",
  "id" : 787912985,
  "in_reply_to_status_id" : 787904446,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steelopus",
      "screen_name" : "steelopus",
      "indices" : [ 0, 10 ],
      "id_str" : "6902732",
      "id" : 6902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787914193",
  "geo" : { },
  "id_str" : "787914536",
  "in_reply_to_user_id" : 6902732,
  "text" : "@steelopus hey, my aunt works there! have fun! :)",
  "id" : 787914536,
  "in_reply_to_status_id" : 787914193,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "steelopus",
  "in_reply_to_user_id_str" : "6902732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787921970",
  "text" : "Trying out Aptana\/RadRails...going just fine so far",
  "id" : 787921970,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787925585",
  "text" : "note to self: Ruby does not like semicolons at the end of lines.",
  "id" : 787925585,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah jones",
      "screen_name" : "LeahJones",
      "indices" : [ 0, 10 ],
      "id_str" : "1539609079",
      "id" : 1539609079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787969147",
  "text" : "@leahjones *BARF* OM NOM NOM NOM",
  "id" : 787969147,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787988261",
  "text" : "RailsEnvy commericals are hilarious. http:\/\/www.railsenvy.com\/tags\/Commercials",
  "id" : 787988261,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787991288",
  "text" : "No need to run mongrel through InstantRails, RadRails does it just fine. woot.",
  "id" : 787991288,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787571985",
  "text" : "I have a need for unhealthy food. Any suggestions?",
  "id" : 787571985,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787625476",
  "text" : "I ended up choosing Denny's. And I had a milkshake. It was GREAT.",
  "id" : 787625476,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Kelly",
      "screen_name" : "ta2yerface",
      "indices" : [ 0, 11 ],
      "id_str" : "14137853",
      "id" : 14137853
    }, {
      "name" : "Devylicious",
      "screen_name" : "Devyl",
      "indices" : [ 12, 18 ],
      "id_str" : "11925462",
      "id" : 11925462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787627471",
  "geo" : { },
  "id_str" : "787631622",
  "in_reply_to_user_id" : 14137853,
  "text" : "@ta2yerface @Devyl Chocolate, the only true milkshake flavor. It's a tradition for me.",
  "id" : 787631622,
  "in_reply_to_status_id" : 787627471,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ta2yerface",
  "in_reply_to_user_id_str" : "14137853",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787646869",
  "text" : "The brightness of my laptop's blue LED should really match the screen's. They are really starting to bother me when i'm on a low intensity.",
  "id" : 787646869,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787647688",
  "text" : "Rails has a ...pluralizer? What?! http:\/\/nubyonrails.com\/tools\/pluralize",
  "id" : 787647688,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787784424",
  "text" : "I can't wait to be on coop again. Weekends full of relaxation, video games, and side projects...only a few weeks away.",
  "id" : 787784424,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787790546",
  "text" : "Learning bass guitar is going to take a long time I'm learning...I think just dedicating some minutes a day to strumming is a good start...",
  "id" : 787790546,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787794129",
  "text" : "Signing up for a gravatar. Mostly because of the awesome name.",
  "id" : 787794129,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl, Inappropriate",
      "screen_name" : "akaMonty",
      "indices" : [ 0, 9 ],
      "id_str" : "9606962",
      "id" : 9606962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787796641",
  "geo" : { },
  "id_str" : "787797105",
  "in_reply_to_user_id" : 9606962,
  "text" : "@akaMonty Seriously? That really sucks, I want to follow people back! (Most times.)",
  "id" : 787797105,
  "in_reply_to_status_id" : 787796641,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaMonty",
  "in_reply_to_user_id_str" : "9606962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Vickerstaffe",
      "screen_name" : "paulvick",
      "indices" : [ 0, 9 ],
      "id_str" : "42205882",
      "id" : 42205882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787805482",
  "text" : "@paulvick Beware of Mr. Tiny Face. http:\/\/tinyurl.com\/5nx5la",
  "id" : 787805482,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl, Inappropriate",
      "screen_name" : "akaMonty",
      "indices" : [ 0, 9 ],
      "id_str" : "9606962",
      "id" : 9606962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787805225",
  "geo" : { },
  "id_str" : "787805775",
  "in_reply_to_user_id" : 9606962,
  "text" : "@akaMonty Yeah, I just went through mine and added a few people, while ignoring spammers. Perhaps it's an opt-in service now? :",
  "id" : 787805775,
  "in_reply_to_status_id" : 787805225,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaMonty",
  "in_reply_to_user_id_str" : "9606962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787809690",
  "text" : "I love BaseCamp.",
  "id" : 787809690,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787823088",
  "text" : "Loving the Rails magic. It's so inituitive.",
  "id" : 787823088,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787824745",
  "geo" : { },
  "id_str" : "787825278",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn very, getting to use vim and the console is very refreshing from using visual studio constantly...",
  "id" : 787825278,
  "in_reply_to_status_id" : 787824745,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787826158",
  "text" : "I'm loving this Rails tutorial. \"WTFMATEOMGMAGIC!\"",
  "id" : 787826158,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787826849",
  "geo" : { },
  "id_str" : "787828594",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 http:\/\/is.gd\/5Fa is the tutorial, see more here: http:\/\/del.icio.us\/doctornick40\/rubyonrails",
  "id" : 787828594,
  "in_reply_to_status_id" : 787826849,
  "created_at" : "2008-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 0, 7 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787195134",
  "geo" : { },
  "id_str" : "787207542",
  "in_reply_to_user_id" : 9993542,
  "text" : "@twhirl works again! IT'S ALIVE! For the first time in weeks!",
  "id" : 787207542,
  "in_reply_to_status_id" : 787195134,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "twhirl",
  "in_reply_to_user_id_str" : "9993542",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787218891",
  "text" : "Hoping Firefox 2 won't crash and burn as I open ~20 or tabs...perhaps it won't crash, it will just die slowly.",
  "id" : 787218891,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787220285",
  "geo" : { },
  "id_str" : "787221587",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike perhaps that means you should be working instead. :)",
  "id" : 787221587,
  "in_reply_to_status_id" : 787220285,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787225750",
  "geo" : { },
  "id_str" : "787226444",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Need it for web development. Using Firefox 3 on the laptop though.",
  "id" : 787226444,
  "in_reply_to_status_id" : 787225750,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787231826",
  "geo" : { },
  "id_str" : "787232576",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn I'm worried more than FF3 will render pages slightly different and I won't be catching FF2 issues. IE6, FF2 won't die for a while.",
  "id" : 787232576,
  "in_reply_to_status_id" : 787231826,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jones",
      "screen_name" : "smalljones",
      "indices" : [ 0, 11 ],
      "id_str" : "11726",
      "id" : 11726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787238338",
  "geo" : { },
  "id_str" : "787243305",
  "in_reply_to_user_id" : 11726,
  "text" : "@smalljones I really hope you're joking. Or being somewhat facetious.",
  "id" : 787243305,
  "in_reply_to_status_id" : 787238338,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "smalljones",
  "in_reply_to_user_id_str" : "11726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787244590",
  "geo" : { },
  "id_str" : "787245971",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane Not really...I tend to use the firefox extension instead of the interface for posting. It's a lot cleaner and easier to add links.",
  "id" : 787245971,
  "in_reply_to_status_id" : 787244590,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jones",
      "screen_name" : "smalljones",
      "indices" : [ 0, 11 ],
      "id_str" : "11726",
      "id" : 11726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787245569",
  "geo" : { },
  "id_str" : "787247028",
  "in_reply_to_user_id" : 11726,
  "text" : "@smalljones I can see their point, but I doubt they will be taken down so easily.",
  "id" : 787247028,
  "in_reply_to_status_id" : 787245569,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "smalljones",
  "in_reply_to_user_id_str" : "11726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787248082",
  "geo" : { },
  "id_str" : "787249087",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane There's a hack to get around it. http:\/\/tinyurl.com\/2sa2f2",
  "id" : 787249087,
  "in_reply_to_status_id" : 787248082,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jones",
      "screen_name" : "smalljones",
      "indices" : [ 0, 11 ],
      "id_str" : "11726",
      "id" : 11726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787249121",
  "geo" : { },
  "id_str" : "787251597",
  "in_reply_to_user_id" : 11726,
  "text" : "@smalljones I wasn't really around or aware for those...I'm sort of new. :)",
  "id" : 787251597,
  "in_reply_to_status_id" : 787249121,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "smalljones",
  "in_reply_to_user_id_str" : "11726",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Kirkpatrick",
      "screen_name" : "marshallk",
      "indices" : [ 0, 10 ],
      "id_str" : "818340",
      "id" : 818340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787242606",
  "geo" : { },
  "id_str" : "787251982",
  "in_reply_to_user_id" : 818340,
  "text" : "@marshallk Your twitter background is downright frightening.",
  "id" : 787251982,
  "in_reply_to_status_id" : 787242606,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshallk",
  "in_reply_to_user_id_str" : "818340",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787253166",
  "geo" : { },
  "id_str" : "787253547",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane twerp.",
  "id" : 787253547,
  "in_reply_to_status_id" : 787253166,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787268520",
  "geo" : { },
  "id_str" : "787271049",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane Heh, most likely...I have Firebug disabled on my copy since it seems to crash a lot, but delicious bookmarks works great.",
  "id" : 787271049,
  "in_reply_to_status_id" : 787268520,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787273304",
  "text" : "Wow. Tweetable scripts, programs in under 140 characters: http:\/\/nat.org\/blog\/?p=825",
  "id" : 787273304,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GarrettAtreides",
      "screen_name" : "GarrettAtreides",
      "indices" : [ 0, 16 ],
      "id_str" : "8091602",
      "id" : 8091602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787285937",
  "geo" : { },
  "id_str" : "787287095",
  "in_reply_to_user_id" : 8091602,
  "text" : "@GarrettAtreides Time for a new job.",
  "id" : 787287095,
  "in_reply_to_status_id" : 787285937,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "GarrettAtreides",
  "in_reply_to_user_id_str" : "8091602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787310688",
  "text" : "GARFIELD LIVES! http:\/\/tinyurl.com\/52fp4d",
  "id" : 787310688,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787323654",
  "geo" : { },
  "id_str" : "787324572",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome for what? barcamp?",
  "id" : 787324572,
  "in_reply_to_status_id" : 787323654,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787341399",
  "text" : "Really getting sick of Twitspammers.",
  "id" : 787341399,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Recordon",
      "screen_name" : "daveman692",
      "indices" : [ 0, 11 ],
      "id_str" : "744463",
      "id" : 744463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787342281",
  "geo" : { },
  "id_str" : "787343557",
  "in_reply_to_user_id" : 744463,
  "text" : "@daveman692 The pink theme really suits you.",
  "id" : 787343557,
  "in_reply_to_status_id" : 787342281,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "daveman692",
  "in_reply_to_user_id_str" : "744463",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jim halligan",
      "screen_name" : "jimCTC",
      "indices" : [ 0, 7 ],
      "id_str" : "15122455",
      "id" : 15122455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787344195",
  "geo" : { },
  "id_str" : "787344977",
  "in_reply_to_user_id" : 10143482,
  "text" : "@jimCTC Been waiting for them, nothing yet today...:(",
  "id" : 787344977,
  "in_reply_to_status_id" : 787344195,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jim",
  "in_reply_to_user_id_str" : "10143482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787350285",
  "text" : "I really loathe VB's array syntax. So clunky.",
  "id" : 787350285,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787349004",
  "geo" : { },
  "id_str" : "787350876",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome You should have let me known about it for BarCamp...i have certain...connections ;)",
  "id" : 787350876,
  "in_reply_to_status_id" : 787349004,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Barrett",
      "screen_name" : "cbarrett",
      "indices" : [ 0, 9 ],
      "id_str" : "3562421",
      "id" : 3562421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787357234",
  "geo" : { },
  "id_str" : "787357867",
  "in_reply_to_user_id" : 3562421,
  "text" : "@cbarrett The solution? Keep IRC minimized, or use a different client so you're not watching it constantly.",
  "id" : 787357867,
  "in_reply_to_status_id" : 787357234,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "cbarrett",
  "in_reply_to_user_id_str" : "3562421",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787365608",
  "geo" : { },
  "id_str" : "787365925",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike congrats. i've heard it's a bit boring there though....but good luck!",
  "id" : 787365925,
  "in_reply_to_status_id" : 787365608,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jim halligan",
      "screen_name" : "jimCTC",
      "indices" : [ 0, 7 ],
      "id_str" : "15122455",
      "id" : 15122455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787345770",
  "geo" : { },
  "id_str" : "787381948",
  "in_reply_to_user_id" : 10143482,
  "text" : "@jimCTC Got them! Had to go to the rental office for them. Thanks again!",
  "id" : 787381948,
  "in_reply_to_status_id" : 787345770,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jim",
  "in_reply_to_user_id_str" : "10143482",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jim halligan",
      "screen_name" : "jimCTC",
      "indices" : [ 17, 24 ],
      "id_str" : "15122455",
      "id" : 15122455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787384414",
  "text" : "3 Rush LP's from @jimCTC are AWESOME. Now to figure how to enshrine them accordingly...",
  "id" : 787384414,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787381150",
  "geo" : { },
  "id_str" : "787385134",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Damn...I liked Shoe the best. :(",
  "id" : 787385134,
  "in_reply_to_status_id" : 787381150,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787377150",
  "geo" : { },
  "id_str" : "787389478",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf Do they deliver? And how long can you wait until I get there.",
  "id" : 787389478,
  "in_reply_to_status_id" : 787377150,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787419919",
  "text" : "How many parameters do you put in a method until that little refactoring bell starts ringing? I think 9 is a bit excessive. 6 even.",
  "id" : 787419919,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787430616",
  "text" : "The amount of religious fanaticism that has been popping up on JoeUser lately is starting to scare me.",
  "id" : 787430616,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yianni Garcia",
      "screen_name" : "yiannig",
      "indices" : [ 0, 8 ],
      "id_str" : "8002272",
      "id" : 8002272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787437828",
  "geo" : { },
  "id_str" : "787439732",
  "in_reply_to_user_id" : 8002272,
  "text" : "@yiannig That Dane Cook is a silly bitch.",
  "id" : 787439732,
  "in_reply_to_status_id" : 787437828,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "yiannig",
  "in_reply_to_user_id_str" : "8002272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787440141",
  "text" : "Must fight...pretzel addiction.",
  "id" : 787440141,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787441625",
  "geo" : { },
  "id_str" : "787443810",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus Looks like snyder's pretzel rods to me. delicious.",
  "id" : 787443810,
  "in_reply_to_status_id" : 787441625,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787523269",
  "text" : "Hanging my new Rush LP's on the wall, and hoping that these 3M mounts won't wreck them too much...",
  "id" : 787523269,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786839094",
  "text" : "Law and order and http:\/\/www.seecolinslash.com\/eric\/images\/batman.jpg",
  "id" : 786839094,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786942598",
  "geo" : { },
  "id_str" : "786945526",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway THE CAKE IS A LIE!",
  "id" : 786945526,
  "in_reply_to_status_id" : 786942598,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787139448",
  "text" : "Friday! FRIDAY! FRIIIIDAY!!!!!!!",
  "id" : 787139448,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787151871",
  "text" : "Limit exceeded, please wait five minutes. STOP TORTURING ME TWITTER. It's been WEEKS.",
  "id" : 787151871,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruud Hein",
      "screen_name" : "RuudHein",
      "indices" : [ 0, 9 ],
      "id_str" : "6460152",
      "id" : 6460152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787170344",
  "geo" : { },
  "id_str" : "787174657",
  "in_reply_to_user_id" : 6460152,
  "text" : "@RuudHein Already doing so. I will email him though.",
  "id" : 787174657,
  "in_reply_to_status_id" : 787170344,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "RuudHein",
  "in_reply_to_user_id_str" : "6460152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787177199",
  "text" : "http:\/\/downforeveryoneorjustme.com\/ &lt; awesome idea.",
  "id" : 787177199,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787179885",
  "geo" : { },
  "id_str" : "787180228",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Hey, they need something to do before Starcraft 2 comes out.",
  "id" : 787180228,
  "in_reply_to_status_id" : 787179885,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787190092",
  "geo" : { },
  "id_str" : "787194923",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown We've moved to Web 4.0, Britney's kids had kids, and started another war.",
  "id" : 787194923,
  "in_reply_to_status_id" : 787190092,
  "created_at" : "2008-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786120241",
  "geo" : { },
  "id_str" : "786121232",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Terror cells communicating via private Twitter accounts. Genius!",
  "id" : 786121232,
  "in_reply_to_status_id" : 786120241,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786158209",
  "text" : "gameTime.IsRunningSlowly. Woe be to the XNA programmer who finds this to be true.",
  "id" : 786158209,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786181875",
  "text" : "Oooh, 'everyone' tab on the Twitter web interface.",
  "id" : 786181875,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786189737",
  "geo" : { },
  "id_str" : "786193401",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense there's a grocery store less than 5 minutes away, you tool.",
  "id" : 786193401,
  "in_reply_to_status_id" : 786189737,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786477876",
  "text" : "Twitter, I'm starting to get angry. External API doesn't work and the web interface likes to eat my tweets.",
  "id" : 786477876,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Foster",
      "screen_name" : "geekygirldawn",
      "indices" : [ 0, 14 ],
      "id_str" : "793351",
      "id" : 793351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786567473",
  "geo" : { },
  "id_str" : "786567691",
  "in_reply_to_user_id" : 793351,
  "text" : "@geekygirldawn Tough call...depends on what you want to get done, backend, DB stuff or perhaps front-end user experience stuff?",
  "id" : 786567691,
  "in_reply_to_status_id" : 786567473,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "geekygirldawn",
  "in_reply_to_user_id_str" : "793351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Fowler",
      "screen_name" : "megfowler",
      "indices" : [ 0, 10 ],
      "id_str" : "19223008",
      "id" : 19223008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786576961",
  "geo" : { },
  "id_str" : "786577444",
  "in_reply_to_user_id" : 819040,
  "text" : "@megfowler you know what's more awesome? OREOS AND MILK.",
  "id" : 786577444,
  "in_reply_to_status_id" : 786576961,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "megtripp",
  "in_reply_to_user_id_str" : "819040",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786393451",
  "geo" : { },
  "id_str" : "786651770",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror you just love to stir up the interwebs, eh? http:\/\/tinyurl.com\/5kmxsl",
  "id" : 786651770,
  "in_reply_to_status_id" : 786393451,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786650244",
  "geo" : { },
  "id_str" : "786652219",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba Depends on what the opinions are for :)",
  "id" : 786652219,
  "in_reply_to_status_id" : 786650244,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786656774",
  "geo" : { },
  "id_str" : "786657329",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr You smell.",
  "id" : 786657329,
  "in_reply_to_status_id" : 786656774,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    }, {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 16, 25 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786658300",
  "geo" : { },
  "id_str" : "786659234",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf expect @mittense to push_back on that one...(that was horrendous, i know)",
  "id" : 786659234,
  "in_reply_to_status_id" : 786658300,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786660800",
  "geo" : { },
  "id_str" : "786661481",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy Vista is NT6.0, XP is NT5.0. Hence, the next version is 7. Read more here: http:\/\/en.wikipedia.org\/wiki\/Windows_NT",
  "id" : 786661481,
  "in_reply_to_status_id" : 786660800,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucretia M Pruitt",
      "screen_name" : "GeekMommy",
      "indices" : [ 0, 10 ],
      "id_str" : "14320218",
      "id" : 14320218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786663642",
  "geo" : { },
  "id_str" : "786663945",
  "in_reply_to_user_id" : 4303181,
  "text" : "@GeekMommy If you had your hands on Windows 7 now, I doubt you'd be talking about it legally. :)",
  "id" : 786663945,
  "in_reply_to_status_id" : 786663642,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "LucretiaPruitt",
  "in_reply_to_user_id_str" : "4303181",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gia Lyons",
      "screen_name" : "gialyons",
      "indices" : [ 0, 9 ],
      "id_str" : "14157732",
      "id" : 14157732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786667661",
  "geo" : { },
  "id_str" : "786668240",
  "in_reply_to_user_id" : 14157732,
  "text" : "@gialyons The internet is a series of tubes.",
  "id" : 786668240,
  "in_reply_to_status_id" : 786667661,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "gialyons",
  "in_reply_to_user_id_str" : "14157732",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786684103",
  "geo" : { },
  "id_str" : "786684202",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman WELCOME TO MOES!",
  "id" : 786684202,
  "in_reply_to_status_id" : 786684103,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786681327",
  "geo" : { },
  "id_str" : "786684770",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy Perhaps put rickroll links in their comments? Or embed astley's masterpiece in one?",
  "id" : 786684770,
  "in_reply_to_status_id" : 786681327,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer P",
      "screen_name" : "jdots24",
      "indices" : [ 0, 8 ],
      "id_str" : "9897172",
      "id" : 9897172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786692746",
  "geo" : { },
  "id_str" : "786693083",
  "in_reply_to_user_id" : 9897172,
  "text" : "@jdots24 Let's go, who cares! Who needs college. :P",
  "id" : 786693083,
  "in_reply_to_status_id" : 786692746,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "jdots24",
  "in_reply_to_user_id_str" : "9897172",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786702927",
  "text" : "\"Find Chuck Norris\" I'm feeling lucky on Google results in...http:\/\/clients.arranschlosberg.com\/chuck\/",
  "id" : 786702927,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786754085",
  "text" : "I need to find my guitar tuner. It's missing. In my apartment.",
  "id" : 786754085,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Foster",
      "screen_name" : "geekygirldawn",
      "indices" : [ 0, 14 ],
      "id_str" : "793351",
      "id" : 793351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786759130",
  "geo" : { },
  "id_str" : "786759718",
  "in_reply_to_user_id" : 793351,
  "text" : "@geekygirldawn the Twitter API has been broken for a few weeks for me. I'm a bit fed up with it :(",
  "id" : 786759718,
  "in_reply_to_status_id" : 786759130,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "geekygirldawn",
  "in_reply_to_user_id_str" : "793351",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just A Sun God",
      "screen_name" : "JustaSunGod",
      "indices" : [ 0, 12 ],
      "id_str" : "11390722",
      "id" : 11390722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786767724",
  "geo" : { },
  "id_str" : "786771739",
  "in_reply_to_user_id" : 11390722,
  "text" : "@JustaSunGod Can you use Twhirl or any other external source?",
  "id" : 786771739,
  "in_reply_to_status_id" : 786767724,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "JustaSunGod",
  "in_reply_to_user_id_str" : "11390722",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Marsh",
      "screen_name" : "jakemarsh",
      "indices" : [ 0, 10 ],
      "id_str" : "2373551",
      "id" : 2373551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786771031",
  "geo" : { },
  "id_str" : "786773681",
  "in_reply_to_user_id" : 2373551,
  "text" : "@jakemarsh CrapSpace.",
  "id" : 786773681,
  "in_reply_to_status_id" : 786771031,
  "created_at" : "2008-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "jakemarsh",
  "in_reply_to_user_id_str" : "2373551",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785521078",
  "geo" : { },
  "id_str" : "785522778",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I must say, you do a horrible job with the GDNet daily news.",
  "id" : 785522778,
  "in_reply_to_status_id" : 785521078,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785721272",
  "geo" : { },
  "id_str" : "785721295",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Ask for a new car too.",
  "id" : 785721295,
  "in_reply_to_status_id" : 785721272,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785738633",
  "text" : "Milk and cereal does not mix well with keyboards.",
  "id" : 785738633,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785749094",
  "text" : "\"Baby with two faces worshipped as goddess\" WTF. http:\/\/www.cnn.com\/2008\/WORLD\/asiapcf\/04\/08\/baby.heads.ap\/index.html",
  "id" : 785749094,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wm. Lee Williams",
      "screen_name" : "WmLee",
      "indices" : [ 0, 6 ],
      "id_str" : "14219412",
      "id" : 14219412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785865611",
  "geo" : { },
  "id_str" : "785867831",
  "in_reply_to_user_id" : 14219412,
  "text" : "@WmLee Gack? wtf.",
  "id" : 785867831,
  "in_reply_to_status_id" : 785865611,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "WmLee",
  "in_reply_to_user_id_str" : "14219412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785868171",
  "text" : "@library_chan Definitely not. You need more question and exclamation marks.",
  "id" : 785868171,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Twohy",
      "screen_name" : "kevintwohy",
      "indices" : [ 0, 11 ],
      "id_str" : "13334062",
      "id" : 13334062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785866423",
  "geo" : { },
  "id_str" : "785868400",
  "in_reply_to_user_id" : 13334062,
  "text" : "@kevintwohy Chat on Facebook!? It really is turning into AOL...",
  "id" : 785868400,
  "in_reply_to_status_id" : 785866423,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevintwohy",
  "in_reply_to_user_id_str" : "13334062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Twohy",
      "screen_name" : "kevintwohy",
      "indices" : [ 0, 11 ],
      "id_str" : "13334062",
      "id" : 13334062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785871188",
  "geo" : { },
  "id_str" : "785873222",
  "in_reply_to_user_id" : 13334062,
  "text" : "@kevintwohy If they add keywords, I'm jumping ship.",
  "id" : 785873222,
  "in_reply_to_status_id" : 785871188,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kevintwohy",
  "in_reply_to_user_id_str" : "13334062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica OGrady",
      "screen_name" : "ericaogrady",
      "indices" : [ 0, 12 ],
      "id_str" : "69743",
      "id" : 69743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785871052",
  "geo" : { },
  "id_str" : "785874554",
  "in_reply_to_user_id" : 69743,
  "text" : "@ericaogrady Legal Seafood! Oh man. I want some chowdah now. I miss Boston.",
  "id" : 785874554,
  "in_reply_to_status_id" : 785871052,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ericaogrady",
  "in_reply_to_user_id_str" : "69743",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markman",
      "screen_name" : "Mickeleh",
      "indices" : [ 0, 9 ],
      "id_str" : "13413",
      "id" : 13413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785876270",
  "geo" : { },
  "id_str" : "785876770",
  "in_reply_to_user_id" : 13413,
  "text" : "@Mickeleh Hah, I haven't heard of that! Sounds like Buffalo Wild Wings...",
  "id" : 785876770,
  "in_reply_to_status_id" : 785876270,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mickeleh",
  "in_reply_to_user_id_str" : "13413",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Reynolds",
      "screen_name" : "scottcreynolds",
      "indices" : [ 0, 15 ],
      "id_str" : "441985676",
      "id" : 441985676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785876877",
  "text" : "@scottcreynolds Programmer needs food, badly!",
  "id" : 785876877,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miffy balboa",
      "screen_name" : "Puddington",
      "indices" : [ 0, 11 ],
      "id_str" : "298414457",
      "id" : 298414457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785880500",
  "geo" : { },
  "id_str" : "785881531",
  "in_reply_to_user_id" : 2057591,
  "text" : "@Puddington Public Safety is going to forcibly remove you from the campus.",
  "id" : 785881531,
  "in_reply_to_status_id" : 785880500,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "oneWillJ",
  "in_reply_to_user_id_str" : "2057591",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785887546",
  "text" : "Almost at 250 followers! Thanks everyone. :)",
  "id" : 785887546,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keyvan Nayyeri",
      "screen_name" : "keyvan",
      "indices" : [ 0, 7 ],
      "id_str" : "714023",
      "id" : 714023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785902572",
  "geo" : { },
  "id_str" : "785903096",
  "in_reply_to_user_id" : 714023,
  "text" : "@keyvan DotObfuscator...if you pay for it, it's pretty kickass.",
  "id" : 785903096,
  "in_reply_to_status_id" : 785902572,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "keyvan",
  "in_reply_to_user_id_str" : "714023",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Devroe",
      "screen_name" : "cdevroe",
      "indices" : [ 0, 8 ],
      "id_str" : "11764",
      "id" : 11764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785995321",
  "geo" : { },
  "id_str" : "785997270",
  "in_reply_to_user_id" : 11764,
  "text" : "@cdevroe I've got it installed, what's up?",
  "id" : 785997270,
  "in_reply_to_status_id" : 785995321,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "cdevroe",
  "in_reply_to_user_id_str" : "11764",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 0, 8 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785996610",
  "geo" : { },
  "id_str" : "785997462",
  "in_reply_to_user_id" : 739293,
  "text" : "@courosa Giving them away? Because I'll take one. Or three. Or fourteen.",
  "id" : 785997462,
  "in_reply_to_status_id" : 785996610,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "courosa",
  "in_reply_to_user_id_str" : "739293",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786042772",
  "text" : "Got my cheapo SD card from Woot. Smash bros screenshots, anyone?",
  "id" : 786042772,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786045092",
  "text" : "I Really Don't Like People Who Captialize The First Letter Of Their Tweets. It Gets Really Obnoxious Really Fast.",
  "id" : 786045092,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth",
      "screen_name" : "bethgo",
      "indices" : [ 0, 7 ],
      "id_str" : "11334",
      "id" : 11334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786050465",
  "geo" : { },
  "id_str" : "786053150",
  "in_reply_to_user_id" : 11334,
  "text" : "@bethgo If you discover it let me know, I want to get Stardock on there too.",
  "id" : 786053150,
  "in_reply_to_status_id" : 786050465,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "bethgo",
  "in_reply_to_user_id_str" : "11334",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 0, 11 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786046280",
  "geo" : { },
  "id_str" : "786053548",
  "in_reply_to_user_id" : 13749072,
  "text" : "@maslowbeer Ahh, that's probably it. Still annoying though.",
  "id" : 786053548,
  "in_reply_to_status_id" : 786046280,
  "created_at" : "2008-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "maslowbeer",
  "in_reply_to_user_id_str" : "13749072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twhirl Announce",
      "screen_name" : "twhirl",
      "indices" : [ 87, 94 ],
      "id_str" : "9993542",
      "id" : 9993542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784754916",
  "text" : "I really wish Twitter's API would work for me. So sick of the web interface, i want my @twhirl back!",
  "id" : 784754916,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784757745",
  "geo" : { },
  "id_str" : "784758988",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Just accept it. It's time to move to a small, hilly European town and have a career change.",
  "id" : 784758988,
  "in_reply_to_status_id" : 784757745,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl, Inappropriate",
      "screen_name" : "akaMonty",
      "indices" : [ 0, 9 ],
      "id_str" : "9606962",
      "id" : 9606962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784759195",
  "geo" : { },
  "id_str" : "784759419",
  "in_reply_to_user_id" : 9606962,
  "text" : "@akaMonty Sell! You know she would do the same! :P",
  "id" : 784759419,
  "in_reply_to_status_id" : 784759195,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "akaMonty",
  "in_reply_to_user_id_str" : "9606962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784777974",
  "text" : "Phonging is kicking my ass.",
  "id" : 784777974,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784778434",
  "text" : "Doh. http:\/\/truckbearingkibble.com\/comic\/2007\/11\/22\/doh\/",
  "id" : 784778434,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784792731",
  "text" : "Getting my raytracer working is immensely satisfying.",
  "id" : 784792731,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784796722",
  "text" : "Mmm, diffuse shading. Now time for some specular highlights! http:\/\/i27.tinypic.com\/blguw.png",
  "id" : 784796722,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784848758",
  "text" : "Mmm specular highlights. Shiny.",
  "id" : 784848758,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784854850",
  "text" : "Wow...war of the worlds in comic form. Amazing. http:\/\/tinyurl.com\/2gwqxz",
  "id" : 784854850,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785071100",
  "text" : "Ready for another great class from the professor who's always late!",
  "id" : 785071100,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clarence Smith Jr",
      "screen_name" : "DYKC",
      "indices" : [ 0, 5 ],
      "id_str" : "5558702",
      "id" : 5558702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785072785",
  "geo" : { },
  "id_str" : "785074394",
  "in_reply_to_user_id" : 5558702,
  "text" : "@dykc The verne troyer one is even worse...",
  "id" : 785074394,
  "in_reply_to_status_id" : 785072785,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "DYKC",
  "in_reply_to_user_id_str" : "5558702",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785214708",
  "geo" : { },
  "id_str" : "785221625",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Firebug was causing me issues so I disabled it, works fine with WebDeveloper and Delicious bookmarks for me",
  "id" : 785221625,
  "in_reply_to_status_id" : 785214708,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785275933",
  "text" : "Close-minded people make me angry. Especially ones on JoeUser.",
  "id" : 785275933,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Snook (Gryphon)",
      "screen_name" : "Snook",
      "indices" : [ 0, 6 ],
      "id_str" : "10778322",
      "id" : 10778322
    }, {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 7, 12 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785268759",
  "geo" : { },
  "id_str" : "785276642",
  "in_reply_to_user_id" : 10778322,
  "text" : "@Snook @beep I'm seeing the same issues, I just can't connect to Twitter via the API anymore. I miss twhirl.",
  "id" : 785276642,
  "in_reply_to_status_id" : 785268759,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Snook",
  "in_reply_to_user_id_str" : "10778322",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785307107",
  "text" : "Web 2.0 Apps in Minutes! Thanks Google ads.",
  "id" : 785307107,
  "created_at" : "2008-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784133695",
  "text" : "The new 5 dollar bill looks absolutely retarded.",
  "id" : 784133695,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784149105",
  "text" : "Thanks tinypic, but I don't need to add a DANCEJAM effect to my picture. I really don't need MC hammer dancing in front of my screenshot.",
  "id" : 784149105,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784149644",
  "geo" : { },
  "id_str" : "784149827",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Don't you dare interrupt my phonging.",
  "id" : 784149827,
  "in_reply_to_status_id" : 784149644,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784191583",
  "text" : "Cheap GPS: http:\/\/tinyurl.com\/6czo22",
  "id" : 784191583,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784193777",
  "text" : "Best yearbook photo, evar. http:\/\/i29.tinypic.com\/qxjjet.jpg",
  "id" : 784193777,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784224105",
  "text" : "Almost...2:30...need...sleep!",
  "id" : 784224105,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784381414",
  "text" : "Monday shall now forth be called Failday.",
  "id" : 784381414,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braden Allchin",
      "screen_name" : "iGexome",
      "indices" : [ 0, 8 ],
      "id_str" : "5518952",
      "id" : 5518952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784388122",
  "geo" : { },
  "id_str" : "784389618",
  "in_reply_to_user_id" : 5518952,
  "text" : "@iGexome He's only in 6th grade!? Damn.",
  "id" : 784389618,
  "in_reply_to_status_id" : 784388122,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "iGexome",
  "in_reply_to_user_id_str" : "5518952",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784413127",
  "text" : "C++ is an expert language. (And therefore sucks.) http:\/\/tinyurl.com\/5jjzx3",
  "id" : 784413127,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784421617",
  "geo" : { },
  "id_str" : "784422811",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf What? How does it lower his credibility?",
  "id" : 784422811,
  "in_reply_to_status_id" : 784421617,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Haslam",
      "screen_name" : "DougH",
      "indices" : [ 0, 6 ],
      "id_str" : "10396",
      "id" : 10396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784424865",
  "geo" : { },
  "id_str" : "784425093",
  "in_reply_to_user_id" : 10396,
  "text" : "@DougH I've been getting it for the past week :(",
  "id" : 784425093,
  "in_reply_to_status_id" : 784424865,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "DougH",
  "in_reply_to_user_id_str" : "10396",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784427799",
  "geo" : { },
  "id_str" : "784427973",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr Yes, it's not got to do with Twhirl...I can't get to Twitter from Twhirl or Witty. :(",
  "id" : 784427973,
  "in_reply_to_status_id" : 784427799,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784428494",
  "geo" : { },
  "id_str" : "784430528",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr Yeah, I've contacted Twitter about it, but it's still not working after more than a week. :(",
  "id" : 784430528,
  "in_reply_to_status_id" : 784428494,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Alan Stevens",
      "screen_name" : "alanstevens",
      "indices" : [ 0, 12 ],
      "id_str" : "9700652",
      "id" : 9700652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784432554",
  "geo" : { },
  "id_str" : "784433243",
  "in_reply_to_user_id" : 9700652,
  "text" : "@alanstevens Perhaps try RapidSVN? http:\/\/rapidsvn.tigris.org",
  "id" : 784433243,
  "in_reply_to_status_id" : 784432554,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "alanstevens",
  "in_reply_to_user_id_str" : "9700652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784541635",
  "text" : "Another beautiful day in Rochester...has spring really come?",
  "id" : 784541635,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784549733",
  "geo" : { },
  "id_str" : "784552390",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort A day where it isn't 100% gray and going outside without a coat is good enough for me",
  "id" : 784552390,
  "in_reply_to_status_id" : 784549733,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 38, 50 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784567245",
  "geo" : { },
  "id_str" : "784569001",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight I may have linked to it, @jongalloway found it for me though. Need it again?",
  "id" : 784569001,
  "in_reply_to_status_id" : 784567245,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 13, 23 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784576802",
  "geo" : { },
  "id_str" : "784576952",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight @cerebrojd enable extensions in ff3, beware of crashes http:\/\/is.gd\/3R2",
  "id" : 784576952,
  "in_reply_to_status_id" : 784576802,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784697029",
  "text" : "buying too much crap at Target...10% discount ftw",
  "id" : 784697029,
  "created_at" : "2008-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783669683",
  "text" : "Back from #barcamproc...exhausted and happy.",
  "id" : 783669683,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783673618",
  "text" : "Sick bass guitar I'm getting off Craigslist for only $100. Hell yes. http:\/\/i29.tinypic.com\/2qk8prn.jpg",
  "id" : 783673618,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783809349",
  "text" : "Alarm clock set an hour ahead = epic sleep fail.",
  "id" : 783809349,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783820582",
  "text" : "I am really sick of Firefox 2. It's so damn slow and clunky.",
  "id" : 783820582,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783810584",
  "geo" : { },
  "id_str" : "783820668",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Must be, the time was correct last night.",
  "id" : 783820668,
  "in_reply_to_status_id" : 783810584,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol Young",
      "screen_name" : "sol",
      "indices" : [ 0, 4 ],
      "id_str" : "12649752",
      "id" : 12649752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783822947",
  "geo" : { },
  "id_str" : "783825381",
  "in_reply_to_user_id" : 12649752,
  "text" : "@sol Report back in 10 hours. :P",
  "id" : 783825381,
  "in_reply_to_status_id" : 783822947,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "sol",
  "in_reply_to_user_id_str" : "12649752",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "woot.com",
      "screen_name" : "woot",
      "indices" : [ 0, 5 ],
      "id_str" : "734493",
      "id" : 734493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783736600",
  "geo" : { },
  "id_str" : "783827480",
  "in_reply_to_user_id" : 734493,
  "text" : "@woot's product description is a riot today. http:\/\/www.woot.com\/",
  "id" : 783827480,
  "in_reply_to_status_id" : 783736600,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "woot",
  "in_reply_to_user_id_str" : "734493",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783830361",
  "geo" : { },
  "id_str" : "783830919",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD You can add 2 special settings in about:config to make old plugins work, msg me if you want it.",
  "id" : 783830919,
  "in_reply_to_status_id" : 783830361,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783831045",
  "text" : "Awesome old Nintendo commericals. http:\/\/tinyurl.com\/6k9k54",
  "id" : 783831045,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784016749",
  "text" : "New strings and an amp FTW! guitar center rocks.",
  "id" : 784016749,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784040469",
  "text" : "Let's just rename Sunday to Choreday. Perhaps it will remind my roommates to help clean.",
  "id" : 784040469,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Leon Watson",
      "screen_name" : "MarkLeonWatson",
      "indices" : [ 0, 15 ],
      "id_str" : "9064182",
      "id" : 9064182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784036194",
  "geo" : { },
  "id_str" : "784040599",
  "in_reply_to_user_id" : 9064182,
  "text" : "@MarkLeonWatson A small Marshall amp. Just something that works.",
  "id" : 784040599,
  "in_reply_to_status_id" : 784036194,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarkLeonWatson",
  "in_reply_to_user_id_str" : "9064182",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784044296",
  "text" : "Powerpoint OM NOM NOM: http:\/\/www.flickr.com\/photos\/judxapp\/2305123089\/",
  "id" : 784044296,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784055183",
  "text" : "a = [2, 'cat', 3.14] a[-1] = 3.14. KABOOM! Ruby just made my brain implode, and I like it.",
  "id" : 784055183,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Dowell",
      "screen_name" : "CerebroJD",
      "indices" : [ 0, 10 ],
      "id_str" : "5744302",
      "id" : 5744302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784049769",
  "geo" : { },
  "id_str" : "784060808",
  "in_reply_to_user_id" : 5744302,
  "text" : "@CerebroJD Posted it to Reddit, give it a shot at Digg if you'd like.",
  "id" : 784060808,
  "in_reply_to_status_id" : 784049769,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "CerebroJD",
  "in_reply_to_user_id_str" : "5744302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Flauaus",
      "screen_name" : "zachflauaus",
      "indices" : [ 0, 12 ],
      "id_str" : "6839272",
      "id" : 6839272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784045995",
  "geo" : { },
  "id_str" : "784060988",
  "in_reply_to_user_id" : 6839272,
  "text" : "@zachflauaus I need to figure out how to include this in a presentation I give.",
  "id" : 784060988,
  "in_reply_to_status_id" : 784045995,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "zachflauaus",
  "in_reply_to_user_id_str" : "6839272",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "rockbandcamproc",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783637080",
  "text" : "#barcamproc has degraded into #rockbandcamproc.",
  "id" : 783637080,
  "created_at" : "2008-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783164484",
  "text" : "mmmm, chocolate Frosty.",
  "id" : 783164484,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783166319",
  "text" : "Wow. PastaHut was not a April Fool's joke. http:\/\/www.pizzahut.com\/",
  "id" : 783166319,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamprochester3",
      "indices" : [ 30, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783238746",
  "text" : "Nethack presentation done for #barcamprochester3 !",
  "id" : 783238746,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamprochester3",
      "indices" : [ 59, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783370044",
  "text" : "Packing up Rock Band and getting ready to have some fun at #barcamprochester3",
  "id" : 783370044,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamprochester3",
      "indices" : [ 3, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783389375",
  "text" : "At #barcamprochester3!",
  "id" : 783389375,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783394835",
  "text" : "Ahem. The proper hashtag is #barcamproc . Failboat.",
  "id" : 783394835,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Horn",
      "screen_name" : "chorn",
      "indices" : [ 0, 6 ],
      "id_str" : "744613",
      "id" : 744613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783402039",
  "geo" : { },
  "id_str" : "783402983",
  "in_reply_to_user_id" : 744613,
  "text" : "@chorn Sometimes it hurts to be an early adopter. #barcamproc",
  "id" : 783402983,
  "in_reply_to_status_id" : 783402039,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "chorn",
  "in_reply_to_user_id_str" : "744613",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 0, 8 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783414897",
  "geo" : { },
  "id_str" : "783416662",
  "in_reply_to_user_id" : 752673,
  "text" : "@jeresig Make sure to mark your tweets with #barcamproc",
  "id" : 783416662,
  "in_reply_to_status_id" : 783414897,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jeresig",
  "in_reply_to_user_id_str" : "752673",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783421187",
  "text" : "Wow. phone controlled webapps...never even though about that! #barcamproc",
  "id" : 783421187,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783400342",
  "geo" : { },
  "id_str" : "783428362",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane Can do :)",
  "id" : 783428362,
  "in_reply_to_status_id" : 783400342,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 23, 31 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783437126",
  "text" : "Smallest room evar for @jeresig's talk at #barcamproc",
  "id" : 783437126,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783482889",
  "text" : "Mmm, delicious subs at #barcamproc",
  "id" : 783482889,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783511773",
  "geo" : { },
  "id_str" : "783512359",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco wtf come to #barcamproc tool",
  "id" : 783512359,
  "in_reply_to_status_id" : 783511773,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 26, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783512508",
  "text" : "Hoping my Nethack talk at #barcamproc went well! :)",
  "id" : 783512508,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783517017",
  "text" : "Soaking up tons of Ruby knowledge at #barcamproc ...it's such a damn pretty language.",
  "id" : 783517017,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JasonMC",
      "screen_name" : "Jasoncalacanis",
      "indices" : [ 0, 15 ],
      "id_str" : "1004",
      "id" : 1004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783521447",
  "geo" : { },
  "id_str" : "783521777",
  "in_reply_to_user_id" : 3840,
  "text" : "@JasonCalacanis Are you joking? do you have a news link to this?",
  "id" : 783521777,
  "in_reply_to_status_id" : 783521447,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Jason",
  "in_reply_to_user_id_str" : "3840",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783527498",
  "text" : "Ballmer wants Yahoo's DEVELOPERS DEVELOPERS DEVELOPERS http:\/\/tinyurl.com\/6cdghx",
  "id" : 783527498,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783552704",
  "text" : "An hour of fighting with the projectors and A\/V setup at #barcamproc turned out to be a success, Rock Band is ALIVE!!!",
  "id" : 783552704,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Resig",
      "screen_name" : "jeresig",
      "indices" : [ 32, 40 ],
      "id_str" : "752673",
      "id" : 752673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamproc",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783575562",
  "text" : "Rawking out at #barcamproc with @jeresig and plenty of other RITsians",
  "id" : 783575562,
  "created_at" : "2008-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782525764",
  "text" : "A valid mistake: http:\/\/tinyurl.com\/2ljzzh",
  "id" : 782525764,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782618794",
  "text" : "Converted the ray tracer to C#, and feeling much more at home in VS2005 rather than Dev-C++.",
  "id" : 782618794,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y\u00EA\u00E9\u00EB\u0113\u0117\u0119s.",
      "screen_name" : "Kabren",
      "indices" : [ 0, 7 ],
      "id_str" : "772796",
      "id" : 772796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782805493",
  "geo" : { },
  "id_str" : "782805771",
  "in_reply_to_user_id" : 772796,
  "text" : "@Kabren I'm writing 0 blog posts today! Want to write me one? :P",
  "id" : 782805771,
  "in_reply_to_status_id" : 782805493,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Kabren",
  "in_reply_to_user_id_str" : "772796",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782806534",
  "text" : "Awesome. My external twitter feed is still hosed, I can't connect via Twhirl or Witty. Very annoying.",
  "id" : 782806534,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milksama",
      "screen_name" : "milksama",
      "indices" : [ 0, 9 ],
      "id_str" : "14245580",
      "id" : 14245580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782807987",
  "geo" : { },
  "id_str" : "782810264",
  "in_reply_to_user_id" : 14245580,
  "text" : "@milksama From both apps I get a message that my limit has been exceeded.",
  "id" : 782810264,
  "in_reply_to_status_id" : 782807987,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "milksama",
  "in_reply_to_user_id_str" : "14245580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782812003",
  "text" : "If a programming language was a boat: http:\/\/tinyurl.com\/2g5nmr",
  "id" : 782812003,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "milksama",
      "screen_name" : "milksama",
      "indices" : [ 0, 9 ],
      "id_str" : "14245580",
      "id" : 14245580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782816166",
  "geo" : { },
  "id_str" : "782830057",
  "in_reply_to_user_id" : 14245580,
  "text" : "@milksama Yeah, I turned the FB one off a few weeks ago.",
  "id" : 782830057,
  "in_reply_to_status_id" : 782816166,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "milksama",
  "in_reply_to_user_id_str" : "14245580",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782950349",
  "text" : "Basecamp is so nice and clean.",
  "id" : 782950349,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782980340",
  "text" : "Completely psyched at the possibility of a new Dune movie. THE SPICE MUST FLOW!",
  "id" : 782980340,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Holmes",
      "screen_name" : "joshholmes",
      "indices" : [ 0, 11 ],
      "id_str" : "5773152",
      "id" : 5773152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782983492",
  "geo" : { },
  "id_str" : "782984123",
  "in_reply_to_user_id" : 5773152,
  "text" : "@joshholmes I'm not quitting, my roommate came by and put it in. Note to self, lock computer when get up.",
  "id" : 782984123,
  "in_reply_to_status_id" : 782983492,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshholmes",
  "in_reply_to_user_id_str" : "5773152",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783029781",
  "text" : "SWFObject rocks. It just works.",
  "id" : 783029781,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783031763",
  "text" : "I can't stand Opera's non-native UI. It just bothers me. Doesn't feel natural like FF or IE does.",
  "id" : 783031763,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783035810",
  "text" : "This is huge! Windows 7 won't give a crap about legacy apps: http:\/\/tinyurl.com\/59tsh8",
  "id" : 783035810,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783050050",
  "text" : "Debating going to BarCampRochester tomorrow...",
  "id" : 783050050,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783055696",
  "text" : "Wow, I'm missing a lot of replies.",
  "id" : 783055696,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783037966",
  "geo" : { },
  "id_str" : "783056125",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf SWFObject is a open source cross-browser compatible javascript snippet to embed flash vids that is really easy to use. :)",
  "id" : 783056125,
  "in_reply_to_status_id" : 783037966,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa",
      "screen_name" : "TeteSagehen",
      "indices" : [ 0, 12 ],
      "id_str" : "434452435",
      "id" : 434452435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783056355",
  "geo" : { },
  "id_str" : "783056411",
  "in_reply_to_user_id" : 13696,
  "text" : "@TeteSagehen Re: IE feeling natural, at least it's got buttons, menus, etc like the rest of Windows has. Opera...just doesn't.",
  "id" : 783056411,
  "in_reply_to_status_id" : 783056355,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "TaePhoenix",
  "in_reply_to_user_id_str" : "13696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zubaz",
      "screen_name" : "zubaz",
      "indices" : [ 0, 6 ],
      "id_str" : "14243440",
      "id" : 14243440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783037738",
  "geo" : { },
  "id_str" : "783056636",
  "in_reply_to_user_id" : 14243440,
  "text" : "@zubaz That was my roommate messing around with my computer. :( You actually think I'd quit?!",
  "id" : 783056636,
  "in_reply_to_status_id" : 783037738,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zubaz",
  "in_reply_to_user_id_str" : "14243440",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783051948",
  "geo" : { },
  "id_str" : "783056876",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton Re: Barcamp...yeah, I have a massive amount of homework to do. But it should be fun, so I'll probably go.",
  "id" : 783056876,
  "in_reply_to_status_id" : 783051948,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783055509",
  "geo" : { },
  "id_str" : "783057205",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob Are you kidding me?! 64-bit only?! That would have messed up the drivers even more so than they were.",
  "id" : 783057205,
  "in_reply_to_status_id" : 783055509,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wm. Lee Williams",
      "screen_name" : "WmLee",
      "indices" : [ 0, 6 ],
      "id_str" : "14219412",
      "id" : 14219412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783048560",
  "geo" : { },
  "id_str" : "783057918",
  "in_reply_to_user_id" : 14219412,
  "text" : "@WmLee I think that's a different realm...new features in an editor vs. old apps not working anymore",
  "id" : 783057918,
  "in_reply_to_status_id" : 783048560,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "WmLee",
  "in_reply_to_user_id_str" : "14219412",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel de Icaza",
      "screen_name" : "migueldeicaza",
      "indices" : [ 0, 14 ],
      "id_str" : "823083",
      "id" : 823083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783058352",
  "geo" : { },
  "id_str" : "783059508",
  "in_reply_to_user_id" : 823083,
  "text" : "@migueldeicaza Please keep the screaming to a minimum.",
  "id" : 783059508,
  "in_reply_to_status_id" : 783058352,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "migueldeicaza",
  "in_reply_to_user_id_str" : "823083",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783060079",
  "geo" : { },
  "id_str" : "783061744",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob It just seems like it would have been an even worse snafu.",
  "id" : 783061744,
  "in_reply_to_status_id" : 783060079,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazinsyco",
      "screen_name" : "Amazingsyco",
      "indices" : [ 0, 12 ],
      "id_str" : "1665428419",
      "id" : 1665428419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783074772",
  "geo" : { },
  "id_str" : "783078132",
  "in_reply_to_user_id" : 658643,
  "text" : "@AmazingSyco Segmentation fault.",
  "id" : 783078132,
  "in_reply_to_status_id" : 783074772,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteveStreza",
  "in_reply_to_user_id_str" : "658643",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 0, 8 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783081765",
  "geo" : { },
  "id_str" : "783083031",
  "in_reply_to_user_id" : 739293,
  "text" : "@courosa This is ridiculous. I bet that professor mumbles to the board and doesn't return materials until the end of the semester.",
  "id" : 783083031,
  "in_reply_to_status_id" : 783081765,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "courosa",
  "in_reply_to_user_id_str" : "739293",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Shaler",
      "screen_name" : "brianshaler",
      "indices" : [ 0, 12 ],
      "id_str" : "6114312",
      "id" : 6114312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783085345",
  "geo" : { },
  "id_str" : "783085940",
  "in_reply_to_user_id" : 6114312,
  "text" : "@brianshaler Dude, that's EPIC.",
  "id" : 783085940,
  "in_reply_to_status_id" : 783085345,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "brianshaler",
  "in_reply_to_user_id_str" : "6114312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Allen",
      "screen_name" : "steveswrong",
      "indices" : [ 0, 12 ],
      "id_str" : "14175623",
      "id" : 14175623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783096459",
  "geo" : { },
  "id_str" : "783096897",
  "in_reply_to_user_id" : 14175623,
  "text" : "@steveswrong Hah, I need a new picture.",
  "id" : 783096897,
  "in_reply_to_status_id" : 783096459,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "steveswrong",
  "in_reply_to_user_id_str" : "14175623",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783097311",
  "geo" : { },
  "id_str" : "783098728",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort I prefer to be called a twit, not a tweeple.",
  "id" : 783098728,
  "in_reply_to_status_id" : 783097311,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Sutton",
      "screen_name" : "KellySutton",
      "indices" : [ 0, 12 ],
      "id_str" : "2232241",
      "id" : 2232241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783098893",
  "geo" : { },
  "id_str" : "783099802",
  "in_reply_to_user_id" : 2232241,
  "text" : "@KellySutton I am, at RIT.",
  "id" : 783099802,
  "in_reply_to_status_id" : 783098893,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "KellySutton",
  "in_reply_to_user_id_str" : "2232241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783102977",
  "geo" : { },
  "id_str" : "783126445",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I hate you.",
  "id" : 783126445,
  "in_reply_to_status_id" : 783102977,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782524223",
  "text" : "Sabres are losing :(",
  "id" : 782524223,
  "created_at" : "2008-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778024780",
  "geo" : { },
  "id_str" : "781857699",
  "in_reply_to_user_id" : 5744442,
  "text" : "@ablissfulgal needs to learn to pull april fools' day pranks on april fools day",
  "id" : 781857699,
  "in_reply_to_status_id" : 778024780,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "aquaranto",
  "in_reply_to_user_id_str" : "5744442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781857861",
  "text" : "I'm over 200 followers! Thanks everyone! :)",
  "id" : 781857861,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781864399",
  "text" : "Great blog post about low\/high level languages and ego: http:\/\/blog.slickedit.com\/?p=224",
  "id" : 781864399,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781883489",
  "text" : "16 things this blogger wish they taught in school: http:\/\/tinyurl.com\/2nv3gk",
  "id" : 781883489,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781900376",
  "text" : "What would you say....you do here. (Hulu is neat!) http:\/\/tinyurl.com\/2jce4c",
  "id" : 781900376,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781918039",
  "text" : "This is neat...saw an looking for a job personal ad on Google Ads. Clever.",
  "id" : 781918039,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781931386",
  "geo" : { },
  "id_str" : "781932367",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Hey! At least I can render a plane. Your sphere sucks compared to my spheres.",
  "id" : 781932367,
  "in_reply_to_status_id" : 781931386,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781932848",
  "geo" : { },
  "id_str" : "781933310",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Looks like I'll need to spill more blood soon...Phong lighting and much more needs to be done by next week",
  "id" : 781933310,
  "in_reply_to_status_id" : 781932848,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781935021",
  "text" : "Art Lebedev proves yet again that his company can't create anything practical. http:\/\/www.artlebedev.com\/everything\/defendius\/",
  "id" : 781935021,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781935007",
  "geo" : { },
  "id_str" : "781936602",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense has managed to break twitter. http:\/\/xs126.xs.to\/xs126\/08144\/phongphongphong547.png",
  "id" : 781936602,
  "in_reply_to_status_id" : 781935007,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781938957",
  "text" : "Sorta cthulu shirt on shirt.woot now: http:\/\/shirt.woot.com\/",
  "id" : 781938957,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoner",
      "screen_name" : "maslowbeer",
      "indices" : [ 0, 11 ],
      "id_str" : "13749072",
      "id" : 13749072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781950539",
  "geo" : { },
  "id_str" : "781951554",
  "in_reply_to_user_id" : 13749072,
  "text" : "@maslowbeer I suck at the internet.",
  "id" : 781951554,
  "in_reply_to_status_id" : 781950539,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "maslowbeer",
  "in_reply_to_user_id_str" : "13749072",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782088930",
  "text" : "This blogger thinks that killing XP is a horrible move for MS. MS definitely doesn't give a crap. http:\/\/tinyurl.com\/28j9h8",
  "id" : 782088930,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Pike",
      "screen_name" : "npike",
      "indices" : [ 0, 6 ],
      "id_str" : "13056112",
      "id" : 13056112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782089290",
  "geo" : { },
  "id_str" : "782090195",
  "in_reply_to_user_id" : 13056112,
  "text" : "@npike Ahh, the joys of oncampus living! Move offcampus as soon as possible, it's much better on the outside.",
  "id" : 782090195,
  "in_reply_to_status_id" : 782089290,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "npike",
  "in_reply_to_user_id_str" : "13056112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Stockton",
      "screen_name" : "johnnystock",
      "indices" : [ 0, 12 ],
      "id_str" : "12032162",
      "id" : 12032162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782088525",
  "geo" : { },
  "id_str" : "782090352",
  "in_reply_to_user_id" : 12032162,
  "text" : "@johnnystock Are you talking about Java?",
  "id" : 782090352,
  "in_reply_to_status_id" : 782088525,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "johnnystock",
  "in_reply_to_user_id_str" : "12032162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Stockton",
      "screen_name" : "johnnystock",
      "indices" : [ 0, 12 ],
      "id_str" : "12032162",
      "id" : 12032162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782091484",
  "geo" : { },
  "id_str" : "782092022",
  "in_reply_to_user_id" : 12032162,
  "text" : "@johnnystock Ah. You're on your own then! Be happy it works in the first place as a MS beta. ;)",
  "id" : 782092022,
  "in_reply_to_status_id" : 782091484,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "johnnystock",
  "in_reply_to_user_id_str" : "12032162",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782120886",
  "geo" : { },
  "id_str" : "782124074",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog I was noticing that with FF3b5 too :\/",
  "id" : 782124074,
  "in_reply_to_status_id" : 782120886,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782120244",
  "geo" : { },
  "id_str" : "782137825",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense the web interface is still slightly messed up because of your phongphongphonging",
  "id" : 782137825,
  "in_reply_to_status_id" : 782120244,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782172162",
  "text" : "I don't think I've ever made up more bullcrap for a test before in my life.",
  "id" : 782172162,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "trillian1117",
      "indices" : [ 0, 13 ],
      "id_str" : "4220781",
      "id" : 4220781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782173504",
  "geo" : { },
  "id_str" : "782175648",
  "in_reply_to_user_id" : 4220781,
  "text" : "@trillian1117 RIT http:\/\/www.rit.edu\/",
  "id" : 782175648,
  "in_reply_to_status_id" : 782173504,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "trillian1117",
  "in_reply_to_user_id_str" : "4220781",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782201279",
  "text" : "Is this kind of headline necessary? \"Crash fails to put kibosh on Seinfeld\" http:\/\/tinyurl.com\/yqqnro",
  "id" : 782201279,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Lu",
      "screen_name" : "christinelu",
      "indices" : [ 0, 12 ],
      "id_str" : "7782442",
      "id" : 7782442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782207823",
  "geo" : { },
  "id_str" : "782208261",
  "in_reply_to_user_id" : 7782442,
  "text" : "@christinelu I think Urban Dictionary is the true source for that information, not twitter.",
  "id" : 782208261,
  "in_reply_to_status_id" : 782207823,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "christinelu",
  "in_reply_to_user_id_str" : "7782442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish",
      "screen_name" : "Dayngr",
      "indices" : [ 0, 7 ],
      "id_str" : "5920872",
      "id" : 5920872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782211845",
  "geo" : { },
  "id_str" : "782212367",
  "in_reply_to_user_id" : 5920872,
  "text" : "@Dayngr The cranes are out to get us! NYC, detroit, now Miami. Where next?",
  "id" : 782212367,
  "in_reply_to_status_id" : 782211845,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Dayngr",
  "in_reply_to_user_id_str" : "5920872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Industry Girl",
      "screen_name" : "IndustryGirl",
      "indices" : [ 0, 13 ],
      "id_str" : "169539330",
      "id" : 169539330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782219404",
  "text" : "@IndustryGirl Google analytics takes a day or so for data to start coming into the system.",
  "id" : 782219404,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782241889",
  "geo" : { },
  "id_str" : "782244129",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn At least it's not rick roll...",
  "id" : 782244129,
  "in_reply_to_status_id" : 782241889,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782245314",
  "text" : "Communication classes FTL",
  "id" : 782245314,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Kelly",
      "screen_name" : "inkedmn",
      "indices" : [ 0, 8 ],
      "id_str" : "2844098929",
      "id" : 2844098929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782257026",
  "geo" : { },
  "id_str" : "782281631",
  "in_reply_to_user_id" : 434883,
  "text" : "@inkedmn Hah, talking about college classes. Quite aware of OO programming though ;)",
  "id" : 782281631,
  "in_reply_to_status_id" : 782257026,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mrbrettkelly",
  "in_reply_to_user_id_str" : "434883",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782295426",
  "text" : "Amy's organic spicy chipotle salsa is 100% delicious.",
  "id" : 782295426,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZOOPED SOCIAL MEDIA ",
      "screen_name" : "zooped",
      "indices" : [ 0, 7 ],
      "id_str" : "1067137999",
      "id" : 1067137999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782307301",
  "geo" : { },
  "id_str" : "782307995",
  "in_reply_to_user_id" : 5840792,
  "text" : "@zooped Turn this into MySpace and I will end you.",
  "id" : 782307995,
  "in_reply_to_status_id" : 782307301,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "zooped1",
  "in_reply_to_user_id_str" : "5840792",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Scott",
      "screen_name" : "IslandDog",
      "indices" : [ 0, 10 ],
      "id_str" : "5278561",
      "id" : 5278561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782308000",
  "geo" : { },
  "id_str" : "782308726",
  "in_reply_to_user_id" : 5278561,
  "text" : "@IslandDog No, and Tom can go shove it.",
  "id" : 782308726,
  "in_reply_to_status_id" : 782308000,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "IslandDog",
  "in_reply_to_user_id_str" : "5278561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782314475",
  "geo" : { },
  "id_str" : "782317042",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued how about \"Rick Astley is never gonna give you up\"",
  "id" : 782317042,
  "in_reply_to_status_id" : 782314475,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782320061",
  "text" : "Do any of the .NET masters know why WPF won't show any images with external URLs for me?",
  "id" : 782320061,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellis",
      "screen_name" : "cisellis",
      "indices" : [ 0, 9 ],
      "id_str" : "3178361",
      "id" : 3178361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782321925",
  "geo" : { },
  "id_str" : "782327113",
  "in_reply_to_user_id" : 3178361,
  "text" : "@cisellis Yes, I did. I had a feeling someone at vertigo would know! I'll uninstall it, I'm usually in IE7 mode anyway.",
  "id" : 782327113,
  "in_reply_to_status_id" : 782321925,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "cisellis",
  "in_reply_to_user_id_str" : "3178361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellis",
      "screen_name" : "cisellis",
      "indices" : [ 0, 9 ],
      "id_str" : "3178361",
      "id" : 3178361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782321925",
  "geo" : { },
  "id_str" : "782333196",
  "in_reply_to_user_id" : 3178361,
  "text" : "@cisellis Uninstalled and it works fine now. Thanks much!",
  "id" : 782333196,
  "in_reply_to_status_id" : 782321925,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "cisellis",
  "in_reply_to_user_id_str" : "3178361",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellis",
      "screen_name" : "cisellis",
      "indices" : [ 68, 77 ],
      "id_str" : "3178361",
      "id" : 3178361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782332885",
  "geo" : { },
  "id_str" : "782333451",
  "in_reply_to_user_id" : 1388411,
  "text" : "@TheADOGuy It was due to the IE8 beta being installed, according to @cisellis it breaks WPF BitmapImage",
  "id" : 782333451,
  "in_reply_to_status_id" : 782332885,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782342673",
  "geo" : { },
  "id_str" : "782345199",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Hey, Trent.",
  "id" : 782345199,
  "in_reply_to_status_id" : 782342673,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782345479",
  "geo" : { },
  "id_str" : "782345723",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense I hate you, and all that you stand for.",
  "id" : 782345723,
  "in_reply_to_status_id" : 782345479,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Archer",
      "screen_name" : "pilotbob",
      "indices" : [ 0, 9 ],
      "id_str" : "14185685",
      "id" : 14185685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782351947",
  "geo" : { },
  "id_str" : "782353967",
  "in_reply_to_user_id" : 14185685,
  "text" : "@pilotbob It's broken. Isn't that enough? :)",
  "id" : 782353967,
  "in_reply_to_status_id" : 782351947,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "pilotbob",
  "in_reply_to_user_id_str" : "14185685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 10, 15 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782393149",
  "text" : "Listening @wilw's PAX 07 keynote. Why haven't I done this before.",
  "id" : 782393149,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782406741",
  "text" : "Now this is a different Mario t-shirt. http:\/\/tinyurl.com\/37n5bm",
  "id" : 782406741,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782420280",
  "text" : "Setting up my playlist after listening to an individual file in winamp is always a pain in the arse.",
  "id" : 782420280,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hanselman",
      "screen_name" : "shanselman",
      "indices" : [ 0, 11 ],
      "id_str" : "5676102",
      "id" : 5676102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782433378",
  "geo" : { },
  "id_str" : "782435964",
  "in_reply_to_user_id" : 5676102,
  "text" : "@shanselman Vista needs 8 gigs now? (Sorry, had to be said!)",
  "id" : 782435964,
  "in_reply_to_status_id" : 782433378,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "shanselman",
  "in_reply_to_user_id_str" : "5676102",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782438381",
  "geo" : { },
  "id_str" : "782440938",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Eh, screw iTunes. Winamp skins ftw.",
  "id" : 782440938,
  "in_reply_to_status_id" : 782438381,
  "created_at" : "2008-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781746235",
  "text" : "MY RAYTRACER IS FINALLY WORKING. (2 days after the project is due)",
  "id" : 781746235,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781767678",
  "text" : "Is this for real? HUGE number 5 on the new 5 dollar bill? How lame. http:\/\/www.moneyfactory.gov\/newmoney\/main.cfm\/currency\/new5",
  "id" : 781767678,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781769000",
  "geo" : { },
  "id_str" : "781769233",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 Yeah, that's how I found the $5 bill. What a joke.",
  "id" : 781769233,
  "in_reply_to_status_id" : 781769000,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781769521",
  "geo" : { },
  "id_str" : "781772275",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway I need to hack it too, I'm not on that list yet :P",
  "id" : 781772275,
  "in_reply_to_status_id" : 781769521,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781773726",
  "geo" : { },
  "id_str" : "781774757",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Yeah, I don't fully understand it either...",
  "id" : 781774757,
  "in_reply_to_status_id" : 781773726,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781778499",
  "geo" : { },
  "id_str" : "781779881",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense oh man. we'll have to play online! This was a triumph...",
  "id" : 781779881,
  "in_reply_to_status_id" : 781778499,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781169211",
  "text" : "Still Alive on Rock Band is delicious and moist.",
  "id" : 781169211,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Starr",
      "screen_name" : "NickStarr",
      "indices" : [ 0, 10 ],
      "id_str" : "48933",
      "id" : 48933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781153562",
  "geo" : { },
  "id_str" : "781173264",
  "in_reply_to_user_id" : 48933,
  "text" : "@NickStarr I had the same deal with Woot today. I keep on checking my account page too and nothing",
  "id" : 781173264,
  "in_reply_to_status_id" : 781153562,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "NickStarr",
  "in_reply_to_user_id_str" : "48933",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781213492",
  "text" : "Why is it that I can't do homework until after 10? This is a serious issue. And I won't be able to do a blog either. Not so serious though.",
  "id" : 781213492,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781222581",
  "text" : "Are those clouds stratocumulus? http:\/\/tinyurl.com\/344587",
  "id" : 781222581,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781229927",
  "text" : "I want to build a fort out of bloxes. http:\/\/bloxes.com\/",
  "id" : 781229927,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781234684",
  "text" : "WHOPR 2.0 = RIPLEY? Wargames 2 trailer: http:\/\/tinyurl.com\/2mhjy2",
  "id" : 781234684,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Moore",
      "screen_name" : "abiteofsanity",
      "indices" : [ 0, 14 ],
      "id_str" : "954792990",
      "id" : 954792990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781239214",
  "text" : "@abiteofsanity As long as there's no Princess Bride 2, we'll be safe.",
  "id" : 781239214,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781243811",
  "text" : "Googling my name is irksome because Google suggests \"Did you mean: Nick Guarino\" NO I DID NOT MEAN THAT. http:\/\/tinyurl.com\/2joxtl",
  "id" : 781243811,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781247881",
  "text" : "Trying to figure out a new blog schedule. Current one isn't working out for me. Other than stopping blogging, anyone have some suggestions?",
  "id" : 781247881,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781417421",
  "text" : "Probably giving up blogging, when I could be coding instead, and then blogging about coding.",
  "id" : 781417421,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781428373",
  "text" : "I can definitely feel that Firefox 3 is faster than 2 when switching back to 2 on my desktop. I miss FF3...the awesome bar and tabs rule.",
  "id" : 781428373,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Downe",
      "screen_name" : "Natbat",
      "indices" : [ 0, 7 ],
      "id_str" : "12161",
      "id" : 12161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781436362",
  "geo" : { },
  "id_str" : "781439495",
  "in_reply_to_user_id" : 12161,
  "text" : "@Natbat Honey or spicy?",
  "id" : 781439495,
  "in_reply_to_status_id" : 781436362,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Natbat",
  "in_reply_to_user_id_str" : "12161",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Vos",
      "screen_name" : "elvo86",
      "indices" : [ 0, 7 ],
      "id_str" : "14183391",
      "id" : 14183391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781437054",
  "geo" : { },
  "id_str" : "781440683",
  "in_reply_to_user_id" : 14183391,
  "text" : "@elvo86 I can't seem to get Firebug, Delicious Bookmarks, or Web Developer to work with FF3, sadly.",
  "id" : 781440683,
  "in_reply_to_status_id" : 781437054,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "elvo86",
  "in_reply_to_user_id_str" : "14183391",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Crassweller",
      "screen_name" : "zoomba",
      "indices" : [ 0, 7 ],
      "id_str" : "6118872",
      "id" : 6118872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781444684",
  "geo" : { },
  "id_str" : "781444979",
  "in_reply_to_user_id" : 6118872,
  "text" : "@zoomba It's around 10 degrees colder here. Consider yourself lucky.",
  "id" : 781444979,
  "in_reply_to_status_id" : 781444684,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoomba",
  "in_reply_to_user_id_str" : "6118872",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Polack",
      "screen_name" : "mittense",
      "indices" : [ 0, 9 ],
      "id_str" : "14237677",
      "id" : 14237677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781479968",
  "geo" : { },
  "id_str" : "781484475",
  "in_reply_to_user_id" : 14237677,
  "text" : "@mittense Don't make me summon the ghost of Turing on you.",
  "id" : 781484475,
  "in_reply_to_status_id" : 781479968,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mittense",
  "in_reply_to_user_id_str" : "14237677",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781492732",
  "text" : "Programming. You're doing it wrong. http:\/\/tinyurl.com\/27prnt",
  "id" : 781492732,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781504591",
  "geo" : { },
  "id_str" : "781506338",
  "in_reply_to_user_id" : 10058232,
  "text" : "@krisbjorkman Me too. And I bought an acoustic, but I want to learn bass now instead.",
  "id" : 781506338,
  "in_reply_to_status_id" : 781504591,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "kristophrrr",
  "in_reply_to_user_id_str" : "10058232",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyell E. Petersen",
      "screen_name" : "93octane",
      "indices" : [ 0, 9 ],
      "id_str" : "1508231",
      "id" : 1508231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781502924",
  "geo" : { },
  "id_str" : "781507088",
  "in_reply_to_user_id" : 1508231,
  "text" : "@93octane Supposedly that's the guy who made Lisp. And supposedly I'm doing it completely wrong.",
  "id" : 781507088,
  "in_reply_to_status_id" : 781502924,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "93octane",
  "in_reply_to_user_id_str" : "1508231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CariElf",
      "screen_name" : "CariElf",
      "indices" : [ 0, 8 ],
      "id_str" : "14238116",
      "id" : 14238116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781515962",
  "geo" : { },
  "id_str" : "781516701",
  "in_reply_to_user_id" : 14238116,
  "text" : "@CariElf we could hop onto freenode! Or just use Twitter. :)",
  "id" : 781516701,
  "in_reply_to_status_id" : 781515962,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "CariElf",
  "in_reply_to_user_id_str" : "14238116",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781561961",
  "text" : "People get way too excited on the Price is Right.",
  "id" : 781561961,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781566512",
  "text" : "If my professor says POJOs one more time, I'm going to scream.",
  "id" : 781566512,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781579880",
  "text" : "WoW equipment could not be seized by authorities, as it is soulbound: http:\/\/snurl.com\/23a2l",
  "id" : 781579880,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781582127",
  "text" : "Great LJ post about why ISO doesn't matter for software anymore with the OOXML decision: http:\/\/bjacob.livejournal.com\/5086.html",
  "id" : 781582127,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781594040",
  "text" : "Anyone ever heard of this? Many of the twitterati are on it: http:\/\/tweets.shoutingmat.ch\/",
  "id" : 781594040,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781646050",
  "text" : "Professor displays a snippet from the Grinch Stole Christmas while talking about Perlin noise = win.",
  "id" : 781646050,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781655056",
  "text" : "Mmm, Firefox 3 beta 5. I still miss my plugins but it's so damn fast.",
  "id" : 781655056,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0413\u0440\u0430\u043D\u043E\u0432\u0441\u043A\u0430\u044F \u0422\u0430\u0442\u044C\u044F\u043D\u0430",
      "screen_name" : "anjrued",
      "indices" : [ 0, 8 ],
      "id_str" : "2836824647",
      "id" : 2836824647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781666130",
  "geo" : { },
  "id_str" : "781669295",
  "in_reply_to_user_id" : 860851,
  "text" : "@anjrued I would disagree with the state college point in the '34 tips' list. The rest are decent though.",
  "id" : 781669295,
  "in_reply_to_status_id" : 781666130,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "andrewdobrow",
  "in_reply_to_user_id_str" : "860851",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 0, 12 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781668329",
  "geo" : { },
  "id_str" : "781677973",
  "in_reply_to_user_id" : 765694,
  "text" : "@jongalloway Thanks! My plugins are back now.",
  "id" : 781677973,
  "in_reply_to_status_id" : 781668329,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "jongalloway",
  "in_reply_to_user_id_str" : "765694",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781730761",
  "geo" : { },
  "id_str" : "781732513",
  "in_reply_to_user_id" : 14152810,
  "text" : "@offwhitemke I've been wondering the same. No ads, no swag...do they make pizza or something?",
  "id" : 781732513,
  "in_reply_to_status_id" : 781730761,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "brennanMKE",
  "in_reply_to_user_id_str" : "14152810",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781740047",
  "text" : "FF3b5 is crashing for me a lot when using GMail, going back to FF2... It could be that I enabled plugins that aren't exactly compatible.",
  "id" : 781740047,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Galloway",
      "screen_name" : "jongalloway",
      "indices" : [ 26, 38 ],
      "id_str" : "765694",
      "id" : 765694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781740020",
  "geo" : { },
  "id_str" : "781742957",
  "in_reply_to_user_id" : 11204662,
  "text" : "@tw3nty3ight Yeah, I used @jongalloway's suggestion: http:\/\/is.gd\/3R2",
  "id" : 781742957,
  "in_reply_to_status_id" : 781740020,
  "created_at" : "2008-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "F3SportsCards",
  "in_reply_to_user_id_str" : "11204662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]
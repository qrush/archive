Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131217939566313473",
  "text" : "So apparently today was Halloween?",
  "id" : 131217939566313473,
  "created_at" : "2011-11-01 03:56:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131204831447748608",
  "text" : "Made it to Buffalo, chilling with the dog at the parents' place. Thanks for the well wishes everyone.",
  "id" : 131204831447748608,
  "created_at" : "2011-11-01 03:04:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131168497786040320",
  "text" : "Also heard Tom Sawyer. Radio is great tonight.",
  "id" : 131168497786040320,
  "created_at" : "2011-11-01 00:39:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131155753150054401",
  "geo" : { },
  "id_str" : "131168296312635392",
  "in_reply_to_user_id" : 372319943,
  "text" : "@A_R_Q_522 hey hey!! More family tweets !",
  "id" : 131168296312635392,
  "in_reply_to_status_id" : 131155753150054401,
  "created_at" : "2011-11-01 00:38:53 +0000",
  "in_reply_to_screen_name" : "Drew_Baggg",
  "in_reply_to_user_id_str" : "372319943",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131148030274584577",
  "text" : "So far, Spirit of Radio, Fly by Night, and Subdivisions all on separate radio stations. Fuck yeah.",
  "id" : 131148030274584577,
  "created_at" : "2011-10-31 23:18:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon SJW Yurek",
      "screen_name" : "jyurek",
      "indices" : [ 0, 7 ],
      "id_str" : "6505422",
      "id" : 6505422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130971914775699457",
  "geo" : { },
  "id_str" : "130977497901842432",
  "in_reply_to_user_id" : 6505422,
  "text" : "@jyurek hah thanks. Already being a whiner.",
  "id" : 130977497901842432,
  "in_reply_to_status_id" : 130971914775699457,
  "created_at" : "2011-10-31 12:00:43 +0000",
  "in_reply_to_screen_name" : "jyurek",
  "in_reply_to_user_id_str" : "6505422",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130965603371585536",
  "text" : "MOVING DAY! THIS TWEET AIS AN ACCURATE REFLECTION OF HOW LITTLE SLEEP I GOT",
  "id" : 130965603371585536,
  "created_at" : "2011-10-31 11:13:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130847709333692416",
  "geo" : { },
  "id_str" : "130884552716595200",
  "in_reply_to_user_id" : 265696367,
  "text" : "@SamBaskinger nope :)",
  "id" : 130884552716595200,
  "in_reply_to_status_id" : 130847709333692416,
  "created_at" : "2011-10-31 05:51:23 +0000",
  "in_reply_to_screen_name" : "njswi",
  "in_reply_to_user_id_str" : "265696367",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Helmkamp",
      "screen_name" : "brynary",
      "indices" : [ 0, 8 ],
      "id_str" : "2049071",
      "id" : 2049071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130763241864441856",
  "geo" : { },
  "id_str" : "130826288410787840",
  "in_reply_to_user_id" : 2049071,
  "text" : "@brynary moving to buffalo! You know, the other biggest city in your state :)",
  "id" : 130826288410787840,
  "in_reply_to_status_id" : 130763241864441856,
  "created_at" : "2011-10-31 01:59:52 +0000",
  "in_reply_to_screen_name" : "brynary",
  "in_reply_to_user_id_str" : "2049071",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "singheyjude",
      "indices" : [ 0, 12 ],
      "id_str" : "5744132",
      "id" : 5744132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130810169616642048",
  "geo" : { },
  "id_str" : "130812626556030976",
  "in_reply_to_user_id" : 5744132,
  "text" : "@singheyjude haha, we procrastishopped",
  "id" : 130812626556030976,
  "in_reply_to_status_id" : 130810169616642048,
  "created_at" : "2011-10-31 01:05:35 +0000",
  "in_reply_to_screen_name" : "singheyjude",
  "in_reply_to_user_id_str" : "5744132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan R. Smith",
      "screen_name" : "ryandotsmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15701745",
      "id" : 15701745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130751328094920704",
  "geo" : { },
  "id_str" : "130797729206116352",
  "in_reply_to_user_id" : 15701745,
  "text" : "@ryandotsmith in the dark grim antifuture....",
  "id" : 130797729206116352,
  "in_reply_to_status_id" : 130751328094920704,
  "created_at" : "2011-10-31 00:06:23 +0000",
  "in_reply_to_screen_name" : "ryandotsmith",
  "in_reply_to_user_id_str" : "15701745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130760494935064576",
  "text" : "Last minute pre moving IKEA run.",
  "id" : 130760494935064576,
  "created_at" : "2011-10-30 21:38:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Barnette",
      "screen_name" : "jbarnette",
      "indices" : [ 0, 10 ],
      "id_str" : "10453902",
      "id" : 10453902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130744450946318336",
  "geo" : { },
  "id_str" : "130749609340440576",
  "in_reply_to_user_id" : 10453902,
  "text" : "@jbarnette nice! What a boss.",
  "id" : 130749609340440576,
  "in_reply_to_status_id" : 130744450946318336,
  "created_at" : "2011-10-30 20:55:10 +0000",
  "in_reply_to_screen_name" : "jbarnette",
  "in_reply_to_user_id_str" : "10453902",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Keys",
      "screen_name" : "therealadam",
      "indices" : [ 0, 12 ],
      "id_str" : "12661",
      "id" : 12661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130701151267065856",
  "geo" : { },
  "id_str" : "130747612398755840",
  "in_reply_to_user_id" : 12661,
  "text" : "@therealadam definitely. Sheds a ton.",
  "id" : 130747612398755840,
  "in_reply_to_status_id" : 130701151267065856,
  "created_at" : "2011-10-30 20:47:14 +0000",
  "in_reply_to_screen_name" : "therealadam",
  "in_reply_to_user_id_str" : "12661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/q4E1sXIL",
      "expanded_url" : "http:\/\/instagr.am\/p\/SE6-8\/",
      "display_url" : "instagr.am\/p\/SE6-8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "130700462080004097",
  "text" : "Not helping with packing. http:\/\/t.co\/q4E1sXIL",
  "id" : 130700462080004097,
  "created_at" : "2011-10-30 17:39:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mislav Marohni\u0107",
      "screen_name" : "mislav",
      "indices" : [ 0, 7 ],
      "id_str" : "7516242",
      "id" : 7516242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130669443142520832",
  "geo" : { },
  "id_str" : "130672783175847936",
  "in_reply_to_user_id" : 7516242,
  "text" : "@mislav exactly what I got out of it. Why is so much effort in web dev spent on reinventing things? :(",
  "id" : 130672783175847936,
  "in_reply_to_status_id" : 130669443142520832,
  "created_at" : "2011-10-30 15:49:53 +0000",
  "in_reply_to_screen_name" : "mislav",
  "in_reply_to_user_id_str" : "7516242",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurtis R.G.",
      "screen_name" : "krainboltgreene",
      "indices" : [ 0, 16 ],
      "id_str" : "55137522",
      "id" : 55137522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130061748681183233",
  "geo" : { },
  "id_str" : "130077368722272256",
  "in_reply_to_user_id" : 55137522,
  "text" : "@krainboltgreene thanks dude. Trying to stay positive :)",
  "id" : 130077368722272256,
  "in_reply_to_status_id" : 130061748681183233,
  "created_at" : "2011-10-29 00:23:56 +0000",
  "in_reply_to_screen_name" : "krainboltgreene",
  "in_reply_to_user_id_str" : "55137522",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130054320061300738",
  "geo" : { },
  "id_str" : "130054683917164544",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella yes!!! Fork it!",
  "id" : 130054683917164544,
  "in_reply_to_status_id" : 130054320061300738,
  "created_at" : "2011-10-28 22:53:47 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Peek",
      "screen_name" : "joshpeek",
      "indices" : [ 0, 9 ],
      "id_str" : "616163",
      "id" : 616163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130043101573160960",
  "geo" : { },
  "id_str" : "130053672729198592",
  "in_reply_to_user_id" : 616163,
  "text" : "@joshpeek can we get this guides.rubygems.org please?",
  "id" : 130053672729198592,
  "in_reply_to_status_id" : 130043101573160960,
  "created_at" : "2011-10-28 22:49:46 +0000",
  "in_reply_to_screen_name" : "joshpeek",
  "in_reply_to_user_id_str" : "616163",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/hHFdoxYA",
      "expanded_url" : "http:\/\/gemfamily.info",
      "display_url" : "gemfamily.info"
    } ]
  },
  "in_reply_to_status_id_str" : "130019187883130880",
  "geo" : { },
  "id_str" : "130019670509092864",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy also there is http:\/\/t.co\/hHFdoxYA that is doing similar things.",
  "id" : 130019670509092864,
  "in_reply_to_status_id" : 130019187883130880,
  "created_at" : "2011-10-28 20:34:39 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130019187883130880",
  "geo" : { },
  "id_str" : "130019327347929088",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy the contribute site is meant to help organize people who want to work together, could toss it there",
  "id" : 130019327347929088,
  "in_reply_to_status_id" : 130019187883130880,
  "created_at" : "2011-10-28 20:33:17 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130018247276888064",
  "geo" : { },
  "id_str" : "130018474369093632",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy would be cool to see as a separate, official service that uses our api :)",
  "id" : 130018474369093632,
  "in_reply_to_status_id" : 130018247276888064,
  "created_at" : "2011-10-28 20:29:54 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130018079290822656",
  "geo" : { },
  "id_str" : "130018414113734656",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy there are patches for it out there but I haven't been  impressed with the quality of code or how they looked",
  "id" : 130018414113734656,
  "in_reply_to_status_id" : 130018079290822656,
  "created_at" : "2011-10-28 20:29:40 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tender",
      "screen_name" : "tenderapp",
      "indices" : [ 20, 30 ],
      "id_str" : "17351175",
      "id" : 17351175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/NJdvuzBF",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "130016495504867329",
  "text" : "Also huge thanks to @tenderapp for letting us run http:\/\/t.co\/NJdvuzBF on their OSS plan. Community win!",
  "id" : 130016495504867329,
  "created_at" : "2011-10-28 20:22:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 3, 13 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 53, 62 ],
      "id_str" : "15527007",
      "id" : 15527007
    }, {
      "name" : "Gaug.es",
      "screen_name" : "gaugesapp",
      "indices" : [ 71, 81 ],
      "id_str" : "245369690",
      "id" : 245369690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/lJ0Uk2G2",
      "expanded_url" : "http:\/\/rubygems.org",
      "display_url" : "rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "130016164519747584",
  "text" : "RT @gemcutter: Finally giving props in our footer to @NewRelic and now @gaugesapp for helping us out on http:\/\/t.co\/lJ0Uk2G2. Seriously, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Relic",
        "screen_name" : "newrelic",
        "indices" : [ 38, 47 ],
        "id_str" : "15527007",
        "id" : 15527007
      }, {
        "name" : "Gaug.es",
        "screen_name" : "gaugesapp",
        "indices" : [ 56, 66 ],
        "id_str" : "245369690",
        "id" : 245369690
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/lJ0Uk2G2",
        "expanded_url" : "http:\/\/rubygems.org",
        "display_url" : "rubygems.org"
      } ]
    },
    "geo" : { },
    "id_str" : "130016050644389890",
    "text" : "Finally giving props in our footer to @NewRelic and now @gaugesapp for helping us out on http:\/\/t.co\/lJ0Uk2G2. Seriously, thanks!",
    "id" : 130016050644389890,
    "created_at" : "2011-10-28 20:20:16 +0000",
    "user" : {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "protected" : false,
      "id_str" : "42259749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/228476150\/gemcutter_normal.jpg",
      "id" : 42259749,
      "verified" : false
    }
  },
  "id" : 130016164519747584,
  "created_at" : "2011-10-28 20:20:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/wsMcKPGE",
      "expanded_url" : "http:\/\/contribute.rubygems.org\/",
      "display_url" : "contribute.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "130015747513659393",
  "text" : "Contribute to RubyGems! Please! http:\/\/t.co\/wsMcKPGE",
  "id" : 130015747513659393,
  "created_at" : "2011-10-28 20:19:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sahil Lavingia",
      "screen_name" : "slavingia",
      "indices" : [ 0, 10 ],
      "id_str" : "435126512",
      "id" : 435126512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130015059278692352",
  "geo" : { },
  "id_str" : "130015555167068160",
  "in_reply_to_user_id" : 16347964,
  "text" : "@slavingia how...how much did you pay for that domain?!",
  "id" : 130015555167068160,
  "in_reply_to_status_id" : 130015059278692352,
  "created_at" : "2011-10-28 20:18:18 +0000",
  "in_reply_to_screen_name" : "shl",
  "in_reply_to_user_id_str" : "16347964",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    }, {
      "name" : "Joe Damato",
      "screen_name" : "joedamato",
      "indices" : [ 38, 48 ],
      "id_str" : "23830105",
      "id" : 23830105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130009878411493377",
  "geo" : { },
  "id_str" : "130010409557164032",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham oh maybe they're looking for @joedamato ?",
  "id" : 130010409557164032,
  "in_reply_to_status_id" : 130009878411493377,
  "created_at" : "2011-10-28 19:57:51 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 5, 16 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/jAD1yxhH",
      "expanded_url" : "http:\/\/instagr.am\/p\/RwxXN\/",
      "display_url" : "instagr.am\/p\/RwxXN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "129953570341666817",
  "text" : "Last @thoughtbot lunch for me, Yuengling FTW. http:\/\/t.co\/jAD1yxhH",
  "id" : 129953570341666817,
  "created_at" : "2011-10-28 16:12:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/ABzySKyo",
      "expanded_url" : "https:\/\/lh4.googleusercontent.com\/-3H-b7AFnpE4\/TqhDiDPG0KI\/AAAAAAAAKJU\/QIpbMwzYsn4\/s400\/boss.gif",
      "display_url" : "lh4.googleusercontent.com\/-3H-b7AFnpE4\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129942042066419712",
  "text" : "Current status: http:\/\/t.co\/ABzySKyo",
  "id" : 129942042066419712,
  "created_at" : "2011-10-28 15:26:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/w2OfmLfc",
      "expanded_url" : "http:\/\/osxdaily.com\/wp-content\/uploads\/2011\/04\/south-park-human-centipad.jpg",
      "display_url" : "osxdaily.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129938888964841472",
  "text" : "Every time I agree to a new iTunes EULA I'm terrified of http:\/\/t.co\/w2OfmLfc",
  "id" : 129938888964841472,
  "created_at" : "2011-10-28 15:13:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129931304144863233",
  "geo" : { },
  "id_str" : "129937384312807425",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems broespionage",
  "id" : 129937384312807425,
  "in_reply_to_status_id" : 129931304144863233,
  "created_at" : "2011-10-28 15:07:41 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129935261277761536",
  "geo" : { },
  "id_str" : "129936952551153665",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh been using it constantly here, mostly because it's faster than typing especially when on the move",
  "id" : 129936952551153665,
  "in_reply_to_status_id" : 129935261277761536,
  "created_at" : "2011-10-28 15:05:58 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 0, 15 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129933431399387136",
  "geo" : { },
  "id_str" : "129934385599361024",
  "in_reply_to_user_id" : 6151392,
  "text" : "@TheDeadSerious it's 1.0 when you break something and ruin enough people's day when you should have put out 1.0 a long time ago :)",
  "id" : 129934385599361024,
  "in_reply_to_status_id" : 129933431399387136,
  "created_at" : "2011-10-28 14:55:46 +0000",
  "in_reply_to_screen_name" : "TheDeadSerious",
  "in_reply_to_user_id_str" : "6151392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129744463114420224",
  "text" : "@IselaMariaPhoto nope, hahah",
  "id" : 129744463114420224,
  "created_at" : "2011-10-28 02:21:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129705192710078464",
  "geo" : { },
  "id_str" : "129712268110864384",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie damn, I can't find out who got hired now",
  "id" : 129712268110864384,
  "in_reply_to_status_id" : 129705192710078464,
  "created_at" : "2011-10-28 00:13:09 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129699930297204736",
  "geo" : { },
  "id_str" : "129702637695270912",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton TMI",
  "id" : 129702637695270912,
  "in_reply_to_status_id" : 129699930297204736,
  "created_at" : "2011-10-27 23:34:53 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129644381073448960",
  "geo" : { },
  "id_str" : "129646168836812800",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik is this a halloween costume!?",
  "id" : 129646168836812800,
  "in_reply_to_status_id" : 129644381073448960,
  "created_at" : "2011-10-27 19:50:30 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Bedell",
      "screen_name" : "kbedell",
      "indices" : [ 0, 8 ],
      "id_str" : "6578432",
      "id" : 6578432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129607470405517312",
  "geo" : { },
  "id_str" : "129644258176155648",
  "in_reply_to_user_id" : 6578432,
  "text" : "@kbedell it is not hosted redis. check out redistogo or openredis for that.",
  "id" : 129644258176155648,
  "in_reply_to_status_id" : 129607470405517312,
  "created_at" : "2011-10-27 19:42:54 +0000",
  "in_reply_to_screen_name" : "kbedell",
  "in_reply_to_user_id_str" : "6578432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/129643706499350528\/photo\/1",
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/KRwN2jiP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcyWQ6GCQAAOpQo.png",
      "id_str" : "129643706503544832",
      "id" : 129643706503544832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcyWQ6GCQAAOpQo.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 659
      } ],
      "display_url" : "pic.twitter.com\/KRwN2jiP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129643706499350528",
  "text" : "This is seriously who Google+ thinks I should follow? http:\/\/t.co\/KRwN2jiP",
  "id" : 129643706499350528,
  "created_at" : "2011-10-27 19:40:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    }, {
      "name" : "Tim Pope",
      "screen_name" : "tpope",
      "indices" : [ 26, 32 ],
      "id_str" : "8000842",
      "id" : 8000842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129420119817469952",
  "geo" : { },
  "id_str" : "129516105139093504",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida I'm convinced @tpope can do anything with vim.",
  "id" : 129516105139093504,
  "in_reply_to_status_id" : 129420119817469952,
  "created_at" : "2011-10-27 11:13:40 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/gHfIWLPH",
      "expanded_url" : "http:\/\/twolivesleft.com\/Codify\/",
      "display_url" : "twolivesleft.com\/Codify\/"
    } ]
  },
  "geo" : { },
  "id_str" : "129341274544291841",
  "text" : "Is this the first true touch screen IDE? Holy shit, I want it. http:\/\/t.co\/gHfIWLPH",
  "id" : 129341274544291841,
  "created_at" : "2011-10-26 23:38:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 0, 7 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/OMYlKOqo",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "in_reply_to_status_id_str" : "129266706685243393",
  "geo" : { },
  "id_str" : "129269748193181696",
  "in_reply_to_user_id" : 3928731,
  "text" : "@cssboy basically, http:\/\/t.co\/OMYlKOqo",
  "id" : 129269748193181696,
  "in_reply_to_status_id" : 129266706685243393,
  "created_at" : "2011-10-26 18:54:44 +0000",
  "in_reply_to_screen_name" : "cssboy",
  "in_reply_to_user_id_str" : "3928731",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 0, 4 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129234488885649410",
  "geo" : { },
  "id_str" : "129235435883995136",
  "in_reply_to_user_id" : 5523,
  "text" : "@pat whatever you learn, can you make a guide on guides.rubygems.org",
  "id" : 129235435883995136,
  "in_reply_to_status_id" : 129234488885649410,
  "created_at" : "2011-10-26 16:38:23 +0000",
  "in_reply_to_screen_name" : "pat",
  "in_reply_to_user_id_str" : "5523",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cloudhead",
      "screen_name" : "cloudhead",
      "indices" : [ 3, 13 ],
      "id_str" : "36156834",
      "id" : 36156834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/zc6s9UYD",
      "expanded_url" : "http:\/\/a7.sphotos.ak.fbcdn.net\/hphotos-ak-ash4\/294177_294589423903851_205344452828349_1132844_758260480_n.jpg",
      "display_url" : "a7.sphotos.ak.fbcdn.net\/hphotos-ak-ash\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129232154877100032",
  "text" : "RT @cloudhead: \"Occupy Arrakis\" is here folks! http:\/\/t.co\/zc6s9UYD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/zc6s9UYD",
        "expanded_url" : "http:\/\/a7.sphotos.ak.fbcdn.net\/hphotos-ak-ash4\/294177_294589423903851_205344452828349_1132844_758260480_n.jpg",
        "display_url" : "a7.sphotos.ak.fbcdn.net\/hphotos-ak-ash\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129231862185992192",
    "text" : "\"Occupy Arrakis\" is here folks! http:\/\/t.co\/zc6s9UYD",
    "id" : 129231862185992192,
    "created_at" : "2011-10-26 16:24:11 +0000",
    "user" : {
      "name" : "cloudhead",
      "screen_name" : "cloudhead",
      "protected" : false,
      "id_str" : "36156834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/339068516\/avatar-152_normal.png",
      "id" : 36156834,
      "verified" : false
    }
  },
  "id" : 129232154877100032,
  "created_at" : "2011-10-26 16:25:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 57, 62 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/9lzaOWat",
      "expanded_url" : "http:\/\/exceptionalruby.com\/",
      "display_url" : "exceptionalruby.com"
    } ]
  },
  "geo" : { },
  "id_str" : "129211339032887296",
  "text" : "LOL had no idea i was quoted on http:\/\/t.co\/9lzaOWat. oh @avdi.",
  "id" : 129211339032887296,
  "created_at" : "2011-10-26 15:02:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/3qFeUjH7",
      "expanded_url" : "http:\/\/i.imgur.com\/jXmVX.jpg",
      "display_url" : "i.imgur.com\/jXmVX.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "129041148802109440",
  "text" : "WINTER IS COMING http:\/\/t.co\/3qFeUjH7",
  "id" : 129041148802109440,
  "created_at" : "2011-10-26 03:46:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/q6Ct3uAi",
      "expanded_url" : "http:\/\/listofthingsforsale.com\/",
      "display_url" : "listofthingsforsale.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128991501266067456",
  "text" : "Just used http:\/\/t.co\/q6Ct3uAi for a party invitation. Didn't see that one coming, did you!?",
  "id" : 128991501266067456,
  "created_at" : "2011-10-26 00:29:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 7, 17 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/sTba2CdA",
      "expanded_url" : "https:\/\/img.skitch.com\/20111026-xbr375mjnqnyi28ty7rgypjnjd.png",
      "display_url" : "img.skitch.com\/20111026-xbr37\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128978806957539329",
  "text" : "Here's @gemcutter's RPM over the past 3 months. Notice a trend? http:\/\/t.co\/sTba2CdA",
  "id" : 128978806957539329,
  "created_at" : "2011-10-25 23:38:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128976862373355520",
  "text" : "Haha no after, he thinks I'm going to steal the birthday bone.",
  "id" : 128976862373355520,
  "created_at" : "2011-10-25 23:30:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/qljgFlDJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/RdMlB\/",
      "display_url" : "instagr.am\/p\/RdMlB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "128969436911779841",
  "text" : "Before.... http:\/\/t.co\/qljgFlDJ",
  "id" : 128969436911779841,
  "created_at" : "2011-10-25 23:01:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 12, 21 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128964027211722752",
  "geo" : { },
  "id_str" : "128965570996617218",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik yay @rubygems API !",
  "id" : 128965570996617218,
  "in_reply_to_status_id" : 128964027211722752,
  "created_at" : "2011-10-25 22:46:02 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128964206786650112",
  "geo" : { },
  "id_str" : "128965309146206210",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub I am so addicted to that stupid game. 23 floors so far",
  "id" : 128965309146206210,
  "in_reply_to_status_id" : 128964206786650112,
  "created_at" : "2011-10-25 22:45:00 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/I8HbaFb6",
      "expanded_url" : "http:\/\/instagr.am\/p\/RZzOK\/",
      "display_url" : "instagr.am\/p\/RZzOK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "128961002321608704",
  "text" : "From our walk this morning. I love fall.  http:\/\/t.co\/I8HbaFb6",
  "id" : 128961002321608704,
  "created_at" : "2011-10-25 22:27:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/I7BQfbnm",
      "expanded_url" : "http:\/\/i.qkme.me\/356wc9.jpg",
      "display_url" : "i.qkme.me\/356wc9.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "128943739795275776",
  "text" : "Insanity Ruby Developer Wolf: http:\/\/t.co\/I7BQfbnm",
  "id" : 128943739795275776,
  "created_at" : "2011-10-25 21:19:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/gwjFhT3v",
      "expanded_url" : "http:\/\/static.quickmeme.com\/media\/social\/qm.gif",
      "display_url" : "static.quickmeme.com\/media\/social\/q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128942945477992448",
  "text" : "http:\/\/t.co\/gwjFhT3v :(",
  "id" : 128942945477992448,
  "created_at" : "2011-10-25 21:16:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Redmond",
      "screen_name" : "coderoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "134567015",
      "id" : 134567015
    }, {
      "name" : "PJ Hagerty",
      "screen_name" : "aspleenic",
      "indices" : [ 11, 21 ],
      "id_str" : "31435721",
      "id" : 31435721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128919853439524864",
  "geo" : { },
  "id_str" : "128936591149383680",
  "in_reply_to_user_id" : 134567015,
  "text" : "@coderoshi @aspleenic you two need to play more NetHack.",
  "id" : 128936591149383680,
  "in_reply_to_status_id" : 128919853439524864,
  "created_at" : "2011-10-25 20:50:53 +0000",
  "in_reply_to_screen_name" : "coderoshi",
  "in_reply_to_user_id_str" : "134567015",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boom Haackalacka",
      "screen_name" : "haacked",
      "indices" : [ 0, 8 ],
      "id_str" : "768197",
      "id" : 768197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128927755046883328",
  "geo" : { },
  "id_str" : "128928231666630657",
  "in_reply_to_user_id" : 768197,
  "text" : "@haacked IMO, I would discourage posting of nightly builds to a service like that. use tags on your source repo instead.",
  "id" : 128928231666630657,
  "in_reply_to_status_id" : 128927755046883328,
  "created_at" : "2011-10-25 20:17:40 +0000",
  "in_reply_to_screen_name" : "haacked",
  "in_reply_to_user_id_str" : "768197",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/o3GoYMpo",
      "expanded_url" : "http:\/\/awesomegifs.com\/wp-content\/uploads\/deal-with-it1.gif",
      "display_url" : "awesomegifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128890995340361728",
  "text" : "Current status: http:\/\/t.co\/o3GoYMpo",
  "id" : 128890995340361728,
  "created_at" : "2011-10-25 17:49:42 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128731079979962369",
  "geo" : { },
  "id_str" : "128786590750351361",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida does \u00FCber have an API for that?",
  "id" : 128786590750351361,
  "in_reply_to_status_id" : 128731079979962369,
  "created_at" : "2011-10-25 10:54:50 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 0, 10 ],
      "id_str" : "23703410",
      "id" : 23703410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128714505348849664",
  "geo" : { },
  "id_str" : "128786500472143872",
  "in_reply_to_user_id" : 23703410,
  "text" : "@magnachef busy the first two Tuesdays of November but yes!!",
  "id" : 128786500472143872,
  "in_reply_to_status_id" : 128714505348849664,
  "created_at" : "2011-10-25 10:54:29 +0000",
  "in_reply_to_screen_name" : "magnachef",
  "in_reply_to_user_id_str" : "23703410",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128689264862044160",
  "geo" : { },
  "id_str" : "128691857315217409",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety your CO2 emissions are worse than some countries",
  "id" : 128691857315217409,
  "in_reply_to_status_id" : 128689264862044160,
  "created_at" : "2011-10-25 04:38:24 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128688155393142784",
  "geo" : { },
  "id_str" : "128688469496180736",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil :( also, Rails.env.production? Plzkthx",
  "id" : 128688469496180736,
  "in_reply_to_status_id" : 128688155393142784,
  "created_at" : "2011-10-25 04:24:56 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128683444891955200",
  "geo" : { },
  "id_str" : "128686957286006784",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps sweaty, tired moving people.",
  "id" : 128686957286006784,
  "in_reply_to_status_id" : 128683444891955200,
  "created_at" : "2011-10-25 04:18:56 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "perlbuzz",
      "screen_name" : "perlbuzz",
      "indices" : [ 0, 9 ],
      "id_str" : "14538270",
      "id" : 14538270
    }, {
      "name" : "Dan Magnuszewski",
      "screen_name" : "magnachef",
      "indices" : [ 10, 20 ],
      "id_str" : "23703410",
      "id" : 23703410
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 65, 75 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128678412024954880",
  "geo" : { },
  "id_str" : "128686331068035072",
  "in_reply_to_user_id" : 14538270,
  "text" : "@perlbuzz @magnachef this is a cool idea, would be neat to see a @gemcutter feedback site too",
  "id" : 128686331068035072,
  "in_reply_to_status_id" : 128678412024954880,
  "created_at" : "2011-10-25 04:16:26 +0000",
  "in_reply_to_screen_name" : "perlbuzz",
  "in_reply_to_user_id_str" : "14538270",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128685467779596288",
  "geo" : { },
  "id_str" : "128685810814951424",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire I'll mush across the frozen tundra with my sled dog, don't have to wait",
  "id" : 128685810814951424,
  "in_reply_to_status_id" : 128685467779596288,
  "created_at" : "2011-10-25 04:14:22 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 0, 9 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128682608468049920",
  "geo" : { },
  "id_str" : "128685567335600129",
  "in_reply_to_user_id" : 18230025,
  "text" : "@marcweil ruby ssl is so fucked, can you use geemus\/excon instead?",
  "id" : 128685567335600129,
  "in_reply_to_status_id" : 128682608468049920,
  "created_at" : "2011-10-25 04:13:24 +0000",
  "in_reply_to_screen_name" : "marcweil",
  "in_reply_to_user_id_str" : "18230025",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Whitmire",
      "screen_name" : "jwhitmire",
      "indices" : [ 0, 10 ],
      "id_str" : "23374570",
      "id" : 23374570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128683018868105216",
  "geo" : { },
  "id_str" : "128685092368424960",
  "in_reply_to_user_id" : 23374570,
  "text" : "@jwhitmire for reals homeslice",
  "id" : 128685092368424960,
  "in_reply_to_status_id" : 128683018868105216,
  "created_at" : "2011-10-25 04:11:31 +0000",
  "in_reply_to_screen_name" : "jwhitmire",
  "in_reply_to_user_id_str" : "23374570",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128673588235608064",
  "text" : "Any #codemash folks want to split a hotel room?",
  "id" : 128673588235608064,
  "created_at" : "2011-10-25 03:25:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 24 ],
      "url" : "http:\/\/t.co\/T7hvspkj",
      "expanded_url" : "https:\/\/twitter.com\/#!\/qrush\/status\/128645349790322689",
      "display_url" : "twitter.com\/#!\/qrush\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "128653655565008896",
  "geo" : { },
  "id_str" : "128661703675232258",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 http:\/\/t.co\/T7hvspkj",
  "id" : 128661703675232258,
  "in_reply_to_status_id" : 128653655565008896,
  "created_at" : "2011-10-25 02:38:35 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiroshi Nakamura",
      "screen_name" : "nahi",
      "indices" : [ 0, 5 ],
      "id_str" : "5626592",
      "id" : 5626592
    }, {
      "name" : "Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 6, 14 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128634301351858176",
  "geo" : { },
  "id_str" : "128650043816292353",
  "in_reply_to_user_id" : 5626592,
  "text" : "@nahi @evanphx is there some way to do more than +1 this?",
  "id" : 128650043816292353,
  "in_reply_to_status_id" : 128634301351858176,
  "created_at" : "2011-10-25 01:52:15 +0000",
  "in_reply_to_screen_name" : "nahi",
  "in_reply_to_user_id_str" : "5626592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiroshi Nakamura",
      "screen_name" : "nahi",
      "indices" : [ 3, 8 ],
      "id_str" : "5626592",
      "id" : 5626592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/TcxSHlHS",
      "expanded_url" : "http:\/\/redmine.ruby-lang.org\/issues\/5482",
      "display_url" : "redmine.ruby-lang.org\/issues\/5482"
    } ]
  },
  "geo" : { },
  "id_str" : "128649883220590592",
  "text" : "RT @nahi: \"Feature #5482: Rubinius as basis for Ruby 2.0 - Ruby Issue Tracking System\" http:\/\/t.co\/TcxSHlHS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/m.ctor.org\/f2p\/\" rel=\"nofollow\"\u003Em.ctor.org\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/TcxSHlHS",
        "expanded_url" : "http:\/\/redmine.ruby-lang.org\/issues\/5482",
        "display_url" : "redmine.ruby-lang.org\/issues\/5482"
      } ]
    },
    "geo" : { },
    "id_str" : "128634301351858176",
    "text" : "\"Feature #5482: Rubinius as basis for Ruby 2.0 - Ruby Issue Tracking System\" http:\/\/t.co\/TcxSHlHS",
    "id" : 128634301351858176,
    "created_at" : "2011-10-25 00:49:42 +0000",
    "user" : {
      "name" : "Hiroshi Nakamura",
      "screen_name" : "nahi",
      "protected" : false,
      "id_str" : "5626592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1377550475\/DSC_7014_middle_normal.jpg",
      "id" : 5626592,
      "verified" : false
    }
  },
  "id" : 128649883220590592,
  "created_at" : "2011-10-25 01:51:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/OMYlKOqo",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128645908832333824",
  "text" : "Absolutely humbled and flattered by the amount of attention http:\/\/t.co\/OMYlKOqo has gotten. Validated the idea, now to make it work!",
  "id" : 128645908832333824,
  "created_at" : "2011-10-25 01:35:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128645167472320512",
  "geo" : { },
  "id_str" : "128645577352282113",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen already married bro.",
  "id" : 128645577352282113,
  "in_reply_to_status_id" : 128645167472320512,
  "created_at" : "2011-10-25 01:34:30 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawn Wildermuth",
      "screen_name" : "ShawnWildermuth",
      "indices" : [ 0, 16 ],
      "id_str" : "1388411",
      "id" : 1388411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128642396962570240",
  "geo" : { },
  "id_str" : "128645535182753792",
  "in_reply_to_user_id" : 1388411,
  "text" : "@ShawnWildermuth haha yes, have a problem with that? :)",
  "id" : 128645535182753792,
  "in_reply_to_status_id" : 128642396962570240,
  "created_at" : "2011-10-25 01:34:20 +0000",
  "in_reply_to_screen_name" : "ShawnWildermuth",
  "in_reply_to_user_id_str" : "1388411",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sela Davis",
      "screen_name" : "sela_davis",
      "indices" : [ 0, 11 ],
      "id_str" : "7488582",
      "id" : 7488582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128642589875372032",
  "geo" : { },
  "id_str" : "128645349790322689",
  "in_reply_to_user_id" : 7488582,
  "text" : "@sela_davis moving closer to family, need a change in scenery\/pace.",
  "id" : 128645349790322689,
  "in_reply_to_status_id" : 128642589875372032,
  "created_at" : "2011-10-25 01:33:36 +0000",
  "in_reply_to_screen_name" : "sela_davis",
  "in_reply_to_user_id_str" : "7488582",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128642323197337601",
  "text" : "1 week until the move to Buffalo. BOXES Y U NO PACK YOURSELVES",
  "id" : 128642323197337601,
  "created_at" : "2011-10-25 01:21:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128592227323748352",
  "geo" : { },
  "id_str" : "128593822484664320",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape man up",
  "id" : 128593822484664320,
  "in_reply_to_status_id" : 128592227323748352,
  "created_at" : "2011-10-24 22:08:51 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    }, {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 12, 22 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128589579782590465",
  "geo" : { },
  "id_str" : "128590015197495296",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape @RedWolves `mate path\/to\/file.js` ?",
  "id" : 128590015197495296,
  "in_reply_to_status_id" : 128589579782590465,
  "created_at" : "2011-10-24 21:53:43 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 24 ],
      "url" : "http:\/\/t.co\/D9AOqSQX",
      "expanded_url" : "http:\/\/www.catonmat.net\/blog\/wp-content\/uploads\/2008\/12\/john-mccarthy-programming-completely-wrong.jpg",
      "display_url" : "catonmat.net\/blog\/wp-conten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128561036059086848",
  "text" : "RIP http:\/\/t.co\/D9AOqSQX",
  "id" : 128561036059086848,
  "created_at" : "2011-10-24 19:58:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128528243551776768",
  "text" : "Listing your photos on Instagram via web: HAHAHA WHY WOULD I EVER WANT TO DO THAT OH WAIT I DO AND ITS IMPOSSIBLE",
  "id" : 128528243551776768,
  "created_at" : "2011-10-24 17:48:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128493861680058368",
  "geo" : { },
  "id_str" : "128496586908106752",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella it could, yeah. figured i'd focus on Siri for now.",
  "id" : 128496586908106752,
  "in_reply_to_status_id" : 128493861680058368,
  "created_at" : "2011-10-24 15:42:28 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Clemesha",
      "screen_name" : "clemesha",
      "indices" : [ 3, 12 ],
      "id_str" : "15651722",
      "id" : 15651722
    }, {
      "name" : "Patrick McKenzie",
      "screen_name" : "patio11",
      "indices" : [ 104, 112 ],
      "id_str" : "20844341",
      "id" : 20844341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/iojrSNdS",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128490343757905920",
  "text" : "RT @clemesha: \"Hook anything up to Siri\": http:\/\/t.co\/iojrSNdS - response by prominent Hacker News user @patio11: \"Dang it, you just sol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick McKenzie",
        "screen_name" : "patio11",
        "indices" : [ 90, 98 ],
        "id_str" : "20844341",
        "id" : 20844341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/iojrSNdS",
        "expanded_url" : "http:\/\/ixoth.com",
        "display_url" : "ixoth.com"
      } ]
    },
    "geo" : { },
    "id_str" : "128348097062502400",
    "text" : "\"Hook anything up to Siri\": http:\/\/t.co\/iojrSNdS - response by prominent Hacker News user @patio11: \"Dang it, you just sold me an iPhone.\".",
    "id" : 128348097062502400,
    "created_at" : "2011-10-24 05:52:25 +0000",
    "user" : {
      "name" : "Alex Clemesha",
      "screen_name" : "clemesha",
      "protected" : false,
      "id_str" : "15651722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/147805899\/agcavatar_normal.jpg",
      "id" : 15651722,
      "verified" : false
    }
  },
  "id" : 128490343757905920,
  "created_at" : "2011-10-24 15:17:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald Ashri",
      "screen_name" : "ronald_istos",
      "indices" : [ 0, 13 ],
      "id_str" : "14257712",
      "id" : 14257712
    }, {
      "name" : "Benjamin Doherty",
      "screen_name" : "bangpound",
      "indices" : [ 14, 24 ],
      "id_str" : "615963",
      "id" : 615963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128483963139403776",
  "geo" : { },
  "id_str" : "128490240590622720",
  "in_reply_to_user_id" : 14257712,
  "text" : "@ronald_istos @bangpound that's the point, would love to have users sharing webhooks and actions. interested to hear what you have in mind!",
  "id" : 128490240590622720,
  "in_reply_to_status_id" : 128483963139403776,
  "created_at" : "2011-10-24 15:17:15 +0000",
  "in_reply_to_screen_name" : "ronald_istos",
  "in_reply_to_user_id_str" : "14257712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128468952488751104",
  "text" : "Dog wouldn't eat, forgot my keys, and left my wedding ring in the shower. HAPPY MONDAY EVERYONE!!!!!",
  "id" : 128468952488751104,
  "created_at" : "2011-10-24 13:52:39 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128409659169177600",
  "geo" : { },
  "id_str" : "128445038723219456",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect email you have to fill out a subject and body...SMS is just faster. I could be convinced otherwise.",
  "id" : 128445038723219456,
  "in_reply_to_status_id" : 128409659169177600,
  "created_at" : "2011-10-24 12:17:38 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128262038693748738",
  "geo" : { },
  "id_str" : "128264682975924224",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel the force is strong with this one",
  "id" : 128264682975924224,
  "in_reply_to_status_id" : 128262038693748738,
  "created_at" : "2011-10-24 00:20:58 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orenstein",
      "screen_name" : "r00k",
      "indices" : [ 0, 5 ],
      "id_str" : "11280212",
      "id" : 11280212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128252966770716672",
  "geo" : { },
  "id_str" : "128253787554062336",
  "in_reply_to_user_id" : 11280212,
  "text" : "@r00k It's short though. And unique!",
  "id" : 128253787554062336,
  "in_reply_to_status_id" : 128252966770716672,
  "created_at" : "2011-10-23 23:37:40 +0000",
  "in_reply_to_screen_name" : "r00k",
  "in_reply_to_user_id_str" : "11280212",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Fallon",
      "screen_name" : "jayfallon",
      "indices" : [ 0, 10 ],
      "id_str" : "814754",
      "id" : 814754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128252189327101954",
  "geo" : { },
  "id_str" : "128252602906456064",
  "in_reply_to_user_id" : 814754,
  "text" : "@jayfallon whoa. Let me know what you'd like to do with ixoth! Sounds powerful.",
  "id" : 128252602906456064,
  "in_reply_to_status_id" : 128252189327101954,
  "created_at" : "2011-10-23 23:32:58 +0000",
  "in_reply_to_screen_name" : "jayfallon",
  "in_reply_to_user_id_str" : "814754",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 0, 6 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/ZgDrZQsi",
      "expanded_url" : "https:\/\/img.skitch.com\/20111023-cxtq1yi13757xc8udkb36uadqn.png",
      "display_url" : "img.skitch.com\/20111023-cxtq1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "128228395237654529",
  "geo" : { },
  "id_str" : "128228634828877824",
  "in_reply_to_user_id" : 6815762,
  "text" : "@cmeik http:\/\/t.co\/ZgDrZQsi",
  "id" : 128228634828877824,
  "in_reply_to_status_id" : 128228395237654529,
  "created_at" : "2011-10-23 21:57:43 +0000",
  "in_reply_to_screen_name" : "cmeik",
  "in_reply_to_user_id_str" : "6815762",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Dalrymple",
      "screen_name" : "jdalrymple",
      "indices" : [ 0, 11 ],
      "id_str" : "12131132",
      "id" : 12131132
    }, {
      "name" : "Steve Streza",
      "screen_name" : "SteveStreza",
      "indices" : [ 12, 24 ],
      "id_str" : "658643",
      "id" : 658643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128227272699289603",
  "geo" : { },
  "id_str" : "128228213473296384",
  "in_reply_to_user_id" : 12131132,
  "text" : "@jdalrymple @SteveStreza what are you thinking of doing with it?",
  "id" : 128228213473296384,
  "in_reply_to_status_id" : 128227272699289603,
  "created_at" : "2011-10-23 21:56:03 +0000",
  "in_reply_to_screen_name" : "jdalrymple",
  "in_reply_to_user_id_str" : "12131132",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/TyqgBFNV",
      "expanded_url" : "http:\/\/gaug.es",
      "display_url" : "gaug.es"
    } ]
  },
  "geo" : { },
  "id_str" : "128227314889785344",
  "text" : "Watching http:\/\/t.co\/TyqgBFNV on AirTraffic live for this little launch is really awesome. It's a big world!",
  "id" : 128227314889785344,
  "created_at" : "2011-10-23 21:52:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazaroth",
      "screen_name" : "Nazaroth",
      "indices" : [ 0, 9 ],
      "id_str" : "18643241",
      "id" : 18643241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128226497621270528",
  "geo" : { },
  "id_str" : "128227058043195392",
  "in_reply_to_user_id" : 18643241,
  "text" : "@Nazaroth my email is nick [at] quaran.to, hit me up",
  "id" : 128227058043195392,
  "in_reply_to_status_id" : 128226497621270528,
  "created_at" : "2011-10-23 21:51:27 +0000",
  "in_reply_to_screen_name" : "Nazaroth",
  "in_reply_to_user_id_str" : "18643241",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE real KR",
      "screen_name" : "realkevinroth",
      "indices" : [ 0, 14 ],
      "id_str" : "44984826",
      "id" : 44984826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128226506311868416",
  "geo" : { },
  "id_str" : "128226950689992704",
  "in_reply_to_user_id" : 44984826,
  "text" : "@realkevinroth thanks! interesting...not sure what that would be used for. it's not like UrbanAirship, etc.",
  "id" : 128226950689992704,
  "in_reply_to_status_id" : 128226506311868416,
  "created_at" : "2011-10-23 21:51:02 +0000",
  "in_reply_to_screen_name" : "realkevinroth",
  "in_reply_to_user_id_str" : "44984826",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u043C\u044B Gray",
      "screen_name" : "melgray",
      "indices" : [ 0, 8 ],
      "id_str" : "8344942",
      "id" : 8344942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128220862942937088",
  "geo" : { },
  "id_str" : "128224636633743360",
  "in_reply_to_user_id" : 8344942,
  "text" : "@melgray thanks! need to flesh it out more, but definitely want to make sure there's interest in it.",
  "id" : 128224636633743360,
  "in_reply_to_status_id" : 128220862942937088,
  "created_at" : "2011-10-23 21:41:50 +0000",
  "in_reply_to_screen_name" : "melgray",
  "in_reply_to_user_id_str" : "8344942",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oren Jacob",
      "screen_name" : "orenjacob",
      "indices" : [ 0, 10 ],
      "id_str" : "21844920",
      "id" : 21844920
    }, {
      "name" : "Faheem",
      "screen_name" : "ims43",
      "indices" : [ 11, 17 ],
      "id_str" : "266682322",
      "id" : 266682322
    }, {
      "name" : "Sachin Patel",
      "screen_name" : "gizmosachin",
      "indices" : [ 18, 30 ],
      "id_str" : "16570300",
      "id" : 16570300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/OMYlKOqo",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "in_reply_to_status_id_str" : "128154847366221824",
  "geo" : { },
  "id_str" : "128224514327851009",
  "in_reply_to_user_id" : 21844920,
  "text" : "@orenjacob @ims43 @gizmosachin http:\/\/t.co\/OMYlKOqo",
  "id" : 128224514327851009,
  "in_reply_to_status_id" : 128154847366221824,
  "created_at" : "2011-10-23 21:41:21 +0000",
  "in_reply_to_screen_name" : "orenjacob",
  "in_reply_to_user_id_str" : "21844920",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/Fl16zIMQ",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3147309",
      "display_url" : "news.ycombinator.com\/item?id=3147309"
    } ]
  },
  "geo" : { },
  "id_str" : "128223560740257792",
  "text" : "Also, would appreciate your upboats\/feedback on HN! http:\/\/t.co\/Fl16zIMQ",
  "id" : 128223560740257792,
  "created_at" : "2011-10-23 21:37:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/OMYlKOqo",
      "expanded_url" : "http:\/\/ixoth.com",
      "display_url" : "ixoth.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128220582666960896",
  "text" : "Introducing http:\/\/t.co\/OMYlKOqo, Siri's little helper. Webhooks to do anything you want. Would love to get some beta testers !",
  "id" : 128220582666960896,
  "created_at" : "2011-10-23 21:25:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Croak",
      "screen_name" : "Croaky",
      "indices" : [ 43, 50 ],
      "id_str" : "787595",
      "id" : 787595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/5Ryz8BvN",
      "expanded_url" : "http:\/\/instagr.am\/p\/RNQfk\/",
      "display_url" : "instagr.am\/p\/RNQfk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "128194499091496960",
  "text" : "Completely wiped out after a big walk with @croaky and jasper! http:\/\/t.co\/5Ryz8BvN",
  "id" : 128194499091496960,
  "created_at" : "2011-10-23 19:42:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127989356815327232",
  "text" : "Basically, going to expose webhooks for Siri. Already working in a small test. SMS isn't free though, and neither will this service be.",
  "id" : 127989356815327232,
  "created_at" : "2011-10-23 06:06:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127989063486676992",
  "text" : "First Siri &lt;=&gt; Twilio integration worked out, now to make it awesome. DM me if you want in on beta testing this.",
  "id" : 127989063486676992,
  "created_at" : "2011-10-23 06:05:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127943461163905024",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub GG, want to take a break for a bit :)",
  "id" : 127943461163905024,
  "created_at" : "2011-10-23 03:04:32 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127930827957993473",
  "geo" : { },
  "id_str" : "127932461761052672",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt salad",
  "id" : 127932461761052672,
  "in_reply_to_status_id" : 127930827957993473,
  "created_at" : "2011-10-23 02:20:50 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127930385882550273",
  "text" : "@RunningWRails ah, had no idea! perhaps there is hope.",
  "id" : 127930385882550273,
  "created_at" : "2011-10-23 02:12:35 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekkub",
      "screen_name" : "tekkub",
      "indices" : [ 0, 7 ],
      "id_str" : "15827231",
      "id" : 15827231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127914394783985664",
  "geo" : { },
  "id_str" : "127914460521312256",
  "in_reply_to_user_id" : 15827231,
  "text" : "@tekkub i will! qrush40 is my game center handle.",
  "id" : 127914460521312256,
  "in_reply_to_status_id" : 127914394783985664,
  "created_at" : "2011-10-23 01:09:18 +0000",
  "in_reply_to_screen_name" : "tekkub",
  "in_reply_to_user_id_str" : "15827231",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127914230149165056",
  "text" : "iOS games are in a whole different category than Android's. Carcassone is a gorgeous experience and I doubt any Droid games get this polish.",
  "id" : 127914230149165056,
  "created_at" : "2011-10-23 01:08:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/7bx6Mm7X",
      "expanded_url" : "http:\/\/instagr.am\/p\/RCJYA\/",
      "display_url" : "instagr.am\/p\/RCJYA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "127777286043877376",
  "text" : "def husky; sleep 1; end http:\/\/t.co\/7bx6Mm7X",
  "id" : 127777286043877376,
  "created_at" : "2011-10-22 16:04:13 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Shaughnessy",
      "screen_name" : "pat_shaughnessy",
      "indices" : [ 0, 16 ],
      "id_str" : "43234200",
      "id" : 43234200
    }, {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 17, 24 ],
      "id_str" : "33493",
      "id" : 33493
    }, {
      "name" : "Jason Seifer",
      "screen_name" : "jseifer",
      "indices" : [ 25, 33 ],
      "id_str" : "1714531",
      "id" : 1714531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127757436999307264",
  "geo" : { },
  "id_str" : "127760817075654658",
  "in_reply_to_user_id" : 43234200,
  "text" : "@pat_shaughnessy @peterc @jseifer cool, please don't be afraid to gem install bundler --pre, we need to hammer that new API :)",
  "id" : 127760817075654658,
  "in_reply_to_status_id" : 127757436999307264,
  "created_at" : "2011-10-22 14:58:47 +0000",
  "in_reply_to_screen_name" : "pat_shaughnessy",
  "in_reply_to_user_id_str" : "43234200",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/nT5A87RJ",
      "expanded_url" : "http:\/\/oos.moxiecode.com\/js_webgl\/xwing\/index.html",
      "display_url" : "oos.moxiecode.com\/js_webgl\/xwing\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127758855215136768",
  "text" : "Nostaglia + WebGL collide! http:\/\/t.co\/nT5A87RJ",
  "id" : 127758855215136768,
  "created_at" : "2011-10-22 14:50:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127585012181774336",
  "text" : "Haha seems like no one knows what to do with Siri.",
  "id" : 127585012181774336,
  "created_at" : "2011-10-22 03:20:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127565907596808192",
  "text" : "So iPhone 4S owners, if you could make Siri do anything for you (as in online, etc) what would it be?",
  "id" : 127565907596808192,
  "created_at" : "2011-10-22 02:04:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Matthieu",
      "screen_name" : "chrismatthieu",
      "indices" : [ 0, 14 ],
      "id_str" : "13604142",
      "id" : 13604142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127556909497720832",
  "geo" : { },
  "id_str" : "127565800763691008",
  "in_reply_to_user_id" : 13604142,
  "text" : "@chrismatthieu hah! I saw the google ad for it, I'll give it a shot.",
  "id" : 127565800763691008,
  "in_reply_to_status_id" : 127556909497720832,
  "created_at" : "2011-10-22 02:03:51 +0000",
  "in_reply_to_screen_name" : "chrismatthieu",
  "in_reply_to_user_id_str" : "13604142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 4, 11 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127551772091883521",
  "text" : "The @twilio SMS API seems like it can get really expensive...really quickly",
  "id" : 127551772091883521,
  "created_at" : "2011-10-22 01:08:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127529925002530816",
  "geo" : { },
  "id_str" : "127530244344262656",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella new rails users do, that's what `rails new` is meant for. existing folks should use a template, IMO",
  "id" : 127530244344262656,
  "in_reply_to_status_id" : 127529925002530816,
  "created_at" : "2011-10-21 23:42:34 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127529909424893953",
  "text" : "\"Microsoft\u2019s Augmented Reality 3D HoloDesk Lets You Play With Balls\" ...haha hahah HAHAHAHAHHAAHAAAA",
  "id" : 127529909424893953,
  "created_at" : "2011-10-21 23:41:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/gPiGYf7t",
      "expanded_url" : "http:\/\/alt.org\/nethack\/player-stats.php?player=DoctorNick",
      "display_url" : "alt.org\/nethack\/player\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "127528575380357121",
  "geo" : { },
  "id_str" : "127529000758296576",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant that too! playing on NAO means you get stats for free though: http:\/\/t.co\/gPiGYf7t",
  "id" : 127529000758296576,
  "in_reply_to_status_id" : 127528575380357121,
  "created_at" : "2011-10-21 23:37:37 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sergeant",
      "screen_name" : "nicksergeant",
      "indices" : [ 0, 13 ],
      "id_str" : "13459652",
      "id" : 13459652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127524499292815360",
  "geo" : { },
  "id_str" : "127528520816668672",
  "in_reply_to_user_id" : 13459652,
  "text" : "@nicksergeant you should just use telnet instead. :)",
  "id" : 127528520816668672,
  "in_reply_to_status_id" : 127524499292815360,
  "created_at" : "2011-10-21 23:35:43 +0000",
  "in_reply_to_screen_name" : "nicksergeant",
  "in_reply_to_user_id_str" : "13459652",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/dNeQYUBD",
      "expanded_url" : "http:\/\/nethack.alt.org",
      "display_url" : "nethack.alt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "127526097335234561",
  "text" : "4 years, 7 ascensions, many deaths, and Nethack is still fun and surprising. telnet http:\/\/t.co\/dNeQYUBD and die yet another stupid death :)",
  "id" : 127526097335234561,
  "created_at" : "2011-10-21 23:26:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@jordansissel",
      "screen_name" : "jordansissel",
      "indices" : [ 53, 66 ],
      "id_str" : "15782607",
      "id" : 15782607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/MtlC4QX1",
      "expanded_url" : "http:\/\/thegreatestgameyouwilleverplay.com\/",
      "display_url" : "thegreatestgameyouwilleverplay.com"
    } ]
  },
  "geo" : { },
  "id_str" : "127524136712024064",
  "text" : "Why you must play Nethack: http:\/\/t.co\/MtlC4QX1 (via @jordansissel)",
  "id" : 127524136712024064,
  "created_at" : "2011-10-21 23:18:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127477891557629953",
  "geo" : { },
  "id_str" : "127495766179725313",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer it's a soft undo right now. going to change that policy soon, trying to take a support burden off",
  "id" : 127495766179725313,
  "in_reply_to_status_id" : 127477891557629953,
  "created_at" : "2011-10-21 21:25:34 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "indices" : [ 3, 14 ],
      "id_str" : "14114392",
      "id" : 14114392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/X3SLGCXr",
      "expanded_url" : "http:\/\/bit.ly\/nUtaLv",
      "display_url" : "bit.ly\/nUtaLv"
    } ]
  },
  "geo" : { },
  "id_str" : "127493893657870336",
  "text" : "RT @thoughtbot: Danger, danger! Use Rails 3.1, high_voltage, and Markdown to make a static site: http:\/\/t.co\/X3SLGCXr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/X3SLGCXr",
        "expanded_url" : "http:\/\/bit.ly\/nUtaLv",
        "display_url" : "bit.ly\/nUtaLv"
      } ]
    },
    "geo" : { },
    "id_str" : "127493814813343744",
    "text" : "Danger, danger! Use Rails 3.1, high_voltage, and Markdown to make a static site: http:\/\/t.co\/X3SLGCXr",
    "id" : 127493814813343744,
    "created_at" : "2011-10-21 21:17:48 +0000",
    "user" : {
      "name" : "thoughtbot",
      "screen_name" : "thoughtbot",
      "protected" : false,
      "id_str" : "14114392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529315997275025408\/ypnB6GAu_normal.png",
      "id" : 14114392,
      "verified" : true
    }
  },
  "id" : 127493893657870336,
  "created_at" : "2011-10-21 21:18:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/NJdvuzBF",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "127472188268883969",
  "geo" : { },
  "id_str" : "127472670555123712",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer we get 2-3+ requests a week to delete gems on http:\/\/t.co\/NJdvuzBF that were pushed by mistake.",
  "id" : 127472670555123712,
  "in_reply_to_status_id" : 127472188268883969,
  "created_at" : "2011-10-21 19:53:47 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 0, 8 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 9, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127469608813871104",
  "geo" : { },
  "id_str" : "127469695921168385",
  "in_reply_to_user_id" : 14060922,
  "text" : "@mperham #firstworldproblems",
  "id" : 127469695921168385,
  "in_reply_to_status_id" : 127469608813871104,
  "created_at" : "2011-10-21 19:41:58 +0000",
  "in_reply_to_screen_name" : "mperham",
  "in_reply_to_user_id_str" : "14060922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127467802985644032",
  "geo" : { },
  "id_str" : "127468346944925696",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath haha one button to 'git add -A && git commit -am \"PUSH ALL THE THINGS\" && git push'",
  "id" : 127468346944925696,
  "in_reply_to_status_id" : 127467802985644032,
  "created_at" : "2011-10-21 19:36:36 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/ZVjl6ff6",
      "expanded_url" : "http:\/\/siri.com",
      "display_url" : "siri.com"
    } ]
  },
  "geo" : { },
  "id_str" : "127467539407179776",
  "text" : "Haha, http:\/\/t.co\/ZVjl6ff6 redirects to, well, what did you expect",
  "id" : 127467539407179776,
  "created_at" : "2011-10-21 19:33:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127466787985043456",
  "text" : "All of those emails were deleted, but still.",
  "id" : 127466787985043456,
  "created_at" : "2011-10-21 19:30:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127466733148704769",
  "text" : "3 recruiter emails today so far and one random phone call. I sometimes wonder why more people aren't in this industry.",
  "id" : 127466733148704769,
  "created_at" : "2011-10-21 19:30:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    }, {
      "name" : "Jeremy Hinegardner",
      "screen_name" : "copiousfreetime",
      "indices" : [ 7, 23 ],
      "id_str" : "14601522",
      "id" : 14601522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127457067689709568",
  "geo" : { },
  "id_str" : "127466359583014912",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi @copiousfreetime definitely will include link to opt out in STDOUT, and the email.",
  "id" : 127466359583014912,
  "in_reply_to_status_id" : 127457067689709568,
  "created_at" : "2011-10-21 19:28:42 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Ingram",
      "screen_name" : "pjammer",
      "indices" : [ 0, 8 ],
      "id_str" : "15266123",
      "id" : 15266123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127464420019417088",
  "geo" : { },
  "id_str" : "127466245191761920",
  "in_reply_to_user_id" : 15266123,
  "text" : "@pjammer just the ones you *just* pushed",
  "id" : 127466245191761920,
  "in_reply_to_status_id" : 127464420019417088,
  "created_at" : "2011-10-21 19:28:15 +0000",
  "in_reply_to_screen_name" : "pjammer",
  "in_reply_to_user_id_str" : "15266123",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 8, 21 ],
      "id_str" : "780561",
      "id" : 780561
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 52, 60 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127437711337463808",
  "geo" : { },
  "id_str" : "127438110534545409",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @technoweenie agreed, discussing plans with @drbrain on this.",
  "id" : 127438110534545409,
  "in_reply_to_status_id" : 127437711337463808,
  "created_at" : "2011-10-21 17:36:27 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/VkGQHftz",
      "expanded_url" : "http:\/\/guides.rubygems.org",
      "display_url" : "guides.rubygems.org"
    } ]
  },
  "in_reply_to_status_id_str" : "127437647978307587",
  "geo" : { },
  "id_str" : "127437785442418688",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates agreed. going to be changing the policy on it and i'm going to make a guide on http:\/\/t.co\/VkGQHftz just for it.",
  "id" : 127437785442418688,
  "in_reply_to_status_id" : 127437647978307587,
  "created_at" : "2011-10-21 17:35:10 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    }, {
      "name" : "Charles Lowell",
      "screen_name" : "cowboyd",
      "indices" : [ 8, 16 ],
      "id_str" : "791224",
      "id" : 791224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127437213578440704",
  "geo" : { },
  "id_str" : "127437659772694528",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates @cowboyd definitely will be opt-out as well.",
  "id" : 127437659772694528,
  "in_reply_to_status_id" : 127437213578440704,
  "created_at" : "2011-10-21 17:34:40 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bates",
      "screen_name" : "rbates",
      "indices" : [ 0, 7 ],
      "id_str" : "14246143",
      "id" : 14246143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127437213578440704",
  "geo" : { },
  "id_str" : "127437556009811968",
  "in_reply_to_user_id" : 14246143,
  "text" : "@rbates yes, thats the plan too, but many use tools that automatically push gems and ignore output (and the fact they just pushed it)",
  "id" : 127437556009811968,
  "in_reply_to_status_id" : 127437213578440704,
  "created_at" : "2011-10-21 17:34:15 +0000",
  "in_reply_to_screen_name" : "rbates",
  "in_reply_to_user_id_str" : "14246143",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Czarnecki",
      "screen_name" : "CzarneckiD",
      "indices" : [ 0, 11 ],
      "id_str" : "13393",
      "id" : 13393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Poht2byB",
      "expanded_url" : "http:\/\/guides.rubygems.org\/rubygems-org-api\/#webhook",
      "display_url" : "guides.rubygems.org\/rubygems-org-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "127437092199473152",
  "geo" : { },
  "id_str" : "127437304766803968",
  "in_reply_to_user_id" : 13393,
  "text" : "@CzarneckiD we have webhooks already. http:\/\/t.co\/Poht2byB",
  "id" : 127437304766803968,
  "in_reply_to_status_id" : 127437092199473152,
  "created_at" : "2011-10-21 17:33:15 +0000",
  "in_reply_to_screen_name" : "CzarneckiD",
  "in_reply_to_user_id_str" : "13393",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "risk _danger_ olson",
      "screen_name" : "technoweenie",
      "indices" : [ 0, 13 ],
      "id_str" : "780561",
      "id" : 780561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127436729270542338",
  "geo" : { },
  "id_str" : "127436970543677441",
  "in_reply_to_user_id" : 780561,
  "text" : "@technoweenie yeah.. I'd like to stop the endless stream of delete requests we get...so this is part of the attack",
  "id" : 127436970543677441,
  "in_reply_to_status_id" : 127436729270542338,
  "created_at" : "2011-10-21 17:31:56 +0000",
  "in_reply_to_screen_name" : "technoweenie",
  "in_reply_to_user_id_str" : "780561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 32, 42 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127436311706615808",
  "text" : "Hey Rubyists: Would you rage if @gemcutter emailed you when you pushed a gem? Say it's ready, link to docs, and how to yank it",
  "id" : 127436311706615808,
  "created_at" : "2011-10-21 17:29:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Redpath",
      "screen_name" : "lukeredpath",
      "indices" : [ 0, 12 ],
      "id_str" : "72573",
      "id" : 72573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127429584613408768",
  "geo" : { },
  "id_str" : "127430167055437825",
  "in_reply_to_user_id" : 72573,
  "text" : "@lukeredpath true, I guess I don't use gcal enough for it to matter",
  "id" : 127430167055437825,
  "in_reply_to_status_id" : 127429584613408768,
  "created_at" : "2011-10-21 17:04:54 +0000",
  "in_reply_to_screen_name" : "lukeredpath",
  "in_reply_to_user_id_str" : "72573",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127429358410412032",
  "text" : "Hooked up siri_says, definitely want to build a web service around this idea.",
  "id" : 127429358410412032,
  "created_at" : "2011-10-21 17:01:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "You",
      "screen_name" : "timocratic",
      "indices" : [ 52, 63 ],
      "id_str" : "14086000",
      "id" : 14086000
    }, {
      "name" : "Aaron Kalin",
      "screen_name" : "martinisoft",
      "indices" : [ 64, 76 ],
      "id_str" : "771669",
      "id" : 771669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/aB6OYZ25",
      "expanded_url" : "https:\/\/github.com\/tysontate\/siri_says\/",
      "display_url" : "github.com\/tysontate\/siri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127406984558411776",
  "text" : "Holy shit, VOICE DEPLOYS. http:\/\/t.co\/aB6OYZ25 (via @timocratic @martinisoft)",
  "id" : 127406984558411776,
  "created_at" : "2011-10-21 15:32:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sanguinetti",
      "screen_name" : "godfoca",
      "indices" : [ 0, 8 ],
      "id_str" : "9337082",
      "id" : 9337082
    }, {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 9, 14 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127401398156525568",
  "geo" : { },
  "id_str" : "127403552913100801",
  "in_reply_to_user_id" : 9337082,
  "text" : "@godfoca @obie yeah...i want to clean it up, test it with rspec\/cuke, etc. that might be too much \"magic ruby\" though, might fork it",
  "id" : 127403552913100801,
  "in_reply_to_status_id" : 127401398156525568,
  "created_at" : "2011-10-21 15:19:08 +0000",
  "in_reply_to_screen_name" : "godfoca",
  "in_reply_to_user_id_str" : "9337082",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obie",
      "screen_name" : "obie",
      "indices" : [ 0, 5 ],
      "id_str" : "45603",
      "id" : 45603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127396740612636672",
  "geo" : { },
  "id_str" : "127398562324692992",
  "in_reply_to_user_id" : 45603,
  "text" : "@obie really? the state of the code is terrible...have you read any of it?",
  "id" : 127398562324692992,
  "in_reply_to_status_id" : 127396740612636672,
  "created_at" : "2011-10-21 14:59:18 +0000",
  "in_reply_to_screen_name" : "obie",
  "in_reply_to_user_id_str" : "45603",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127384010740600832",
  "geo" : { },
  "id_str" : "127395956441362432",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape it's full size for sure, just about 1 year old too. but yeah, would definitely scale fences like that.",
  "id" : 127395956441362432,
  "in_reply_to_status_id" : 127384010740600832,
  "created_at" : "2011-10-21 14:48:57 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "shellscape",
      "indices" : [ 0, 11 ],
      "id_str" : "16134710",
      "id" : 16134710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127395364608294912",
  "geo" : { },
  "id_str" : "127395831199449088",
  "in_reply_to_user_id" : 16134710,
  "text" : "@shellscape definitely a Shiba Inu. (totally not a dog geek now)",
  "id" : 127395831199449088,
  "in_reply_to_status_id" : 127395364608294912,
  "created_at" : "2011-10-21 14:48:27 +0000",
  "in_reply_to_screen_name" : "shellscape",
  "in_reply_to_user_id_str" : "16134710",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/fuamHyTB",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=U7v2lz3OME4",
      "display_url" : "youtube.com\/watch?v=U7v2lz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127394719788564480",
  "text" : "Current status: http:\/\/t.co\/fuamHyTB",
  "id" : 127394719788564480,
  "created_at" : "2011-10-21 14:44:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reddit",
      "screen_name" : "reddit",
      "indices" : [ 51, 58 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Ivv0JajR",
      "expanded_url" : "http:\/\/28.media.tumblr.com\/tumblr_ls6uqfpyLl1qdxqlzo1_500.jpg",
      "display_url" : "28.media.tumblr.com\/tumblr_ls6uqfp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127383792632602624",
  "text" : "Crazy huskies are crazy: http:\/\/t.co\/Ivv0JajR (via @reddit)",
  "id" : 127383792632602624,
  "created_at" : "2011-10-21 14:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/9oip0l48",
      "expanded_url" : "http:\/\/instagr.am\/p\/Q2zOn\/",
      "display_url" : "instagr.am\/p\/Q2zOn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "127217517281288192",
  "text" : "Just one more rep! http:\/\/t.co\/9oip0l48",
  "id" : 127217517281288192,
  "created_at" : "2011-10-21 02:59:54 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Hickey",
      "screen_name" : "stevehickeydsgn",
      "indices" : [ 0, 16 ],
      "id_str" : "20779370",
      "id" : 20779370
    }, {
      "name" : "-march gabe",
      "screen_name" : "gabebw",
      "indices" : [ 17, 24 ],
      "id_str" : "224887329",
      "id" : 224887329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/g25LSlLL",
      "expanded_url" : "http:\/\/static.rubycentral.org\/IE%20I%20AM%20DISAPPOINT.png",
      "display_url" : "static.rubycentral.org\/IE%20I%20AM%20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "127207411525234688",
  "geo" : { },
  "id_str" : "127212219497840640",
  "in_reply_to_user_id" : 20779370,
  "text" : "@stevehickeydsgn @gabebw http:\/\/t.co\/g25LSlLL",
  "id" : 127212219497840640,
  "in_reply_to_status_id" : 127207411525234688,
  "created_at" : "2011-10-21 02:38:51 +0000",
  "in_reply_to_screen_name" : "stevehickeydsgn",
  "in_reply_to_user_id_str" : "20779370",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127196145960226816",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez in any case, we should talk sometime on IRC :D",
  "id" : 127196145960226816,
  "created_at" : "2011-10-21 01:34:59 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127196104122040320",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez i'd love to dump in cucumber, rspec, etc...but not sure about your philosophy with this. I could just fork and do my own thing :)",
  "id" : 127196104122040320,
  "created_at" : "2011-10-21 01:34:49 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qrush\/status\/127186879916408832\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/fX71XwOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcPbyx3CAAA2QYi.jpg",
      "id_str" : "127186879920603136",
      "id" : 127186879920603136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcPbyx3CAAA2QYi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/fX71XwOK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127185053439639553",
  "geo" : { },
  "id_str" : "127186879916408832",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves been riding the wagon for a few years now, proof attached http:\/\/t.co\/fX71XwOK",
  "id" : 127186879916408832,
  "in_reply_to_status_id" : 127185053439639553,
  "created_at" : "2011-10-21 00:58:10 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 100, 108 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/o1KQYjVf",
      "expanded_url" : "https:\/\/github.com\/antirez\/lamernews",
      "display_url" : "github.com\/antirez\/lamern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127184964952395776",
  "text" : "Feeling a serious hankering to reformat\/C un-styleize http:\/\/t.co\/o1KQYjVf (along with test it!) ...@antirez any objections?",
  "id" : 127184964952395776,
  "created_at" : "2011-10-21 00:50:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Pytel",
      "screen_name" : "cpytel",
      "indices" : [ 0, 7 ],
      "id_str" : "9488922",
      "id" : 9488922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127180455039602690",
  "geo" : { },
  "id_str" : "127180590163304450",
  "in_reply_to_user_id" : 9488922,
  "text" : "@cpytel i think your account is hacked",
  "id" : 127180590163304450,
  "in_reply_to_status_id" : 127180455039602690,
  "created_at" : "2011-10-21 00:33:10 +0000",
  "in_reply_to_screen_name" : "cpytel",
  "in_reply_to_user_id_str" : "9488922",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 21, 30 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127180401390268416",
  "text" : "Off of FaceTime with @bquarant and BOOM, Sabres 1-0! Getting back in the Buffalo state of mind!",
  "id" : 127180401390268416,
  "created_at" : "2011-10-21 00:32:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/lPB4VMYy",
      "expanded_url" : "http:\/\/www.youtubehoneybadger.com\/wp-content\/uploads\/2011\/07\/HoneyBadger1.jpg",
      "display_url" : "youtubehoneybadger.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "127172516182630401",
  "geo" : { },
  "id_str" : "127175247173648384",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik your jerseys better say http:\/\/t.co\/lPB4VMYy",
  "id" : 127175247173648384,
  "in_reply_to_status_id" : 127172516182630401,
  "created_at" : "2011-10-21 00:11:56 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/sLQQMSY7",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=8LsxmQV8AXk",
      "display_url" : "youtube.com\/watch?v=8LsxmQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127163083247460352",
  "text" : "\"Supercoders needed to take down cybercriminals.\" job posting reminds me of http:\/\/t.co\/sLQQMSY7",
  "id" : 127163083247460352,
  "created_at" : "2011-10-20 23:23:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3093\u3089\u304B\u306E\u6587\u8108",
      "screen_name" : "_KenGo",
      "indices" : [ 0, 7 ],
      "id_str" : "59445773",
      "id" : 59445773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/66MYqIJV",
      "expanded_url" : "http:\/\/rubygems.org\/pages\/download",
      "display_url" : "rubygems.org\/pages\/download"
    } ]
  },
  "in_reply_to_status_id_str" : "127045359481532417",
  "geo" : { },
  "id_str" : "127079074748313600",
  "in_reply_to_user_id" : 59445773,
  "text" : "@_KenGo gem update --system or update from http:\/\/t.co\/66MYqIJV",
  "id" : 127079074748313600,
  "in_reply_to_status_id" : 127045359481532417,
  "created_at" : "2011-10-20 17:49:47 +0000",
  "in_reply_to_screen_name" : "_KenGo",
  "in_reply_to_user_id_str" : "59445773",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127071155717804033",
  "text" : "@IselaMariaPhoto THUNDERCATS ARE GOO!!!!!!",
  "id" : 127071155717804033,
  "created_at" : "2011-10-20 17:18:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/FgpRpWTG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=rvDqoxMUroA",
      "display_url" : "youtube.com\/watch?v=rvDqox\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127060551913320449",
  "text" : "SPACE!!!! http:\/\/t.co\/FgpRpWTG",
  "id" : 127060551913320449,
  "created_at" : "2011-10-20 16:36:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127005897623994368",
  "geo" : { },
  "id_str" : "127012277101670401",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage ...why?",
  "id" : 127012277101670401,
  "in_reply_to_status_id" : 127005897623994368,
  "created_at" : "2011-10-20 13:24:21 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Firebaugh",
      "screen_name" : "jfire",
      "indices" : [ 0, 6 ],
      "id_str" : "16693852",
      "id" : 16693852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126863163860844544",
  "geo" : { },
  "id_str" : "126880001097347072",
  "in_reply_to_user_id" : 16693852,
  "text" : "@jfire not sure why it's borked yet...probably a twitter API thing. Will check again tomorrow",
  "id" : 126880001097347072,
  "in_reply_to_status_id" : 126863163860844544,
  "created_at" : "2011-10-20 04:38:44 +0000",
  "in_reply_to_screen_name" : "jfire",
  "in_reply_to_user_id_str" : "16693852",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Beary",
      "screen_name" : "geemus",
      "indices" : [ 0, 7 ],
      "id_str" : "14237099",
      "id" : 14237099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126873608537653248",
  "geo" : { },
  "id_str" : "126879323641753600",
  "in_reply_to_user_id" : 14237099,
  "text" : "@geemus ooooh is it 4 layer only? Would like to know more !",
  "id" : 126879323641753600,
  "in_reply_to_status_id" : 126873608537653248,
  "created_at" : "2011-10-20 04:36:02 +0000",
  "in_reply_to_screen_name" : "geemus",
  "in_reply_to_user_id_str" : "14237099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Whitbeck",
      "screen_name" : "RedWolves",
      "indices" : [ 0, 10 ],
      "id_str" : "651373",
      "id" : 651373
    }, {
      "name" : "appendTo",
      "screen_name" : "appendTo",
      "indices" : [ 21, 30 ],
      "id_str" : "19742171",
      "id" : 19742171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126866404229124096",
  "geo" : { },
  "id_str" : "126878400454463488",
  "in_reply_to_user_id" : 651373,
  "text" : "@RedWolves congrats! @appendto is building a kickass distributed team!",
  "id" : 126878400454463488,
  "in_reply_to_status_id" : 126866404229124096,
  "created_at" : "2011-10-20 04:32:22 +0000",
  "in_reply_to_screen_name" : "RedWolves",
  "in_reply_to_user_id_str" : "651373",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "codemash",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126844095787311104",
  "text" : "Looks 2012 will be my first #codemash year!",
  "id" : 126844095787311104,
  "created_at" : "2011-10-20 02:16:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126841077817815040",
  "text" : "South Park time!",
  "id" : 126841077817815040,
  "created_at" : "2011-10-20 02:04:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126752860963737600",
  "geo" : { },
  "id_str" : "126753264103469056",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant this is a daily amazement to me as well, when there's stuff of mine 5+ years older still running\/working, even more so",
  "id" : 126753264103469056,
  "in_reply_to_status_id" : 126752860963737600,
  "created_at" : "2011-10-19 20:15:07 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126749597732323328",
  "geo" : { },
  "id_str" : "126751587057143808",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove WILL INVEST $100M DOLLARBUCKS IN YOUR STARTUPS",
  "id" : 126751587057143808,
  "in_reply_to_status_id" : 126749597732323328,
  "created_at" : "2011-10-19 20:08:27 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 3, 10 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/m8Q4b6CV",
      "expanded_url" : "http:\/\/bit.ly\/oIXKDP",
      "display_url" : "bit.ly\/oIXKDP"
    } ]
  },
  "geo" : { },
  "id_str" : "126726190311555072",
  "text" : "RT @lsegal: New Blog: Do Gem Downloads Really Correlate with Gem Usage? Survey Says: No http:\/\/t.co\/m8Q4b6CV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twhirl.org\" rel=\"nofollow\"\u003ESeesmic twhirl\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/m8Q4b6CV",
        "expanded_url" : "http:\/\/bit.ly\/oIXKDP",
        "display_url" : "bit.ly\/oIXKDP"
      } ]
    },
    "geo" : { },
    "id_str" : "126725934278651904",
    "text" : "New Blog: Do Gem Downloads Really Correlate with Gem Usage? Survey Says: No http:\/\/t.co\/m8Q4b6CV",
    "id" : 126725934278651904,
    "created_at" : "2011-10-19 18:26:31 +0000",
    "user" : {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "protected" : false,
      "id_str" : "5186831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514507532795002880\/VGVzaMU__normal.jpeg",
      "id" : 5186831,
      "verified" : false
    }
  },
  "id" : 126726190311555072,
  "created_at" : "2011-10-19 18:27:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126714961610285057",
  "text" : "This mocking\/stubbing framework is easy to use. - Nobody, ever.",
  "id" : 126714961610285057,
  "created_at" : "2011-10-19 17:42:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Morrison",
      "screen_name" : "jayunit",
      "indices" : [ 0, 8 ],
      "id_str" : "14238213",
      "id" : 14238213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126644824395882496",
  "geo" : { },
  "id_str" : "126657321144303616",
  "in_reply_to_user_id" : 14238213,
  "text" : "@jayunit at least we're not detroit!",
  "id" : 126657321144303616,
  "in_reply_to_status_id" : 126644824395882496,
  "created_at" : "2011-10-19 13:53:53 +0000",
  "in_reply_to_screen_name" : "jayunit",
  "in_reply_to_user_id_str" : "14238213",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/h3aHGpZs",
      "expanded_url" : "http:\/\/www.buffalonews.com\/business\/article595589.ece",
      "display_url" : "buffalonews.com\/business\/artic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126492335910567936",
  "text" : "Awesome story about returning to Buffalo, excited to do the same soon!! http:\/\/t.co\/h3aHGpZs",
  "id" : 126492335910567936,
  "created_at" : "2011-10-19 02:58:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 7, 14 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 15, 22 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126353085403627520",
  "text" : "heyyyy @github @kneath how much whiskey do I have to cough up to get repo listings to be in monospace font again?",
  "id" : 126353085403627520,
  "created_at" : "2011-10-18 17:44:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 3, 11 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126342156095987712",
  "text" : "RT @mperham: \"This PHP code is so clean and elegantly solves the problem at hand\" - Nobody, never",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126341922792017920",
    "text" : "\"This PHP code is so clean and elegantly solves the problem at hand\" - Nobody, never",
    "id" : 126341922792017920,
    "created_at" : "2011-10-18 17:00:36 +0000",
    "user" : {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "protected" : false,
      "id_str" : "14060922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519271188569128960\/i2t9GfcA_normal.jpeg",
      "id" : 14060922,
      "verified" : false
    }
  },
  "id" : 126342156095987712,
  "created_at" : "2011-10-18 17:01:31 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "indices" : [ 3, 11 ],
      "id_str" : "15947489",
      "id" : 15947489
    }, {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 14, 26 ],
      "id_str" : "237845487",
      "id" : 237845487
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 95, 101 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DuneItRight",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Vslhkzxg",
      "expanded_url" : "http:\/\/ow.ly\/i\/jpov",
      "display_url" : "ow.ly\/i\/jpov"
    } ]
  },
  "geo" : { },
  "id_str" : "126308547238690817",
  "text" : "RT @sgharms: \u201C@GeorgeTakei: The inspiration for OWS.  #DuneItRight   http:\/\/t.co\/Vslhkzxg\u201D cc: @qrush",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Takei",
        "screen_name" : "GeorgeTakei",
        "indices" : [ 1, 13 ],
        "id_str" : "237845487",
        "id" : 237845487
      }, {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 82, 88 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DuneItRight",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/Vslhkzxg",
        "expanded_url" : "http:\/\/ow.ly\/i\/jpov",
        "display_url" : "ow.ly\/i\/jpov"
      } ]
    },
    "geo" : { },
    "id_str" : "126307072500445185",
    "text" : "\u201C@GeorgeTakei: The inspiration for OWS.  #DuneItRight   http:\/\/t.co\/Vslhkzxg\u201D cc: @qrush",
    "id" : 126307072500445185,
    "created_at" : "2011-10-18 14:42:07 +0000",
    "user" : {
      "name" : "Steven G. Harms",
      "screen_name" : "sgharms",
      "protected" : false,
      "id_str" : "15947489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443827037573115904\/j6Jp8jht_normal.jpeg",
      "id" : 15947489,
      "verified" : false
    }
  },
  "id" : 126308547238690817,
  "created_at" : "2011-10-18 14:47:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dropbox",
      "screen_name" : "Dropbox",
      "indices" : [ 15, 23 ],
      "id_str" : "14749606",
      "id" : 14749606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/MrWs4ZtV",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/10\/18\/dropbox-said-no-to-nine-digits-acquisition-offer-from-apple-steve-jobs\/",
      "display_url" : "techcrunch.com\/2011\/10\/18\/dro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126307977983565824",
  "text" : "Holy shit, the @dropbox guys have some brass balls. http:\/\/t.co\/MrWs4ZtV",
  "id" : 126307977983565824,
  "created_at" : "2011-10-18 14:45:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arun Agrawal",
      "screen_name" : "arunagw",
      "indices" : [ 0, 8 ],
      "id_str" : "4612661",
      "id" : 4612661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126262406014971904",
  "geo" : { },
  "id_str" : "126304250656587776",
  "in_reply_to_user_id" : 4612661,
  "text" : "@arunagw odd, wtf? :(",
  "id" : 126304250656587776,
  "in_reply_to_status_id" : 126262406014971904,
  "created_at" : "2011-10-18 14:30:54 +0000",
  "in_reply_to_screen_name" : "arunagw",
  "in_reply_to_user_id_str" : "4612661",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126272566573801473",
  "geo" : { },
  "id_str" : "126273086684278784",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant use exchange instead of gmail, then delete = archive",
  "id" : 126273086684278784,
  "in_reply_to_status_id" : 126272566573801473,
  "created_at" : "2011-10-18 12:27:04 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/9fUKvlBM",
      "expanded_url" : "http:\/\/instagr.am\/p\/QlBEE\/",
      "display_url" : "instagr.am\/p\/QlBEE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "126263126176968704",
  "text" : "Down by the river  http:\/\/t.co\/9fUKvlBM",
  "id" : 126263126176968704,
  "created_at" : "2011-10-18 11:47:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Williams",
      "screen_name" : "wbruce",
      "indices" : [ 0, 7 ],
      "id_str" : "38353",
      "id" : 38353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126153787806191617",
  "geo" : { },
  "id_str" : "126156823421136897",
  "in_reply_to_user_id" : 38353,
  "text" : "@wbruce stick everything in\/etc with different formats\/syntaxes, I heard that works well",
  "id" : 126156823421136897,
  "in_reply_to_status_id" : 126153787806191617,
  "created_at" : "2011-10-18 04:45:05 +0000",
  "in_reply_to_screen_name" : "wbruce",
  "in_reply_to_user_id_str" : "38353",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    }, {
      "name" : "hone",
      "screen_name" : "hone",
      "indices" : [ 67, 72 ],
      "id_str" : "6637242",
      "id" : 6637242
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 73, 82 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126124974636408832",
  "geo" : { },
  "id_str" : "126125254899806208",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim i'm not 100% sure of how bundler works in this regard... @hone @indirect would know",
  "id" : 126125254899806208,
  "in_reply_to_status_id" : 126124974636408832,
  "created_at" : "2011-10-18 02:39:38 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126123830233153536",
  "geo" : { },
  "id_str" : "126124584259952640",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim dependency information is a whole different, harder problem. that's a *massive* amount of data.",
  "id" : 126124584259952640,
  "in_reply_to_status_id" : 126123830233153536,
  "created_at" : "2011-10-18 02:36:58 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126122924854886400",
  "geo" : { },
  "id_str" : "126123519376502784",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim yeah both will be difficult. really any messing around with internal rubygems code is :\/",
  "id" : 126123519376502784,
  "in_reply_to_status_id" : 126122924854886400,
  "created_at" : "2011-10-18 02:32:44 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    }, {
      "name" : "Joe Ferris",
      "screen_name" : "joeferris",
      "indices" : [ 71, 81 ],
      "id_str" : "14575143",
      "id" : 14575143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126122213870022656",
  "geo" : { },
  "id_str" : "126122703609540608",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim harder problem is working in the sync. +1 for experimenting, @joeferris and I have talked a lot about differential updates",
  "id" : 126122703609540608,
  "in_reply_to_status_id" : 126122213870022656,
  "created_at" : "2011-10-18 02:29:30 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sanheim",
      "screen_name" : "rsanheim",
      "indices" : [ 0, 9 ],
      "id_str" : "6141442",
      "id" : 6141442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/S18jJ1xx",
      "expanded_url" : "http:\/\/rubygems.org\/specs.4.8.gz",
      "display_url" : "rubygems.org\/specs.4.8.gz"
    } ]
  },
  "in_reply_to_status_id_str" : "126122213870022656",
  "geo" : { },
  "id_str" : "126122440282746881",
  "in_reply_to_user_id" : 6141442,
  "text" : "@rsanheim basically would just be heavy caching of http:\/\/t.co\/S18jJ1xx. So, not hard?",
  "id" : 126122440282746881,
  "in_reply_to_status_id" : 126122213870022656,
  "created_at" : "2011-10-18 02:28:27 +0000",
  "in_reply_to_screen_name" : "rsanheim",
  "in_reply_to_user_id_str" : "6141442",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Shipley",
      "screen_name" : "wilshipley",
      "indices" : [ 3, 14 ],
      "id_str" : "2911221",
      "id" : 2911221
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 93, 106 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BG7j4a5P",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ws6AAhTw7RA",
      "display_url" : "youtube.com\/watch?v=Ws6AAh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126121267370799104",
  "text" : "RT @wilshipley: My jaw was literally dropped watching this. No, I really mean \u201Cliterally.\u201D\n\n\u201C@codinghorror: quantum levitation http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Atwood",
        "screen_name" : "codinghorror",
        "indices" : [ 77, 90 ],
        "id_str" : "5637652",
        "id" : 5637652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/BG7j4a5P",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Ws6AAhTw7RA",
        "display_url" : "youtube.com\/watch?v=Ws6AAh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126101060493377536",
    "text" : "My jaw was literally dropped watching this. No, I really mean \u201Cliterally.\u201D\n\n\u201C@codinghorror: quantum levitation http:\/\/t.co\/BG7j4a5P\u201D",
    "id" : 126101060493377536,
    "created_at" : "2011-10-18 01:03:30 +0000",
    "user" : {
      "name" : "Wil Shipley",
      "screen_name" : "wilshipley",
      "protected" : false,
      "id_str" : "2911221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562730246646947840\/lFp9SLKJ_normal.png",
      "id" : 2911221,
      "verified" : false
    }
  },
  "id" : 126121267370799104,
  "created_at" : "2011-10-18 02:23:48 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/tnNQlvJu",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=oiXaT_1I-vw",
      "display_url" : "youtube.com\/watch?v=oiXaT_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126079795510517760",
  "text" : "Current status: http:\/\/t.co\/tnNQlvJu",
  "id" : 126079795510517760,
  "created_at" : "2011-10-17 23:39:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Kahn",
      "screen_name" : "akahn",
      "indices" : [ 0, 6 ],
      "id_str" : "15068402",
      "id" : 15068402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126061035529580544",
  "geo" : { },
  "id_str" : "126061821839933440",
  "in_reply_to_user_id" : 15068402,
  "text" : "@akahn working on that",
  "id" : 126061821839933440,
  "in_reply_to_status_id" : 126061035529580544,
  "created_at" : "2011-10-17 22:27:35 +0000",
  "in_reply_to_screen_name" : "akahn",
  "in_reply_to_user_id_str" : "15068402",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/OvwXNEwp",
      "expanded_url" : "http:\/\/instagr.am\/p\/QhfMY\/",
      "display_url" : "instagr.am\/p\/QhfMY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "126060827697610752",
  "text" : "Badass husky. http:\/\/t.co\/OvwXNEwp",
  "id" : 126060827697610752,
  "created_at" : "2011-10-17 22:23:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David P Kleinschmidt",
      "screen_name" : "zobar2",
      "indices" : [ 0, 7 ],
      "id_str" : "22627592",
      "id" : 22627592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126058387971653632",
  "geo" : { },
  "id_str" : "126058676724314112",
  "in_reply_to_user_id" : 22627592,
  "text" : "@zobar2 it is definitely a stretch. Minitest is a good alternative for the minimalists :)",
  "id" : 126058676724314112,
  "in_reply_to_status_id" : 126058387971653632,
  "created_at" : "2011-10-17 22:15:05 +0000",
  "in_reply_to_screen_name" : "zobar2",
  "in_reply_to_user_id_str" : "22627592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 61, 71 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/NaPbJ2eP",
      "expanded_url" : "http:\/\/patshaughnessy.net\/2011\/10\/14\/why-bundler-1-1-will-be-much-faster",
      "display_url" : "patshaughnessy.net\/2011\/10\/14\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125980876839452673",
  "text" : "Awesome writeup of why Bundler 1.1 will be faster, thanks to @gemcutter! http:\/\/t.co\/NaPbJ2eP",
  "id" : 125980876839452673,
  "created_at" : "2011-10-17 17:05:56 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125909218464247808",
  "geo" : { },
  "id_str" : "125912496463814656",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant that's some star wars shit right there",
  "id" : 125912496463814656,
  "in_reply_to_status_id" : 125909218464247808,
  "created_at" : "2011-10-17 12:34:13 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Edward Gray II",
      "screen_name" : "JEG2",
      "indices" : [ 0, 5 ],
      "id_str" : "20941662",
      "id" : 20941662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125761630930874368",
  "geo" : { },
  "id_str" : "125765564487565312",
  "in_reply_to_user_id" : 20941662,
  "text" : "@JEG2 I dont understand anyone who does this. It's like reading every line of a very busy IRC channel...",
  "id" : 125765564487565312,
  "in_reply_to_status_id" : 125761630930874368,
  "created_at" : "2011-10-17 02:50:21 +0000",
  "in_reply_to_screen_name" : "JEG2",
  "in_reply_to_user_id_str" : "20941662",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125764343638917120",
  "text" : "Ok, TweetDeck does it too...iPhone UX is not always obvious",
  "id" : 125764343638917120,
  "created_at" : "2011-10-17 02:45:30 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Speicher",
      "screen_name" : "rspeicher",
      "indices" : [ 0, 10 ],
      "id_str" : "15929592",
      "id" : 15929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125763717299314689",
  "geo" : { },
  "id_str" : "125763972275257345",
  "in_reply_to_user_id" : 15929592,
  "text" : "@rspeicher ah ha, twitter does, TD doesn't :(",
  "id" : 125763972275257345,
  "in_reply_to_status_id" : 125763717299314689,
  "created_at" : "2011-10-17 02:44:02 +0000",
  "in_reply_to_screen_name" : "rspeicher",
  "in_reply_to_user_id_str" : "15929592",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125763579877146625",
  "text" : "Do any Twitter apps for iPhone make it easy to scroll through TONS of tweets? TweetDeck for droid has a 'snap' to now timeline, missing it",
  "id" : 125763579877146625,
  "created_at" : "2011-10-17 02:42:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.37148, -71.23925 ]
  },
  "id_str" : "125759621653737472",
  "text" : "Broke down and got Orcs Must Die. So worth it.",
  "id" : 125759621653737472,
  "created_at" : "2011-10-17 02:26:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/XXWTYg1a",
      "expanded_url" : "http:\/\/i.imgur.com\/lNMm0.png",
      "display_url" : "i.imgur.com\/lNMm0.png"
    } ]
  },
  "geo" : { },
  "id_str" : "125726031431741440",
  "text" : "Having put in many hours of TF2 in the past 2 weeks, I can verify this analysis: http:\/\/t.co\/XXWTYg1a",
  "id" : 125726031431741440,
  "created_at" : "2011-10-17 00:13:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apigee",
      "screen_name" : "Apigee",
      "indices" : [ 3, 10 ],
      "id_str" : "26094126",
      "id" : 26094126
    }, {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 53, 62 ],
      "id_str" : "14881835",
      "id" : 14881835
    }, {
      "name" : "Sebastian Spier",
      "screen_name" : "sebastianspier",
      "indices" : [ 71, 86 ],
      "id_str" : "96320763",
      "id" : 96320763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/GblC96Rb",
      "expanded_url" : "http:\/\/spier.hu\/2011\/10\/apigee-console-for-rubygems-api\/",
      "display_url" : "spier.hu\/2011\/10\/apigee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125713069551796224",
  "text" : "RT @Apigee: Check out the Apigee API Console for the @rubygems API (by @sebastianspier) http:\/\/t.co\/GblC96Rb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyGems",
        "screen_name" : "rubygems",
        "indices" : [ 41, 50 ],
        "id_str" : "14881835",
        "id" : 14881835
      }, {
        "name" : "Sebastian Spier",
        "screen_name" : "sebastianspier",
        "indices" : [ 59, 74 ],
        "id_str" : "96320763",
        "id" : 96320763
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/GblC96Rb",
        "expanded_url" : "http:\/\/spier.hu\/2011\/10\/apigee-console-for-rubygems-api\/",
        "display_url" : "spier.hu\/2011\/10\/apigee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "125249445934809088",
    "text" : "Check out the Apigee API Console for the @rubygems API (by @sebastianspier) http:\/\/t.co\/GblC96Rb",
    "id" : 125249445934809088,
    "created_at" : "2011-10-15 16:39:29 +0000",
    "user" : {
      "name" : "Apigee",
      "screen_name" : "Apigee",
      "protected" : false,
      "id_str" : "26094126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000508262189\/6f72b788786c25b956aac477099a23ed_normal.png",
      "id" : 26094126,
      "verified" : false
    }
  },
  "id" : 125713069551796224,
  "created_at" : "2011-10-16 23:21:46 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Bigg",
      "screen_name" : "ryanbigg",
      "indices" : [ 0, 9 ],
      "id_str" : "14506011",
      "id" : 14506011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125702012456288257",
  "geo" : { },
  "id_str" : "125702518046081024",
  "in_reply_to_user_id" : 14506011,
  "text" : "@ryanbigg no, that is way, way worse.",
  "id" : 125702518046081024,
  "in_reply_to_status_id" : 125702012456288257,
  "created_at" : "2011-10-16 22:39:50 +0000",
  "in_reply_to_screen_name" : "ryanbigg",
  "in_reply_to_user_id_str" : "14506011",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 4, 11 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125701509190127617",
  "text" : "Hey @github, can you please kill mailing lists\/google groups next? There has to be a better way.",
  "id" : 125701509190127617,
  "created_at" : "2011-10-16 22:35:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 0, 15 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125594985553862657",
  "geo" : { },
  "id_str" : "125683538321354753",
  "in_reply_to_user_id" : 6151392,
  "text" : "@TheDeadSerious plenty of projects do this and are OSS. RVM, anyone with a pledgie button",
  "id" : 125683538321354753,
  "in_reply_to_status_id" : 125594985553862657,
  "created_at" : "2011-10-16 21:24:25 +0000",
  "in_reply_to_screen_name" : "TheDeadSerious",
  "in_reply_to_user_id_str" : "6151392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125683340312444928",
  "text" : "@IselaMariaPhoto bills fans are used to losing!",
  "id" : 125683340312444928,
  "created_at" : "2011-10-16 21:23:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/kCMDc5Jt",
      "expanded_url" : "http:\/\/instagr.am\/p\/QZ_L7\/",
      "display_url" : "instagr.am\/p\/QZ_L7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "125678769930387456",
  "text" : "Carcassonne! http:\/\/t.co\/kCMDc5Jt",
  "id" : 125678769930387456,
  "created_at" : "2011-10-16 21:05:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125618801453703168",
  "text" : "Bills time! WINGS ACQUIRED",
  "id" : 125618801453703168,
  "created_at" : "2011-10-16 17:07:10 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125618485496782848",
  "text" : "@_rekado is s3.amazonaws.com blocked?",
  "id" : 125618485496782848,
  "created_at" : "2011-10-16 17:05:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125593837107298305",
  "text" : "Ocrs Must Die really is a mix of Tower Defense and FPS...must...resist...buying it!",
  "id" : 125593837107298305,
  "created_at" : "2011-10-16 15:27:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/NJdvuzBF",
      "expanded_url" : "http:\/\/help.rubygems.org",
      "display_url" : "help.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "125593680034807808",
  "text" : "@_rekado :( what URL\/IP is being blocked? can you open a request on http:\/\/t.co\/NJdvuzBF ?",
  "id" : 125593680034807808,
  "created_at" : "2011-10-16 15:27:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 0, 15 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125516742867955712",
  "geo" : { },
  "id_str" : "125591717259911168",
  "in_reply_to_user_id" : 6151392,
  "text" : "@TheDeadSerious i'm confused, you're making money off it?",
  "id" : 125591717259911168,
  "in_reply_to_status_id" : 125516742867955712,
  "created_at" : "2011-10-16 15:19:33 +0000",
  "in_reply_to_screen_name" : "TheDeadSerious",
  "in_reply_to_user_id_str" : "6151392",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/mtXICmwa",
      "expanded_url" : "http:\/\/instagr.am\/p\/QWWuN\/",
      "display_url" : "instagr.am\/p\/QWWuN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "125538751748386816",
  "text" : "Empty dog park ftw http:\/\/t.co\/mtXICmwa",
  "id" : 125538751748386816,
  "created_at" : "2011-10-16 11:49:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Suggs",
      "screen_name" : "ktheory",
      "indices" : [ 0, 8 ],
      "id_str" : "1696",
      "id" : 1696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125276143409569792",
  "geo" : { },
  "id_str" : "125277552330809345",
  "in_reply_to_user_id" : 1696,
  "text" : "@ktheory haha... It's just iUI.js?",
  "id" : 125277552330809345,
  "in_reply_to_status_id" : 125276143409569792,
  "created_at" : "2011-10-15 18:31:10 +0000",
  "in_reply_to_screen_name" : "ktheory",
  "in_reply_to_user_id_str" : "1696",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 17, 23 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125114242268540928",
  "geo" : { },
  "id_str" : "125208174172192768",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase @raggi ...or what?",
  "id" : 125208174172192768,
  "in_reply_to_status_id" : 125114242268540928,
  "created_at" : "2011-10-15 13:55:29 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clayton",
      "screen_name" : "joshuaclayton",
      "indices" : [ 0, 14 ],
      "id_str" : "10293122",
      "id" : 10293122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125090219241381889",
  "geo" : { },
  "id_str" : "125091035905933312",
  "in_reply_to_user_id" : 10293122,
  "text" : "@joshuaclayton no idea but this was pretty easy and feels way more robust. gonna whip up a GR post this weekend for it.",
  "id" : 125091035905933312,
  "in_reply_to_status_id" : 125090219241381889,
  "created_at" : "2011-10-15 06:10:01 +0000",
  "in_reply_to_screen_name" : "joshuaclayton",
  "in_reply_to_user_id_str" : "10293122",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Maddox",
      "screen_name" : "maddox",
      "indices" : [ 0, 7 ],
      "id_str" : "750823",
      "id" : 750823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125087881189527552",
  "geo" : { },
  "id_str" : "125089472617525248",
  "in_reply_to_user_id" : 750823,
  "text" : "@maddox yeah, did this but calling my contact \"Failwhale\" :)",
  "id" : 125089472617525248,
  "in_reply_to_status_id" : 125087881189527552,
  "created_at" : "2011-10-15 06:03:48 +0000",
  "in_reply_to_screen_name" : "maddox",
  "in_reply_to_user_id_str" : "750823",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125089375968165888",
  "text" : "Ended up using Rails 3.1, high_voltage, and easily disabling ActiveRecord to make a static site. Sprockets ftw!",
  "id" : 125089375968165888,
  "created_at" : "2011-10-15 06:03:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 3, 10 ],
      "id_str" : "638323",
      "id" : 638323
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 11, 18 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/PxZb5mP9",
      "expanded_url" : "https:\/\/github.com\/rails\/rails",
      "display_url" : "github.com\/rails\/rails"
    } ]
  },
  "geo" : { },
  "id_str" : "125089063739985920",
  "text" : "yo @kneath @github monospace fonts on repo browsing (the actual tree\/blob entries) are missing http:\/\/t.co\/PxZb5mP9",
  "id" : 125089063739985920,
  "created_at" : "2011-10-15 06:02:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Ringo",
      "screen_name" : "stevenringo",
      "indices" : [ 0, 12 ],
      "id_str" : "10702602",
      "id" : 10702602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125078361184800768",
  "geo" : { },
  "id_str" : "125079039219220481",
  "in_reply_to_user_id" : 10702602,
  "text" : "@stevenringo this sentiment really bothers me.",
  "id" : 125079039219220481,
  "in_reply_to_status_id" : 125078361184800768,
  "created_at" : "2011-10-15 05:22:21 +0000",
  "in_reply_to_screen_name" : "stevenringo",
  "in_reply_to_user_id_str" : "10702602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Ringo",
      "screen_name" : "stevenringo",
      "indices" : [ 0, 12 ],
      "id_str" : "10702602",
      "id" : 10702602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125075870376402944",
  "geo" : { },
  "id_str" : "125076948027318272",
  "in_reply_to_user_id" : 10702602,
  "text" : "@stevenringo no tests at all for that gem :((((",
  "id" : 125076948027318272,
  "in_reply_to_status_id" : 125075870376402944,
  "created_at" : "2011-10-15 05:14:02 +0000",
  "in_reply_to_screen_name" : "stevenringo",
  "in_reply_to_user_id_str" : "10702602",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dream of the 90s",
      "screen_name" : "steveklabnik",
      "indices" : [ 0, 13 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125070365260136448",
  "geo" : { },
  "id_str" : "125074829618581504",
  "in_reply_to_user_id" : 22386062,
  "text" : "@steveklabnik octopress can handle scss\/coffee regen like sprockets can?",
  "id" : 125074829618581504,
  "in_reply_to_status_id" : 125070365260136448,
  "created_at" : "2011-10-15 05:05:37 +0000",
  "in_reply_to_screen_name" : "steveklabnik",
  "in_reply_to_user_id_str" : "22386062",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Brock",
      "screen_name" : "kbrock",
      "indices" : [ 0, 7 ],
      "id_str" : "623223",
      "id" : 623223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125069882042761216",
  "geo" : { },
  "id_str" : "125070023906697216",
  "in_reply_to_user_id" : 623223,
  "text" : "@kbrock added my google apps as an exchange account, seems ok so far",
  "id" : 125070023906697216,
  "in_reply_to_status_id" : 125069882042761216,
  "created_at" : "2011-10-15 04:46:32 +0000",
  "in_reply_to_screen_name" : "kbrock",
  "in_reply_to_user_id_str" : "623223",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125068991063539713",
  "geo" : { },
  "id_str" : "125069391690866688",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan yeahhhh i guess so. trying to combine high_voltage and heroku cedar to see if it works easier.",
  "id" : 125069391690866688,
  "in_reply_to_status_id" : 125068991063539713,
  "created_at" : "2011-10-15 04:44:01 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125066974517657600",
  "text" : "Spinning up a Jekyll site, want to use Sass and CoffeeScript...fuck this, going to Rails 3.1 instead.",
  "id" : 125066974517657600,
  "created_at" : "2011-10-15 04:34:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 4, 19 ],
      "id_str" : "6151392",
      "id" : 6151392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125058308938797056",
  "text" : "Hey @TheDeadSerious, why isn't ruby-toolbox on github?",
  "id" : 125058308938797056,
  "created_at" : "2011-10-15 03:59:58 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/gLl0l0bj",
      "expanded_url" : "http:\/\/m.rubygems.org",
      "display_url" : "m.rubygems.org"
    } ]
  },
  "geo" : { },
  "id_str" : "125045662709592064",
  "text" : "New domain for the gem whisperer, in honor of actually seeing it on iOS! http:\/\/t.co\/gLl0l0bj GET YER GEMS FRESH AND HOT!",
  "id" : 125045662709592064,
  "created_at" : "2011-10-15 03:09:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125031824798920704",
  "text" : "OH WHAT THE FUCK :(",
  "id" : 125031824798920704,
  "created_at" : "2011-10-15 02:14:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sabres",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125031239605428225",
  "text" : "Started listening to the #Sabres just in time for the tiebreaker!!!!",
  "id" : 125031239605428225,
  "created_at" : "2011-10-15 02:12:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Professor S",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125020642100785152",
  "geo" : { },
  "id_str" : "125021839150944256",
  "in_reply_to_user_id" : 23621187,
  "text" : "@Schneems installed !",
  "id" : 125021839150944256,
  "in_reply_to_status_id" : 125020642100785152,
  "created_at" : "2011-10-15 01:35:03 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125007261797068800",
  "text" : "Is there any way to disable the Newsstand in iOS5?",
  "id" : 125007261797068800,
  "created_at" : "2011-10-15 00:37:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125005283796844544",
  "text" : "Wow, all of these apps...cost...money.",
  "id" : 125005283796844544,
  "created_at" : "2011-10-15 00:29:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124999595590828033",
  "text" : "So far, my dog has barked into Siri more than I have talked to it.",
  "id" : 124999595590828033,
  "created_at" : "2011-10-15 00:06:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124996577805864960",
  "text" : "I want to use Siri...but I have no idea WTF to ask it.",
  "id" : 124996577805864960,
  "created_at" : "2011-10-14 23:54:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124996509212213249",
  "text" : "Thanks for the suggestions on apps, folks! Will check them out.",
  "id" : 124996509212213249,
  "created_at" : "2011-10-14 23:54:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124993073158684673",
  "text" : "Haha fuck, how am I going to get my contacts over from Google...",
  "id" : 124993073158684673,
  "created_at" : "2011-10-14 23:40:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124991915790843904",
  "text" : "Setting up my first iPhone! What apps should I get?",
  "id" : 124991915790843904,
  "created_at" : "2011-10-14 23:36:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 0, 4 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124857837770911744",
  "geo" : { },
  "id_str" : "124858144617791488",
  "in_reply_to_user_id" : 14561327,
  "text" : "@dhh most people probably search for \"iphone\" and don't even see the homepage",
  "id" : 124858144617791488,
  "in_reply_to_status_id" : 124857837770911744,
  "created_at" : "2011-10-14 14:44:36 +0000",
  "in_reply_to_screen_name" : "dhh",
  "in_reply_to_user_id_str" : "14561327",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/xTDcTsUV",
      "expanded_url" : "https:\/\/github.com\/antirez\/redis\/pull\/138",
      "display_url" : "github.com\/antirez\/redis\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "124856498894548992",
  "geo" : { },
  "id_str" : "124856839321026560",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez i have a pull request in to fix a few typos while you're at it! :) http:\/\/t.co\/xTDcTsUV",
  "id" : 124856839321026560,
  "in_reply_to_status_id" : 124856498894548992,
  "created_at" : "2011-10-14 14:39:24 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 0, 12 ],
      "id_str" : "5716862",
      "id" : 5716862
    }, {
      "name" : "Angelo Simeoni",
      "screen_name" : "cssboy",
      "indices" : [ 59, 66 ],
      "id_str" : "3928731",
      "id" : 3928731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124852174550339584",
  "geo" : { },
  "id_str" : "124856285895196672",
  "in_reply_to_user_id" : 5716862,
  "text" : "@tristandunn oh man, TORONTO DRIFT needs to come back. \/cc @cssboy",
  "id" : 124856285895196672,
  "in_reply_to_status_id" : 124852174550339584,
  "created_at" : "2011-10-14 14:37:12 +0000",
  "in_reply_to_screen_name" : "tristandunn",
  "in_reply_to_user_id_str" : "5716862",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 8, 16 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124839067371319296",
  "geo" : { },
  "id_str" : "124842929218011136",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @headius remove the gut reaction of 'jruby is slow' and you'll win.",
  "id" : 124842929218011136,
  "in_reply_to_status_id" : 124839067371319296,
  "created_at" : "2011-10-14 13:44:08 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 0, 7 ],
      "id_str" : "5186831",
      "id" : 5186831
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 8, 16 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124839067371319296",
  "geo" : { },
  "id_str" : "124842777908482049",
  "in_reply_to_user_id" : 5186831,
  "text" : "@lsegal @headius and if we actually cared about performance (over time), would ruby really be the best choice?",
  "id" : 124842777908482049,
  "in_reply_to_status_id" : 124839067371319296,
  "created_at" : "2011-10-14 13:43:32 +0000",
  "in_reply_to_screen_name" : "lsegal",
  "in_reply_to_user_id_str" : "5186831",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Loren Segal",
      "screen_name" : "lsegal",
      "indices" : [ 9, 16 ],
      "id_str" : "5186831",
      "id" : 5186831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124839488244555776",
  "geo" : { },
  "id_str" : "124842336315375616",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @lsegal that's the whole point though. As an application developer that's the only benchmark I care about. Perceived vs. Real perf.",
  "id" : 124842336315375616,
  "in_reply_to_status_id" : 124839488244555776,
  "created_at" : "2011-10-14 13:41:47 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Huss",
      "screen_name" : "mwhuss",
      "indices" : [ 0, 7 ],
      "id_str" : "4235881",
      "id" : 4235881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124837899509301249",
  "geo" : { },
  "id_str" : "124842282670235649",
  "in_reply_to_user_id" : 4235881,
  "text" : "@mwhuss I'll probably be in buffalo! Moving at the end of the month. Would love to learn more though.",
  "id" : 124842282670235649,
  "in_reply_to_status_id" : 124837899509301249,
  "created_at" : "2011-10-14 13:41:34 +0000",
  "in_reply_to_screen_name" : "mwhuss",
  "in_reply_to_user_id_str" : "4235881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124837244086386688",
  "text" : "...oh, and the Share button.",
  "id" : 124837244086386688,
  "created_at" : "2011-10-14 13:21:33 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124837196275519488",
  "text" : "...every game crashing\/slowing down, power cycle taking 5 minutes,",
  "id" : 124837196275519488,
  "created_at" : "2011-10-14 13:21:21 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124837013886218240",
  "text" : "What I'll miss about my first gen Droid: dust getting into the screen, not being able to pick up phone calls, home screen freezing, ...",
  "id" : 124837013886218240,
  "created_at" : "2011-10-14 13:20:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124836070624993280",
  "geo" : { },
  "id_str" : "124836761078738944",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius and even that is slow. Feedback is king, I could care less about perf over time",
  "id" : 124836761078738944,
  "in_reply_to_status_id" : 124836070624993280,
  "created_at" : "2011-10-14 13:19:37 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124836101079842816",
  "text" : "What I'm most excited about my iphone 4S being delivered today: better UIs for apps and games that don't suck.",
  "id" : 124836101079842816,
  "created_at" : "2011-10-14 13:17:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124702589181894656",
  "geo" : { },
  "id_str" : "124835293412065280",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius make startup time less than MRI and ill switch. Jruby completely kills my TDD feedback loop.",
  "id" : 124835293412065280,
  "in_reply_to_status_id" : 124702589181894656,
  "created_at" : "2011-10-14 13:13:47 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124824589149802496",
  "text" : "Zomg iphone out for delivery today!",
  "id" : 124824589149802496,
  "created_at" : "2011-10-14 12:31:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124673399107751936",
  "text" : "Of course, every google hit for \"STEAM WONT FUCKING START ON OSX\" is from 1-2+ years ago. MAYBE BECAUSE EVERYONE STOPPED USING IT SINCE THEN",
  "id" : 124673399107751936,
  "created_at" : "2011-10-14 02:30:29 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124672537253789697",
  "text" : "I play consoles instead of PC games because of this bullshit. It's worth more to me for things to JUST FUCKING WORK",
  "id" : 124672537253789697,
  "created_at" : "2011-10-14 02:27:03 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124670604199739392",
  "geo" : { },
  "id_str" : "124671968166416384",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham i have done that several times, nothing. and lost all my games.",
  "id" : 124671968166416384,
  "in_reply_to_status_id" : 124670604199739392,
  "created_at" : "2011-10-14 02:24:48 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124670980000989184",
  "text" : "Is it too much to ask technology to work? Do I know too much about how things work to expect everything to just FUCKING WORK!?",
  "id" : 124670980000989184,
  "created_at" : "2011-10-14 02:20:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124670223608590336",
  "text" : "Fuck OSX Steam. Has to restart in order to connect, can't connect without being off the network, and can't play TF2 since I need to update.",
  "id" : 124670223608590336,
  "created_at" : "2011-10-14 02:17:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "Dave Fayram",
      "screen_name" : "KirinDave",
      "indices" : [ 8, 18 ],
      "id_str" : "784519",
      "id" : 784519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124540729820315649",
  "geo" : { },
  "id_str" : "124541120851091457",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @KirinDave is there any special flag I need to pass so it doesn't look terrible?",
  "id" : 124541120851091457,
  "in_reply_to_status_id" : 124540729820315649,
  "created_at" : "2011-10-13 17:44:51 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham McIntire",
      "screen_name" : "gmcintire",
      "indices" : [ 0, 10 ],
      "id_str" : "642713",
      "id" : 642713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124540483509813248",
  "geo" : { },
  "id_str" : "124540893863751680",
  "in_reply_to_user_id" : 642713,
  "text" : "@gmcintire i have no idea :( i've been thinking a push system, or maybe something like mirrorbrain. no experience with this though.",
  "id" : 124540893863751680,
  "in_reply_to_status_id" : 124540483509813248,
  "created_at" : "2011-10-13 17:43:57 +0000",
  "in_reply_to_screen_name" : "gmcintire",
  "in_reply_to_user_id_str" : "642713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Well-Actually-aaS",
      "screen_name" : "ReinH",
      "indices" : [ 0, 6 ],
      "id_str" : "10255262",
      "id" : 10255262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124534028698255360",
  "geo" : { },
  "id_str" : "124540001898872832",
  "in_reply_to_user_id" : 10255262,
  "text" : "@ReinH we are using CloudFront. gem fetch rake -V",
  "id" : 124540001898872832,
  "in_reply_to_status_id" : 124534028698255360,
  "created_at" : "2011-10-13 17:40:24 +0000",
  "in_reply_to_screen_name" : "ReinH",
  "in_reply_to_user_id_str" : "10255262",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham McIntire",
      "screen_name" : "gmcintire",
      "indices" : [ 0, 10 ],
      "id_str" : "642713",
      "id" : 642713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124535353884422145",
  "geo" : { },
  "id_str" : "124539841642893312",
  "in_reply_to_user_id" : 642713,
  "text" : "@gmcintire no, that's the worst solution. thats how it was before with rubyforge, took days for mirrors to sync (if at all)",
  "id" : 124539841642893312,
  "in_reply_to_status_id" : 124535353884422145,
  "created_at" : "2011-10-13 17:39:46 +0000",
  "in_reply_to_screen_name" : "gmcintire",
  "in_reply_to_user_id_str" : "642713",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124539722168147969",
  "text" : "Are there any tools out there to visualize the history of a file in git over time? Basically want a slider type deal.",
  "id" : 124539722168147969,
  "created_at" : "2011-10-13 17:39:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124526590414700545",
  "geo" : { },
  "id_str" : "124527025145917440",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella possibly. Walk through app\/models\/dependency.rb and think about it.",
  "id" : 124527025145917440,
  "in_reply_to_status_id" : 124526590414700545,
  "created_at" : "2011-10-13 16:48:51 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124526564846223360",
  "geo" : { },
  "id_str" : "124526888906522625",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 nah we'll watch newrelic. (Haha could always yank if it really crashes and burns)",
  "id" : 124526888906522625,
  "in_reply_to_status_id" : 124526564846223360,
  "created_at" : "2011-10-13 16:48:18 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124521483736326146",
  "geo" : { },
  "id_str" : "124526194417868800",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella 1.1 makes me nervous since that will really increase our server load...none of it right now is served via CDN",
  "id" : 124526194417868800,
  "in_reply_to_status_id" : 124521483736326146,
  "created_at" : "2011-10-13 16:45:32 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 49, 60 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124521020672581632",
  "text" : "So many complaints about bundler\/rubygems.org in @tenderlove's mentions, never ANY patches or offers for help to fix :(",
  "id" : 124521020672581632,
  "created_at" : "2011-10-13 16:24:59 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124448766664249344",
  "geo" : { },
  "id_str" : "124520807551606786",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove :( we need mirrors.",
  "id" : 124520807551606786,
  "in_reply_to_status_id" : 124448766664249344,
  "created_at" : "2011-10-13 16:24:08 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124511158953717761",
  "geo" : { },
  "id_str" : "124512850491359232",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella script\/plugin install",
  "id" : 124512850491359232,
  "in_reply_to_status_id" : 124511158953717761,
  "created_at" : "2011-10-13 15:52:31 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Dunn",
      "screen_name" : "tristandunn",
      "indices" : [ 39, 51 ],
      "id_str" : "5716862",
      "id" : 5716862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/cJsfM2bH",
      "expanded_url" : "http:\/\/i.imgur.com\/bXXJI.png",
      "display_url" : "i.imgur.com\/bXXJI.png"
    } ]
  },
  "geo" : { },
  "id_str" : "124444074353762304",
  "text" : "An essential Halloween infographic for @tristandunn. http:\/\/t.co\/cJsfM2bH",
  "id" : 124444074353762304,
  "created_at" : "2011-10-13 11:19:14 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/uB1NICcb",
      "expanded_url" : "http:\/\/www.google.com\/logos\/2011\/gumby11-gumby.jpg",
      "display_url" : "google.com\/logos\/2011\/gum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124326606574587904",
  "text" : "Google's gumby sprite logo is wild: http:\/\/t.co\/uB1NICcb",
  "id" : 124326606574587904,
  "created_at" : "2011-10-13 03:32:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 34, 42 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124325808629235713",
  "text" : "Officially dingdong'd someone via @rubiety's phone. EPIC WIN.",
  "id" : 124325808629235713,
  "created_at" : "2011-10-13 03:29:17 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 69, 79 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/XTkLNM42",
      "expanded_url" : "https:\/\/gist.github.com\/1282468",
      "display_url" : "gist.github.com\/1282468"
    } ]
  },
  "geo" : { },
  "id_str" : "124222951561244672",
  "text" : "Humbled by the amount of community participation over the months for @gemcutter. `git remote -v` itself is proof! http:\/\/t.co\/XTkLNM42",
  "id" : 124222951561244672,
  "created_at" : "2011-10-12 20:40:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 0, 11 ],
      "id_str" : "14809096",
      "id" : 14809096
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 12, 20 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 21, 31 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124219060333449216",
  "geo" : { },
  "id_str" : "124221270517760003",
  "in_reply_to_user_id" : 14809096,
  "text" : "@pnoordhuis @antirez @stevelosh sure, but it's still confusing, regardless",
  "id" : 124221270517760003,
  "in_reply_to_status_id" : 124219060333449216,
  "created_at" : "2011-10-12 20:33:53 +0000",
  "in_reply_to_screen_name" : "pnoordhuis",
  "in_reply_to_user_id_str" : "14809096",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robby Grossman",
      "screen_name" : "freerobby",
      "indices" : [ 0, 10 ],
      "id_str" : "15023866",
      "id" : 15023866
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 54, 64 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124218554756239360",
  "geo" : { },
  "id_str" : "124218722125758465",
  "in_reply_to_user_id" : 15023866,
  "text" : "@freerobby 2.4 more for seeing it saves any memory on @gemcutter's data set. looks like it does so far.",
  "id" : 124218722125758465,
  "in_reply_to_status_id" : 124218554756239360,
  "created_at" : "2011-10-12 20:23:45 +0000",
  "in_reply_to_screen_name" : "freerobby",
  "in_reply_to_user_id_str" : "15023866",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 0, 8 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 9, 20 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124217340882731008",
  "geo" : { },
  "id_str" : "124217588061454337",
  "in_reply_to_user_id" : 5813712,
  "text" : "@antirez @pnoordhuis ok sure, but what happened to 2.5..2.8 ? I don't understand why this project's version never makes sense",
  "id" : 124217588061454337,
  "in_reply_to_status_id" : 124217340882731008,
  "created_at" : "2011-10-12 20:19:15 +0000",
  "in_reply_to_screen_name" : "antirez",
  "in_reply_to_user_id_str" : "5813712",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 109, 117 ],
      "id_str" : "5813712",
      "id" : 5813712
    }, {
      "name" : "Pieter Noordhuis",
      "screen_name" : "pnoordhuis",
      "indices" : [ 118, 129 ],
      "id_str" : "14809096",
      "id" : 14809096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124216984060702720",
  "text" : "Did `brew install redis -H`, \"Server started, Redis version 2.9.0\" ???? redis.io shows 2.4 as the latest RC. @antirez @pnoordhuis WTF?",
  "id" : 124216984060702720,
  "created_at" : "2011-10-12 20:16:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Fine",
      "screen_name" : "jfine",
      "indices" : [ 0, 6 ],
      "id_str" : "14568910",
      "id" : 14568910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124199593868144640",
  "geo" : { },
  "id_str" : "124199915206352896",
  "in_reply_to_user_id" : 14568910,
  "text" : "@jfine ???",
  "id" : 124199915206352896,
  "in_reply_to_status_id" : 124199593868144640,
  "created_at" : "2011-10-12 19:09:01 +0000",
  "in_reply_to_screen_name" : "jfine",
  "in_reply_to_user_id_str" : "14568910",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 30, 40 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/YiEHi4wD",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/gemcutter\/Ejppb-0bot8",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124198083704782848",
  "text" : "If you get a chance, help out @gemcutter and try to break the site! http:\/\/t.co\/YiEHi4wD",
  "id" : 124198083704782848,
  "created_at" : "2011-10-12 19:01:45 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Neath",
      "screen_name" : "kneath",
      "indices" : [ 0, 7 ],
      "id_str" : "638323",
      "id" : 638323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124196108481212417",
  "in_reply_to_user_id" : 638323,
  "text" : "@kneath the number for issues\/pull requests is WAY too tiny :(",
  "id" : 124196108481212417,
  "created_at" : "2011-10-12 18:53:54 +0000",
  "in_reply_to_screen_name" : "kneath",
  "in_reply_to_user_id_str" : "638323",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124195906848436225",
  "text" : "Why is there a dependency on rdoc for railties? Does anyone actually generate rdocs from their rails apps?",
  "id" : 124195906848436225,
  "created_at" : "2011-10-12 18:53:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Hughes",
      "screen_name" : "rubiety",
      "indices" : [ 0, 8 ],
      "id_str" : "6592472",
      "id" : 6592472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124168674344058880",
  "geo" : { },
  "id_str" : "124180975650476032",
  "in_reply_to_user_id" : 6592472,
  "text" : "@rubiety this is a pretty average lunch conversation.",
  "id" : 124180975650476032,
  "in_reply_to_status_id" : 124168674344058880,
  "created_at" : "2011-10-12 17:53:46 +0000",
  "in_reply_to_screen_name" : "rubiety",
  "in_reply_to_user_id_str" : "6592472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00E9my Lecour",
      "screen_name" : "jlecour",
      "indices" : [ 0, 8 ],
      "id_str" : "14587814",
      "id" : 14587814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124149267060363265",
  "geo" : { },
  "id_str" : "124179931428159490",
  "in_reply_to_user_id" : 14587814,
  "text" : "@jlecour I'm convinced this would annoy 99% of people, and be ignored most of the time anyway.",
  "id" : 124179931428159490,
  "in_reply_to_status_id" : 124149267060363265,
  "created_at" : "2011-10-12 17:49:37 +0000",
  "in_reply_to_screen_name" : "jlecour",
  "in_reply_to_user_id_str" : "14587814",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy McAnally",
      "screen_name" : "jm",
      "indices" : [ 0, 3 ],
      "id_str" : "937561",
      "id" : 937561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124139539571802114",
  "geo" : { },
  "id_str" : "124140487681650688",
  "in_reply_to_user_id" : 937561,
  "text" : "@jm all gems get downloads, sometimes under a minute after being pushed thanks to the webhooks system.",
  "id" : 124140487681650688,
  "in_reply_to_status_id" : 124139539571802114,
  "created_at" : "2011-10-12 15:12:53 +0000",
  "in_reply_to_screen_name" : "jm",
  "in_reply_to_user_id_str" : "937561",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Richert",
      "screen_name" : "laserlemon",
      "indices" : [ 0, 11 ],
      "id_str" : "48431692",
      "id" : 48431692
    }, {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 12, 22 ],
      "id_str" : "823615",
      "id" : 823615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124137796653944832",
  "geo" : { },
  "id_str" : "124138254579666945",
  "in_reply_to_user_id" : 48431692,
  "text" : "@laserlemon @bleything I think a grace period might be reasonable...need to think more about it.",
  "id" : 124138254579666945,
  "in_reply_to_status_id" : 124137796653944832,
  "created_at" : "2011-10-12 15:04:00 +0000",
  "in_reply_to_screen_name" : "laserlemon",
  "in_reply_to_user_id_str" : "48431692",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 11, 24 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/1V8U9E3A",
      "expanded_url" : "http:\/\/help.rubygems.org\/kb\/gemcutter\/removing-a-published-rubygem",
      "display_url" : "help.rubygems.org\/kb\/gemcutter\/r\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "124136789765140480",
  "geo" : { },
  "id_str" : "124137113024335872",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @derickbailey the FAQ here covers it: http:\/\/t.co\/1V8U9E3A",
  "id" : 124137113024335872,
  "in_reply_to_status_id" : 124136789765140480,
  "created_at" : "2011-10-12 14:59:28 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bleything",
      "screen_name" : "bleything",
      "indices" : [ 0, 10 ],
      "id_str" : "823615",
      "id" : 823615
    }, {
      "name" : "Derick Bailey",
      "screen_name" : "derickbailey",
      "indices" : [ 11, 24 ],
      "id_str" : "14766954",
      "id" : 14766954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124136789765140480",
  "geo" : { },
  "id_str" : "124137014651125760",
  "in_reply_to_user_id" : 823615,
  "text" : "@bleything @derickbailey the reasons for not allowing deletion\/overwrite are numerous, i'd rather not allow anyone than let them",
  "id" : 124137014651125760,
  "in_reply_to_status_id" : 124136789765140480,
  "created_at" : "2011-10-12 14:59:05 +0000",
  "in_reply_to_screen_name" : "bleything",
  "in_reply_to_user_id_str" : "823615",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 76, 86 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124135910257328129",
  "text" : "I'm really tired of running delete requests for accidentally pushed gems to @gemcutter. Maybe we should just refuse to delete any.",
  "id" : 124135910257328129,
  "created_at" : "2011-10-12 14:54:41 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124123173120770049",
  "text" : "Really low cloud cover in Charlotte is making watching airplanes take off fun, they completely disappear!",
  "id" : 124123173120770049,
  "created_at" : "2011-10-12 14:04:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124104119333027840",
  "text" : "\"Are you sure you want your e-mail address n***@q*****.to to be removed from our distribution list?\" ..seriously? is the hiding necessary?",
  "id" : 124104119333027840,
  "created_at" : "2011-10-12 12:48:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxBuffalo",
      "screen_name" : "TEDxBuffalo",
      "indices" : [ 0, 12 ],
      "id_str" : "140515765",
      "id" : 140515765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124102356571922432",
  "geo" : { },
  "id_str" : "124103487851212800",
  "in_reply_to_user_id" : 140515765,
  "text" : "@TEDxBuffalo will there be videos posted of the talks?",
  "id" : 124103487851212800,
  "in_reply_to_status_id" : 124102356571922432,
  "created_at" : "2011-10-12 12:45:51 +0000",
  "in_reply_to_screen_name" : "TEDxBuffalo",
  "in_reply_to_user_id_str" : "140515765",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/1tGV7vvN",
      "expanded_url" : "http:\/\/webreflection.blogspot.com\/2011\/10\/what-is-wrong-about-17259-lines-of-code.html",
      "display_url" : "webreflection.blogspot.com\/2011\/10\/what-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124102080095981568",
  "text" : "I really hope Google doesn't convince people to actually use Dart. http:\/\/t.co\/1tGV7vvN",
  "id" : 124102080095981568,
  "created_at" : "2011-10-12 12:40:16 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123957922073030656",
  "geo" : { },
  "id_str" : "123966687136579584",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky definitely saw this parked in waltham...no lights and truck was not as full.",
  "id" : 123966687136579584,
  "in_reply_to_status_id" : 123957922073030656,
  "created_at" : "2011-10-12 03:42:16 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 0, 6 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123959559193755648",
  "geo" : { },
  "id_str" : "123966383095689216",
  "in_reply_to_user_id" : 5877822,
  "text" : "@jamis seriously, imagine: classes! Inheritance! Sanity!",
  "id" : 123966383095689216,
  "in_reply_to_status_id" : 123959559193755648,
  "created_at" : "2011-10-12 03:41:03 +0000",
  "in_reply_to_screen_name" : "jamis",
  "in_reply_to_user_id_str" : "5877822",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Ruby",
      "screen_name" : "cltrb",
      "indices" : [ 19, 25 ],
      "id_str" : "68703285",
      "id" : 68703285
    }, {
      "name" : "Jim Van Fleet",
      "screen_name" : "bigfleet",
      "indices" : [ 43, 52 ],
      "id_str" : "3123671",
      "id" : 3123671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123926973759229952",
  "text" : "Thanks for the big @cltrb welcome and from @bigfleet! Had a great time in Charlotte, ready to be back with @ablissfulgal tomorrow!",
  "id" : 123926973759229952,
  "created_at" : "2011-10-12 01:04:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Ruby",
      "screen_name" : "cltrb",
      "indices" : [ 3, 9 ],
      "id_str" : "68703285",
      "id" : 68703285
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 35, 41 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Upu0NVcS",
      "expanded_url" : "http:\/\/g.co\/maps\/aesnm",
      "display_url" : "g.co\/maps\/aesnm"
    } ]
  },
  "geo" : { },
  "id_str" : "123843966033592321",
  "text" : "RT @cltrb: Tonight a Social Event! @qrush will be with us at Dilworth Neighborhood Grill from 6PM til ? http:\/\/t.co\/Upu0NVcS  Drop on by!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 24, 30 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Upu0NVcS",
        "expanded_url" : "http:\/\/g.co\/maps\/aesnm",
        "display_url" : "g.co\/maps\/aesnm"
      } ]
    },
    "geo" : { },
    "id_str" : "123837080316022784",
    "text" : "Tonight a Social Event! @qrush will be with us at Dilworth Neighborhood Grill from 6PM til ? http:\/\/t.co\/Upu0NVcS  Drop on by!",
    "id" : 123837080316022784,
    "created_at" : "2011-10-11 19:07:15 +0000",
    "user" : {
      "name" : "Charlotte Ruby",
      "screen_name" : "cltrb",
      "protected" : false,
      "id_str" : "68703285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/380804179\/256px-Ruby_logo.svg_normal.png",
      "id" : 68703285,
      "verified" : false
    }
  },
  "id" : 123843966033592321,
  "created_at" : "2011-10-11 19:34:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TedXBuffalo",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123731354256019457",
  "text" : "Best part about #TedXBuffalo tag: lots of awesome Buffalo folks to follow! Definitely want to go next year.",
  "id" : 123731354256019457,
  "created_at" : "2011-10-11 12:07:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/Qyym5cKN",
      "expanded_url" : "http:\/\/i.imgur.com\/zWPR7.jpg",
      "display_url" : "i.imgur.com\/zWPR7.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "123572937168125952",
  "text" : "HUSKYPACK http:\/\/t.co\/Qyym5cKN",
  "id" : 123572937168125952,
  "created_at" : "2011-10-11 01:37:38 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Mcaliley",
      "screen_name" : "johnmcaliley",
      "indices" : [ 0, 13 ],
      "id_str" : "59556086",
      "id" : 59556086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123558719022837762",
  "geo" : { },
  "id_str" : "123564456600023041",
  "in_reply_to_user_id" : 59556086,
  "text" : "@johnmcaliley thanks! more to come! :)",
  "id" : 123564456600023041,
  "in_reply_to_status_id" : 123558719022837762,
  "created_at" : "2011-10-11 01:03:56 +0000",
  "in_reply_to_screen_name" : "johnmcaliley",
  "in_reply_to_user_id_str" : "59556086",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "legally a wizard",
      "screen_name" : "dennyabraham",
      "indices" : [ 0, 13 ],
      "id_str" : "16036099",
      "id" : 16036099
    }, {
      "name" : "Jim Van Fleet",
      "screen_name" : "bigfleet",
      "indices" : [ 75, 84 ],
      "id_str" : "3123671",
      "id" : 3123671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123557633046233089",
  "geo" : { },
  "id_str" : "123558269053714432",
  "in_reply_to_user_id" : 16036099,
  "text" : "@dennyabraham maybe! wouldn't mind going somewhere closer to the city. \/cc @bigfleet",
  "id" : 123558269053714432,
  "in_reply_to_status_id" : 123557633046233089,
  "created_at" : "2011-10-11 00:39:21 +0000",
  "in_reply_to_screen_name" : "dennyabraham",
  "in_reply_to_user_id_str" : "16036099",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Anderson",
      "screen_name" : "sudomv",
      "indices" : [ 0, 7 ],
      "id_str" : "1911924188",
      "id" : 1911924188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123521747973713920",
  "geo" : { },
  "id_str" : "123523757523480576",
  "in_reply_to_user_id" : 88489441,
  "text" : "@sudomv thanks! :D",
  "id" : 123523757523480576,
  "in_reply_to_status_id" : 123521747973713920,
  "created_at" : "2011-10-10 22:22:13 +0000",
  "in_reply_to_screen_name" : "AdamBFerg",
  "in_reply_to_user_id_str" : "88489441",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Ruby",
      "screen_name" : "cltrb",
      "indices" : [ 3, 9 ],
      "id_str" : "68703285",
      "id" : 68703285
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 46, 52 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123518323387412482",
  "text" : "RT @cltrb Hey Rubyists, come have a beer with @qrush at Bad Daddy's in Ballantyne tonight!  Follow him for more updates on his schedule.",
  "id" : 123518323387412482,
  "created_at" : "2011-10-10 22:00:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Van Fleet",
      "screen_name" : "bigfleet",
      "indices" : [ 0, 9 ],
      "id_str" : "3123671",
      "id" : 3123671
    }, {
      "name" : "Ben Scofield",
      "screen_name" : "bscofield",
      "indices" : [ 10, 20 ],
      "id_str" : "7921582",
      "id" : 7921582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123359075835723776",
  "geo" : { },
  "id_str" : "123369023500075008",
  "in_reply_to_user_id" : 3123671,
  "text" : "@bigfleet @bscofield yep!",
  "id" : 123369023500075008,
  "in_reply_to_status_id" : 123359075835723776,
  "created_at" : "2011-10-10 12:07:21 +0000",
  "in_reply_to_screen_name" : "bigfleet",
  "in_reply_to_user_id_str" : "3123671",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/8AmaMQ16",
      "expanded_url" : "http:\/\/gowalla.com\/stories\/52My1",
      "display_url" : "gowalla.com\/stories\/52My1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.2201261779, -80.9439504147 ]
  },
  "id_str" : "123241891348226048",
  "text" : "Finally! \u2013 at CLT Charlotte Douglas International http:\/\/t.co\/8AmaMQ16",
  "id" : 123241891348226048,
  "created_at" : "2011-10-10 03:42:11 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sahil Lavingia",
      "screen_name" : "slavingia",
      "indices" : [ 0, 10 ],
      "id_str" : "435126512",
      "id" : 435126512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123231270942670850",
  "geo" : { },
  "id_str" : "123239123996774401",
  "in_reply_to_user_id" : 16347964,
  "text" : "@slavingia wtf is it? Also how much did you shell out for that domain?!",
  "id" : 123239123996774401,
  "in_reply_to_status_id" : 123231270942670850,
  "created_at" : "2011-10-10 03:31:11 +0000",
  "in_reply_to_screen_name" : "shl",
  "in_reply_to_user_id_str" : "16347964",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123165886885543936",
  "geo" : { },
  "id_str" : "123186164541833216",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi RUBBY ON RAILS HAS WARNINGINGS?",
  "id" : 123186164541833216,
  "in_reply_to_status_id" : 123165886885543936,
  "created_at" : "2011-10-10 00:00:44 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 3, 7 ],
      "id_str" : "10079052",
      "id" : 10079052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/Jd0gYNga",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3091649",
      "display_url" : "news.ycombinator.com\/item?id=3091649"
    } ]
  },
  "geo" : { },
  "id_str" : "123185909859483649",
  "text" : "RT @rjs: On how much code Product Managers should understand: http:\/\/t.co\/Jd0gYNga",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/Jd0gYNga",
        "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3091649",
        "display_url" : "news.ycombinator.com\/item?id=3091649"
      } ]
    },
    "geo" : { },
    "id_str" : "123182574876114945",
    "text" : "On how much code Product Managers should understand: http:\/\/t.co\/Jd0gYNga",
    "id" : 123182574876114945,
    "created_at" : "2011-10-09 23:46:29 +0000",
    "user" : {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "protected" : false,
      "id_str" : "10079052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542046114791178240\/n3uSJI7z_normal.jpeg",
      "id" : 10079052,
      "verified" : false
    }
  },
  "id" : 123185909859483649,
  "created_at" : "2011-10-09 23:59:44 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THAT isaac",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Travis Swicegood",
      "screen_name" : "tswicegood",
      "indices" : [ 5, 16 ],
      "id_str" : "9478892",
      "id" : 9478892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123152525833678849",
  "geo" : { },
  "id_str" : "123161263353237504",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @tswicegood clearly you'll still need to know JS for a long, long time...but have you actually written any CS?",
  "id" : 123161263353237504,
  "in_reply_to_status_id" : 123152525833678849,
  "created_at" : "2011-10-09 22:21:48 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam :",
      "screen_name" : "Lenary",
      "indices" : [ 0, 7 ],
      "id_str" : "14466962",
      "id" : 14466962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123144079725953024",
  "geo" : { },
  "id_str" : "123145483404316672",
  "in_reply_to_user_id" : 14466962,
  "text" : "@Lenary no, they were mostly angry. got switched out of the metal detector only line too, then I opted out.",
  "id" : 123145483404316672,
  "in_reply_to_status_id" : 123144079725953024,
  "created_at" : "2011-10-09 21:19:05 +0000",
  "in_reply_to_screen_name" : "Lenary",
  "in_reply_to_user_id_str" : "14466962",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123143559783251968",
  "text" : "Just got a free full body massage at the airport! No happy ending, just a several officers angry waiting at the cancer machines.",
  "id" : 123143559783251968,
  "created_at" : "2011-10-09 21:11:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gowalla.com\/\" rel=\"nofollow\"\u003EGowalla\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/h25aDm0I",
      "expanded_url" : "http:\/\/gowalla.com\/stories\/52BHd",
      "display_url" : "gowalla.com\/stories\/52BHd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.3666420527, -71.0169506349 ]
  },
  "id_str" : "123140290574954496",
  "text" : "Attempt #2... \u2013 at BOS Logan International http:\/\/t.co\/h25aDm0I",
  "id" : 123140290574954496,
  "created_at" : "2011-10-09 20:58:27 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123128630829268992",
  "text" : "OH: 'What's a tablet?' 'It's like an iPad but it's not.'",
  "id" : 123128630829268992,
  "created_at" : "2011-10-09 20:12:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123124500706500608",
  "text" : "Unsure train digital announcement is unsure: \"Belmont is the next stop. ...Which is the next stop?\"",
  "id" : 123124500706500608,
  "created_at" : "2011-10-09 19:55:43 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 3, 12 ],
      "id_str" : "183117429",
      "id" : 183117429
    }, {
      "name" : "Nick Quaranto",
      "screen_name" : "qrush",
      "indices" : [ 14, 20 ],
      "id_str" : "5743852",
      "id" : 5743852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/CcKnA6BM",
      "expanded_url" : "http:\/\/imgur.com\/lMwLj",
      "display_url" : "imgur.com\/lMwLj"
    } ]
  },
  "geo" : { },
  "id_str" : "123122897043726336",
  "text" : "RT @bquarant: @qrush via \/r\/ruby - http:\/\/t.co\/CcKnA6BM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Quaranto",
        "screen_name" : "qrush",
        "indices" : [ 0, 6 ],
        "id_str" : "5743852",
        "id" : 5743852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/CcKnA6BM",
        "expanded_url" : "http:\/\/imgur.com\/lMwLj",
        "display_url" : "imgur.com\/lMwLj"
      } ]
    },
    "geo" : { },
    "id_str" : "123116992428384256",
    "in_reply_to_user_id" : 5743852,
    "text" : "@qrush via \/r\/ruby - http:\/\/t.co\/CcKnA6BM",
    "id" : 123116992428384256,
    "created_at" : "2011-10-09 19:25:53 +0000",
    "in_reply_to_screen_name" : "qrush",
    "in_reply_to_user_id_str" : "5743852",
    "user" : {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "protected" : false,
      "id_str" : "183117429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2469549385\/jwmpg4abzrb5retg76v1_normal.jpeg",
      "id" : 183117429,
      "verified" : false
    }
  },
  "id" : 123122897043726336,
  "created_at" : "2011-10-09 19:49:20 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    }, {
      "name" : "Pat Allan",
      "screen_name" : "pat",
      "indices" : [ 13, 17 ],
      "id_str" : "5523",
      "id" : 5523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/bFwVemQ3",
      "expanded_url" : "http:\/\/github.com\/thoughtbot\/diesel",
      "display_url" : "github.com\/thoughtbot\/die\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "123097654539468800",
  "geo" : { },
  "id_str" : "123098760279621632",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen @pat didn't like http:\/\/t.co\/bFwVemQ3 ?",
  "id" : 123098760279621632,
  "in_reply_to_status_id" : 123097654539468800,
  "created_at" : "2011-10-09 18:13:26 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suss",
      "screen_name" : "suss",
      "indices" : [ 0, 5 ],
      "id_str" : "3468841",
      "id" : 3468841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123088660383019008",
  "geo" : { },
  "id_str" : "123093710157266944",
  "in_reply_to_user_id" : 3468841,
  "text" : "@suss this time it wasn't I what I forgot...instead it was what I took. Convinced it is just impossible to be organized.",
  "id" : 123093710157266944,
  "in_reply_to_status_id" : 123088660383019008,
  "created_at" : "2011-10-09 17:53:22 +0000",
  "in_reply_to_screen_name" : "suss",
  "in_reply_to_user_id_str" : "3468841",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123087981400686593",
  "text" : "How do I manage to fuck up every trip I take? Either lose or don't remember things, every time without fail.",
  "id" : 123087981400686593,
  "created_at" : "2011-10-09 17:30:36 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Reimann",
      "screen_name" : "dbloete",
      "indices" : [ 0, 8 ],
      "id_str" : "462447345",
      "id" : 462447345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122635618751746048",
  "geo" : { },
  "id_str" : "122650653783900161",
  "in_reply_to_user_id" : 1145881,
  "text" : "@dbloete yes sorry :( will respond today",
  "id" : 122650653783900161,
  "in_reply_to_status_id" : 122635618751746048,
  "created_at" : "2011-10-08 12:32:49 +0000",
  "in_reply_to_screen_name" : "dennisreimann",
  "in_reply_to_user_id_str" : "1145881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Te6gZhy4",
      "expanded_url" : "http:\/\/29.media.tumblr.com\/tumblr_lrwp1ydOD41qk5yn3o1_500.jpg",
      "display_url" : "29.media.tumblr.com\/tumblr_lrwp1yd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122628218879619073",
  "text" : "Current status: http:\/\/t.co\/Te6gZhy4",
  "id" : 122628218879619073,
  "created_at" : "2011-10-08 11:03:40 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 0, 10 ],
      "id_str" : "9459332",
      "id" : 9459332
    }, {
      "name" : "Christoph Olszowka",
      "screen_name" : "TheDeadSerious",
      "indices" : [ 11, 26 ],
      "id_str" : "6151392",
      "id" : 6151392
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 65, 75 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122451964884815872",
  "geo" : { },
  "id_str" : "122469391551041536",
  "in_reply_to_user_id" : 9459332,
  "text" : "@svenfuchs @TheDeadSerious it's about time we get this linked on @gemcutter pages",
  "id" : 122469391551041536,
  "in_reply_to_status_id" : 122451964884815872,
  "created_at" : "2011-10-08 00:32:32 +0000",
  "in_reply_to_screen_name" : "svenfuchs",
  "in_reply_to_user_id_str" : "9459332",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122430886007406592",
  "geo" : { },
  "id_str" : "122433311741181952",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh I don't understand this argument. It does what you want. If you must just delete the other junk (view, model, etc)",
  "id" : 122433311741181952,
  "in_reply_to_status_id" : 122430886007406592,
  "created_at" : "2011-10-07 22:09:10 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122429197544210432",
  "geo" : { },
  "id_str" : "122430808198873088",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh backbone?",
  "id" : 122430808198873088,
  "in_reply_to_status_id" : 122429197544210432,
  "created_at" : "2011-10-07 21:59:13 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stub",
      "indices" : [ 85, 90 ]
    }, {
      "text" : "build_stubbed",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122428344846385152",
  "geo" : { },
  "id_str" : "122430723440390144",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi there is none. stub out only what you need or use something like FactoryGirl's #stub (#build_stubbed in FG 2.0)",
  "id" : 122430723440390144,
  "in_reply_to_status_id" : 122428344846385152,
  "created_at" : "2011-10-07 21:58:53 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 0, 10 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122407546509197312",
  "geo" : { },
  "id_str" : "122407941625217025",
  "in_reply_to_user_id" : 10230812,
  "text" : "@josevalim booyah!!",
  "id" : 122407941625217025,
  "in_reply_to_status_id" : 122407546509197312,
  "created_at" : "2011-10-07 20:28:22 +0000",
  "in_reply_to_screen_name" : "josevalim",
  "in_reply_to_user_id_str" : "10230812",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122396577678635008",
  "geo" : { },
  "id_str" : "122397261291454465",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt and instead you use?",
  "id" : 122397261291454465,
  "in_reply_to_status_id" : 122396577678635008,
  "created_at" : "2011-10-07 19:45:55 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 0, 6 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122396763561799680",
  "geo" : { },
  "id_str" : "122397109289885696",
  "in_reply_to_user_id" : 15359408,
  "text" : "@raggi run \"rake\", that error occurs, \"test\" task appears NOWHERE in my application code. think like a brand new rails user dude.",
  "id" : 122397109289885696,
  "in_reply_to_status_id" : 122396763561799680,
  "created_at" : "2011-10-07 19:45:19 +0000",
  "in_reply_to_screen_name" : "raggi",
  "in_reply_to_user_id_str" : "15359408",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122384863545401344",
  "geo" : { },
  "id_str" : "122385653303476224",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove where is the \"test\" task coming from? why is rails getting only harder to understand for people who have used it for years? :(",
  "id" : 122385653303476224,
  "in_reply_to_status_id" : 122384863545401344,
  "created_at" : "2011-10-07 18:59:48 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 0, 4 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122385400051404800",
  "geo" : { },
  "id_str" : "122385520667004928",
  "in_reply_to_user_id" : 11253302,
  "text" : "@fxn :(",
  "id" : 122385520667004928,
  "in_reply_to_status_id" : 122385400051404800,
  "created_at" : "2011-10-07 18:59:16 +0000",
  "in_reply_to_screen_name" : "fxn",
  "in_reply_to_user_id_str" : "11253302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 79, 90 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 91, 102 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Eliza Brock Marcum",
      "screen_name" : "elizabrock",
      "indices" : [ 103, 114 ],
      "id_str" : "10358392",
      "id" : 10358392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/gMCJkKM1",
      "expanded_url" : "http:\/\/blog.elizabrock.com\/post\/7213861688\/rails-3-1-rake-aborted-dont-know-how-to-build-task",
      "display_url" : "blog.elizabrock.com\/post\/721386168\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122384528214982657",
  "text" : "This rake\/rails error sucks. What can we do about it? http:\/\/t.co\/gMCJkKM1 \/cc @tenderlove @jimweirich @elizabrock",
  "id" : 122384528214982657,
  "created_at" : "2011-10-07 18:55:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 0, 4 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/iSR1DbxU",
      "expanded_url" : "https:\/\/github.com\/lifo\/docrails\/commit\/3d595c5eaeec43e5dc9f2930420506108b0ce813",
      "display_url" : "github.com\/lifo\/docrails\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "122335140092444673",
  "geo" : { },
  "id_str" : "122382549652742145",
  "in_reply_to_user_id" : 11253302,
  "text" : "@fxn i dont think it did, i dont see this change in the assets guide: http:\/\/t.co\/iSR1DbxU",
  "id" : 122382549652742145,
  "in_reply_to_status_id" : 122335140092444673,
  "created_at" : "2011-10-07 18:47:28 +0000",
  "in_reply_to_screen_name" : "fxn",
  "in_reply_to_user_id_str" : "11253302",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby on Rails",
      "screen_name" : "rails",
      "indices" : [ 0, 6 ],
      "id_str" : "3116191",
      "id" : 3116191
    }, {
      "name" : "Xavier Noria",
      "screen_name" : "fxn",
      "indices" : [ 7, 11 ],
      "id_str" : "11253302",
      "id" : 11253302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122333680239783936",
  "geo" : { },
  "id_str" : "122334093802348544",
  "in_reply_to_user_id" : 3116191,
  "text" : "@rails @fxn time to regen the guides site!",
  "id" : 122334093802348544,
  "in_reply_to_status_id" : 122333680239783936,
  "created_at" : "2011-10-07 15:34:55 +0000",
  "in_reply_to_screen_name" : "rails",
  "in_reply_to_user_id_str" : "3116191",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122328515130564608",
  "geo" : { },
  "id_str" : "122329976774209538",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl this is the same endpoint that `gem owner` uses. I suppose we could have it in both, more thoughts for API v2!",
  "id" : 122329976774209538,
  "in_reply_to_status_id" : 122328515130564608,
  "created_at" : "2011-10-07 15:18:33 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 18, 28 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 126, 133 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/sSWjh4Js",
      "expanded_url" : "https:\/\/rubygems.org\/api\/v1\/gems\/rails\/owners.json",
      "display_url" : "rubygems.org\/api\/v1\/gems\/ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122327349579612160",
  "text" : "Listing owners on @gemcutter through the API is publicly accessible now, because, why not? `curl http:\/\/t.co\/sSWjh4Js` thanks @sferik!",
  "id" : 122327349579612160,
  "created_at" : "2011-10-07 15:08:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Losh",
      "screen_name" : "stevelosh",
      "indices" : [ 0, 10 ],
      "id_str" : "727813",
      "id" : 727813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122300212726345728",
  "geo" : { },
  "id_str" : "122301143698255872",
  "in_reply_to_user_id" : 727813,
  "text" : "@stevelosh git merge would have worked if that branch was not tracking master.",
  "id" : 122301143698255872,
  "in_reply_to_status_id" : 122300212726345728,
  "created_at" : "2011-10-07 13:23:59 +0000",
  "in_reply_to_screen_name" : "stevelosh",
  "in_reply_to_user_id_str" : "727813",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frontend Stuff",
      "screen_name" : "frontendstuff",
      "indices" : [ 3, 17 ],
      "id_str" : "252443560",
      "id" : 252443560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122285499330211841",
  "text" : "RT @frontendstuff: Array(16).join(\"lol\" - 2) + \"batman\"\n\"NaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNbatman\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mowglii.com\/itsy\" rel=\"nofollow\"\u003EItsy!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121996485578588160",
    "text" : "Array(16).join(\"lol\" - 2) + \"batman\"\n\"NaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNNaNbatman\"",
    "id" : 121996485578588160,
    "created_at" : "2011-10-06 17:13:23 +0000",
    "user" : {
      "name" : "Frontend Stuff",
      "screen_name" : "frontendstuff",
      "protected" : false,
      "id_str" : "252443560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1245005057\/fe-stuff_normal.png",
      "id" : 252443560,
      "verified" : false
    }
  },
  "id" : 122285499330211841,
  "created_at" : "2011-10-07 12:21:49 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/IMeuNN4l",
      "expanded_url" : "https:\/\/www.facebook.com\/nick.quaranto\/posts\/846143050625",
      "display_url" : "facebook.com\/nick.quaranto\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122117265779982337",
  "text" : "617 \u21BA 716 http:\/\/t.co\/IMeuNN4l",
  "id" : 122117265779982337,
  "created_at" : "2011-10-07 01:13:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/WCSdgPL1",
      "expanded_url" : "http:\/\/tigertailfoods.com\/wp\/wp-content\/uploads\/2010\/11\/husky-at-computer.jpg",
      "display_url" : "tigertailfoods.com\/wp\/wp-content\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122044932193128448",
  "text" : "Current status: http:\/\/t.co\/WCSdgPL1",
  "id" : 122044932193128448,
  "created_at" : "2011-10-06 20:25:53 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Corey Woodcox",
      "screen_name" : "cwoodcox",
      "indices" : [ 8, 17 ],
      "id_str" : "15893003",
      "id" : 15893003
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 18, 27 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122037053826404352",
  "geo" : { },
  "id_str" : "122037374921342976",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @cwoodcox @indirect and not trying to troll, i just want to run one damn command :(",
  "id" : 122037374921342976,
  "in_reply_to_status_id" : 122037053826404352,
  "created_at" : "2011-10-06 19:55:52 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Corey Woodcox",
      "screen_name" : "cwoodcox",
      "indices" : [ 8, 17 ],
      "id_str" : "15893003",
      "id" : 15893003
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 18, 27 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122037053826404352",
  "geo" : { },
  "id_str" : "122037292880769025",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @cwoodcox @indirect so basically i want `alias bundle=bundle update`",
  "id" : 122037292880769025,
  "in_reply_to_status_id" : 122037053826404352,
  "created_at" : "2011-10-06 19:55:32 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122037053826404352",
  "geo" : { },
  "id_str" : "122037102086066176",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats so why can't install?",
  "id" : 122037102086066176,
  "in_reply_to_status_id" : 122037053826404352,
  "created_at" : "2011-10-06 19:54:47 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Corey Woodcox",
      "screen_name" : "cwoodcox",
      "indices" : [ 8, 17 ],
      "id_str" : "15893003",
      "id" : 15893003
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 18, 27 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122018809937801216",
  "geo" : { },
  "id_str" : "122036899408904192",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @cwoodcox @indirect not really. ideally, i want `bundle` to work no matter what happens in the Gemfile.",
  "id" : 122036899408904192,
  "in_reply_to_status_id" : 122018809937801216,
  "created_at" : "2011-10-06 19:53:58 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 8, 17 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122010542272544768",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @indirect no one understands or cares why they have just violated everything sane about version management, just install it",
  "id" : 122010542272544768,
  "created_at" : "2011-10-06 18:09:14 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 8, 17 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122010161467506688",
  "geo" : { },
  "id_str" : "122010383748825088",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @indirect the use case is, \"i just added something to my gemfile, don't make me run `bundle` then `bundle update foo` to install it",
  "id" : 122010383748825088,
  "in_reply_to_status_id" : 122010161467506688,
  "created_at" : "2011-10-06 18:08:36 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Meyer",
      "screen_name" : "roidrage",
      "indices" : [ 0, 9 ],
      "id_str" : "14658472",
      "id" : 14658472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122009063188987904",
  "geo" : { },
  "id_str" : "122010091284201472",
  "in_reply_to_user_id" : 14658472,
  "text" : "@roidrage LOUDDDDD NOISES!!!!!",
  "id" : 122010091284201472,
  "in_reply_to_status_id" : 122009063188987904,
  "created_at" : "2011-10-06 18:07:27 +0000",
  "in_reply_to_screen_name" : "roidrage",
  "in_reply_to_user_id_str" : "14658472",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 0, 9 ],
      "id_str" : "5674672",
      "id" : 5674672
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 10, 17 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122009434531696642",
  "geo" : { },
  "id_str" : "122009598302498816",
  "in_reply_to_user_id" : 5674672,
  "text" : "@indirect @wycats yes yes yes.",
  "id" : 122009598302498816,
  "in_reply_to_status_id" : 122009434531696642,
  "created_at" : "2011-10-06 18:05:29 +0000",
  "in_reply_to_screen_name" : "indirect",
  "in_reply_to_user_id_str" : "5674672",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 118, 125 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "literally misandr\u00E9",
      "screen_name" : "indirect",
      "indices" : [ 126, 135 ],
      "id_str" : "5674672",
      "id" : 5674672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122008971375677440",
  "text" : "Can we PLEASE PLEASE have `bundle --update-i-dont-give-a-fuck-just-install-the-damn-gem`? Or just `bundle install -f` @wycats @indirect ?",
  "id" : 122008971375677440,
  "created_at" : "2011-10-06 18:03:00 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stephenson",
      "screen_name" : "sstephenson",
      "indices" : [ 5, 17 ],
      "id_str" : "6707392",
      "id" : 6707392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/92QRCFHm",
      "expanded_url" : "https:\/\/sstephenson.s3.amazonaws.com\/presentations\/fowa-2011-coffeescript.pdf",
      "display_url" : "sstephenson.s3.amazonaws.com\/presentations\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121921866406432768",
  "text" : "Yep, @sstephenson nails why you should go CoffeeScript and never, ever look back: http:\/\/t.co\/92QRCFHm",
  "id" : 121921866406432768,
  "created_at" : "2011-10-06 12:16:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121749395548012544",
  "text" : "Really enjoying all of these tweets with just one unicode box on my droid.",
  "id" : 121749395548012544,
  "created_at" : "2011-10-06 00:51:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 41, 52 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121741493185679361",
  "text" : "Ok, gem uninstall psych fixed it? :( \/cc @tenderlove",
  "id" : 121741493185679361,
  "created_at" : "2011-10-06 00:20:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 78, 89 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/KlnWgKsz",
      "expanded_url" : "https:\/\/gist.github.com\/1266144",
      "display_url" : "gist.github.com\/1266144"
    } ]
  },
  "geo" : { },
  "id_str" : "121741237152780288",
  "text" : "RAILS, Y SO MANY WARNINGS? http:\/\/t.co\/KlnWgKsz (rails new -d postgresql) \/cc @tenderlove",
  "id" : 121741237152780288,
  "created_at" : "2011-10-06 00:19:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121737576964030464",
  "text" : "Just bought my first 5 letter .com. Feels good man.",
  "id" : 121737576964030464,
  "created_at" : "2011-10-06 00:04:34 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/y8FxodbQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=63Y5XjlO4vk",
      "display_url" : "youtube.com\/watch?v=63Y5Xj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121734674413387776",
  "text" : "Barrels. http:\/\/t.co\/y8FxodbQ",
  "id" : 121734674413387776,
  "created_at" : "2011-10-05 23:53:02 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/0QfEkzPo",
      "expanded_url" : "http:\/\/www.apple.com\/stevejobs\/",
      "display_url" : "apple.com\/stevejobs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "121732267692408832",
  "text" : "Going to code some awesome shit tonight. Here's to you, Steve. http:\/\/t.co\/0QfEkzPo",
  "id" : 121732267692408832,
  "created_at" : "2011-10-05 23:43:28 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121731241786609664",
  "text" : "Hope you guys feel like assholes for complaining about the iPhone 4S now.",
  "id" : 121731241786609664,
  "created_at" : "2011-10-05 23:39:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121634570838880256",
  "geo" : { },
  "id_str" : "121634941523070976",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant your emails are probably just as BORING",
  "id" : 121634941523070976,
  "in_reply_to_status_id" : 121634570838880256,
  "created_at" : "2011-10-05 17:16:44 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121573166471581696",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan I guess my main grievance is that route\/css tags were in one place, now they arre encouraged to be scrambled",
  "id" : 121573166471581696,
  "created_at" : "2011-10-05 13:11:16 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121562680430563328",
  "geo" : { },
  "id_str" : "121572696281718785",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan I don't see why this is an issue still. I understand the need for more abstraction but paths\/selectors are great for starting out",
  "id" : 121572696281718785,
  "in_reply_to_status_id" : 121562680430563328,
  "created_at" : "2011-10-05 13:09:24 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Harman",
      "screen_name" : "stevenharman",
      "indices" : [ 0, 13 ],
      "id_str" : "5875112",
      "id" : 5875112
    }, {
      "name" : "Marc Weil",
      "screen_name" : "marcweil",
      "indices" : [ 14, 23 ],
      "id_str" : "18230025",
      "id" : 18230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121441844168105984",
  "geo" : { },
  "id_str" : "121447291226820608",
  "in_reply_to_user_id" : 5875112,
  "text" : "@stevenharman @marcweil i couldn't even get images to load, css seemed ok, didn't get to JS yet.",
  "id" : 121447291226820608,
  "in_reply_to_status_id" : 121441844168105984,
  "created_at" : "2011-10-05 04:51:05 +0000",
  "in_reply_to_screen_name" : "stevenharman",
  "in_reply_to_user_id_str" : "5875112",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 19, 29 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/PVIF4UJO",
      "expanded_url" : "https:\/\/rubygems.org\/profiles\/blablablalol",
      "display_url" : "rubygems.org\/profiles\/blabl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121447054827470848",
  "text" : "404's and 500's in @gemcutter now aren't stupid Internal Server Error messages! http:\/\/t.co\/PVIF4UJO (this needs a blog post)",
  "id" : 121447054827470848,
  "created_at" : "2011-10-05 04:50:08 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 80, 90 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121438489966428160",
  "text" : "Tried and failed to understand sprockets and Rails 3.1 integration tonight with @gemcutter. I have a feeling many will avoid a 3.1 upgrade.",
  "id" : 121438489966428160,
  "created_at" : "2011-10-05 04:16:06 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/mJgSicIm",
      "expanded_url" : "https:\/\/github.com\/rails\/journey",
      "display_url" : "github.com\/rails\/journey"
    } ]
  },
  "geo" : { },
  "id_str" : "121437286670942210",
  "text" : "\"Journey is a router. It routes requests.\" ... \"FEATURES\/PROBLEMS: Designed for rails\" lol http:\/\/t.co\/mJgSicIm",
  "id" : 121437286670942210,
  "created_at" : "2011-10-05 04:11:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Sichanugrist",
      "screen_name" : "sikachu",
      "indices" : [ 0, 8 ],
      "id_str" : "28819745",
      "id" : 28819745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121411531006160897",
  "geo" : { },
  "id_str" : "121417055466561537",
  "in_reply_to_user_id" : 28819745,
  "text" : "@sikachu brew install pianobar",
  "id" : 121417055466561537,
  "in_reply_to_status_id" : 121411531006160897,
  "created_at" : "2011-10-05 02:50:56 +0000",
  "in_reply_to_screen_name" : "sikachu",
  "in_reply_to_user_id_str" : "28819745",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121416900805795840",
  "text" : "WITTY QUIP ABOUT RELEVANT TOPIC ON HACKER NEWS, SUBTLE INSULT AND JEST TOWARDS OWN LONELINESS",
  "id" : 121416900805795840,
  "created_at" : "2011-10-05 02:50:19 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Quaranto",
      "screen_name" : "bquarant",
      "indices" : [ 0, 9 ],
      "id_str" : "183117429",
      "id" : 183117429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121405944348413952",
  "geo" : { },
  "id_str" : "121407011291275266",
  "in_reply_to_user_id" : 183117429,
  "text" : "@bquarant \u007D:(",
  "id" : 121407011291275266,
  "in_reply_to_status_id" : 121405944348413952,
  "created_at" : "2011-10-05 02:11:01 +0000",
  "in_reply_to_screen_name" : "bquarant",
  "in_reply_to_user_id_str" : "183117429",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121390990287306752",
  "text" : "They are constantly programming shit on Star Trek. Holodeck, various subsystems, Data himself. I wish programming was that easy.",
  "id" : 121390990287306752,
  "created_at" : "2011-10-05 01:07:22 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121388369606488065",
  "text" : "GHC, Y U HAVE INSTALLER THAT IS 131 MB?",
  "id" : 121388369606488065,
  "created_at" : "2011-10-05 00:56:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    }, {
      "name" : "C. Scott Meiklejohn",
      "screen_name" : "cmeik",
      "indices" : [ 8, 14 ],
      "id_str" : "6815762",
      "id" : 6815762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121349497820430337",
  "geo" : { },
  "id_str" : "121357306356174849",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik @cmeik time to start watching newrelic! Haha",
  "id" : 121357306356174849,
  "in_reply_to_status_id" : 121349497820430337,
  "created_at" : "2011-10-04 22:53:31 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Cardarella",
      "screen_name" : "bcardarella",
      "indices" : [ 0, 12 ],
      "id_str" : "18787589",
      "id" : 18787589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121313383512408064",
  "geo" : { },
  "id_str" : "121317101267984385",
  "in_reply_to_user_id" : 18787589,
  "text" : "@bcardarella and it's still slow as balls",
  "id" : 121317101267984385,
  "in_reply_to_status_id" : 121313383512408064,
  "created_at" : "2011-10-04 20:13:45 +0000",
  "in_reply_to_screen_name" : "bcardarella",
  "in_reply_to_user_id_str" : "18787589",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bernhardt",
      "screen_name" : "garybernhardt",
      "indices" : [ 0, 14 ],
      "id_str" : "809685",
      "id" : 809685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121292639172706304",
  "geo" : { },
  "id_str" : "121294814116462593",
  "in_reply_to_user_id" : 809685,
  "text" : "@garybernhardt and they're TOTALLY NOT USEFUL BLEHHHH MERGLE",
  "id" : 121294814116462593,
  "in_reply_to_status_id" : 121292639172706304,
  "created_at" : "2011-10-04 18:45:11 +0000",
  "in_reply_to_screen_name" : "garybernhardt",
  "in_reply_to_user_id_str" : "809685",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121261817816297472",
  "text" : "Autorefreshing Engadget for the first time in years, actually excited to ditch my first-gen Droid.",
  "id" : 121261817816297472,
  "created_at" : "2011-10-04 16:34:04 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Mayer",
      "screen_name" : "danmayer",
      "indices" : [ 0, 9 ],
      "id_str" : "14630648",
      "id" : 14630648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121259617362771968",
  "geo" : { },
  "id_str" : "121259987275227137",
  "in_reply_to_user_id" : 14630648,
  "text" : "@danmayer gmail filter",
  "id" : 121259987275227137,
  "in_reply_to_status_id" : 121259617362771968,
  "created_at" : "2011-10-04 16:26:48 +0000",
  "in_reply_to_screen_name" : "danmayer",
  "in_reply_to_user_id_str" : "14630648",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Brady",
      "screen_name" : "dbrady",
      "indices" : [ 61, 68 ],
      "id_str" : "14253546",
      "id" : 14253546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121254326558654465",
  "text" : "Failed with the railroad gem and several github repos, found @dbrady's and it worked! Thanks!!",
  "id" : 121254326558654465,
  "created_at" : "2011-10-04 16:04:18 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Reimann",
      "screen_name" : "dbloete",
      "indices" : [ 0, 8 ],
      "id_str" : "462447345",
      "id" : 462447345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121186412740612097",
  "geo" : { },
  "id_str" : "121221760757669888",
  "in_reply_to_user_id" : 1145881,
  "text" : "@dbloete my OSS time is absolutely hammered, but I would love to walk you through how I'd do it though. email me: nick@quaran.to",
  "id" : 121221760757669888,
  "in_reply_to_status_id" : 121186412740612097,
  "created_at" : "2011-10-04 13:54:54 +0000",
  "in_reply_to_screen_name" : "dennisreimann",
  "in_reply_to_user_id_str" : "1145881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/wGkXYBt0",
      "expanded_url" : "https:\/\/github.com\/cucumber\/cucumber-rails\/issues\/174",
      "display_url" : "github.com\/cucumber\/cucum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121221019250855936",
  "text" : "Very unhappy about this cucumber change. :( http:\/\/t.co\/wGkXYBt0",
  "id" : 121221019250855936,
  "created_at" : "2011-10-04 13:51:57 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121220120386347008",
  "text" : "Getting used to the new gmail dense theme, away from Space for the first time in years. A pleasant change.",
  "id" : 121220120386347008,
  "created_at" : "2011-10-04 13:48:23 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121061253048303617",
  "geo" : { },
  "id_str" : "121063823363940352",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 IT MAKES SO MUCH SENSE NOW",
  "id" : 121063823363940352,
  "in_reply_to_status_id" : 121061253048303617,
  "created_at" : "2011-10-04 03:27:19 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/O2eAwRmb",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_lbqi9cJ2Hh1qz9muno1_400.gif",
      "display_url" : "25.media.tumblr.com\/tumblr_lbqi9cJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121034278581714945",
  "text" : "Current status: http:\/\/t.co\/O2eAwRmb",
  "id" : 121034278581714945,
  "created_at" : "2011-10-04 01:29:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Padilla",
      "screen_name" : "dabit",
      "indices" : [ 0, 6 ],
      "id_str" : "15265916",
      "id" : 15265916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120907310443937794",
  "geo" : { },
  "id_str" : "121011380286525440",
  "in_reply_to_user_id" : 15265916,
  "text" : "@dabit no? maybe open an issue on help.rubygems.org or SO with your errors?",
  "id" : 121011380286525440,
  "in_reply_to_status_id" : 120907310443937794,
  "created_at" : "2011-10-03 23:58:56 +0000",
  "in_reply_to_screen_name" : "dabit",
  "in_reply_to_user_id_str" : "15265916",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Reimann",
      "screen_name" : "dbloete",
      "indices" : [ 0, 8 ],
      "id_str" : "462447345",
      "id" : 462447345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120813879143038977",
  "geo" : { },
  "id_str" : "121011272484519936",
  "in_reply_to_user_id" : 1145881,
  "text" : "@dbloete agreed, i've been calling for a separate service to parse\/display these that could use our api",
  "id" : 121011272484519936,
  "in_reply_to_status_id" : 120813879143038977,
  "created_at" : "2011-10-03 23:58:30 +0000",
  "in_reply_to_screen_name" : "dennisreimann",
  "in_reply_to_user_id_str" : "1145881",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120969436885827585",
  "text" : "Hey internets, I want to read about Kanban tonight. GIVE ME YOUR LINKS!",
  "id" : 120969436885827585,
  "created_at" : "2011-10-03 21:12:15 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120947207095590913",
  "text" : "\"Bitbucket now rocks Git\" guys, it's 6 months to April Fools' Day.",
  "id" : 120947207095590913,
  "created_at" : "2011-10-03 19:43:55 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120850690087202816",
  "text" : "Apparently body slamming into my face is how my dog communicates he's going to shit on the floor and make me late for work.",
  "id" : 120850690087202816,
  "created_at" : "2011-10-03 13:20:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120581785577992192",
  "text" : "There's 2 types of HTML templating systems: 1) only programmers can modify or 2) meant for designers to tweak. Preferring the latter.",
  "id" : 120581785577992192,
  "created_at" : "2011-10-02 19:31:52 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 3, 10 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120575052579221504",
  "text" : "In @wycats' sproutcore 2 breakout, learning some crazy javascript hacks. Apparently JS has getters and setters?!",
  "id" : 120575052579221504,
  "created_at" : "2011-10-02 19:05:07 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u201CKonstantin\u201D",
      "screen_name" : "konstantinhaase",
      "indices" : [ 0, 16 ],
      "id_str" : "16997374",
      "id" : 16997374
    }, {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 62, 72 ],
      "id_str" : "42259749",
      "id" : 42259749
    }, {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 89, 96 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120562673367789568",
  "geo" : { },
  "id_str" : "120564033534435329",
  "in_reply_to_user_id" : 16997374,
  "text" : "@konstantinhaase was not a sinatra bug, but we should upgrade @gemcutter's sinatra soon! @sferik is a boss at upgrading :)",
  "id" : 120564033534435329,
  "in_reply_to_status_id" : 120562673367789568,
  "created_at" : "2011-10-02 18:21:20 +0000",
  "in_reply_to_screen_name" : "konstantinhaase",
  "in_reply_to_user_id_str" : "16997374",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 0, 12 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120557581264625664",
  "geo" : { },
  "id_str" : "120557898676961280",
  "in_reply_to_user_id" : 15524875,
  "text" : "@SaraJChipps jumped rooms, way up front stage right for scaling perf talk",
  "id" : 120557898676961280,
  "in_reply_to_status_id" : 120557581264625664,
  "created_at" : "2011-10-02 17:56:57 +0000",
  "in_reply_to_screen_name" : "SaraJChipps",
  "in_reply_to_user_id_str" : "15524875",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120557695085453312",
  "text" : "Macbook died at #jqcon, forgot my charger :(",
  "id" : 120557695085453312,
  "created_at" : "2011-10-02 17:56:09 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Burns",
      "screen_name" : "mikeburns",
      "indices" : [ 37, 47 ],
      "id_str" : "15001533",
      "id" : 15001533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/GUUuvuAY",
      "expanded_url" : "https:\/\/img.skitch.com\/20111002-jhc9yfnhd6ci8w4tcc76sbegct.png",
      "display_url" : "img.skitch.com\/20111002-jhc9y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120553386167898112",
  "text" : "Today's math humor brought to you by @mikeburns http:\/\/t.co\/GUUuvuAY",
  "id" : 120553386167898112,
  "created_at" : "2011-10-02 17:39:01 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraJo",
      "screen_name" : "SaraJChipps",
      "indices" : [ 3, 15 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120546993360744448",
  "text" : "In @SaraJChipps' talk at #jqcon!",
  "id" : 120546993360744448,
  "created_at" : "2011-10-02 17:13:37 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/iY3lUA9h",
      "expanded_url" : "https:\/\/gist.github.com\/1257579",
      "display_url" : "gist.github.com\/1257579"
    } ]
  },
  "geo" : { },
  "id_str" : "120530832111833088",
  "text" : "Seriously, which would you want to maintain? http:\/\/t.co\/iY3lUA9h (coffee vs js)",
  "id" : 120530832111833088,
  "created_at" : "2011-10-02 16:09:24 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ffMBTreL",
      "expanded_url" : "https:\/\/github.com\/qrush\/counter\/blob\/master\/Guardfile",
      "display_url" : "github.com\/qrush\/counter\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120527982866604032",
  "text" : "Exploring guard a little more, it provides a nice callback `start_begin` to allow commands to be run on guard startup: http:\/\/t.co\/ffMBTreL",
  "id" : 120527982866604032,
  "created_at" : "2011-10-02 15:58:05 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120526397109321729",
  "text" : "Culture shock: Notepad++ is still being used by serious developers.",
  "id" : 120526397109321729,
  "created_at" : "2011-10-02 15:51:47 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lolnodejs",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/tWKVaXgW",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!msg\/nodejs\/qxwjTOhB01Y\/hoyVDFGz9x0J",
      "display_url" : "groups.google.com\/forum\/#!msg\/no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120516270801158144",
  "text" : "\"It's because ruby rots people's brains.\" #lolnodejs http:\/\/t.co\/tWKVaXgW",
  "id" : 120516270801158144,
  "created_at" : "2011-10-02 15:11:32 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Hernandez",
      "screen_name" : "carlosjhrgf",
      "indices" : [ 0, 12 ],
      "id_str" : "257740771",
      "id" : 257740771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120512942029545473",
  "geo" : { },
  "id_str" : "120515522856099841",
  "in_reply_to_user_id" : 257740771,
  "text" : "@carlosjhrgf it's fixed, can you try again?",
  "id" : 120515522856099841,
  "in_reply_to_status_id" : 120512942029545473,
  "created_at" : "2011-10-02 15:08:34 +0000",
  "in_reply_to_screen_name" : "carlosjhrgf",
  "in_reply_to_user_id_str" : "257740771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemcutter",
      "screen_name" : "gemcutter",
      "indices" : [ 9, 19 ],
      "id_str" : "42259749",
      "id" : 42259749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120515484776013824",
  "text" : "Deployed @gemcutter from #jqcon!",
  "id" : 120515484776013824,
  "created_at" : "2011-10-02 15:08:25 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Hernandez",
      "screen_name" : "carlosjhrgf",
      "indices" : [ 0, 12 ],
      "id_str" : "257740771",
      "id" : 257740771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120512942029545473",
  "geo" : { },
  "id_str" : "120514193144299520",
  "in_reply_to_user_id" : 257740771,
  "text" : "@carlosjhrgf yeah, it's a known issue :(",
  "id" : 120514193144299520,
  "in_reply_to_status_id" : 120512942029545473,
  "created_at" : "2011-10-02 15:03:17 +0000",
  "in_reply_to_screen_name" : "carlosjhrgf",
  "in_reply_to_user_id_str" : "257740771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Hernandez",
      "screen_name" : "carlosjhrgf",
      "indices" : [ 0, 12 ],
      "id_str" : "257740771",
      "id" : 257740771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120509442096762880",
  "geo" : { },
  "id_str" : "120510219154489344",
  "in_reply_to_user_id" : 257740771,
  "text" : "@carlosjhrgf how so? i dont think we have...",
  "id" : 120510219154489344,
  "in_reply_to_status_id" : 120509442096762880,
  "created_at" : "2011-10-02 14:47:29 +0000",
  "in_reply_to_screen_name" : "carlosjhrgf",
  "in_reply_to_user_id_str" : "257740771",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Champion",
      "screen_name" : "graysky",
      "indices" : [ 0, 8 ],
      "id_str" : "364",
      "id" : 364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120474555742560256",
  "geo" : { },
  "id_str" : "120475944984133632",
  "in_reply_to_user_id" : 364,
  "text" : "@graysky I didn't go yesterday",
  "id" : 120475944984133632,
  "in_reply_to_status_id" : 120474555742560256,
  "created_at" : "2011-10-02 12:31:18 +0000",
  "in_reply_to_screen_name" : "graysky",
  "in_reply_to_user_id_str" : "364",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqcon",
      "indices" : [ 13, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120473965234880512",
  "text" : "Heading into #jqcon day 2, feeling way better!",
  "id" : 120473965234880512,
  "created_at" : "2011-10-02 12:23:26 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/hC83ZiSe",
      "expanded_url" : "https:\/\/github.com\/zynga\/scroller",
      "display_url" : "github.com\/zynga\/scroller"
    } ]
  },
  "geo" : { },
  "id_str" : "120321314102853632",
  "text" : "Wow: http:\/\/t.co\/hC83ZiSe",
  "id" : 120321314102853632,
  "created_at" : "2011-10-02 02:16:51 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "indices" : [ 3, 9 ],
      "id_str" : "15359408",
      "id" : 15359408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120294976742621184",
  "text" : "RT @raggi: [ANN] rubygems-mirror is now released. It should work with current rubygems, and will definitely work with the next release.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120290451558375424",
    "text" : "[ANN] rubygems-mirror is now released. It should work with current rubygems, and will definitely work with the next release.",
    "id" : 120290451558375424,
    "created_at" : "2011-10-02 00:14:13 +0000",
    "user" : {
      "name" : "James Tucker",
      "screen_name" : "raggi",
      "protected" : false,
      "id_str" : "15359408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3388593743\/5530c82013709c3922ef8f947092b623_normal.jpeg",
      "id" : 15359408,
      "verified" : false
    }
  },
  "id" : 120294976742621184,
  "created_at" : "2011-10-02 00:32:12 +0000",
  "user" : {
    "name" : "Nick Quaranto",
    "screen_name" : "qrush",
    "protected" : false,
    "id_str" : "5743852",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539934850052943872\/wtt9RBjT_normal.jpeg",
    "id" : 5743852,
    "verified" : false
  }
} ]